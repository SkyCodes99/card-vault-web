"""Choose the price type (roadmap "Choose the price type"): which kind of price every total values a card at.

Saved per game in the vault setting 'price_type' (it follows the account like 'price_pick', see webapi/settings.PREF_GAME).
    market   the card's market price - today's behaviour, and what every card falls back to
    low      the lowest price among the sources in use (price sources: pricepick.py)
    mid      the middle price among the sources in use
    recent   the recent typical sale price: the middle of the last 7 days of saved prices (Sale Data, trend.py) - our stand-in for "last sold", which no free feed gives
A card that has no price of the chosen type counts at its market price, and its price source line says so ("... no low price, market shown"), so a total is never
quietly short.  Low and Mid need two or more sources with a price for the card; a game with one source offers only Market and Recent.

For pricepick.py:
    chosen(v) -> the saved type ("market" when nothing is saved or the value is unknown)
    typed(v, kind, cands, days, known) -> {card id: (usd, source words, capture day)} for the cards that HAVE a price of that type
    available(v, n_sources) -> the types this game can show, for the Settings card
"""
import os
import statistics

KEY = "price_type"
NAMES = {"market": "Market price", "low": "Lowest price", "mid": "Middle price", "recent": "Recent sales"}
NOTES = {"market": "The usual price on each card (TCGplayer's market price).",
         "low": "The lowest price among the sources you use. Needs two or more sources with a price for the card.",
         "mid": "The middle price among the sources you use. Needs two or more sources with a price for the card.",
         "recent": "The typical price of the last 7 days of saved prices (not a list of actual sales). Needs a few days of saved history."}
IDS = tuple(NAMES)


def chosen(v):
    raw = v.get_setting(KEY)
    return raw if raw in IDS else "market"


def save(v, kind):
    kind = kind if kind in IDS else "market"
    v.set_setting(KEY, kind)                         # ("market" is stored too, not deleted: a deleted setting would not reach the synced record and the old type would come back)
    return kind


def _trend_path(v):
    return os.path.join(v.gdir, "trend.db")


def stamp(v):
    """Changes when this game's saved-price trend file does (part of the cache key of the picked prices)."""
    try:
        return os.path.getmtime(_trend_path(v))
    except OSError:
        return 0


def _trend(v):
    """This game's saved-price trend (cached on the vault until the file changes); empty and harmless when there is none."""
    from .trend import Trend
    st = stamp(v)
    got = getattr(v, "_pricetype_trend", None)
    if got is None or got[0] != st:
        got = v._pricetype_trend = (st, Trend(v.gdir))
    return got[1]


def available(v, n_sources):
    out = ["market"]
    if n_sources >= 2:
        out += ["low", "mid"]
    if stamp(v):
        out.append("recent")
    return out


def typed(v, kind, cands, days=None, known=None):
    """Prices of the chosen type.  cands = {card id: {source key: usd}} (pricepick._candidates, which also adds a 'store' key that is not a source);
    days = {(card id, source key): (words, day)}; known = the card ids to keep (None: all)."""
    out = {}
    if kind in ("low", "mid"):
        for cid, c in cands.items():
            vals = {k: x for k, x in c.items() if k != "store" and x is not None and x > 0}
            if len(vals) < 2:
                continue
            usd = min(vals.values()) if kind == "low" else statistics.median(vals.values())
            when = min(((days or {}).get((cid, k)) or ("", ""))[1] or "" for k in vals)
            out[cid] = (usd, f"{NAMES[kind]} of {len(vals)} sources", when)
    elif kind == "recent":
        t = _trend(v)
        for cid, r in (t.rows if t is not None else {}).items():
            if r and r[1] is not None and r[1] > 0 and (known is None or cid in known):
                out[cid] = (float(r[1]), "Recent typical price (last 7 days)", t.built)
    return out


def fallback_words(kind):
    """The words added to a price source line when the card has no price of the chosen type."""
    return f"no {NAMES[kind].lower()}, market shown"
