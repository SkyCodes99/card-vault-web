"""One copy of the desktop app at a time, and "is this working folder still in use?".

A second copy (an impatient double-click) used to unlock the same profile and treat the FIRST copy's open, decrypted collection as a crash leftover: it was overwritten,
and the first window lost every change after that (3.50.134 review).  Now a second start brings the open window forward and exits, and a working folder whose owner
is still running is never touched.

Both use an exclusive lock on a small file: the system drops it the moment its owner ends (also after a crash), so a stale lock can never keep the app from starting."""
import errno
import os
import sys
import time

_AT = 1 << 16          # the locked byte lies past the text, so the owner's process id stays readable by others


class FileLock:
    """An exclusive, non-blocking lock on `path` (created if missing).  Held until release() or until the process ends."""

    def __init__(self, path):
        self.path, self.f = path, None

    def acquire(self, note=""):
        try:
            open(self.path, "ab").close()
            f = open(self.path, "r+b")
        except OSError:
            return False
        try:
            if os.name == "nt":
                import msvcrt
                f.seek(_AT)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (ImportError, AttributeError):
            pass                                  # a system without file locks (the website's engine runs in the browser): nothing else can run beside it there
        except OSError as e:
            if e.errno not in (errno.ENOSYS, errno.ENOTSUP, getattr(errno, "EOPNOTSUPP", errno.ENOTSUP)):
                f.close()
                return False
        if note:
            try:
                f.seek(0)
                f.truncate()
                f.write(note.encode("utf-8"))
                f.flush()
            except OSError:
                pass
        self.f = f
        return True

    def release(self):
        f, self.f = self.f, None
        if f is None:
            return
        try:
            if os.name == "nt":
                import msvcrt
                f.seek(_AT)
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        finally:
            f.close()


def in_use(path):
    """Is the lock file at `path` held right now (by this process or any other)?  A missing file = nobody."""
    if not os.path.isfile(path):
        return False
    probe = FileLock(path)
    if probe.acquire():
        probe.release()
        return False
    return True


def lock_path():
    from .paths import CONFIG_DIR
    return os.path.join(CONFIG_DIR, "app.lock")


def claim(wait=None):
    """Become THE running copy: -> the held FileLock, or None when another copy already runs.  A copy started by an update or a restart waits for the old one to end first."""
    if wait is None:
        from . import skyrelaunch
        wait = 60.0 if skyrelaunch.was_restarted() else 2.0
    path = lock_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except OSError:
        pass
    lock, end = FileLock(path), time.time() + wait
    while True:
        if lock.acquire(str(os.getpid())):
            return lock
        if time.time() >= end:
            return None
        time.sleep(0.2)


def other_pid():
    try:
        with open(lock_path(), "rb", buffering=0) as f:          # (unbuffered: a buffered read asks for more and runs into the locked byte - "permission denied")
            raw = f.read(32).decode("ascii", "ignore").strip()
        return int(raw) if raw.isdigit() else 0
    except OSError:
        return 0


def show_other(pid=None):
    """Bring the running copy's window to the front (restored if minimised).  -> True when a window was found.  Windows only; elsewhere nothing happens."""
    pid = pid or other_pid()
    if not pid or not sys.platform.startswith("win"):
        return False
    try:
        import ctypes
        from ctypes import wintypes
        from .version import APP_NAME
        user32 = ctypes.windll.user32
        found = []
        proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def each(hwnd, _):
            if not user32.IsWindowVisible(hwnd):
                return True
            owner = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value != pid:
                return True
            n = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value.startswith(APP_NAME):
                found.append(hwnd)
                return False
            return True
        user32.EnumWindows(proto(each), 0)
        if not found:
            return False
        if user32.IsIconic(found[0]):
            user32.ShowWindow(found[0], 9)          # SW_RESTORE
        user32.SetForegroundWindow(found[0])
        return True
    except Exception:  # noqa: BLE001 - bringing it forward is a courtesy; the second copy exits either way
        return False
