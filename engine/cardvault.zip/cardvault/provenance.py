"""Everything remembers where it came from (roadmap 1.5): every card, picture and price records its source, link and date.

One small table in each game's cards.db:
    provenance(card_id, field, source, day, ref)   field = card | name | image | price | date; source = a short code; day = 'YYYY-MM-DD' (NULL = before records began)
    sources(code, name, url_tpl)                   the long strings live here once, not on every row
The link is NOT stored per row: it is the source's template filled from the card ({tcg_id}, {id}, {image_base}); `ref` holds a link only when a source has no template.
Same shape as Fetched.provenance() in cardvault/sources: source + url + fetched_at (day = the date part of fetched_at)."""
import datetime
import json
import re
import sqlite3

FIELDS = ("card", "name", "image", "price", "date")

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources(code TEXT PRIMARY KEY, name TEXT, url_tpl TEXT);
CREATE TABLE IF NOT EXISTS provenance(
    card_id TEXT NOT NULL, field TEXT NOT NULL, source TEXT NOT NULL, day TEXT, ref TEXT,
    PRIMARY KEY(card_id, field)) WITHOUT ROWID;
"""

# code -> (name, link template).  ".i" = the picture host of that site (its link is the picture itself).
SOURCES = {
    "tcgp": ("TCGplayer", "https://www.tcgplayer.com/product/{tcg_id}"),
    "tcgp.i": ("TCGplayer", "{image_base}"),
    "tdx": ("TCGdex", "https://api.tcgdex.net/v2/en/cards/{id}"),
    "tdx.i": ("TCGdex", "{image_base}"),
    "scry": ("Scryfall", "https://scryfall.com/search?q=tcgplayer_id%3A{tcg_id}"),
    "scry.i": ("Scryfall", "{image_base}"),
    "mtgj": ("MTGJSON", "https://mtgjson.com"),
    "ebay": ("eBay", None),
    # release dates (roadmap 2.9, cardvault/datefix.py): a sealed product's day and where it came from
    "tcgp.d": ("TCGplayer set date", "https://tcgcsv.com/tcgplayer"), "inherit": ("Its set's date", None),
    "fix": ("Owner's correction", None),
}
# How far a source is believed when two disagree (cardvault/keepfixes.py): the bulk card feed (TCGdex) never overwrites a field that the owner or a more trusted source set.
# A source not named here (TCGplayer, Scryfall, a picture host met later) sits between the two.
TRUST = {"fix": 9, "tdx": 1, "tdx.i": 1}
DEFAULT_TRUST = 5


def trust(code):
    """How far a source code is believed: 0 for none, 1 for the bulk feed, 9 for the owner's own fix."""
    return TRUST.get(code, DEFAULT_TRUST) if code else 0
IMAGE_HOSTS = {"tcgplayer-cdn.tcgplayer.com": "tcgp.i", "product-images.tcgplayer.com": "tcgp.i", "assets.tcgdex.net": "tdx.i",
               "cards.scryfall.io": "scry.i", "c1.scryfall.com": "scry.i"}


def today():
    return datetime.date.today().isoformat()


def ensure(conn):
    """Idempotent migration: the two tables and the known sources.  Safe to call on every open."""
    conn.executescript(SCHEMA)
    conn.executemany("INSERT OR IGNORE INTO sources(code,name,url_tpl) VALUES(?,?,?)", [(k, v[0], v[1]) for k, v in SOURCES.items()])


def host_of(url):
    m = re.match(r"https?://([^/]+)", url or "")
    return m.group(1).lower() if m else ""


def image_source(conn, url):
    """The source code for a picture link, by its host; a host we have not met is registered as its own source ('i:host')."""
    host = host_of(url)
    if not host:
        return None
    code = IMAGE_HOSTS.get(host)
    if code:
        return code
    code = "i:" + host
    conn.execute("INSERT OR IGNORE INTO sources(code,name,url_tpl) VALUES(?,?,?)", (code, host, "{image_base}"))
    return code


def _run(conn, fn):
    try:
        return fn()
    except sqlite3.OperationalError as e:
        if "no such table" not in str(e):
            raise
        ensure(conn)
        return fn()


def record_many(conn, rows):
    """rows: (card_id, field, source, day=None, ref=None) tuples.  The newest record for a card + field replaces the old one.  The caller commits."""
    rows = [(str(r[0]), r[1], r[2], (r[3] if len(r) > 3 else None) or today(), r[4] if len(r) > 4 else None) for r in rows if r[2]]
    if rows:
        _run(conn, lambda: conn.executemany("INSERT OR REPLACE INTO provenance(card_id,field,source,day,ref) VALUES(?,?,?,?,?)", rows))


def record(conn, card_id, field, source, day=None, ref=None):
    record_many(conn, [(card_id, field, source, day, ref)])


def record_by_tcg(conn, field, source, items):
    """items: (tcg_id, day) pairs - stamps every card with that TCGplayer link (the daily price file is keyed by it).  The caller commits."""
    items = [(d, str(t)) for t, d in items]
    _run(conn, lambda: conn.executemany("INSERT OR REPLACE INTO provenance(card_id,field,source,day) SELECT id, '%s', '%s', ? FROM cards WHERE tcg_id=?" % (field, source), items))


def record_image(conn, card_id, url, day=None):
    """A card's picture came from `url` (today, unless day is given)."""
    src = image_source(conn, url)
    if src:
        record(conn, card_id, "image", src, day)


def from_raw(conn):
    """The toy and collectible lists (audit L6.2): every entry with no record yet gets one from what its builder already kept in the row - the entry from its page (raw 'url': the shop or source
    page, kept as the row's link) or its named source (raw 'source'), the picture from its link's host, a retail price from the page it was read on (dated by price_updated).  Undated otherwise:
    the day it was read was not kept.  INSERT OR IGNORE, so a record a live fetch wrote is never replaced.  The caller commits.  -> rows added"""
    ensure(conn)
    rows, srcs = [], {}
    for cid, img, kind, upd, price, raw in conn.execute("SELECT id, image_base, price_kind, price_updated, price_usd, raw FROM cards"):
        try:
            r = json.loads(raw) if raw else {}
        except ValueError:
            r = {}
        r = r if isinstance(r, dict) else {}
        url = r.get("url") if str(r.get("url") or "").startswith("http") else ""
        if r.get("productId") or str(cid).isdigit():
            code, ref = "tcgp", None                                     # (a TCGplayer product: its link is the source's template)
        elif url:
            code, ref = "w:" + host_of(url), url
            srcs[code] = host_of(url)
        elif isinstance(r.get("source"), str) and r["source"].strip():
            code, ref = "n:" + r["source"].strip()[:80], None
            srcs[code] = r["source"].strip()[:80]
        else:
            code = ref = None
        if code:
            rows.append((cid, "card", code, None, ref))
            if price is not None and kind == "retail price" and code != "tcgp":
                rows.append((cid, "price", code, upd, ref))
        if str(img or "").startswith("http"):
            rows.append((cid, "image", image_source(conn, img), None, None))
    conn.executemany("INSERT OR IGNORE INTO sources(code,name,url_tpl) VALUES(?,?,NULL)", list(srcs.items()))
    before = conn.total_changes
    conn.executemany("INSERT OR IGNORE INTO provenance(card_id,field,source,day,ref) VALUES(?,?,?,?,?)", [r for r in rows if r[2]])
    return conn.total_changes - before


def for_card(conn, card_id):
    """What the item detail shows: [{field, source, name, url, date}] in card / image / price order; [] for a list made before records began."""
    try:
        rows = conn.execute("SELECT p.field, p.source, p.day, p.ref, s.name, s.url_tpl FROM provenance p LEFT JOIN sources s ON s.code=p.source WHERE p.card_id=?", (str(card_id),)).fetchall()
        c = conn.execute("SELECT id, tcg_id, image_base FROM cards WHERE id=?", (str(card_id),)).fetchone()
    except sqlite3.Error:
        return []
    vals = {"id": c[0], "tcg_id": c[1] or (c[0] if str(c[0]).isdigit() else ""), "image_base": c[2] or ""} if c else {}
    out = []
    for field, source, day, ref, name, tpl in sorted(rows, key=lambda r: FIELDS.index(r[0]) if r[0] in FIELDS else 9):
        url = ref
        if not url and tpl:
            try:
                url = tpl.format(**vals)
            except (KeyError, IndexError):
                url = ""
            if not all(vals.get(k) for k in re.findall(r"\{(\w+)\}", tpl)):
                url = ""                                   # (a template that needs a value this card does not have gives no link)
        out.append({"field": field, "source": source, "name": name or source, "url": url or "", "date": day or ""})
    return out
