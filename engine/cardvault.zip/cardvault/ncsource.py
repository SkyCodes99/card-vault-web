"""Picture hosts whose licence allows only non-commercial use: a picture from one of them is never shown (owner quiz 2026-11-15 q4/q11: "Find another source"; owner 2026-11-14: "NO shown
picture anywhere in 135 comes from bulbapedia/archives.bulbagarden").
Bulbapedia and the Bulbagarden Archives (every *.bulbagarden.net site) are CC BY-NC-SA.  Facts read there (which Pokemon a pack shows, a release date) are not their material and may stay;
their pictures and text may not.  Used by the pack arts (packarts.py), the retail collaborations (collabmerch.py), the plush list (collectibles.py), the pictures found elsewhere
(tools/repair_pictures.py), the set logos (bulbapedia.py), and strip_db(), which clears such pictures from a card list when it is published, installed or opened (the item then shows
"No picture yet")."""
import json
import sqlite3
from urllib.parse import urlparse

NC_HOSTS = ("bulbagarden.net",)
NOTE = "No picture yet: the only picture found is from Bulbapedia / the Bulbagarden Archives, whose licence allows only non-commercial use."


def non_commercial(url):
    """True when a picture's address is on a non-commercial-only host (also an address written without its 'https:' or without '//')."""
    s = str(url or "").strip()
    host = urlparse(s).netloc or (urlparse("//" + s).netloc if "://" not in s and not s.startswith("/") else "")
    host = host.lower().rsplit("@", 1)[-1].split(":")[0].rstrip(".")
    return any(host == h or host.endswith("." + h) for h in NC_HOSTS)


def picture(url):
    """The picture address when it may be shown (https, not a non-commercial host), else ''."""
    url = str(url or "")
    return url if url.startswith("https://") and not non_commercial(url) else ""


def allowed(url):
    """The address unchanged unless it is on a non-commercial host ('' then).  Unlike picture() it keeps any address form the list already uses (a TCGdex base, a local path)."""
    return "" if non_commercial(url) else (url or "")


_LIKE = tuple(f"%{h}%" for h in NC_HOSTS)
_RAW_PICTURES = ("image_primary", "thumb")                 # picture addresses a card keeps in raw (the real one behind a stand-in, a plush's wiki thumbnail): never brought back


def strip_db(conn):
    """Clears every picture address on a non-commercial host from a card list: cards.image_base (with raw.image_note saying why, and the copies kept in raw), sealed_products.image_base
    and sets.logo.  -> number of pictures cleared.  The caller commits.  A list without one of the tables is fine."""
    n = 0
    where = lambda col: " OR ".join(f"{col} LIKE ?" for _ in _LIKE)
    try:
        rows = conn.execute(f"SELECT id, image_base, raw FROM cards WHERE {where('image_base')} OR {where('raw')}", _LIKE + _LIKE).fetchall()
    except sqlite3.OperationalError:
        rows = []
    updates = []
    for cid, base, raw in rows:
        try:
            d = json.loads(raw) if raw else {}
        except ValueError:
            d = None
        changed = False
        if isinstance(d, dict):
            for k in _RAW_PICTURES:
                if non_commercial(d.get(k)):
                    d[k] = ""
                    changed = True
        if non_commercial(base):
            base, n = None, n + 1
            if isinstance(d, dict):
                d["image_note"] = NOTE
            changed = True
        if changed:
            updates.append((base, json.dumps(d, ensure_ascii=False) if isinstance(d, dict) else raw, cid))
    if updates:
        conn.executemany("UPDATE cards SET image_base=?, raw=? WHERE id=?", updates)
    for table, col in (("sealed_products", "image_base"), ("sets", "logo")):
        try:
            hit = [(r[0],) for r in conn.execute(f"SELECT id, {col} FROM {table} WHERE {where(col)}", _LIKE).fetchall() if non_commercial(r[1])]
        except sqlite3.OperationalError:
            continue
        if hit:
            conn.executemany(f"UPDATE {table} SET {col}=NULL WHERE id=?", hit)
            n += len(hit)
    return n
