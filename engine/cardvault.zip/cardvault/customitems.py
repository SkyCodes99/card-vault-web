"""Your own items: things that are in no catalog (a hand-made figure, a local-con exclusive, a vintage toy, a one-off).

An item is a row in u.custom_items (name, set, series, number, category, labels, YOUR ESTIMATE, picture fingerprint).  It syncs through the cloud snapshot like the sold and grading rows
(cloud/snapshot.py "custom_items", the sync stamp, conflicts.py).  Everything else about it is an ordinary copy: quantity, condition, price paid, notes, location and portfolio live in a normal
u.lots row, so the collection, search, checklists, duplicates, sold history, export, insurance report and every count already work for it.
To make that true the item is also written into the game's card list as a card called "custom:<uuid>" (materialize(): at every open, after every change, after a card-list download or a sync -
the card list on disk is a copy of Card Data and a new copy would otherwise lose it).  Only the open person's items are in it, so a second account on the same PC never sees them.

VALUE - the estimate is stored as the card's price with the price kind "your estimate" (ESTIMATE_KIND):
  * it counts in every total, under every price source pick, and is labelled "your estimate" wherever a price is shown (pricepick.py treats it like a store price);
  * it is NOT a true price: completion.true_price() says no, so the item is in the "N have no true price" count;
  * it is never market data: record_price_history() skips it, so it never reaches price history, trends, market movers, AI or modelling.
PICTURE - the owner's own photo.  The bytes live in u.lot_photos under the item's uuid (that table syncs only to the owner's own account, encrypted) and a copy is written as the card's picture file
in this game's images folder (the existing /img route serves it).  Nothing else ever sends it anywhere.
ONE UNDO per action (create, edit, delete) through rowundo.track (custom_items + lots rows; the card-list copy is rebuilt from them)."""
import base64
import hashlib
import io
import json
import os
import re

from . import rowundo
from .db import CONDITIONS, image_file, new_uuid, now_iso, sort_key, today

rowundo.TABLES.setdefault("custom_items", "uuid")

PREFIX = "custom:"
ESTIMATE_KIND = "your estimate"
OTHER_GAME = "other"                                   # the "Other" game: a home for items that belong to no game on the list
DEFAULT_SET = "My items"
DEFAULT_SERIES = "My own items"
MAX_LABELS, MAX_PICTURES_KEPT = 12, 3

SCHEMA = ("CREATE TABLE IF NOT EXISTS u.custom_items("
          "uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, name TEXT, set_name TEXT, series TEXT, number TEXT, category TEXT, labels TEXT, estimate REAL, pic TEXT, "
          "updated_at TEXT, deleted INTEGER DEFAULT 0)",
          "CREATE INDEX IF NOT EXISTS u.custom_items_user ON custom_items(user_id, game)")
COLS = ("name", "set_name", "series", "number", "category", "labels", "estimate", "pic", "updated_at", "deleted")      # what travels in a snapshot (the owner and game are known by the receiving device)


class CustomError(ValueError):
    pass


def ensure(v):
    for sql in SCHEMA:
        v.conn.execute(sql)


def is_custom(card_id):
    return str(card_id or "").startswith(PREFIX)


def is_estimate(kind):
    return str(kind or "").lower().startswith(ESTIMATE_KIND)


# ------------------------------------------------------------------------------------------------ reading what was typed
def _text(x, what, n, required=False):
    s = re.sub(r"\s+", " ", str(x or "")).strip()
    if required and not s:
        raise CustomError(f"Type {what}.")
    return s[:n]


def _money(x, what):
    if x in (None, ""):
        return None
    try:
        c = float(x)
    except (TypeError, ValueError):
        raise CustomError(f"{what[0].upper() + what[1:]} has to be a number.")
    if c < 0 or c != c or c > 1e9:
        raise CustomError(f"{what[0].upper() + what[1:]} has to be zero or more.")
    return round(c, 4)


def _labels(x):
    parts = x if isinstance(x, (list, tuple)) else re.split(r"[;,]", str(x or ""))
    out = []
    for p in parts:
        s = _text(p, "", 30)
        if s and s.lower() not in {o.lower() for o in out}:
            out.append(s)
    return ",".join(out[:MAX_LABELS])


def _qty(x):
    try:
        n = int(float(x))
    except (TypeError, ValueError):
        raise CustomError("How many you own has to be a whole number.")
    if n < 1:
        raise CustomError("You own at least one.")
    return min(n, 100000)


def _fields(d, creating):
    """What the form sent -> the item's own fields (only those present when editing)."""
    out = {}
    spec = {"name": lambda x: _text(x, "a name", 120, required=True), "set_name": lambda x: _text(x, "", 80), "series": lambda x: _text(x, "", 80), "number": lambda x: _text(x, "", 30),
            "category": lambda x: _text(x, "", 60), "labels": _labels, "estimate": lambda x: _money(x, "your estimate")}
    for k, fn in spec.items():
        if k in d or (creating and k == "name"):
            out[k] = fn(d.get(k))
    return out


def _lot_fields(d):
    """What the form sent about the copies: {qty, condition, purchase_price, notes, location, portfolio} (only those present)."""
    out = {}
    if d.get("qty") not in (None, ""):
        out["qty"] = _qty(d["qty"])
    if "condition" in d:
        c = str(d.get("condition") or "").strip()
        out["condition"] = c if c in CONDITIONS else "Near Mint"
    if "paid" in d:
        out["purchase_price"] = _money(d.get("paid"), "the price paid")
    if "notes" in d:
        out["notes"] = _text(d.get("notes"), "", 400)
    if "location" in d:
        out["location"] = _text(d.get("location"), "", 80)
    if d.get("portfolio") is not None and "portfolio" in d:
        out["portfolio"] = str(d["portfolio"])
    return out


# ------------------------------------------------------------------------------------------------ the card-list copy
def set_id_of(name):
    return PREFIX + hashlib.sha1((name or DEFAULT_SET).lower().encode("utf-8")).hexdigest()[:10]


def _card_row(r):
    """The cards-table values of one item row."""
    est = r["estimate"]
    num = r["number"] or ""
    return {"id": PREFIX + r["uuid"], "set_id": set_id_of(r["set_name"] or DEFAULT_SET), "local_id": num, "sort_key": sort_key(num), "name": r["name"], "image_base": "", "detailed": 1,
            "category": r["category"] or None, "types": r["labels"] or None, "description": "Added by you",
            "price_usd": est if est and est > 0 else None, "price_kind": ESTIMATE_KIND if est and est > 0 else None, "price_updated": (r["updated_at"] or "")[:10] or today(),
            "variants": json.dumps({"normal": True}), "raw": json.dumps({"custom": r["uuid"]})}


def materialize(v):
    """Make this person's items cards in the open game's card list (and nobody else's).  -> True when the card list changed.  Cheap when there is nothing to do."""
    c = v.conn
    ensure(v)
    rows = [r for r in c.execute("SELECT * FROM u.custom_items WHERE user_id=? AND game=? AND deleted=0", (v.user_id, v.game))]
    have = {r["id"]: r for r in c.execute("SELECT * FROM main.cards WHERE id LIKE 'custom:%'")}
    if not rows and not have:
        return False
    changed = False
    want = {}
    for r in rows:
        row = _card_row(r)
        want[row["id"]] = row
        old = have.get(row["id"])
        if old is None or any(old[k] != row[k] for k in row if k in old.keys()):
            c.execute(f"INSERT OR REPLACE INTO main.cards({','.join(row)}) VALUES({','.join('?' * len(row))})", list(row.values()))
            changed = True
    for cid in set(have) - set(want):
        c.execute("DELETE FROM main.cards WHERE id=?", (cid,))
        changed = True
    sets = {}
    for row in want.values():
        sets.setdefault(row["set_id"], 0)
        sets[row["set_id"]] += 1
    names = {}
    for r in rows:
        names.setdefault(set_id_of(r["set_name"] or DEFAULT_SET), (r["set_name"] or DEFAULT_SET, r["series"] or DEFAULT_SERIES))
    for sid, n in sets.items():
        name, serie = names[sid]
        old = c.execute("SELECT name, serie, total FROM main.sets WHERE id=?", (sid,)).fetchone()
        if old is None or (old["name"], old["serie"], old["total"]) != (name, serie, n):
            c.execute("INSERT OR REPLACE INTO main.sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,NULL,?,0,NULL)", (sid, name, serie, n))
            changed = True
    for (sid,) in c.execute("SELECT id FROM main.sets WHERE id LIKE 'custom:%'").fetchall():
        if sid not in sets:
            c.execute("DELETE FROM main.sets WHERE id=?", (sid,))
            changed = True
    if changed:
        c.commit()
        v.invalidate_index()
        v.__dict__.pop("_img_bases", None)
    write_pictures(v, rows)
    return changed


# ------------------------------------------------------------------------------------------------ the picture
def _jpeg(data_url):
    """A photo the person picked (a data: address) -> a JPEG of at most 900 px."""
    if not isinstance(data_url, str) or len(data_url) > 45_000_000:
        raise CustomError("That picture is too large.")
    try:
        from PIL import Image
        raw = base64.b64decode(data_url.split(",", 1)[-1])
        with Image.open(io.BytesIO(raw)) as im:
            im = im.convert("RGB")
            im.thumbnail((900, 900))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=82)
        return buf.getvalue()
    except Exception:  # noqa: BLE001 - anything that is not a picture
        raise CustomError("That isn't a picture I can read.")


def fingerprint(data):
    return hashlib.sha1(data).hexdigest()[:20]


def picture_bytes(v, uuid, pic=None):
    """The JPEG bytes of the item's current picture (by its fingerprint), or None."""
    if pic is None:
        r = v.conn.execute("SELECT pic FROM u.custom_items WHERE uuid=?", (uuid,)).fetchone()
        pic = r[0] if r else ""
    if not pic:
        return None
    for (data,) in v.conn.execute("SELECT data FROM u.lot_photos WHERE lot_uuid=? ORDER BY id DESC", (uuid,)):
        if data and fingerprint(data) == pic:
            return bytes(data)
    return None


def save_picture(v, uuid, data_url):
    """Keep a new picture for an item: -> its fingerprint ('' removes the picture).  The older few stay in the table so one Undo can bring the last one back."""
    if not data_url:
        return ""
    data = _jpeg(data_url)
    fp = fingerprint(data)
    if not v.conn.execute("SELECT 1 FROM u.lot_photos WHERE lot_uuid=? AND data=?", (uuid, data)).fetchone():
        v.conn.execute("INSERT INTO u.lot_photos(lot_uuid, side, data, added) VALUES(?,?,?,?)", (uuid, "front", data, now_iso()))
    ids = [r[0] for r in v.conn.execute("SELECT id FROM u.lot_photos WHERE lot_uuid=? ORDER BY id DESC", (uuid,))]
    for old in ids[MAX_PICTURES_KEPT:]:
        row = v.conn.execute("SELECT data FROM u.lot_photos WHERE id=?", (old,)).fetchone()
        if row and row[0]:
            from .cloud import photos
            v.conn.execute("INSERT OR IGNORE INTO u.photo_deleted VALUES(?,datetime('now'))", (photos.key_for(uuid, row[0]),))
        v.conn.execute("DELETE FROM u.lot_photos WHERE id=?", (old,))
    return fp


def _picture_paths(v, row):
    sid = set_id_of(row["set_name"] or DEFAULT_SET)
    return [image_file(v.gdir, q, PREFIX + row["uuid"], sid) for q in ("low", "high")]


def write_pictures(v, rows=None):
    """Put each item's picture where the card pictures are (so /img shows it).  Only what changed is written (a small .sha file beside the picture says which one is there).  -> [paths written]"""
    if rows is None:
        rows = list(v.conn.execute("SELECT * FROM u.custom_items WHERE user_id=? AND game=? AND deleted=0", (v.user_id, v.game)))
    done = []
    for r in rows:
        paths = _picture_paths(v, r)
        pic = r["pic"] or ""
        for p in paths:
            mark = p + ".sha"
            try:
                current = open(mark).read().strip() if os.path.exists(mark) else ""
                if current == pic:
                    continue
                if not pic:
                    for x in (p, mark):
                        if os.path.exists(x):
                            os.remove(x)
                    done.append(p)
                    continue
                data = picture_bytes(v, r["uuid"], pic)
                if data is None:
                    continue                                              # (the picture has not arrived from the other device yet: written when it does)
                from PIL import Image
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with Image.open(io.BytesIO(data)) as im:
                    im.save(p + ".part", "WEBP", quality=82)
                os.replace(p + ".part", p)
                with open(mark, "w") as f:
                    f.write(pic)
                done.append(p)
            except Exception:  # noqa: BLE001 - a picture problem must never stop the item (it shows its placeholder)
                continue
    return done


# ------------------------------------------------------------------------------------------------ the actions
def _item(v, uuid):
    r = v.conn.execute("SELECT * FROM u.custom_items WHERE uuid=? AND user_id=? AND game=? AND deleted=0", (uuid, v.user_id, v.game)).fetchone()
    if r is None:
        raise CustomError("That item is not in your collection any more.")
    return r


def _lot(v, uuid):
    return v.conn.execute("SELECT * FROM u.lots WHERE user_id=? AND game=? AND card_id=? AND deleted=0 ORDER BY id LIMIT 1", (v.user_id, v.game, PREFIX + uuid)).fetchone()


def _specs(v, card_id):
    return [("custom_items", "user_id=? AND game=?", (v.user_id, v.game)),
            ("lots", "user_id=? AND game=? AND card_id=?", (v.user_id, v.game, card_id))]


def _insert_lot(v, card_id, f):
    ts = now_iso()
    pf = f.get("portfolio", v.target_pf) or ""
    v.check_accepts(pf, v.item_kind())
    v.conn.execute("INSERT INTO u.lots(uuid,user_id,game,card_id,variant,condition,language,qty,graded,grade_company,grade,purchase_price,notes,cert,location,edition,purchased,source,portfolio,added,updated_at,deleted,placed) "
                   "VALUES(?,?,?,?,?,?,?,?,0,'','',?,?,'',?,'',?,'',?,?,?,0,1)",
                   (new_uuid(), v.user_id, v.game, card_id, "Normal", f.get("condition", "Near Mint"), "English", f.get("qty", 1), f.get("purchase_price"), f.get("notes", ""), f.get("location", ""),
                    today(), pf, ts, ts))


def create(v, d, uuid=None):
    """Add an item you own that is in no catalog.  d: name (needed), set_name, series, number, category, labels, estimate, qty, condition, paid, notes, location, portfolio, picture (a data: address).
    -> {uuid, id (its card id), picture: [paths written]}.  ONE undo takes it all away."""
    ensure(v)
    f = _fields(d, True)
    lot = _lot_fields({"qty": 1 if d.get("qty") in (None, "") else d.get("qty"), "condition": d.get("condition") or "Near Mint", **{k: d[k] for k in ("paid", "notes", "location", "portfolio") if k in d}})
    pic_in = d.get("picture")
    uuid = uuid or new_uuid()
    cid = PREFIX + uuid
    ts = now_iso()

    def run():
        pic = save_picture(v, uuid, pic_in) if pic_in else ""
        v.conn.execute("INSERT OR REPLACE INTO u.custom_items(uuid,user_id,game,name,set_name,series,number,category,labels,estimate,pic,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                       (uuid, v.user_id, v.game, f["name"], f.get("set_name", ""), f.get("series", ""), f.get("number", ""), f.get("category", ""), f.get("labels", ""), f.get("estimate"), pic, ts))
        _insert_lot(v, cid, lot)

    rowundo.track(v, f"Added your own item: {f['name']}", _specs(v, cid), run)
    materialize(v)
    v.log("custom.add", "custom_item", uuid, {"name": f["name"]})
    return {"uuid": uuid, "id": cid, "picture": _picture_paths(v, {"uuid": uuid, "set_name": f.get("set_name", "")})}


def edit(v, uuid, d):
    """Change an item: its own fields (name, set_name, series, number, category, labels, estimate, picture) and its first stack (qty, condition, paid, notes, location).  Only what is sent changes.
    ONE undo."""
    ensure(v)
    old = _item(v, uuid)
    f = _fields(d, False)
    lf = _lot_fields(d)
    cid = PREFIX + uuid
    has_pic = "picture" in d

    def run():
        sets = dict(f)
        if has_pic:
            sets["pic"] = save_picture(v, uuid, d.get("picture")) if d.get("picture") else ""
        if sets:
            sets["updated_at"] = now_iso()
            v.conn.execute(f"UPDATE u.custom_items SET {','.join(f'{k}=?' for k in sets)} WHERE uuid=?", (*sets.values(), uuid))
        if lf:
            lot = _lot(v, uuid)
            if lot is None:
                _insert_lot(v, cid, lf)
            else:
                ts = now_iso()
                if "portfolio" in lf:
                    v.check_accepts(lf["portfolio"], v.item_kind())
                v.conn.execute(f"UPDATE u.lots SET {','.join(f'{k}=?' for k in lf)}, updated_at=? WHERE id=?", (*lf.values(), ts, lot["id"]))

    rowundo.track(v, f"Edited your own item: {f.get('name', old['name'])}", _specs(v, cid), run)
    materialize(v)
    v.log("custom.edit", "custom_item", uuid, {"fields": sorted(set(f) | set(lf) | ({"picture"} if has_pic else set()))})
    return {"uuid": uuid, "id": cid}


def remove(v, uuid):
    """Delete an item and every copy of it from the collection (one undo).  Sold history rows keep their own copy of the details."""
    ensure(v)
    old = _item(v, uuid)
    cid = PREFIX + uuid

    def run():
        ts = now_iso()
        v.conn.execute("UPDATE u.custom_items SET deleted=1, updated_at=? WHERE uuid=?", (ts, uuid))
        v.conn.execute("UPDATE u.lots SET deleted=1, updated_at=? WHERE user_id=? AND game=? AND card_id=? AND deleted=0", (ts, v.user_id, v.game, cid))
        v.conn.execute("DELETE FROM u.wishlist WHERE user_id=? AND game=? AND card_id=?", (v.user_id, v.game, cid))

    rowundo.track(v, f"Deleted your own item: {old['name']}", _specs(v, cid), run)
    materialize(v)
    v.log("custom.delete", "custom_item", uuid, {"name": old["name"]})
    return {"uuid": uuid}


def restore_from_row(v, row):
    """A line of the app's own CSV export for an item of yours (card_id custom:<uuid>): make the item again, with the same uuid, when this profile does not have it.  -> True when it is there now.
    Not undone item by item - the import's own undo removes the copies; the item stays as a card you do not own."""
    cid = (row.get("card_id") or "").strip()
    if not is_custom(cid) or not (row.get("name") or "").strip():
        return False
    uuid = cid[len(PREFIX):]
    ensure(v)
    est = _money(row.get("your_estimate"), "your estimate") if (row.get("your_estimate") or "") != "" else None
    cur = v.conn.execute("SELECT deleted FROM u.custom_items WHERE uuid=?", (uuid,)).fetchone()
    vals = (_text(row.get("name"), "", 120), _text(row.get("set"), "", 80), _text(row.get("series"), "", 80), _text(row.get("number"), "", 30),
            _text(row.get("item_category"), "", 60), _labels(row.get("labels")), est)
    if cur is None:
        v.conn.execute("INSERT INTO u.custom_items(uuid,user_id,game,name,set_name,series,number,category,labels,estimate,pic,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,'',?,0)",
                       (uuid, v.user_id, v.game, *vals, now_iso()))
    elif cur[0]:
        v.conn.execute("UPDATE u.custom_items SET deleted=0, updated_at=? WHERE uuid=?", (now_iso(), uuid))
    materialize(v)
    return True


# ------------------------------------------------------------------------------------------------ reading
def mine_ids(v):
    """{card id} of every item of the signed-in person, in every game (a card list on this PC may still hold another account's items: only these are theirs)."""
    ensure(v)
    return {PREFIX + r[0] for r in v.conn.execute("SELECT uuid FROM u.custom_items WHERE user_id=? AND deleted=0", (v.user_id,))}


def get(v, uuid):
    """One item for the edit form: its fields, its first stack and its picture (a data: address)."""
    ensure(v)
    r = _item(v, uuid)
    lot = _lot(v, uuid)
    data = picture_bytes(v, uuid, r["pic"])
    return {"uuid": uuid, "id": PREFIX + uuid, "game": v.game, "name": r["name"], "set_name": r["set_name"] or "", "series": r["series"] or "", "number": r["number"] or "", "category": r["category"] or "",
            "labels": [x for x in (r["labels"] or "").split(",") if x], "estimate": r["estimate"], "picture": ("data:image/jpeg;base64," + base64.b64encode(data).decode()) if data else "",
            "qty": lot["qty"] if lot else 0, "condition": lot["condition"] if lot else "Near Mint", "paid": lot["purchase_price"] if lot else None, "notes": (lot["notes"] if lot else "") or "",
            "location": (lot["location"] if lot else "") or "", "portfolio": (lot["portfolio"] if lot else "") or ""}


def listing(v):
    """{items, summary} for this game: every item with its copies, and the totals (items, copies, value of the estimates)."""
    ensure(v)
    own = {}
    for r in v.conn.execute("SELECT card_id, SUM(qty) AS q FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND card_id LIKE 'custom:%' GROUP BY card_id", (v.user_id, v.game)):
        own[r["card_id"]] = r["q"]
    items = []
    for r in v.conn.execute("SELECT * FROM u.custom_items WHERE user_id=? AND game=? AND deleted=0 ORDER BY name COLLATE NOCASE", (v.user_id, v.game)):
        q = own.get(PREFIX + r["uuid"], 0)
        items.append({"uuid": r["uuid"], "id": PREFIX + r["uuid"], "name": r["name"], "set": r["set_name"] or DEFAULT_SET, "number": r["number"] or "", "category": r["category"] or "",
                      "labels": [x for x in (r["labels"] or "").split(",") if x], "estimate": r["estimate"], "copies": q})
    return {"items": items, "summary": summary(v)}


def summary(v):
    """{items, copies, estimate}: how many of your own items you hold in the open game and what YOUR ESTIMATES add up to (an estimate each x copies; they count in the total, labelled)."""
    ensure(v)
    n = c = 0
    est = 0.0
    for r in v.conn.execute("SELECT i.estimate, SUM(l.qty) AS q FROM u.custom_items i JOIN u.lots l ON l.card_id='custom:'||i.uuid AND l.user_id=i.user_id AND l.game=i.game "
                            "WHERE i.user_id=? AND i.game=? AND i.deleted=0 AND l.deleted=0 AND l.qty>0 GROUP BY i.uuid", (v.user_id, v.game)):
        n += 1
        c += r["q"] or 0
        est += (r["estimate"] or 0) * (r["q"] or 0)
    return {"items": n, "copies": c, "estimate": round(est, 2)}
