"""New Funko Pop! figures from the Funko fandom wiki, added to the Funko list.

The open hobbyDB list stops around 2020 and TCGplayer only knows part of what came after, so the newest Pops (2021 onward: Squid Game, Fallout, Wicked, Demon Slayer ...) are missing.  The wiki's
category pages ('Pop! Television', 'Pop! Animation' ...) hold a table of every Pop per line: number, name, picture, year, series.  They are read through the wiki's MediaWiki API only (its web pages
are behind a bot challenge and are never fetched), one request at a time with a pause, and kept in the Funko folder for a week so the daily rebuild does not ask the wiki again.

Only Pops released from MIN_YEAR on are added, and only when the list has nothing at that number in that line (the line's numbers are unique).  Multi-packs, rides, covers, mascots and the other
tables that count on their own are left out.  A row that cannot be read with confidence is skipped, never guessed.  The picture is the wiki's own file for that exact Pop, or none.  Network trouble changes nothing: the list is left as it is."""
import html
import json
import os
import re
import time

import requests

from . import funkovariants

API = "https://funko.fandom.com/api.php"
UA = "CollectEmAll/3 (collection app)"
TTL = 7 * 86400                                   # the pages are read again after a week
PAUSE = 1.0                                       # between two requests to the wiki
MIN_YEAR = 2021                                   # only Pops released from here on are added (older ones come from hobbyDB / TCGplayer, where a different spelling could double them)
SKIP_PAGES = {"Pop! Digital", "Pop! Custom", "Special Editions", "Pop! Trading Cards", "Pop! Comic Covers", "Pop! Die-Cast"}     # NFT / custom / non-figure lists, and lists that number each franchise on its own
_CATEGORY = {"Pop! Rides": "Pop! Rides", "Pop! Albums": "Pop! Albums", "Pop! Moments": "Pop! Moments", "Pop! Deluxe": "Pop! Deluxe", "Pop! Deluxe Moments": "Pop! Deluxe"}
_NO_PICTURE = re.compile(r"\b(?:exclusive|glow|chase|flocked|logo|sticker|icon|placeholder|coming soon|tba|tbd)\b", re.I)         # a badge or placeholder, not the Pop
_SUBLINE = re.compile(r"multi|\bpacks?\b|\brides?\b|\bcovers?\b|\bposters?\b|digital|deluxe|\bmoments?\b|\btown\b|mascots?|\bmls\b|\blegends?\b|super-?sized|\bvhs\b|\balbums?\b|die-?cast|wreck|special edition|raiders|\bsets?\b|bundle", re.I)
_NO_NAME = re.compile(r"^(?:tba|tbd|n/?a|\?+|unknown|none|-+)$", re.I)

_session = requests.Session()
_session.headers["User-Agent"] = UA


# ------------------------------------------------------------------------------------------------ the wiki (API only, cached)
def _api(**params):
    params["format"] = "json"
    r = _session.get(API, params=params, timeout=30)
    r.raise_for_status()
    return r.json()


def _cache_read(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _cache_write(path, obj):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        json.dump(obj, open(path, "w", encoding="utf-8"))
    except OSError:
        pass


def page_text(folder, title, cancel):
    """The wikitext of one wiki page, from the weekly cache or (once a week) from the API; the old copy when the wiki cannot be reached; '' when there is none."""
    path = os.path.join(folder, re.sub(r"[^A-Za-z0-9]+", "_", title) + ".json")
    old = _cache_read(path) or {}
    if old.get("text") and time.time() - old.get("at", 0) < TTL:
        return old["text"]
    if cancel.is_set():
        return old.get("text", "")
    try:
        text = (((_api(action="parse", page=title, prop="wikitext", redirects=1).get("parse") or {}).get("wikitext") or {}).get("*")) or ""
    except (requests.RequestException, ValueError):
        text = ""
    time.sleep(PAUSE)
    if text:
        _cache_write(path, {"at": time.time(), "text": text})
    return text or old.get("text", "")


def category_titles(folder, cancel):
    """The category pages listed on 'Pop! Categories' (so a new category is picked up by itself)."""
    text = page_text(folder, "Pop! Categories", cancel)
    return [t for t in dict.fromkeys(m.group(1).strip() for m in re.finditer(r"^\*\s*\[\[([^\]|#]+)", text, re.M)) if t not in SKIP_PAGES]


# ------------------------------------------------------------------------------------------------ reading the tables
def _clean(s):
    s = re.sub(r"<ref[^>]*?/>|<ref[^>]*>.*?</ref>|<!--.*?-->", "", s or "", flags=re.S)
    s = re.sub(r"\[\[(?:File|Image):[^\]]*\]\]", "", s, flags=re.I)
    s = re.sub(r"\[\[(?:[^\]|]*\|)?([^\]]*)\]\]", r"\1", s)
    s = re.sub(r"<br\s*/?>", " ", s, flags=re.I)
    s = re.sub(r"<[^>]+>|'{2,5}", "", s)
    return re.sub(r"\s+", " ", html.unescape(s)).strip()


_ATTR = re.compile(r"^\s*(?:[a-z-]+\s*=\s*(?:\"[^\"]*\"|'[^']*'|\S+)\s*)+\|(?!\|)")


def _table_rows(table):
    """[[(is_header, text), ...]] for each row of one wikitable's text (cell attributes such as rowspan are dropped; an empty cell stays as an empty cell so the columns keep their places)."""
    out = []
    for raw in re.split(r"\n\|-+", "\n" + table):
        cells = []
        for ln in raw.split("\n"):
            if ln[:1] in ("!", "|") and not ln.startswith(("|}", "|+", "{|")) and ln.strip():
                head = ln[0] == "!"
                for part in re.split(r"!!" if head else r"\|\|", ln[1:]):
                    cells.append([head, _ATTR.sub("", part)])
            elif cells and ln.strip():
                cells[-1][1] += "\n" + ln
        if cells:
            out.append(cells)
    return out


def _column(header, *words):
    for i, h in enumerate(header):
        if any(w in h.lower() for w in words):
            return i
    return -1


def _tables(text):
    """[(heading, caption, table text)] of a page's wikitables: the nearest '== heading ==' above each one and its '|+ caption'."""
    out, head = [], ""
    for part in re.split(r"(?m)^(={2,5}[^=\n].*?={2,5})\s*$", text):
        if re.fullmatch(r"={2,5}[^=\n].*?={2,5}", part.strip()):
            head = _clean(part.strip("= \n"))
            continue
        for table in re.findall(r"\{\|(.*?)\n\|\}", part, flags=re.S):
            cap = re.search(r"\n\|\+([^\n]*)", "\n" + table)
            out.append((head, _clean(cap.group(1)) if cap else "", table))
    return out


def _is_other_line(page, label):
    """True for a table of another numbering than the page's main list (multi-packs: the 'number' is the pack size; rides, covers, mascots, special editions ... count on their own)."""
    own = page.lower()
    return any(m.group(0).lower().rstrip("s") not in own for m in _SUBLINE.finditer(label))


def _notes(header, cells, texts):
    """(note, variants): the row's Notes / Variants / Exclusivity / Features cells as one text, and its '# item' variant list (the wiki's own words; 'Original' and 'N/A' are not variants)."""
    cols = [i for i, h in enumerate(header) if re.search(r"note|variant|exclusiv|feature", h, re.I) and i < len(cells)]
    note, variants = [], []
    for i in cols:
        raw = cells[i][1]
        items = [_clean(m) for m in re.findall(r"^\s*#\s*(.+)$", raw, re.M)]
        variants += [x for x in items if x and len(x) <= 60 and not funkovariants._ORIGINAL.match(x)]
        text = _clean(re.sub(r"^\s*#.*$", " ", raw, flags=re.M)) if items else texts[i]
        if text and len(text) <= 120 and not _NO_NAME.match(text) and not re.fullmatch(r"n/?a|none|-+", text, re.I):
            note.append(text)
    return " / ".join(note), list(dict.fromkeys(variants))


def parse_pops(page, text):
    """[{page, number, name, year, series, file}] for every Pop row of a category page's main list(s) whose number and name read cleanly."""
    pops = []
    for head, cap, table in _tables(text):
        if _is_other_line(page, head + " " + cap):
            continue
        header = []
        for cells in _table_rows(table):
            texts = [_clean(c[1]) for c in cells]
            num = re.fullmatch(r"#?\s*(\d{1,4})", texts[0]) if texts else None
            if not num:
                if len(cells) >= 3 and not header:
                    header = texts
                continue
            if len(cells) < 4 or not cells[1][0]:
                continue                                               # a variant row (no number / name cell of its own)
            name = texts[1]
            if not name or len(name) > 90 or _NO_NAME.match(name) or re.search(r"[|{}<>=�]", name):
                continue
            iy, isr, ii = _column(header, "year"), _column(header, "series", "franchise"), _column(header, "image", "picture")
            year = next((t for t in ([texts[iy]] if 0 <= iy < len(texts) else texts[2:]) if re.fullmatch(r"(?:19|20)\d\d", t)), "")
            series = texts[isr] if 0 <= isr < len(texts) else ""
            if len(series) > 60 or re.search(r"[|{}<>=�]", series):
                series = ""
            icell = cells[ii if 0 <= ii < len(cells) else 2][1]
            fm = re.search(r"\[\[(?:File|Image):([^|\]]+)", icell, re.I)
            all_files = [x.strip() for x in re.findall(r"\[\[(?:File|Image):([^|\]]+)", icell, re.I)]
            note, variants = _notes(header, cells, texts)
            pops.append({"page": page, "number": int(num.group(1)), "name": name, "year": year, "series": series, "file": fm.group(1).strip() if fm else "", "files": all_files, "note": note, "variants": variants})
    return pops


# ------------------------------------------------------------------------------------------------ is it already in the list?


def core(name):
    """A Pop's plain name for comparing: no size, no brackets, no letters but a-z and 0-9 ('Xenomorph 6"' and 'Xenomorph (Glow)' are both 'xenomorph')."""
    s = html.unescape(name or "")
    s = re.sub(r"\s*\d+\s*(?:\"|-?inch\b|in\b)", "", s)
    s = re.sub(r"\s*[\(\[].*?[\)\]]", "", s)
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def _keys(name):
    full = html.unescape(name or "")
    return {k for k in (core(full), core(full.split(": ")[-1])) if k}


class Known:
    """What the list already has, to tell whether a wiki Pop is in it: the numbered Pops (TCGplayer): each name with its number, and which line holds which number."""

    def __init__(self, conn):
        self.numbered, self.lines = set(), set()
        for cid, set_id, local_id, name in conn.execute("SELECT id, set_id, local_id, name FROM cards"):
            digits = re.sub(r"\D", "", local_id or "")
            if digits and not str(cid).startswith("hdb:"):
                self.numbered.update((k, int(digits)) for k in _keys(name))
                self.lines.add((set_id, int(digits)))


def is_known(pop, set_id, known):
    """The same name with the same number, or any entry at that number in the same line (a line's numbers are unique), is the Pop we already have.  The unnumbered hobbyDB entries stop around
    2020, so a wiki Pop from MIN_YEAR on is never one of them, even when a character of the same name is listed there."""
    keys = _keys(pop["name"])
    return not keys or any((k, pop["number"]) in known.numbered for k in keys) or (set_id, pop["number"]) in known.lines


# ------------------------------------------------------------------------------------------------ pictures
def pictures(folder, files, cancel):
    """{file name: direct address} for the wiki files asked for (50 per request; answers kept, so a file is asked for once).  Files the wiki does not have are left out."""
    path = os.path.join(folder, "files.json")
    known = _cache_read(path) or {}
    need = [f for f in dict.fromkeys(files) if f not in known]
    for i in range(0, len(need), 50):
        if cancel.is_set():
            break
        chunk = need[i:i + 50]
        try:
            d = (_api(action="query", titles="|".join("File:" + f for f in chunk), prop="imageinfo", iiprop="url").get("query") or {})
        except (requests.RequestException, ValueError):
            break
        norm = {n["to"]: n["from"] for n in d.get("normalized", [])}
        for pg in (d.get("pages") or {}).values():
            url = ((pg.get("imageinfo") or [{}])[0]).get("url") or ""
            asked = norm.get(pg.get("title"), pg.get("title") or "")
            if asked.startswith("File:"):
                known[asked[5:]] = url.split("/revision/")[0]          # the plain file address (ends in .png / .jpg, so the app shows it as it is)
        for f in chunk:
            known.setdefault(f, known.get(f.replace("_", " "), ""))
        time.sleep(PAUSE)
    _cache_write(path, known)
    return {f: known.get(f, "") or known.get(f.replace("_", " "), "") for f in files}


def picture_fits(pop):
    """The wiki file in a Pop's row is used only if it looks like that Pop's own picture: not a badge / placeholder, and no other Pop's number in its name ('Popheroes632.jpg' is #632 only)."""
    f = pop["file"]
    if not f or _NO_PICTURE.search(f) or not f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
        return False
    return all(int(n) == pop["number"] or 1990 <= int(n) <= 2030 for n in re.findall(r"(?<!\d)\d{3,4}(?!\d)", f))


# ------------------------------------------------------------------------------------------------ putting it together
def wiki_pops(gdir, cancel):
    folder = os.path.join(gdir, "funkowiki")
    pops = []
    for title in category_titles(folder, cancel):
        if cancel.is_set():
            break
        pops += parse_pops(title, page_text(folder, title, cancel))
    return pops


OLDEST = 2008                                                  # a Pop 'released' before this is a typo, not a Pop
LAST = {}                                                      # the counts of the last add_new run (the daily report reads them)


def _set_id(set_name):
    return "fd:" + re.sub(r"[^a-z0-9]+", "-", set_name.lower()).strip("-")


def second_source(pop, set_id, index, evidence):
    """Another allowed source that agrees the Pop exists: the same plain name in another line of the TCGplayer / hobbyDB lists, or a saved checker finding (games/funko/funkowiki/second_sources.json,
    {'<number> <name>': 'where it was found'}).  The wiki alone is one source."""
    base = funkovariants.base_key(pop["name"])
    if any(r["key"] == base for k, rs in index.by.items() if k[0] != set_id for r in rs):
        return "another line of our lists"
    return evidence.get(f"{pop['number']} {pop['name']}", "")


def new_pops(conn, pops, evidence=None):
    """-> (add, review): the wiki Pops the list lacks.  add = [(pop, set name)] with a real picture of their own AND a second agreeing source; review = [(pop, set name, what is missing)] the owner (or a
    checker with more sources) settles.  A Pop from MIN_YEAR on is lacking when the list has nothing at that number; an older one only when it also has no hobbyDB twin of that name in its line."""
    known, seen, add, review = Known(conn), set(), [], []
    index = funkovariants.Index(conn)
    evidence = evidence or {}
    files = [p["file"] for p in pops if picture_fits(p)]
    shared = {f for f in files if files.count(f) > 1}
    for p in pops:
        set_name = re.sub(r"^Pop!\s*", "", p["page"]).strip()
        key = (p["number"], core(p["name"]), p["series"].lower())
        year = int(p["year"]) if p["year"] else 0
        if key in seen or not OLDEST <= year <= time.gmtime().tm_year + 1:
            continue                                                   # listed twice (on two pages); an undated row or a year that cannot be right
        seen.add(key)
        sid = _set_id(set_name)
        if is_known(p, sid, known) or (year < MIN_YEAR and index.has_base(sid, p["name"])):
            continue
        missing = []
        if not picture_fits(p) or p["file"] in shared:
            missing.append("a picture of its own")
        if not second_source(p, sid, index, evidence):
            missing.append("a second source")
        if missing:
            review.append((p, set_name, " and ".join(missing)))
        else:
            add.append((p, set_name))
    return add, review


_KEYWORDS = {"Chase": r"chase", "Glow in the Dark": r"glow|gitd", "Flocked": r"flock", "Metallic": r"metallic", "Diamond": r"diamond", "Glitter": r"glitter", "Translucent": r"translucent",
             "Blacklight": r"black-?light", "Pearlescent": r"pearl", "Scented": r"scent", "Chrome": r"chrome"}


def variant_file(pop, item):
    """The wiki file that shows THIS variant: one file in the Pop's picture cell whose name carries every finish / chase word of the variant ('...-Red-Chase.jpg' for 'Chase - Red') and the Pop's own
    number or name; '' when no file or several files fit (a variant without finish words cannot be told from the picture)."""
    want = [k for k in funkovariants.tokens("", (), item, "") if k in _KEYWORDS]
    if not want:
        return ""
    name_words = [w for w in funkovariants.base_key(pop["name"]).split() if len(w) > 2][:2]
    fit = []
    for f in pop.get("files", []):
        low = re.sub(r"[ _]+", "-", f.lower())
        if not low.endswith((".png", ".jpg", ".jpeg", ".webp")) or re.search(r"logo|sticker|icon|placeholder|coming-soon|tba", low):
            continue
        if all(re.search(_KEYWORDS[k], low) for k in want) and (str(pop["number"]) in low or any(w in low for w in name_words)):
            fit.append(f)
    return fit[0] if len(fit) == 1 else ""


def variant_rows(conn, pops):
    """[(pop, set name, label)]: the wiki's listed variants ('# Original # Chase - Red') of Pops the list has, that the list lacks (same line, same plain name, marks not all there)."""
    index, out, seen = funkovariants.Index(conn), [], set()
    finishes = {x for x, _ in funkovariants._FIN}
    for p in pops:
        if not p["variants"] or not p["year"] or not OLDEST <= int(p["year"]) <= time.gmtime().tm_year + 1:
            continue
        set_name = re.sub(r"^Pop!\s*", "", p["page"]).strip()
        sid = _set_id(set_name)
        if not index.has_base(sid, p["name"]):
            continue                                                   # a Pop we lack is handled by new_pops; its variants follow once it is in
        stores = {k: v for k, v in funkovariants.tokens("", (), p["note"], "").items() if k not in finishes and k != funkovariants.GENERIC}
        for item in p["variants"]:
            own = funkovariants.tokens("", (), item, "")
            label = funkovariants.flat_label(item, {k: v for k, v in stores.items() if k not in own})
            probe = f"{p['name']} ({label})"
            key = (sid, p["number"], funkovariants.base_key(p["name"]), item.lower())
            if key in seen or index.has(sid, probe, funkovariants.tokens(probe, (), "", "")):
                continue
            seen.add(key)
            out.append((p, set_name, label, variant_file(p, item)))
    return out


def _insert(conn, put_set, pop, set_name, name, pic, slug_extra=""):
    sid = put_set(set_name)
    slug = re.sub(r"[^a-z0-9]+", "-", f"{set_name} {pop['number']} {pop['name']} {slug_extra}".lower()).strip("-")
    cur = conn.execute(
        "INSERT OR IGNORE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
        ("fw:" + slug, sid, str(pop["number"]), pop["number"], name, pic, _CATEGORY.get(pop["page"], "Pop! Vinyl"), "Standard", pop["series"],
         f"Released {pop['year']}." if pop["year"] else "", json.dumps({"normal": True}),
         json.dumps({"source": "funko.fandom.com", "page": pop["page"], "series": pop["series"], "year": pop["year"], "note": pop["note"] if not slug_extra else slug_extra}, ensure_ascii=False)))
    return cur.rowcount


def add_new(conn, gdir, put_set, cancel, day):
    """Add the Pops the wiki has and the list lacks (real picture + a second source), and the wiki's listed variants of Pops the list has; returns how many rows.  The rest is counted in LAST (and
    queued by queue_review).  Never raises: with the wiki down the list stays as it is."""
    LAST.clear()
    try:
        found = wiki_pops(gdir, cancel)
        evidence = _cache_read(os.path.join(gdir, "funkowiki", "second_sources.json")) or {}
        fresh, review = new_pops(conn, found, evidence)
        files = [p["file"] for p, _ in fresh if picture_fits(p)]
        pics = pictures(os.path.join(gdir, "funkowiki"), list(dict.fromkeys(files)), cancel)
        added = 0
        for p, set_name in fresh:
            pic = pics.get(p["file"]) or None
            if not pic:
                review.append((p, set_name, "a picture of its own"))
                continue
            added += _insert(conn, put_set, p, set_name, p["name"], pic)
        variants = 0
        vrows = variant_rows(conn, found)
        vfiles = [r[3] for r in vrows if r[3]]
        vshared = {f for f in vfiles if vfiles.count(f) > 1}                 # one picture for two variants is not either one's own
        vpics = pictures(os.path.join(gdir, "funkowiki"), list(dict.fromkeys(f for f in vfiles if f not in vshared)), cancel)
        for p, set_name, label, vfile in vrows:
            pic = (vpics.get(vfile) or None) if vfile and vfile not in vshared else None
            if pic:
                variants += _insert(conn, put_set, p, set_name, f"{p['name']} ({label})", pic, slug_extra=label)
            else:                                                            # a variant needs a real picture of ITS OWN, else it waits for review
                review.append(({**p, "name": f"{p['name']} ({label})", "variant": label, "base": p["name"]}, set_name, "no picture of this variant"))
        conn.commit()
        LAST.update({"added": added, "variants": variants, "review": review})
        return added + variants
    except Exception as e:  # noqa: BLE001 - an extra source: the rest of the list is fine without it today
        print("funko: wiki Pops not added:", str(e)[:80], flush=True)
        return 0


KIND = "funko_add"


def queue_review(game="funko"):
    """The wiki Pops that lack a picture or a second source wait on the owner's review list with what is missing (a yes adds the Pop as the wiki names it).  -> how many were queued"""
    from . import reviewlist
    n = 0
    for p, set_name, missing in LAST.get("review", []):
        item_id = f"{set_name} #{p['number']} {p['name']}"
        reviewlist.add_item(KIND, game, item_id, f'The Funko wiki lists "{p["name"]}" (#{p["number"]}, {set_name}, {p["year"]}) and we do not: it still needs {missing}. Add it as the wiki names it?',
                            before={"pop": p, "setName": set_name, "missing": missing}, source="Funko wiki (funko.fandom.com)")
        n += 1
    return n


def _settle(item, ans, value, ctx):
    """The owner's answer on a wiki Pop: yes = add it as the wiki names it, no = leave it out."""
    if ans == "no":
        return "left out"
    import sqlite3
    from .db import game_dir
    from .paths import release_data_dir
    b = item["before"] or {}
    p = b.get("pop") or {}
    conn = sqlite3.connect(os.path.join(game_dir((ctx or {}).get("data_dir") or release_data_dir(), item["game"]), "cards.db"), timeout=60)
    try:
        sid = _set_id(b.get("setName") or "Other")
        if not conn.execute("SELECT 1 FROM sets WHERE id=?", (sid,)).fetchone():
            return "nothing added: its line is not in the list"
        n = _insert(conn, lambda _name: sid, {**p, "name": p.get("base") or p["name"]}, b.get("setName") or "Other", p["name"], None, slug_extra=p.get("variant") or "")
        conn.commit()
    finally:
        conn.close()
    return "added" if n else "already in the list"


def _register():
    from . import reviewlist
    reviewlist.register(KIND, apply=_settle)


_register()
