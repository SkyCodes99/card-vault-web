"""Where the app keeps its settings and data.  Everything stays on this PC."""
import json
import os
import sys

def _config_base():
    """Settings live where each system expects them: %APPDATA% (Windows), ~/Library/Application Support (macOS), ~/.config (Linux)."""
    if os.environ.get("APPDATA"):
        return os.environ["APPDATA"]
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support")
    return os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")


CONFIG_DIR = os.path.join(_config_base(), "Pokemon Card Vault")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def default_data_dir():
    return os.path.join(os.path.expanduser("~"), "Pokemon Card Vault Data")


def load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg.setdefault("data_dir", default_data_dir())
    cfg.setdefault("image_quality", "low")
    cfg.setdefault("dim_missing", True)
    return cfg


def save_config(cfg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass
