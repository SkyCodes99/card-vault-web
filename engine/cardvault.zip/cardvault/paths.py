"""Where the app keeps its settings and data.  Everything stays on this PC."""
import json
import os
import shutil
import sys
import tempfile
import threading
import time

def _config_base():
    """Settings live where each system expects them: %APPDATA% (Windows), ~/Library/Application Support (macOS), ~/.config (Linux)."""
    if os.environ.get("APPDATA"):
        return os.environ["APPDATA"]
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support")
    return os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")


LEGACY_NAME = "Pokemon Card Vault"          # the program's name before it became "Collect Em All": folders are moved over, nothing is lost


def _move_legacy(old, new):
    if os.path.isdir(old) and not os.path.exists(new):
        try:
            os.rename(old, new)
            return True
        except OSError:
            return False
    return False


_move_legacy(os.path.join(_config_base(), LEGACY_NAME), os.path.join(_config_base(), "Collect Em All"))
CONFIG_DIR = os.path.join(_config_base(), "Collect Em All")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def default_data_dir():
    return os.path.join(os.path.expanduser("~"), "Collect Em All Data")


def release_data_dir():
    """The folder the RELEASE tools (card lists, search index, sealed classes) read from.  They must not trust the settings file for this: a test that forgot to isolate its settings once overwrote
    it with a temporary folder, and the next release would have published an empty card list to everybody.  CEA_DATA_DIR names the folder outright; otherwise it is the app's usual folder when that
    exists (else what the settings say).  A folder inside the system's temporary folder is refused: that is a test's folder, not the owner's."""
    import tempfile
    path = os.environ.get("CEA_DATA_DIR") or (default_data_dir() if os.path.isdir(default_data_dir()) else load_config()["data_dir"])
    here, temp = os.path.normcase(os.path.abspath(path)), os.path.normcase(os.path.abspath(tempfile.gettempdir()))
    if here == temp or here.startswith(temp + os.sep):
        raise SystemExit(f"The data folder {path} is inside the temporary folder - that is a test's folder, not yours. Name the real one: set CEA_DATA_DIR, or pass --data=<folder>.")
    return path


def _read_cfg(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg if isinstance(cfg, dict) else None
    except (OSError, ValueError):
        return None


def load_config():
    cfg = _read_cfg(CONFIG_FILE)
    if cfg is None:                                                  # damaged or gone (a power cut mid-save): the last good copy before the defaults
        cfg = _read_cfg(CONFIG_FILE + ".bak") or {}
    old_default = os.path.join(os.path.expanduser("~"), LEGACY_NAME + " Data")
    if os.path.normcase(os.path.abspath(cfg.get("data_dir") or old_default)) == os.path.normcase(old_default):
        if _move_legacy(old_default, default_data_dir()) or not os.path.isdir(old_default):
            cfg["data_dir"] = default_data_dir()
    cfg.setdefault("data_dir", default_data_dir())
    cfg.setdefault("image_quality", "low")
    cfg.setdefault("dim_missing", True)
    return cfg


def _in_temp(path):
    import tempfile
    here, temp = os.path.normcase(os.path.abspath(path)), os.path.normcase(os.path.abspath(tempfile.gettempdir()))
    return here == temp or here.startswith(temp + os.sep)


_SAVE_LOCK = threading.Lock()


def save_config(cfg):
    # A test's settings (a data folder inside the temporary folder) are never written over the owner's real settings file: a test that set APPDATA only after this module
    # was imported did exactly that (2026-11-13) - the desktop app then opened the test's folder and had updates switched off.
    if cfg.get("data_dir") and _in_temp(cfg["data_dir"]) and not _in_temp(CONFIG_FILE):
        print(f"Not saved: settings naming the temporary folder {cfg['data_dir']} are not written over {CONFIG_FILE}", file=sys.stderr)
        return
    with _SAVE_LOCK:                                                 # saves come from several threads (the engine, jobs, the window closing): one at a time
        target = CONFIG_FILE
        folder = os.path.dirname(target)
        tmp = None
        try:
            for _ in range(3):
                try:
                    text = json.dumps(dict(cfg), indent=2)           # a copy: another thread changing a setting mid-save used to stop the save ("dictionary changed size")
                    break
                except RuntimeError:
                    time.sleep(0.01)
            else:
                raise RuntimeError("the settings kept changing while being saved")
            os.makedirs(folder, exist_ok=True)
            # written beside it, then swapped in: an app closed mid-save left an EMPTY settings file (2026-11-14).  Its own name each time: two saves at once shared one file.
            fd, tmp = tempfile.mkstemp(prefix="config.", suffix=".new", dir=folder)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(text)
                f.flush()
                os.fsync(f.fileno())                                 # on the disk before it is swapped in: a power cut cannot leave a renamed-but-empty file
            if _read_cfg(target) is not None:                        # the last good settings, kept beside them (load_config falls back to it)
                try:
                    shutil.copyfile(target, target + ".bak")
                except OSError:
                    pass
            for attempt in range(8):
                try:
                    os.replace(tmp, target)
                    tmp = None
                    break
                except PermissionError:                              # Windows: another program has config.json open for a moment (a backup or search indexer, a second copy reading it)
                    if attempt == 7:
                        raise
                    time.sleep(0.05 * (attempt + 1))
        except Exception as e:  # noqa: BLE001 - a settings save never crashes the app; it is said, not swallowed
            print(f"Settings not saved to {target}: {e!r}", file=sys.stderr)
        finally:
            if tmp:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
