"""Sold history: copies the owner sold, with the sale price, date, where it was sold, and fees / shipping.

A sale takes the copies OUT of the collection (the stack shrinks, or the whole stack is marked removed - its quantity kept, so undo and sync only flip that mark - when all of it is sold - so every count, value, checklist tick and set completion drops by itself, they all read u.lots)
and writes ONE row per stack into u.sold.  The row is self-contained: it keeps what the card was called, its set, condition / grade, the price paid (each), the grading cost and the sale itself, so the history
and the profit totals stay right whatever happens to the card list later.  It syncs through the cloud snapshot like the grading rows (cloud/snapshot.py "sold", the sync stamp, conflicts.py).
    qty         how many copies (a stack of 5 can sell 2: the stack drops to 3 and the row says 2)
    price       sale price of ONE copy; fees = fees kept by the marketplace, shipping = what the shipping cost - both TOTALS for the row
    paid        price paid for ONE copy, None when it was never entered ("no cost recorded")
    grading_cost  total grading cost of those copies (grading.py)
Realised profit = price*qty - fees - shipping - (paid*qty + grading_cost), and only for rows that have a price paid; a row without one shows "no cost recorded" and is left out of the profit and cost totals.
Every sale is ONE undoable action through rowundo.track (lots + sealed + sold rows).  Prices are dollars here; the screens show them with money()."""
import datetime

from . import grading, pricepick, rowundo, sealedprice
from .db import new_uuid, now_iso

rowundo.TABLES.setdefault("sold", "uuid")

SCHEMA = ("CREATE TABLE IF NOT EXISTS u.sold("
          "uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, kind TEXT, card_id TEXT, name TEXT, set_name TEXT, number TEXT, variant TEXT, condition TEXT, graded INTEGER DEFAULT 0, "
          "grade_company TEXT, grade TEXT, cert TEXT, qty INTEGER, paid REAL, grading_cost REAL DEFAULT 0, price REAL, fees REAL DEFAULT 0, shipping REAL DEFAULT 0, "
          "sold_on TEXT, place TEXT, purchased TEXT, notes TEXT, lot_uuid TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0)",
          "CREATE INDEX IF NOT EXISTS u.sold_day ON sold(user_id, sold_on)")
# the columns that travel in a snapshot (everything but the owner / game, which the receiving device knows)
COLS = ("kind", "card_id", "name", "set_name", "number", "variant", "condition", "graded", "grade_company", "grade", "cert", "qty", "paid", "grading_cost", "price", "fees", "shipping",
        "sold_on", "place", "purchased", "notes", "lot_uuid", "updated_at", "deleted")


class SoldError(ValueError):
    pass


def ensure(v):
    for sql in SCHEMA:
        v.conn.execute(sql)


def _money(x, what, required=False):
    if x in (None, ""):
        if required:
            raise SoldError(f"Type {what}.")
        return 0.0
    try:
        c = float(x)
    except (TypeError, ValueError):
        raise SoldError(f"{what[0].upper() + what[1:]} has to be a number.")
    if c < 0:
        raise SoldError(f"{what[0].upper() + what[1:]} cannot be below zero.")
    return round(c, 4)


def _day(x):
    s = str(x or "").strip()[:10]
    if not s:
        return datetime.date.today().isoformat()
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        raise SoldError("Type the date as year-month-day, like 2026-11-10.")


# ------------------------------------------------------------------------------------------------ what can be sold
def _lot_row(v, ref):
    """A lot by its id (number) or uuid (text); None when it is not this person's, not this game's or already gone."""
    key = "id" if isinstance(ref, int) or str(ref).isdigit() else "uuid"
    r = v.conn.execute(f"SELECT * FROM u.lots WHERE {key}=? AND user_id=? AND game=? AND deleted=0 AND qty>0", (ref, v.user_id, v.game)).fetchone()
    return r


def _takes(v, items):
    """items -> [{kind, row, n, price}]: which stacks the sale takes copies from.  {lot: id|uuid, qty} one stack; {card: card id, qty} that card's copies, oldest stack first; {sealed: uuid, qty}.
    A missing qty means all of the stack (all of the card's copies).  Asking for more than is owned is refused in plain words, before anything is written."""
    left, out = {}, []
    for it in items or []:
        qty = it.get("qty")
        qty = None if qty in (None, "") else int(qty)
        if qty is not None and qty < 1:
            raise SoldError("Sell at least one copy.")
        price = _money(it.get("price"), "the sale price of each copy", required=True)
        if it.get("sealed"):
            r = v.conn.execute("SELECT * FROM u.sealed WHERE uuid=? AND user_id=? AND game=? AND deleted=0 AND qty>0", (it["sealed"], v.user_id, v.game)).fetchone()
            rows, kind = ([r] if r else []), "sealed"
        elif it.get("lot") not in (None, ""):
            r = _lot_row(v, it["lot"])
            rows, kind = ([r] if r else []), "card"
        elif it.get("card"):
            rows, kind = [r for r in v.lots_for(it["card"]) if r["qty"] > 0], "card"
        else:
            raise SoldError("Pick what was sold.")
        if not rows:
            raise SoldError("That copy is not in your collection any more.")
        want = qty if qty is not None else sum(left.setdefault((kind, r["uuid"]), r["qty"]) for r in rows)
        have = sum(left.setdefault((kind, r["uuid"]), r["qty"]) for r in rows)
        if want > have:
            name = rows[0]["name"] if kind == "sealed" else ((v.card_basic(rows[0]["card_id"]) or {}).get("name") or rows[0]["card_id"])
            raise SoldError(f"You only have {have} of {name} to sell.")
        for r in rows:
            n = min(want, left[(kind, r["uuid"])])
            if n < 1:
                continue
            left[(kind, r["uuid"])] -= n
            want -= n
            out.append({"kind": kind, "row": r, "n": n, "price": price})
    if not out:
        raise SoldError("Pick what was sold.")
    return out


def preview(v, items):
    """What the 'Mark sold' window shows for the picked things: name, how many are owned, what one is worth now (to start the price box with), what was paid."""
    out = []
    for it in items or []:
        try:
            takes = _takes(v, [{**it, "price": 0}])
        except SoldError:
            continue
        r0 = takes[0]
        have = sum(t["row"]["qty"] for t in takes)
        if r0["kind"] == "sealed":
            p = sealedprice.price_for(v, r0["row"]["name"])
            out.append({"ref": {"sealed": r0["row"]["uuid"]}, "name": r0["row"]["name"], "sub": "Sealed product", "owned": have, "now": p["price"] if p else None, "paid": r0["row"]["paid"], "qty": r0["row"]["qty"]})
            continue
        row = r0["row"]
        c = v.card_basic(row["card_id"]) or {}
        now = pricepick.copy_price(v, row["card_id"], row["graded"], row["grade_company"], row["grade"])
        ref = {"lot": row["uuid"]} if it.get("lot") not in (None, "") else {"card": row["card_id"]}
        sub = " · ".join(p for p in (c.get("set_name") or "", row["variant"] or "", f"{row['grade_company']} {row['grade']}".strip() if row["graded"] else (row["condition"] or "")) if p)
        paid = {t["row"]["purchase_price"] for t in takes}
        out.append({"ref": ref, "name": c.get("name") or row["card_id"], "sub": sub, "owned": have, "now": now, "paid": paid.pop() if len(paid) == 1 else None,
                    "qty": row["qty"] if ref.get("lot") else have})
    return out


def _share(total, parts):
    """Split `total` over rows in proportion to `parts` (equally when they are all zero), to the cent, the last row taking the rounding."""
    if not total:
        return [0.0] * len(parts)
    s = sum(parts)
    shares = [total * p / s for p in parts] if s else [total / len(parts)] * len(parts)
    out = [round(x, 2) for x in shares]
    out[-1] = round(total - sum(out[:-1]), 2)
    return out


# ------------------------------------------------------------------------------------------------ the action
def mark(v, items, day="", place="", fees=0, shipping=0, notes=""):
    """Sell copies.  items = [{lot|card|sealed, qty, price (each)}]; fees and shipping are the TOTALS for the whole sale (shared over the rows by what each sold for).
    -> {sold: copies, rows: stacks, revenue}.  ONE undo puts every copy back and removes the history rows."""
    ensure(v)
    grading.ensure(v)
    when, fees, shipping = _day(day), _money(fees, "the fees"), _money(shipping, "the shipping")
    place = str(place or "").strip()[:80]
    notes = str(notes or "").strip()[:300]
    takes = _takes(v, items)
    gross = [t["price"] * t["n"] for t in takes]
    fee_part, ship_part = _share(fees, gross), _share(shipping, gross)
    cards = sorted({t["row"]["card_id"] for t in takes if t["kind"] == "card"})
    seals = [t["row"]["uuid"] for t in takes if t["kind"] == "sealed"]
    gcost = grading.lot_costs(v)
    specs = [("sold", "user_id=? AND game=?", (v.user_id, v.game))]
    if cards:
        specs.append(("lots", f"user_id=? AND game=? AND card_id IN ({','.join('?' * len(cards))})", (v.user_id, v.game, *cards)))
    if seals:
        specs.append(("sealed", f"user_id=? AND game=? AND uuid IN ({','.join('?' * len(seals))})", (v.user_id, v.game, *seals)))
    n_all = sum(t["n"] for t in takes)

    def run():
        ts = now_iso()
        for t, fe, sh in zip(takes, fee_part, ship_part):
            r, n = t["row"], t["n"]
            if t["kind"] == "sealed":
                v.conn.execute("UPDATE u.sealed SET qty=CASE WHEN qty-?<=0 THEN qty ELSE qty-? END, deleted=CASE WHEN qty-?<=0 THEN 1 ELSE deleted END, updated_at=? WHERE uuid=?", (n, n, n, ts, r["uuid"]))
                row = dict(kind="sealed", card_id="", name=r["name"], set_name="Sealed product", number="", variant="", condition="", graded=0, grade_company="", grade="", cert="",
                           paid=r["paid"], grading_cost=0.0, purchased=r["purchased"] or "", lot_uuid=r["uuid"])
            else:
                v.conn.execute("UPDATE u.lots SET qty=CASE WHEN qty-?<=0 THEN qty ELSE qty-? END, deleted=CASE WHEN qty-?<=0 THEN 1 ELSE deleted END, updated_at=? WHERE id=?", (n, n, n, ts, r["id"]))
                c = v.card_basic(r["card_id"]) or {}
                row = dict(kind="card", card_id=r["card_id"], name=c.get("name") or r["card_id"], set_name=c.get("set_name") or "", number=str(c.get("local_id") or c.get("number") or ""),
                           variant=r["variant"] or "", condition=r["condition"] or "", graded=r["graded"] or 0, grade_company=r["grade_company"] or "", grade=r["grade"] or "", cert=r["cert"] or "",
                           paid=r["purchase_price"], grading_cost=round(gcost.get(r["id"], 0.0) * n / r["qty"], 2), purchased=r["purchased"] or "", lot_uuid=r["uuid"])
            row.update(qty=n, price=t["price"], fees=fe, shipping=sh, sold_on=when, place=place, notes=notes, updated_at=ts, deleted=0)
            v.conn.execute(f"INSERT INTO u.sold(uuid,user_id,game,{','.join(row)}) VALUES(?,?,?,{','.join('?' * len(row))})", (new_uuid(), v.user_id, v.game, *row.values()))
    rowundo.track(v, f"Sold {n_all} cop{'ies' if n_all != 1 else 'y'}" + (f" ({place})" if place else ""), specs, run)
    return {"sold": n_all, "rows": len(takes), "revenue": round(sum(gross), 2)}


# ------------------------------------------------------------------------------------------------ fixing a recorded sale
def _sold_row(v, uuid):
    r = v.conn.execute("SELECT * FROM u.sold WHERE uuid=? AND user_id=? AND deleted=0", (uuid, v.user_id)).fetchone() if uuid else None
    if not r:
        raise SoldError("That sale was not found.")
    return r


def edit(v, uuid, changes):
    """Correct a recorded sale.  changes may hold price (each), fees, shipping (totals for the row), day, place, notes, paid (each; empty = no cost recorded).
    The copies sold do not change (remove the sale and mark it again for that).  ONE undo."""
    ensure(v)
    r = _sold_row(v, uuid)
    ch = changes or {}
    sets = {}
    if "price" in ch:
        sets["price"] = _money(ch["price"], "the sale price of each copy", required=True)
    if "fees" in ch:
        sets["fees"] = _money(ch["fees"], "the fees")
    if "shipping" in ch:
        sets["shipping"] = _money(ch["shipping"], "the shipping")
    if "paid" in ch:
        sets["paid"] = None if ch["paid"] in (None, "") else _money(ch["paid"], "the price paid")
    if "day" in ch:
        sets["sold_on"] = _day(ch["day"])
    if "place" in ch:
        sets["place"] = str(ch["place"] or "").strip()[:80]
    if "notes" in ch:
        sets["notes"] = str(ch["notes"] or "").strip()[:300]
    if not sets:
        return {"changed": 0}

    def run():
        v.conn.execute(f"UPDATE u.sold SET {','.join(f'{c}=?' for c in sets)}, updated_at=? WHERE uuid=?", (*sets.values(), now_iso(), uuid))
    rowundo.track(v, f"Edited the sale of {r['name']}", [("sold", [uuid])], run)
    return {"changed": 1}


def remove(v, uuid, restore=False):
    """Remove a recorded sale (it leaves the history and the profit totals).  restore: the copies come back into the collection - the same stack, which comes back if it had gone.  ONE undo."""
    ensure(v)
    r = _sold_row(v, uuid)
    specs = [("sold", [uuid])]
    back = None
    if restore:
        table = "sealed" if r["kind"] == "sealed" else "lots"
        back = v.conn.execute(f"SELECT * FROM u.{table} WHERE uuid=? AND user_id=?", (r["lot_uuid"], v.user_id)).fetchone() if r["lot_uuid"] else None
        if not back:
            raise SoldError("The copies cannot be put back: their stack is no longer on this device. Remove the sale without putting them back, then add the copies again.")
        specs.append((table, [back[rowundo.TABLES[table]]]))

    def run():
        ts = now_iso()
        v.conn.execute("UPDATE u.sold SET deleted=1, updated_at=? WHERE uuid=?", (ts, uuid))
        if back is not None:
            table, key = ("sealed", "uuid") if r["kind"] == "sealed" else ("lots", "id")
            n = r["qty"] or 0
            v.conn.execute(f"UPDATE u.{table} SET qty=CASE WHEN deleted=1 THEN ? ELSE qty+? END, deleted=0, updated_at=? WHERE {key}=?", (n, n, ts, back[key]))
    rowundo.track(v, f"Removed the sale of {r['name']}" + (" (copies put back)" if restore else ""), specs, run)
    return {"removed": 1, "restored": r["qty"] if restore else 0}


# ------------------------------------------------------------------------------------------------ the numbers
def figures(r):
    """One sold row -> its money: revenue, fees (fees + shipping), cost (None without a price paid), profit (None without a cost)."""
    qty = r["qty"] or 0
    revenue = round((r["price"] or 0) * qty, 2)
    fees = round((r["fees"] or 0) + (r["shipping"] or 0), 2)
    cost = None if r["paid"] is None else round(r["paid"] * qty + (r["grading_cost"] or 0), 2)
    return {"revenue": revenue, "fees": fees, "cost": cost, "profit": None if cost is None else round(revenue - fees - cost, 2)}


def totals(rows):
    """rows (with the figures() keys) -> the totals.  Cost and profit only count the sales that have a price paid; noCost says how many do not."""
    costed = [x for x in rows if x["cost"] is not None]
    return {"sales": len(rows), "copies": sum(x["qty"] for x in rows), "revenue": round(sum(x["revenue"] for x in rows), 2), "fees": round(sum(x["fees"] for x in rows), 2),
            "cost": round(sum(x["cost"] for x in costed), 2), "profit": round(sum(x["profit"] for x in costed), 2), "costed": len(costed), "noCost": len(rows) - len(costed)}


def listing(v, q="", game="", start="", end="", place=""):
    """{rows, totals, games, places} for the Sold history page: every sold stack of this person (all games unless one is picked), newest first, filtered by text, game, dates and place."""
    ensure(v)
    from .games import game_by_id
    mine = list(v.conn.execute("SELECT * FROM u.sold WHERE user_id=? AND deleted=0 ORDER BY sold_on DESC, rowid DESC", (v.user_id,)))
    games = sorted({r["game"] for r in mine})
    places = sorted({r["place"] for r in mine if r["place"]}, key=str.lower)
    q = (q or "").strip().lower()
    rows = []
    for r in mine:
        if game and r["game"] != game:
            continue
        if start and (r["sold_on"] or "") < start[:10]:
            continue
        if end and (r["sold_on"] or "") > end[:10]:
            continue
        if place and (r["place"] or "").lower() != place.lower():
            continue
        if q and q not in " ".join(str(r[k] or "") for k in ("name", "set_name", "number", "variant", "place", "notes", "card_id", "grade_company", "grade")).lower():
            continue
        f = figures(r)
        rows.append({"id": r["uuid"], "game": r["game"], "kind": r["kind"], "card_id": r["card_id"], "name": r["name"], "set": r["set_name"], "number": r["number"], "variant": r["variant"],
                     "condition": r["condition"], "graded": bool(r["graded"]), "grade": f"{r['grade_company']} {r['grade']}".strip() if r["graded"] else "", "qty": r["qty"],
                     "paid": r["paid"], "gradingCost": r["grading_cost"] or 0.0, "price": r["price"], "shipping": r["shipping"] or 0.0, "fee": r["fees"] or 0.0, "day": r["sold_on"],
                     "place": r["place"] or "", "notes": r["notes"] or "", "noCost": f["cost"] is None, **f})
    return {"rows": rows, "totals": totals(rows), "games": [{"id": g, "name": game_by_id(g).name} for g in games], "places": places}


def realised(v, game=None):
    """The totals of every sale of this person in this game (for the Profit view); None before anything was sold.  game: another game's id, or "" for every game."""
    ensure(v)
    game = v.game if game is None else game
    rows = [{**figures(r), "qty": r["qty"]} for r in v.conn.execute("SELECT * FROM u.sold WHERE user_id=? AND deleted=0" + (" AND game=?" if game else ""),
                                                                    (v.user_id, game) if game else (v.user_id,))]
    return totals(rows) if rows else None
