"""The weekly value email's CONTENT (roadmap "Weekly value email"): a short, plain note with what your collection is worth, the change over the week, the biggest movers and the
new releases for the games you collect.  Built here on the device from calls the app already has (the saved daily values, marketmovers, releasecal); the account server only
sends it (docs/server_requests.md), because the server cannot read your collection.  Nothing is written, no email address is known or used here.
compose() is pure (text from numbers) so it is easy to test; build() gathers the numbers."""
import datetime

from . import currency, marketmovers, releasecal

MOVERS, RELEASES = 3, 5
NEW_DAYS, SOON_DAYS = 7, 21
SUBJECT = "Your collection this week"


def _values(conn, user_id, base_day):
    """(value now, value a week ago or None) over every game saved: each game's newest saved day, and its newest day on or before base_day.  The change only counts games that have both."""
    seen = {}
    for game, day, usd in conn.execute("SELECT game, day, total_usd FROM u.snapshots WHERE user_id=? ORDER BY day", (user_id,)):
        g = seen.setdefault(game, {"now": 0.0, "base": None})
        g["now"] = usd or 0.0
        if day <= base_day:
            g["base"] = usd or 0.0
    both = [g for g in seen.values() if g["base"] is not None]
    return sum(g["now"] for g in seen.values()), (round(sum(g["now"] - g["base"] for g in both), 2) if both else None)


def _movers(v, today):
    w = marketmovers.movers(v, None, today=today)["windows"]["7"]
    pick = lambda rows: [{"name": r["name"], "game": r["game_name"], "pct": r["pct"], "new": r["new"]} for r in rows[:MOVERS]]
    return pick(w["rises"]), pick(w["drops"])


def _releases(v, today):
    """Sets, sealed products and toy lines with an exact day: out in the last week, and coming in the next three weeks (the release calendar's own dates)."""
    out, soon = [], []
    for gid in releasecal.collected_games(v):
        for it in releasecal.game_items(v.data_dir, gid):
            if it["precision"] != "day":
                continue
            days = (datetime.date.fromisoformat(it["date"]) - today).days
            row = {"name": it["name"], "game": it["game_name"], "date": it["date"]}
            if -NEW_DAYS <= days <= 0:
                out.append(row)
            elif 0 < days <= SOON_DAYS:
                soon.append(row)
    key = lambda r: (r["date"], r["name"].lower())
    return sorted(out, key=key, reverse=True)[:RELEASES], sorted(soon, key=key)[:RELEASES]


def _day(iso):
    d = datetime.date.fromisoformat(iso)
    return f"{d.strftime('%b')} {d.day}"


def compose(value, change, ups, downs, out_now, soon, fmt=currency.fmt):
    """Plain, short, kid-simple wording.  change = None when there is no value from a week ago to compare with."""
    lines = [SUBJECT, "", f"Your cards are worth {fmt(value)} right now."]
    if change is not None:
        lines.append("That is the same as a week ago." if abs(change) < 0.005 else f"That is {fmt(abs(change))} {'more' if change > 0 else 'less'} than a week ago.")
    if ups or downs:
        lines += ["", "Biggest price changes this week"]
        lines += [f"- {r['name']} ({r['game']}): up {r['pct']:g}% to {fmt(r['new'])}" for r in ups]
        lines += [f"- {r['name']} ({r['game']}): down {abs(r['pct']):g}% to {fmt(r['new'])}" for r in downs]
    if out_now or soon:
        lines += ["", "New releases for your games"]
        lines += [f"- Out now: {r['name']} ({r['game']}), {_day(r['date'])}" for r in out_now]
        lines += [f"- Coming soon: {r['name']} ({r['game']}), {_day(r['date'])}" for r in soon]
    lines += ["", "You get this because you turned on the weekly email in Collect Em All. To stop it, open Settings, Account & security, Weekly email, and switch it off."]
    return "\n".join(lines)


def build(svc, today=None):
    """-> {"week": "2026-W46", "subject", "text"} for the signed-in account, or None when there is nothing in the collection to write about."""
    v = svc.vault
    if v is None:
        return None
    today = today or datetime.date.today()
    value, change = _values(v.conn, v.user_id, (today - datetime.timedelta(days=7)).isoformat())
    if value <= 0:
        return None
    ups, downs = _movers(v, today)
    out_now, soon = _releases(v, today)
    y, w, _ = today.isocalendar()
    return {"week": f"{y}-W{w:02d}", "subject": SUBJECT, "text": compose(value, change, ups, downs, out_now, soon)}
