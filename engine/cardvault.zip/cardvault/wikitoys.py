"""Toy lines that have no shop feed, built from the fan wikis' product lists (MediaWiki API, CC BY-SA text) and, for Beyblade, a collector's spreadsheet.

  beyblade   Beyblade X - every Takara Tomy release (Basic BX / Unique UX / Custom CX / limited and prize releases) and every Hasbro release, plus the event gear stickers.  The kind of product
             (starter, booster, random booster, set, stadium, launcher, parts ...), the blade(s) inside, the line, year, exclusive-to and variant (Metal Coat ...) are filters.
  bakugan    Bakugan - every Bakugan and every attachment (Battle Gear, Super Assault, Mobile Assault, BakuNano, Mechtogan, Baku-Gear ...), one entry per attribute ("type": Pyrus, Aquos ...), by season and wave.

Only addresses of the pictures are stored (they stay on the wikis' servers).  Network trouble never empties a list: when a wiki cannot be read the list that is already there is kept."""
import json
import os
import re
import time
from urllib.parse import quote, urlencode

from . import sync
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

BEY_WIKI = "beyblade.fandom.com"
BAKU_WIKI = "bakugan.fandom.com"
_DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_MONTHS = {m: i + 1 for i, m in enumerate(["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"])}
_MON3 = {k[:3]: v for k, v in _MONTHS.items()}


# ------------------------------------------------------------------------------------------------------------------ wiki helpers
def _api(host, **params):
    params["format"] = "json"
    return sync._get(f"https://{host}/api.php?{urlencode(params)}") or {}


def wikitext(host, title):
    d = _api(host, action="parse", page=title, prop="wikitext", redirects=1)
    return ((d.get("parse") or {}).get("wikitext") or {}).get("*") or ""


def page_batches(host, titles, with_text=False, size=40):
    """{title: {"text": wikitext or None, "image": thumbnail address or None}} for pages (redirects followed, the asked-for title is the key)."""
    out = {}
    titles = list(dict.fromkeys(t for t in titles if t))
    for i in range(0, len(titles), size):
        chunk = titles[i:i + size]
        p = dict(action="query", titles="|".join(chunk), redirects=1, prop="pageimages" + ("|revisions" if with_text else ""), piprop="thumbnail", pithumbsize=420)
        if with_text:
            p.update(rvprop="content", rvslots="main")
        d = (_api(host, **p).get("query") or {})
        back = {}
        for n in d.get("normalized", []):
            back[n["to"]] = n["from"]
        redirect = {r["from"]: r["to"] for r in d.get("redirects", [])}
        to_ask = {}
        for t in chunk:
            to_ask.setdefault(redirect.get(t, t.replace("_", " ")), []).append(t)
        for pg in (d.get("pages") or {}).values():
            keys = to_ask.get(pg.get("title"), []) or [pg.get("title")]
            rev = (pg.get("revisions") or [{}])[0].get("slots", {}).get("main", {}).get("*") if with_text else None
            img = (pg.get("thumbnail") or {}).get("source")
            for k in keys:
                out[k] = {"text": rev, "image": img}
    return out


def strip_markup(s):
    s = re.sub(r"<!--.*?-->", "", s or "", flags=re.S)
    s = re.sub(r"<ref[^>]*?/>|<ref[^>]*>.*?</ref>", "", s, flags=re.S)
    s = re.sub(r"\[\[(?:File|Image|Category):[^\]]*\]\]", "", s, flags=re.I)
    s = re.sub(r"\{\{[^{}]*\}\}", "", s)
    s = re.sub(r"\[\[([^\]|]*\|)?([^\]]*)\]\]", r"\2", s)
    s = re.sub(r"\[https?://\S+\s+([^\]]+)\]", r"\1", s)
    s = re.sub(r"'{2,5}", "", s)
    s = re.sub(r"<br\s*/?>", " | ", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    return re.sub(r"\s+", " ", s.replace("&nbsp;", " ").replace("&amp;", "&")).strip(" |")


def first_link(s):
    m = re.search(r"\[\[([^\]|#]+)(?:\|[^\]]*)?\]\]", re.sub(r"\[\[(?:File|Image|Category):[^\]]*\]\]", "", s or "", flags=re.I))
    return m.group(1).strip() if m else ""


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")


def parse_date(s):
    """'July 15th, 2023 (CoroCoro ...)' / 'May 2024' / '2025' -> ISO date (day 01 when the wiki gives only a month); '' when none."""
    t = strip_markup(s)
    m = re.search(r"\b([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b", t)
    if m and m.group(1)[:3].lower() in _MON3:
        return f"{m.group(3)}-{_MON3[m.group(1)[:3].lower()]:02d}-{int(m.group(2)):02d}"
    m = re.search(r"\b([A-Za-z]{3,9})\.?\s+(\d{4})\b", t)
    if m and m.group(1)[:3].lower() in _MON3:
        return f"{m.group(2)}-{_MON3[m.group(1)[:3].lower()]:02d}-01"
    m = re.search(r"\b(20\d\d|19\d\d)\b", t)
    return f"{m.group(1)}-01-01" if m else ""


_CELL_ATTR = re.compile(r"^\s*(?:[a-z-]+=\"[^\"]*\"\s*)+\|(?!\|)")


def table_rows(text):
    """[(section, group, [cells])] of every wikitable row: section = the == heading ==, group = the last full-width sub-heading row inside the table."""
    out, section, group = [], "", ""
    for block in re.split(r"(?m)^(==[^=\n].*?==)\s*$", text):
        if re.fullmatch(r"==[^=\n].*?==", block.strip()):
            section, group = strip_markup(block.strip("= \n")), ""
            continue
        for raw in re.split(r"\n\|-", block):
            cells, header = [], ""
            for ln in raw.split("\n"):
                if ln.startswith("! colspan"):
                    header = strip_markup(ln.split("|", 1)[1]) if "|" in ln else ""
                elif ln.startswith("|") and not ln.startswith(("|}", "|+", "|-")):
                    c = ln[1:]
                    for part in (c.split("||") if "||" in c else [c]):
                        cells.append(_CELL_ATTR.sub("", part).strip())
                elif cells and ln and not ln.startswith(("{|", "!", "}")):
                    cells[-1] += " " + ln.strip()
            if header:
                group = header
            elif cells:
                out.append((section, group, cells))
    return out


def _kv(gdir, name, ttl_days, keys, fetch):
    """{key: value} kept in the game folder.  Only keys not yet known are fetched (fetch(list of keys) -> dict with an entry for every key); after ttl_days everything is read again,
    and when the wiki cannot be reached the old copy is kept."""
    path = os.path.join(gdir, name)
    try:
        obj = json.load(open(path, encoding="utf-8"))
    except (OSError, ValueError):
        obj = {}
    data, at = dict(obj.get("data") or {}), obj.get("at") or 0
    stale = None
    if at < time.time() - ttl_days * 86400 and data:
        stale, data = data, {}
    need = [k for k in dict.fromkeys(keys) if k and k not in data]
    if need:
        try:
            data.update(fetch(need))
            at = time.time() if stale is not None or not at else at
        except Exception as e:  # noqa: BLE001 - keep what we had when the wiki is down
            print(f"{name}: wiki not reachable, using the saved copy ({str(e)[:80]})", flush=True)
            if stale is not None:
                data = {**stale, **data}
        os.makedirs(gdir, exist_ok=True)
        json.dump({"at": at or time.time(), "data": data}, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    return data


def _put_set(conn, sid, name, serie, release=""):
    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, name, serie, release, 0, 0))


def _put_card(conn, cid, sid, local_id, sort_key, name, image, category, rarity, types, description, price, price_kind, tags, ext, extra=None):
    raw = {"tags": tags, "ext": {k: v for k, v in ext.items() if v}, "source": "wiki"}
    raw.update(extra or {})
    conn.execute(
        "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
        (cid, sid, local_id, sort_key, name, image or "", category, rarity, types, description[:600], price, price_kind if price is not None else None,
         time.strftime("%Y-%m-%d") if price is not None else None, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))


def _finish(conn, game_id):
    conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id)")
    conn.execute("DELETE FROM sets WHERE id LIKE ? AND NOT EXISTS (SELECT 1 FROM cards WHERE set_id=sets.id)", (game_id + ":%",))
    conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
    conn.commit()
    try:
        from . import gamefacets
        gamefacets.ensure(conn, game_id, force=True)
    except Exception as e:  # noqa: BLE001
        print(f"{game_id}: filters not built ({str(e)[:80]})", flush=True)
    return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]


# ================================================================================================================== Beyblade X
def _bey_sheet():
    try:
        return json.load(open(os.path.join(_DATA, "beyblade_sheet.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return {"blades": {}, "contents": {}, "stickers": []}


_HASBRO_NAMES = {"Helm Knight": "Knight Shield", "Scythe Incendio": "Hell's Scythe", "Wand Wizard": "Wizard Rod", "Steel Samurai": "Samurai Saber"}


def _squash(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


_COLLAB = (("Marvel", r"iron man|thanos|spider-?man|venom|captain america|red hulk|hulk|black panther|thor\b"),
           ("Star Wars", r"skywalker|darth|vader|mandalorian|moff|obi-?wan|grievous|chewbacca|storm ?trooper|yoda|grogu|ahsoka"),
           ("Transformers", r"optimus|megatron|starscream|bumblebee|transformers"),
           ("Jurassic dinosaurs", r"spinosaurus|quetzalcoatlus|t\. ?rex|mosasaurus|jurassic"),
           ("Football clubs", r"barcelona|giants|frontale|yokohama fc|antlers|ventforet"),
           ("Classic Beyblade (X-Over)", r"x-over|dranzer ?spiral|driger ?slash|l-drago|dragoon ?storm|storm ?pegasis|victory ?valkyrie|xeno ?x-?calibur|draciel ?shield"))


def _bey_kind(name, group=""):
    n = name.lower()
    g = group.lower()
    if re.search(r"random booster", n):
        return "Random Booster"
    if re.search(r"multipack", n) or "multipack" in g:
        return "Multipack set"
    if re.search(r"\bstarter\b", n) or "starter" in g or re.search(r"dran deck starter", n):
        return "Starter"
    if re.search(r"\bbooster\b", n) or (g.endswith("booster packs") and not re.search(r"set", n)):
        return "Booster"
    if "dual pack" in g:
        return "Dual pack"
    if re.search(r"stadium|beystadium", n) or "stadium" in g:
        return "Stadium"
    if re.search(r"launcher|grip", n):
        return "Launcher & grip"
    if re.search(r"\bcase\b|\bpass\b|gear case|storage|bag\b|sticker|tool|wrench|belt", n) or "accessor" in g:
        return "Accessory"
    if re.search(r"\bset\b|package|pack\b|deck|kick off|collection", n) or "set" in g or "pack" in g:
        return "Set / pack"
    return "Other"


def _bey_line(code, section, group, maker):
    c = (code or "").upper()
    if maker == "Hasbro":
        g = group.lower()
        return "Custom (CX)" if "custom" in g else "Infinity" if "infinity" in g else "Basic / Unique (BX / UX)" if ("basic" in g or "unique" in g) else "Hasbro (all lines)"
    if c.startswith("BX"):
        return "Basic (BX)"
    if c.startswith("UX"):
        return "Unique (UX)"
    if c.startswith("CX"):
        return "Custom (CX)"
    return "Basic (BX)" if "basic" in section.lower() else "Unique (UX)" if "unique" in section.lower() else "Custom (CX)" if "custom" in section.lower() else "Other"


class BeybladeProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("beyblade", 0, type_field="Blade")

    # ---- blades named like the collectors write them ('DranSword' -> 'Dran Sword') and what is in each numbered product
    def _spaced(self, text, sheet):
        names = sorted(sheet["blades"].values(), key=lambda s: -len(_squash(s)))
        if not hasattr(self, "_blade_re"):
            pats = []

            def pat(txt):
                return re.compile(r"(?<![A-Za-z])" + r"[ ']?".join(re.escape(ch) for ch in _squash(txt)) + r"(?![a-z])", re.I)
            for nm in names:
                if nm in ("Dran Dragger",):
                    continue
                pats.append((pat(nm), nm))
                words = nm.replace("'", "").split()
                if len(words) == 2:
                    pats.append((pat(" ".join(reversed(words))), nm))              # Hasbro: Sword Dran, Arrow Wizard, Claw Leon ...
            for hb, tk in _HASBRO_NAMES.items():
                if tk in sheet["blades"].values():
                    pats.append((pat(hb), tk))
            self._blade_re = pats
        return self._blade_re

    def _generic_blade(self, text, sheet):
        """A blade that is not in the spreadsheet (newer than it): the words before the ratchet / bit ('BulletGriffon H', 'Rock Leone 6-80GN', 'Courage Dran S 6-60V'), spaced the way collectors write them."""
        words = []
        for w in text.replace("(", " ").replace(")", " ").split():
            if re.search(r"\d", w):
                break
            words.append(w)
        while len(words) > 1 and len(words[-1]) <= 3 and not re.fullmatch(r"[A-Z][a-z]+", words[-1]):
            words.pop()
        if not words or words[0].lower() in ("vol", "vol.", "the", "metal", "set") or any(w.lower() in ("deck", "pack", "set", "starter") for w in words):
            return ""
        nm = " ".join(words)
        if len(words) == 1:
            nm = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", nm)
        return sheet["blades"].get(_squash(nm)) or nm

    def _blades_in(self, name, code, kind, sheet, link=""):
        found = []
        for rx, nm in self._spaced(name, sheet):
            if rx.search(name) and nm not in found:
                found.append(nm)
        found = [n for n in found if not any(n != o and _squash(n) in _squash(o) for o in found)]
        if not found and kind in ("Random Booster", "Set / pack", "Multipack set") and code and code in sheet["contents"] and not code.endswith("-00"):
            found = list(sheet["contents"][code])
        if kind == "Random Booster" and code in sheet["contents"] and not code.endswith("-00"):
            found = list(sheet["contents"][code])                     # a random booster holds several blades: the spreadsheet knows which
        if not found and kind in ("Starter", "Booster", "Dual pack", "Random Booster"):
            core = re.sub(r"\([^)]*\)", "", name).strip()
            if kind == "Dual pack":
                for part in re.split(r"\s+and\s+", re.sub(r"\s+Dual Pack$", "", core)):
                    b = self._generic_blade(part, sheet)
                    if b and b not in found:
                        found.append(b)
            else:
                src = link if link and re.search(r"\d", link) else core
                src = re.sub(r"\s+Select$", "", re.sub(r"^(?:Random Booster|Starter|Booster)\s+", "", src))
                b = self._generic_blade(src, sheet)
                if b:
                    found.append(b)
        return found

    def _pretty(self, name, sheet):
        out = name
        for rx, nm in self._spaced(name, sheet):
            out = rx.sub(nm, out)
        return out

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            sheet = _bey_sheet()
            progress("Reading the Beyblade X product lists…", 0, 4)
            tt = wikitext(BEY_WIKI, "List_of_Beyblade_X_products_(Takara_Tomy)")
            progress("Reading the Hasbro list…", 1, 4)
            hb = wikitext(BEY_WIKI, "List_of_Beyblade_X_products_(Hasbro)")
            if not tt and not hb:
                raise RuntimeError("the Beyblade wiki returned nothing")
            rows = []
            for section, group, cells in table_rows(tt):
                if len(cells) >= 4 and re.match(r"^[A-Z]{2}-\d{2}$", strip_markup(cells[0])):
                    rows.append(dict(maker="Takara Tomy", section=section, group=group, code=strip_markup(cells[0]), name_raw=cells[1], date_raw=cells[2], price_raw=cells[3]))
            for section, group, cells in table_rows(hb):
                if len(cells) >= 4 and strip_markup(cells[0]) and not strip_markup(cells[0]).lower().startswith(("product", "tba")):
                    rows.append(dict(maker="Hasbro", section=section, group=group, code=strip_markup(cells[0]), name_raw=cells[1], date_raw=cells[2], price_raw=cells[3]))
            links = [first_link(r["name_raw"]) for r in rows]
            imgs = _kv(gdir, "wiki_images.json", 14, links, lambda need: {**{k: "" for k in need}, **{k: (v.get("image") or "") for k, v in page_batches(BEY_WIKI, need).items()}})
            progress("Writing the list…", 3, 4)
            used, seen_set = {}, {}
            for r, link in zip(rows, links):
                name_clean = strip_markup(r["name_raw"])
                part = re.match(r"(Blade|Ratchet|Bit|Main Blade|Assist Blade|Lock Chip) - ", link or "")
                if part:
                    name_clean = f"{part.group(1)} {name_clean}"
                kind = "Parts" if part or re.match(r"Bit Set\b", name_clean) else _bey_kind(name_clean, r["group"])
                maker, code = r["maker"], r["code"]
                if kind == "Other" and re.search(r"\b\d-\d\d[A-Z]{1,3}\b", name_clean):
                    kind = "Booster"                                       # the X-Over Project rows are plain blade combinations
                name = self._pretty(name_clean, sheet) if maker == "Takara Tomy" else name_clean                 # Hasbro keeps its own names (Sword Dran)
                m = re.search(r"\(([^()]*)\)\s*$", name)
                variant = m.group(1).strip() if m and not re.search(r"^\d+$", m.group(1)) else ""
                date_text = strip_markup(r["date_raw"])
                iso = parse_date(r["date_raw"])
                venue_m = re.search(r"\(([^()]+)\)", date_text)
                venue = venue_m.group(1).strip() if venue_m else ""
                if maker == "Hasbro" and not venue:
                    venue = ""
                blades = self._blades_in(name_clean, code, kind, sheet, link)
                line = _bey_line(code, r["section"], r["group"], maker)
                limited = r["section"].lower().startswith("limited") or code.endswith("-00")
                sid_name = {"Takara Tomy": ("Limited & exclusive releases" if limited else {"Basic (BX)": "Basic line (BX)", "Unique (UX)": "Unique line (UX)", "Custom (CX)": "Custom line (CX)"}.get(line, "Other Takara Tomy")),
                            "Hasbro": "Hasbro (Western releases)"}[maker]
                sid = "beyblade:" + slug(sid_name)
                if sid not in seen_set:
                    seen_set[sid] = sid_name
                    _put_set(conn, sid, sid_name, "Takara Tomy" if maker == "Takara Tomy" else "Hasbro")
                key = slug(f"{maker}-{code}-{name_clean}-{iso}")[:120] or slug(name_clean)
                if key in used:
                    used[key] += 1
                    key += f"-{used[key]}"
                else:
                    used[key] = 1
                collab = [label for label, rx in _COLLAB if re.search(rx, name_clean + " " + r["group"] + " " + venue, re.I)][:1]
                price_txt = strip_markup(r["price_raw"])
                usd = None
                if maker == "Hasbro":
                    seg = next((s for s in re.split(r"<br\s*/?>", r["price_raw"]) if "United States" in s), (re.split(r"<br\s*/?>", r["price_raw"]) or [""])[0])
                    pm = re.search(r"\$\s*(\d+(?:\.\d\d)?)", seg)
                    usd = float(pm.group(1)) if pm else None
                    if usd is None:
                        pm = re.search(r"\$\s*(\d+(?:\.\d\d)?)", r["price_raw"])
                        usd = float(pm.group(1)) if pm else None
                    price_txt = f"${usd:.2f} (US)" if usd is not None else price_txt
                tags = ["line:" + line, "maker:" + maker, "kind:" + kind] + ["blade:" + b for b in blades] + (["year:" + iso[:4]] if iso else []) + (["exclusive:" + venue[:60]] if venue else []) \
                    + (["variant:" + variant[:60]] if variant else []) + ["collab:" + c for c in collab] + (["limited"] if limited else [])
                ext = {"Product code": code if not code.endswith("-00") else "No number (limited / prize)", "Maker": maker, "Line": line, "Product kind": kind, "Released": iso or date_text,
                       "Sold at / event": venue, "Variant": variant, "Blades": ", ".join(blades), "Retail price": price_txt, "Wiki page": f"https://{BEY_WIKI}/wiki/{quote(link.replace(' ', '_'))}" if link else ""}
                desc = f"{maker} Beyblade X {kind.lower()}" + (f" ({variant})" if variant else "") + (f", {venue}" if venue else "") + (f". Contains: {', '.join(blades)}." if blades and kind in ("Random Booster", "Set / pack", "Multipack set") else ".")
                _put_card(conn, "bey:" + key, sid, code if not code.endswith("-00") else "", int(iso.replace("-", "")) if iso else 0, name, imgs.get(link) if link else "", kind,
                          "Limited / exclusive" if limited else "Regular release", ", ".join(blades[:3]), desc, usd, "retail price (US)", tags, ext)
            # ---- the event gear stickers (from the collector's spreadsheet)
            if sheet.get("stickers"):
                sid = "beyblade:gear-stickers"
                _put_set(conn, sid, "Gear stickers (events & collabs)", "Takara Tomy", "")
                for s in sheet["stickers"]:
                    yr = re.search(r"20\d\d", s["en"] + " " + s["desc"])
                    tags = ["line:Stickers", "maker:Takara Tomy", "kind:Gear sticker", "limited"] + (["year:" + yr.group(0)] if yr else [])
                    ext = {"Number": str(s["n"]), "Japanese name": s["jp"], "How it was given out": s["desc"], "Versions": (f"{s['types']} (Type 1 ... Type {s['types']})" if s["types"] else "1")}
                    _put_card(conn, f"bey:sticker-{s['n']:02d}", sid, str(s["n"]), s["n"], s["en"], "", "Gear sticker", "Limited / exclusive", "", s["desc"] or "Event / collaboration gear sticker.", None, "", tags, ext)
            conn.execute("UPDATE sets SET release_date=(SELECT substr(MIN(sort_key), 1, 4) || '-' || substr(MIN(sort_key), 5, 2) || '-' || substr(MIN(sort_key), 7, 2) FROM cards WHERE set_id=sets.id AND sort_key > 20000000) "
                         "WHERE id LIKE 'beyblade:%' AND EXISTS (SELECT 1 FROM cards WHERE set_id=sets.id AND sort_key > 20000000)")                # a set is dated by its first product
            progress("Done", 4, 4)
            return _finish(conn, "beyblade")
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0


# ================================================================================================================== Bakugan
ATTRS = ("Pyrus", "Aquos", "Haos", "Darkus", "Subterra", "Ventus", "Aurelus")
_ATTR_RX = re.compile(r"\b(" + "|".join(ATTRS) + r")\b", re.I)
_SEASONS = (("Bakugan Battle Brawlers", "Battle Brawlers", "2008", "Classic"), ("Bakugan Battle Brawlers: New Vestroia", "New Vestroia", "2009", "Classic"),
            ("Bakugan: Gundalian Invaders", "Gundalian Invaders", "2010", "Classic"), ("Bakugan: Mechtanium Surge", "Mechtanium Surge", "2011", "Classic"))
_MODERN = (("Battle Planet Bakugan", "Battle Planet", "2019"), ("Armored Alliance Bakugan", "Armored Alliance", "2020"), ("Evolutions Bakugan", "Evolutions", "2021"),
           ("Geogan Rising Bakugan", "Geogan Rising", "2022"), ("Legends Bakugan", "Legends", "2023"))
ATTACH_KINDS = {"battle gear", "deluxe battle gear", "super assault", "mobile assault", "mobile assaults", "bakunano", "mechtogan", "mechtogan titan", "mechtogan combinations", "mechtogan destroyers",
                "bakugan battle suits", "battle suit", "bakumine", "baku-gear", "bakugan armors"}


def _kind_label(sub):
    s = re.sub(r"\s+", " ", (sub or "Bakugan").replace("Bakugan Traps", "Bakugan Trap")).strip()
    s = re.sub(r"\s*\((?:Special Treatment )?Re-?Releases\)", "", s, flags=re.I)
    rep = {"Mobile Assaults": "Mobile Assault", "Bakugan Battle Suits": "Battle Suit", "Baku Sky Raider Combinations": "Baku Sky Raider (combination)", "BakuFusion Combinations": "BakuFusion (combination)",
           "Mechtogan Combinations": "Mechtogan (combination)", "Bakugan vs Marvel Re-Released Bakugan": "Bakugan vs Marvel", "Special Attack": "Bakugan (Special Attack)"}
    return rep.get(s, s)


def _attrs_of(text):
    """The attribute(s) a page says it has: the infobox field, else the colour tabs template at the top ({{Pyrus Tabs}})."""
    m = re.search(r"\|\s*attribute\s*=\s*(.*?)(?=\n\s*\||\n\}\})", text or "", re.I | re.S)
    found = []
    for src in ([m.group(1)] if m else []) + [t for t in re.findall(r"\{\{\s*(Pyrus|Aquos|Haos|Darkus|Subterra|Ventus|Aurelus)\s+Tabs", text or "", re.I)]:
        for a in _ATTR_RX.findall(src):
            a = a.capitalize()
            if a not in found:
                found.append(a)
        if found:
            break
    return found[:6]


class BakuganProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("bakugan", 0, type_field="Type")

    def _pages(self, gdir, titles):
        """{title: {"attrs": [...], "image": url, "cats": [...]}} for wiki pages; pages read in the last 14 days are not read again."""
        def fetch(need):
            out = {t: {"attrs": [], "image": "", "cats": []} for t in need}
            for i in range(0, len(need), 40):
                for t, v in page_batches(BAKU_WIKI, need[i:i + 40], with_text=True).items():
                    x = v.get("text") or ""
                    out[t] = {"attrs": _attrs_of(x), "image": v.get("image") or "", "cats": re.findall(r"\[\[Category:([^\]|]+)", x)}
            return out
        return _kv(gdir, "wiki_pages.json", 14, titles, fetch)

    def _category(self, cat):
        out, cont = [], {}
        while True:
            d = _api(BAKU_WIKI, action="query", list="categorymembers", cmtitle="Category:" + cat, cmlimit=500, **cont)
            out += [m["title"] for m in (d.get("query") or {}).get("categorymembers", []) if m.get("ns") == 0]
            if "continue" in d:
                cont = d["continue"]
            else:
                return out

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the Bakugan wave lists…", 0, 5)
            waves = wikitext(BAKU_WIKI, "Bakugan_Waves")
            if not waves:
                raise RuntimeError("the Bakugan wiki returned nothing")
            season = wave = sub = None
            wave_base = ""
            entries = []                                                       # classic toys: (season title, wave, sub-heading, page, shown name, note)
            for ln in waves.splitlines():
                h = re.match(r"^(=+)\s*(.*?)\s*\1\s*$", ln)
                if h:
                    lvl, txt = len(h.group(1)), strip_markup(h.group(2))
                    if lvl == 2:
                        season, wave, sub = txt, None, None
                    elif lvl == 3 and re.match(r"(Worldwide|European Exclusive)", txt):
                        wave, sub = wave_base + (" - European exclusive" if txt.startswith("European") else ""), None
                    elif lvl == 3:
                        wave_base, wave, sub = txt, txt, None
                    elif lvl >= 4:
                        sub = txt
                    continue
                m = re.match(r"^\*+\s*\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|([^\]]+))?\]\](.*)$", ln)
                if m and season in {s[0] for s in _SEASONS} and wave:
                    entries.append((season, wave, sub or "Bakugan", m.group(1).strip(), (m.group(2) or m.group(1)).strip(), strip_markup(m.group(3))))
            modern = {}
            for i, (cat, label, year) in enumerate(_MODERN):
                progress(f"Reading {label}…", 1 + i // 2, 5)
                try:
                    modern[label] = self._category(cat)
                except Exception as e:  # noqa: BLE001
                    print(f"bakugan {label}: {str(e)[:80]}", flush=True)
                    modern[label] = []
            gear_text = wikitext(BAKU_WIKI, "Baku-Gear")
            gear = re.findall(r"^\*'''([^']+?)'''\s*:\s*\[\[([^\]|]+)(?:\|[^\]]*)?\]\][^\n]*$", gear_text, re.M)
            titles = {e[3] for e in entries}
            for label, members in modern.items():
                titles.update(members)
            titles.update(o for _g, o in gear)
            progress("Reading each Bakugan's page (types and pictures)…", 3, 5)
            pages = self._pages(gdir, sorted(titles))
            progress("Writing the list…", 4, 5)
            order, seen = 0, set()

            def add(season_label, year, serie, wave_label, kind, page_title, shown, note, attrs, ids_prefix):
                nonlocal order
                group = "Attachment" if kind.lower() in ATTACH_KINDS or kind.lower().startswith("mechtogan") else "Bakugan"
                sid = "bakugan:" + slug(season_label)
                _put_set(conn, sid, f"{season_label} ({year})", serie, year + "-01-01")
                page = pages.get(page_title) or {}
                attrs = attrs or page.get("attrs") or []
                attrs = attrs or (["Unknown"] if group == "Bakugan" else ["Neutral"])             # an attachment with no attribute is neutral; a Bakugan whose page names none is unknown
                for a in attrs:
                    key = slug(f"{ids_prefix}-{wave_label}-{kind}-{shown}-{a}")[:150]
                    if key in seen:
                        continue
                    seen.add(key)
                    order += 1
                    rare = "Re-release" if re.search(r"re-?release|special treatment", note + kind + wave_label, re.I) else "Exclusive" if re.search(r"only at|exclusive", note, re.I) else "Regular release"
                    nm = re.sub(r"\s*\((?:Generation \d|%s)\)\s*$" % "|".join(re.escape(x[1]) for x in _MODERN), "", shown).strip()
                    tags = ["group:" + group, "kind:" + kind, "attr:" + a, "season:" + season_label, "wave:" + wave_label] + (["note:Re-release"] if rare == "Re-release" else []) + (["note:Retailer exclusive"] if rare == "Exclusive" else [])
                    ext = {"Bakugan or attachment": group, "Kind": kind, "Type (attribute)": a, "Season": f"{season_label} ({year})", "Wave / release": wave_label, "Notes": note,
                           "Wiki page": f"https://{BAKU_WIKI}/wiki/{quote(page_title.replace(' ', '_'))}"}
                    _put_card(conn, "bak:" + key, sid, "", year_order(year) * 100000 + order, nm if a in ("Neutral", "Unknown") else f"{nm} ({a})", page.get("image") or "", group, rare, a,
                              f"{season_label} {kind}" + (f" - {wave_label}" if wave_label else "") + (f". {note}" if note else "") + ".", None, "", tags, ext)

            def year_order(y):
                return int(y) - 2000

            ymap = {s[0]: (s[1], s[2], s[3]) for s in _SEASONS}
            for season_t, wave_t, sub, page_t, shown, note in entries:
                lab, year, serie = ymap.get(season_t, (season_t, "2008", "Classic"))
                wave_label = re.sub(r"\s+", " ", wave_t)
                add(lab, year, serie, wave_label, _kind_label(sub), page_t, shown, note, None, "w")
            for cat, label, year in _MODERN:
                for t in modern.get(label, []):
                    pg = pages.get(t) or {}
                    cats = pg.get("cats") or []
                    if not pg.get("attrs") or re.search(r"Tabs|Characters|^Unknown ", t) or t in ATTRS:              # the attribute pages themselves and placeholder pages are not toys
                        continue
                    kind = "Bakugan Trap" if any(c in ("Connecting Trap", "Bakugan Trap") for c in cats) else "Evolution" if "Evolution Bakugan" in cats else "Bakugan"
                    add(label, year, "Spin Master relaunch", label, kind, t, t, "", None, "m")
            owner_season = {}
            for _cat, label, _y in _MODERN:
                for t in modern.get(label, []):
                    owner_season.setdefault(t, label)
            years = {label: y for _c, label, y in _MODERN}
            for name, owner in gear:
                lead = re.match(r"^((?:(?:%s)(?:\s*/\s*|\s+))+)" % "|".join(ATTRS), name, re.I)          # 'Ventus/Aquos Boomerang Blades': the attribute(s) come first
                at = [a.capitalize() for a in _ATTR_RX.findall(lead.group(1))] if lead else []
                nm = name[lead.end():] if lead else name
                nm = re.sub(r"\s*\(.*?\)\s*", " ", nm)
                nm = re.sub(r"\s+", " ", nm).strip()
                label = owner_season.get(owner) or "Armored Alliance"
                owner_nm = re.sub(r"\s*\(.*?\)", "", owner)
                add(label, years.get(label, "2020"), "Spin Master relaunch", "Baku-Gear", "Baku-Gear", owner, f"{nm} - {owner_nm}", f"Baku-Gear of {owner_nm}", at[:2] or None, "g")
            dup = conn.execute("SELECT set_id, name FROM cards WHERE id LIKE 'bak:%' GROUP BY set_id, name HAVING COUNT(*) > 1").fetchall()
            for sid, nm in dup:
                for cid, raw in conn.execute("SELECT id, raw FROM cards WHERE set_id=? AND name=?", (sid, nm)).fetchall():
                    wv = next((x[5:] for x in (json.loads(raw).get("tags") or []) if x.startswith("wave:")), "")
                    short = re.search(r"\(([^()]*Wave[^()]*)\)", wv)
                    label = short.group(1) if short else wv
                    conn.execute("UPDATE cards SET name=? WHERE id=?", (f"{nm} - {label}" if label else nm, cid))
            for sid, nm in conn.execute("SELECT set_id, name FROM cards WHERE id LIKE 'bak:%' GROUP BY set_id, name HAVING COUNT(*) > 1").fetchall():       # same wave too: tell them apart by kind
                for cid, raw in conn.execute("SELECT id, raw FROM cards WHERE set_id=? AND name=?", (sid, nm)).fetchall():
                    kd = next((x[5:] for x in (json.loads(raw).get("tags") or []) if x.startswith("kind:")), "")
                    conn.execute("UPDATE cards SET name=? WHERE id=?", (f"{nm} ({kd})" if kd else nm, cid))
            return _finish(conn, "bakugan")
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0
