"""McDonald's Happy Meal toys: every promotion (a year, a collab) is a "set", every toy an item of its own, filed under its promotion.  No network at refresh.

Data: cardvault/mcdonalds_data.json (docs/mcdonalds_data.md has the survey and what is left).  Every fact an item shows is one its source states (name, the set's group, the country where stated, the year, the
number in the set as the source states it); one the source does not state is left out, never guessed.  Each stated fact gets a provenance record.  PICTURES: only the Pokemon TCG McDonald's promo cards have
one - the card's own TCGplayer product picture (the record that states its name and number), kept by tools/import_mcdonalds.py only after the automatic byte check (photoverify); Wikipedia's toy pictures are
non-free files and no allowed source gives a picture of the other toys, so those say "No picture yet" and sit on the review list (raw ext 'Review').  The Pokemon cards name their card in the Pokemon list
('Also in the Pokémon list'); that list is not changed.  The 2021 cards are two items each, Holo and Non-Holo (owner: "2 separate items"; cardvault/mcdonalds_import.py SPLIT_PRINTINGS).  PRICES: none (no free source with real toy prices is allowed; the Pokemon cards have theirs in the Pokemon list).  Stable id `mcd:<id>` is kept in raw `key`."""
import json
import os
import time

from . import provenance
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mcdonalds_data.json")
NO_PICTURE = "No picture yet: no source we are allowed to read gives a picture we may show of this exact toy"


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def facts_of(promo, toy):
    """{detail label: stated value} of one toy in display order (a fact the source does not state is simply not here)."""
    n = promo.get("total") or 0
    out = {"Promotion": promo["name"], "Year": promo.get("year"), "Country": toy.get("country") or promo.get("country"), "Collab / brand": promo.get("brand"),
           "Group in the set": toy.get("group"), "Number in the set": ("%s of %s" % (toy["number"], n)) if n else toy.get("number"), "Toys in the set": str(n) if n else "", "Printing": toy.get("printing"), "Note": toy.get("note")}
    return {k: v for k, v in out.items() if v}


class McDonaldsProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("mcdonalds", 0, type_field="Promotion")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the McDonald's toys list…", 0, 0)
            provenance.ensure(conn)
            data = load()
            promos = {p["id"]: p for p in data["promotions"]}
            rows, prov, moves = [], [], {}
            count = {}
            for t in data["toys"]:
                count[t["promotion"]] = count.get(t["promotion"], 0) + 1
            for p in data["promotions"]:                                                       # (total = items listed, official = the stated set size: the 2021 set is 25 cards in 2 printings = 50 items)
                conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)",
                             ("mcd:" + p["id"], p["name"], p["year"], p["year"], max(p.get("total") or 0, count.get(p["id"], 0) if p.get("total") else 0), p.get("total") or 0))
            for i, t in enumerate(sorted((t for t in data["toys"] if t["promotion"] in promos), key=lambda t: (promos[t["promotion"]]["year"], t["promotion"], int(t["number"])))):
                p = promos[t["promotion"]]
                src = data["sources"][t["source"]]
                code = "w:" + src["host"]
                conn.execute("INSERT OR REPLACE INTO sources(code,name,url_tpl) VALUES(?,?,NULL)", (code, src["name"]))
                facts = facts_of(p, t)
                cid = "mcd:" + t["id"]
                pic = t.get("picture") or {}
                review = list(t.get("review", []))                                            # (the importer's reasons: a record without a picture, a picture that failed the check)
                if not pic.get("url"):
                    review = ["No picture yet: " + review[0]] + review[1:] if review else [NO_PICTURE]
                ext = {"Source": "%s: %s" % (src["name"], t["url"]), **facts, "Also in the Pokémon list": t.get("pokemon_link"),
                       "Photo credit": "%s: %s" % (pic["credit"], pic["page"]) if pic.get("url") else "", "Review": "; ".join(review)}
                ext = {k: v for k, v in ext.items() if v}
                prov.append((cid, "card", code, t["read"], t["url"]))
                prov += [(cid, label, code, t["read"], t.get("printing_url") if label == "Printing" else t["url"]) for label in facts]     # (the printing is stated by TCGplayer's price records)
                if t.get("moves_from"):
                    moves.setdefault("mcd:" + t["moves_from"]["id"], {})[t["moves_from"]["variant"]] = cid
                if pic.get("url"):
                    prov.append((cid, "image", provenance.image_source(conn, pic["url"]), pic["checked"], pic["page"]))
                rows.append((cid, "mcd:" + p["id"], t["number"], int(t["number"]), t["name"], pic.get("url", ""), p["name"], p["year"], p.get("brand") or "",
                             "%s - %s, %s." % (t["name"], p["name"], p["year"]), json.dumps(t.get("variants") or {"normal": True}),
                             json.dumps({"source": src["host"], "key": t["id"], "promotion": p["id"], "url": t["url"], "cover_url": pic.get("url", ""), "ext": ext}, ensure_ascii=False)))
            conn.executemany("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) "
                             "VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)", rows)
            keep = {r[0] for r in rows}
            gone = [(r[0],) for r in conn.execute("SELECT id FROM cards") if r[0] not in keep]
            conn.executemany("DELETE FROM cards WHERE id=?", gone)
            conn.executemany("DELETE FROM provenance WHERE card_id=?", gone + [(c,) for c in keep])
            provenance.record_many(conn, prov)
            conn.execute("DELETE FROM sets WHERE id NOT IN (SELECT DISTINCT set_id FROM cards)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('variant_moves', ?)", (json.dumps(moves, ensure_ascii=False, sort_keys=True),))      # {kept id: {printing: its own item}} (db.Vault._apply_variant_moves)
            conn.commit()
            from . import gamefacets
            gamefacets.ensure(conn, self.game_id, force=True)
            return len(rows)
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no free source with real prices is allowed (docs/mcdonalds_data.md)
