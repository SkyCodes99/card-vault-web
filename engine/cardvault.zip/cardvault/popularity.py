"""One "popularity" number per card, worked out by the nightly job and stored in the card list (cards.popularity, REAL; NULL = no signal), so the app sorts by it with no network.

Signals (all already ours or from eBay's OFFICIAL Browse API - nothing is scraped):
  * how many app users hold the card (an anonymous count of accounts in collection.db, when that data is on this computer)
  * eBay demand: the number of live listings that match the card (the `total` of one Browse search, limit=1 - table pop_signal; kept 7 days then dropped, eBay's rules)
  * the price level (TCGplayer market, or the eBay asking price) - a card people pay more for is looked at more
  * how far the asking price moved lately (table ask_history, where there is one)
score = 3*ln(1+holders) + 2*ln(1+ebay listings) + 0.8*ln(1+price) + 1.5*min(1, move).  A card with none of the signals has NULL and sorts after those that have one, in set order.
The eBay searches are spent on the most-held, then highest-value cards first (pick); a card is looked at again after 7 days.  Keys are never read here: the caller hands over an object with .count(query)."""
import math
import os
import sqlite3

KEEP_DAYS = 7
HINT = {"pokemon": "pokemon card", "pokemon_jp": "pokemon card japanese", "mtg": "magic the gathering card", "yugioh": "yugioh card", "lorcana": "lorcana card",
        "onepiece": "one piece card game"}


def table(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS pop_signal(card_id TEXT PRIMARY KEY, total INTEGER NOT NULL, at TEXT NOT NULL)")


def score(price, holders, total, move):
    """The popularity of one card, or None when there is no signal at all."""
    price = price if price and price > 0 else 0
    if not (price or holders or total is not None):
        return None
    return round(3 * math.log1p(holders or 0) + 2 * math.log1p(total or 0) + 0.8 * math.log1p(price) + 1.5 * min(1.0, abs(move or 0)), 4)


def holders(data, game):
    """{card id: how many accounts hold it} from collection.db (read-only); {} when there is none."""
    path = os.path.join(data, "collection.db")
    if not os.path.exists(path):
        return {}
    try:
        c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=30)
        try:
            return {str(i): n for i, n in c.execute("SELECT card_id, COUNT(DISTINCT user_id) FROM lots WHERE game=? AND qty>0 AND COALESCE(deleted,0)=0 GROUP BY card_id", (game,))}
        finally:
            c.close()
    except sqlite3.Error:
        return {}


def _moves(conn, day):
    try:
        rows = conn.execute("SELECT card_id, day, usd FROM ask_history WHERE day >= date(?, '-14 day') ORDER BY card_id, day", (day,)).fetchall()
    except sqlite3.Error:
        return {}
    first, last = {}, {}
    for cid, _d, usd in rows:
        first.setdefault(cid, usd)
        last[cid] = usd
    return {c: abs(last[c] - first[c]) / first[c] for c in first if first[c] > 0}


def compute(conn, held, day):
    """Write cards.popularity for every card of this list.  -> cards that got a score.  The caller commits."""
    if not any(r[1] == "popularity" for r in conn.execute("PRAGMA table_info(cards)")):
        conn.execute("ALTER TABLE cards ADD COLUMN popularity REAL")
    table(conn)
    conn.execute("DELETE FROM pop_signal WHERE at < date(?, ?)", (day, f"-{KEEP_DAYS} day"))
    sig = dict(conn.execute("SELECT card_id, total FROM pop_signal"))
    mv = _moves(conn, day)
    out = [(score(price, held.get(str(cid), 0), sig.get(cid), mv.get(cid)), cid) for cid, price in conn.execute("SELECT id, price_usd FROM cards").fetchall()]
    conn.executemany("UPDATE cards SET popularity=? WHERE id=?", out)
    return sum(1 for s, _ in out if s is not None)


def pick(conns, held, day, n):
    """Up to n (game, card id, query) to search on eBay: cards with no count from the last KEEP_DAYS, most-held first, then highest price.  conns = {game: sqlite connection}; held = {game: {id: n}}."""
    cand = []
    for g, conn in conns.items():
        table(conn)
        fresh = {r[0] for r in conn.execute("SELECT card_id FROM pop_signal WHERE at >= date(?, ?)", (day, f"-{KEEP_DAYS} day"))}
        h = held.get(g, {})
        for cid, name, sname, price in conn.execute("SELECT c.id, c.name, s.name, c.price_usd FROM cards c LEFT JOIN sets s ON s.id=c.set_id").fetchall():
            if cid in fresh or not (price and price > 0 or h.get(str(cid))):
                continue
            cand.append((-h.get(str(cid), 0), -(price or 0), g, cid, f"{HINT.get(g, g)} {name} {sname or ''}".strip()))
    cand.sort()
    return [(g, cid, q) for _h, _p, g, cid, q in cand[:n]]
