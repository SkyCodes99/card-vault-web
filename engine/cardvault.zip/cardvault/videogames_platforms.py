"""Platforms of the "Video games (physical)" list: the consoles and handhelds whose games come on a disc, a cartridge or a card.  Each one is a "set" of the list; a game released on it is one item of that set.

`qid` is the platform's Wikidata item (what a game's "platform" statement points at), `maker` groups the sets, `media` is what the game is sold on.  Digital-only and PC / phone platforms are not here on
purpose: the list is for what you can hold.  A platform is only a row here; whether it has games in the list depends on the data (cardvault/videogames_data.json or the import)."""

CARTRIDGE, CARD, DISC, DISK_CARD = "Cartridge", "Game card", "Disc", "Disk card"
MEDIA = (CARTRIDGE, CARD, DISC, DISK_CARD)

# (Wikidata id, name shown, maker, media)
_ROWS = (
    ("Q172742", "Nintendo Entertainment System", "Nintendo", CARTRIDGE),
    ("Q491640", "Family Computer (Famicom)", "Nintendo", CARTRIDGE),
    ("Q135321", "Famicom Disk System", "Nintendo", DISK_CARD),
    ("Q183259", "Super Nintendo Entertainment System", "Nintendo", CARTRIDGE),
    ("Q184839", "Nintendo 64", "Nintendo", CARTRIDGE),
    ("Q182172", "Nintendo GameCube", "Nintendo", DISC),
    ("Q8079", "Wii", "Nintendo", DISC),
    ("Q56942", "Wii U", "Nintendo", DISC),
    ("Q19610114", "Nintendo Switch", "Nintendo", CARD),
    ("Q122761124", "Nintendo Switch 2", "Nintendo", CARD),
    ("Q186437", "Game Boy", "Nintendo", CARTRIDGE),
    ("Q203992", "Game Boy Color", "Nintendo", CARTRIDGE),
    ("Q188642", "Game Boy Advance", "Nintendo", CARTRIDGE),
    ("Q164651", "Virtual Boy", "Nintendo", CARTRIDGE),
    ("Q170323", "Nintendo DS", "Nintendo", CARD),
    ("Q637178", "Nintendo DSi", "Nintendo", CARD),
    ("Q203597", "Nintendo 3DS", "Nintendo", CARD),
    ("Q10677", "PlayStation", "Sony", DISC),
    ("Q10680", "PlayStation 2", "Sony", DISC),
    ("Q10683", "PlayStation 3", "Sony", DISC),
    ("Q5014725", "PlayStation 4", "Sony", DISC),
    ("Q63184502", "PlayStation 5", "Sony", DISC),
    ("Q170325", "PlayStation Portable", "Sony", DISC),
    ("Q188808", "PlayStation Vita", "Sony", CARD),
    ("Q132020", "Xbox", "Microsoft", DISC),
    ("Q48263", "Xbox 360", "Microsoft", DISC),
    ("Q13361286", "Xbox One", "Microsoft", DISC),
    ("Q98973368", "Xbox Series X and Series S", "Microsoft", DISC),
    ("Q1136956", "SG-1000", "Sega", CARTRIDGE),
    ("Q209868", "Sega Master System", "Sega", CARTRIDGE),
    ("Q10676", "Sega Genesis / Mega Drive", "Sega", CARTRIDGE),
    ("Q1047516", "Sega CD / Mega-CD", "Sega", DISC),
    ("Q200912", "Sega Saturn", "Sega", DISC),
    ("Q184198", "Dreamcast", "Sega", DISC),
    ("Q751719", "Game Gear", "Sega", CARTRIDGE),
    ("Q206261", "Atari 2600", "Atari", CARTRIDGE),
    ("Q743222", "Atari 5200", "Atari", CARTRIDGE),
    ("Q753600", "Atari 7800", "Atari", CARTRIDGE),
    ("Q650601", "Atari Jaguar", "Atari", CARTRIDGE),
    ("Q753657", "Atari Lynx", "Atari", CARTRIDGE),
    ("Q1057377", "TurboGrafx-16 / PC Engine", "NEC", CARD),
    ("Q1136902", "PC-FX", "NEC", DISC),
    ("Q1054350", "Neo Geo", "SNK", CARTRIDGE),
    ("Q2703883", "Neo Geo CD", "SNK", DISC),
    ("Q939881", "Neo Geo Pocket", "SNK", CARTRIDGE),
    ("Q1065792", "WonderSwan", "Bandai", CARTRIDGE),
    ("Q1023103", "Philips CD-i", "Other makers", DISC),
    ("Q229429", "3DO Interactive Multiplayer", "Other makers", DISC),
    ("Q1061441", "Intellivision", "Other makers", CARTRIDGE),
    ("Q1046862", "ColecoVision", "Other makers", CARTRIDGE),
    ("Q576932", "Magnavox Odyssey 2", "Other makers", CARTRIDGE),
    ("Q767631", "Vectrex", "Other makers", CARTRIDGE),
    ("Q981935", "Amstrad GX4000", "Other makers", CARTRIDGE),
    ("Q336434", "N-Gage", "Other makers", CARD),
)

PLATFORMS = [{"qid": q, "id": "wd-" + q, "name": n, "maker": m, "media": md} for q, n, m, md in _ROWS]
BY_QID = {p["qid"]: p for p in PLATFORMS}
