"""Automatic check of third-party product pictures (Worlds / Internationals merchandise and the Wikipedia / Wikimedia Commons console photos).
Owner 2026-11-11: such a picture is no longer accepted just because it carries a photo credit; each one is CHECKED by code, never by looking at it.

Checks (all automatic; tools/verify_photos.py fetches the evidence, this module judges it, so the judging is testable without a network):
  image    the URL answers 200 with an image content type, is big enough, decodes, is not an icon / logo / banner / SVG (side length, aspect ratio, file name), and its bytes (sha1) are not
           shared by another, different product (a placeholder or a stand-in picture)
  page     the source page really shows THIS picture and is about THIS product: the picture is found on the page, and the product's name tokens appear in the picture's own alt / title / file
           name / caption (strong) or on the page (weaker, only when the picture is on it); a different year in the picture's own text fails
  licence  Wikimedia Commons: the file page's licence (Commons API) is a free one, the file is a raster image, not tagged non-free, no restrictions, and it still matches the licence on record;
           other sites: a credit naming the site the picture is served from (or whose page shows it) and nothing in it that forbids showing it
Verdicts are stored in cardvault/photo_verdicts.json ({key: {image, verdict 'pass' | 'review', reasons, checks}}).  accepted() lets a picture through only when its stored verdict for the
SAME image URL is 'pass' (or the owner answered yes on the review list).  Everything else is shown as "no picture" with a Review note and waits on the review list (kind 'photo_verify')."""
import hashlib
import html
import io
import json
import os
import re
import struct
import unicodedata
import urllib.parse

from . import reviewlist

KIND = "photo_verify"
VERDICTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "photo_verdicts.json")
MIN_BYTES, MIN_SIDE, MAX_ASPECT = 3000, 150, 3.0
BAD_FILE = re.compile(r"(?<![a-z])(logo|icon|favicon|banner|placeholder|no[-_ ]?image|noimage|default|sprite|spacer|blank|avatar|thumb[-_ ]?missing|coming[-_ ]?soon)(?![a-z])", re.I)
STOP = {"the", "of", "a", "an", "and", "at", "in", "pokemon", "pokémon", "championships", "championship", "world", "worlds", "international", "internationals", "from", "for", "with", "edition", "by"}
NO_REUSE = re.compile(r"\b(do not use|not allowed|prohibit|forbidden|no reuse|not permitted|must not be used|permission required)\b", re.I)
FREE = re.compile(r"^(CC[ -]|CC0|Public domain|PD|GFDL|Attribution|Copyrighted free use|Free Art|OGL|Open Government)", re.I)


# ------------------------------------------------------------------------------------------------ image facts from bytes (no viewing)
def image_size(data):
    """(width, height) read from the image header (png, jpeg, gif, webp), or None."""
    try:
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", data[16:24])
        if data[:6] in (b"GIF87a", b"GIF89a"):
            return struct.unpack("<HH", data[6:10])
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            k = data[12:16]
            if k == b"VP8X":
                return 1 + int.from_bytes(data[24:27], "little"), 1 + int.from_bytes(data[27:30], "little")
            if k == b"VP8 ":
                w, h = struct.unpack("<HH", data[26:30])
                return w & 0x3FFF, h & 0x3FFF
            if k == b"VP8L":
                b = int.from_bytes(data[21:25], "little")
                return 1 + (b & 0x3FFF), 1 + ((b >> 14) & 0x3FFF)
        if data[:2] == b"\xff\xd8":
            i = 2
            while i < len(data) - 9:
                if data[i] != 0xFF:
                    i += 1
                    continue
                m = data[i + 1]
                if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
                    i += 2
                    continue
                n = struct.unpack(">H", data[i + 2:i + 4])[0]
                if 0xC0 <= m <= 0xCF and m not in (0xC4, 0xC8, 0xCC):
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return w, h
                i += 2 + n
    except (struct.error, IndexError):
        pass
    return None


def decodes(data):
    """True when the bytes decode as an image (Pillow when present, else the header was readable)."""
    try:
        from PIL import Image
    except ImportError:
        return image_size(data) is not None
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
        return True
    except Exception:  # noqa: BLE001
        return False


def facts(status, ctype, data, url=""):
    """What was read from one picture URL -> the 'image' evidence dict."""
    ctype = (ctype or "").split(";")[0].strip().lower()
    out = {"status": status, "ctype": ctype, "bytes": len(data or b"")}
    if data:
        sz = image_size(data)
        out.update(w=sz[0] if sz else 0, h=sz[1] if sz else 0, sha1=hashlib.sha1(data).hexdigest(), decodes=decodes(data))
    return out


# ------------------------------------------------------------------------------------------------ the judging (pure functions)
def check_image(img, url="", name=""):
    """-> list of reasons it fails (empty = fine).  A file name with 'logo' etc. is fine when the product itself is called that (a Logo Pin)."""
    why = []
    if not img or img.get("status") != 200:
        return ["picture URL does not resolve (HTTP %s)" % (img or {}).get("status", "no answer")]
    if not img["ctype"].startswith("image/") or "svg" in img["ctype"]:
        why.append("not a photo file (content type %s)" % (img["ctype"] or "none"))
    if img["bytes"] < MIN_BYTES:
        why.append("picture file is tiny (%d bytes), likely a placeholder" % img["bytes"])
    w, h = img.get("w", 0), img.get("h", 0)
    if not img.get("decodes") or not w or not h:
        why.append("picture does not decode as an image")
    else:
        if min(w, h) < MIN_SIDE:
            why.append("picture too small (%dx%d), likely an icon" % (w, h))
        if max(w, h) / min(w, h) > MAX_ASPECT:
            why.append("picture shape %dx%d looks like a banner / strip, not a product photo" % (w, h))
    name, name_ = urllib.parse.unquote(urllib.parse.urlparse(url).path.rsplit("/", 1)[-1]), name
    bad = BAD_FILE.search(name)
    if bad and bad.group(1).lower() not in (name_ or "").lower():
        why.append("picture file name looks like a logo / icon / placeholder (%s)" % name[:60])
    return why


def duplicates(items):
    """items: [{key, name, sha1}] -> {key: reason} for pictures whose bytes are shared by a product with a different name."""
    by = {}
    for it in items:
        if it.get("sha1"):
            by.setdefault(it["sha1"], []).append(it)
    out = {}
    for group in by.values():
        if len({g["name"].lower() for g in group}) > 1:
            for g in group:
                others = sorted({o["name"] for o in group if o["name"].lower() != g["name"].lower()})
                out[g["key"]] = "same picture bytes as %d other product(s): %s" % (len(others), "; ".join(others[:3]))
    return out


def tokens(text):
    """Lower-case word tokens (accents folded, plural s dropped) without filler words."""
    t = html.unescape(text or "").lower().replace("é", "e")
    out = []
    for w in re.findall(r"[a-z0-9]+", t):
        w = w[:-1] if len(w) > 3 and w.endswith("s") else w
        if w not in STOP and w.rstrip("s") not in STOP:
            out.append(w)
    return out


def name_tokens(name, extra=""):
    seen = []
    for w in tokens(name) + tokens(extra):
        if w not in seen:
            seen.append(w)
    return seen


def _cover(want, have):
    have = set(have)
    return sum(1 for w in want if w in have) / len(want) if want else 0.0


def check_page(name, page, extra=""):
    """page: {'found': the picture is on the page, 'local': text tied to the picture (alt, title, file name, caption), 'text': page title + visible text}.  -> (reasons it fails, how it passed)."""
    want = name_tokens(name, extra)
    if page is None:
        return ["source page could not be read"], ""
    if not page.get("found"):
        return ["picture not found on its source page"], ""
    years = [w for w in want if re.fullmatch(r"(19|20)\d\d", w)]
    local = tokens(page.get("local", ""))
    wrong = [y for y in set(re.findall(r"\b(?:19|20)\d\d\b", page.get("local", ""))) if years and y not in years]
    if wrong:
        return ["picture's own caption / file name names another year (%s), product is %s" % (", ".join(sorted(wrong)), ", ".join(years))], ""
    if _cover(want, local) >= 0.6 and (not years or all(y in local for y in years)):
        return [], "picture's own text matches the product name"
    if page.get("text") and _cover(want, tokens(page["text"])) >= 0.99:
        return [], "product name tokens all appear on the page that shows the picture"
    return ["source page does not mention the product (%d%% of its name words near the picture)" % round(100 * _cover(want, local))], ""


def site_of(url):
    h = urllib.parse.urlparse(url).netloc.lower()
    return re.sub(r"^(www|mcdn|cdn|images?|static)\.", "", h)


def _root(h):
    p = h.split(".")
    return ".".join(p[-3:] if len(p) > 2 and p[-2] in ("co", "com", "org") else p[-2:])


def check_credit(credit, image_url, source_url):
    """A site's picture: a credit that names the site it comes from and does not forbid showing it.  -> reasons it fails."""
    if not (credit or "").strip():
        return ["no photo credit"]
    if NO_REUSE.search(credit):
        return ["credit forbids reuse: " + credit[:80]]
    hosts = {_root(site_of(u)) for u in (image_url, source_url) if u}
    low = unicodedata.normalize("NFKD", credit.lower()).encode("ascii", "ignore").decode()
    own = "pokemon company" in low                                   # the company's own sites (pokemon.com, pokemonxp.com, pokemon.co.jp) credited to The Pokemon Company
    if not any(h.split(".")[0] in low or h in low or (own and h.split(".")[0] in ("pokemon", "pokemonxp")) for h in hosts):
        return ["credit does not name the site the picture comes from (%s)" % ", ".join(sorted(hosts))]
    return []


def check_commons(file_name, rec_licence, info):
    """info: Commons API facts {licence, author, mime, nonfree, restrictions} for the file, or None.  -> reasons it fails."""
    if not info:
        return ["Commons has no file page for %s" % file_name]
    why = []
    if not FREE.match(info.get("licence", "")):
        why.append("licence on Commons is not a free one (%s)" % (info.get("licence") or "none"))
    if not info.get("mime", "").startswith("image/") or "svg" in info.get("mime", ""):
        why.append("Commons file is not a raster photo (%s)" % info.get("mime"))
    if info.get("nonfree"):
        why.append("Commons marks the file non-free")
    if info.get("restrictions"):
        why.append("Commons lists restrictions: " + info["restrictions"][:60])
    if not info.get("author"):
        why.append("no author on the Commons file page")
    return why


def verdict(image_url, image_reasons, page_reasons, licence_reasons, dup_reason="", passed_by=""):
    why = list(image_reasons) + list(page_reasons) + list(licence_reasons) + ([dup_reason] if dup_reason else [])
    return {"image": image_url, "verdict": "review" if why else "pass", "reasons": why, **({"how": passed_by} if passed_by and not why else {})}


# ------------------------------------------------------------------------------------------------ stored verdicts + what the catalogue builders ask
def load_verdicts(path=None):
    try:
        with open(path or VERDICTS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"day": "", "items": {}}


def save_verdicts(data, path=None):
    with open(path or VERDICTS, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1, sort_keys=True)
        f.write("\n")


class Gate:
    """What the catalogue builders ask: ok(key, image_url) -> (True, '') or (False, why)."""

    def __init__(self, game, path=None, owner_yes=None):
        self.items = load_verdicts(path)["items"]
        if owner_yes is None:
            try:
                owner_yes = {it["item_id"]: (it["final"] or {}).get("picture") for it in reviewlist.items("confirmed", game, KIND) if it["answer"] == "yes"}
            except Exception:  # noqa: BLE001  (no review list on this machine: nothing was answered)
                owner_yes = {}
        self.owner_yes = owner_yes

    def ok(self, key, url):
        v = self.items.get(key)
        if self.owner_yes.get(key) and self.owner_yes[key] == url:
            return True, ""
        if v is None or v.get("image") != url:
            return False, "picture not verified yet"
        if v["verdict"] == "pass":
            return True, ""
        return False, "; ".join(v["reasons"])[:200] or "picture check failed"


def put_on_review(game, key, name, url, source_page, reasons):
    """A picture that failed or could not be confirmed waits on the owner's review list."""
    return reviewlist.add_item(KIND, game, key, "Is this the right picture of %s? It is not shown yet: %s." % (name, "; ".join(reasons)[:300]),
                               before={"picture": "No picture yet"}, after={"picture": url, "from": source_page}, source="automatic picture check")


def _apply(item, ans, value, ctx):
    return "picture accepted by the owner (shown from the next catalogue rebuild)" if ans in ("yes", "value") else "picture not used"


reviewlist.register(KIND, apply=_apply)
