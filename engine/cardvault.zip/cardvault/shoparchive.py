"""Toys a shop no longer sells, read back from the Internet Archive.

A shop's own product feed (see collectibles.ShopifyToyProvider) lists only what it sells NOW: when a convention exclusive or a limited run is gone, so is its page - and the toy drops out of the
feed for good.  The Internet Archive (web.archive.org, free and public) saved most of those pages while they were up, so the name, price, pictures and the first day each toy was seen can be read back
from there.  What comes out looks like one product of the shop's own feed, so the same rules (which products are toys, which line, how the edition is named) apply to it unchanged.

Polite use: two questions for the list of saved pages per shop, then ONE page at a time with a pause, and every page already read is kept in a file beside the list so it is only ever asked for once.
Only the shop's own words and the addresses of its pictures are kept (the pictures stay on the shop's server)."""
import html
import json
import os
import re
import time
from urllib.parse import quote, unquote, urlencode

from . import sync

CDX = "https://web.archive.org/cdx/search/cdx"
PAGE = "https://web.archive.org/web/{ts}id_/{url}"            # id_ = the page exactly as the shop sent it
PAUSE = 0.8                                                    # seconds between two pages
_NOT_PRODUCT = re.compile(r"not a physical product|you will not receive anything|digital (?:download|product)|gift card", re.I)


def handle_of(url):
    """'https://shop.example/products/some-toy?variant=1' -> 'some-toy' (None for anything that is not a plain product page)."""
    if "/products/" not in url:
        return None
    h = unquote(url.split("/products/", 1)[1].split("?")[0].split("#")[0]).strip("/")
    return h if h and "/" not in h and not h.endswith((".js", ".json", ".xml", ".atom")) else None


def _fetch(url):
    return sync._get(url, as_json=False)


def saved_pages(host, get=None, pattern=None):
    """{handle: (first saved, last saved)} - the product pages of `host` the archive has a good copy of, as 14-digit timestamps.  Two questions: the first copy of each page, then the newest.
    `pattern` (a regular expression) keeps only the addresses that match it: a big shop's pages about one toy line."""
    get = get or _fetch
    out = {}
    for newest in (False, True):
        params = {"url": f"{host}/products/*", "output": "json", "fl": "original,timestamp", "filter": ["statuscode:200", "mimetype:text/html"] + ([f"original:{pattern}"] if pattern else []), "collapse": "urlkey"}
        if newest:
            params["sort"] = "reverse"
        rows = json.loads(get(CDX + "?" + urlencode(params, doseq=True)) or b"[]")
        for original, ts in rows[1:]:
            h = handle_of(original)
            if h:
                first, last = out.get(h, (None, None))
                out[h] = (first or ts, ts) if newest else (ts, last or ts)
    return out


def _metas(text):
    """[(property or name, content)] of every <meta> tag on the page, whatever order the tag writes its attributes in."""
    out = []
    for tag in re.findall(r"<meta\b[^>]*>", text):
        a = {k.lower(): html.unescape(v) for k, v in re.findall(r'([\w:-]+)\s*=\s*"([^"]*)"', tag)}
        if "content" in a and (a.get("property") or a.get("name")):
            out.append((a.get("property") or a.get("name"), a["content"]))
    return out


def _first(metas, prop):
    return next((v for k, v in metas if k == prop), "")


_SIZE = re.compile(r"_(?:\d{2,4}x\d{0,4}|x\d{2,4})(?=\.\w+(?:\?|$))")


def _bigger(src):
    """A picture address as the shop's server keeps the original: https, without the '_1200x1200' size the page asked for."""
    return _SIZE.sub("", re.sub(r"^http://", "https://", src.split("#")[0]))


def _shop_meta(text):
    """The product record a Shopify theme writes into the page ('var meta = {"product": {...}}'), or {}."""
    i = text.find("var meta = ")
    if i < 0:
        return {}
    try:
        return (json.JSONDecoder().raw_decode(text[i + len("var meta = "):])[0] or {}).get("product") or {}
    except ValueError:
        return {}


def parse_page(text, handle, first, last, host=""):
    """One saved shop page -> a product the way the shop's own feed shows it (None when the page is not a product, or not a physical one)."""
    metas = _metas(text)
    if "product" not in _first(metas, "og:type"):
        return None
    title, body = _first(metas, "og:title").strip(), _first(metas, "og:description").strip()
    if not title or _NOT_PRODUCT.search(title + " " + body):
        return None
    shop = _shop_meta(text)
    price = _first(metas, "og:price:amount")
    cents = ((shop.get("variants") or [{}])[0]).get("price")
    if not price and isinstance(cents, (int, float)):
        price = "%.2f" % (cents / 100.0)
    pictures = [v for k, v in metas if k == "og:image:secure_url"] or [v for k, v in metas if k == "og:image"]
    images = list(dict.fromkeys(_bigger(u) for u in pictures))
    return {"id": f"archive:{host}:{handle}", "handle": handle, "title": title, "body_html": body, "tags": [], "product_type": shop.get("type") or "", "vendor": shop.get("vendor") or "",
            "images": [{"src": u} for u in images], "variants": [{"price": price, "available": False}],
            "published_at": f"{first[:4]}-{first[4:6]}-{first[6:8]}T00:00:00", "_archive": {"first": first, "last": last, "host": host}}


def load_cache(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_cache(path, cache):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
    except OSError:
        pass


def _head(url):
    return sync._session().head(url, timeout=15, allow_redirects=True).status_code


def alive(url, known, head=None):
    """Does the picture still load?  `known` ({address: yes / no}) keeps what was found out, so a picture is asked about once; a shop that cannot be asked counts as alive."""
    if url not in known:
        try:
            known[url] = (head or _head)(url) < 400
        except Exception:  # noqa: BLE001 - not being able to tell is not a reason to drop a picture
            return True
    return known[url]


def living(images, known, head=None, look=3):
    """The pictures of an old page that still load.  A page's pictures often died with its product (the shop deletes them): the first `look` are asked about, and the rest are dropped."""
    return [i for i in (images or [])[:look] if i.get("src") and alive(i["src"], known, head)]


LIST_EVERY = 7 * 86400                                          # the list of saved pages changes slowly: once a week is plenty


def cached_products(cache, known=()):
    """The toys already read (and kept in `cache`) that the shop's own feed does not have, oldest first."""
    got = [v for k, v in cache.items() if not k.startswith("_") and v and k not in known]
    return sorted(got, key=lambda p: (p["_archive"]["first"], p["handle"]))


def recover(host, known, cache, get=None, limit=40, pause=None, cancel=None, progress=None, skip=None, pattern=None):
    """The products `host` no longer lists: every saved page not among the `known` handles is read (at most `limit` new pages this time, oldest first) and kept in `cache` ({handle: product, or {} for a
    page that was not a toy product}).  `skip(handle)` says which pages are not worth reading (a pin, a T-shirt: the address already tells); `pattern` limits the shop's pages to some addresses (see saved_pages).  -> all the toys found so far, oldest first.
    A network failure never loses what was read before: it just stops, and the next run goes on.  Once everything has been read the list of saved pages is not asked for again for a week (cache['_listed'])."""
    get = get or _fetch
    pause = PAUSE if pause is None else pause
    if time.time() - cache.get("_listed", 0) < LIST_EVERY:
        return cached_products(cache, known)
    pages = saved_pages(host, get, pattern)
    todo = [h for h in sorted(pages, key=lambda h: pages[h][0]) if h not in known and h not in cache and not (skip and skip(h))]
    for n, h in enumerate(todo[:limit]):
        if cancel is not None and cancel.is_set():
            return cached_products(cache, known)
        if progress:
            progress(f"Reading old shop pages ({n + 1} of {min(limit, len(todo))})…", n, min(limit, len(todo)))
        first, last = pages[h]
        try:
            raw = get(PAGE.format(ts=last, url=f"https://{host}/products/{quote(h, safe='')}"))
        except RuntimeError:
            return cached_products(cache, known)                                   # the archive is busy or away: what is already in the cache is kept, the rest comes next time
        cache[h] = parse_page(raw.decode("utf-8", "replace"), h, first, last, host) if raw else {}
        if pause:
            time.sleep(pause)
    if len(todo) <= limit:
        cache["_listed"] = time.time()
    return cached_products(cache, known)


# ------------------------------------------------------------------------------------------------ other shops' titles
# A retailer writes the same toy as 'Abominable Toys Chomp - Electric Purple Skeleton Glow Edition /450 made - Plastic Empire Exclusive [Box condition 8/10]': the toy's own name is in there somewhere.
_HOLDERS = (r"plastic empire|toy temple|7 ?bucks ?a ?pop|7bap|kid ?robot|rotofugi|japan ?la|hot topic|fye|stormy vault|entertainment earth|mondo(?:con)?|sdcc|nycc|c2e2|eccc|dcon|designer ?con|wonder ?con|"
            r"dragon ?con|emerald city|creature club|lucasfilm|kickstarter|hobbydb|boxlunch|target|walmart|gamestop|amazon|thinkgeek|big bad toy store|bbts|toynk|barnes & noble|convention|online")
_EXCLUSIVE = re.compile(r"(?P<who>%s)(?: con)?(?:\s+\d{4})?\s+exclusive|exclusive\s+(?:to|at|from)\s+(?P<who2>%s)" % (_HOLDERS, _HOLDERS), re.I)
_NOISE = re.compile(r"box condition[^-\[(]*|\blimited(?:\s+edition)?\s+\d[\d,]*\b|\bltd\.?\s*ed\.?(?:\s+\d[\d,]*\b)?|\b(?:in stock|sold out|pre-?order|brand new|new in box|officially licensed|limited edition)\b|\b\d+\s*/\s*10(?: or better)?|/\s*\d[\d,]*(?:\s*(?:pcs|pieces|made))?|"
                    r"\b\d[\d,]*\s*(?:pcs|pieces|made)\b|\ble\s*\d+\b|chomp\s*#\d+|#\d+|\babominable toys\b|100%\s*soft|\bfrozen culture x\b|\bx abominable toys\b", re.I)


_SHOW = re.compile(r"\b(?:sdcc|nycc|c2e2|eccc|dcon|designer ?con|wonder ?con|emerald city(?: comic con)?)\b(?:\s+20\d\d\b)?|\b20\d\d\s+(?:sdcc|nycc|c2e2|eccc|dcon|designer ?con|wonder ?con)\b", re.I)          # a convention and its year: where it was sold, not the toy's name


_CHASE = re.compile(r"\*{0,2}\bshot at\s+(?:a\s+|the\s+)?(?:\w+\s+)?chase\b!?\*{0,2}|\b\d+\s*:\s*\d+\s*chance\b(?:\s+at\s+(?:a\s+|the\s+)?chase)?|\bw/\s*chance\b.*$", re.I)          # '1:9 Chance at Chase', 'Shot at Chase!'


def toy_title(title):
    """A retailer's long product title -> the toy's own name, ready for collectibles.short_name ('Abominable Toys Chomp - Electric Purple Skeleton Glow Edition /450 made - Plastic Empire Exclusive'
    -> 'Chomp - Electric Purple Skeleton Glow Edition'); the retailer's own words (who it is exclusive to, stock, condition, how many were made) are left out."""
    t = re.sub(r"\[[^\]]*\]|\*\*[^*]*\*\*", " ", html.unescape(title or "")).replace("�", " ").replace("*", " ")
    t = _NOISE.sub(" ", t)
    t = _EXCLUSIVE.sub(" ", t)
    t = _SHOW.sub(" ", _CHASE.sub(" ", t))
    t = re.sub(r"\bexclusive\b|\bmax\s*\d+\s*per\s*(?:household|person|customer)\b|\(\s*[,\s]*\)|\bby\s*(?=[-–|:]|$)", " ", t, flags=re.I)
    t = re.sub(r"\s+[-–|:]+\s+", " - ", t)
    t = re.sub(r"(?:\s*-\s*){2,}", " - ", t)
    t = re.sub(r"\s+x\s*$", "", t.strip(" -–|:,"), flags=re.I)                   # 'Chomp #195 Chris Squink X Abominable Toys': what is left of 'X <the maker>' once the maker's name is gone
    return re.sub(r"\s+", " ", t).strip(" -–|:,")


_RUN = re.compile(r"(?:(?<=\s)|^)/\s*(\d[\d,]*)|\ble\s*(\d[\d,]*)\b|\blimited(?:\s+edition)?\s+(\d[\d,]*)\b|\bltd\.?\s*ed\.?\s+(\d[\d,]*)\b|\b(\d[\d,]*)\s*(?:pcs|pieces|made)\b", re.I)


def edition_of(title):
    """How many were made, as a shop writes it in a title ('/450 made', 'LE 500', 'Limited Edition 250', 'Ltd Ed 300', '240 pieces'), or None (a year is not a count, and neither is a box condition like 8/10)."""
    for m in _RUN.finditer(html.unescape(title or "")):
        n = int(next(g for g in m.groups() if g).replace(",", ""))
        if n >= 2 and not 1990 <= n <= 2035:
            return n
    return None


def exclusive_of(title):
    """Who a title says the toy is exclusive to ('... - Plastic Empire Exclusive', '[Toy Temple Exclusive]', 'Kid Robot Exclusive', 'exclusive to Rotofugi'), as the shop writes it, or ''."""
    m = _EXCLUSIVE.search(html.unescape(title or ""))
    return re.sub(r"\s+", " ", (m.group("who") or m.group("who2"))).strip() if m else ""
