"""What the deck builder needs to know about a card, read from the game's own card list (cards.db): its section (Pokémon / Trainer / Energy; Leader / Characters / Events / Stages /
DON!!), its "play key" (the cards that are the same card for deck rules: Pokémon by name, One Piece by card number), its regulation mark, colours and cost.
Nothing here guesses beyond the list: a field the list doesn't have is left empty and the rules that need it say so."""
import json
import re

from . import deckcards_tcg

POKEMON_SECTIONS = ("Pokémon", "Trainer", "Energy", "Other")
ONEPIECE_SECTIONS = ("Leader", "Characters", "Events", "Stages", "DON!!", "Other")
_OP_SECTION = {"leader": "Leader", "character": "Characters", "event": "Events", "stage": "Stages", "don!!": "DON!!", "don": "DON!!"}
_BASIC_ENERGY = re.compile(r"^(basic\s+)?(grass|fire|water|lightning|psychic|fighting|darkness|metal|fairy|dragon|colorless)\s+energy$", re.I)


def sections(game):
    return {"onepiece": ONEPIECE_SECTIONS, "yugioh": deckcards_tcg.YGO_SECTIONS, "mtg": deckcards_tcg.MTG_SECTIONS, "unionarena": deckcards_tcg.UA_SECTIONS}.get(game, POKEMON_SECTIONS)


def norm_name(name):
    """'Basic {L} Energy', curly quotes and spacing don't make a different card."""
    n = (name or "").replace("’", "'").replace("é", "e").replace("É", "E")
    return " ".join(n.lower().split())


def is_basic_energy(info):
    if info.get("energy_type"):
        return info["energy_type"].lower() == "normal"
    return bool(_BASIC_ENERGY.match((info.get("name") or "").strip()))


def play_key(game, name, number):
    """The cards that are the same card for the deck rules: One Piece by card number, the others by name ('Basic Fire Energy' = 'Fire Energy'; a printing's '(Alternate Art)' label is dropped)."""
    if game == "onepiece" and number:
        return str(number).upper()
    if game == "unionarena":                                                # (by card number, like describe_ua: each number is its own card)
        return deckcards_tcg.ua_number(number) or deckcards_tcg.strip_tail(name).lower()
    if game in ("yugioh", "mtg"):
        return norm_name(deckcards_tcg.strip_tail(name))
    return norm_name(re.sub(r"^basic\s+", "", name or "", flags=re.I))


def _raw(text):
    try:
        d = json.loads(text) if text else {}
        return d if isinstance(d, dict) else {}
    except ValueError:
        return {}


def _pokemon_section(cat, name):
    c = (cat or "").lower().replace("é", "e")
    if c.startswith("pokemon"):
        return "Pokémon"
    if c.startswith("trainer"):
        return "Trainer"
    if c.startswith("energy") or (not c and (name or "").strip().lower().endswith(" energy")):
        return "Energy"
    return "Other"


def _op_cost(ext):
    for k in ("Cost", "Cost ", "cost"):
        if str(ext.get(k) or "").strip().isdigit():
            return int(str(ext[k]).strip())
    return None


def info_for(v, ids):
    """{card_id: info} for these cards of the open game."""
    ids = [str(i) for i in ids]
    out = {}
    for i in range(0, len(ids), 500):
        part = ids[i:i + 500]
        q = (f"SELECT c.id, c.name, c.set_id, c.local_id, c.category, c.stage, c.types, c.rarity, c.price_usd, c.description, c.raw, s.name AS set_name, s.serie, s.release_date "
             f"FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id IN ({','.join('?' * len(part))})")
        for r in v.conn.execute(q, part):
            out[r["id"]] = describe(v.game, dict(r))
    return out


def describe(game, r):
    raw = _raw(r.get("raw"))
    info = {"id": r["id"], "name": r.get("name") or "", "set_id": r.get("set_id") or "", "set_name": r.get("set_name") or "", "serie": r.get("serie") or "",
            "number": str(r.get("local_id") or ""), "rarity": r.get("rarity") or "", "price": r.get("price_usd"), "date": r.get("release_date") or "",
            "colors": [t.strip() for t in re.split(r"[,;/]", r.get("types") or "") if t.strip()]}
    if game == "onepiece":
        ext = raw.get("ext") or {}
        cat = (r.get("category") or ext.get("CardType") or "").strip().lower()
        info.update(section=_OP_SECTION.get(cat, "Other"), key=play_key(game, info["name"], info["number"]), cost=_op_cost(ext))
    elif game == "yugioh":
        deckcards_tcg.describe_ygo(info, raw, r.get("category"))
        info["key"] = play_key(game, info["name"], "")
    elif game == "unionarena":
        deckcards_tcg.describe_ua(info, raw, r.get("category"))
    elif game == "mtg":
        deckcards_tcg.describe_mtg(info, raw.get("ext") or {}, r.get("description") or "")
        info["key"] = play_key(game, info["name"], "")
    else:
        info.update(section=_pokemon_section(r.get("category") or raw.get("category"), info["name"]), key=play_key(game, info["name"], ""),
                    stage=(r.get("stage") or raw.get("stage") or ""), mark=(raw.get("regulationMark") or "").strip().upper(), energy_type=raw.get("energyType") or "",
                    trainer_type=raw.get("trainerType") or "", legal=raw.get("legal") if isinstance(raw.get("legal"), dict) else {})
    return info


NOT_IN_SIZE = ("Leader", "DON!!", "Action Points")            # the lines that do not count toward the deck's size (One Piece Leader and DON!!, Union Arena's Action Point cards)


# ------------------------------------------------------------------------------------------------ groups (how the builder screen files a card)
_GROUP_IDS = {"Extra Deck": "extra"}
SIDE_LABEL = {"yugioh": "Side Deck", "mtg": "Sideboard"}


def group_id(game, c, zone="main"):
    """The pile a card is shown in: Yu-Gi-Oh! Monsters / Spells / Traps / Extra Deck / Side Deck; Magic Commander / Creatures ... Lands / Sideboard.  None for the games that just show their sections."""
    if game not in ("yugioh", "mtg"):
        return None
    if zone == "side":
        return "sidedeck" if game == "yugioh" else "sideboard"
    if zone == "cmd":
        return "commander"
    return _GROUP_IDS.get(c["section"], c["section"].lower())


def groups(game):
    """[(id, English label)] in the order the screen lists them (the label is the fallback when a language has no word for the id)."""
    if game == "yugioh":
        return [(_GROUP_IDS.get(s, s.lower()), s) for s in deckcards_tcg.YGO_SECTIONS] + [("sidedeck", SIDE_LABEL["yugioh"])]
    if game == "mtg":
        return [("commander", "Commander")] + [(s.lower(), s) for s in deckcards_tcg.MTG_SECTIONS] + [("sideboard", SIDE_LABEL["mtg"])]
    return [(None, s) for s in sections(game)]
