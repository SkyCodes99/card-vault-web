"""Magic decklists as text, the way Arena (MTGA), Magic Online (MTGO) and the deck sites share them.
    Arena   "Commander" / "Deck" / "Sideboard" headers, "4 Lightning Bolt (M10) 146" lines (the set and number are read when they match a print, otherwise the name decides)
    MTGO    "4 Lightning Bolt" lines, a blank line, then the sideboard (or "SB: 2 Name" lines)
Export writes the plain name form both read.  Lines that aren't a card line (About, Name ...) are skipped; a card that isn't in the list comes back as it was written."""
import re

from . import deckcards_tcg, decklookup, deckzones

_HEADERS = {"deck": deckzones.MAIN, "main": deckzones.MAIN, "main deck": deckzones.MAIN, "mainboard": deckzones.MAIN, "sideboard": deckzones.SIDE, "side": deckzones.SIDE,
            "side board": deckzones.SIDE, "companion": deckzones.SIDE, "commander": deckzones.CMD, "maybeboard": None, "considering": None}
_LINE = re.compile(r"^(?:SB:\s*)?(\d{1,3})\s*[xX]?\s+(.+?)(?:\s+\(([A-Za-z0-9]{2,6})\)(?:\s+([A-Za-z0-9★-]+))?)?(?:\s+\*[A-Za-z]\*)?$")


def export(deck, info):
    zoned = deckzones.split(deck)
    parts = []
    for z, head in ((deckzones.CMD, "Commander"), (deckzones.MAIN, "Deck"), (deckzones.SIDE, "Sideboard")):
        merged = {}
        for cid, n in zoned[z].items():
            c = info.get(cid)
            if c:
                name = deckcards_tcg.strip_tail(c["name"])
                merged[name] = merged.get(name, 0) + n
        if merged:
            parts.append(head + "\n" + "\n".join(f"{n} {name}" for name, n in sorted(merged.items(), key=lambda x: (-x[1], x[0]))))
    return "\n\n".join(parts) + "\n"


def parse(v, text):
    """-> {cards: {key: copies}, unmatched: [line], lines: card lines read}.  Keys carry the zone (deckzones)."""
    raw = [ln.rstrip() for ln in (text or "").splitlines()]
    has_head = any(ln.strip().rstrip(":").lower() in _HEADERS for ln in raw)
    cards, unmatched, count = {}, [], 0
    zone, seen_card, blank_after = deckzones.MAIN, False, False
    for ln in raw:
        s = ln.strip()
        if not s:
            blank_after = seen_card
            continue
        head = s.rstrip(":").lower()
        if head in _HEADERS:
            zone, blank_after = _HEADERS[head], False
            continue
        m = _LINE.match(s)
        if not m:
            continue
        if blank_after and not has_head:
            zone = deckzones.SIDE                                    # (the MTGO form: the blank line starts the sideboard)
        blank_after = False
        if s.upper().startswith("SB:"):
            use = deckzones.SIDE
        else:
            use = zone
        if use is None:
            continue
        seen_card = True
        count += 1
        cid = decklookup.by_name(v, m.group(2), m.group(4) or "")
        if cid:
            k = deckzones.key(use, cid)
            cards[k] = cards.get(k, 0) + int(m.group(1))
        else:
            unmatched.append(s)
    return {"cards": cards, "unmatched": unmatched, "lines": count}
