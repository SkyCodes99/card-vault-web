"""The permanent price archive on Card Data (https://.../history/<game>/<YYYY-MM>.json.gz): one price per product per day, kept forever.
Your own saved prices stay exactly as they are; the archive only fills in days you did not capture yourself (before you owned a card, or while the app was closed), so a
card's graph can reach back as far as the archive does the moment you add it."""
import datetime
import gzip
import json


def _get(url, timeout=40):
    import requests
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "CollectEmAll/3 (price history)"})
    if r.status_code != 200:
        return None
    return r.content


def _months(first, last):
    y, m = int(first[:4]), int(first[5:7])
    ly, lm = int(last[:4]), int(last[5:7])
    while (y, m) <= (ly, lm):
        yield f"{y:04d}-{m:02d}"
        m += 1
        if m > 12:
            y, m = y + 1, 1


def backfill(svc, get=None):
    """Fill the saved price history of the cards and sealed products you track from the archive (open game only).  Returns how many daily prices were added."""
    from . import carddata
    get = get or _get
    v = svc.vault
    if v is None or svc.session is None and not getattr(svc, "guest", False):
        return 0
    base = (svc.cfg.get("carddata_url") or carddata.BASE).rstrip("/") + "/history"
    raw = get(base + "/manifest.json")
    if not raw:
        return 0
    man = json.loads(raw.decode("utf-8"))
    g = (man.get("games") or {}).get(v.game)
    if not g or not g.get("first"):
        return 0
    # what is tracked: cards owned or wished for (by their TCGplayer product id), and the sealed products owned (by name)
    ids = list(v.tracked_card_ids())
    by_pid = {}
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        for cid, tid in v.conn.execute(f"SELECT id, tcg_id FROM cards WHERE id IN ({','.join('?' * len(chunk))}) AND tcg_id IS NOT NULL AND tcg_id != ''", chunk):
            by_pid[str(tid)] = cid
    try:
        from .tcgcsv import norm_name
        for (name,) in v.conn.execute("SELECT DISTINCT name FROM u.sealed WHERE user_id=? AND game=? AND deleted=0", (v.user_id, v.game)).fetchall():
            r = v.conn.execute("SELECT id FROM sealed_products WHERE norm=? ORDER BY price_updated DESC LIMIT 1", (norm_name(name),)).fetchone()
            if r:
                by_pid[str(r[0])] = "sealed:" + norm_name(name)
    except Exception:  # noqa: BLE001 - a game with no sealed list
        pass
    if not by_pid:
        return 0
    done_key = "price_archive_done_" + v.game
    done = svc.pget(done_key) or ""
    added = 0
    last = g.get("last") or datetime.date.today().isoformat()
    for month in _months(max(g["first"], done[:7] + "-01") if done else g["first"], last):
        blob = get(f"{base}/{v.game}/{month}.json.gz")
        if not blob:
            continue
        try:
            shard = json.loads(gzip.decompress(blob).decode("utf-8"))
        except (OSError, ValueError):
            continue
        days = shard.get("days") or []
        items = shard.get("items") or {}
        for pid, cid in by_pid.items():
            series = items.get(pid)
            if not series:
                continue
            for day, usd in zip(days, series):
                if usd is None:
                    continue
                cur = v.conn.execute("INSERT OR IGNORE INTO u.price_history VALUES(?,?,?,?,?)", (v.game, cid, day, usd, None))
                added += cur.rowcount or 0
    v._commit()
    svc.pset(done_key, last)
    return added
