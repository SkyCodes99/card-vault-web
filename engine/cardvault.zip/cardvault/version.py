APP_NAME = "Collect Em All"
VERSION = "3.22.1"

CHANGELOG = [
    ("3.22.1", [
        "Card lists and prices arrive sooner: the app used to update only one game's card list per check (and check twice a day), so Pokemon could wait a day or more behind the others, which is why newer prices like the 30th Celebration ones could take so long to show. It now updates every game that has news, the game you are looking at first, one after another.",
        "The sign-in card shows your username, also on devices that signed in before the change.",
        "Celebrations Classic Collection prices added (24 of 25 cards).",
    ]),
    ("3.22.0", [
        "Your username, not your email: the sign-in card, the top bar and your profile now show your username. The name this device uses for you follows your username automatically, and the email is no longer shown next to it.",
        "Profile pictures: Settings > Your profile > 'Add a picture…'. Pick a picture up to 2 MB, it is shrunk automatically, then drag to position it and zoom to fit it in the circle. It shows in the top bar and on the sign-in card, and follows you to your other devices.",
        "TCG Pocket cards in the Art categories: a new 'TCG Pocket illustrated cards' group holds the 720 star, shiny and crown cards of Pokemon TCG Pocket (for example Meowth from Fantastical Parade, Genetic Apex, Extradimensional Crisis and Mega Rising), and they now count as Art cards too.",
    ]),
    ("3.21.0", [
        "Better search: it now ignores capitals and accents (typing 'pokemon' finds Pokémon, 'farfetchd' finds Farfetch'd), understands card numbers written as #4, 4/102 or 006/165, and puts cards whose name is exactly what you typed first. The 'Search everything' window also takes your typing straight away.",
        "Sealed products by era: for Pokemon, Browse all products now has a button for each era (Original, EX, Diamond & Pearl to HeartGold, Black & White, XY, Sun & Moon, Sword & Shield, Scarlet & Violet, Mega Evolution) with how many products each holds. The other games keep all their sealed products together.",
    ]),
    ("3.20.2", [
        "Prices for the whole Pokemon 30th Celebration: all 188 cards (including the 30 Classic Collection reprints) now have a TCGplayer price.",
    ]),
    ("3.20.1", [
        "Safer updates: if a problem is ever found in the newest version, the app can offer to go back to the previous one with a clear 'A problem was found in the newest version. Go back to ...?' message. It never goes back on its own, and your collection is never rolled back.",
    ]),
    ("3.20.0", [
        "More prices: 560 more Pokemon cards (promos, trainer kits and older sets) now have a TCGplayer price, found by matching each card's name and number. Digital TCG Pocket cards now say 'Digital card' instead of 'No price', because they are not sold as real cards.",
        "Pokemon cards by era: a new 'By era' list splits every card into Original (1999-2003), EX, Diamond & Pearl to HeartGold, Black & White, XY, Sun & Moon, Sword & Shield, Scarlet & Violet and Mega Evolution - plus one 'Before Sword & Shield' group with the whole older era together.",
    ]),
    ("3.19.0", [
        "Set logos for the card games that had none: every set box now shows its logo - One Piece (38 sets, including the release-event sets that share their main set's logo), Union Arena (57), Yu-Gi-Oh! (161) and Dragon Ball Super (64). Sets without a logo keep their name.",
    ]),
    ("3.18.0", [
        "Two missing Pokemon sets added: Prize Pack Series Cards (849 cards) and World Championship Decks (1,717 cards), with TCGplayer prices and pictures.",
        "Phones: the whole page now scrolls, so the card grid gets the whole screen instead of being squeezed under the filters.",
        "Sale Data prices start filling in: the website now saves prices every day, and the app picks up the recent-price trend as soon as there are a couple of days of history.",
    ]),
    ("3.17.0", [
        "Sign-in fix: after you sign in, the top bar, menus and banners now update at once and stop asking you to sign in. A hiccup while checking your sign-in can no longer make the app think you were signed out.",
        "Sale Data prices: Settings > Prices lets you show Standard (TCGplayer market), Sale Data (a recent typical price with a rising / falling arrow, worked out from prices saved every day) or Both. It is a trend, not a list of actual sales, and it fills in once a few days of prices are saved.",
        "Save a backup file: Settings > Backups & safety > 'Save a backup file…' puts everything (every game, lists, photos, settings) in one file locked with a password you choose. Restore it on any device from the same place.",
        "A friendly welcome asks you once to make your account your home, so your collection is saved to the cloud and follows you everywhere.",
    ]),
    ("3.16.0", [
        "Prices you can see: every card in the Cards grid and in your lists now shows its price under the picture. A * means it is a different kind of price (for example the middle price), and hovering tells you which. Cards with no price say 'No price'.",
        "Sealed products catalog: on the Sealed page, 'Browse all products' lists about 9,000 boxes, packs, bundles and decks with their pictures and TCGplayer prices. Click one to add it to your collection with the price filled in, and 'My sealed products' now shows what each one is worth now.",
        "Show / hide password: every password box has an eye button to see what you typed.",
        "Forgot your password? You can now come back in three ways: your recovery key (everything returns), a 2-step code from your authenticator app, or an emailed code. The last two restore your account but start its cloud copy empty, and the screen says so and asks you to confirm first.",
        "Change your email address: Settings > Your account > Email address. (It says 'isn't available yet' until email sending is switched on.)",
        "If creating an account fails, the screen now says plainly 'Your account was NOT created' and why.",
    ]),
    ("3.15.0", [
        "More prices: about 12,500 cards that had no price now show one (all of Japanese Pokemon, plus gaps in Pokemon, Dragon Ball Super, Yu-Gi-Oh!, One Piece and Union Arena). When there is no market price the app uses the price of another printing, or TCGplayer's mid or low price, and says so on the card. Cards that really have no price now say why instead of just 'no price'.",
        "Two-step sign-in: Settings > Your account > Two-step sign-in shows a QR code to scan with your authenticator app (the code is drawn on your device), with the typed key as a backup.",
        "Clearer accounts: if you are not signed in to a cloud account, every screen now says so plainly and offers 'Create your account' first (with an optional username). After creating it you are offered to save your collection to it right away, and if a sign-in ends you are told 'Your session ended - sign in again'.",
        "A new look for the main screen: a top bar with the game switcher, a Cards | Sealed switch and 'Search everything' (Ctrl+K), which searches every game at once and opens a result in its own game. Sealed products now have their own space. On phones there is a thumb-friendly tab bar with the scanner in the middle.",
    ]),
    ("3.14.1", [
        "Your username is now easy to find: Settings opens with 'Your profile', showing your username with an Edit button, a live check that the name is free, and a clear message if it is taken. Click your name in the sidebar to jump straight to it.",
        "Plainer wording everywhere: technical and behind-the-scenes terms are gone from the screens, messages and release notes. Settings now has a simple 'Cloud saving' section, and connection problems say 'we'll keep trying' instead of showing error details.",
    ]),
    ("3.14.0", [
        "Art categories fixed and explained: 'Scene art' now only holds cards whose picture is one illustrated scene. Rainbow, shiny and Mega EX full arts (like Venusaur & Snivy-GX or the shiny Charizard V) are no longer counted as art, and 62 genuine alternate arts that were missing are now included. Every category has a plain-English description.",
        "More card pictures: 6,777 cards that had no picture (1,370 English and 5,407 Japanese Pokemon cards) now show one.",
        "Cloud saving is impossible to miss: if a computer only holds your collection locally, the bottom bar says 'Only on this device - turn on cloud saving' and a banner offers one-tap sign-in. Once you have an account, every change is saved by itself a few seconds after you make it.",
        "Username box in Settings checks live whether a name is free.",
        "Card lists update by themselves: when a corrected or fuller card list is published, the app fetches it (twice a day) and keeps any newer prices it already had.",
    ]),
    ("3.13.0", [
        "A much smaller download: the old classic window has been retired for good, so the app is about half the size (the React screens you already use are the only edition).",
    ]),
    ("3.12.0", [
        "Usernames: everyone has one, shown as their name (a random one until they choose their own - you are asked once after signing in, and you can change it in Settings > Account). Sign in with your email OR your username. Your email is never shown to anyone, and usernames never reveal it.",
        "The public showcase page shows your username, never your email.",
        "Older accounts: sign in once with your email after this update and username sign-in switches on for them automatically.",
    ]),
    ("3.11.0", [
        "Stay signed in: tick 'Stay signed in on this device' when you sign in (or in Settings > Security) and the website and the Windows app open without asking for your password until you press Lock or change your password. The key is kept protected by the browser / Windows itself.",
        "The website opens straight to your sign-in card in your own theme; type your password right away and it unlocks as soon as the app has started.",
        "Everything you do is now saved to your account: spending log, value-over-time history, share links, photos of your copies, and your choices (currency, units, budget, portfolio name, showcase, reminders) all follow you to your other devices.",
        "A clear 'Saved to your account' time in the bottom bar, 'Saving...' while changes are on their way, and a warning with a Retry button if a save fails.",
    ]),
    ("3.10.0", [
        "Pick a username (optional) when you create your account, or later in Settings. It is shown as your name, and you can use it instead of your email to sign in.",
    ]),
    ("3.9.1", [
        "Fixed the Account card in Settings and the Scanner tab, which could spin forever instead of loading.",
        "The website now asks your browser to keep its saved data, and shows a warning in the bottom bar when this browser's collection is not backed up to an account.",
        "Price history is now saved after every price update (it could be skipped before).",
    ]),
    ("3.9.0", [
        "New look: smoother buttons and menus, a clearer sidebar, softer shadows, themed scroll bars, nicer pop-ups, and a floating bottom bar on phones.",
        "24 themes now (12 new: Sky, Rose, Citrus, Sand, Pokedex, Midnight, Nord, Mocha, Vampire, Cyber, Emerald, AMOLED, Dusk), plus your own accent colour, spacing (compact / normal / roomy) and corner style.",
        "Your look follows your account: choose a theme on the website and the phone and computer match. Turn on 'Use a different look on this device' to give any device its own.",
        "Fixed the website on phones, where the page could squeeze into a narrow strip.",
    ]),
    ("3.8.0", [
        "No more Games & downloads screen: every game's card list now comes from the website automatically, in seconds. Pick a game from the list at the top of the sidebar and its cards appear.",
        "All six games are on the website: Pokemon (English and Japanese), One Piece, Union Arena, Yu-Gi-Oh! and Dragon Ball Super.",
        "Updates never interrupt you: a new version downloads quietly and waits; you see 'Version X is ready' and choose when to reload.",
        "If the connection drops for a moment, saving waits and retries quietly instead of showing an error.",
    ]),
    ("3.7.1", [
        "Card pictures no longer have to live on your PC: a picture that isn't saved is downloaded when you look at that card and kept for next time.",
        "New Settings card 'Card pictures on this PC' shows how much room pictures take and can free it (you confirm first), or keep it under a size you choose automatically.",
    ]),
    ("3.7.0", [
        "Two new games: Yu-Gi-Oh! (46,000+ cards, 1st Edition / Unlimited printings) and Dragon Ball Super Card Game (11,000+ cards), with sets, rarities, pictures and market prices. Pick them in Games.",
        "The website has a 'Get the app' page (and a link on the sign-in screen) to download the Windows app.",
        "The website loads much faster after the first visit: the app files now come straight from the saved copy instead of being downloaded again each time.",
        "The Scanner tab opens instantly on the website and no longer keeps checking in the background.",
    ]),
    ("3.6.2", [
        "Simpler sign-up and sign-in: just your email and password (type the password twice only when creating an account). No separate name to type; the same password locks this device unless you choose a different one.",
    ]),
    ("3.6.1", [
        "Cloud accounts are on by default: the first screen offers 'I'm new - create my account', 'I already have an account' or 'Just this device'. Your collection is encrypted on your device before it is saved to your account.",
    ]),
    ("3.6.0", [
        "Cloud accounts: one email and password for the desktop app, website and phone. Your collection is encrypted before it leaves your device, so only you can read it. Settings > Account has sign in, your devices (sign a lost phone out), password change and recovery. Changes made on one device now show up on the others within seconds.",
        "Portfolio > Insights: a collection health score with tips, challenges (one of every type, every generation, rarity ladder...), a timeline of milestones and a year in review you can copy and share.",
        "Organize: dream binders to plan the binder you wish you had, sealed products (scan the barcode), and a Missing versions list for people hunting reverse holos and other versions (off unless you turn it on).",
        "Trade: a fairness check that uses recent price swings, and a trade link - send the other person a link and they see your deal from their side and can change it.",
        "Quick add: press Ctrl+K and type or say what you got ('two charizard from 151'). Scanner: Keep scanning mode goes through a pile hands-free. Finish a set: a shopping list grouped by price with search links.",
        "Condition photos on each copy (front, back, anything else), a cover card for your public showcase, an account activity log that now records exports and device links, text size / high contrast / reduce motion in Settings, and a guided tour that shows 'What's new' after updates.",
        "Faster: the classification of every card is saved, so big sets open noticeably quicker. Fixed: after another device's changes were pulled in they sometimes did not appear until the next edit.",
    ]),
    ("3.5.1", [
        "The website now has an 'I already use Collect Em All on another device' option on the first screen: paste the link code from Settings > Sync > Link another device and your collection comes over.",
        "In a checklist, clicking one of a Pokemon's card options now shows that card's picture and details (a 'Use this one' button picks it for the list), instead of staying on the default card.",
        "Fix: 'Install and restart' for updates now really works. The little helper that swaps in the new files and reopens the app was being started in a way that made Windows quit it at once, so the app closed and nothing came back. It now waits for the app to close completely, copies the new version in (retrying if a file is still busy), reopens Collect Em All, and if anything goes wrong it reopens the old version and leaves a note.",
    ]),
    ("3.5.0", [
        "Adding a card is now one click less: the card panel has the usual details right there (portfolio, how many, condition, price paid, date, where bought) and remembers your last choices. 'More...' opens the full form for graded copies and notes.",
        "A polish pass over the whole app: grouped navigation with a clear marker for where you are, softer cards and shadows, nicer buttons, inputs and tables, a sticky card panel, smoother hover effects, and the artwork of a card (not its title bar) as the picture of rarity, illustrator and Pokemon boxes.",
        "Fix (website / phone): the Sets screen could stay on the previous list because the set-picture list could not be read in the browser version. Set logos that fail to load now fall back to a banner.",
    ]),
    ("3.4.2", [
        "Scanner add-on: only the newest version is kept (on this PC and on the releases page), so the download and the folder never grow with each update.",
    ]),
    ("3.4.1", [
        "The scanner add-on now updates itself: when a newer scanner is available the Scanner tab offers 'Update the scanner'. It also finds a scanner installed on your Desktop.",
    ]),
    ("3.4.0", [
        "The program is now called Collect Em All (new name on the app, the Desktop files and the download files). Your settings and collection move over automatically the first time you start it.",
        "Portfolios: keep separate collections (for example Kids, Graded, Sealed), look at one, several together, or everything. Value is now the Portfolio tab with a big graph (1D to 2 years, All, or a custom range) that goes back to the date you bought each card.",
        "A Condition & grading guide (what Near Mint to Damaged mean, what PSA / BGS / CGC grades mean) is one click away when adding a card and in Settings.",
        "Adding cards: price paid, date purchased, where you bought it (card shop, card show...), condition, grading and notes - one card or many at once.",
        "Rarities: every card is filed under its exact rarity (Alt Art, Rainbow, Gold, Trainer Full Art, Radiant, Shining, Prism Star, Ancient Trait...) using the Art / Shiny rules from your spreadsheet and the Bulbapedia / PokeRip guides. Categories is now called Rarities.",
        "Sets: a Master set view shows every version of every card (with the normal size of the set kept beside it) and lets you add graded copies. Finish this set shows what is missing and exports it with picture and all the card info.",
        "Trade: a compact card picker, cash, extra items, percentage scenarios, a what-if table, matching suggestions, a trade log and notes.",
        "Better banners for boxes with no picture, the coolest card as the picture of each illustrator, Pokémon and rarity, and 27 more set logos (Collectr) plus your McDonald's 2023 and 2024 pictures.",
        "New Scanner tab (add-on): scan with the camera or photos, one card or a whole table, and add them to the portfolio you choose. New Showcase tab: make your collection public (opt-in) with a Top 10 by value, or open a friend's showcase.",
    ]),
    ("3.3.0", [
        "The website, phone and tablet apps now work exactly like the computer app, so every feature is the same everywhere: checklists, value, trade, exports (CSV, Excel, PDF), backups, undo and saving.",
        "One account everywhere: Settings > Sync > 'Link another device' makes a single code; paste it on a new device and your collection appears, end-to-end encrypted.",
        "PDF export no longer needs anything extra and works on Linux and macOS too. Set and card pictures load straight from the web in the browser version.",
        "Browser version: installable from the browser menu (Add to Home Screen / Install), works offline once loaded, and tells you when a new version is ready.",
    ]),
    ("3.2.1", [
        "Fix: syncing with a password-protected account now sends your real collection (it could read a wrong, empty file before). Please update.",
        "New: 12 colour themes (Settings > Appearance); a notification with Refresh / Update / Later when a new version is out; Linux and macOS downloads on the release page.",
    ]),
    ("3.2.0", [
        "Forgot your password? Turn on 'Reset by email' (Settings > Security) and a 6-digit code is emailed to you; enter it and choose a new password - your collection is kept. Off by default; the recovery key keeps working.",
        "New cardvault_service: the small account service that sends the codes (self-hosted, with rate limits, single-use codes and no way to read anyone's collection). See cardvault_service/README.md.",
    ]),
    ("3.1.0", [
        "Accounts and log-in: create a password-protected account on first start; your collection, backups and saved sign-ins are encrypted on disk (AES-256), with a recovery key, wrong-password lockouts, auto-lock and Lock now. Your existing collection is protected for you.",
        "Encrypted saving: what is saved to the cloud can only be read by your own devices. The phone has its own password lock.",
        "Tighter security everywhere: file exports limited to places you pick, update downloads checked for damage, and a security activity log.",
        "Missing set pictures found online (promos, McDonald's sets, trainer kits...) and neat generated pictures for sets that have none anywhere.",
        "Phone: browse by Categories, Illustrators and Pokémon exactly like the PC; every downloaded game (Japanese, One Piece...) is available on the phone.",
    ]),
    ("3.0.0", [
        "Brand-new look: every screen was rebuilt with React - Cards, Checklists, Value, Organize, Trade, Share, Games, Dev tools and Settings - faster, cleaner and the same on your computer and phone.",
        "The phone app now shares the same screens: Home with your value and progress, offline notice with changes uploading by themselves, trade, binder pages, duplicates, locations and more.",
        "Starts faster and stays small: the app uses the browser engine that is already part of Windows.",
        "Everything underneath is unchanged: your collection, sync, undo history, backups, prices and downloads.",
    ]),
    ("2.4.0", [
        "New Trade screen: what you give vs what you get at market price (with a % for each side), the difference, copy a summary, and complete the trade in your collection (undoable).",
        "New Organize screen: binder pages (3x3, 4x3, 9x9, 12x12), a duplicates finder with 'send to trade', and 'where things are' storage locations.",
        "Value is now a set of tabs: Overview, Profit & movers (profit/loss per card, weekly gainers and losers, insurance PDF), Spending (log + monthly budget), and Finish a set (cost to complete, 90%/95%).",
        "Every copy now has Edition and Stored-in fields; select many cards, right-click and 'Edit selected' to change them all at once.",
        "Currency choice in Settings (10 currencies, rates by hand or one-click update). Full spreadsheet export and import from TCGplayer / Collectr / other trackers (all undoable).",
        "Phone app: Home screen with value and progress, clear offline notice with a count of waiting changes that upload by themselves when you are online, edition and location on each copy, real error text when sync fails.",
    ]),
    ("2.3.1", [
        "Phone app: every set now shows its logo in the set list.",
    ]),
    ("2.3.0", [
        "Recent actions log (bottom-left, or Ctrl+Z): every change - including removing many cards at once, deleting a checklist or a category - can be undone, even later.",
        "Faster auto-save: changes are copied to your other devices a few seconds after you make them, and a safety backup is taken 15 seconds after you stop.",
    ]),
    ("2.2.0", [
        "Check for updates (Settings), plus an automatic check at start-up: new versions download and install with one click.",
        "Cloud saving (Settings): your collection, copies, wishlist, checklists and categories stay the same on your computer and phone.",
        "Phone app (installable web app) and Android app that update together with the desktop app.",
    ]),
    ("2.1.0", [
        "Start-up window drawn by the launcher itself: smooth progress bar that never stutters, closes the moment the app opens.",
        "Pokémon spots under Cards: Physical TCG, TCG Pocket (its own spot) and Japanese, all collected under Pokémon.",
        "Presets and the Pokédex wizard collect the physical game; TCG Pocket cards are opt-in.",
    ]),
    ("2.0.0", [
        "One Piece Card Game and Union Arena added (Games tab): every set, card, picture and market price.",
        "Browse by Sets / Categories / Illustrators / Pokémon with boxes; pick several and track them as one checklist; 'Track as checklist' on any set, artist or Pokémon.",
        "Dev tools: put cards into categories and make your own (with automatic rules); saved, export/import as a file, survive updates.",
        "Pokédex slots with no card show 'No Card Exists'; choosing a card for a slot ticks it, shows it on the list and can be unticked.",
        "Cleaner layout: Settings page (theme, prices, backups, CSV), no duplicate menus / tabs / buttons; checklists page is only your checklists.",
    ]),
    ("1.6.0", [
        "Set logos and symbols from Bulbapedia (Games > Set logos & symbols): ~155 sets matched; logos fill gaps, symbols show beside each set name.",
    ]),
    ("1.5.0", [
        "Pokedex of all 1025 Pokemon: choose which categories count (Art cards, IR, SIR, Alt Art, any rarity...); each Pokemon lists its options and you tick the one(s) you own.",
        "Quantities show everywhere: x-badges on tiles, + / - keys and right-click copies, Pokedex slots, portfolio value.",
        "Copy details: condition, graded copies with company (PSA, BGS, CGC, SGC, TAG, ACE, AGS, Other), grade and cert number; edit any copy later.",
        "Cert numbers are included in CSV export/import (and stay private in share pages).",
    ]),
    ("1.4.0", [
        "Sets are now boxes you click (with the set logo, progress bar and %); the side list is gone.",
        "A series / era dropdown filters the boxes; find, sort and filter sets by progress (in progress / complete / not started).",
        "Categories are boxes too (Art cards, rarities, mechanics, card types).",
        "Split any set by rarity: one section per rarity with its own owned / total and progress.",
        "New goal: collect one card of EACH RARITY in every set (checklist mode, master-set goal switch, preset).",
        "Set logos are downloaded with pictures (Games > Update).",
    ]),
    ("1.3.0", [
        "Admin page: add or remove cards on any card group (Art cards, Illustration Rare, Alt Art, rarity groups...) or any of your checklists; saved immediately.",
        "Corrections override the automatic rules and are kept in your collection file (backed up, journaled).",
        "Training: your Alt Art labels re-tune the automatic detection threshold; export every correction with card features (CSV) for deeper analysis.",
    ]),
    ("1.2.0", [
        "Categories browser: see every Art card, Illustration Rare, Special Illustration Rare, Gallery card, Alt Art, each rarity group, and ex / V / VMAX / VSTAR / GX cards, with owned counts.",
        "Art cards = whole card is an illustration: IR, SIR, all gallery cards and full-illustration Alt Arts (detected from secret numbering + the picture).",
        "Per-card Card type override (card panel or right-click > Card type) for Alt Arts the automatic rules cannot see.",
        "Checklist rules can use card groups; Art-card Pokedex preset rebuilt on them; Card groups tab with progress for every group; groups can be exported and shared.",
    ]),
    ("1.1.0", [
        "Brand-new look: side navigation, light/dark/system themes, tile cards with a tick-box on every card (click, or Space).",
        "Quick marking: tick-box on every card in sets and search results; multi-select + right-click bulk marking; undo toast.",
        "Custom checklists with a rule builder (rarity, set, number prefix, Pokedex number, secret numbering...) and presets like Illustration Pokedex.",
        "Pokedex-style lists: one qualifying card per Pokemon counts.  Per-variant master sets.",
        "Master set progress with percentages for every set and checklist; owned / missing views.",
        "Export what's missing (or owned) as .txt or a formatted .xlsx with card pictures.",
        "Value page: automatic price updates, value-over-time graph, breakdown by set/series/rarity/checklist/card, top cards.",
        "Games & downloads manager (Pokemon now; other games plug in later). Per-game folders.",
        "Safety: saved after every change, change journal, rolling automatic backups (+ optional second folder), restore.",
        "Share pages (.html) with per-item permissions.",
    ]),
    ("1.0.0", [
        "First release: every English Pokémon card with its picture, in your own collection.",
        "Browse and search; collection tracking; CSV import/export; backup.",
    ]),
]
