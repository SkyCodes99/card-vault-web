APP_NAME = "Collect Em All"
VERSION = "3.35.0"

CHANGELOG = [
    ("3.35.0", [
        "Sealed products sorted properly: I re-checked every sealed product name. Build & Battle Box Displays, Stacking Tin Displays and V Battle Deck Displays no longer sit under Booster box - they are filed as Build & battle, Tin and League / battle / theme deck. New product types: Hanger box, Mini / fun pack, Prize pack, Trainer kit and Secret Lair drop.",
        "New toggle on the Sealed page: 'Show cases, displays and multi-packs'. It is off by default, so each product type shows single items only; switch it on to see cases, displays and other several-in-one products too (the Sealed case type always shows them).",
        "More art promos: Gothitelle and Reuniclus (the Illustration Contest promos, SVP 208-215 with Victini, Thundurus, Tornadus, Feraligatr, Pikachu and Toxtricity ex), Miraidon and Koraidon (SVP 013 / 014) and Charmander (SVP 044) are now art cards.",
    ]),
    ("3.34.4", [
        "Art is only art: I re-checked every hand-picked promo at full size. The Mega ex promos (Zeraora, Darkrai, Dragonite, Charizard X and Y, Kangaskhan, Gardevoir, Lucario, Meganium, Emboar, Feraligatr, Zygarde, Clefable, Gengar, Greninja) and the full-art ex promos (Cynthia's Garchomp, Team Rocket's Mewtwo, Nidoking and Persian, Cinderace, Lapras, Terapagos, Ogerpon, Eevee, Espeon, Umbreon, Charizard) were full arts, not scene art, so they now appear under the Full Art categories and no longer under Art. The gold Lugia is no longer counted as art. The illustrations (First Partner starters, Wobbuffet, Snorlax, Mew ex, Kingdra ex, Magikarp and the other scene cards) and the alternate-art V / VMAX promos stay.",
    ]),
    ("3.34.3", [
        "Fixes the website showing an old version (for example 3.29) after an update: a new version used to wait downloaded in the background until every tab was closed, and meanwhile the old saved copy kept supplying the old engine to the new screens. A new version now takes over by itself and the page reloads once; each version only ever uses its own saved files; the few files that keep the same name every release are fetched fresh; and the page notices when its engine is behind its screens and refreshes.",
    ]),
    ("3.34.2", [
        "Check this app: Settings > Updates & about has a new 'Check this app' button. It shows which version this copy is really running, how many art cards it finds, and whether the hand-checked art promos are counted - handy when cards or categories look wrong, because the numbers tell us exactly what is going on.",
    ]),
    ("3.34.1", [
        "Checklists keep what you ticked: when you change a checklist's rules (for example untick a category), any card you already own that the new rules no longer match stays on the list instead of vanishing. You decide: untick or remove it yourself. A card you removed by hand stays removed.",
    ]),
    ("3.34.0", [
        "Era filter: the card view now has an Era menu next to Type and Rarity (Original 1999-2003, EX, Diamond & Pearl, HeartGold & SoulSilver, Black & White, XY, Sun & Moon, Sword & Shield, Scarlet & Violet, Mega Evolution, and promos & specials), each with how many cards it holds.",
        "More art cards: the Greninja V-UNION set, Kingdra ex (SVP 131), Mega Greninja ex and the other Mega ex promos (Charizard X and Y, Kangaskhan, Gardevoir, Lucario, Meganium, Emboar, Feraligatr, Zygarde, Clefable, Gengar, Zeraora, Darkrai, Dragonite) are now art cards. They are filed under Alternate Art or Illustration Rare, so they appear with only the art categories ticked - you never need to tick Promo.",
    ]),
    ("3.33.2", [
        "The art cards I added last time are now in the categories your checklists already use: the Eevee-evolution V / VMAX promos and the Mew VMAX reprint are filed under Alternate Art, and the illustrated promos (the First Partner starters, Team Rocket's Wobbuffet, Snorlax, Mew ex, Magikarp 203/193 and the rest) are filed under Illustration Rare, as well as under Art. Before, they were only in a new 'Art promos' category, so a checklist built from specific categories (rather than all Art) did not pick them up.",
    ]),
    ("3.33.1", [
        "More art promos: I went through every Scarlet & Violet promo by picture and added the full-illustration ones to Art - Team Rocket's Wobbuffet, Team Rocket's Mewtwo ex / Nidoking ex / Persian ex, Cynthia's Garchomp ex, Marnie's Morpeko, Steven's Beldum, the Eevee, Eevee ex, Espeon ex and Umbreon ex illustrations, Terapagos ex, Pecharunt, Flutter Mane, Iron Thorns, Pikachu with Grey Felt Hat and more (25 cards). If one is still missing, tell me its name.",
    ]),
    ("3.33.0", [
        "The website now updates itself: when you open it, or come back to it after being away a little while, it checks for a newer version and refreshes straight away (once per version, so it can never get stuck reloading). Before, a phone could keep showing an old copy until every tab was closed - which is why fixes did not show up. 'Refresh now' also clears the saved offline copy of the app itself (never your collection) so it is guaranteed to fetch everything fresh.",
        "The Mega Evolution First Partner Illustration Collection (Series 1, 2 and 3 - the illustrated starters from Bulbasaur to Quaxly, Mega promos 037-063) now count as Art.",
    ]),
    ("3.32.0", [
        "Much better on phones: tapping a card with several versions in a checklist now shows just the choices (a roomy sheet with two cards across) instead of also throwing up the full-screen card panel on top. The card panel is a bottom sheet you can close by tapping outside it, windows slide up from the bottom, the Home button works (it was stuck on a spinner on the website), a checklist's title is no longer squeezed into a thin column, Trade shows 'what I give' and 'what I get' one above the other, nothing runs off the side of the screen, and buttons and fields are finger-sized.",
        "More art cards: the Eevee-evolution alternate-art promos (Flareon, Vaporeon, Jolteon V and VMAX), Snorlax SVP 051, Mew ex SVP 053, the Classic Collection art reprints (Magikarp 203/193, Mew VMAX, Lugia 149/147) now count as Art, under a new 'Art promos' category. They are checked by hand against the pictures; more can be added from Card tools (Art category > Find cards to add > 'Likely art first').",
        "Pokedex numbers for the cards added last time: about 3,300 Pokemon (Classic Collection, Battle Academy, promos...) now have their Pokedex number, so they appear in Pokedex checklists and under Browse by Pokemon.",
    ]),
    ("3.31.2", [
        "3,367 more Pokemon cards and 19 more sets: cards that TCGplayer lists but the card list was missing are now in. That includes the Trading Card Game Classic set, Battle Academy, Jumbo cards, League and Championship cards, Deck Exclusives, Nintendo, Burger King and Pikachu World Collection promos, the Mega Evolution promos, the basic Energy of Shrouded Fable and Chaos Rising, and more. They have pictures and prices where TCGplayer has them, and the new sets are filed under Miscellaneous.",
    ]),
    ("3.31.1", [
        "No more screen flashing: when your collection syncs (or anything changes in the background) the screen no longer dims or flickers. Lists and pages now refresh quietly in place, and only redraw if something really changed.",
    ]),
    ("3.31.0", [
        "Merge two accounts: made two accounts by mistake? In Settings > your account, 'Merge another account…' signs in to the other account for a moment, copies its collection, lists, portfolios and settings into the one you are using (nothing is lost on either side), and - only if you tick the box - erases the other account so its name is free again. Card photos are not copied.",
        "Get a link to a binder: Organize > Binder pages > 'Get a link…' makes a web address anyone can open to look through the binder (colour = owned, grey = needed, blank = no card exists). It never shows prices, copies or notes. 'Update the link' refreshes it with the same address; 'Take the link down' turns it off straight away.",
        "The Windows app and the website are now checked against each other at every release: same version, and a written list of the few things that can only exist on one side (the scanner, your data folder, pictures stored on your PC).",
    ]),
    ("3.30.0", [
        "Binder views: in Organize > Binder pages you can now choose how the binder looks. 'Everything on the list' shows the cards you own in full colour and the ones you still need greyed out; 'Only what I own' packs your cards into a filled binder with no gaps; 'Only what I'm missing' shows just the gaps. In a checklist like your art Pokedex, a Pokemon that has no card in your chosen categories is a blank spot (you can switch the blank spots off).",
        "Choose the card you are after: when a checklist spot has several cards to pick from, click its pocket (it shows a small number) and choose which one you are collecting. It stays in the binder - grey - until you own it, so the binder always knows which one that spot means.",
        "Share a binder: 'Save as web page' turns a binder into one web page you can send to anyone. They can flip the pages, switch between everything / owned / missing, and see colour for owned, grey for needed and blank where no card exists. It never includes prices, copies or notes.",
    ]),
    ("3.29.0", [
        "Scanner confidence: in Settings you can choose how sure the scanner has to be. Cards it is less sure about than the first level (usually 85%) are marked so you look before adding; below the second level (usually 50%) you have to tick 'Yes, it is' before the card can be added.",
        "Clearer permission wording for helping the scanner learn: it is still off unless you turn it on, and now says it can also help improve other card features such as the card pictures in sets.",
        "Card lists kept in step with TCGplayer: new tools compare every game's card list with TCGplayer's own list and report new sets, new cards and changes. Japanese cards that had no rarity now have one, 200 more cards are linked to their TCGplayer product, and 4 new One Piece cards arrived. The owner has a 'TCGplayer sync' button in Card tools, including a place to add picture-link sources.",
    ]),
    ("3.28.0", [
        "New analytics pages: the set and series analytics were rebuilt. A big completion ring, four number cards with little trend lines, a value chart with 1W / 1M / 3M / 1Y / All and tick-to-hide lines, bars you can read at a glance (value by rarity, what is left to buy by rarity), price bands, and rows of card pictures for the most valuable cards, the biggest cards you still need and the cheapest way to make progress. The series page ranks every set and each set opens its own analytics. It adapts to phones, tablets and big screens.",
        "Checklist analytics: every checklist now has an Analytics tab showing what the checklist is worth, what you already own, what finishing it would cost (using the card you picked for each slot, or the cheapest option) and a value-over-time chart. 'Analytics of several lists' reads any mix of checklists as one (a card on two lists counts once).",
        "Portfolios inside portfolios: a portfolio can now sit inside another one, so you can make a category (for example Sealed with Booster boxes and Tins inside it). Choosing a category shows everything inside it, and its totals include the portfolios inside. Portfolio analytics (the chart button) work for one portfolio, a whole category or any mix you tick, with the value over time, what you paid, gain / loss, value by rarity, set and series, sealed products by type, your most valuable cards, and an option to hide prices.",
        "Tie checklists to a portfolio: pick checklists for a portfolio (the cog button) to see what they are worth there, or make a portfolio that is every checklist put together, including ones you make later. One button sorts a portfolio's sealed products into sub-portfolios by product type.",
        "More checklist presets and quick lists: Shiny Pokedex, Illustration Rare and Special Illustration Rare Pokedex, Holo, Full-art and Secret Rare Pokedex, every Trainer card, every Energy, every ex, V / VMAX / VSTAR, Radiant / Amazing / ACE SPEC, the Classic Collection, the Original era, Scarlet & Violet, Mega Evolution and TCG Pocket illustrated cards. 'All cards by an illustrator', 'All cards of a Pokemon' and 'A whole set or series' make a list in two clicks (pick as many as you like, for example every Yuka Morii card).",
        "Binder pages show only what belongs: choose a set or a checklist and the pages hold exactly those cards, one pocket per checklist entry, with 'owned' judged only inside that selection. Nothing is shown until you choose one.",
        "Accuracy pass on categories: the Prism Star, Rare BREAK and Rare Ace cards are filed under the right rarity, Japanese Triple Rare, Character Rare and Character Super Rare cards now have proper rarity groups, illustrators that were written two ways (for example 'Miki Tanaka' and 'MikiTanaka') are merged into one, and 'N/A' is no longer an illustrator. Your saved checklists keep working. 47 more cards (Celebrations Classic Collection, the 30th Celebration and others) now have a picture and price link.",
    ]),
    ("3.27.0", [
        "Sealed products sorted properly: every sealed product now has a product type and the right series. POP Series packs, Trainer Kits, McDonald's, World Championship Decks and other specials have their own series instead of being lumped into the newest era, and the catch-all 'Miscellaneous' products are placed by the set they belong to.",
        "Filter sealed products by type: Booster box, Sealed case, Elite trainer box, Booster bundle, Sleeved booster pack, Booster pack, Checklane blister, 3-pack blister, 2-pack blister, Single-pack blister, Mini tin, Tin, Collector chest, Build & battle, Tournament collection box, Premium and Ultra-premium collection, Collection box, decks, kits and more - pick any number of types at once, together with a series. Digital code cards and loose single cards that TCGplayer lists with the products are hidden unless you tick the box. This works for every game.",
    ]),
    ("3.26.0", [
        "One shared source for card data: card lists, prices and price trends now come from the same central card-data server that every one of the apps uses, so a fix made once is right everywhere. The app keeps only a copy of it, and Settings > Data & backup > 'Card lists & prices' shows exactly what you have and what is published (and why, if it can't be reached).",
        "Corrections: the owner's category and rarity fixes can now be published once and applied the same way in every app.",
    ]),
    ("3.25.1", [
        "Click the picture to choose a version: in a checklist's list of versions (the window that opens when a slot has several cards) and in master sets, clicking a card's picture now marks that version as owned (and takes it off again), just like its tick box. Click the name to see the card's details.",
    ]),
    ("3.25.0", [
        "Five new card games: Magic: The Gathering (105,000 cards), Disney Lorcana (3,600), Gundam Card Game (2,000), Riftbound - the League of Legends card game (1,700) and the Palworld card game (260). Each has every set with its logo where one exists, pictures, TCGplayer prices (95-99% priced), sealed products and the same set analytics, master sets and checklists as the other games. Pick them in the game switcher at the top; Magic is a big download, so it is fetched only when you choose it.",
    ]),
    ("3.24.5", [
        "Pictures that can't be loaded are no longer left blank: when the first picture source is down for a moment or doesn't have a card, the same card's picture from TCGplayer is shown instead (this fixes cards like the Lost Origin Trainer Gallery Charizard and the 151 Squirtle). About 2,700 cards that had no picture address at all now have one.",
        "186 Pokemon cards of the 30th Celebration had no Pokedex number, so they could not appear in Pokedex checklists or under 'Browse by Pokemon'. They now have one (and so do 209 Japanese cards).",
    ]),
    ("3.24.4", [
        "Checklists: click a card's picture to tick it off (click it again to take it off), no need to aim for the small tick box. Click the card's name - or double-click it - to see its details. Cards that stand for several choices (like a Pokedex slot) still open their options when you click them.",
    ]),
    ("3.24.3", [
        "Set value on every set box: each set on the sets screen now shows what one of every card in it is worth (for example 'Set value $1,667'), or 'No prices yet' / how many cards are priced when some are missing.",
    ]),
    ("3.24.2", [
        "Better on phones: tick boxes on cards are finger-sized, small buttons are taller, and the progress header of a set wraps so 'Track as checklist' no longer runs off the screen.",
    ]),
    ("3.24.1", [
        "Series analytics: on the sets screen, the new '📊 Series analytics' button (it says the series name when you pick one, like 'Scarlet & Violet analytics') combines every set of the series into one page: total value, what you own, cost to complete, typical card, a value graph with day / week / month change, a table of every set (value, how complete, cost to complete) with an 'Analytics' button that opens that set's own analytics, the most valuable cards, price spread and value by rarity.",
        "The leave-cards-out pop-up is tidier: a solid panel with a Done button always visible, tick boxes per rarity that show 'x of y counted', click-outside to close, clear 'Leave out / Count it again' buttons under each card, and left-out cards are labelled and dimmed.",
        "Settings > Data & backup > Card lists & prices: shows when each game's card list was built and what the website has, with an 'Update card lists now' button - so out-of-date sets (like the 30th Celebration prices) can be fixed on the spot.",
    ]),
    ("3.24.0", [
        "The three unnumbered Mew cards of the 30th Celebration (Red, Green and Blue RGB) are now in the set, with their prices, in their own 'RGB Rare' group. They count in the master set, and 'Leave cards out…' > RGB Rare switches all three off or on in one tap.",
        "Build your own custom set: in any set, select cards and press 'Leave out of this set' (or use the per-card button in the master set). Left-out cards stop counting in the set's progress, in the set boxes and in the master set, and the 'Left out' tab shows them so you can bring them back.",
    ]),
    ("3.23.2", [
        "Phones: Lists, Organize, Share and the set analytics screens now fit the width of a phone (nothing runs off the edge), tab rows scroll sideways, and tables scroll instead of squeezing.",
        "Help the scanner learn (desktop, off by default) now shows how many of your corrected-card pictures are kept on the server, and keeps your pictures on your PC if your limit is reached.",
    ]),
    ("3.23.1", [
        "Set analytics: open any set and choose 'Analytics' to see what the whole set is worth, what you own is worth, the cost to complete, a graph of how the set's value changes day by day (with day / week / month change), the most valuable cards, the biggest cards you still need, how the cards are priced, and the value of every rarity.",
        "Master sets show prices: every card in a master set now shows its price (the 30th Celebration set and its Classic Collection were missing them because master-set cards had no price line).",
        "Leave cards out of a master set: each card has a 'Leave out' button, 'Leave cards out…' switches a whole rarity off or on, and a 'Left out' tab shows what you hid. Left-out cards don't count in the master-set totals.",
        "The website waits a few minutes before any background download, so opening it is not slowed down.",
    ]),
    ("3.23.0", [
        "Once-a-day prices for every card and product: prices now update once a day, three minutes after TCGplayer's own daily update (20:03 UTC). If the new prices are not ready yet, the app checks again every 5 minutes and stops as soon as it has them. Settings > Prices & money > Price updates shows the status and has a 'check now' button.",
        "Far more cards have prices: Japanese Pokemon went from 69% to 86% priced (older sets are now matched by release date and size), and English Pokemon promos and older sets were matched by name and number. Every card is now linked to its TCGplayer listing so the daily update can reach it. What still has no price: digital TCG Pocket cards (they are not sold), and cards TCGplayer lists without any price.",
        "Settings is tidier: five tabs (Account, Prices & money, Data & backup, Look & feel, Updates & about) instead of one very long page.",
    ]),
    ("3.22.2", [
        "Fixes a blank screen: version 3.22.1 could open to an empty window. This version fixes it.",
        "Move your data: Settings > 'Where your data is stored' copies everything to another folder or drive (the old folder is kept as a copy, nothing is deleted) and uses the new one from the next start.",
        "Help the scanner learn (desktop): a new switch in Settings, OFF unless you turn it on. When on, the picture of a card you corrected in the scanner (never your whole photo) and the right card number are sent, kept at most 30 days, used once and deleted. Turning it off deletes what is waiting. It starts working once the website side is switched on.",
        "More rarity groups: Classic Collection, Pikachu Rare and Futuristic Rare each have their own group, and Mega Hyper Rare is separate from the older gold Hyper Rares.",
    ]),
    ("3.22.1", [
        "Card lists and prices arrive sooner: the app used to update only one game's card list per check (and check twice a day), so Pokemon could wait a day or more behind the others, which is why newer prices like the 30th Celebration ones could take so long to show. It now updates every game that has news, the game you are looking at first, one after another.",
        "The sign-in card shows your username, also on devices that signed in before the change.",
        "Celebrations Classic Collection prices added (24 of 25 cards).",
    ]),
    ("3.22.0", [
        "Your username, not your email: the sign-in card, the top bar and your profile now show your username. The name this device uses for you follows your username automatically, and the email is no longer shown next to it.",
        "Profile pictures: Settings > Your profile > 'Add a picture…'. Pick a picture up to 2 MB, it is shrunk automatically, then drag to position it and zoom to fit it in the circle. It shows in the top bar and on the sign-in card, and follows you to your other devices.",
        "TCG Pocket cards in the Art categories: a new 'TCG Pocket illustrated cards' group holds the 720 star, shiny and crown cards of Pokemon TCG Pocket (for example Meowth from Fantastical Parade, Genetic Apex, Extradimensional Crisis and Mega Rising), and they now count as Art cards too.",
    ]),
    ("3.21.0", [
        "Better search: it now ignores capitals and accents (typing 'pokemon' finds Pokémon, 'farfetchd' finds Farfetch'd), understands card numbers written as #4, 4/102 or 006/165, and puts cards whose name is exactly what you typed first. The 'Search everything' window also takes your typing straight away.",
        "Sealed products by era: for Pokemon, Browse all products now has a button for each era (Original, EX, Diamond & Pearl to HeartGold, Black & White, XY, Sun & Moon, Sword & Shield, Scarlet & Violet, Mega Evolution) with how many products each holds. The other games keep all their sealed products together.",
    ]),
    ("3.20.2", [
        "Prices for the whole Pokemon 30th Celebration: all 188 cards (including the 30 Classic Collection reprints) now have a TCGplayer price.",
    ]),
    ("3.20.1", [
        "Safer updates: if a problem is ever found in the newest version, the app can offer to go back to the previous one with a clear 'A problem was found in the newest version. Go back to ...?' message. It never goes back on its own, and your collection is never rolled back.",
    ]),
    ("3.20.0", [
        "More prices: 560 more Pokemon cards (promos, trainer kits and older sets) now have a TCGplayer price, found by matching each card's name and number. Digital TCG Pocket cards now say 'Digital card' instead of 'No price', because they are not sold as real cards.",
        "Pokemon cards by era: a new 'By era' list splits every card into Original (1999-2003), EX, Diamond & Pearl to HeartGold, Black & White, XY, Sun & Moon, Sword & Shield, Scarlet & Violet and Mega Evolution - plus one 'Before Sword & Shield' group with the whole older era together.",
    ]),
    ("3.19.0", [
        "Set logos for the card games that had none: every set box now shows its logo - One Piece (38 sets, including the release-event sets that share their main set's logo), Union Arena (57), Yu-Gi-Oh! (161) and Dragon Ball Super (64). Sets without a logo keep their name.",
    ]),
    ("3.18.0", [
        "Two missing Pokemon sets added: Prize Pack Series Cards (849 cards) and World Championship Decks (1,717 cards), with TCGplayer prices and pictures.",
        "Phones: the whole page now scrolls, so the card grid gets the whole screen instead of being squeezed under the filters.",
        "Sale Data prices start filling in: the website now saves prices every day, and the app picks up the recent-price trend as soon as there are a couple of days of history.",
    ]),
    ("3.17.0", [
        "Sign-in fix: after you sign in, the top bar, menus and banners now update at once and stop asking you to sign in. A hiccup while checking your sign-in can no longer make the app think you were signed out.",
        "Sale Data prices: Settings > Prices lets you show Standard (TCGplayer market), Sale Data (a recent typical price with a rising / falling arrow, worked out from prices saved every day) or Both. It is a trend, not a list of actual sales, and it fills in once a few days of prices are saved.",
        "Save a backup file: Settings > Backups & safety > 'Save a backup file…' puts everything (every game, lists, photos, settings) in one file locked with a password you choose. Restore it on any device from the same place.",
        "A friendly welcome asks you once to make your account your home, so your collection is saved to the cloud and follows you everywhere.",
    ]),
    ("3.16.0", [
        "Prices you can see: every card in the Cards grid and in your lists now shows its price under the picture. A * means it is a different kind of price (for example the middle price), and hovering tells you which. Cards with no price say 'No price'.",
        "Sealed products catalog: on the Sealed page, 'Browse all products' lists about 9,000 boxes, packs, bundles and decks with their pictures and TCGplayer prices. Click one to add it to your collection with the price filled in, and 'My sealed products' now shows what each one is worth now.",
        "Show / hide password: every password box has an eye button to see what you typed.",
        "Forgot your password? You can now come back in three ways: your recovery key (everything returns), a 2-step code from your authenticator app, or an emailed code. The last two restore your account but start its cloud copy empty, and the screen says so and asks you to confirm first.",
        "Change your email address: Settings > Your account > Email address. (It says 'isn't available yet' until email sending is switched on.)",
        "If creating an account fails, the screen now says plainly 'Your account was NOT created' and why.",
    ]),
    ("3.15.0", [
        "More prices: about 12,500 cards that had no price now show one (all of Japanese Pokemon, plus gaps in Pokemon, Dragon Ball Super, Yu-Gi-Oh!, One Piece and Union Arena). When there is no market price the app uses the price of another printing, or TCGplayer's mid or low price, and says so on the card. Cards that really have no price now say why instead of just 'no price'.",
        "Two-step sign-in: Settings > Your account > Two-step sign-in shows a QR code to scan with your authenticator app (the code is drawn on your device), with the typed key as a backup.",
        "Clearer accounts: if you are not signed in to a cloud account, every screen now says so plainly and offers 'Create your account' first (with an optional username). After creating it you are offered to save your collection to it right away, and if a sign-in ends you are told 'Your session ended - sign in again'.",
        "A new look for the main screen: a top bar with the game switcher, a Cards | Sealed switch and 'Search everything' (Ctrl+K), which searches every game at once and opens a result in its own game. Sealed products now have their own space. On phones there is a thumb-friendly tab bar with the scanner in the middle.",
    ]),
    ("3.14.1", [
        "Your username is now easy to find: Settings opens with 'Your profile', showing your username with an Edit button, a live check that the name is free, and a clear message if it is taken. Click your name in the sidebar to jump straight to it.",
        "Plainer wording everywhere: technical and behind-the-scenes terms are gone from the screens, messages and release notes. Settings now has a simple 'Cloud saving' section, and connection problems say 'we'll keep trying' instead of showing error details.",
    ]),
    ("3.14.0", [
        "Art categories fixed and explained: 'Scene art' now only holds cards whose picture is one illustrated scene. Rainbow, shiny and Mega EX full arts (like Venusaur & Snivy-GX or the shiny Charizard V) are no longer counted as art, and 62 genuine alternate arts that were missing are now included. Every category has a plain-English description.",
        "More card pictures: 6,777 cards that had no picture (1,370 English and 5,407 Japanese Pokemon cards) now show one.",
        "Cloud saving is impossible to miss: if a computer only holds your collection locally, the bottom bar says 'Only on this device - turn on cloud saving' and a banner offers one-tap sign-in. Once you have an account, every change is saved by itself a few seconds after you make it.",
        "Username box in Settings checks live whether a name is free.",
        "Card lists update by themselves: when a corrected or fuller card list is published, the app fetches it (twice a day) and keeps any newer prices it already had.",
    ]),
    ("3.13.0", [
        "A much smaller download: the old classic window has been retired for good, so the app is about half the size (the React screens you already use are the only edition).",
    ]),
    ("3.12.0", [
        "Usernames: everyone has one, shown as their name (a random one until they choose their own - you are asked once after signing in, and you can change it in Settings > Account). Sign in with your email OR your username. Your email is never shown to anyone, and usernames never reveal it.",
        "The public showcase page shows your username, never your email.",
        "Older accounts: sign in once with your email after this update and username sign-in switches on for them automatically.",
    ]),
    ("3.11.0", [
        "Stay signed in: tick 'Stay signed in on this device' when you sign in (or in Settings > Security) and the website and the Windows app open without asking for your password until you press Lock or change your password. The key is kept protected by the browser / Windows itself.",
        "The website opens straight to your sign-in card in your own theme; type your password right away and it unlocks as soon as the app has started.",
        "Everything you do is now saved to your account: spending log, value-over-time history, share links, photos of your copies, and your choices (currency, units, budget, portfolio name, showcase, reminders) all follow you to your other devices.",
        "A clear 'Saved to your account' time in the bottom bar, 'Saving...' while changes are on their way, and a warning with a Retry button if a save fails.",
    ]),
    ("3.10.0", [
        "Pick a username (optional) when you create your account, or later in Settings. It is shown as your name, and you can use it instead of your email to sign in.",
    ]),
    ("3.9.1", [
        "Fixed the Account card in Settings and the Scanner tab, which could spin forever instead of loading.",
        "The website now asks your browser to keep its saved data, and shows a warning in the bottom bar when this browser's collection is not backed up to an account.",
        "Price history is now saved after every price update (it could be skipped before).",
    ]),
    ("3.9.0", [
        "New look: smoother buttons and menus, a clearer sidebar, softer shadows, themed scroll bars, nicer pop-ups, and a floating bottom bar on phones.",
        "24 themes now (12 new: Sky, Rose, Citrus, Sand, Pokedex, Midnight, Nord, Mocha, Vampire, Cyber, Emerald, AMOLED, Dusk), plus your own accent colour, spacing (compact / normal / roomy) and corner style.",
        "Your look follows your account: choose a theme on the website and the phone and computer match. Turn on 'Use a different look on this device' to give any device its own.",
        "Fixed the website on phones, where the page could squeeze into a narrow strip.",
    ]),
    ("3.8.0", [
        "No more Games & downloads screen: every game's card list now comes from the website automatically, in seconds. Pick a game from the list at the top of the sidebar and its cards appear.",
        "All six games are on the website: Pokemon (English and Japanese), One Piece, Union Arena, Yu-Gi-Oh! and Dragon Ball Super.",
        "Updates never interrupt you: a new version downloads quietly and waits; you see 'Version X is ready' and choose when to reload.",
        "If the connection drops for a moment, saving waits and retries quietly instead of showing an error.",
    ]),
    ("3.7.1", [
        "Card pictures no longer have to live on your PC: a picture that isn't saved is downloaded when you look at that card and kept for next time.",
        "New Settings card 'Card pictures on this PC' shows how much room pictures take and can free it (you confirm first), or keep it under a size you choose automatically.",
    ]),
    ("3.7.0", [
        "Two new games: Yu-Gi-Oh! (46,000+ cards, 1st Edition / Unlimited printings) and Dragon Ball Super Card Game (11,000+ cards), with sets, rarities, pictures and market prices. Pick them in Games.",
        "The website has a 'Get the app' page (and a link on the sign-in screen) to download the Windows app.",
        "The website loads much faster after the first visit: the app files now come straight from the saved copy instead of being downloaded again each time.",
        "The Scanner tab opens instantly on the website and no longer keeps checking in the background.",
    ]),
    ("3.6.2", [
        "Simpler sign-up and sign-in: just your email and password (type the password twice only when creating an account). No separate name to type; the same password locks this device unless you choose a different one.",
    ]),
    ("3.6.1", [
        "Cloud accounts are on by default: the first screen offers 'I'm new - create my account', 'I already have an account' or 'Just this device'. Your collection is encrypted on your device before it is saved to your account.",
    ]),
    ("3.6.0", [
        "Cloud accounts: one email and password for the desktop app, website and phone. Your collection is encrypted before it leaves your device, so only you can read it. Settings > Account has sign in, your devices (sign a lost phone out), password change and recovery. Changes made on one device now show up on the others within seconds.",
        "Portfolio > Insights: a collection health score with tips, challenges (one of every type, every generation, rarity ladder...), a timeline of milestones and a year in review you can copy and share.",
        "Organize: dream binders to plan the binder you wish you had, sealed products (scan the barcode), and a Missing versions list for people hunting reverse holos and other versions (off unless you turn it on).",
        "Trade: a fairness check that uses recent price swings, and a trade link - send the other person a link and they see your deal from their side and can change it.",
        "Quick add: press Ctrl+K and type or say what you got ('two charizard from 151'). Scanner: Keep scanning mode goes through a pile hands-free. Finish a set: a shopping list grouped by price with search links.",
        "Condition photos on each copy (front, back, anything else), a cover card for your public showcase, an account activity log that now records exports and device links, text size / high contrast / reduce motion in Settings, and a guided tour that shows 'What's new' after updates.",
        "Faster: the classification of every card is saved, so big sets open noticeably quicker. Fixed: after another device's changes were pulled in they sometimes did not appear until the next edit.",
    ]),
    ("3.5.1", [
        "The website now has an 'I already use Collect Em All on another device' option on the first screen: paste the link code from Settings > Sync > Link another device and your collection comes over.",
        "In a checklist, clicking one of a Pokemon's card options now shows that card's picture and details (a 'Use this one' button picks it for the list), instead of staying on the default card.",
        "Fix: 'Install and restart' for updates now really works. The little helper that swaps in the new files and reopens the app was being started in a way that made Windows quit it at once, so the app closed and nothing came back. It now waits for the app to close completely, copies the new version in (retrying if a file is still busy), reopens Collect Em All, and if anything goes wrong it reopens the old version and leaves a note.",
    ]),
    ("3.5.0", [
        "Adding a card is now one click less: the card panel has the usual details right there (portfolio, how many, condition, price paid, date, where bought) and remembers your last choices. 'More...' opens the full form for graded copies and notes.",
        "A polish pass over the whole app: grouped navigation with a clear marker for where you are, softer cards and shadows, nicer buttons, inputs and tables, a sticky card panel, smoother hover effects, and the artwork of a card (not its title bar) as the picture of rarity, illustrator and Pokemon boxes.",
        "Fix (website / phone): the Sets screen could stay on the previous list because the set-picture list could not be read in the browser version. Set logos that fail to load now fall back to a banner.",
    ]),
    ("3.4.2", [
        "Scanner add-on: only the newest version is kept (on this PC and on the releases page), so the download and the folder never grow with each update.",
    ]),
    ("3.4.1", [
        "The scanner add-on now updates itself: when a newer scanner is available the Scanner tab offers 'Update the scanner'. It also finds a scanner installed on your Desktop.",
    ]),
    ("3.4.0", [
        "The program is now called Collect Em All (new name on the app, the Desktop files and the download files). Your settings and collection move over automatically the first time you start it.",
        "Portfolios: keep separate collections (for example Kids, Graded, Sealed), look at one, several together, or everything. Value is now the Portfolio tab with a big graph (1D to 2 years, All, or a custom range) that goes back to the date you bought each card.",
        "A Condition & grading guide (what Near Mint to Damaged mean, what PSA / BGS / CGC grades mean) is one click away when adding a card and in Settings.",
        "Adding cards: price paid, date purchased, where you bought it (card shop, card show...), condition, grading and notes - one card or many at once.",
        "Rarities: every card is filed under its exact rarity (Alt Art, Rainbow, Gold, Trainer Full Art, Radiant, Shining, Prism Star, Ancient Trait...) using the Art / Shiny rules from your spreadsheet and the Bulbapedia / PokeRip guides. Categories is now called Rarities.",
        "Sets: a Master set view shows every version of every card (with the normal size of the set kept beside it) and lets you add graded copies. Finish this set shows what is missing and exports it with picture and all the card info.",
        "Trade: a compact card picker, cash, extra items, percentage scenarios, a what-if table, matching suggestions, a trade log and notes.",
        "Better banners for boxes with no picture, the coolest card as the picture of each illustrator, Pokémon and rarity, and 27 more set logos (Collectr) plus your McDonald's 2023 and 2024 pictures.",
        "New Scanner tab (add-on): scan with the camera or photos, one card or a whole table, and add them to the portfolio you choose. New Showcase tab: make your collection public (opt-in) with a Top 10 by value, or open a friend's showcase.",
    ]),
    ("3.3.0", [
        "The website, phone and tablet apps now work exactly like the computer app, so every feature is the same everywhere: checklists, value, trade, exports (CSV, Excel, PDF), backups, undo and saving.",
        "One account everywhere: Settings > Sync > 'Link another device' makes a single code; paste it on a new device and your collection appears, end-to-end encrypted.",
        "PDF export no longer needs anything extra and works on Linux and macOS too. Set and card pictures load straight from the web in the browser version.",
        "Browser version: installable from the browser menu (Add to Home Screen / Install), works offline once loaded, and tells you when a new version is ready.",
    ]),
    ("3.2.1", [
        "Fix: syncing with a password-protected account now sends your real collection (it could read a wrong, empty file before). Please update.",
        "New: 12 colour themes (Settings > Appearance); a notification with Refresh / Update / Later when a new version is out; Linux and macOS downloads on the release page.",
    ]),
    ("3.2.0", [
        "Forgot your password? Turn on 'Reset by email' (Settings > Security) and a 6-digit code is emailed to you; enter it and choose a new password - your collection is kept. Off by default; the recovery key keeps working.",
        "New cardvault_service: the small account service that sends the codes (self-hosted, with rate limits, single-use codes and no way to read anyone's collection). See cardvault_service/README.md.",
    ]),
    ("3.1.0", [
        "Accounts and log-in: create a password-protected account on first start; your collection, backups and saved sign-ins are encrypted on disk (AES-256), with a recovery key, wrong-password lockouts, auto-lock and Lock now. Your existing collection is protected for you.",
        "Encrypted saving: what is saved to the cloud can only be read by your own devices. The phone has its own password lock.",
        "Tighter security everywhere: file exports limited to places you pick, update downloads checked for damage, and a security activity log.",
        "Missing set pictures found online (promos, McDonald's sets, trainer kits...) and neat generated pictures for sets that have none anywhere.",
        "Phone: browse by Categories, Illustrators and Pokémon exactly like the PC; every downloaded game (Japanese, One Piece...) is available on the phone.",
    ]),
    ("3.0.0", [
        "Brand-new look: every screen was rebuilt with React - Cards, Checklists, Value, Organize, Trade, Share, Games, Dev tools and Settings - faster, cleaner and the same on your computer and phone.",
        "The phone app now shares the same screens: Home with your value and progress, offline notice with changes uploading by themselves, trade, binder pages, duplicates, locations and more.",
        "Starts faster and stays small: the app uses the browser engine that is already part of Windows.",
        "Everything underneath is unchanged: your collection, sync, undo history, backups, prices and downloads.",
    ]),
    ("2.4.0", [
        "New Trade screen: what you give vs what you get at market price (with a % for each side), the difference, copy a summary, and complete the trade in your collection (undoable).",
        "New Organize screen: binder pages (3x3, 4x3, 9x9, 12x12), a duplicates finder with 'send to trade', and 'where things are' storage locations.",
        "Value is now a set of tabs: Overview, Profit & movers (profit/loss per card, weekly gainers and losers, insurance PDF), Spending (log + monthly budget), and Finish a set (cost to complete, 90%/95%).",
        "Every copy now has Edition and Stored-in fields; select many cards, right-click and 'Edit selected' to change them all at once.",
        "Currency choice in Settings (10 currencies, rates by hand or one-click update). Full spreadsheet export and import from TCGplayer / Collectr / other trackers (all undoable).",
        "Phone app: Home screen with value and progress, clear offline notice with a count of waiting changes that upload by themselves when you are online, edition and location on each copy, real error text when sync fails.",
    ]),
    ("2.3.1", [
        "Phone app: every set now shows its logo in the set list.",
    ]),
    ("2.3.0", [
        "Recent actions log (bottom-left, or Ctrl+Z): every change - including removing many cards at once, deleting a checklist or a category - can be undone, even later.",
        "Faster auto-save: changes are copied to your other devices a few seconds after you make them, and a safety backup is taken 15 seconds after you stop.",
    ]),
    ("2.2.0", [
        "Check for updates (Settings), plus an automatic check at start-up: new versions download and install with one click.",
        "Cloud saving (Settings): your collection, copies, wishlist, checklists and categories stay the same on your computer and phone.",
        "Phone app (installable web app) and Android app that update together with the desktop app.",
    ]),
    ("2.1.0", [
        "Start-up window drawn by the launcher itself: smooth progress bar that never stutters, closes the moment the app opens.",
        "Pokémon spots under Cards: Physical TCG, TCG Pocket (its own spot) and Japanese, all collected under Pokémon.",
        "Presets and the Pokédex wizard collect the physical game; TCG Pocket cards are opt-in.",
    ]),
    ("2.0.0", [
        "One Piece Card Game and Union Arena added (Games tab): every set, card, picture and market price.",
        "Browse by Sets / Categories / Illustrators / Pokémon with boxes; pick several and track them as one checklist; 'Track as checklist' on any set, artist or Pokémon.",
        "Dev tools: put cards into categories and make your own (with automatic rules); saved, export/import as a file, survive updates.",
        "Pokédex slots with no card show 'No Card Exists'; choosing a card for a slot ticks it, shows it on the list and can be unticked.",
        "Cleaner layout: Settings page (theme, prices, backups, CSV), no duplicate menus / tabs / buttons; checklists page is only your checklists.",
    ]),
    ("1.6.0", [
        "Set logos and symbols from Bulbapedia (Games > Set logos & symbols): ~155 sets matched; logos fill gaps, symbols show beside each set name.",
    ]),
    ("1.5.0", [
        "Pokedex of all 1025 Pokemon: choose which categories count (Art cards, IR, SIR, Alt Art, any rarity...); each Pokemon lists its options and you tick the one(s) you own.",
        "Quantities show everywhere: x-badges on tiles, + / - keys and right-click copies, Pokedex slots, portfolio value.",
        "Copy details: condition, graded copies with company (PSA, BGS, CGC, SGC, TAG, ACE, AGS, Other), grade and cert number; edit any copy later.",
        "Cert numbers are included in CSV export/import (and stay private in share pages).",
    ]),
    ("1.4.0", [
        "Sets are now boxes you click (with the set logo, progress bar and %); the side list is gone.",
        "A series / era dropdown filters the boxes; find, sort and filter sets by progress (in progress / complete / not started).",
        "Categories are boxes too (Art cards, rarities, mechanics, card types).",
        "Split any set by rarity: one section per rarity with its own owned / total and progress.",
        "New goal: collect one card of EACH RARITY in every set (checklist mode, master-set goal switch, preset).",
        "Set logos are downloaded with pictures (Games > Update).",
    ]),
    ("1.3.0", [
        "Admin page: add or remove cards on any card group (Art cards, Illustration Rare, Alt Art, rarity groups...) or any of your checklists; saved immediately.",
        "Corrections override the automatic rules and are kept in your collection file (backed up, journaled).",
        "Training: your Alt Art labels re-tune the automatic detection threshold; export every correction with card features (CSV) for deeper analysis.",
    ]),
    ("1.2.0", [
        "Categories browser: see every Art card, Illustration Rare, Special Illustration Rare, Gallery card, Alt Art, each rarity group, and ex / V / VMAX / VSTAR / GX cards, with owned counts.",
        "Art cards = whole card is an illustration: IR, SIR, all gallery cards and full-illustration Alt Arts (detected from secret numbering + the picture).",
        "Per-card Card type override (card panel or right-click > Card type) for Alt Arts the automatic rules cannot see.",
        "Checklist rules can use card groups; Art-card Pokedex preset rebuilt on them; Card groups tab with progress for every group; groups can be exported and shared.",
    ]),
    ("1.1.0", [
        "Brand-new look: side navigation, light/dark/system themes, tile cards with a tick-box on every card (click, or Space).",
        "Quick marking: tick-box on every card in sets and search results; multi-select + right-click bulk marking; undo toast.",
        "Custom checklists with a rule builder (rarity, set, number prefix, Pokedex number, secret numbering...) and presets like Illustration Pokedex.",
        "Pokedex-style lists: one qualifying card per Pokemon counts.  Per-variant master sets.",
        "Master set progress with percentages for every set and checklist; owned / missing views.",
        "Export what's missing (or owned) as .txt or a formatted .xlsx with card pictures.",
        "Value page: automatic price updates, value-over-time graph, breakdown by set/series/rarity/checklist/card, top cards.",
        "Games & downloads manager (Pokemon now; other games plug in later). Per-game folders.",
        "Safety: saved after every change, change journal, rolling automatic backups (+ optional second folder), restore.",
        "Share pages (.html) with per-item permissions.",
    ]),
    ("1.0.0", [
        "First release: every English Pokémon card with its picture, in your own collection.",
        "Browse and search; collection tracking; CSV import/export; backup.",
    ]),
]
