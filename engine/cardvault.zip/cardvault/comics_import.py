"""Comics importer: reads a Grand Comics Database (comics.org, CC BY-SA 4.0) SQLite file the OWNER downloaded and returns the list's data (the shape of cardvault/comics_data.json).

comics.org needs a free account for its data dump and answers a plain client with a bot check, so the app never makes an account and never reads the site: docs/comics_data.md has the owner's steps.
Two shapes are read, told apart by their tables:
  * the full GCD dump (gcd_series, gcd_issue, gcd_publisher, gcd_story, gcd_cover ...): series, issues, variant covers (an issue with variant_of_id), the cover id, key-issue sentences from notes;
  * a reshaped extract (series, issue; for example the CC BY-SA extract Paperbunkr publishes): series and issues only - it has no variants, notes or covers.
A column a file does not have is simply left empty (never guessed).  Series ids are `gcd-s<id>`, issue ids `gcd-<id>` (the GCD's own ids, stable between dumps: the cover scanner keys on them).
`covers=True` keeps a cover picture URL built from the GCD cover id - OFF by default: the pattern is documented but unverified (comics.org blocks plain readers) and the scans belong to their publishers."""
import datetime
import re
import sqlite3
from pathlib import Path

from . import comicskeys

COVER_URL = "https://files1.comics.org//img/gcd/covers_by_id/{bucket}/w400/{id}.jpg"       # UNVERIFIED pattern (docs/comics_data.md); only used with covers=True
SOURCE = {"name": "Grand Comics Database (CC BY-SA 4.0)", "host": "www.comics.org"}
CHUNK = 400
_CLAIM_SQL = " OR ".join("lower(notes) LIKE '%%%s%%'" % w for w in ("appearance", "origin", "death", "debut"))


class NotAGcdFile(Exception):
    pass


def iso_month(text):
    """GCD key dates '1938-06-00' / '1938-00-00' / '1938' -> '1938-06' / '1938' (anything else -> '')."""
    m = re.match(r"(\d{4})(?:-(\d{2}))?", str(text or ""))
    if not m:
        return ""
    return "%s-%s" % (m.group(1), m.group(2)) if m.group(2) and m.group(2) != "00" else m.group(1)


def iso_day(text):
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", str(text or ""))
    return text if m and "00" not in m.groups() else ""


class _Db:
    def __init__(self, path):
        self.conn = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
        self.conn.row_factory = sqlite3.Row
        self.tables = {r[0] for r in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self._cols = {}

    def cols(self, table):
        if table not in self._cols:
            self._cols[table] = {r[1] for r in self.conn.execute("PRAGMA table_info(%s)" % table)}
        return self._cols[table]

    def col(self, table, name, alias, prefix="t"):
        """'t.name AS alias' when the table has the column, else 'NULL AS alias'."""
        return ("%s.%s AS %s" % (prefix, name, alias)) if name in self.cols(table) else "NULL AS %s" % alias

    def live(self, table, prefix="t"):
        return " AND (%s.deleted IS NULL OR %s.deleted=0)" % (prefix, prefix) if "deleted" in self.cols(table) else ""

    def rows(self, sql, args=()):
        return self.conn.execute(sql, args).fetchall()


def _series_rows(db):
    if "gcd_series" in db.tables:
        s = "gcd_series"
        join = " LEFT JOIN gcd_publisher p ON p.id=t.publisher_id" if "gcd_publisher" in db.tables and "publisher_id" in db.cols(s) else ""
        lang = " LEFT JOIN stddata_language l ON l.id=t.language_id" if "stddata_language" in db.tables and "language_id" in db.cols(s) else ""
        pub = "p.name AS publisher" if join else "NULL AS publisher"
        code = "l.code AS language" if lang else "NULL AS language"
        comics_only = " AND t.is_comics_publication=1" if "is_comics_publication" in db.cols(s) else ""
        return db.rows("SELECT t.id, t.name, %s, %s, %s, %s FROM %s t%s%s WHERE 1=1%s%s" % (db.col(s, "year_began", "year_began"), db.col(s, "year_ended", "year_ended"), pub, code, s, join, lang,
                                                                                         db.live(s), comics_only))
    return db.rows("SELECT t.id, t.name, %s, %s, %s, %s FROM series t" % (db.col("series", "year_began", "year_began"), db.col("series", "year_ended", "year_ended"),
                                                                          db.col("series", "publisher", "publisher"), db.col("series", "language", "language")))


def _wanted(row, publishers, languages, year_from, year_to):
    if languages and str(row["language"] or "").lower() not in languages:
        return False
    if publishers and not any(p in str(row["publisher"] or "").lower() for p in publishers):
        return False
    y = int(row["year_began"]) if str(row["year_began"] or "").isdigit() else None
    return not ((year_from and (y is None or y < year_from)) or (year_to and (y is None or y > year_to)))


def _issue_rows(db, ids):
    full = "gcd_issue" in db.tables
    t = "gcd_issue" if full else "issue"
    marks = ",".join("?" * len(ids))
    sql = "SELECT t.id, t.series_id, t.number, %s, %s, %s, %s, %s FROM %s t WHERE t.series_id IN (%s)%s" % (
        db.col(t, "key_date", "key_date"), db.col(t, "on_sale_date", "on_sale_date"), db.col(t, "variant_of_id", "variant_of_id"), db.col(t, "variant_name", "variant_name"),
        db.col(t, "notes", "notes"), t, marks, db.live(t))
    return db.rows(sql, ids)


def _story_notes(db, issue_ids):
    """{issue id: [note texts that may state a first appearance ...]} from the stories' own editorial notes (their plot summaries are never read)."""
    if "gcd_story" not in db.tables or "notes" not in db.cols("gcd_story"):
        return {}
    out = {}
    for a in range(0, len(issue_ids), 800):
        part = issue_ids[a:a + 800]
        for r in db.rows("SELECT issue_id, notes FROM gcd_story WHERE issue_id IN (%s) AND notes IS NOT NULL AND (%s)%s" % (",".join("?" * len(part)), _CLAIM_SQL, db.live("gcd_story", "gcd_story")), part):
            out.setdefault(r["issue_id"], []).append(r["notes"])
    return out


def _cover_ids(db, issue_ids):
    if "gcd_cover" not in db.tables:
        return {}
    out = {}
    for a in range(0, len(issue_ids), 800):
        part = issue_ids[a:a + 800]
        for r in db.rows("SELECT issue_id, MIN(id) AS cid FROM gcd_cover WHERE issue_id IN (%s)%s GROUP BY issue_id" % (",".join("?" * len(part)), db.live("gcd_cover", "gcd_cover")), part):
            out[r["issue_id"]] = r["cid"]
    return out


def read(path, publishers=(), languages=("en",), year_from=None, year_to=None, max_series=None, covers=False, day=None):
    """The list's data from a GCD file.  publishers: words that must be in the publisher's name (any of them); languages: codes ('en'); year_from / year_to: the series' first year; max_series: a cap."""
    db = _Db(path)
    try:
        if not (("gcd_series" in db.tables and "gcd_issue" in db.tables) or ("series" in db.tables and "issue" in db.tables)):
            raise NotAGcdFile("%s has no GCD tables (gcd_series / gcd_issue, or series / issue)" % path)
        full = "gcd_issue" in db.tables
        day = day or datetime.date.today().isoformat()
        pubs, langs = [p.lower() for p in publishers], {x.lower() for x in languages}
        chosen = [r for r in _series_rows(db) if _wanted(r, pubs, langs, year_from, year_to)]
        chosen = chosen[:max_series] if max_series else chosen
        series, issues = [], []
        for a in range(0, len(chosen), CHUNK):
            part = chosen[a:a + CHUNK]
            rows = _issue_rows(db, [r["id"] for r in part])
            ids = [r["id"] for r in rows]
            notes, cover = (_story_notes(db, ids), _cover_ids(db, ids) if covers else {}) if full else ({}, {})
            have = {r["series_id"] for r in rows}
            series += [{"id": "gcd-s%d" % r["id"], "name": r["name"], "volume": "", "publisher": r["publisher"] or "", "year_began": str(r["year_began"] or ""), "source": "gcd",
                        "url": "https://www.comics.org/series/%d/" % r["id"], "read": day} for r in part if r["id"] in have]
            for r in rows:
                key = [{"note": n} for n in comicskeys.notes_in(r["notes"], *notes.get(r["id"], []))]
                cid = cover.get(r["id"])
                issues.append({"id": "gcd-%d" % r["id"], "series": "gcd-s%d" % r["series_id"], "number": str(r["number"] or "").strip() or "[nn]", "cover_date": iso_month(r["key_date"]),
                               "on_sale": iso_day(r["on_sale_date"]), "cover": (r["variant_name"] or "Variant") if r["variant_of_id"] else "", "variant_of": ("gcd-%d" % r["variant_of_id"]) if r["variant_of_id"] else "",
                               "cover_artist": "", "cover_url": COVER_URL.format(bucket=cid // 1000, id=cid) if cid else "", "key": key,
                               "gcd_issue_id": r["id"], "source": "gcd", "url": "https://www.comics.org/issue/%d/" % r["id"], "read": day})
        return {"about": "Imported from a Grand Comics Database file (%s) on %s: %d series, %d issues. Data CC BY-SA 4.0, credit: Grand Comics Database (comics.org)." % (Path(path).name, day, len(series), len(issues)),
                "sources": {"gcd": SOURCE}, "series": series, "issues": issues}
    finally:
        db.conn.close()
