"""Which price every total uses (roadmap "Choose your price sources").

The choice is saved per game in the vault setting 'price_pick' (it follows the account like the other per-game choices):
    {"use": "main" | "site" | <source key>, "trust": [source keys]}
    main   today's behaviour, unchanged: the card's main price (cards.price_usd).  Everyone who never touches the setting stays here.
    <key>  one source you trust; a card that source has no price for counts as unpriced.
    site   "Site price": one balanced price from the ticked sources (SITE RULE below).

Sources are the sellers whose numbers we have, not the sites that copy them:
    tcgplayer     the main price - never when it is an eBay asking price; a Scryfall / Lorcast copy of TCGplayer fills in when the main price is missing
    cardmarket    EUR (Scryfall, MTGJSON, YGOPRODeck's lowest, the card list's own price_eur), turned into dollars at the Currency setting's EUR rate
    cardkingdom, manapool, coolstuffinc, ygoprodeck   US dollars
    Never used: eBay (asking prices - license rule: never blended, modelled or used for AI), MTGO tix and Cardhoarder (digital cards), other currencies.

SITE RULE: take the ticked sources' prices for the card; with 3 or more, drop any value above 2x or below half of their median; the answer is the
median (middle value; the average of the two middle ones) of what is left.

For other code:
    price_for(vault, card_id, main_usd)  -> the price to use for one card (main_usd is the card's cards.price_usd, returned as-is in "main" mode)
    sql(vault, alias="c")                -> SQL for a card row's price: "c.price_usd" in "main" mode, else a lookup of the picked price
    prices(vault)                        -> None in "main" mode, else {card id: picked usd} for the whole game (cached until prices change)
    shown(vault, card_id, main_usd, kind) / patch(vault, rows)  -> what a card tile / list row / the drawer shows (the picked price; no-op in "main" mode)
The phone's card list (cloud/engine.build_catalog) carries the picked price, so the phone shows the same numbers; tools/price_parity.py checks every surface.
"""
import json
import re
import sqlite3
import statistics

from . import currency, pricetype

KEY = "price_pick"
DEFAULT = {"use": "main", "trust": []}
NAMES = {"tcgplayer": "TCGplayer", "cardmarket": "Cardmarket", "cardkingdom": "Card Kingdom", "manapool": "Manapool",
         "coolstuffinc": "CoolStuffInc", "ygoprodeck": "YGOPRODeck"}
NOTES = {"cardmarket": "Europe - euros turned into dollars at your Currency rate", "coolstuffinc": "lowest price across the card's printings",
         "ygoprodeck": "the price of this printing"}
ORDER = list(NAMES)
FINISH_RANK = {"normal": 0, "printing": 0, "lowest": 1}         # a printing's own price beats a 'lowest of all printings' figure
STORE = "store"                                                 # a toy's maker / shop price (price_kind 'retail price'): counts in values under every pick, marked "store price"
COPIES_OF_MAIN = "tcgplayer"                                    # rows from Scryfall / Lorcast that repeat TCGplayer: only a fill-in


# ------------------------------------------------------------------------------------------------ the rule (pure)
def site_price(values):
    """The Site price of a card from its trusted sources' dollar prices (SITE RULE in the module notes); None when there are none."""
    vals = [float(x) for x in values if x is not None and x > 0]
    if not vals:
        return None
    if len(vals) >= 3:
        m = statistics.median(vals)
        vals = [x for x in vals if m / 2 <= x <= m * 2] or vals
    return round(statistics.median(vals), 2)


def choose(cands, setting):
    """cands = {source key: usd} for one card -> the price to use under `setting` (a normalized setting, not "main")."""
    use = setting["use"]
    if use == "site":
        got = site_price(cands.get(k) for k in setting["trust"])
        return got if got is not None else cands.get(STORE)
    return cands.get(use) if cands.get(use) is not None else cands.get(STORE)         # (a toy's store price counts in every total whichever source is picked)


def is_ebay(kind):
    return str(kind or "").lower().startswith("ebay")


# ------------------------------------------------------------------------------------------------ what a game offers
def _main_label(kind):
    """Where the card-list price (cards.price_usd) came from, in words: TCGplayer market, an eBay asking price, a maker's retail price (MSRP)."""
    k = str(kind or "")
    if is_ebay(k):
        return "eBay asking price"
    if k.startswith("retail price"):
        return "Store price (MSRP) · set by maker"
    if k.lower().startswith("your estimate"):
        return "Your estimate (not a market price)"
    return f"TCGplayer {k}" if k else "TCGplayer market"


def _vendor_label(key):
    return "TCGplayer market" if key == "tcgplayer" else f"{NAMES.get(key, key)} price"


def _has_table(conn):
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='source_prices'").fetchone() is not None


def _cached(v, name, key, make):
    got = getattr(v, "_pricepick_" + name, None)
    if got and got[0] == key:
        return got[1]
    val = make()
    setattr(v, "_pricepick_" + name, (key, val))
    return val


def _rev(v):
    return (getattr(v, "game", ""), getattr(v, "_cl_rev", 0))


def offered(v):
    """[{key, name, note}] - the sources this game's card list has prices from (TCGplayer always first)."""
    def make():
        keys = {"tcgplayer"}
        try:
            if v.conn.execute("SELECT 1 FROM cards WHERE price_eur IS NOT NULL LIMIT 1").fetchone():
                keys.add("cardmarket")
        except sqlite3.Error:
            pass
        if _has_table(v.conn):
            keys.update(r[0] for r in v.conn.execute("SELECT DISTINCT vendor FROM source_prices") if r[0] in NAMES)
        return [{"key": k, "name": NAMES[k], "note": NOTES.get(k, "")} for k in ORDER if k in keys]
    return _cached(v, "offered", _rev(v), make)


# ------------------------------------------------------------------------------------------------ the person's choice
def normalize(raw, keys):
    """A saved / sent setting -> {"use", "trust"} that only names sources in `keys`; anything odd falls back to "main" (today's behaviour)."""
    if isinstance(raw, str):
        try:
            raw = json.loads(raw or "{}")
        except ValueError:
            raw = {}
    raw = raw if isinstance(raw, dict) else {}
    trust = [k for k in keys if k in (raw.get("trust") if isinstance(raw.get("trust"), list) else keys)]
    use = raw.get("use") or "main"
    if use not in ("main", "site") and use not in trust:
        use = "site" if trust else "main"
    if use == "site" and not trust:
        use = "main"
    return {"use": use, "trust": trust}


def setting(v):
    return normalize(v.get_setting(KEY), [o["key"] for o in offered(v)])


def _plain_main(raw):
    """True when a saved setting comes out as "main" whatever sources the list offers (nothing saved, or "use": "main" - normalize() never turns "main" into anything else)."""
    if isinstance(raw, str):
        try:
            raw = json.loads(raw or "{}")
        except ValueError:
            return True
    return not isinstance(raw, dict) or (raw.get("use") or "main") == "main"


def is_default(v):
    raw = v.get_setting(KEY)
    return (not raw or setting(v)["use"] == "main") and pricetype.chosen(v) == "market"


def save(v, use, trust):
    s = normalize({"use": use, "trust": list(trust or [])}, [o["key"] for o in offered(v)])
    v.set_setting(KEY, None if s["use"] == "main" and len(s["trust"]) == len(offered(v)) else json.dumps(s, separators=(",", ":")))
    return s


def label(v):
    s = setting(v)
    if s["use"] == "main":
        base = "Standard (TCGplayer)"
    elif s["use"] == "site":
        base = f"Site price ({', '.join(NAMES[k] for k in s['trust'])})"
    else:
        base = NAMES[s["use"]]
    kind = pricetype.chosen(v)
    return base if kind == "market" else f"{base} - {pricetype.NAMES[kind].lower()}"


# ------------------------------------------------------------------------------------------------ the picked prices
def _candidates(v, wanted, days=None):
    """{card id: {source key: usd}} for the sources in `wanted`, read from the card list and source_prices.
    days (a dict, optional) is filled with {(card id, source key): (source label, capture day)} for each price it returns."""
    out = {}
    eur_ok = currency.usd_from(1.0, "EUR") is not None
    for cid, usd, kind, eur, upd in v.conn.execute("SELECT id, price_usd, price_kind, price_eur, price_updated FROM cards"):
        d = {}
        if usd is not None and usd > 0 and str(kind or "").lower().startswith(("retail price", "your estimate")):          # (your own estimate of an item of yours counts in every total, like a store price - never as a market price)
            d[STORE] = usd
            if days is not None:
                days[(cid, STORE)] = (_main_label(kind), upd or "")
        if "tcgplayer" in wanted and usd is not None and usd > 0 and not is_ebay(kind):
            d["tcgplayer"] = usd
            if days is not None:
                days[(cid, "tcgplayer")] = (_main_label(kind), upd or "")
        if "cardmarket" in wanted and eur_ok and eur is not None and eur > 0:
            d["cardmarket"] = currency.usd_from(eur, "EUR")
            if days is not None:
                days[(cid, "cardmarket")] = (_vendor_label("cardmarket"), upd or "")
        if d:
            out[cid] = d
    if not _has_table(v.conn):
        return out
    rank = {}
    for cid, vendor, finish, cur, price, day in v.conn.execute(
            "SELECT card_id, vendor, finish, currency, price, day FROM source_prices WHERE price > 0 AND finish IN ('normal','printing','lowest') AND currency IN ('USD','EUR')"):
        if vendor not in wanted:
            continue
        usd = price if cur == "USD" else currency.usd_from(price, cur)
        if usd is None:
            continue
        d = out.setdefault(cid, {})
        r = FINISH_RANK[finish] + (2 if vendor == COPIES_OF_MAIN else 0)        # the main TCGplayer price (rank -1, set above) always wins over a copy
        if vendor in d and rank.get((cid, vendor), -1) <= r:
            continue
        d[vendor] = usd
        rank[(cid, vendor)] = r
        if days is not None:
            days[(cid, vendor)] = (_vendor_label(vendor), day or "")
    return out


def _wanted(s, v):
    """The sources the picked price reads: the one in use or the ticked ones (Standard: the ticked ones too - Low / Mid compare them)."""
    if s["use"] == "site":
        return set(s["trust"])
    return {s["use"]} if s["use"] != "main" else set(s["trust"]) or {o["key"] for o in offered(v)}


def _all_main(v):
    return {cid: usd for cid, usd in v.conn.execute("SELECT id, price_usd FROM cards WHERE price_usd IS NOT NULL")}


def prices(v):
    """None in "main" mode with the Market price type; else {card id: picked usd} for every card of the open game that has one (cached until the card list's prices change)."""
    kind = pricetype.chosen(v)
    if kind == "market" and _plain_main(v.get_setting(KEY)):
        return None                                  # (the usual case: no need to ask which sources the list offers - on Magic that is two reads of the whole list, ~0.17 s after signing in)
    s = setting(v)
    if s["use"] == "main" and kind == "market":
        return None
    wanted = _wanted(s, v)

    def make():
        cands = _candidates(v, wanted)
        if s["use"] == "main":
            out = dict(_all_main(v))
        else:
            out = {cid: p for cid, c in cands.items() if (p := choose(c, s)) is not None}
        if kind != "market":                         # a card without a price of this type keeps its market price
            out.update({cid: t[0] for cid, t in pricetype.typed(v, kind, cands, None, _card_ids(v)).items()})
        return {cid: round(p, 2) for cid, p in out.items()}      # (to the cent: the phone's card list holds cents too)
    return _cached(v, "prices", (_rev(v), json.dumps(s), kind, pricetype.stamp(v), currency.usd_from(1.0, "EUR")), make)


def prices_or_main(v):
    """prices(v), or None (the main price) when this game's pick cannot be read - a game read without opening it (no settings), or a price list problem that must not stop a report."""
    try:
        return prices(v)
    except Exception:  # noqa: BLE001
        return None


_MISSING = object()


def price_for(v, card_id, main_usd=_MISSING):
    """The price to use for one card.  main_usd = the card's own cards.price_usd if the caller has it (returned unchanged in "main" mode)."""
    m = prices(v)
    if m is not None:
        return m.get(card_id)
    if main_usd is _MISSING:
        main_usd = (v.card_basic(card_id) or {}).get("price_usd")
    return main_usd


def shown(v, card_id, main_usd, kind=""):
    """(price, price kind) a card tile, list row or the drawer shows: (main_usd, kind) in "main" mode; else the picked price.  The kind (an 'eBay asking price', a 'retail price')
    stays only while the picked number IS that same main price - an eBay asking price is never shown as a picked price (license: labelled asking prices only, never blended)."""
    return shown_in(prices(v), card_id, main_usd, kind)


def shown_in(m, card_id, main_usd, kind=""):
    """shown() with the picked prices already in hand (m = prices(v), None in "main" mode) - for code that reads a game it has not opened."""
    if m is None:
        return main_usd, kind or ""
    p = m.get(card_id)
    return p, (kind or "") if p is not None and p == main_usd and not is_ebay(kind) else ""


def _main_src(v, ids):
    """{card id: (source label, capture day)} for the card-list price of THESE cards (just the rows on screen: reading the whole list cost the first screen after signing in ~0.1 s)."""
    ids = [i for i in dict.fromkeys(ids) if isinstance(i, str)]
    out = {}
    for i in range(0, len(ids), 500):
        part = ids[i:i + 500]
        for cid, kind, upd in v.conn.execute(f"SELECT id, price_kind, price_updated FROM cards WHERE price_usd IS NOT NULL AND id IN ({','.join('?' * len(part))})", part):
            out[cid] = (_main_label(kind), upd or "")
    return out


def list_sources(v, ids):
    """{card id: {source, date}} of the card-list price (cards.price_usd) of these cards - for screens that show that price as it is (Portfolios)."""
    return {k: {"source": a, "date": b} for k, (a, b) in _main_src(v, ids).items()}


def _picked_src(v):
    """{card id: (source label, capture day)} for the picked price of each card (cached like prices()).  Site price: the label names the ticked sources and the day is the
    OLDEST of the ticked prices a card has, so an age is never understated.  A price type other than Market: the cards that have one say which (Lowest of 3 sources ...),
    the rest keep their market line plus 'no low price, market shown'."""
    s = setting(v)
    kind = pricetype.chosen(v)
    if s["use"] == "main" and kind == "market":
        return {}
    wanted = _wanted(s, v)

    def make():
        days = {}
        out = {}
        site = label(v) if s["use"] == "site" else ""
        cands = _candidates(v, wanted, days)
        if s["use"] == "main":
            out = _main_src(v, list(_card_ids(v)))
        for cid, c in cands.items():
            if s["use"] == "main":
                break
            if s["use"] == "site":
                ks = [k for k in s["trust"] if k in c]
                if ks:
                    out[cid] = (site, min(days[(cid, k)][1] for k in ks))
                elif (cid, STORE) in days:
                    out[cid] = days[(cid, STORE)]
            elif (cid, s["use"]) in days:
                out[cid] = days[(cid, s["use"])]
            elif (cid, STORE) in days:
                out[cid] = days[(cid, STORE)]
        if kind != "market":
            got = pricetype.typed(v, kind, cands, days, _card_ids(v))
            for cid, (words, day) in list(out.items()):
                out[cid] = (words, day) if cid in got else (f"{words} ({pricetype.fallback_words(kind)})", day)
            out.update({cid: (t[1], t[2]) for cid, t in got.items()})
        return out
    return _cached(v, "picked_src", (_rev(v), json.dumps(s), kind, pricetype.stamp(v), currency.usd_from(1.0, "EUR")), make)


def source_info(v, card_id):
    """{source, date} of the price a card shows (the same one shown() gives): the source in words and the day it was captured ('' when not known).
    {} when the card has no price.  Works in both modes; the age is worked out where it is shown."""
    got = (_main_src(v, [str(card_id)]) if prices(v) is None else _picked_src(v)).get(str(card_id))
    return {"source": got[0], "date": got[1]} if got else {}


def _card_ids(v):
    return _cached(v, "ids", _rev(v), lambda: {r[0] for r in v.conn.execute("SELECT id FROM cards")})


def patch(v, rows, id="id", price="price", kind="priceKind"):
    """Rows a screen shows (dicts) -> each CARD row's price (and price kind, when the row has one) follows the pick; rows without a price, sealed products and other games'
    rows are left alone.  Every card row that has a price also gets priceSrc = {source, date} (where that price came from and when it was captured).
    In "main" mode the price itself is not changed.  Returns rows."""
    m = prices(v)
    ids = _card_ids(v) if m is not None else None
    table = _main_src(v, [r.get(id) for r in rows]) if m is None else _picked_src(v)
    for r in rows:
        cid = r.get(id)
        if price not in r or not isinstance(cid, str):
            continue
        if m is not None:
            if cid not in ids:
                continue
            r[price], k = shown(v, cid, r.get(price), r.get(kind))
            if kind in r:
                r[kind] = k
        got = table.get(cid)
        if got and r.get(price) is not None:
            r["priceSrc"] = {"source": got[0], "date": got[1]}
    return rows


def _box(v):
    """[price map, graded map] behind pick_usd() / graded_usd(), registered ONCE per connection: registering a function again while another query is still being read (the Find & Add
    warm-up keeps one open) fails with "Error creating function", so a new map is swapped into the box instead."""
    box = v.__dict__.get("_pricepick_box")
    if box is None:
        box = v._pricepick_box = [{}, {}]
        v.conn.create_function("pick_usd", 1, lambda cid, _b=box: _b[0].get(cid))
        v.conn.create_function("graded_usd", 3, lambda cid, co, gr, _b=box: (_b[1].get((str(cid), finish_key(co, gr))) or (None,))[0])
    return box


def sql(v, alias="c", lot=None):
    """SQL for a card row's price: "<alias>.price_usd" in "main" mode (no cost), else pick_usd(<alias>.id) backed by prices(v).
    lot="l" (the alias of a lots table in the same query) -> the price of THAT COPY: a graded copy uses its grade's price when the card list has one (graded_price below), else the card's price.
    Without a graded copy that has a graded price this is exactly the card price, so nothing changes (or costs anything) for anyone who never grades."""
    m = prices(v)
    if m is None:
        base = f"{alias}.price_usd"
    else:
        _box(v)[0] = m
        base = f"pick_usd({alias}.id)"
    if lot:
        g = _graded_map(v)
        if g:
            _box(v)[1] = g
            return f"COALESCE(CASE WHEN {lot}.graded=1 THEN graded_usd({lot}.card_id,{lot}.grade_company,{lot}.grade) END,{base})"
    return base


# ------------------------------------------------------------------------------------------------ graded copies (ONE rule for every value screen)
def finish_key(company, grade):
    """How the card list writes a graded price's finish: company and grade together in lower case ('psa10', 'bgs9.5')."""
    return re.sub(r"\s+", "", f"{company or ''}{grade or ''}").lower()


def _graded_lookup(v, keys):
    """{(card id, finish key): (usd, source words)} for these (card id, finish key) pairs, from the card list's graded price rows (source_prices).  Dollars or euros; never eBay; a pair with no row is absent (never guessed)."""
    out = {}
    if not keys or not _has_table(v.conn):
        return out
    from . import currency
    finishes = sorted({k[1] for k in keys})
    got = {}
    for i in range(0, len(finishes), 400):
        part = finishes[i:i + 400]
        for cid, finish, vendor, cur, price in v.conn.execute(f"SELECT card_id, finish, vendor, currency, price FROM source_prices WHERE finish IN ({','.join('?' * len(part))}) AND price>0", part):
            if (str(cid), finish) in keys and not str(vendor or "").lower().startswith("ebay"):
                usd = price if cur == "USD" else currency.usd_from(price, cur) if cur == "EUR" else None
                if usd is not None:
                    vals, names = got.setdefault((str(cid), finish), ([], set()))
                    vals.append(usd)
                    names.add(NAMES.get(vendor, vendor))
    for k, (vals, names) in got.items():
        p = site_price(vals)
        if p is not None:
            out[k] = (p, ", ".join(sorted(names)))
    return out


def _graded_map(v):
    """{(card id, finish key): (usd, source)} for every graded copy in the collection that has a graded price (cached until copies or prices change); {} when there are none."""
    try:
        fp = v.conn.execute("SELECT COUNT(*), COALESCE(MAX(updated_at),''), COALESCE(SUM(id),0) FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND graded=1 AND qty>0", (v.user_id, v.game)).fetchone()
    except Exception:  # noqa: BLE001 - a vault with no copies table yet
        return {}
    if not fp[0]:
        return {}
    from . import currency

    def make():
        keys = {(str(r[0]), finish_key(r[1], r[2])) for r in v.conn.execute(
            "SELECT DISTINCT card_id, grade_company, grade FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND graded=1 AND qty>0", (v.user_id, v.game))}
        return _graded_lookup(v, keys)
    return _cached(v, "graded", (_rev(v), tuple(fp), currency.usd_from(1.0, "EUR")), make)


def graded_price(v, card_id, company, grade):
    """(usd, source words) of this card at this grade, or None when the card list holds no graded price for it ("no graded price yet"; never guessed, never an eBay price)."""
    if not company or not grade:
        return None
    k = (str(card_id), finish_key(company, grade))
    return _graded_map(v).get(k) or _graded_lookup(v, {k}).get(k)


def copy_price(v, card_id, graded, company, grade, raw=_MISSING):
    """The price of ONE copy, whatever screen asks: a graded copy's graded price when it exists, else the card's price (raw = the card's picked price if the caller has it)."""
    if graded:
        gp = graded_price(v, card_id, company, grade)
        if gp:
            return gp[0]
    return price_for(v, card_id, raw) if raw is _MISSING else raw


def attach_owned(v, rows, id="id", price="price", qty="qty"):
    """Card tiles / list rows (dicts) -> each owned card gets value = what its copies are worth (a graded copy at its graded price when one exists, the row's price for the rest) and
    noGradedPrice = how many graded copies have no graded price yet (they stay at the raw price).  Rows that are not owned are left alone."""
    mine = {r[id]: r for r in rows if isinstance(r.get(id), str) and (r.get(qty) or 0) > 0}
    if not mine:
        return rows
    graded = {}
    ids = list(mine)
    for i in range(0, len(ids), 500):
        part = ids[i:i + 500]
        for cid, q, co, gr in v.conn.execute(f"SELECT card_id, qty, grade_company, grade FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND graded=1 AND card_id IN ({','.join('?' * len(part))})", (v.user_id, v.game, *part)):
            graded.setdefault(cid, []).append((q, co, gr))
    for cid, r in mine.items():
        raw, n = r.get(price), r[qty]
        total, lacking = 0.0, 0
        for q, co, gr in graded.get(cid, ()):
            gp = graded_price(v, cid, co, gr)
            n -= q
            if gp:
                total += gp[0] * q
            else:
                lacking += q
                n += q                                     # (no graded price: this copy stays at the raw price)
        total += (raw or 0) * n
        r["value"] = None if raw is None and total == 0 else round(total, 2)
        if lacking:
            r["noGradedPrice"] = lacking
    return rows
