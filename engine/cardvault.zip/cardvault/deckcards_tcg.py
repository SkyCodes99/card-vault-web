"""Yu-Gi-Oh! and Magic: what the deck builder reads from a card of the game's card list (see deckcards.py for the other games).
Yu-Gi-Oh!  the card type (ext "Card Type": Effect Monster, Fusion Monster, Spell Card ...) gives the section; Fusion / Synchro / Xyz / Link monsters belong in the Extra Deck.
Magic      the type line (ext SubType) gives the section, basic lands and legendary creatures; colours, mana value and colour identity come from the facts tools/enrich_mtg.py adds."""
import re

YGO_SECTIONS = ("Monsters", "Spells", "Traps", "Extra Deck", "Other")
UA_SECTIONS = ("Characters", "Events", "Sites", "Action Points", "Other")
MTG_SECTIONS = ("Creatures", "Planeswalkers", "Instants", "Sorceries", "Artifacts", "Enchantments", "Lands", "Battles", "Other")
_PAREN_TAIL = re.compile(r"\s*\([^)]*\)\s*$")
_EXTRA = re.compile(r"\b(fusion|synchro|xyz|link)\b", re.I)
_BASIC_NAME = re.compile(r"^(snow-covered )?(plains|island|swamp|mountain|forest)$|^wastes$", re.I)
_DASH = re.compile("\\s+[\u2014\u2013\ufffd-]\\s+")
_COLOR = {"W": "White", "U": "Blue", "B": "Black", "R": "Red", "G": "Green"}
_LAND_COLOR = {"plains": "W", "island": "U", "swamp": "B", "mountain": "R", "forest": "G"}
_SECTION_WORDS = (("Land", "Lands"), ("Creature", "Creatures"), ("Planeswalker", "Planeswalkers"), ("Battle", "Battles"), ("Instant", "Instants"), ("Sorcery", "Sorceries"),
                  ("Artifact", "Artifacts"), ("Enchantment", "Enchantments"))


def strip_tail(name):
    """'Dark Magician (Alternate Art)' -> 'Dark Magician' (a printing's label is not part of the card's name)."""
    return _PAREN_TAIL.sub("", name or "").strip()


# ------------------------------------------------------------------------------------------------ Yu-Gi-Oh!
def ygo_type(info_raw, category):
    ext = (info_raw or {}).get("ext") or {}
    return str(ext.get("Card Type") or ext.get("CardType") or category or "").strip()


def ygo_section(card_type):
    t = (card_type or "").lower()
    if "spell" in t:
        return "Spells"
    if "trap" in t:
        return "Traps"
    if "skill" in t or "token" in t:
        return "Other"
    if "monster" in t and _EXTRA.search(t):
        return "Extra Deck"
    return "Monsters" if "monster" in t else "Other"


# ------------------------------------------------------------------------------------------------ Magic
def type_line(ext):
    return str((ext or {}).get("SubType") or "").replace("\xa0", " ")


def _front(line):
    face = line.split("//")[0].strip()
    parts = _DASH.split(face, maxsplit=1)
    return parts[0], (parts[1] if len(parts) > 1 else "")


def mtg_section(line):
    words = _front(line)[0]
    for w, sec in _SECTION_WORDS:
        if re.search(r"\b" + w + r"\b", words):
            return sec
    return "Other"


def mtg_is_basic_land(name, line):
    front = _front(line)[0]
    return bool(re.search(r"\bBasic\b", front) and re.search(r"\bLand\b", front)) or bool(_BASIC_NAME.match(strip_tail(name)))


def _symbols(text):
    out = set()
    for tok in re.findall(r"\{([^}]*)\}", text or ""):
        out |= {p for p in tok.upper().split("/") if p in _COLOR}
    return out


def mtg_identity(ext, text=""):
    """The card's colour identity as a set of W U B R G letters, or None when the list has no colour facts for it yet.
    The facts file's own ColorIdentity wins; otherwise colours + the symbols in the mana cost and rules text (not the reminder text) + the basic land types."""
    ext = ext or {}
    if "ColorIdentity" in ext:
        return {c for c in str(ext.get("ColorIdentity") or "").split(",") if c in _COLOR}
    if "Colors" not in ext:
        return None
    ids = {c for c in str(ext.get("Colors") or "").split(",") if c in _COLOR}
    ids |= _symbols(ext.get("ManaCost"))
    ids |= _symbols(re.sub(r"\([^)]*\)", " ", text or ""))
    sub = _front(type_line(ext))[1].lower()
    ids |= {_LAND_COLOR[w] for w in re.findall(r"[a-z]+", sub) if w in _LAND_COLOR}
    return ids


def describe_mtg(info, ext, text):
    line = type_line(ext)
    front = _front(line)[0]
    ident = mtg_identity(ext, text)
    cols = [_COLOR[c] for c in "WUBRG" if c in str(ext.get("Colors") or "").split(",")] if "Colors" in ext else []
    mv = ext.get("ManaValue")
    info.update(section=mtg_section(line), key=strip_tail(info["name"]).lower(), colors=cols or (["Colorless"] if "Colors" in ext else []), typeLine=line,
                cost=int(mv) if str(mv).strip().lstrip("-").isdigit() else None, basic=mtg_is_basic_land(info["name"], line), identity=None if ident is None else "".join(c for c in "WUBRG" if c in ident),
                legendary=bool(re.search(r"\bLegendary\b", front)), creature=bool(re.search(r"\bCreature\b", front)))
    return info


def describe_ygo(info, raw, category):
    t = ygo_type(raw, category)
    info.update(section=ygo_section(t), key=strip_tail(info["name"]).lower(), cardType=t, colors=[], cost=None)
    return info


# ------------------------------------------------------------------------------------------------ Union Arena
_UA_KINDS = (("action", "Action Points"), ("character", "Characters"), ("event", "Events"), ("site", "Sites"))


def ua_number(number):
    """'UE17BT/SLG-1-035' and 'SLG-1-035' are the same card number for the deck rules."""
    return str(number or "").split("/")[-1].strip().upper()


def describe_ua(info, raw, category):
    ext = (raw or {}).get("ext") or {}
    kind = str(category or ext.get("CardType") or "").lower()
    cost = str(ext.get("RequiredEnergy") or "").strip()
    info.update(section=next((s for w, s in _UA_KINDS if w in kind), "Other"), key=ua_number(info["number"]) or strip_tail(info["name"]).lower(), colors=[],
                series=str(ext.get("SeriesName") or "").strip(), cost=int(cost) if cost.isdigit() else None)
    return info
