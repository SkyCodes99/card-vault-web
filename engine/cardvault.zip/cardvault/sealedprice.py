"""The price of a sealed product the person owns, found by its NAME.

Names differ between where a product came from (typed by hand, an import from Collectr, the product list): accents (Pokémon / Pokemon), brackets and notes in
parentheses ('(Exclusive)'), punctuation and word order.  So the name is folded (accents, case, punctuation, bracketed notes dropped) and matched exactly first,
then by the words it shares with a product (all of the shorter name's words must appear in the other).  A close - not exact - match is labelled as such."""
import re
import unicodedata


def fold(s):
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch)).lower()
    s = re.sub(r"[\(\[].*?[\)\]]", " ", s)                       # '(Exclusive)', '[Kangaskhan]'
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


_STOP = {"the", "a", "of", "and", "pokemon", "tcg", "trading", "card", "game"}


def _tokens(folded):
    return {w for w in folded.split() if w not in _STOP}


def _index(v):
    n, last = v.conn.execute("SELECT COUNT(*), COALESCE(MAX(price_updated),'') FROM sealed_products WHERE price_usd IS NOT NULL").fetchone()
    sig = (n, last)
    cache = getattr(v, "_sealed_price_cache", None)
    if cache and cache[0] == sig:
        return cache
    exact, items = {}, []
    for name, usd, kind, upd in v.conn.execute("SELECT name, price_usd, price_kind, price_updated FROM sealed_products WHERE price_usd IS NOT NULL ORDER BY price_updated"):
        f = fold(name)
        exact[f] = (usd, kind or "")
        items.append((_tokens(f), usd, kind or "", f))
    cache = (sig, exact, items)
    v._sealed_price_cache = cache
    return cache


def price_for(v, name):
    """{'price': usd, 'kind': text} or None.  kind is '' for an exact match, 'close match' when it was matched by shared words."""
    try:
        _, exact, items = _index(v)
    except Exception:  # noqa: BLE001 - a game with no sealed list
        return None
    f = fold(name)
    if not f:
        return None
    hit = exact.get(f)
    if hit:
        return {"price": hit[0], "kind": hit[1]}
    t = _tokens(f)
    if len(t) < 2:
        return None
    best, score = None, 0.0
    for tk, usd, kind, pf in items:
        small, big = (t, tk) if len(t) <= len(tk) else (tk, t)
        if not small or not small <= big:
            continue
        j = len(small) / len(big)                                   # how much of the longer name the shorter one covers
        if j > score and j >= 0.6:
            best, score = (usd, kind), j
    return {"price": best[0], "kind": "close match"} if best else None
