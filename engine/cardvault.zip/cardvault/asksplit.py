"""Current eBay ASKING prices split by grade, condition and language, and the list of the newest asking prices (roadmap rows "Price per grade", "Price by condition and language", "Recent sales list").

These are what sellers ask right now for fixed-price listings, never what anything sold for (eBay gives sold prices only to approved business partners): every screen says "asking".  The numbers come
from the eBay listings the daily run already reads (tools/ebay_splits.py for cards, tools/ebay_prices.py for the toy lines); nothing is fetched when a card is opened.
Two small tables in the game's cards.db:
    ask_split(card_id, kind, label, usd, n, at)       kind 'grade' ("PSA 10"), 'condition' ("Near Mint"), 'language' ("Japanese"); usd = the middle of the cheaper half of n sellers' asks
    ask_recent(card_id, pos, usd, title, listed, url, label, at)   the newest individual asks (listed day, link to the listing); no seller is kept
eBay API License Agreement: both tables are emptied of rows older than askexpiry.MAX_AGE_HOURS (cardvault/askexpiry.expire) by the daily run and by the app itself; for_card() also ignores them."""
import time

from . import ebayprices, listingtags

MIN_SELLERS = 2                      # a grade / condition / language line needs this many different sellers
RECENT_KEEP = 10
GRADE_ORDER = {"BGS": 0, "CGC": 1, "PSA": 2}
CONDITION_ORDER = ("Near Mint", "Lightly Played", "Moderately Played", "Heavily Played", "Damaged")
SCHEMA = (
    "CREATE TABLE IF NOT EXISTS ask_split(card_id TEXT NOT NULL, kind TEXT NOT NULL, label TEXT NOT NULL, usd REAL NOT NULL, n INTEGER NOT NULL, at TEXT NOT NULL, PRIMARY KEY(card_id, kind, label)) WITHOUT ROWID",
    "CREATE TABLE IF NOT EXISTS ask_recent(card_id TEXT NOT NULL, pos INTEGER NOT NULL, usd REAL NOT NULL, title TEXT, listed TEXT, url TEXT, label TEXT, at TEXT NOT NULL, PRIMARY KEY(card_id, pos)) WITHOUT ROWID",
)


def ensure(conn):
    for sql in SCHEMA:
        conn.execute(sql)


def _stamp():
    return time.strftime("%Y-%m-%d %H:%M", time.gmtime())


def _label(tag):
    if tag["grader"]:
        return f"{tag['grader']} {tag['grade']}"
    return tag["condition"]


def _group(it):
    tag = listingtags.parse(it.get("title") or "")
    return _label(tag) + "|" + tag["language"]


def split(listings, name, number="", language="English"):
    """[(kind, label, usd, n)] from one search's listings.  Grade lines come from titles naming exactly one grader and one grade; condition lines from raw copies whose title says the condition; language lines
    from raw copies whose title names a language.  Copies in another language never count towards a grade or condition line (they are a different card)."""
    groups, by_lang = {}, {}
    for total, it in ebayprices.candidates(listings, name, number, _group):
        tag = listingtags.parse(it.get("title") or "")
        if not tag["ok"]:
            continue
        lang = tag["language"] or language
        if tag["grader"]:
            if lang == language:
                groups.setdefault(("grade", f"{tag['grader']} {tag['grade']}"), []).append(total)
            continue
        if lang == language and tag["condition"]:
            groups.setdefault(("condition", tag["condition"]), []).append(total)
        if tag["language"]:                                               # (one price per seller per language - its cheapest: a shop's NM and LP copies are one seller, not two)
            who = (it.get("seller") or {}).get("username") or it.get("itemId")
            mine = by_lang.setdefault(tag["language"], {})
            mine[who] = min(total, mine.get(who, total))
    for lang, per_seller in by_lang.items():
        groups[("language", lang)] = list(per_seller.values())
    out = []
    for (kind, label), prices in groups.items():
        usd, n = ebayprices.median_ask(prices, MIN_SELLERS)
        if usd:
            out.append((kind, label, usd, n))
    return out


def recent(listings, name, number="", language=None, keep=RECENT_KEEP):
    """[(usd, title, listed day, url, label)] the newest asking prices, newest first (a listing with no date goes last).  One per seller; lots / customs / other-language copies are left out."""
    rows = []
    for total, it in ebayprices.candidates(listings, name, number, _group):
        tag = listingtags.parse(it.get("title") or "")
        if not tag["ok"] or (language and (tag["language"] or language) != language):
            continue
        rows.append((str(it.get("itemCreationDate") or ""), round(total, 2), str(it.get("title") or "")[:140], str(it.get("itemWebUrl") or "")[:300], _label(tag)))
    rows.sort(key=lambda r: r[0], reverse=True)
    return [(usd, title, listed[:10], url, label) for listed, usd, title, url, label in rows[:keep]]


def record_split(conn, cid, rows):
    """Replace this card's split lines with `rows` (none -> the old lines are dropped: they were read from older listings).  The caller commits."""
    ensure(conn)
    conn.execute("DELETE FROM ask_split WHERE card_id=?", (str(cid),))
    at = _stamp()
    conn.executemany("INSERT INTO ask_split VALUES(?,?,?,?,?,?)", [(str(cid), k, label, usd, n, at) for k, label, usd, n in rows])


def record_recent(conn, cid, rows):
    ensure(conn)
    conn.execute("DELETE FROM ask_recent WHERE card_id=?", (str(cid),))
    at = _stamp()
    conn.executemany("INSERT INTO ask_recent VALUES(?,?,?,?,?,?,?,?)", [(str(cid), i, usd, title, listed, url, label, at) for i, (usd, title, listed, url, label) in enumerate(rows)])


def _grade_key(label):
    grader, _, grade = label.partition(" ")
    num = grade.split(" ")[0]
    try:
        top = float(num)
    except ValueError:
        top = 0.0
    return (GRADE_ORDER.get(grader, 9), -top, 0 if " " in grade else 1)          # best first; "10 Pristine" / "10 Black Label" ahead of a plain 10


def for_card(conn, card_id, now=None):
    """What an item's detail shows: {grades: [{grader, rows: [{grade, usd, n}]}], conditions: [{label, usd, n}], languages: [...], recent: [{usd, title, listed, url, label}], at}.
    Only lines read within askexpiry.MAX_AGE_HOURS; every part is empty when the tables are not there yet."""
    from . import askexpiry
    out = {"grades": [], "conditions": [], "languages": [], "recent": [], "at": ""}
    since = (f"-{askexpiry.MAX_AGE_HOURS} hours")
    try:
        lines = conn.execute("SELECT kind, label, usd, n, at FROM ask_split WHERE card_id=? AND at >= strftime('%Y-%m-%d %H:%M', ?, ?)", (str(card_id), now or "now", since)).fetchall()
        recents = conn.execute("SELECT usd, title, listed, url, label, at FROM ask_recent WHERE card_id=? AND at >= strftime('%Y-%m-%d %H:%M', ?, ?) ORDER BY pos", (str(card_id), now or "now", since)).fetchall()
    except Exception:  # noqa: BLE001 - the tables are made by the first daily run
        return out
    by_grader = {}
    for kind, label, usd, n, at in lines:
        out["at"] = max(out["at"], at)
        if kind == "grade":
            by_grader.setdefault(label.split(" ")[0], []).append((label, {"grade": label.partition(" ")[2], "usd": usd, "n": n}))
        elif kind == "condition":
            out["conditions"].append({"label": label, "usd": usd, "n": n})
        elif kind == "language":
            out["languages"].append({"label": label, "usd": usd, "n": n})
    for grader in sorted(by_grader, key=lambda g: GRADE_ORDER.get(g, 9)):
        out["grades"].append({"grader": grader, "rows": [r for _l, r in sorted(by_grader[grader], key=lambda p: _grade_key(p[0]))]})
    out["conditions"].sort(key=lambda r: CONDITION_ORDER.index(r["label"]) if r["label"] in CONDITION_ORDER else 9)
    out["languages"].sort(key=lambda r: r["usd"], reverse=True)
    out["recent"] = [{"usd": u, "title": t, "listed": d, "url": link, "label": lab} for u, t, d, link, lab, at in recents]
    out["at"] = max([out["at"]] + [r[5] for r in recents])
    return out
