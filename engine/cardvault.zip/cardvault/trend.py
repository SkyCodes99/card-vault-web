"""Sale Data: our own saved price history, turned into a recent typical price.

Every day the website saves TCGplayer's market price for each product and publishes, per game, a small file with three numbers per product:
today's price, the typical (median) price of the last 7 days and of the last 30 days.  This module downloads that file and answers questions about it.
It is a *trend from saved TCGplayer prices*, not a list of actual sales (eBay etc.) - the screens say so."""
import gzip
import json
import os
import sqlite3

from . import sync
from .tcggames import by_game_id, data_slug


def _path(gdir):
    return os.path.join(gdir, "trend.db")


def local_built(gdir):
    try:
        c = sqlite3.connect(_path(gdir))
        try:
            r = c.execute("SELECT value FROM meta WHERE key='built'").fetchone()
        finally:
            c.close()
        return r[0] if r else ""
    except sqlite3.Error:
        return ""


def base_for(catalog_base):
    """The trend files live next to the card lists: .../catalog -> .../trend."""
    b = catalog_base.rstrip("/")
    return (b.rsplit("/", 1)[0] + "/trend") if "/" in b else "trend"


def manifest(base):
    d = sync._get(base.rstrip("/") + "/manifest.json", tries=1)
    return {**d, "games": by_game_id(d["games"])} if isinstance(d, dict) and isinstance(d.get("games"), dict) else None          # (the games under the app's own ids: Card Data names some of them differently)


def install(gdir, base, game_id):
    """Download <base>/<game>.json.gz into gdir/trend.db (kept as it was if anything looks wrong).  -> number of products."""
    data = sync._get(f"{base.rstrip('/')}/{data_slug(game_id)}.json.gz", as_json=False)
    if not data:
        return 0
    raw = bytes(data)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw)          # the web server may already have unzipped it in transit
    items = doc.get("items")
    if not isinstance(items, dict):
        raise RuntimeError("the price trend file is not readable")
    tmp = _path(gdir) + ".part"
    for suf in ("", "-wal", "-shm"):
        try:
            os.remove(tmp + suf)
        except OSError:
            pass
    c = sqlite3.connect(tmp)
    try:
        c.execute("CREATE TABLE t(id TEXT PRIMARY KEY, today REAL, p7 REAL, p30 REAL)")
        c.execute("CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT)")
        c.executemany("INSERT INTO t VALUES(?,?,?,?)", ((k, *(list(v) + [None, None, None])[:3]) for k, v in items.items() if isinstance(v, list)))
        c.execute("INSERT INTO meta VALUES('built', ?)", (str(doc.get("built") or ""),))
        c.execute("INSERT INTO meta VALUES('days', ?)", (str(int(doc.get("days") or 0)),))
        c.commit()
    finally:
        c.close()
    os.replace(tmp, _path(gdir))
    return len(items)


def ask_rows(gdir):
    """{id: (today, 7-day median, 30-day median)} of the ASKING prices saved in the card list itself (table ask_history, written by the daily eBay step) - for items that have no market-price trend.
    Asking prices, not sales: eBay's free API cannot give sold prices."""
    import statistics
    out = {}
    try:
        c = sqlite3.connect("file:" + os.path.join(gdir, "cards.db").replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
        try:
            days = c.execute("SELECT MAX(day) FROM ask_history").fetchone()[0]
            if not days:
                return out
            by = {}
            for cid, d, usd in c.execute("SELECT card_id, day, usd FROM ask_history WHERE day >= date(?, '-30 day') ORDER BY card_id, day", (days,)):
                by.setdefault(cid, []).append((d, usd))
        finally:
            c.close()
    except (sqlite3.Error, OSError):
        return out
    import datetime
    cut7 = (datetime.date.fromisoformat(days) - datetime.timedelta(days=7)).isoformat()
    for cid, pts in by.items():
        p30 = statistics.median(u for _d, u in pts)
        last7 = [u for d, u in pts if d > cut7] or [pts[-1][1]]
        out[cid] = (pts[-1][1], statistics.median(last7), p30)
    return out


class Trend:
    """Reads gdir/trend.db (empty and harmless when there is none yet)."""

    def __init__(self, gdir):
        self.rows, self.days, self.built = {}, 0, ""
        self.ask = ask_rows(gdir)                                     # eBay ASKING prices: kept apart, never mixed into the typical price (owner, 2026-11-11: split)
        p = _path(gdir)
        if not os.path.exists(p):
            return
        try:
            c = sqlite3.connect(p)
            try:
                self.rows.update({r[0]: (r[1], r[2], r[3]) for r in c.execute("SELECT id, today, p7, p30 FROM t")})
                m = dict(c.execute("SELECT key, value FROM meta").fetchall())
            finally:
                c.close()
            self.days, self.built = int(m.get("days") or 0), m.get("built") or ""
        except (sqlite3.Error, ValueError):
            self.rows = {}

    def recent(self, cid):
        """The recent typical price (7-day median), or None."""
        r = self.rows.get(str(cid))
        return r[1] if r and r[1] is not None else None

    def ask_info(self, cid):
        """The eBay asking-price line {today, recent, median30} (asking price, not a sale price), or None.  Separate from the typical price, which is real sales only."""
        r = self.ask.get(str(cid))
        return {"today": r[0], "recent": r[1], "median30": r[2]} if r else None

    def info(self, cid):
        r = self.rows.get(str(cid))
        if not r or r[1] is None:
            return None
        today, p7, p30 = r
        change = None
        if p7 is not None and p30:
            change = round((p7 - p30) / p30 * 100, 1)
        arrow = "" if change is None else ("up" if change >= 3 else "down" if change <= -3 else "flat")
        return {"recent": p7, "today": today, "median30": p30, "change": change, "trend": arrow, "days": self.days}


def for_vault(svc):
    """The Trend for the open game, cached until the file changes."""
    v = svc.vault
    gdir = os.path.dirname(v.cards_path) if hasattr(v, "cards_path") else None
    if gdir is None:
        from .db import game_dir
        gdir = game_dir(svc.cfg["data_dir"], v.game)
    p = _path(gdir)
    try:
        stamp = (v.game, os.path.getmtime(p))
    except OSError:
        stamp = (v.game, 0)
    c = getattr(svc, "_trend", None)
    if c is None or c[0] != stamp:
        c = (stamp, Trend(gdir))
        svc._trend = c
    return c[1]
