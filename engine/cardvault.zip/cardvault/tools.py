"""Collection analytics and helpers used by the Money, Organize and Trade screens (no UI code here, so it can be tested)."""
import datetime

from . import completion, grading, pricepick


def _rows(v, sql, *args):
    return v.conn.execute(sql, args).fetchall()


# ----------------------------------------------------------------------------------------------- profit / loss
def profit_loss(v):
    """One row per owned card: copies, what you paid (copies with a price), current value, gain."""
    lp = pricepick.sql(v, lot="l")                                  # each copy at its own price: a graded copy at its grade's price when one exists
    rows = _rows(v, "SELECT l.card_id, SUM(l.qty) AS qty, SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty*l.purchase_price ELSE 0 END) AS paid, "
                    f"SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty ELSE 0 END) AS paid_qty, c.name, SUM(l.qty*{lp}) AS val, SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty*{lp} END) AS known, "
                    "c.set_id, c.local_id "
                    "FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY l.card_id",
                 v.user_id, v.game)
    out = []
    cost = grading.card_costs(v)                                  # grading cost joins the cost basis
    for r in rows:
        value, known_value = r["val"], r["known"]
        r = {**dict(r), "paid": r["paid"] + cost.get(r["card_id"], 0.0)}
        gain = None if (known_value is None or not r["paid_qty"]) else known_value - r["paid"]
        out.append({"card_id": r["card_id"], "name": r["name"], "set_id": r["set_id"], "number": r["local_id"], "qty": r["qty"],
                    "paid": r["paid"] if r["paid_qty"] else None, "paid_qty": r["paid_qty"], "value": value, "gain": gain,
                    "pct": None if (gain is None or not r["paid"]) else 100.0 * gain / r["paid"]})
    return out


def profit_totals(rows):
    paid = sum(r["paid"] or 0 for r in rows if r["gain"] is not None)
    gain = sum(r["gain"] for r in rows if r["gain"] is not None)
    return {"paid": paid, "gain": gain, "tracked": sum(1 for r in rows if r["gain"] is not None), "cards": len(rows)}


# ----------------------------------------------------------------------------------------------- weekly movers
def movers(v, days=7, market=False):
    """Owned cards whose price changed over the last `days` days: [(card_id, name, old, new, change, qty)] (needs price history)."""
    since = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
    out = []
    owned = v.owned_map()
    if market:          # trending: every card the app has saved prices for (not only yours), worth at least a dollar so pennies don't dominate
        ids = [r[0] for r in v.conn.execute("SELECT DISTINCT card_id FROM u.price_history WHERE game=? AND card_id NOT LIKE 'sealed:%'", (v.game,))]
        items = [(c, owned.get(c, 0)) for c in ids]
    else:
        items = list(owned.items())
    for cid, qty in items:
        hist = v.price_history(cid)
        if len(hist) < 2:
            continue
        latest = next((h for h in reversed(hist) if h[1] is not None), None)
        past = [h for h in hist if h[0] <= since and h[1] is not None]
        base = past[-1] if past else next((h for h in hist if h[1] is not None), None)
        if not latest or not base or latest[0] == base[0] or not base[1]:
            continue
        if market and (latest[1] or 0) < 1 and (base[1] or 0) < 1:
            continue
        card = v.card_light(cid)
        out.append({"card_id": cid, "name": card["name"] if card else cid, "old": base[1], "new": latest[1],
                    "change": latest[1] - base[1], "pct": 100.0 * (latest[1] - base[1]) / base[1], "qty": qty,
                    "total_change": (latest[1] - base[1]) * qty, "since": base[0]})
    out.sort(key=(lambda r: r["pct"]) if market else (lambda r: r["total_change"]))
    return out


# ----------------------------------------------------------------------------------------------- duplicates
def duplicates(v, keep=1):
    """Cards you hold more than `keep` of: extras are tradeable.  [(card_id, name, set, number, qty, extra, value_of_extra)]"""
    out = []
    held = {cid: qty for cid, qty in v.owned_map().items() if qty > keep}
    lights = v.card_lights(held)
    for cid, qty in held.items():
        c = lights.get(cid)
        if not c:
            continue
        extra, unit = qty - keep, pricepick.price_for(v, cid, c["price_usd"])
        out.append({"card_id": cid, "name": c["name"], "set_name": c["set_name"], "number": c["local_id"], "qty": qty, "extra": extra,
                    "value": (unit or 0) * extra, "unit": unit})
    out.sort(key=lambda r: -r["value"])
    return out


# ----------------------------------------------------------------------------------------------- storage locations
def locations(v):
    """{'Binder 1': {'copies': n, 'cards': n, 'value': usd}, '(no location)': ...}"""
    rows = _rows(v, "SELECT COALESCE(NULLIF(l.location,''),'(no location)') AS loc, COUNT(DISTINCT l.card_id) AS cards, SUM(l.qty) AS copies, "
                    f"SUM(l.qty*COALESCE({pricepick.sql(v, lot='l')},0)) AS value FROM lots_s l JOIN cards c ON c.id=l.card_id "
                    "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY loc ORDER BY loc", v.user_id, v.game)
    return {r["loc"]: {"cards": r["cards"], "copies": r["copies"], "value": r["value"] or 0} for r in rows}


def cards_in_location(v, loc):
    cond = "COALESCE(l.location,'')=''" if loc in ("", "(no location)") else "l.location=?"
    args = (v.user_id, v.game) + (() if loc in ("", "(no location)") else (loc,))
    return [r[0] for r in v.conn.execute(
        f"SELECT DISTINCT l.card_id FROM lots_s l WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND {cond}", args)]


def known_locations(v):
    return [r[0] for r in v.conn.execute("SELECT DISTINCT location FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND location!='' "
                                         "ORDER BY location", (v.user_id, v.game))]


# ----------------------------------------------------------------------------------------------- finishing a set / list
def finish_ids(v, kind, key):
    """The cards a "Finish this ..." screen counts: a set's cards (without the ones the person left out of it, as Cost to complete does) or a checklist's members."""
    if kind != "set":
        return list(v.checklist_members(key))
    left = v.excluded_cards(key)
    return [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=?", (key,)) if r[0] not in left]


def finish_cost(v, card_ids):
    """What it would cost to own one of each of these cards at today's prices.
    -> {'total', 'owned', 'missing': [...cheapest first...], 'cost': usd, 'unpriced': n, 'steps': {90: usd, 95: usd, 100: usd}}"""
    owned = v.owned_map()
    ids = list(dict.fromkeys(card_ids))
    price = completion.card_costs(v, [c for c in ids if owned.get(c, 0) <= 0])           # (the ONE price of a card still to buy: the same as Cost to complete, the tiles and the wishlist)
    missing = []
    for cid in ids:
        if owned.get(cid, 0) > 0:
            continue
        c, it = v.card_light(cid), price.get(cid)
        if c:
            missing.append({"card_id": cid, "name": c["name"], "set_name": c["set_name"], "number": c["local_id"], "price": it["price"] if it else None, "ask": bool(it and it["ask"])})
    priced = sorted((m for m in missing if m["price"] is not None), key=lambda m: m["price"])
    unpriced = len(missing) - len(priced)
    total = len(ids)
    have = total - len(missing)
    steps = {}
    for pct in (80, 90, 95, 100):
        need = max(0, -(-total * pct // 100) - have)          # ceil(total*pct/100) - have
        steps[pct] = {"cards": min(need, len(priced)), "cost": sum(m["price"] for m in priced[:need]), "reachable": need <= len(priced)}
    return {"total": total, "owned": have, "missing": sorted(missing, key=lambda m: (m["price"] is None, m["price"] or 0)),
            "cost": sum(m["price"] for m in priced), "unpriced": unpriced, "asked": sum(m["price"] for m in priced if m["ask"]), "steps": steps}      # (asked: the part of the cost that is eBay asking prices)


# ----------------------------------------------------------------------------------------------- trades
def trade_summary(give, get, give_pct=100, get_pct=100):
    """give / get: [{'card_id', 'qty', 'unit'(usd or None)}].  Percentages let you value each side at, say, 80% of market."""
    def side(items, pct):
        raw = sum((i["unit"] or 0) * i["qty"] for i in items)
        return raw, raw * pct / 100.0, sum(1 for i in items if i["unit"] is None)
    g_raw, g_val, g_miss = side(give, give_pct)
    r_raw, r_val, r_miss = side(get, get_pct)
    diff = r_val - g_val
    return {"give_market": g_raw, "give_value": g_val, "get_market": r_raw, "get_value": r_val, "difference": diff,
            "unpriced": g_miss + r_miss,
            "verdict": "even" if abs(diff) < 0.5 else ("you get more" if diff > 0 else "you give more")}


def apply_trade(v, give, get, label="Trade", log=None, lenient=False):
    """Complete a trade in the collection (one undoable action): remove what you gave, add what you received."""
    owned = v.owned_map()
    problems = [i["card_id"] for i in give if owned.get(i["card_id"], 0) < i["qty"]]
    if problems and not lenient:
        raise ValueError("You don't own enough copies of: " + ", ".join(problems))
    if lenient:                                                         # a trade planned with cards that aren't tracked here: take out only what is
        give = [{**i, "qty": min(i["qty"], owned.get(i["card_id"], 0))} for i in give if owned.get(i["card_id"], 0) > 0]
    with v.action(label) as act:
        for i in give:
            left = i["qty"]
            for lot in v.lots_for(i["card_id"]):
                take = min(left, lot["qty"])
                if take:
                    v.change_lot_qty(lot["id"], -take)
                    left -= take
                if not left:
                    break
        for i in get:
            v.add_lot(i["card_id"], v.default_variant(i["card_id"]), "Near Mint", i["qty"], price=i.get("unit"), purchased=datetime.date.today().isoformat(), source="Trade")
        v.record_price_history([i["card_id"] for i in get])
        if log is not None:
            v.log_trade(log.get("partner", ""), log.get("notes", ""), log)
    return act


# ----------------------------------------------------------------------------------------------- insurance / full export rows
def inventory_rows(v):
    """Every copy with everything known about it - used by the insurance report and the full export."""
    rows = _rows(v, f"SELECT l.*, c.name, c.local_id, c.rarity, {pricepick.sql(v, lot='l')} AS price_usd, s.name AS set_name, s.serie FROM lots_s l JOIN cards c ON c.id=l.card_id "
                    "LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 ORDER BY s.release_date, c.set_id, c.sort_key, c.local_id",
                 v.user_id, v.game)
    return [dict(r) for r in rows]


# ----------------------------------------------------------------------------------------------- portfolio value over time
RANGE_DAYS = {"1d": 1, "3d": 3, "7d": 7, "14d": 14, "1m": 30, "30d": 30, "2m": 61, "3m": 91, "6m": 183, "1y": 365, "12m": 365, "2y": 730}


def portfolio_series(v, range_key="all", start=None, end=None, max_points=240, mode="full", svc=None):
    """Daily value of the copies shown right now (and what was paid for them).  mode "full" = everything owned now, at each past day's price, as far back as prices go;
    "purchase" = only copies with a purchase date, each from that date.  The work is in valueseries.py (one SQL query summed per day)."""
    from . import valueseries
    return valueseries.series(v, range_key, start, end, max_points, mode, svc)


SOURCE_SUGGESTIONS = ["Card shop", "Card show", "Online (eBay)", "Online (TCGplayer)", "Online (Cardmarket)", "Pack I opened", "Booster box", "Trade", "Gift", "Facebook / Discord", "Big box store"]


def known_sources(v):
    used = [r[0] for r in v.conn.execute("SELECT DISTINCT source FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(source,'')!='' ORDER BY source", (v.user_id, v.game))]
    return used + [s for s in SOURCE_SUGGESTIONS if s not in used]
