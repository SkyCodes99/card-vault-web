"""Collection analytics and helpers used by the Money, Organize and Trade screens (no UI code here, so it can be tested)."""
import datetime


def _rows(v, sql, *args):
    return v.conn.execute(sql, args).fetchall()


# ----------------------------------------------------------------------------------------------- profit / loss
def profit_loss(v):
    """One row per owned card: copies, what you paid (copies with a price), current value, gain."""
    rows = _rows(v, "SELECT l.card_id, SUM(l.qty) AS qty, SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty*l.purchase_price ELSE 0 END) AS paid, "
                    "SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty ELSE 0 END) AS paid_qty, c.name, c.price_usd, c.set_id, c.local_id "
                    "FROM u.lots l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY l.card_id",
                 v.user_id, v.game)
    out = []
    for r in rows:
        price = r["price_usd"]
        value = None if price is None else price * r["qty"]
        known_value = None if price is None else price * r["paid_qty"]
        gain = None if (known_value is None or not r["paid_qty"]) else known_value - r["paid"]
        out.append({"card_id": r["card_id"], "name": r["name"], "set_id": r["set_id"], "number": r["local_id"], "qty": r["qty"],
                    "paid": r["paid"] if r["paid_qty"] else None, "paid_qty": r["paid_qty"], "value": value, "gain": gain,
                    "pct": None if (gain is None or not r["paid"]) else 100.0 * gain / r["paid"]})
    return out


def profit_totals(rows):
    paid = sum(r["paid"] or 0 for r in rows if r["gain"] is not None)
    gain = sum(r["gain"] for r in rows if r["gain"] is not None)
    return {"paid": paid, "gain": gain, "tracked": sum(1 for r in rows if r["gain"] is not None), "cards": len(rows)}


# ----------------------------------------------------------------------------------------------- weekly movers
def movers(v, days=7):
    """Owned cards whose price changed over the last `days` days: [(card_id, name, old, new, change, qty)] (needs price history)."""
    since = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
    out = []
    for cid, qty in v.owned_map().items():
        hist = v.price_history(cid)
        if len(hist) < 2:
            continue
        latest = next((h for h in reversed(hist) if h[1] is not None), None)
        past = [h for h in hist if h[0] <= since and h[1] is not None]
        base = past[-1] if past else next((h for h in hist if h[1] is not None), None)
        if not latest or not base or latest[0] == base[0] or not base[1]:
            continue
        card = v.card_light(cid)
        out.append({"card_id": cid, "name": card["name"] if card else cid, "old": base[1], "new": latest[1],
                    "change": latest[1] - base[1], "pct": 100.0 * (latest[1] - base[1]) / base[1], "qty": qty,
                    "total_change": (latest[1] - base[1]) * qty, "since": base[0]})
    out.sort(key=lambda r: r["total_change"])
    return out


# ----------------------------------------------------------------------------------------------- duplicates
def duplicates(v, keep=1):
    """Cards you hold more than `keep` of: extras are tradeable.  [(card_id, name, set, number, qty, extra, value_of_extra)]"""
    out = []
    for cid, qty in v.owned_map().items():
        if qty > keep:
            c = v.card_light(cid)
            if not c:
                continue
            extra = qty - keep
            out.append({"card_id": cid, "name": c["name"], "set_name": c["set_name"], "number": c["local_id"], "qty": qty, "extra": extra,
                        "value": (c["price_usd"] or 0) * extra, "unit": c["price_usd"]})
    out.sort(key=lambda r: -r["value"])
    return out


# ----------------------------------------------------------------------------------------------- storage locations
def locations(v):
    """{'Binder 1': {'copies': n, 'cards': n, 'value': usd}, '(no location)': ...}"""
    rows = _rows(v, "SELECT COALESCE(NULLIF(l.location,''),'(no location)') AS loc, COUNT(DISTINCT l.card_id) AS cards, SUM(l.qty) AS copies, "
                    "SUM(l.qty*COALESCE(c.price_usd,0)) AS value FROM u.lots l JOIN cards c ON c.id=l.card_id "
                    "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY loc ORDER BY loc", v.user_id, v.game)
    return {r["loc"]: {"cards": r["cards"], "copies": r["copies"], "value": r["value"] or 0} for r in rows}


def cards_in_location(v, loc):
    cond = "COALESCE(l.location,'')=''" if loc in ("", "(no location)") else "l.location=?"
    args = (v.user_id, v.game) + (() if loc in ("", "(no location)") else (loc,))
    return [r[0] for r in v.conn.execute(
        f"SELECT DISTINCT l.card_id FROM u.lots l WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND {cond}", args)]


def known_locations(v):
    return [r[0] for r in v.conn.execute("SELECT DISTINCT location FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND location!='' "
                                         "ORDER BY location", (v.user_id, v.game))]


# ----------------------------------------------------------------------------------------------- finishing a set / list
def finish_cost(v, card_ids):
    """What it would cost to own one of each of these cards at today's prices.
    -> {'total', 'owned', 'missing': [...cheapest first...], 'cost': usd, 'unpriced': n, 'steps': {90: usd, 95: usd, 100: usd}}"""
    owned = v.owned_map()
    ids = list(dict.fromkeys(card_ids))
    missing = []
    for cid in ids:
        if owned.get(cid, 0) > 0:
            continue
        c = v.card_light(cid)
        if c:
            missing.append({"card_id": cid, "name": c["name"], "set_name": c["set_name"], "number": c["local_id"], "price": c["price_usd"]})
    priced = sorted((m for m in missing if m["price"] is not None), key=lambda m: m["price"])
    unpriced = len(missing) - len(priced)
    total = len(ids)
    have = total - len(missing)
    steps = {}
    for pct in (80, 90, 95, 100):
        need = max(0, -(-total * pct // 100) - have)          # ceil(total*pct/100) - have
        steps[pct] = {"cards": min(need, len(priced)), "cost": sum(m["price"] for m in priced[:need]), "reachable": need <= len(priced)}
    return {"total": total, "owned": have, "missing": sorted(missing, key=lambda m: (m["price"] is None, m["price"] or 0)),
            "cost": sum(m["price"] for m in priced), "unpriced": unpriced, "steps": steps}


# ----------------------------------------------------------------------------------------------- trades
def trade_summary(give, get, give_pct=100, get_pct=100):
    """give / get: [{'card_id', 'qty', 'unit'(usd or None)}].  Percentages let you value each side at, say, 80% of market."""
    def side(items, pct):
        raw = sum((i["unit"] or 0) * i["qty"] for i in items)
        return raw, raw * pct / 100.0, sum(1 for i in items if i["unit"] is None)
    g_raw, g_val, g_miss = side(give, give_pct)
    r_raw, r_val, r_miss = side(get, get_pct)
    diff = r_val - g_val
    return {"give_market": g_raw, "give_value": g_val, "get_market": r_raw, "get_value": r_val, "difference": diff,
            "unpriced": g_miss + r_miss,
            "verdict": "even" if abs(diff) < 0.5 else ("you get more" if diff > 0 else "you give more")}


def apply_trade(v, give, get, label="Trade"):
    """Complete a trade in the collection (one undoable action): remove what you gave, add what you received."""
    owned = v.owned_map()
    problems = [i["card_id"] for i in give if owned.get(i["card_id"], 0) < i["qty"]]
    if problems:
        raise ValueError("You don't own enough copies of: " + ", ".join(problems))
    with v.action(label) as act:
        for i in give:
            left = i["qty"]
            for lot in v.lots_for(i["card_id"]):
                take = min(left, lot["qty"])
                if take:
                    v.change_lot_qty(lot["id"], -take)
                    left -= take
                if not left:
                    break
        for i in get:
            v.add_lot(i["card_id"], v.default_variant(i["card_id"]), "Near Mint", i["qty"], price=i.get("unit"))
        v.record_price_history([i["card_id"] for i in get])
    return act


# ----------------------------------------------------------------------------------------------- insurance / full export rows
def inventory_rows(v):
    """Every copy with everything known about it - used by the insurance report and the full export."""
    rows = _rows(v, "SELECT l.*, c.name, c.local_id, c.rarity, c.price_usd, s.name AS set_name, s.serie FROM u.lots l JOIN cards c ON c.id=l.card_id "
                    "LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 ORDER BY s.release_date, c.set_id, c.sort_key, c.local_id",
                 v.user_id, v.game)
    return [dict(r) for r in rows]
