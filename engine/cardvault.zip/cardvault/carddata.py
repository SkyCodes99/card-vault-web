"""Card Data: the ONE shared place the card lists, prices and price trends are read from (https://sky-carddata-tnnwxj.azurewebsites.net, public, read-only).
The app keeps only a cache identical to it.  The old place (next to the website) is a fallback that is only used while Card Data cannot be reached."""
BASE = "https://sky-carddata-tnnwxj.azurewebsites.net"
last_errors = []          # why the last look at a manifest failed (shown in Settings > Card lists, so a problem can be seen instead of guessed)


def bases(svc, kind):
    """Where to look for 'catalog' / 'prices' / 'trend', best first: an address set in the settings, else Card Data, then the website's own old copy."""
    from . import runtime
    out = []
    own = svc.cfg.get(f"{kind}_base") or (svc.cfg.get("catalog_base") if kind == "catalog" else "") or ""
    if own and not runtime.IN_BROWSER and str(own).startswith(("http://", "https://")):          # an address set on purpose (tests, a mirror); in the browser an old saved address must never win
        out.append(own.rstrip("/"))
    else:
        out.append(f"{(svc.cfg.get('carddata_url') or BASE).rstrip('/')}/{kind}")
    if runtime.IN_BROWSER:
        if svc.cfg.get("site_url"):
            out.append(f"{svc.cfg['site_url']}/{kind}")                       # the website's own old copy (only a fallback)
    else:
        try:
            from .webapi import accountapi
            url = accountapi.server_url(svc)
            if url:
                out.append(f"{url}/{kind}")
        except Exception:  # noqa: BLE001
            pass
    seen, res = set(), []
    for b in out:
        if b and b not in seen:
            seen.add(b)
            res.append(b)
    return res


def first_manifest(svc, kind, fetch):
    """-> (base, manifest) from the first place that answers, else (None, None).  `fetch` is the module's manifest(base) function."""
    last_errors.clear()
    for b in bases(svc, kind):
        try:
            m = fetch(b)
        except Exception as e:  # noqa: BLE001
            m = None
            last_errors.append(f"{b}: {str(e)[:160]}")
        if m:
            return b, m
    return None, None
