"""Video games (physical) list: every platform is a "set" (NES, PlayStation 2, Nintendo Switch ...), every game RELEASED ON a platform an item of its own - so one game on three platforms is three items, each opening
with its other versions and the other games of its series (cardvault/webapi/gameversions.py).  No network at refresh.

Where the data comes from (docs/video_games_data.md has the whole survey):
  * videogames_import.json in the list's folder - written by tools/harvest_videogames.py (a bigger harvest than the one that ships); when it exists it is the list.
  * else cardvault/videogames_data.json - the best-known games of each platform with the series they belong to, read from Wikidata (CC0) with tools/harvest_videogames.py.
Every fact an item shows is one Wikidata states (publisher, developer, series, genre, release dates with their platform and place); one it does not state is left out, never guessed.  Each stated fact gets a
provenance record.  PRICES: none - no free source with real video game prices is allowed (docs/video_games_data.md lists the candidates for the owner).  PICTURES: only a Commons file with a free licence on
record that is certainly this platform's release AND passed the automatic picture check (photoverify); the rest show "No picture yet" and a Review note.
A stable id (`videogames:<Wikidata id>-<platform id>`) and the game's Wikidata id are kept in raw (`key`, `game`) for the cover scanner."""
import json
import os
import time
import urllib.parse

from . import photoverify, provenance, videogames_platforms as plats
from .comics import month_day
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

BUNDLED = "videogames_data.json"
IMPORT_NAME = "videogames_import.json"
SAMPLE = os.path.join(os.path.dirname(os.path.abspath(__file__)), BUNDLED)
FILEPATH = "https://commons.wikimedia.org/wiki/Special:FilePath/"
WD = "https://www.wikidata.org/wiki/"
SOURCE = ("w:wikidata.org", "Wikidata (CC0)")
NO_PICTURE = "No picture yet: Wikidata and Commons give no cover we may show that is certainly this platform's release (a free licence on record, then the automatic picture check)"
GAME_KEY = "game"


def load(gdir=None):
    """The list's data: the import in the list's folder when there is one, else the bundled data."""
    path = os.path.join(gdir, IMPORT_NAME) if gdir else ""
    with open(path if path and os.path.exists(path) else SAMPLE, encoding="utf-8") as f:
        return json.load(f)


def release_facts(game, platform):
    """{fact: value} of the dates Wikidata states for this game ON this platform (with their places), else the game's own first date.  '' values are left out by the caller."""
    mine = sorted((r for r in game.get("rel", []) if r["p"] == platform), key=lambda r: (r["d"] + "-99-99")[:10])          # (a bare year sorts after the exact days of that year)
    if mine:
        out = {"Release date": month_day(mine[0]["d"]) if len(mine[0]["d"]) < 10 else mine[0]["d"]}
        regional = ["%s: %s" % (r["r"], r["d"]) for r in mine if r["r"]]
        if regional:
            out["Release dates by region"] = "; ".join(regional)
            out["Regions"] = " / ".join(dict.fromkeys(r["r"] for r in mine if r["r"]))
        return out
    anyp = sorted((r["d"] for r in game.get("rel", []) if not r["p"]), key=lambda d: (d + "-99-99")[:10])
    return {"First released (the game, platform not stated)": anyp[0]} if anyp else {}


def facts_of(game, platform, series_names):
    info = plats.BY_QID[platform]
    out = {"Platform": info["name"], "Maker": info["maker"], "Format": info["media"], "Publisher": " / ".join(game.get("pub", [])), "Developer": " / ".join(game.get("dev", [])),
           "Series": " / ".join(series_names.get(s, "") for s in game.get("series", []) if series_names.get(s)), "Genre": " / ".join(game.get("genre", [])),
           **release_facts(game, platform), "Other platforms": " / ".join(plats.BY_QID[p]["name"] for p in game.get("plat", []) if p != platform and p in plats.BY_QID)}
    return {k: v for k, v in out.items() if v}


def cover_of(game, platform):
    """(file, licence, author) of the picture Wikidata/Commons give for this game when it fits this platform's release, else None."""
    cv = game.get("cv")
    return (cv["file"], cv["lic"], cv["by"]) if cv and platform in cv.get("p", []) else None


class VideoGamesProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("videogames", 0, type_field="Publisher")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the video games list…", 0, 0)
            provenance.ensure(conn)
            data = load(gdir)
            names = data.get("series", {})
            read = data["day"]
            gate = photoverify.Gate("videogames")
            conn.execute("INSERT OR REPLACE INTO sources(code,name,url_tpl) VALUES(?,?,NULL)", SOURCE)
            by_plat = {}
            for g in data["games"]:
                for p in g.get("plat", []):
                    if p in plats.BY_QID:
                        by_plat.setdefault(p, []).append(g)
            rows, prov, sets = [], [], []
            for p in plats.PLATFORMS:
                if p["qid"] not in by_plat:
                    continue
                sid = "videogames:" + p["id"]
                sets.append((sid, p["name"], p["maker"], "", len(by_plat[p["qid"]]), len(by_plat[p["qid"]]), None))
                for n, g in enumerate(sorted(by_plat[p["qid"]], key=lambda g: (g["name"].casefold(), g["q"])), 1):
                    cid = "videogames:%s-%s" % (g["q"], p["qid"])
                    facts = facts_of(g, p["qid"], names)
                    cov = cover_of(g, p["qid"])
                    url = FILEPATH + urllib.parse.quote(cov[0]) + "?width=400" if cov else ""
                    ok, why_not = gate.ok(cid, url) if cov else (False, "")
                    ext = {"Source": "Wikidata: " + WD + g["q"], "Wikipedia": "https://en.wikipedia.org/wiki/" + urllib.parse.quote(g["wp"], safe="_(),'!-.%:") if g.get("wp") else "", **facts}
                    review = []
                    if not ok:
                        review.append(NO_PICTURE if not cov else "picture not shown yet: %s" % (why_not or "not checked"))
                    if not any(k in facts for k in ("Release date", "First released (the game, platform not stated)")):
                        review.append("no release date stated by Wikidata")
                    if ok:
                        ext["Photo credit"] = "%s, %s, Wikimedia Commons File:%s" % (cov[2] or "author on file page", cov[1], cov[0])
                    if review:
                        ext["Review"] = "; ".join(review)
                    ext = {k: v for k, v in ext.items() if v}
                    page = WD + g["q"]
                    prov.append((cid, "card", SOURCE[0], read, page))
                    prov += [(cid, label, SOURCE[0], read, page) for label in facts]
                    date = facts.get("Release date") or facts.get("First released (the game, platform not stated)") or "release date not stated"
                    rows.append((cid, sid, "", n, g["name"], url if ok else "", p["media"], p["media"], (g.get("pub") or [""])[0],
                                 "%s - %s game%s, %s." % (g["name"], p["name"], " by " + facts["Publisher"] if facts.get("Publisher") else "", date), json.dumps({"normal": True}),
                                 json.dumps({"source": "wikidata.org", "key": "%s-%s" % (g["q"], p["qid"]), GAME_KEY: g["q"], "platform": p["qid"], "series": g.get("series", []), "url": page,
                                             "ext": ext}, ensure_ascii=False)))
            conn.executemany("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", sets)
            conn.executemany("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) "
                             "VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)", rows)
            keep = {r[0] for r in rows}
            gone = [(r[0],) for r in conn.execute("SELECT id FROM cards") if r[0] not in keep]
            conn.executemany("DELETE FROM cards WHERE id=?", gone)
            conn.executemany("DELETE FROM provenance WHERE card_id=?", gone + [(c,) for c in keep])
            provenance.record_many(conn, prov)
            conn.execute("DELETE FROM sets WHERE id NOT IN (SELECT DISTINCT set_id FROM cards)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            from . import gamefacets
            gamefacets.ensure(conn, self.game_id, force=True)
            return len(rows)
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no free source with real video game prices is allowed (docs/video_games_data.md); owners can enter what they paid
