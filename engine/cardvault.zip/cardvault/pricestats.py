"""Price stats on an item (roadmap "Price stats"): 7 / 30 / 90-day change, the highest and lowest price on record, and how steady the price is.

Built only from the saved daily price history the app already keeps (the same one Market movers and Price alerts read; the Card Data price archive fills it back to Feb 2024),
so it costs no extra query: the item screen already loads that list and hands it to stats().  Pure functions, nothing is written.
Rules: only true market prices (the caller passes the price kind: an eBay asking price, a maker's store price or "your estimate" gives no stats at all); an old price too far from the
window's start day, or a newest price that is stale, gives "not enough history" (None), never 0.  "High / low" mean since the history starts (`since`), not "ever".
How often it sells is NOT here: the archive keeps one price per day and no sales or listing count, so there is nothing true to show.
Steadiness: the typical (median) size of a one-day move over the last 90 days, ignoring days where either price is under $0.25, in plain words:
  under 1 % a day = steady, under 3 % = moves some, more = jumpy.  Needs at least 20 such day-pairs."""
import datetime
import statistics

from . import marketmovers
from .completion import true_price

WINDOWS = (7, 30, 90)
MIN_MOVE_PRICE = 0.01          # a single item's own change is shown at any price (Market movers' $1 floor is for ranking many cards)
STALE_DAYS = 7                 # the newest saved price must be this recent
STEADY_DAYS, STEADY_MIN_PRICE, STEADY_MIN_PAIRS = 90, 0.25, 20
STEADY_AT, MOVES_AT = 1.0, 3.0  # median daily move, in %
NOT_MARKET = ("retail price", "store", "ebay", "your estimate")


def _day(s):
    return datetime.date.fromisoformat(s[:10])


def _points(history):
    """[(day, usd)] oldest first, real prices only (> 0), one per day."""
    seen = {}
    for p in history or ():
        d, usd = (p["day"], p["usd"]) if isinstance(p, dict) else (p[0], p[1])
        if d and usd is not None and usd > 0:
            seen[str(d)[:10]] = float(usd)
    return sorted(seen.items())


def _base(pts, cutoff, w):
    """Newest saved price on or before the window's start day, but not older than a quarter of the window (min 3 days) before it."""
    best = None
    for d, usd in pts:
        if d <= cutoff:
            best = (d, usd)
        else:
            break
    if best and (_day(cutoff) - _day(best[0])).days > max(3, w // 4):
        return None
    return best


def steadiness(pts, today):
    """-> {"label": steady|moves some|jumpy, "typical": median daily move in %, "pairs": n} or None when there are too few day-pairs."""
    cutoff = (today - datetime.timedelta(days=STEADY_DAYS)).isoformat()
    moves = []
    for (d0, p0), (d1, p1) in zip(pts, pts[1:]):
        if d0 < cutoff or p0 < STEADY_MIN_PRICE or p1 < STEADY_MIN_PRICE:
            continue
        gap = (_day(d1) - _day(d0)).days
        if 1 <= gap <= 3:
            moves.append(abs(100.0 * (p1 - p0) / p0) / gap)
    if len(moves) < STEADY_MIN_PAIRS:
        return None
    typ = statistics.median(moves)
    return {"label": "steady" if typ < STEADY_AT else "moves some" if typ < MOVES_AT else "jumpy", "typical": round(typ, 2), "pairs": len(moves)}


def stats(history, kind="", today=None):
    """history = [{"day", "usd"}] or [(day, usd, ...)] -> {"changes": {"7": move|None, "30": ..., "90": ...}, "high": {usd, day}|None, "low": ..., "since": first day, "steady": {...}|None,
    "days": points} or None when this price is not a true market price or there is no usable history at all.  A move is {old, new, change, pct, since, day} (marketmovers.window_move)."""
    if str(kind or "").lower().startswith(NOT_MARKET) or not true_price(1.0, kind):
        return None
    pts = _points(history)
    if not pts:
        return None
    today = today or datetime.date.today()
    latest = pts[-1]
    fresh = (today - _day(latest[0])).days <= STALE_DAYS
    changes = {}
    for w in WINDOWS:
        cutoff = marketmovers.window_start(w, today)
        changes[str(w)] = marketmovers.window_move(_base(pts, cutoff, w), latest, cutoff, MIN_MOVE_PRICE) if fresh else None
    hi, lo = max(pts, key=lambda p: p[1]), min(pts, key=lambda p: p[1])
    ok = len(pts) >= 2
    return {"changes": changes, "high": {"usd": hi[1], "day": hi[0]} if ok else None, "low": {"usd": lo[1], "day": lo[0]} if ok else None,
            "since": pts[0][0], "steady": steadiness(pts, today) if fresh else None, "days": len(pts)}
