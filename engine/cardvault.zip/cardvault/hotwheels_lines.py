"""Hot Wheels: the source sites and the line each one covers.  One table, used by the harvester (tools/harvest_hotwheels.py) and the catalog builder (cardvault/hotwheels.py).

A 'line' is the kind of release (Treasure Hunt, Super Treasure Hunt, Red Line Club, Redline era ...).  The line of a car is what its source site IS about, or the Type its page states -
never worked out from a car's name.  Lines with no allowed source yet (mainline by year, Premium, Elite 64, retailer exclusives) are simply not in the list: docs/hotwheels_sources.md."""

# code -> the site.  prose: its car pages describe ONE car (colour, wheels, base are read from them); a Redline page describes a whole casting, so only its fact box is read.
SITES = {
    "hwt": {"name": "HWtreasure.com", "host": "www.hwtreasure.com", "checklist": "https://www.hwtreasure.com/treasure-hunt-checklist/", "two_part": True, "prose": True, "line": ""},
    "hwrlc": {"name": "HWRLC.com", "host": "hwrlc.com", "checklist": "https://hwrlc.com/checklist/", "two_part": False, "prose": True, "line": "Red Line Club"},
    "hwred": {"name": "HWredline.com", "host": "hwredline.com", "checklist": "https://hwredline.com/checklist/", "two_part": False, "prose": False, "line": "Redline era (1968-1977)"},
}
LINE_ORDER = ("Redline era (1968-1977)", "Treasure Hunt", "Super Treasure Hunt", "Red Line Club")
# what a group of one line and one year is called in the app ("2027 Super Treasure Hunts", "Red Line Club 2026", "Redlines 1968")
_GROUP = {"Treasure Hunt": "{year} Treasure Hunts", "Super Treasure Hunt": "{year} Super Treasure Hunts", "Red Line Club": "Red Line Club {year}", "Redline era (1968-1977)": "Redlines {year}"}


def line_of(item):
    """The line of a harvested car: its site's own line, else the Type its page states ('' when neither says)."""
    return SITES[item["site"]]["line"] or item.get("type") or ""


def group_name(line, year):
    return _GROUP.get(line, line + " {year}").format(year=year)


def short(line):
    """'Redline era (1968-1977)' -> 'Redline' for an item's name."""
    return line.split(" (")[0].replace(" era", "")
