"""Where the engine is running.  In the browser (Pyodide) there are no threads, so the data service, background jobs and housekeeping run
one step at a time inside the engine's own web worker ("inline" mode).  Everything else is the same code as on the desktop."""
import os
import sys

IN_BROWSER = sys.platform == "emscripten"
REMOTE_IMAGES = IN_BROWSER or os.environ.get("CARDVAULT_REMOTE_IMAGES") == "1"   # pictures are shown straight from their web address (nothing is stored)
service = None                       # the running data service (set by Service); lets small helpers look pictures up
INLINE = IN_BROWSER or os.environ.get("CARDVAULT_INLINE") == "1"      # the second form lets the tests exercise inline mode on a PC
