"""Covers of the Video games (physical) list: which platform's item a Wikidata picture may be shown on, and whether Commons says the file is free to reuse.  Pure rules (the tool fetches the Commons facts).

A game's Wikidata "image" is ONE picture, often the box of one release.  It is shown on a platform's item only when it is certain to be that release's: the game is on one platform of the list, or the file's own
name names the platform.  Anything else (and any file whose licence Commons does not state as free, or marks non-free) shows "No picture yet" with a Review note and waits on the review list; never a stand-in."""
import re

from . import photoverify
from .videogames_platforms import BY_QID

ALIASES = {"Q172742": ("nes", "nintendo entertainment system"), "Q183259": ("snes", "super nintendo", "super famicom"), "Q184839": ("n64", "nintendo 64"), "Q182172": ("gamecube", "game cube", "ngc"),
           "Q8079": ("wii",), "Q56942": ("wii u", "wiiu"), "Q19610114": ("switch",), "Q122761124": ("switch 2",), "Q186437": ("game boy", "gameboy"), "Q203992": ("game boy color", "gbc"),
           "Q188642": ("game boy advance", "gba"), "Q170323": ("nintendo ds", "nds"), "Q203597": ("3ds",), "Q10677": ("playstation", "psx", "ps1"), "Q10680": ("playstation 2", "ps2"),
           "Q10683": ("playstation 3", "ps3"), "Q5014725": ("playstation 4", "ps4"), "Q63184502": ("playstation 5", "ps5"), "Q170325": ("psp", "playstation portable"), "Q188808": ("vita",),
           "Q132020": ("xbox",), "Q48263": ("xbox 360", "x360"), "Q13361286": ("xbox one", "xone"), "Q98973368": ("xbox series", "series x"), "Q10676": ("genesis", "mega drive", "megadrive"),
           "Q209868": ("master system",), "Q200912": ("saturn",), "Q184198": ("dreamcast",), "Q751719": ("game gear",), "Q206261": ("atari 2600", "2600"), "Q1057377": ("turbografx", "pc engine")}


def _flat(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def _aliases(q):
    return {_flat(k) for k in set(ALIASES.get(q, ())) | {BY_QID[q]["name"]}} if q in BY_QID else set()


def names_platform(filename, qid_):
    """True when the file's own name carries the platform's name or a well-known short name of it as whole words, and no longer name of ANOTHER platform that contains it ('Wii' in 'Wii U')."""
    name = " " + _flat(re.sub(r"\.[A-Za-z0-9]+$", "", filename)) + " "
    mine = {a for a in _aliases(qid_) if " %s " % a in name}
    if not mine:
        return False
    longer = {a for q in BY_QID if q != qid_ for a in _aliases(q) if " %s " % a in name}
    return any(not any(m != o and m in o for o in longer) for m in mine)


COVER_WORDS = re.compile(r"(?<![a-z])(?:cover|box ?art|boxart|box|cartridge|cart|case|jacket|sleeve)(?![a-z])", re.I)
_SKIP = {"the", "a", "an", "of", "and", "for", "in", "on", "to"}


def is_cover(filename, game_name):
    """Wikidata's "image" of a game is whatever picture the editors chose (a convention booth, a console, a plane).  It counts as a COVER only when the file's own name says cover / box / cartridge / case
    AND carries the game's name (every significant word of its first three), so a stage photo or another game's box never becomes the cover."""
    base = re.sub(r"\.[A-Za-z0-9]+$", "", filename or "")
    words = [w for w in _flat(game_name).split() if w not in _SKIP][:3]
    flat = " " + _flat(base) + " "
    return bool(COVER_WORDS.search(base)) and bool(words) and all(" %s " % w in flat or w in flat.split() for w in words)


def platforms_for(filename, game_platforms):
    """The platforms of the list (Wikidata ids) the picture may be shown on: the only platform, or the one(s) the file name names."""
    ours = [q for q in game_platforms if q in BY_QID]
    if len(ours) == 1:
        return ours
    return [q for q in ours if names_platform(filename, q)]


def free_reasons(info, filename):
    """Why a Commons file is NOT usable as a cover ([] = free and usable): the licence facts Commons gives (see photoverify.check_commons), plus a logo / icon check on the name."""
    why = photoverify.check_commons(filename, "", info)
    if photoverify.BAD_FILE.search(filename or ""):
        why.append("the file name says it is a logo or icon, not a cover")
    return why
