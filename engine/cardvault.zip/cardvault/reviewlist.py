"""ONE REVIEW LIST for the owner: anything a checker is unsure about waits here for a yes or no (owner-only, Dev Tools > Review list).  Any checker adds with add_item(); the owner answers; each
answer is applied right away by the applier registered for that kind of item (register()).

An item is a question, or a proposed fix (before -> after).  States:
  open       waits for a yes / no (a fix is shown before/after side by side)
  retry      the fix was refused and the checker has no new proposal yet; a new add_item() with a different fix reopens it
  ask        the fix was refused MAX_TRIES times: it asks the owner for the right value instead of guessing
  confirmed  answered and applied: LOCKED - never asked again, never changed
  solved     closed by the checker that asked, because a later run found it fixed (applied = why); the same problem coming back opens it again
Stored in review_list.db next to the daily update log, so the daily run and the app share it."""
import json
import os
import sqlite3

from . import dailylog

MAX_TRIES = 3
APPLIERS, RECHECKERS = {}, {}
_SCHEMA = ("CREATE TABLE IF NOT EXISTS review(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, game TEXT NOT NULL, item_id TEXT NOT NULL, question TEXT, before TEXT, after TEXT, source TEXT,"
           " status TEXT NOT NULL, tries INTEGER NOT NULL DEFAULT 0, rejected TEXT NOT NULL DEFAULT '[]', answer TEXT, final TEXT, applied TEXT, created TEXT, answered TEXT, UNIQUE(kind, game, item_id))")
_JSON = ("before", "after", "rejected", "final")


class ReviewError(Exception):
    pass


def path():
    return os.path.join(dailylog.log_dir(), "review_list.db")


def _conn():
    os.makedirs(dailylog.log_dir(), exist_ok=True)
    c = sqlite3.connect(path(), timeout=30)
    c.row_factory = sqlite3.Row
    c.execute(_SCHEMA)
    return c


def _item(row):
    d = dict(row)
    for k in _JSON:
        d[k] = json.loads(d[k]) if d.get(k) else None
    d["rejected"] = d["rejected"] or []
    return d


def register(kind, apply=None, recheck=None):
    """apply(item, answer, value, ctx) -> a short note: runs when the owner settles an item ('yes' to a question or fix, 'no' to a question, or 'value' for the right value he typed).
    recheck(item) -> a new proposed fix (or None): runs right after a refused fix, so the next try comes at once."""
    if apply:
        APPLIERS[kind] = apply
    if recheck:
        RECHECKERS[kind] = recheck


def _dump(v):
    return None if v is None else json.dumps(v, ensure_ascii=False, sort_keys=True)


def add_item(kind, game, item_id, question, before=None, after=None, source=""):
    """A checker is unsure: put it on the list.  Safe to call every day: the same item is never listed twice, a confirmed item stays locked (-> None), and a fix the owner already refused is not
    proposed again.  -> the item's id"""
    item_id = str(item_id)
    c = _conn()
    try:
        row = c.execute("SELECT * FROM review WHERE kind=? AND game=? AND item_id=?", (kind, game, item_id)).fetchone()
        if row is None:
            cur = c.execute("INSERT INTO review(kind, game, item_id, question, before, after, source, status, created) VALUES(?,?,?,?,?,?,?,?,?)",
                            (kind, game, item_id, question, _dump(before), _dump(after), source, "open", dailylog.now()))
            c.commit()
            return cur.lastrowid
        it = _item(row)
        if it["status"] == "confirmed":
            return None
        if it["status"] == "solved":                                 # the problem came back after the checker closed it: ask again
            c.execute("UPDATE review SET question=?, before=?, after=?, source=?, status='open', applied=NULL, answered=NULL WHERE id=?",
                      (question, _dump(before), _dump(after), source, it["id"]))
            c.commit()
            return it["id"]
        if it["status"] in ("open", "retry") and after is not None and after != it["after"] and after not in it["rejected"]:
            c.execute("UPDATE review SET question=?, before=?, after=?, source=?, status='open' WHERE id=?", (question, _dump(before), _dump(after), source, it["id"]))
            c.commit()
        return it["id"]
    finally:
        c.close()


def get(item_id):
    c = _conn()
    try:
        row = c.execute("SELECT * FROM review WHERE id=?", (int(item_id),)).fetchone()
        return _item(row) if row else None
    finally:
        c.close()


def items(status="", game="", kind=""):
    """Newest first; status '' = everything that still waits (open, retry, ask)."""
    where, args = ["status IN ('open','retry','ask')" if not status else "status=?"], ([status] if status else [])
    for col, v in (("game", game), ("kind", kind)):
        if v:
            where.append(col + "=?")
            args.append(v)
    c = _conn()
    try:
        return [_item(r) for r in c.execute("SELECT * FROM review WHERE " + " AND ".join(where) + " ORDER BY id DESC", args)]
    finally:
        c.close()


def counts():
    c = _conn()
    try:
        out = {s: 0 for s in ("open", "retry", "ask", "confirmed", "solved")}
        out.update({r[0]: r[1] for r in c.execute("SELECT status, COUNT(*) FROM review GROUP BY status")})
        return out
    finally:
        c.close()


def record_answer(kind, game, item_id, question, before, answer, final=None, note="", source=""):
    """An answer the owner gave somewhere else (Dev Tools > Changes: a revert), kept on the list as a confirmed item (locked; nothing is applied - it already was).
    Readers of confirmed answers (Mini you's retrain) learn from it like from any other.  -> the item's id"""
    rid = add_item(kind, game, item_id, question, before=before, source=source)
    if rid is not None:
        _save(rid, status="confirmed", answer=answer, final=_dump(final), applied=note, answered=dailylog.now())
    return rid


def _save(item_id, **cols):
    c = _conn()
    try:
        c.execute("UPDATE review SET " + ", ".join(k + "=?" for k in cols) + " WHERE id=?", [*cols.values(), item_id])
        c.commit()
    finally:
        c.close()


def solve(item_id, why):
    """The checker that asked found the problem gone (fixed with proof, passes now, item no longer in the list): close the question with the reason.  Never touches a confirmed item."""
    c = _conn()
    try:
        n = c.execute("UPDATE review SET status='solved', applied=?, answered=? WHERE id=? AND status IN ('open','retry','ask')", (why, dailylog.now(), int(item_id))).rowcount
        c.commit()
        return n == 1
    finally:
        c.close()


def _settle(it, ans, final, ctx):
    """Apply the answer right now; only when that worked is the item confirmed (and locked)."""
    fn = APPLIERS.get(it["kind"])
    note = (fn(it, ans, final, ctx) if fn else "") or ""
    _save(it["id"], status="confirmed", answer=ans, final=_dump(final), applied=note, answered=dailylog.now())
    return get(it["id"])


def answer(item_id, yes=None, value=None, ctx=None):
    """The owner's answer: yes / no to an open item, or `value` (the right answer, typed) to an item that asks for one.  -> the item as it is now."""
    it = get(item_id)
    if it is None:
        raise ReviewError("That item is not on the list any more.")
    if it["status"] == "confirmed":
        raise ReviewError("That one is already confirmed and locked.")
    if it["status"] == "ask":
        if value is None or str(value).strip() == "":
            raise ReviewError("Type the right value.")
        return _settle(it, "value", str(value).strip(), ctx)
    if it["status"] == "retry" or yes is None:
        raise ReviewError("There is nothing to answer yet." if it["status"] == "retry" else "Answer yes or no.")
    if yes:
        return _settle(it, "yes", it["after"], ctx)
    if it["after"] is None:                                         # a plain question: "no" is the answer
        return _settle(it, "no", None, ctx)
    rejected = it["rejected"] + [it["after"]]                        # a proposed fix was refused
    tries = it["tries"] + 1
    cols = {"tries": tries, "rejected": _dump(rejected), "after": None, "status": "ask" if tries >= MAX_TRIES else "retry"}
    if tries < MAX_TRIES and it["kind"] in RECHECKERS:
        new = RECHECKERS[it["kind"]](dict(it, rejected=rejected, tries=tries))
        if new is not None and new not in rejected:
            cols.update(after=_dump(new), status="open")
    _save(it["id"], **cols)
    return get(it["id"])
