"""The figures inside the Frozen Culture blind bags Abominable Toys sells - one list entry for each figure, besides the entry for the pack.

The shop sells a series as 'one random blind-bag figure' (a 'Single Figure' listing) and as a case, so its product feed has one entry per series, never one per figure.  A collector wants every figure:
which of Cheer Bear, Funshine Bear ... have I got?  The names below come from what the maker's and the retailers' product pages and the series' own descriptions say (six or eight styles and the chase
figures; a chase nobody has named yet is 'Mystery chase 1, 2 ...' and keeps that id when its name becomes known).  Each series becomes a line of its own ('Frozen Culture - Care Bears') under the heading
'Frozen Culture', and its figures show the picture of the pack until a picture of the figure itself is found.  Ids ('fc:<series>:<figure>') never change; run again any time, it rewrites the same rows."""
import json
import re
import time
from collections import namedtuple

from . import toylines

Series = namedtuple("Series", "key name pack figures")          # pack: the id of the list entry that is the series' blind bag; figures: ((name, rarity), ...)
STANDARD, CHASE = "Standard", "Chase"
HEADING = "Frozen Culture"
DESIGNER = "Andrew Heath (Frozen Culture)"


def _figs(styles, chases=(), mystery=0):
    """The styles of a series, then its named chases, then `mystery` chases nobody has named."""
    out = [(n, STANDARD) for n in styles] + [(n, CHASE) for n in chases]
    return tuple(out + [(f"Mystery chase {i}" if mystery > 1 else "Mystery chase", CHASE) for i in range(1, mystery + 1)])


SERIES = (
    Series("chomp-series-1", "Chomp Series 1", "shp:frozen-culture-chomp-single-figure",
           _figs(["Chomp", "Cotton Candy Chomp", "Bigfoot Chomp", "Albino Chomp", "Jolly Green Chomp", "Mean Muggin' Chomp"], mystery=3)),
    Series("gingerbread", "Gingerbread Chomp", "shp:gingerbread-frozen-culture-single-figure", _figs(["Gingerbread Chomp"], mystery=1)),
    Series("berry", "Berry Chomp", "shp:limited-edition-berry-chomp-frozen-culture-single-figure",
           _figs(["Strawberry Chomp", "Blueberry Chomp", "Razzberry Chomp", "Grapeberry Chomp", "Mintberry Chomp", "Orangeberry Chomp"], mystery=1)),
    Series("pumpkin", "Pumpkin Chomp", "shp:limited-edition-pumpkin-chomp-frozen-culture-copy", _figs(["Pumpkin Chomp"], chases=["Jack-o-Lantern"])),
    Series("classic-monsters", "Classic Monsters", "shp:monsters-frozen-culture-single-figure",
           _figs(["Dracula", "Frankenstein", "Vampiress", "Cyclops", "Grim Reaper", "The Glob", "Zombie", "Hunchback"], chases=["Drac", "Frankenstache", "Clownclops", "Booger Glob"])),
    Series("madballs", "Madballs", "shp:madballs-frozen-culture-single-figure",
           _figs(["Horn Head", "Oculus Orbus", "Dust Brain", "Slobulus", "Skull Face", "Screamin' Meemie"], mystery=3)),
    Series("care-bears", "Care Bears", "shp:care-bears-frozen-culture-single-figure",
           _figs(["Cheer Bear", "Funshine Bear", "Good Luck Bear", "Grumpy Bear", "Tenderheart Bear", "Share Bear"], mystery=3)),
    Series("godzilla-series-1", "Godzilla Series 1", "shp:frozen-culture-godzilla-series-1-limited-edition",
           (("Godzilla", "Common"), ("Mechagodzilla", "Uncommon"), ("Mothra", "Uncommon"), ("Heat Ray Godzilla", "Rare"),
            ("Skull Godzilla", "Super Rare chase"), ("Glow Mothra", "Super Rare chase"), ("Gold Mechagodzilla", "Hyper Rare chase"))),
)


def _slug(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def line_name(series):
    return f"{HEADING} - {series.name}"


def add_figures(conn, game_id="chomps", series=SERIES):
    """Write one entry for every figure of every series whose pack is in the list.  -> how many entries were written."""
    day, written = time.strftime("%Y-%m-%d"), 0
    for s in series:
        pack = conn.execute("SELECT image_base, rarity, price_usd, raw FROM cards WHERE id=?", (s.pack,)).fetchone()
        if not pack:
            continue                                                       # (the shop has never listed this pack: there is nothing to hang the figures on)
        image, rarity, price, raw_json = pack
        praw = json.loads(raw_json or "{}")
        pext = praw.get("ext") or {}
        sid = toylines.ensure_set(conn, game_id, line_name(s), serie=HEADING)
        for i, (name, tier) in enumerate(s.figures, 1):
            chase = "chase" in tier.lower()
            ext = {"Edition": "Open edition (no stated limit)", "Exclusive to": "Not exclusive", "Released": pext.get("Released") or "unknown", "Availability": pext.get("Availability") or "Sold out",
                   "Designer": DESIGNER, "Series": s.name, "Series rarity": tier, "Figure": f"{i} of {len(s.figures)}", "Shop page": pext.get("Shop page") or praw.get("url") or "",
                   "Source": "The names come from the maker's and the retailers' product pages for the series (a chase nobody has named yet is a mystery chase)"}
            raw = {"series": s.key, "series_order": i, "pack": s.pack, "edition": None, "exclusive": [], "available": bool(praw.get("available")), "published": pext.get("Released") or "",
                   "tags": [HEADING, s.name, "Blind bag"] + (["Chase"] if chase else []), "images": praw.get("images") or [], "url": praw.get("url") or "", "ext": {k: v for k, v in ext.items() if v}}
            cost = f" (${price:.2f} each, at random)" if price else ""
            desc = f"{tier} figure {i} of {len(s.figures)} in the Frozen Culture {s.name} blind-bag series, sold as a random pack{cost}: you cannot choose which one you get."
            conn.execute("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) "
                         "VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,?,?,?)",
                         (f"fc:{s.key}:{_slug(name)}", sid, str(i), toylines.sort_key_for(pext.get("Released"), i), name, image, "Blind bag figure", rarity or "Open edition", line_name(s), desc, day,
                          json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
            written += 1
    return written
