"""LEGO list: every official LEGO set Rebrickable dates 2024 or later, one item per set, grouped by its top theme (Star Wars, City, Technic ...) with the subtheme as a fact and a filter.
No network at refresh: the data is cardvault/lego_data.json, written by tools/harvest_lego.py from Rebrickable's public database downloads (docs/lego_data.md has the terms and the survey).

Each set keeps what the download states: set number, name, theme path, year, part count and minifigure count (from the set's first inventory).  A fact it does not state is left out (never
guessed: a set with no inventory yet has no part or minifigure count, not 0) and named in the raw ext 'Review' note, the note the other toy lists use.  Every stated fact gets a provenance record.
PICTURES: Rebrickable's picture of the set (LEGO's own set picture, linked from Rebrickable's CDN, never re-hosted), shown only when the automatic check passed it (it loads, decodes, is big
enough and no other set has the same bytes); the rest show "No picture yet" with the reason in the Review note.
PRICES: none.  Rebrickable has no prices; LEGO.com may not be read by programs (its Code of Conduct forbids scraping and its terms reserve text and data mining); Brickset's API needs an
account key.  No retail price is shown rather than a guess; owners can enter what they paid."""
import json
import os
import re
import time

from . import provenance
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lego_data.json")
FIRST_YEAR = 2024                                         # owner 2026-11-14: "please add legos and include the sets from 2024 to now"
SOURCE_URL = "https://rebrickable.com/downloads/"
SOURCE = ("w:rebrickable.com", "Rebrickable (database downloads)")
SET_PAGE = "https://rebrickable.com/sets/%s/"
NO_PICTURE = "No picture yet: Rebrickable has no picture for this set"
# Top themes that are not building sets (caps, mugs, bags, keychains, clothes ... and books): counted in the data file's 'left_out', not listed.  Owner question in docs/lego_data.md.
LEFT_OUT = frozenset({"Gear", "Books"})
# Rebrickable's own bookkeeping inventories ("Unused Parts Database Set", Pick-a-Brick, Build-a-Mini, WANTED-1 ...) under Other / Database Sets: not LEGO products, never listed.
BOOKKEEPING = "Database Sets"


def is_bookkeeping(s, themes):
    return BOOKKEEPING in theme_path(themes, s["theme"])
# What a thing in a top theme is (the rest are building sets).  Rebrickable files the minifigure series and parts packs under themes of their own.
KINDS = {"Key Chains": "Gear", "Magnets": "Gear", "Collectible Minifigures": "Collectible minifigure", "Service Packs": "Spare parts pack",
         "Supplemental": "Supplemental parts", "Bulk Bricks": "Bulk bricks"}


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def theme_path(themes, tid):
    """['Star Wars', 'Ultimate Collector Series'] - the top theme first."""
    out = []
    while tid:
        out.insert(0, themes[tid]["name"])
        tid = themes[tid]["parent"]
    return out


def set_number(num):
    """'75398-1' -> '75398'; a second version keeps its suffix ('6000-2' -> '6000-2')."""
    return num[:-2] if num.endswith("-1") else num


def facts_of(s, themes):
    path = theme_path(themes, s["theme"])
    out = {"Set number": set_number(s["num"]), "Theme": path[0], "Subtheme": " / ".join(path[1:]), "Year": str(s["year"]), "Kind": KINDS.get(path[0], "Building set")}
    if s["parts"]:
        out["Parts (Rebrickable count)"] = "{:,}".format(s["parts"])
    if s.get("figs") is not None:
        out["Minifigures"] = str(s["figs"])
    return {k: v for k, v in out.items() if v}


def photo_ok(s):
    return bool(s.get("img")) and bool((s.get("photo") or {}).get("ok"))


def review_of(s, facts):
    why = []
    if not photo_ok(s):
        p = s.get("photo") or {}
        why.append(NO_PICTURE if not s.get("img") else "picture not shown yet: %s" % (p.get("why") or "not checked yet (tools/harvest_lego.py --check-photos)"))
    if "Parts (Rebrickable count)" not in facts:
        why.append("part count not stated (Rebrickable has no inventory for this set yet)")
    if "Minifigures" not in facts:
        why.append("minifigure count not stated")
    return "; ".join(why)


def slug(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


class LegoProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("lego", 0, type_field="Subtheme")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the LEGO list…", 0, 0)
            provenance.ensure(conn)
            data = load()
            themes, read = data["themes"], data["day"]
            conn.execute("INSERT OR REPLACE INTO sources(code,name,url_tpl) VALUES(?,?,NULL)", SOURCE)
            made, rows, prov = {}, [], []
            for s in data["sets"]:
                if is_bookkeeping(s, themes):
                    continue
                facts = facts_of(s, themes)
                sid = "lego:" + slug(facts["Theme"])
                if sid not in made:
                    made[sid] = [facts["Theme"], 0, s["year"]]
                made[sid][1] += 1
                made[sid][2] = min(made[sid][2], s["year"])
                page = SET_PAGE % s["num"]
                ok = photo_ok(s)
                ext = {"Source": "Rebrickable: " + page, **facts}
                if ok:
                    ext["Photo credit"] = "LEGO set picture (© The LEGO Group), linked from Rebrickable"
                review = review_of(s, facts)
                if review:
                    ext["Review"] = review
                cid = "lego:" + s["num"]
                prov.append((cid, "card", SOURCE[0], read, page))
                prov += [(cid, label, SOURCE[0], read, page) for label in facts]
                if ok:
                    prov.append((cid, "image", SOURCE[0], data.get("photos_checked") or read, s["img"]))
                n = facts["Set number"]
                num = re.match(r"\d+", n)
                rows.append((cid, sid, n, int(num.group(0)) if num else 0, s["name"], s["img"] if ok else "", facts["Kind"], None, facts.get("Subtheme") or facts["Theme"],
                             "%s - LEGO %s %s %s (%s)%s." % (s["name"], facts["Theme"], facts["Kind"].lower(), n, s["year"],
                                                            ", %s parts" % facts["Parts (Rebrickable count)"] if "Parts (Rebrickable count)" in facts else ""),
                             json.dumps({"normal": True}), json.dumps({"source": "rebrickable.com", "key": s["num"], "url": page, "ext": ext}, ensure_ascii=False)))
            conn.executemany("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) "
                             "VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)", rows)
            conn.executemany("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)",
                             [(sid, name, "LEGO", str(year), n, n) for sid, (name, n, year) in made.items()])
            keep = {r[0] for r in rows}
            gone = [(r[0],) for r in conn.execute("SELECT id FROM cards") if r[0] not in keep]          # (a set Rebrickable re-dates or drops leaves the list; owners' own copies are kept elsewhere)
            conn.executemany("DELETE FROM cards WHERE id=?", gone)
            conn.executemany("DELETE FROM provenance WHERE card_id=?", gone + [(c,) for c in keep])
            provenance.record_many(conn, prov)
            conn.execute("DELETE FROM sets WHERE id NOT IN (SELECT DISTINCT set_id FROM cards)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            from . import gamefacets
            gamefacets.ensure(conn, self.game_id, force=True)
            return len(rows)
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no allowed price source (docs/lego_data.md); owners can enter what they paid
