"""The photos of one portfolio item (a card copy or a sealed purchase): up to MAX_PHOTOS, the first is the cover.

The bytes live in u.lot_photos under the item's uuid (the same table, photo limit and account photo sync as every other photo); u.lot_photos.pos says where each one stands (cover = first).
Photos are shrunk to a JPEG of at most 2 MB by custompics.shrink (the one shrink for every photo; up to 30 MB is accepted).
DATA SAFETY: nothing here deletes a photo except photo.delete (webapi/photoapi.py, undoable).  An item that already holds more than MAX_PHOTOS photos (the old limit was 8) keeps all of them:
the limit only stops NEW photos from being added."""
from . import custompics
from .db import now_iso

MAX_PHOTOS = custompics.MAX_PICTURES
ORDER = "pos IS NULL, pos, id"                          # arranged photos first (by position), then the ones never arranged in the order they were added


def rows(conn, owner):
    return conn.execute(f"SELECT id, side, data FROM u.lot_photos WHERE lot_uuid=? ORDER BY {ORDER}", (owner,)).fetchall()


def count(conn, owner):
    return conn.execute("SELECT COUNT(*) FROM u.lot_photos WHERE lot_uuid=?", (owner,)).fetchone()[0]


def check_room(conn, owner):
    if count(conn, owner) >= MAX_PHOTOS:
        raise custompics.PictureError(f"An item can have up to {MAX_PHOTOS} photos. Remove one to add another.")


def add(v, owner, image, side="front"):
    """Shrink and store one photo at the end (it is the cover only when it is the item's first).  -> the new photo's id.  The same picture twice is stored once."""
    check_room(v.conn, owner)
    data = custompics.shrink(image)
    from .cloud import photos
    same = v.conn.execute("SELECT id FROM u.lot_photos WHERE lot_uuid=? AND data=?", (owner, data)).fetchone()
    if same:
        return same[0]
    last = v.conn.execute("SELECT MAX(pos) FROM u.lot_photos WHERE lot_uuid=?", (owner,)).fetchone()[0]
    cur = v.conn.execute("INSERT INTO u.lot_photos(lot_uuid, side, data, added, pos) VALUES(?,?,?,?,?)",
                         (owner, side if side in ("front", "back", "other") else "other", data, now_iso(), (last or 0) + 1 if last is not None else None))
    photos.revive(v.conn, owner, data)                  # (the same photo removed before: its 'removed' marker must not delete it again at the next sync)
    return cur.lastrowid


def arrange(v, owner, ids):
    """The wanted order, as photo ids (cover first).  Photos of the item that are not named keep their place after the named ones; ids of other items are ignored.  Only positions change."""
    have = [r[0] for r in rows(v.conn, owner)]
    named = [i for i in dict.fromkeys(int(x) for x in ids or []) if i in have]
    final = named + [i for i in have if i not in named]
    if final == have and all(p is not None for (p,) in v.conn.execute("SELECT pos FROM u.lot_photos WHERE lot_uuid=?", (owner,))):
        return False
    for n, pid in enumerate(final, 1):
        v.conn.execute("UPDATE u.lot_photos SET pos=? WHERE id=? AND lot_uuid=?", (n, pid, owner))
    from .cloud import photoorder
    photoorder.changed(v.conn, owner)
    return True
