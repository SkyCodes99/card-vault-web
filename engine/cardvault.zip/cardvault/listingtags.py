"""What an eBay listing TITLE says about a trading card: who graded it and what grade, its condition, its language.  Pure text rules, no network, no state.

    parse(title) -> {"grader": "PSA"|"BGS"|"CGC"|"", "grade": "10"|"9.5"|"10 Pristine"|"10 Black Label"|"", "condition": "Near Mint"|...|"", "language": "Japanese"|...|"", "ok": bool}

A title that names more than one grader or grade ("PSA 9 and BGS 9.5 lot"), says it is only ready for grading ("PSA ready", "to grade", "raw"), or asks the buyer to pick a grade is `ok: False`:
it is never counted in a price.  Condition and language are only taken when the title says so in words (a title that says nothing gives "" - never a guess).
Used by cardvault/asksplit.py for the price per grade / condition / language, and by the recent asking-prices list."""
import re

GRADERS = ("PSA", "BGS", "CGC")
_GRADER = re.compile(r"\b(PSA|BGS|BECKETT|CGC)\b", re.I)
_GRADE = re.compile(r"\b(?:PSA|BGS|BECKETT|CGC)\s*(?:GRADED\s*|GEM\s*(?:MT|MINT)\s*|MINT\s*|NM[-\s]*MT\s*\+?\s*|AUTHENTIC\s*|PRISTINE\s*|PERFECT\s*)?[#-]?\s*(10|[1-9](?:\.5)?)\b", re.I)
_NOT_SLAB = re.compile(r"\b(psa|bgs|cgc|beckett)[\s-]*(ready|quality|candidate|worthy|potential|bound|submission|submit)\b|\b(to|for|can|could|will|ready to|pre)[\s-]*(be\s*)?grad(e|ing)\b|"
                       r"\b(raw|ungraded|not graded|no grade|cracked slab|crack(?:ed)? out)\b", re.I)                  # names a grader but is not a slab
_MANY = re.compile(r"\b(pick(?: your)? grade|choose(?: your)? grade|you pick|u pick|you choose|select(?: your)? grade|select grade|lot of|lots|bulk|bundle|collection|set of)\b", re.I)
_BLACK = re.compile(r"\bblack\s*label\b", re.I)
_PRISTINE = re.compile(r"\bpristine\b", re.I)
CONDITIONS = (                                  # (label, pattern) - the first that matches wins; most specific first
    ("Damaged", re.compile(r"\b(damaged|dmg|poor)\b", re.I)),
    ("Heavily Played", re.compile(r"\b(heavily played|hp(?!\s*\d)|heavy play(?:ed)?)\b", re.I)),
    ("Moderately Played", re.compile(r"\b(moderately played|moderate play(?:ed)?|mp|vg|very good)\b", re.I)),
    ("Lightly Played", re.compile(r"\b(lightly played|light play(?:ed)?|lp)\b", re.I)),
    ("Near Mint", re.compile(r"\b(near mint|nm|nm-mt|nm/mt|near-mint)\b", re.I)),
)
LANGUAGES = (
    ("Japanese", re.compile(r"\b(japanese|japan|jpn|jp|ja)\b", re.I)),
    ("Korean", re.compile(r"\b(korean|kor|kr)\b", re.I)),
    ("Chinese", re.compile(r"\b(chinese|traditional chinese|simplified chinese|zh)\b", re.I)),
    ("German", re.compile(r"\b(german|deutsch|ger)\b", re.I)),
    ("French", re.compile(r"\b(french|francais|fra)\b", re.I)),
    ("Italian", re.compile(r"\b(italian|italiano|ita)\b", re.I)),
    ("Spanish", re.compile(r"\b(spanish|espanol|esp)\b", re.I)),
    ("Portuguese", re.compile(r"\b(portuguese)\b", re.I)),
    ("English", re.compile(r"\b(english|eng)\b", re.I)),
)


def grade_of(title):
    """(grader, grade) from a title, or ("", "") when it is not clearly one graded copy."""
    t = title or ""
    if _NOT_SLAB.search(t) or _MANY.search(t):
        return "", ""
    names = {("BGS" if m.upper() == "BECKETT" else m.upper()) for m in _GRADER.findall(t)}
    grades = {m.group(1) for m in _GRADE.finditer(t)}
    if len(names) != 1 or len(grades) != 1:
        return "", ""
    grader, num = next(iter(names)), next(iter(grades))
    if num == "10" and grader in ("BGS", "CGC") and _PRISTINE.search(t):
        return grader, "10 Pristine"
    if num == "10" and grader == "BGS" and _BLACK.search(t):
        return grader, "10 Black Label"
    return grader, num


def condition_of(title):
    """The card condition the title states in words ("" when it states none or several different ones)."""
    found = {label for label, rx in CONDITIONS if rx.search(title or "")}
    return next(iter(found)) if len(found) == 1 else ""


def language_of(title):
    """The language the title states ("" when it states none or several)."""
    found = {label for label, rx in LANGUAGES if rx.search(title or "")}
    return next(iter(found)) if len(found) == 1 else ""


def parse(title):
    """See the module note.  `ok` is False for a multi-copy / pick-a-grade listing and for a title that names a grader without exactly one grade."""
    t = title or ""
    grader, grade = grade_of(t)
    named = bool(_GRADER.search(t))
    return {"grader": grader, "grade": grade, "condition": "" if named else condition_of(t), "language": language_of(t),
            "ok": not _MANY.search(t) and (bool(grader) or not named)}
