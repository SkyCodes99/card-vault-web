"""Free daily Disney Lorcana prices from Lorcast (roadmap 1.2), shown NEXT TO the TCGplayer and eBay prices, never over them.

Lorcast (https://lorcast.com/docs/api) lists every card with its TCGplayer product id and prices.usd / prices.usd_foil (TCGplayer-sourced, updated once a day).
Their ask: 50-100 ms between calls to api.lorcast.com, cache at least 24 hours, descriptive User-Agent.  We read the set list (1 call) and each set's
card list (about 30 calls), once a day, through the shared polite Fetcher.
Stored in the table the Magic readers use (cardvault.freeprices.source_prices), source = 'lorcast', vendor 'tcgplayer', finish normal | foil, USD.
Cards are matched by tcgplayer_id = cards.tcg_id.  cards.price_usd / price_kind / price_updated are never touched.
If one set cannot be read (and is not in the cache), nothing is written, so a half-read day never replaces the whole table."""
from . import freeprices, provenance
from .sources import SourceError, rules

SOURCE = "lorcast"
BASE = "https://api.lorcast.com/v0"
DAY_AGE = 20 * 3600
ACCEPT = {"Accept": "application/json"}

rules.add(rules.SiteRule("lorcast", "Lorcast", ("api.lorcast.com",), 0.15, "data",
                         "Lorcast asks for 50-100 ms between API calls and caching for 24 h (prices change once a day); credit Lorcast. "
                         "Lorcana artwork/trademarks belong to Disney/Ravensburger (Community Code Policy): prices and ids only here.", "https://lorcast.com/docs/api"))
provenance.SOURCES.setdefault("lorc", ("Lorcast", "https://lorcast.com"))


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f > 0 else None


def card_rows(cards, day):
    """Lorcast card objects -> iterator of (tcg_id, vendor, finish, currency, price, day).  A card with no tcgplayer_id is skipped."""
    for c in cards or ():
        tid = c.get("tcgplayer_id")
        if not tid:
            continue
        prices = c.get("prices") or {}
        for key, finish in (("usd", "normal"), ("usd_foil", "foil")):
            p = _num(prices.get(key))
            if p is not None:
                yield str(tid), "tcgplayer", finish, "USD", p, day


def read_all(fetcher):
    """-> (list of card objects, newest fetched_at, all_from_cache, any_stale).  Raises SourceError / ValueError when the set list or any set is missing."""
    sets_got = fetcher.get(f"{BASE}/sets", max_age=DAY_AGE, headers=ACCEPT)
    sets = ((sets_got.json() or {}).get("results") if sets_got.status == 200 else None) or []
    if not sets:
        raise ValueError(f"set list not available (HTTP {sets_got.status})")
    cards, newest, cached, stale = [], sets_got.fetched_at, sets_got.from_cache, sets_got.stale
    for s in sets:
        got = fetcher.get(f"{BASE}/sets/{s['id']}/cards", max_age=DAY_AGE, headers=ACCEPT)
        if got.status != 200 or not isinstance(got.json(), list):
            raise ValueError(f"set {s.get('code')} not available (HTTP {got.status})")
        cards.extend(got.json())
        newest, cached, stale = max(newest, got.fetched_at), cached and got.from_cache, stale or got.stale
    return cards, newest, cached, stale


def run(conn, fetcher):
    """Fetch (cached for a day), match by TCGplayer id and store.  Returns the result dict (rows, cards, entries, entries_matched, ...)."""
    freeprices.ensure(conn)
    try:
        cards, fetched_at, cached, stale = read_all(fetcher)
    except (SourceError, ValueError) as e:
        return {"source": SOURCE, "written": False, "error": f"{type(e).__name__}: {e}"}
    day = fetched_at[:10]
    res = freeprices.write(conn, SOURCE, card_rows(cards, day))
    res.update(day=day, from_cache=cached, stale=stale, source_cards=len(cards))
    return res
