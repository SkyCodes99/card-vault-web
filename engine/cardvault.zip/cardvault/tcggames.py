"""The card games whose lists come from TCGplayer (through tcgcsv.com): ONE table, read by games.py (the providers), tcgsync, the all-games search index and the release tools.  A new game is one line in
CATEGORIES and one in TYPE_FIELDS here plus its Game(...) entry in games.py - not an edit in ten files that each kept their own copy of the list.

CATEGORIES   game id -> TCGplayer category id (the two Pokémon lists are TCGdex's own; TCGplayer is only where their PRICES come from)
TYPE_FIELDS  game id -> the extended-data field a card's `types` come from: what the game's cards are filtered by (colour, class, element, nation ...)
KIND_FIELDS  the few games that keep a card's kind (Beastie / Spell, Avatar / Minion) under another name than CardType
is_card()    what makes a TCGplayer product a single card rather than a box, pack or accessory - the same answer for the builder, the daily check and the release tools
NATIVE       the games whose card id IS the TCGplayer product id (everything but Pokémon)
tests/test_tcggames.py keeps this, games.py and tcgsync in step."""
import re

POKEMON = ("pokemon", "pokemon_jp")

CATEGORIES = {
    "pokemon": 3, "pokemon_jp": 85, "onepiece": 68, "unionarena": 81, "yugioh": 2, "dbs": 27, "mtg": 1, "lorcana": 71, "gundam": 86, "riftbound": 89, "palworld": 91, "weissschwarz": 20,
    # the other card games TCGplayer lists (added 2026-10-29)
    "dbsfw": 80, "dbz": 23, "swu": 79, "digimon": 63, "fab": 62, "vanguard": 16, "fow": 17, "shadowverse": 73, "grandarchive": 74, "wixoss": 67, "hololive": 87, "finalfantasy": 24,
    "battlespirits": 72, "metazoo": 66, "universus": 25, "sorcery": 77, "cookierun": 90, "godzilla": 88, "alphaclash": 78, "elestrals": 83, "akora": 75, "kryptik": 76, "transformers": 57,
    "swdestiny": 26, "gateruler": 65,
    # the smaller card games TCGplayer lists (added 2026-10-29, second batch)
    "wowtcg": 13, "dicemasters": 18, "buddyfight": 19, "dragoborne": 28, "metax": 30, "zwo": 36, "casterchronicles": 37, "exodus": 47, "lightseekers": 48, "munchkin": 53,
    "aoschampions": 54, "bakugantcg": 58, "chronoclash": 60, "argentsaga": 61, "cyberpunk": 92,
}

TYPE_FIELDS = {
    "onepiece": "Color", "unionarena": "SeriesName", "yugioh": "Attribute", "dbs": "Color", "mtg": "SubType", "lorcana": "InkType", "gundam": "Color", "riftbound": "Domain", "palworld": "Type", "weissschwarz": "Color",
    "dbsfw": "Color", "dbz": "Color", "swu": "Aspect", "digimon": "Color", "fab": "Class", "vanguard": "Nation", "fow": "Attribute", "shadowverse": "Class", "grandarchive": "Element", "wixoss": "Color",
    "hololive": "Color", "finalfantasy": "Element", "battlespirits": "Color", "metazoo": "AuraType", "universus": "Resource", "sorcery": "Element", "cookierun": "Color", "godzilla": "Color",
    "alphaclash": "Color", "elestrals": "ElementType", "akora": "Attribute", "kryptik": "Faction", "transformers": "Affiliation", "swdestiny": "Color", "gateruler": "Faction",
    "wowtcg": "Class", "dicemasters": "EnergyType", "buddyfight": "World", "dragoborne": "Color", "metax": "StatType", "zwo": "Color", "casterchronicles": "Element", "exodus": "Edition",
    "lightseekers": "PrimaryOrder", "munchkin": "Faction", "aoschampions": "Alliance", "bakugantcg": "Faction", "chronoclash": "CardColor", "argentsaga": "Element", "cyberpunk": "Color",
}

KIND_FIELDS = {"metazoo": "PageType", "sorcery": "CardCategory", "munchkin": "Type"}

NATIVE = frozenset(game for game in CATEGORIES if game not in POKEMON)

# Card Data keeps each game's daily prices, trends and price history under a name made from TCGplayer's category name ('forceofwill', 'dragon_ball_z_tcg'); the app's own game id is the shorter one.
# A game that is not here has the same name in both (checked against https://sky-carddata-tnnwxj.azurewebsites.net/prices/manifest.json on 2026-10-29).
DATA_SLUGS = {
    "weissschwarz": "weiss", "dbz": "dragon_ball_z_tcg", "fow": "forceofwill", "alphaclash": "alpha_clash", "kryptik": "kryptik_tcg", "transformers": "transformers_tcg", "swdestiny": "star_wars_destiny",
    "gateruler": "gate_ruler", "wowtcg": "wow", "dicemasters": "dice_masters", "metax": "metax_tcg", "zwo": "zombie_world_order_tcg", "casterchronicles": "the_caster_chronicles", "exodus": "exodus_tcg",
    "lightseekers": "lightseekers_tcg", "munchkin": "munchkin_ccg", "bakugantcg": "bakugan_tcg", "chronoclash": "chrono_clash_system", "argentsaga": "argent_saga_tcg",
}


def data_slug(game_id):
    """The name Card Data files a game's prices, trends and price history under."""
    return DATA_SLUGS.get(game_id, game_id)


def by_game_id(games):
    """Card Data's manifests list games by that name: the same entries again under the app's own ids, so `games[game_id]` finds them."""
    out = dict(games or {})
    for game_id, slug in DATA_SLUGS.items():
        if slug in out:
            out.setdefault(game_id, out[slug])
    return out

# The twelve games that were here first: a card in them has a collector Number, nothing else (their lists were built before the rule below existed, and a product without a Number there - a token,
# a code card, an oversized promo - lives with the sealed products).
LEGACY = frozenset({"pokemon", "pokemon_jp", "onepiece", "unionarena", "yugioh", "dbs", "mtg", "lorcana", "gundam", "riftbound", "palworld", "weissschwarz"})
_BRACKETS = re.compile(r"\([^)]*\)|\[[^\]]*\]")
_SEALED_NAME = re.compile(r"\b(booster|display|case|core pack|(starter|structure|theme|trial|intro|expansion|armory|blitz|demo|welcome) (deck|kit|set)|collector'?s? (box|tin|set|chest|pack)"
                          r"|collection (box|set|pack)|bundle|prerelease (kit|pack|box)|tin|blister|sealed|playmat|sleeves|deck box)\b", re.I)


def looks_sealed(name):
    """True when a product's name says it is a box, pack, deck or accessory ('Booster Box', 'Starter Deck', 'Core Pack').  What is in brackets is a printing ('(Box Topper)'), not the product."""
    return bool(_SEALED_NAME.search(_BRACKETS.sub(" ", name or "")))


def is_card(game, ext, name=""):
    """`ext` = a TCGplayer product's extended data as {name: value}, `name` = its name.  -> True for a single card, False for a box, pack, case or accessory.
    A product with a collector Number is a card.  In the newer games some cards print no Number (Sorcery, World of Warcraft, Exodus, a Force of Will Uber Rare ...): there a product with a Rarity is a
    card unless its name says it is sealed."""
    if "Number" in ext:
        return True
    return game not in LEGACY and "Rarity" in ext and not looks_sealed(name)
