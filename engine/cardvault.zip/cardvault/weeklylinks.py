"""The WEEKLY link check (once every 7 days, from tools/daily_update.py): refreshes the Shop list's In stock / Out of stock and the Where-to-sell buylist offers, politely.

Politeness rules (owner, 2026-11-10):
  * robots.txt is read per host (cached 7 days).  A host whose robots.txt names Claude/Anthropic, blocks us, or cannot be read is skipped; a path that is Disallowed is skipped.
  * A small request budget per host (BUDGET), a timeout on every request, and a cache: a link read in the last 6 days is not read again.
  * A 403, a captcha page or any other refusal is never worked around - that link/host is left as it was.  A 429 stops the host and backs it off until next week.
  * Buylist offers are read only from Card Kingdom (Magic), only where its purchasing page states ONE exact match (same name and set); otherwise the link shows "check site".
  * Never read: eBay, PriceCharting, Collectr, CardTrader, Cardmarket.  Plain links only, no affiliate parameters.
Results go to cardvault/linkstore.py with their check date."""
import datetime
import html
import json
import re
import urllib.robotparser
from urllib.parse import urlsplit

from . import linkstore, selllinks, shoplinks

WEEK = datetime.timedelta(days=7)
FRESH = datetime.timedelta(days=6)
BUDGET = 15                                    # requests per host per weekly run (robots.txt included)
TIMEOUT = 10
UA = "CollectEmAll-LinkCheck/1.0 (personal collection tracker; weekly, polite)"
NEVER = ("ebay.", "pricecharting.", "collectr.", "cardtrader.", "cardmarket.", "tcgplayer.com")     # never read (tcgplayer: no public stock page)
CAPTCHA = re.compile(r"captcha|are you a robot|unusual traffic|access denied|cf-chl|just a moment", re.I)


def default_fetch(url):
    """(status, text) of a plain GET with a timeout; (0, '') when the site cannot be reached."""
    import requests
    try:
        r = requests.get(url, headers={"User-Agent": UA, "Accept": "text/html,application/json"}, timeout=TIMEOUT)
        return r.status_code, r.text[:2_000_000]
    except requests.RequestException:
        return 0, ""


def _now_iso(now):
    return now.isoformat(timespec="seconds")


def _parse(s):
    try:
        return datetime.datetime.fromisoformat(s)
    except (TypeError, ValueError):
        return None


def is_due(store, now):
    """The weekly gate: True when the last run was 7 or more days ago (or never)."""
    last = _parse(store.get("last_run"))
    return last is None or now - last >= WEEK


class Polite:
    """One run's politeness state: robots per host, request budget per host, 429 back-off."""

    def __init__(self, store, fetch, now):
        self.store, self.fetch, self.now = store, fetch, now
        self.used, self.report, self.parsers = {}, {"checked": {}, "skipped": {}}, {}

    def _skip(self, host, why):
        self.report["skipped"].setdefault(host, why)

    def _backed_off(self, host):
        until = _parse((self.store.get("backoff") or {}).get(host))
        return bool(until and until > self.now)

    def _get(self, host, url):
        """One counted request -> (status, text), or None when the budget is spent.  A 429 backs the host off until next week."""
        if self.used.get(host, 0) >= BUDGET:
            self._skip(host, f"request budget ({BUDGET}) spent")
            return None
        self.used[host] = self.used.get(host, 0) + 1
        st, text = self.fetch(url)
        if st == 429:
            self.store.setdefault("backoff", {})[host] = _now_iso(self.now + WEEK)
            self._skip(host, "429 - backing off until next week")
        return st, text

    def robots(self, host):
        """A RobotFileParser for the host, or None when the host must be skipped (names Claude/Anthropic, blocks us, cannot be read, backed off)."""
        if host in self.parsers:
            return self.parsers[host]
        self.parsers[host] = None
        if self._backed_off(host):
            self._skip(host, "backing off after a 429")
            return None
        cached = self.store.setdefault("robots", {}).get(host) or {}
        at = _parse(cached.get("at"))
        if at and self.now - at < WEEK and "text" in cached:
            status, text = cached.get("status", 200), cached["text"]
        else:
            r = self._get(host, f"https://{host}/robots.txt")
            if r is None or self._backed_off(host):
                return None
            status, text = r
            if status == 200:
                self.store["robots"][host] = {"at": _now_iso(self.now), "text": text, "status": status}
        if status in (404, 410):                                   # no robots.txt: nothing is disallowed
            text = ""
        elif status != 200:                                        # 401/403/5xx/unreachable: do not guess, do not go round it
            self._skip(host, f"robots.txt answered {status or 'nothing'}")
            return None
        if re.search(r"claude|anthropic", text, re.I):
            self._skip(host, "robots.txt names Claude")
            return None
        rp = urllib.robotparser.RobotFileParser()
        rp.parse(text.splitlines())
        if not rp.can_fetch(UA, f"https://{host}/"):
            self._skip(host, "robots.txt blocks the site")
            return None
        self.parsers[host] = rp
        return rp

    def read(self, url):
        """The page text for `url`, or None (skipped: never-list / robots / budget / back-off / refusal / captcha / not 200)."""
        host = urlsplit(url).netloc.lower()
        if any(n in host for n in NEVER):
            self._skip(host, "never read")
            return None
        rp = self.robots(host)
        if rp is None or self._backed_off(host):
            return None
        if not rp.can_fetch(UA, url):
            self._skip(host + urlsplit(url).path[:20], "robots.txt disallows the path")
            return None
        r = self._get(host, url)
        if r is None:
            return None
        st, text = r
        if st != 200 or CAPTCHA.search(text[:4000]):
            return None                                            # 403 / 429 / captcha / error: left as it was, never worked around
        self.report["checked"][host] = self.report["checked"].get(host, 0) + 1
        return text


# ------------------------------------------------------------------------------------------------ reading a page
def parse_stock(text):
    """'in' | 'out' | None from schema.org availability in the page (JSON-LD / microdata) - only when the page states it plainly and consistently."""
    states = set()
    for m in re.finditer(r"schema\.org/(InStock|OutOfStock|SoldOut|PreOrder|BackOrder|LimitedAvailability|Discontinued)", text or "", re.I):
        k = m.group(1).lower()
        states.add("in" if k in ("instock", "limitedavailability") else "out" if k in ("outofstock", "soldout", "discontinued") else "other")
    return states.pop() if len(states) == 1 and next(iter(states)) in ("in", "out") else None


def parse_ck_offers(text):
    """[(title, set text, usd)] from a Card Kingdom purchasing page: the cash price shown for each listed card."""
    out = []
    for block in (text or "").split('class="itemContentWrapper"')[1:]:
        t = re.search(r'class="productDetailTitle">\s*<a[^>]*>([^<]+)</a>', block)
        s = re.search(r'class="productDetailSet">\s*([^<]*?)\s*<', block)
        p = re.search(r'class="usdSellPrice">\s*<span[^>]*>\$([\d,]+\.\d{2})<', block)
        if t and p:
            out.append((html.unescape(t.group(1)).strip(), html.unescape(s.group(1)).strip() if s else "", float(p.group(1).replace(",", ""))))
    return out


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", str(s or "").lower()).strip()


def pick_offer(rows, name, set_name):
    """The ONE usd offer whose title equals `name` and whose set matches `set_name`; None when there is none or more than one (then the link says 'check site')."""
    want, wset = _norm(name), _norm(set_name)
    if not want or not wset:
        return None
    hits = []
    for title, st, usd in rows:
        ck = _norm(re.sub(r"\([^)]*\)\s*$", "", st))
        if _norm(title) == want and ck and (ck in wset or wset in ck):
            hits.append(usd)
    return hits[0] if len(hits) == 1 else None


# ------------------------------------------------------------------------------------------------ the two steps
def _fresh(prev, now):
    last = _parse((prev.get("checked") or "") + "T00:00:00")
    return bool(last and now - last < FRESH)


def refresh_stock(items, store=None, fetch=None, now=None, polite=None):
    """items: [(card_id, shop_list)].  Reads each maker/retailer link not read in the last 6 days; stores {url: {stock, checked}}.  Returns {card_id: [updated shop_list]}.
    Called alone (no `store`) it saves the store itself."""
    now = now or datetime.datetime.now()
    own = store is None
    store = json.loads(json.dumps(linkstore.load())) if own else store
    pol = polite or Polite(store, fetch or default_fetch, now)
    day = now.date().isoformat()
    stock = store.setdefault("stock", {})
    out = {}
    for cid, shops in items:
        new, changed = [], False
        for s in shops:
            s = dict(s)
            if s.get("kind") in ("maker", "retailer") and s.get("url"):
                prev = stock.get(s["url"]) or {}
                if not _fresh(prev, now):
                    page = pol.read(s["url"])
                    st = parse_stock(page) if page is not None else None
                    if st:
                        prev = stock[s["url"]] = {"stock": st, "checked": day}
                if prev.get("stock") in ("in", "out"):
                    s.update(stock=prev["stock"], checked=prev["checked"], checkedText=linkstore.pretty(prev["checked"]))
                    changed = True
            new.append(s)
        if changed:
            out[cid] = new
    if own:
        linkstore.save(store)
    return out


def refresh_offers(items, store=None, fetch=None, now=None, polite=None):
    """items: [(game, name, set_name)].  Card Kingdom (Magic) only.  Stores {key: {usd, checked}}; returns {(game, name, set_name): {site: {usd, checked}}}."""
    now = now or datetime.datetime.now()
    own = store is None
    store = json.loads(json.dumps(linkstore.load())) if own else store
    pol = polite or Polite(store, fetch or default_fetch, now)
    day = now.date().isoformat()
    offers = store.setdefault("offers", {})
    out = {}
    for game, name, set_name in items:
        for site, (games, _tpl) in selllinks.SITES.items():
            if site != "Card Kingdom" or game not in games or site in selllinks.BLOCKED:      # only Card Kingdom's purchasing page is read (CoolStuffInc, added 1076d13, is a link only)
                continue
            key = linkstore.offer_key(game, name, set_name, site)
            prev = offers.get(key) or {}
            if not _fresh(prev, now):
                link = [x for x in selllinks.for_item(game, name, set_name) if x["site"] == site]
                page = pol.read(link[0]["url"]) if link else None
                usd = pick_offer(parse_ck_offers(page), name, set_name) if page else None
                if usd:
                    prev = offers[key] = {"usd": usd, "checked": day}
            if prev.get("usd"):
                out[(game, name, set_name)] = {site: dict(prev)}
    if own:
        linkstore.save(store)
    return out


# ------------------------------------------------------------------------------------------------ the job
def pick_items(data_dir, limit_per_host=BUDGET):
    """(stock items [(id, shop_list)], offer items [(game, name, set)]) from the game lists: shop links with a stored maker/retailer url (spread over hosts, oldest-checked first)
    and the highest-priced Magic cards (a buylist matters most for those)."""
    import os
    import sqlite3
    from . import games
    from .db import game_dir
    stock_items, per_host, offer_items = [], {}, []
    old = linkstore.load().get("stock") or {}
    for g in games.GAMES:
        p = os.path.join(game_dir(data_dir, g.id), "cards.db")
        if not os.path.exists(p):
            continue
        try:
            db = sqlite3.connect(p, timeout=30)
            if g.id == "mtg":
                offer_items += [("mtg", n, s or "") for n, s in db.execute(
                    "SELECT c.name, COALESCE(s.name, '') FROM cards c LEFT JOIN sets s ON s.id = c.set_id WHERE c.price_usd IS NOT NULL ORDER BY c.price_usd DESC LIMIT ?", (BUDGET,))]
            rows = db.execute("SELECT id, raw FROM cards WHERE raw LIKE '%\"url\"%' AND raw NOT LIKE '%tcgplayer.com%'").fetchall()
            db.close()
        except sqlite3.Error:
            continue
        cand = []
        for cid, raw in rows:
            try:
                url = shoplinks.clean_url(json.loads(raw or "{}").get("url") or "")
            except ValueError:
                continue
            if url:
                cand.append(((old.get(url) or {}).get("checked") or "", cid, url))
        for _chk, cid, url in sorted(cand):
            host = urlsplit(url).netloc.lower()
            if per_host.get(host, 0) < limit_per_host:
                per_host[host] = per_host.get(host, 0) + 1
                kind = "maker" if host.removeprefix("www.").endswith(shoplinks.MAKER_HOSTS) else "retailer"
                stock_items.append((cid, [{"site": host, "url": url, "kind": kind}]))
    return stock_items, offer_items


def run_weekly(data_dir, fetch=None, now=None, force=False, picker=None):
    """The whole weekly step.  Does nothing ({"ran": False}) unless 7 days passed since the last run.  Returns a short report."""
    now = now or datetime.datetime.now()
    store = json.loads(json.dumps(linkstore.load()))
    if not force and not is_due(store, now):
        return {"ran": False, "note": f"last weekly check {store.get('last_run')}"}
    stock_items, offer_items = (picker or pick_items)(data_dir)
    pol = Polite(store, fetch or default_fetch, now)
    stock = refresh_stock(stock_items, store=store, polite=pol, now=now)
    offers = refresh_offers(offer_items, store=store, polite=pol, now=now)
    store["last_run"] = _now_iso(now)
    linkstore.save(store)
    return {"ran": True, "stock": len(stock), "offers": len(offers), "checked": pol.report["checked"], "skipped": pol.report["skipped"]}
