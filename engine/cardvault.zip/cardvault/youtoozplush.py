"""Which franchise (or creator) a Youtooz plush belongs to.

youtooz.com files every plush under the product type 'Plush', so the franchise comes from the shop's COLLECTIONS ('SpongeBob SquarePants', 'Jschlatt', 'IronMouse'): the smallest collection that holds
a product is the most specific one.  The shop has about 550 collections and lists them 250 to a page; the first version of this read only page one, which left 900 plush - every creator and franchise
after 'H' - in 'Plush (other)'.

The shop slows down a caller that asks for too much (a full read is some 600 requests), so the read is made to survive that: each collection's product list is kept as soon as it is read, collections
are read smallest first (a partial read is never wrong, only less complete), a throttled shop ends the run politely and the next run carries on where this one stopped, and a collection is read again only
when its size changes or after two to four weeks.  `get(url)` is the caller's polite JSON fetch (collectibles._shop_get), passed in so this module needs no network of its own."""
import json
import os
import re
import time
import zlib

CACHE = "youtooz_collections.v2.json"                  # {handle: {n: size when read, ids: [product ids], t: when, title}}
BIGGEST = 450                                          # a collection holding more than this is a catch-all ('Gaming', 'Past Drops'), not a franchise
PAUSE = 1.0                                            # seconds between requests (at 0.5 the shop throttled after about 500, at 0.8 after about 80)
COOLDOWN = 120                                         # seconds to let a throttling shop recover before the same collection is asked again
ATTEMPTS = 3                                           # asks per collection before the run gives up
SAVE_EVERY = 25                                        # collections read between saves
PAGES = 6                                              # collection pages to read at most, 250 each
PAGE_SIZE = 250                                        # what the shop returns at most per page
PRODUCT_PAGES = 3                                      # product pages per collection

# collections that say WHEN or HOW a product was sold (drops, events, status, bundles), not what it is - read from the handle
_NOT_A_FRANCHISE = re.compile(
    r"^(all|anime|anime-collection|new|best-sellers?|featured|frontpage|home|sale|exclusives?|gifts?|plush|plushies|plush-collection|collectibles|figures?|preorders?|pre-orders?|pre-order.*|restock|in-stock|"
    r"bundles?|more-from.*|live-now|past-drops|coming-soon.*|gone-soon|rare|.*concepts?|weighted.*|twitch-legends|holiday.*|black-friday.*|cyber.*|.*-drop|.*-sale|.*-bundle|under-.*|.*gift.*|.*under.*|"
    r".*-event.*|.*event-.*|women.*day|valentine.*|halloween.*|christmas.*|spooky|spooktooz|.*pins?|"
    r"comic-books|heroes-villains|robots|reptiles|cats-dogs|sci-fi|fantasy|horror|npcs|pew-pew|shoulder-riders|sidekicks|couples|playstation|xbox|indie-games)$", re.I)       # (the last row: themes and platforms, not franchises)
_RENAMED = {"\U0001F3B6": "Music"}                        # a collection the shop names with an emoji (musical notes)


def is_franchise(collection):
    """True for a collection that names a franchise or creator (not a sale, drop, status or catch-all)."""
    return not _NOT_A_FRANCHISE.match(collection.get("handle") or "") and 0 < collection.get("products_count", 0) <= BIGGEST


def collections(get, base, cancel=None, pause=PAUSE):
    """Every collection the shop lists, page after page: [{'id', 'handle', 'title', 'products_count'}]."""
    out, seen = [], set()
    for page in range(1, PAGES + 1):
        if cancel is not None and cancel.is_set():
            break
        batch = (get(f"{base}/collections.json?limit=250&page={page}") or {}).get("collections") or []
        fresh = [c for c in batch if c["id"] not in seen]
        if not fresh:
            break
        seen.update(c["id"] for c in fresh)
        out += fresh
        time.sleep(pause)
    return out


def _spelling(title, franchise):
    """The franchise as the shop's own product types spell it ('Spongebob Squarepants' -> 'SpongeBob SquarePants'), else the collection's title."""
    title = _RENAMED.get(title.strip(), title.strip())
    key = re.sub(r"[^a-z0-9]+", "", title.lower())
    return franchise.get(key) or franchise.get(key[:-1] if key.endswith("s") else key) or title                    # ('Memes' is the product type 'Meme')


def _product_ids(get, base, handle, cancel, pause):
    """The ids of the products in one collection (it raises when the shop stops answering)."""
    ids = []
    for page in range(1, PRODUCT_PAGES + 1):
        if cancel is not None and cancel.is_set():
            break
        time.sleep(pause)
        products = (get(f"{base}/collections/{handle}/products.json?limit=250&page={page}") or {}).get("products") or []
        ids += [p["id"] for p in products]
        if len(products) < PAGE_SIZE:
            break                                                          # a short page is the last one: no second request to find that out
    return ids


def _rest(cancel, seconds):
    """Let a throttling shop recover.  -> True when the read was cancelled meanwhile."""
    if cancel is None:
        time.sleep(seconds)
        return False
    return cancel.wait(seconds)


def _read(get, base, handle, cancel, pause, cooldown):
    """The product ids of one collection - or None when the shop keeps refusing: it is given a rest and asked again, twice, before the run gives up."""
    for attempt in range(ATTEMPTS):
        try:
            return _product_ids(get, base, handle, cancel, pause)
        except Exception as e:  # noqa: BLE001 - the shop is throttling us
            print(f"youtooz: '{handle}' refused ({str(e)[:50]})" + (f"; resting {cooldown:.0f}s" if attempt + 1 < ATTEMPTS else ""), flush=True)
            if attempt + 1 < ATTEMPTS and _rest(cancel, cooldown):
                return []
    return None


def _stale(handle, read_at):
    """A collection is read again after two to four weeks - spread by its handle, so they do not all come due on the same day."""
    return time.time() - read_at > (14 + zlib.crc32(handle.encode("utf-8")) % 14) * 86400


def _load(path):
    try:
        with open(path, encoding="utf-8") as f:
            saved = json.load(f)
        return saved if isinstance(saved, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(path, saved):
    if not saved:
        return
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(saved, f)
    except OSError:
        pass


def franchise_map(get, base, franchise, cancel, cache_dir, pause=PAUSE, cooldown=COOLDOWN):
    """{product id: franchise} for the shop's plush.  `franchise` is {normalised name: the shop's spelling} from the product types.  Reads the collections not yet read (smallest first), keeps what it read,
    and returns the map from everything it holds - a shop that throttles it just ends this run early.  {} when it holds nothing (the plush stay under 'Plush (other)' and the next run tries again)."""
    path = os.path.join(cache_dir or "", CACHE)
    saved = _load(path)
    try:
        listed = collections(get, base, cancel, pause)
    except Exception as e:  # noqa: BLE001 - a busy shop: go on with what an earlier run kept
        print("youtooz: collections not listed:", str(e)[:80], flush=True)
        listed = []
    if cancel is not None and cancel.is_set():
        return {}
    if not listed:
        listed = [{"handle": h, "title": e.get("title") or h, "products_count": e.get("n", 0)} for h, e in saved.items()]
    wanted = sorted((c for c in listed if is_franchise(c)), key=lambda c: c["products_count"])
    read = 0
    for c in wanted:
        entry = saved.get(c["handle"])
        if entry and entry.get("n") == c["products_count"] and not _stale(c["handle"], entry.get("t", 0)):
            continue
        ids = _read(get, base, c["handle"], cancel, pause, cooldown)
        if ids is None:                                                    # the shop keeps refusing: stop here, keep what was read, carry on next run
            print(f"youtooz: stopped at collection '{c['handle']}'; what was read is kept", flush=True)
            break
        if cancel is not None and cancel.is_set():
            _save(path, saved)
            return {}
        if ids:                                                            # (a collection that answers with no products at all was a hiccup: it is asked again next run)
            saved[c["handle"]] = {"n": c["products_count"], "ids": ids, "t": time.time(), "title": c["title"]}
            read += 1
            if read % SAVE_EVERY == 0:
                _save(path, saved)                                         # (a run that is stopped halfway keeps most of what it read)
    _save(path, saved)
    best = {}                                                              # product id -> (size of its smallest collection, franchise)
    for c in wanted:
        for pid in (saved.get(c["handle"]) or {}).get("ids") or ():
            if pid not in best or c["products_count"] < best[pid][0]:
                best[pid] = (c["products_count"], _spelling(c.get("title") or "", franchise))
    return {i: v[1] for i, v in best.items()}
