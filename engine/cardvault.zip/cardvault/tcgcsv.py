"""Provider for card games listed in TCGplayer's catalogue, read from tcgcsv.com (a free daily dump of that catalogue).

Download-only.  One request lists a game's sets ("groups"); one request per set gives its cards ("products", including rarity,
number, colour, card type, text) and one gives its market prices - about 170 small requests for a whole game.  Pictures come
from TCGplayer's image server (200 px or 400 px JPEG).  Sealed products (boxes, packs) are skipped: only products that
have a card Number are cards.
"""
import html
import json
import os
import re
import time

from . import sync
from .db import image_file, open_cards_conn, sort_key
from .games import GameProvider

BASE = "https://tcgcsv.com/tcgplayer"


def _clean(text):
    t = re.sub(r"<[^>]+>", "", html.unescape(text or ""))
    return re.sub(r"\s+", " ", t).strip()


def _ext(product):
    return {e["name"]: e["value"] for e in product.get("extendedData", [])}


def serie_for(game_id, group):
    """Which era / family a set belongs to - used by the series dropdown."""
    name = group.get("name") or ""
    abbr = (group.get("abbreviation") or "").upper()
    low = name.lower()
    if game_id == "onepiece":
        if "release event" in low or abbr.endswith(" RE"):
            return "Release Event Cards"
        code = abbr or name.split(":")[0].upper()
        if code.startswith("OP"):
            return "Booster Packs"
        if code.startswith("EB") or low.startswith("extra booster"):
            return "Extra Boosters"
        if code.startswith("PRB") or "premium booster" in low:
            return "Premium Boosters"
        if code.startswith(("ST", "SD")) or "starter deck" in low:
            return "Starter Decks"
        return "Promos & Other"
    if game_id == "unionarena":
        if "release event" in low:
            return "Release Event Cards"
        m = re.match(r"(UE|UEX|UP)?(\d+)?([A-Z]+)?", name.split(":")[0].upper())
        code = name.split(":")[0].upper()
        if code.startswith("UEX"):
            return "Special Boosters"
        if code.startswith("UP"):
            return "Premium Boosters"
        if code.endswith("BT"):
            return "Booster Packs"
        if code.endswith("ST") or "starter" in low:
            return "Starter Decks"
        if code.endswith("DC") or "advanced deck" in low:
            return "Advanced Decks"
        return "Promos & Other"
    return None


class TcgCsvProvider(GameProvider):
    avg_bytes = {"low": 22_000, "high": 60_000}

    def __init__(self, game_id, category_id, type_field="Color"):
        self.game_id = game_id
        self.category_id = category_id
        self.type_field = type_field

    # ------------------------------------------------------------------ catalogue (sets + cards + prices in one pass)
    def _get(self, path):
        d = sync._get(f"{BASE}/{self.category_id}/{path}")
        return (d or {}).get("results", [])

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the list of sets…", 0, 0)
            groups = self._get("groups")
            if only_sets:
                groups = [g for g in groups if str(g["groupId"]) in only_sets]
            done = [0]
            day = time.strftime("%Y-%m-%d")

            def one(g):
                gid = g["groupId"]
                return self._get(f"{gid}/products"), self._get(f"{gid}/prices")

            def got(g, result):
                products, prices = result
                done[0] += 1
                cards = [p for p in products if "Number" in _ext(p)]
                if cards:
                    self._store_group(conn, g, cards, prices, day)
                if done[0] % 8 == 0:
                    conn.commit()
                progress("Reading sets…", done[0], len(groups))

            sync._pool(groups, one, cancel, got, workers=6)
            conn.commit()
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def _store_group(self, conn, g, cards, prices, day):
        sid = str(g["groupId"])
        rel = (g.get("publishedOn") or "")[:10]
        conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)",
                     (sid, g["name"], serie_for(self.game_id, g), rel, len(cards), len(cards), None))
        by_pid = {}
        for pr in prices:
            by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr.get("marketPrice")
        for p in cards:
            ext = _ext(p)
            number = str(ext.get("Number") or "")
            nums = re.findall(r"\d+", number)
            subs = by_pid.get(p["productId"], {})
            usd = subs.get("Normal") if subs.get("Normal") is not None else next((v for v in subs.values() if v is not None), None)
            flags = {}
            if "Normal" in subs or not subs:
                flags["normal"] = True
            if "Foil" in subs:
                flags["holo"] = True
            typ = str(ext.get(self.type_field) or "").replace(";", ", ")
            name = re.sub(r"\s*\(\d{1,3}\)\s*", " ", p["name"]).strip()
            raw = {"productId": p["productId"], "url": p.get("url"), "ext": ext, "prices": subs}
            conn.execute(
                "INSERT INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_updated,variants,raw) "
                "VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET set_id=excluded.set_id, local_id=excluded.local_id, "
                "sort_key=excluded.sort_key, name=excluded.name, image_base=excluded.image_base, detailed=1, category=excluded.category, "
                "rarity=excluded.rarity, types=excluded.types, description=excluded.description, price_usd=excluded.price_usd, "
                "price_updated=excluded.price_updated, variants=excluded.variants, raw=excluded.raw",
                (str(p["productId"]), sid, number, int(nums[-1]) if nums else 100000, name, p.get("imageUrl"), ext.get("CardType"),
                 ext.get("Rarity"), typ, _clean(ext.get("Description")), usd, day, json.dumps(flags), json.dumps(raw, ensure_ascii=False)))

    def fetch_details(self, gdir, cancel, progress, refresh_all=False, only_ids=None):
        return 0          # everything arrives with the catalogue

    # ------------------------------------------------------------------ pictures
    def _url(self, base, quality):
        return base.replace("_200w", "_400w") if quality == "high" else base

    def _pending(self, gdir, quality):
        conn = open_cards_conn(gdir)
        try:
            rows = conn.execute("SELECT id, set_id, image_base FROM cards WHERE image_base IS NOT NULL AND image_base!=''").fetchall()
        finally:
            conn.close()
        todo = []
        for cid, sid, base in rows:
            p = image_file(gdir, quality, cid, sid)
            if not (os.path.exists(p) and os.path.getsize(p) > 0):
                todo.append((cid, sid, base))
        return todo, len(rows)

    def fetch_images(self, gdir, quality, cancel, progress):
        todo, _ = self._pending(gdir, quality)
        total, count = len(todo), [0]

        def one(item):
            cid, sid, base = item
            data = sync._get(self._url(base, quality), as_json=False)
            if data:
                p = image_file(gdir, quality, cid, sid)      # JPEG bytes in the shared picture folder; Qt and Pillow read by content
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p + ".part", "wb") as f:
                    f.write(data)
                os.replace(p + ".part", p)
            return bool(data)

        def got(item, ok):
            count[0] += 1
            if count[0] % 25 == 0 or count[0] == total:
                progress("Downloading images…", count[0], total)

        progress("Downloading images…", 0, total)
        sync._pool(todo, one, cancel, got)
        return total

    def estimate(self, gdir, quality):
        conn = open_cards_conn(gdir)
        try:
            n_cards = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
            n_sets = conn.execute("SELECT COUNT(*) FROM sets").fetchone()[0]
        finally:
            conn.close()
        todo, with_img = self._pending(gdir, quality)
        return {"logos_missing": 0, "cards": n_cards, "sets": n_sets, "details_missing": 0, "images_missing": len(todo),
                "images_total": with_img, "image_mb": len(todo) * self.avg_bytes[quality] / 1_000_000}

    # ------------------------------------------------------------------ prices (one request per set)
    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        conn = open_cards_conn(gdir)
        try:
            groups = [r[0] for r in conn.execute("SELECT id FROM sets")]
            day = time.strftime("%Y-%m-%d")
            done = [0]

            def one(gid):
                return self._get(f"{gid}/prices")

            def got(gid, prices):
                by_pid = {}
                for pr in prices:
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr.get("marketPrice")
                for pid, subs in by_pid.items():
                    usd = subs.get("Normal") if subs.get("Normal") is not None else next((v for v in subs.values() if v is not None), None)
                    conn.execute("UPDATE cards SET price_usd=?, price_updated=? WHERE id=?", (usd, day, str(pid)))
                done[0] += 1
                progress("Updating prices…", done[0], len(groups))

            progress("Updating prices…", 0, len(groups))
            try:
                sync._pool(groups, one, cancel, got, workers=6)
            finally:
                conn.commit()
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return len(groups)
        finally:
            conn.close()
