"""Profit and loss (roadmap "Profit and loss"): what the owner paid against what it is worth now, per item and overall, with the best and worst buys, for one game or all.

Built only from what already exists - nothing new is stored:
    paid        u.lots.purchase_price (each) + the grading cost of those copies (grading.lot_costs); sealed products: u.sealed.paid
    worth now   the ONE price-pick rule (pricepick: the Settings > Price sources choice; a graded copy at its grade's price when the card list has one); sealed: sealedprice
    realised    the sold history (sold.realised: u.sold, Value > Sold)
Rules:
    * only copies with a price paid count ("no cost recorded" copies are counted, never guessed);
    * an item of your own (customitems) counts at YOUR ESTIMATE and its P&L is marked est (estimated) - never presented as market data;
    * an item with a price paid but no true price and no estimate (no price at all, or only an eBay asking price) is listed as "no price yet" - never counted as 0 profit.
A game that is not open is read through a read-only stand-in (open_other); its pick falls back to the main price when its setting cannot be read, like the collection export."""
from . import completion, grading, pfscope, pricepick, sealedprice, sold
from .customitems import PREFIX

TOP = 10


def _basis(usd, kind):
    """'est' (your estimate), 'market' (a true price) or None (no price yet)."""
    if usd is None or usd <= 0:
        return None
    if completion.is_estimate(kind):
        return "est"
    return "market" if completion.true_price(usd, kind) else None


def _copy_price(g, picked, estimates, r):
    """(usd, basis) of ONE copy: an item of your own at its estimate, a graded copy at its graded price when one exists, else the picked card price."""
    cid = r["card_id"]
    if cid.startswith(PREFIX):
        est = estimates.get(cid)
        return est, ("est" if est else None)
    if r["graded"]:
        gp = pricepick.graded_price(g, cid, r["grade_company"], r["grade"])
        if gp:
            return gp[0], "market"
    usd, kind = pricepick.shown_in(picked, cid, r["price_usd"], r["price_kind"])
    return usd, _basis(usd, kind)


def _item(out, gid, key, kind, name, set_name, number):
    return out.setdefault((gid, key), {"game": gid, "id": key, "kind": kind, "name": name or key, "set": set_name or "", "number": number or "",
                                       "qty": 0, "paidQty": 0, "paid": 0.0, "worth": 0.0, "noPriceQty": 0, "noPricePaid": 0.0, "est": False})


def _add(it, qty, paid_each, extra_cost, usd, basis):
    it["qty"] += qty
    if paid_each is None:
        return
    cost = paid_each * qty + (extra_cost or 0.0)
    it["paidQty"] += qty
    if basis is None:
        it["noPriceQty"] += qty; it["noPricePaid"] += cost
        return
    it["paid"] += cost; it["worth"] += usd * qty
    it["est"] = it["est"] or basis == "est"


def game_items(g, gid, user_id, pf=None):
    """Every item this person owns in one game (cards - grouped per card - and sealed products), with the money of its copies that have a price paid.
    pf = only these portfolios (database ids, '' = the main one); None = every portfolio."""
    lots_pf, sealed_pf = pfscope.where(pf, "l.portfolio"), pfscope.where(pf)
    picked = pricepick.prices_or_main(g)
    gcost = grading.lot_costs(g)
    estimates = {PREFIX + u: e for u, e in g.conn.execute("SELECT uuid, estimate FROM u.custom_items WHERE user_id=? AND game=? AND deleted=0", (user_id, gid))} if _has(g, "custom_items") else {}
    out = {}
    for r in g.conn.execute("SELECT l.id, l.card_id, l.qty, l.purchase_price, l.graded, l.grade_company, l.grade, c.name, c.local_id, c.price_usd, c.price_kind, s.name AS set_name "
                            "FROM u.lots l LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0" + lots_pf[0], (user_id, gid, *lots_pf[1])):
        usd, basis = _copy_price(g, picked, estimates, r)
        _add(_item(out, gid, r["card_id"], "card", r["name"], r["set_name"], r["local_id"]), r["qty"], r["purchase_price"], gcost.get(r["id"]), usd, basis)
    if _has(g, "sealed"):
        for r in g.conn.execute("SELECT name, qty, paid FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0" + sealed_pf[0], (user_id, gid, *sealed_pf[1])):
            p = (sealedprice.price_for(g, r["name"]) or {}).get("price")
            _add(_item(out, gid, "sealed:" + (r["name"] or ""), "sealed", r["name"], "Sealed", ""), r["qty"] or 0, r["paid"], 0.0, p, "market" if p else None)
    return [_finish(x) for x in out.values()]


def _has(g, table):
    return g.conn.execute("SELECT 1 FROM u.sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def _finish(it):
    priced = it["paidQty"] - it["noPriceQty"]
    for k in ("paid", "worth", "noPricePaid"):
        it[k] = round(it[k], 2)
    it["gain"] = round(it["worth"] - it["paid"], 2) if priced else None
    it["pct"] = round(100.0 * it["gain"] / it["paid"], 1) if priced and it["paid"] else None
    return it


def summary(items, realised):
    """The P&L of these items: {unrealised, realised, overall, best, worst, rows, noPrice, noCost}.  realised = sold.realised(...) or None."""
    rows = sorted((x for x in items if x["gain"] is not None), key=lambda x: (-x["gain"], x["name"]))
    paid, worth = sum(x["paid"] for x in rows), sum(x["worth"] for x in rows)
    est = [x for x in rows if x["est"]]
    unreal = {"paid": round(paid, 2), "worth": round(worth, 2), "gain": round(worth - paid, 2), "pct": round(100.0 * (worth - paid) / paid, 1) if paid else None,
              "items": len(rows), "estItems": len(est), "estGain": round(sum(x["gain"] for x in est), 2)}
    best = rows[:TOP]
    top = {id(x) for x in best}
    worst = [x for x in reversed(rows) if id(x) not in top][:TOP]
    no_price = sorted((x for x in items if x["noPriceQty"]), key=lambda x: (-x["noPricePaid"], x["name"]))
    no_cost = [x for x in items if x["qty"] > x["paidQty"]]
    overall = round(unreal["gain"] + (realised["profit"] if realised and realised.get("costed") else 0), 2)
    return {"unrealised": unreal, "realised": realised, "overall": overall, "best": best, "worst": worst, "rows": rows, "noPrice": no_price,
            "noCost": {"items": len(no_cost), "copies": sum(x["qty"] - x["paidQty"] for x in no_cost)}}


def owned_games(v):
    """The games this person holds or sold anything in, sorted."""
    sold.ensure(v)
    q = ("SELECT DISTINCT game FROM u.lots WHERE user_id=? AND deleted=0 AND qty>0 UNION SELECT DISTINCT game FROM u.sold WHERE user_id=? AND deleted=0"
         + (" UNION SELECT DISTINCT game FROM u.sealed WHERE user_id=? AND deleted=0 AND qty>0" if _has(v, "sealed") else ""))
    return sorted({r[0] for r in v.conn.execute(q, (v.user_id,) * q.count("?")) if r[0]})


def report(v, game="", open_other=None, pf=None):
    """The whole P&L for one game (game = its id) or every game (game = ""), from the open vault `v`.  open_other(v, game id) -> a read-only stand-in for a game that is not open
    (closed by this function); without it only the open game's items are read.  pf = only these portfolios (database ids); None = every portfolio."""
    from .games import game_by_id
    gids = owned_games(v)
    items = []
    for gid in gids:
        if game and gid != game:
            continue
        if gid == v.game:
            items += game_items(v, gid, v.user_id, pf)
        elif open_other:
            g = open_other(v, gid)
            try:
                items += game_items(g, gid, v.user_id, pf)
            finally:
                g.conn.close()
    names = {gid: game_by_id(gid).name if game_by_id(gid).id == gid else gid for gid in gids}      # (an id the game list does not know keeps its id)
    for x in items:
        x["gameName"] = names.get(x["game"], x["game"])
    return {"game": game, "open": v.game, "games": [{"id": g, "name": names[g]} for g in gids], **summary(items, sold.realised(v, game, pf))}
