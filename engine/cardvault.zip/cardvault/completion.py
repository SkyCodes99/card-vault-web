"""The ONE completion engine: for a set and a goal -> what has to be owned, what is owned, what is missing, how far along (%) and what the missing part costs.

Goals (the internal key of the third one is still "extended", the name people see is "Extra"):
  standard  one of every card of the set (a card counts when any of its versions is owned); cards left out of the set by the person are not counted
  master    every version of every card (normal, reverse holo, holo, 1st edition ... as the card list says it comes in)
  extended  master + the extra CARDS (never sealed products) that name the set: stamped, Cosmos Holo, staff / pre-release, box / blister / league promos (the pattern printings are a separate checkmark)
Collectible games (toys, plushies ...) have no versions or promo cards: they only have "standard".
The set tile (counts, %, tag), "Cost to complete" and the wishlist all read from here.  `counts()` is the same math for every set at once (the tiles); `items()` / `summary()` for one set.
An item id is the card id (standard), "card id|version" (master) or "card id|extra" (an extra card) - the same keys the master-set screen uses."""
import json

from . import variantprice
from .db import VARIANT_FLAGS, VARIANT_LABELS, clean_flags

STANDARD, MASTER, EXTENDED = "standard", "master", "extended"
GOALS = (STANDARD, MASTER, EXTENDED)
LABELS = {STANDARD: "Standard", MASTER: "Master", EXTENDED: "Extra"}


def allowed(game):
    """The goals a game offers (`game` = the Game record or None)."""
    return (STANDARD,) if game is not None and getattr(game, "family", "") == "collectibles" else GOALS


def clamp(goal, game=None, default=STANDARD):
    """`goal` if the game offers it, else the default (or the first goal on offer)."""
    ok = allowed(game)
    return goal if goal in ok else (default if default in ok else ok[0])


_LABELS = {}


def version_labels(variants, rarity):
    """The versions a card comes in, as the names the collection uses ('Normal' when the list says nothing).  (A big list has only a few hundred different answers: kept.)"""
    got = _LABELS.get((variants, rarity))
    if got is None:
        try:
            flags = clean_flags(json.loads(variants or "{}"), rarity)
        except ValueError:
            flags = {}
        if len(_LABELS) > 20000:
            _LABELS.clear()
        got = _LABELS[(variants, rarity)] = tuple(VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)) or ("Normal",)
    return list(got)


# ---------------------------------------------------------------------------------------------------------------- prices (the ONE place a missing item's price comes from)
_COLS = "id, rarity, variants, price_usd, price_kind, variant_prices"


def price_book(v):
    """The prices every cost here uses: None = the card list's own prices (as every total has always used them), else {card id: usd} from the person's choice in
    Settings > Price sources (cardvault/pricepick.py, "Choose your price sources").  The hook for that choice is here and nowhere else."""
    try:
        from . import pricepick
    except ImportError:                                                        # (a build without price sources: the card list's own prices)
        return None
    return pricepick.prices(v)


def is_ask(kind):
    """Is this card-list price kind an eBay asking price (cardvault/ebayprices.py: the only price many toys have)?"""
    return str(kind or "").lower().startswith("ebay")


def card_price(r, label, book, vp=None):
    """-> (usd or None, exact, ask): the price of one version of a card (label None = the card itself, e.g. an extra card).
    A version's own TCGplayer price comes first (variantprice); otherwise the card's own price stands in (exact False) - the picked one when `book` is set.
    `ask` = the price kind ("eBay asking price (median of 6)") when the only price the item has is an eBay ASKING price, else "": such an item has NO true price (usd None, owner 2026-11-11) - an ask never counts
    in a cost to finish, and the screens say it has only an ask."""
    head = r["price_usd"] if book is None else book.get(r["id"])
    if label is None or not r["variant_prices"]:
        usd, exact = head, label is None
    else:
        usd, exact = variantprice.price_for({"variant_prices": r["variant_prices"] if vp is None else vp, "variants": r["variants"], "price_usd": head}, label)     # (vp: already read)
    ask = (r["price_kind"] or "") if book is None and usd is not None and not (label and exact) and is_ask(r["price_kind"]) else ""
    return (None if ask else usd), exact, ask                                  # (an eBay ask is never a cost: the item has "no true price"; `ask` still says why)


# ---------------------------------------------------------------------------------------------------------------- extra cards
def extra_cards(svc, set_row, extra_kinds=None, patterns=False):
    """[(card id, name, number, label)] of the extra cards that count for this set: the chosen kinds (None = all of them); pattern printings only when `patterns` is set."""
    try:
        from .webapi.masterextra import GROUPS, PATTERNS, extras_for_set, group_of
        found = extras_for_set(svc, set_row)
    except Exception:  # noqa: BLE001 - a game without promo sets simply has none
        return []
    want = set(extra_kinds) if extra_kinds else {g for g, _t in GROUPS} | {"other"}
    want.discard(PATTERNS)
    if patterns:
        want.add(PATTERNS)
    return [e for e in found if group_of(e[3]) in want and not str(e[0]).startswith("sealed:")]      # (CARDS ONLY: a sealed product never counts in the Extra goal)


# ---------------------------------------------------------------------------------------------------------------- one set
def _set_row(v, set_id):
    r = v.conn.execute("SELECT * FROM sets WHERE id=?", (set_id,)).fetchone()
    if r is None:
        raise LookupError("set not found")
    return r


def _vp(r):
    """A card row's prices per version, read once ({} when it has none)."""
    try:
        d = json.loads(r["variant_prices"]) if r["variant_prices"] else {}
    except ValueError:
        return {}
    return d if isinstance(d, dict) else {}


def _card_items(r, goal, mine, book, price_owned=True):
    """The items one card adds at this goal (`r` = its card-list row with id, rarity, variants, price_usd, price_kind, variant_prices; `mine` = the versions owned).
    items() (one set) and costs() (every set) both go through here, so the tiles and the missing list always agree."""
    if goal == STANDARD:                                                      # one per card: owned in whichever version; if none, the cheapest version is the one to buy
        owned = bool(mine)
        if owned and not price_owned:
            usd, exact, ask = None, True, ""
        elif not r["variant_prices"]:
            usd, exact, ask = card_price(r, "Normal", book)                   # (no price per version: every version has the card's own price)
        else:
            vp = _vp(r)
            got = [card_price(r, lab, book, vp) for lab in version_labels(r["variants"], r["rarity"])]
            best = min((g for g in got if g[0] is not None), key=lambda g: g[0], default=(None, True, ""))
            usd, exact, ask = best[0], all(g[1] for g in got), best[2]
        yield {"id": r["id"], "card": r["id"], "variant": None, "extra": None, "price": usd, "exact": exact, "ask": ask, "owned": owned}
        return
    vp = _vp(r)
    for lab in version_labels(r["variants"], r["rarity"]):
        owned = lab in mine
        usd, exact, ask = (None, True, "") if owned and not price_owned else card_price(r, lab, book, vp)
        yield {"id": f"{r['id']}|{lab}", "card": r["id"], "variant": lab, "extra": None, "price": usd, "exact": exact, "ask": ask, "owned": owned}


def _extra_item(cid, lab, row, book, owned):
    usd, exact, ask = card_price(row, None, book)
    return {"id": f"{cid}|extra", "card": cid, "variant": None, "extra": lab, "price": usd, "exact": exact, "ask": ask, "owned": owned}


def _light_row(v, cid):
    c = v.card_light(cid) or {}
    return {"id": cid, "price_usd": c.get("price_usd"), "price_kind": c.get("price_kind"), "variant_prices": None, "variants": None}


def items(svc, set_id, goal, extra_kinds=None, patterns=False):
    """Everything that must be owned to finish the set at this goal: [{id, card, variant, extra, price, exact, ask, owned}] in card order.  `price` is that version's price (None = no price),
    `ask` = it is an eBay asking price (see card_price)."""
    v = svc.vault
    s = _set_row(v, set_id)
    goal = clamp(goal, getattr(svc, "game", None), MASTER)
    have = {}
    for cid, var in v.conn.execute("SELECT l.card_id, l.variant FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE c.set_id=? AND l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0",
                                   (set_id, v.user_id, v.game)):
        have.setdefault(cid, set()).add(var)
    left = v.excluded_cards(set_id)
    book = price_book(v)
    out = []
    for r in v.conn.execute(f"SELECT {_COLS} FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,)):
        if r["id"] not in left:
            out.extend(_card_items(r, goal, have.get(r["id"], set()), book))
    if goal == EXTENDED:
        for cid, _nm, _no, lab in extra_cards(svc, s, extra_kinds, patterns):
            out.append(_extra_item(cid, lab, _light_row(v, cid), book, svc.owned.get(cid, 0) > 0))
    return out


def card_costs(v, ids):
    """{card id: item} for single cards at the Standard level, owned or not (the price is always given): the same item, the same price, as the tiles and the missing list use for a card that is
    not owned yet - what a wishlist (or any list of cards) costs to buy is worked out from this and nowhere else."""
    book, have, out = price_book(v), v.owned_variants(), {}
    ids = list(dict.fromkeys(ids))
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        for r in v.conn.execute(f"SELECT {_COLS} FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
            for it in _card_items(r, STANDARD, have.get(r["id"], ()), book):
                out[r["id"]] = it
    return out


def summarize(its, goal, full=False):
    """The numbers of one set at one goal from its items: required / owned / missing (ids, count) / % and what the missing part costs (the unpriced ones are counted apart, never guessed)."""
    missing = [i for i in its if not i["owned"]]
    priced = [i["price"] for i in missing if i["price"] is not None]
    out = {"goal": goal, "goalLabel": LABELS.get(goal, goal), "required": len(its), "owned": len(its) - len(missing), "missing": [i["id"] for i in missing], "missingCount": len(missing),
           "pct": (100.0 * (len(its) - len(missing)) / len(its)) if its else 0.0, "missingCost": round(sum(priced), 2), "unpriced": len(missing) - len(priced),
           "askCost": round(sum(i["price"] for i in missing if i["price"] is not None and i.get("ask")), 2)}       # (the part of missingCost that is eBay asking prices)
    if full:
        out["requiredIds"] = [i["id"] for i in its]
    return out


def for_set(svc, set_id, goal, extra_kinds=None, patterns=False, full=False):
    """items() + summarize() in one go."""
    goal = clamp(goal, getattr(svc, "game", None), MASTER)
    return summarize(items(svc, set_id, goal, extra_kinds, patterns), goal, full)


# ---------------------------------------------------------------------------------------------------------------- every set at once (the tiles)
def _master_counts(v):
    """{set id: (owned, total)} counted as a MASTER set: every version of every card (a card left out of the set is not counted)."""
    have, left, out = v.owned_variants(), v.excluded_cards(), {}
    for cid, sid, rarity, variants in v.conn.execute("SELECT id, set_id, rarity, variants FROM cards"):
        if cid in left.get(sid, ()):
            continue
        labels = version_labels(variants, rarity)
        mine = have.get(cid, set())
        owned, total = out.get(sid, (0, 0))
        out[sid] = (owned + sum(1 for lab in labels if lab in mine), total + len(labels))
    return out


def _standard_overrides(v):
    """{set id: (owned, total)} for the sets that have cards left out (every other set's standard count is simply its distinct owned cards / its size, which the caller already has)."""
    left, out = v.excluded_cards(), {}
    if not left:
        return out
    have = v.owned_map()
    for sid, gone in left.items():
        ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=?", (sid,)) if r[0] not in gone]
        out[sid] = (sum(1 for i in ids if have.get(i, 0) > 0), len(ids))
    return out


def counts(svc, goal, patterns=False):
    """{set id: (owned, total)} counted at this goal.  For STANDARD only the sets that need a correction are in it (those with cards left out).  Worked out once per change of collection and kept."""
    v = svc.vault
    key = (svc.last_change, v.game, v.user_id, goal, bool(patterns), id(v.card_index()))
    kept = getattr(svc, "_set_levels", None)
    if kept is None:
        kept = svc._set_levels = {}
    if goal in kept and kept[goal][0] == key:
        return kept[goal][1]
    if goal == STANDARD:
        out = _standard_overrides(v)
    else:
        out = dict(counts(svc, MASTER)) if goal == EXTENDED else _master_counts(v)
        if goal == EXTENDED:
            for s in v.sets():
                extras = extra_cards(svc, s, None, patterns)
                if extras:
                    owned, total = out.get(s["id"], (0, 0))
                    out[s["id"]] = (owned + sum(1 for e in extras if svc.owned.get(e[0], 0) > 0), total + len(extras))
    kept[goal] = (key, out)
    return out


# ---------------------------------------------------------------------------------------------------------------- what finishing every set costs (the tiles, the overview)
# Two steps so a change to the collection costs next to nothing on a 100,000-card list: what every set costs with NOTHING owned (one pass over the card list, kept until the card list,
# its prices or the price choice change), then the cards the person owns or left out are taken off - only those rows are read again.
def _bump(out, sid, it, sign=1):
    n, cost, unpriced, asked = out.get(sid, (0, 0.0, 0, 0.0))
    p = it["price"]
    out[sid] = (n + sign, cost + sign * (p or 0.0), unpriced + sign * (p is None), asked + sign * (p if p is not None and it["ask"] else 0.0))


def _whole_sets(svc, goal, patterns, book):
    """({set id: (items, cost, unpriced, asked)} with nothing owned, {set id: [extra items]}, book)."""
    v, out, extras = svc.vault, {}, {}
    for r in v.conn.execute(f"SELECT set_id, {_COLS} FROM cards"):
        for it in _card_items(r, goal, (), book):
            _bump(out, r["set_id"], it)
    if goal == EXTENDED:
        for s in v.sets():
            found = extra_cards(svc, s, None, patterns)
            if found:
                rows = {r["id"]: r for r in v.conn.execute(f"SELECT {_COLS} FROM cards WHERE id IN ({','.join('?' * len(found))})", [e[0] for e in found])}
                extras[s["id"]] = [_extra_item(cid, lab, rows.get(cid) or _light_row(v, cid), book, False) for cid, _nm, _no, lab in found]
    return out, extras, book


def _whole(svc, goal, patterns, book):
    """_whole_sets(); with the card list's own prices it is kept in a file beside the card list too (filtercache), so a new session does not work it out again (Magic: about a second)."""
    if book is not None:
        return _whole_sets(svc, goal, patterns, book)
    from .webapi import filtercache
    base, extras, _b = filtercache.kept(svc.vault, f"setcosts2_{goal}{'_patterns' if patterns else ''}", lambda: list(_whole_sets(svc, goal, patterns, None)))
    return base, extras, None


def _rows_of(v, ids):
    ids = list(ids)
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        yield from v.conn.execute(f"SELECT set_id, {_COLS} FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk)


def _set_costs(svc, goal, patterns, whole):
    v = svc.vault
    base, extras, book = whole
    out, have, left = dict(base), v.owned_variants(), v.excluded_cards()
    gone = {cid for ids in left.values() for cid in ids}
    for r in _rows_of(v, set(have) | gone):
        out_of_set = r["id"] in left.get(r["set_id"], ())
        for it in _card_items(r, goal, have.get(r["id"], ()), book):
            if out_of_set or it["owned"]:
                _bump(out, r["set_id"], it, -1)                                # (priced the same way as when it was added, so it comes off exactly)
    for sid, its in extras.items():
        for it in its:
            if svc.owned.get(it["card"], 0) <= 0:
                _bump(out, sid, it)
    return {sid: (n, round(cost, 2), unpriced, round(max(asked, 0.0), 2)) for sid, (n, cost, unpriced, asked) in out.items() if n > 0}


def _list_key(v, goal, patterns, book):
    """What the whole-list part of costs() is worked out from (book: the picked prices, compared by identity first)."""
    return (v.game, goal, bool(patterns), id(v.card_index()), book, getattr(v, "_cl_rev", 0))


def costs_ready(svc, goal, patterns=False):
    """Whether costs() can answer without its costly part (the whole card list): it is kept for this card list and its prices.  (Home asks this so it never waits a second for it.)"""
    whole = (getattr(svc, "_set_costs", None) or {}).get(("whole", goal))
    return whole is not None and whole[0] == _list_key(svc.vault, goal, patterns, price_book(svc.vault))


def costs(svc, goal, patterns=False):
    """{set id: (missing count, missing cost, unpriced, asked)} for every set that still misses something at this goal - the same items and prices as items() / summarize() (`asked` = the part of
    the cost that is eBay asking prices).  Kept per change of collection, like counts(); the costly part (the card list with nothing owned) only per change of the card list or its prices."""
    v = svc.vault
    book = price_book(v)
    list_key = _list_key(v, goal, patterns, book)
    kept = getattr(svc, "_set_costs", None)
    if kept is None:
        kept = svc._set_costs = {}
    whole = kept.get(("whole", goal))
    if whole is None or whole[0] != list_key:
        whole = kept[("whole", goal)] = (list_key, _whole(svc, goal, patterns, book))
    key = (svc.last_change, v.user_id, list_key)
    if goal not in kept or kept[goal][0] != key:
        kept[goal] = (key, _set_costs(svc, goal, patterns, whole[1]))
    return kept[goal][1]


# ---------------------------------------------------------------------------------------------------------------- how many items of a list have no TRUE price (the one helper behind every "12 of 340 have no true price yet")
def true_price(usd, kind=""):
    """Is this a true price?  A number that is not an eBay asking price (a store price counts, for toys)."""
    return usd is not None and usd > 0 and not is_ask(kind) and not is_estimate(kind)


def is_estimate(kind):
    """Is this the owner's own "your estimate" of an item of theirs (cardvault/customitems.py)?  It counts in totals but is never a true (market) price."""
    return str(kind or "").lower().startswith("your estimate")


def missing_price_count(v, ids):
    """{"missing": n, "total": n} for these card ids of the open game: `missing` = those with no true price (the picked price - pricepick - when none, or only an eBay ask).  Sealed products and ids the
    card list does not know are not counted as cards here; a name list the caller made of sealed items uses count_missing() instead."""
    ids = list(dict.fromkeys(i for i in ids if i))
    book, missing, total = price_book(v), 0, 0
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        for r in v.conn.execute(f"SELECT id, price_usd, price_kind FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
            total += 1
            usd = r["price_usd"] if book is None else book.get(r["id"])
            missing += not true_price(usd, r["price_kind"] if book is None else "") or is_estimate(r["price_kind"])      # (an estimate is not a true price whichever price source is picked)
    return {"missing": missing, "total": total}


def count_missing(prices):
    """The same count from prices a screen already has: [(usd, kind)] -> {"missing", "total"} (sealed products, portfolio rows ...)."""
    prices = list(prices)
    return {"missing": sum(1 for u, k in prices if not true_price(u, k)), "total": len(prices)}
