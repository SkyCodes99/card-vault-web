"""Documents made from the collection: the insurance inventory (PDF) and the full spreadsheet export."""
import datetime
import html

from . import currency, tools


def _grade(r):
    return f"{r['grade_company']} {r['grade']}".strip() if r["graded"] else (r["condition"] or "")


def insurance_html(vault, owner=""):
    rows = tools.inventory_rows(vault)
    total_copies = sum(r["qty"] for r in rows)
    total_value = sum((r["price_usd"] or 0) * r["qty"] for r in rows)
    unpriced = sum(1 for r in rows if r["price_usd"] is None)
    e = html.escape
    parts = [f"<h1>Collection inventory for insurance</h1>",
             f"<p>{e(owner) + ' - ' if owner else ''}{datetime.date.today():%d %B %Y}  ·  Pokemon Card Vault</p>",
             f"<p><b>{total_copies:,}</b> cards ({len(rows):,} lines)  ·  estimated market value <b>{currency.fmt(total_value)}</b> "
             f"({currency.code()})" + (f"  ·  {unpriced} lines have no price" if unpriced else "") + "</p>",
             "<p><i>Values are market estimates taken from public prices on the date above. They are not an appraisal; "
             "graded and rare cards can sell for more or less.</i></p>",
             "<table border='1' cellspacing='0' cellpadding='3' width='100%'>"
             "<tr bgcolor='#dddddd'><th align='left'>Card</th><th align='left'>Set</th><th>#</th><th>Qty</th>"
             "<th align='left'>Condition / grade</th><th align='left'>Where</th><th align='right'>Each</th><th align='right'>Total</th></tr>"]
    for r in rows:
        each = r["price_usd"]
        extra = " · ".join(x for x in (r["variant"], r["edition"], r["cert"] and f"cert {r['cert']}") if x)
        parts.append(f"<tr><td>{e(r['name'])}{(' <small>(' + e(extra) + ')</small>') if extra else ''}</td><td>{e(r['set_name'] or '')}</td>"
                     f"<td align='center'>{e(str(r['local_id']))}</td><td align='center'>{r['qty']}</td><td>{e(_grade(r))}</td>"
                     f"<td>{e(r['location'] or '')}</td><td align='right'>{currency.fmt(each)}</td>"
                     f"<td align='right'>{currency.fmt(None if each is None else each * r['qty'])}</td></tr>")
    parts.append(f"<tr bgcolor='#eeeeee'><td colspan='7' align='right'><b>Total</b></td><td align='right'><b>{currency.fmt(total_value)}</b></td></tr></table>")
    return "".join(parts)


_PUNCT = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "…": "...", "·": "-", "★": "*", "×": "x", "€": "EUR"}


def _latin(text):
    """The PDF's built-in font covers Western European letters (Pokémon, Mé..); anything else becomes '?'."""
    text = "".join(_PUNCT.get(ch, ch) for ch in str(text or ""))
    return text.encode("latin-1", "replace").decode("latin-1")


def insurance_pdf(path, vault, owner=""):
    """The insurance inventory as a PDF.  Written with fpdf2 (pure Python), so it works the same on every system and in the browser."""
    from fpdf import FPDF
    from fpdf.enums import Align
    rows = tools.inventory_rows(vault)
    total_copies = sum(r["qty"] for r in rows)
    total_value = sum((r["price_usd"] or 0) * r["qty"] for r in rows)
    unpriced = sum(1 for r in rows if r["price_usd"] is None)
    pdf = FPDF(orientation="L", unit="mm", format="A4")
    pdf.set_title("Collection inventory")
    pdf.set_auto_page_break(True, 12)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 9, "Collection inventory for insurance", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 6, _latin(f"{owner + ' - ' if owner else ''}{datetime.date.today():%d %B %Y}  -  Pokemon Card Vault"), new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 6, _latin(f"{total_copies:,} cards ({len(rows):,} lines) - estimated market value {currency.fmt(total_value)} ({currency.code()})"
                          + (f" - {unpriced} lines have no price" if unpriced else "")), new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "I", 8)
    pdf.multi_cell(0, 4, "Values are market estimates taken from public prices on the date above. They are not an appraisal; graded and rare cards can sell for more or less.",
                   new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)
    pdf.set_font("Helvetica", "", 8)
    with pdf.table(col_widths=(62, 48, 10, 10, 34, 38, 22, 24), text_align=("LEFT", "LEFT", "CENTER", "CENTER", "LEFT", "LEFT", "RIGHT", "RIGHT"),
                   line_height=4.5, padding=0.8) as table:
        head = table.row()
        for h in ("Card", "Set", "#", "Qty", "Condition / grade", "Where", "Each", "Total"):
            head.cell(h, style=None)
        for r in rows:
            each = r["price_usd"]
            extra = " - ".join(x for x in (r["variant"], r["edition"], r["cert"] and f"cert {r['cert']}") if x)
            row = table.row()
            for v in (r["name"] + (f" ({extra})" if extra else ""), r["set_name"] or "", str(r["local_id"]), str(r["qty"]), _grade(r), r["location"] or "",
                      currency.fmt(each), currency.fmt(None if each is None else each * r["qty"])):
                row.cell(_latin(v))
    pdf.ln(2)
    pdf.set_font("Helvetica", "B", 10)
    pdf.cell(0, 6, _latin(f"Total: {currency.fmt(total_value)}"), align=Align.R)
    pdf.output(path)
    return len(rows)


def full_export_xlsx(path, vault):
    """Everything about every copy, plus wishlist and spending, in a spreadsheet (opens in Excel and Google Sheets)."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    head_fill = PatternFill("solid", fgColor="DDE7F5")

    def sheet(ws, headers, rows, money_cols=()):
        ws.append(headers)
        for c in ws[1]:
            c.font, c.fill = Font(bold=True), head_fill
        for r in rows:
            ws.append(r)
        for i, h in enumerate(headers, 1):
            width = max([len(str(h))] + [len(str(r[i - 1])) for r in rows[:400] if r[i - 1] is not None]) + 2
            ws.column_dimensions[get_column_letter(i)].width = min(width, 48)
            if i in money_cols:
                for row in ws.iter_rows(min_row=2, min_col=i, max_col=i):
                    row[0].number_format = f'"{currency.symbol().strip()}"#,##0.00'
        ws.freeze_panes = "A2"

    ws = wb.active
    ws.title = "Collection"
    lots = tools.inventory_rows(vault)
    r_each = lambda r: None if r["price_usd"] is None else round(currency.convert(r["price_usd"]), 2)
    sheet(ws, ["Card", "Set", "Series", "#", "Rarity", "Variant", "Edition", "Language", "Condition", "Graded", "Grading company", "Grade", "Cert #",
               "Qty", "Location", f"Paid each ({currency.code()})", f"Market each ({currency.code()})", f"Market total ({currency.code()})",
               f"Gain ({currency.code()})", "Notes", "Added", "Card id"],
          [[r["name"], r["set_name"], r["serie"], r["local_id"], r["rarity"], r["variant"], r["edition"], r["language"], r["condition"],
            "yes" if r["graded"] else "", r["grade_company"], r["grade"], r["cert"], r["qty"], r["location"],
            None if r["purchase_price"] is None else round(currency.convert(r["purchase_price"]), 2), r_each(r),
            None if r["price_usd"] is None else round(currency.convert(r["price_usd"] * r["qty"]), 2),
            None if (r["price_usd"] is None or r["purchase_price"] is None) else round(currency.convert((r["price_usd"] - r["purchase_price"]) * r["qty"]), 2),
            r["notes"], (r["added"] or "")[:10], r["card_id"]] for r in lots], money_cols=(16, 17, 18, 19))
    wl = wb.create_sheet("Wishlist")
    wrows = []
    for cid in sorted(vault.wishlist_ids()):
        c = vault.card_light(cid)
        if c:
            wrows.append([c["name"], c["set_name"], c["local_id"], None if c["price_usd"] is None else round(currency.convert(c["price_usd"]), 2), cid])
    sheet(wl, ["Card", "Set", "#", f"Market ({currency.code()})", "Card id"], wrows, money_cols=(4,))
    sp = wb.create_sheet("Spending")
    sheet(sp, ["Date", f"Amount ({currency.code()})", "Category", "Note"],
          [[r["day"], round(currency.convert(r["amount_usd"]), 2), r["category"], r["note"]] for r in vault.spending_rows()], money_cols=(2,))
    wb.save(path)
    return len(lots)
