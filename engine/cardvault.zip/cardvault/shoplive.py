"""The toys another shop lists NOW: a retailer's own public product feed (<shop>/products.json), read for one toy line.

A maker's shop lists only what it sells itself, but the toys made for a convention or a retailer ('Plastic Empire Exclusive', '[Toy Temple Exclusive]') and the ones made together with a partner (Handmade by
Robots, an artist's own shop) are sold - and photographed, priced and dated - by those shops.  Their feeds give the title, price, pictures and the day the shop first listed each product; this module reads them,
one page of 250 at a time with a pause, and keeps only the products whose title, vendor, tags or address match the toy line.  The same rules as for the old pages (retiredtoys.py) decide what becomes an entry."""
import json
import re
import time

from . import sync

PAUSE = 0.7                                                    # seconds between two pages of one shop
MAX_PAGES = 40                                                 # 250 products each: a shop with more than 10,000 products is not read to the end


def _fetch(url):
    raw = sync._get(url, as_json=False)
    try:
        return json.loads(raw.decode("utf-8")) if raw else {}
    except ValueError:
        return {}


def matches(product, pattern):
    """Is the product about the toy line?  The pattern is looked for in its address, title, maker (vendor) and tags."""
    text = " ".join([f"/products/{product.get('handle') or ''}", product.get("title") or "", product.get("vendor") or "", " ".join(product.get("tags") or [])])
    return bool(re.search(pattern, text, re.I))


def first_day(product):
    """The product with `published_at` set to the day the shop first knew it: the earlier of when it was made and when it went on sale (a shop that lists its whole range again republishes every product)."""
    days = [d for d in (product.get("created_at"), product.get("published_at")) if d]
    return dict(product, published_at=min(days)) if days else product


def products(host, pattern, get=None, pause=None, cancel=None, progress=None):
    """The products of `host` that match `pattern`, newest first.  A shop that is away (or stops answering half-way) gives what was read so far: the next run reads it again, and nothing that
    an earlier run kept is ever removed because of a short read."""
    get = get or _fetch
    pause = PAUSE if pause is None else pause
    out = []
    for page in range(1, MAX_PAGES + 1):
        if cancel is not None and cancel.is_set():
            break
        if progress:
            progress(f"Reading {host}…", page, MAX_PAGES)
        try:
            batch = (get(f"https://{host}/products.json?limit=250&page={page}") or {}).get("products") or []
        except RuntimeError:
            break
        if not batch:
            break
        out += [first_day(p) for p in batch if matches(p, pattern)]
        if len(batch) < 250:
            break
        if pause:
            time.sleep(pause)
    return sorted(out, key=lambda p: p.get("published_at") or "", reverse=True)
