"""McDonald's toys: the sidebar filters, read from each toy's stated facts (raw ext written by cardvault/mcdonalds.py).  Used by cardvault/gamefacets.py.
A filter value is always a word the source states; a toy whose source states none has no value in that filter."""


def decade(e, c):
    y = str(e.get("Year") or "")
    return ["%s0s" % y[:3]] if len(y) == 4 and y.isdigit() else []


def _one(key):
    return lambda e, c: [str(e[key]).strip()] if e.get(key) else []


FACETS = [("year", "Year", _one("Year")), ("decade", "Decade", decade), ("country", "Country", _one("Country")), ("promotion", "Promotion", _one("Promotion")),
          ("brand", "Collab / brand", _one("Collab / brand")), ("group", "Group in the set", _one("Group in the set"))]
