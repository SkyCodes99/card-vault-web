"""Market indexes (roadmap "Market indexes"): one value line for a whole game, an era (a set's series) or one set, like a stock index.  The method is in docs/market_indexes.md.

Built once a day by tools/market_index.py from the TCGplayer market-price archive the app already keeps (no new source) and published to Card Data, one small file per game:

    <carddata>/catalog/marketindex/<game>.json.gz
    {"v": 1, "game": "pokemon", "built": "2026-11-12", "rules": {...},
     "days": ["2024-02-11", ...],                                    the same day grid as the per-set history files (sethistory.keep_day)
     "all": {"s": 0, "v": [1000, 1003, null, ...], "n": [812, ...]},   the whole game: index x 10 (base 100 = 1000) from day s on; null = too few cards that day (no point drawn)
     "eras": {"Scarlet & Violet": {...}}, "sets": {"sv1": {...}}}

The app keeps that file in the game's folder and answers from it at once; it never works an index out itself (tools/market_index.py does, the night before)."""
import datetime
import gzip
import json
import math
import os
import threading
import time

from .marketmovers import MIN_PRICE

FORMAT = 1
FOLDER = "marketindex"      # under Card Data's catalog/
BASE = 100.0                # the index on its first day
FLOOR = MIN_PRICE           # dollars, at both ends of a step: bulk commons sit under it and never move the index (Market movers' own floor)
MIN_CARDS = 10              # fewer cards priced on both days of a step -> no point that day (the line has a gap rather than a guess)
TRIM = 0.10                 # the share of the day's price changes cut from EACH end before averaging (at least one card each end)
MAX_STEP = math.log(2)      # one card's change in one step counts as at most x2 or /2


def rules():
    return {"base": BASE, "floor": FLOOR, "minCards": MIN_CARDS, "trim": TRIM, "maxStep": 2}


# ------------------------------------------------------------------------------------------------ the method
def step(pairs):
    """One step of the index from (old price, new price) pairs of the same cards on two days.  -> (ratio or None, cards counted).
    Counts only cards at or over FLOOR on both days; each change is capped at x2 / /2; the biggest and smallest TRIM share are cut; the rest averaged as logs (a geometric mean)."""
    lrs = sorted(max(-MAX_STEP, min(MAX_STEP, math.log(b / a))) for a, b in pairs if a is not None and b is not None and a >= FLOOR and b >= FLOOR)
    n = len(lrs)
    if n < MIN_CARDS:
        return None, n
    k = max(1, int(n * TRIM))
    core = lrs[k:n - k]
    return math.exp(math.fsum(core) / len(core)), n


def chain(days, prices):
    """The index of one group of cards.  days = the day grid (sorted); prices = {card: [usd or None per day]}.
    -> [(day, level or None, cards counted)].  The first day with MIN_CARDS cards at or over FLOOR is BASE; each later day is the last drawn day's level times step() between the two.
    A day with too few cards draws no point and the next day is compared with the last drawn day, so a gap in the data never bends the line.  A card that enters or leaves
    only changes which cards are compared, never the level (only price CHANGES are counted)."""
    out, anchor, level = [], None, None
    cols = list(prices.values())
    for i, d in enumerate(days):
        if anchor is None:
            n = sum(1 for p in cols if p[i] is not None and p[i] >= FLOOR)
            if n >= MIN_CARDS:
                anchor, level = i, BASE
                out.append((d, BASE, n))
            else:
                out.append((d, None, n))
            continue
        r, n = step((p[anchor], p[i]) for p in cols)
        if r is None:
            out.append((d, None, n))
            continue
        level *= r
        anchor = i
        out.append((d, level, n))
    return out


def pack(points):
    """chain() -> the stored form {"s": first day index, "v": [index x 10], "n": [cards]} (None when the group never reached MIN_CARDS)."""
    first = next((i for i, (_d, lv, _n) in enumerate(points) if lv is not None), None)
    if first is None:
        return None
    rest = points[first:]
    return {"s": first, "v": [None if lv is None else round(lv * 10) for _d, lv, _n in rest], "n": [n for _d, _lv, n in rest]}


def build_doc(game_slug, days, prices, groups, eras):
    """The whole file for one game.  prices = {row key: [usd or None per day]}; groups = {set id: [row keys]}; eras = {era name: [set ids]}."""
    def of(keys):
        return pack(chain(days, {k: prices[k] for k in keys if k in prices}))
    sets = {sid: s for sid, s in ((sid, of(keys)) for sid, keys in sorted(groups.items())) if s}
    era_docs = {}
    for name, sids in sorted(eras.items()):
        s = of([k for sid in sids for k in groups.get(sid, ())])
        if s:
            era_docs[name] = s
    return {"v": FORMAT, "game": game_slug, "built": days[-1] if days else "", "rules": rules(), "days": list(days),
            "all": of(list(prices)), "eras": era_docs, "sets": sets}


def encode(doc):
    """Compact JSON, gzip with no time stamp (the same index gives the same bytes, so an unchanged file is not uploaded again)."""
    return gzip.compress(json.dumps(doc, separators=(",", ":")).encode("utf-8"), 9, mtime=0)


def decode(raw):
    raw = bytes(raw)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)          # (the web server may already have unzipped it in transit)
    if not isinstance(doc, dict) or not isinstance(doc.get("days"), list) or not isinstance(doc.get("sets"), dict):
        raise ValueError("not a market index file")
    return doc


def points(doc, scope="game", key=None):
    """[{"day", "v", "n"}] of one line from a file: scope 'game', 'era' (key = era name) or 'set' (key = set id).  Days with no point are left out."""
    doc = doc or {}
    s = doc.get("all") if scope == "game" else (doc.get("eras" if scope == "era" else "sets") or {}).get(str(key or ""))
    if not s:
        return []
    days, i0 = doc.get("days") or [], int(s.get("s") or 0)
    return [{"day": days[i0 + j], "v": v / 10, "n": n} for j, (v, n) in enumerate(zip(s.get("v") or (), s.get("n") or ())) if v is not None and i0 + j < len(days)]


def window(pts, since=None, max_points=0):
    """The points from day `since` on, thinned evenly to at most max_points (the newest point always kept).  Reading only: nothing is worked out again."""
    if since:
        pts = [p for p in pts if p["day"] >= since]
    if max_points and len(pts) > max_points:
        step_ = len(pts) / max_points
        keep = sorted({int(i * step_) for i in range(max_points)} | {len(pts) - 1})
        pts = [pts[i] for i in keep]
    return pts


# ------------------------------------------------------------------------------------------------ the app side
_lock = threading.Lock()
_busy = set()               # games whose file is being fetched in the background now
_DOCS = {}                  # path -> (mtime, doc): a file is read once, not on every question
_failed = {}                # game -> time.monotonic() of a fetch that brought nothing (offline, Card Data down): not tried again for RETRY_AFTER
RETRY_AFTER = 600


def _path(svc, game):
    from .db import game_dir
    return os.path.join(game_dir(svc.cfg["data_dir"], game), FOLDER + ".json.gz")


def _fetch(svc, game, get=None):
    """Download the game's file into its folder.  -> True when one arrived.  A game Card Data has no file for leaves a marker (asked again tomorrow)."""
    from . import carddata, sync
    from .tcggames import data_slug
    get = get or (lambda u: sync._get(u, as_json=False, tries=2))
    path = _path(svc, game)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    answered = False
    for base in carddata.bases(svc, "catalog"):
        try:
            raw = get(f"{base}/{FOLDER}/{data_slug(game)}.json.gz")
        except Exception:  # noqa: BLE001 - the next place (none answering: asked again next time)
            continue
        answered = True
        if not raw:
            continue
        try:
            decode(raw)
        except (OSError, ValueError):
            continue
        with open(path + ".part", "wb") as f:
            f.write(bytes(raw))
        os.replace(path + ".part", path)
        return True
    if answered:
        with open(path + ".none", "w", encoding="utf-8") as f:
            f.write(datetime.date.today().isoformat())
    return False


def _try(svc, game, get=None):
    """_fetch, remembering a try that brought nothing so the screens asking every second do not start a new download each time (asked again after RETRY_AFTER)."""
    try:
        ok = _fetch(svc, game, get)
    except Exception:  # noqa: BLE001 - counted as a failed try
        ok = False
    if ok:
        _failed.pop(game, None)
    else:
        _failed[game] = time.monotonic()
    return ok


def cached(svc, game):
    """The game's file as kept on this device (read once per change), or None."""
    path = _path(svc, game)
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return None
    hit = _DOCS.get(path)
    if hit and hit[0] == mtime:
        return hit[1]
    try:
        with open(path, "rb") as f:
            doc = decode(f.read())
    except (OSError, ValueError):
        return None
    _DOCS[path] = (mtime, doc)
    return doc


def for_game(svc, game, get=None, inline=None):
    """-> (doc or None, pending).  Answers from the kept file at once; a missing or old one is fetched in the background (pending=True: ask again shortly).
    In the browser (no threads) the small file is fetched right here, inside the engine's own worker, so the screen still never waits on it."""
    from . import sethistory
    from .runtime import INLINE
    inline = INLINE if inline is None else inline
    path = _path(svc, game)
    if sethistory._fresh(path) or not svc.cfg.get("auto_prices", True) or time.monotonic() - _failed.get(game, -RETRY_AFTER) < RETRY_AFTER:
        return cached(svc, game), False
    if inline:
        _try(svc, game, get)
        return cached(svc, game), False
    with _lock:
        if game in _busy:
            return cached(svc, game), True
        _busy.add(game)

    def run():
        try:
            _try(svc, game, get)
        finally:
            with _lock:
                _busy.discard(game)

    threading.Thread(target=run, name="marketindex-fetch", daemon=True).start()
    return cached(svc, game), True
