"""Union Arena decklists as plain text: one "4 Card name SLG-1-035" line per card number (the deck rules treat each card number as its own card, so two cards sharing a name stay apart).
Pasted lines may leave the number out (then the name decides) or carry the full 'UE17BT/SLG-1-035'.  Action Point cards are lines like any other."""
import re

from . import decklookup
from .deckcards_tcg import ua_number

_LINE = re.compile(r"^\s*(\d{1,2})\s*[xX×]?\s+(.+?)\s*$")
_TAIL = re.compile(r"^(.*?)\s+((?:[A-Z0-9]+/)?[A-Z0-9]+-\d+-[A-Z0-9]+)$", re.I)          # '... SLG-1-035' or '... UE17BT/SLG-1-035'


def export(deck, info):
    merged = {}
    for cid, n in deck.items():
        c = info.get(cid)
        if c:
            k = (c["section"] == "Action Points", c["name"], ua_number(c.get("number")))
            merged[k] = merged.get(k, 0) + n
    return "\n".join(f"{n} {name} {num}".rstrip() for (_, name, num), n in sorted(merged.items(), key=lambda x: (x[0][0], -x[1], x[0][1], x[0][2]))) + "\n"


def _by_number(v, name, number):
    """The card with that card number (any print of it: 'UE17BT/SLG-1-035' = 'SLG-1-035'), the one with the line's name first."""
    num = ua_number(number)
    rows = v.conn.execute(decklookup.SELECT + "WHERE UPPER(c.local_id)=? OR UPPER(c.local_id) LIKE ?", (num, "%/" + num)).fetchall()
    same = [r for r in rows if (r["name"] or "").lower() == name.lower()]
    return decklookup.pick(same or rows)


def _find(v, text):
    t = _TAIL.match(text)
    if t:
        cid = _by_number(v, t.group(1), t.group(2))
        if cid:
            return cid
    return decklookup.by_name(v, text) or (decklookup.by_name(v, t.group(1)) if t else None)


def parse(v, text):
    cards, unmatched, count = {}, [], 0
    for ln in (text or "").splitlines():
        m = _LINE.match(ln.strip())
        if not m:
            continue
        count += 1
        cid = _find(v, m.group(2))
        if cid:
            cards[cid] = cards.get(cid, 0) + int(m.group(1))
        else:
            unmatched.append(ln.strip())
    return {"cards": cards, "unmatched": unmatched, "lines": count}
