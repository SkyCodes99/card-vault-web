"""Price alerts that run by themselves after the daily prices (roadmap "Price alerts").  Three kinds of rule, all read-only on the prices:
  target  a price the owner set on one card or sealed product (the "Price alert" button in the item drawer = the account's price_alerts list)  - below / above $X
  label   a wishlist label with a price: every card on the wishlist with that label that is not owned yet, at or below $X
  move    one default rule for the cards the owner HAS: up or down by at least pct % over 1 or 7 days, ignoring cards under `min` dollars at either end (default +-25 % / 7 days / $1)
Prices: the one price function (pricepick.price_for) for targets and labels; the saved daily history (the same one Market movers reads) for moves.  eBay asking prices are never used.
Each alert fires ONCE per crossing: a rule that is true now and was not true at the last check fires; it stays quiet while it stays true and is armed again when it stops being true.
Where the owner sees them: the bell in the top bar (notify.local -> inbox below) and Settings > Price alerts.
Everything is kept in one account setting "price_watch" (it follows the account to every device):
  {"on": true, "pct": 25, "days": 7, "min": 1.0, "labels": {label id: usd}, "armed": [keys true at the last check], "inbox": [alert, ...newest first]}"""
import datetime
import json

from . import marketmovers, pricepick, wishlabels
from .db import new_uuid

KEY = "price_watch"
DEFAULTS = {"on": True, "pct": 25.0, "days": 7, "min": 1.0}
DAYS = (1, 7)
INBOX_MAX, INBOX_DAYS = 60, 45
GROUP_OVER = 5                     # more than this many alerts of one kind in one check become ONE line (a first check must not flood the bell)


# ----------------------------------------------------------------------------------------------- the saved setting
def _num(x, lo, hi, default):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return default if v != v else max(lo, min(hi, v))


def normalize(raw):
    d = raw if isinstance(raw, dict) else {}
    labels = {}
    for k, x in (d.get("labels") or {}).items() if isinstance(d.get("labels"), dict) else ():
        v = _num(x, 0, 1e7, 0)
        if v > 0:
            labels[str(k)] = round(v, 2)
    return {"on": bool(d.get("on", DEFAULTS["on"])), "pct": round(_num(d.get("pct"), 1, 1000, DEFAULTS["pct"]), 1),
            "days": 1 if str(d.get("days")) == "1" else 7, "min": round(_num(d.get("min"), 0, 1e6, DEFAULTS["min"]), 2),
            "labels": labels, "armed": [str(x) for x in d.get("armed") or [] if isinstance(x, str)][:5000],
            "inbox": [a for a in d.get("inbox") or [] if isinstance(a, dict) and a.get("id")][:INBOX_MAX]}


def load(svc):
    try:
        return normalize(json.loads(svc.pget(KEY) or "{}"))
    except ValueError:
        return normalize({})


def save(svc, d):
    svc.pset(KEY, json.dumps(d, ensure_ascii=False))


# ----------------------------------------------------------------------------------------------- the rules (pure)
def crossings(now_true, armed, game):
    """now_true = {key: event} of every rule that is true at this check, armed = keys that were true at the last one.
    -> (events to announce, the new armed list): a rule fires only when it was not true before; another game's keys (they start with its id + '|') are carried over untouched."""
    old = set(armed)
    fired = [{**e, "key": k} for k, e in now_true.items() if k not in old]
    keep = [k for k in old if not k.startswith(game + "|")] + list(now_true)
    return fired, keep


def target_hit(direction, price, target):
    return price is not None and ((direction == "below" and price <= target) or (direction == "above" and price >= target))


def move_event(old, new, pct_min, min_price):
    """(old usd, new usd) -> signed % change when it is big enough and neither end is under min_price, else None."""
    if old is None or new is None or old < min_price or new < min_price or old <= 0:
        return None
    pct = 100.0 * (new - old) / old
    return round(pct, 1) if abs(pct) >= pct_min else None


def group(events, over=GROUP_OVER):
    """Alerts of one kind: up to `over` stay single lines; more become one summary line (the single ones are still in `items`)."""
    by = {}
    for e in events:
        by.setdefault(e["kind"], []).append(e)
    out = []
    for kind, es in by.items():
        if len(es) <= over:
            out += es
        else:
            word = {"label": "wishlist cards are at or below their price", "target": "of your price targets were reached", "move": "cards you own moved a lot"}[kind]
            out.append({"kind": kind, "key": f"{kind}|many", "title": f"{len(es)} {word}", "text": ", ".join(e["name"] for e in es[:3]) + "...", "usd": [], "card": "", "many": len(es)})
    return out


# ----------------------------------------------------------------------------------------------- the data
def _cards(v, ids):
    """{card id: (name, price_usd, price_kind)} from the card list."""
    out, ids = {}, list(dict.fromkeys(ids))
    for i in range(0, len(ids), 500):
        c = ids[i:i + 500]
        for r in v.conn.execute(f"SELECT id, name, price_usd, price_kind FROM cards WHERE id IN ({','.join('?' * len(c))})", c):
            out[r[0]] = (r[1], r[2], r[3])
    return out


def _price(v, cid, row):
    """The one price function; None for a card with no price or an eBay asking price (never used)."""
    if row is None or pricepick.is_ebay(row[2]):
        return None
    return pricepick.price_for(v, cid, row[1])


def conditions(svc, today=None):
    """{key: event} for every rule that is true right now in the open game."""
    from . import sealedprice
    from .webapi import alerts
    v, game, cfg = svc.vault, svc.vault.game, load(svc)
    out, targeted = {}, set()
    for a in alerts._all(svc):                                                        # 1. targets (the Price alert button): cards and sealed products
        if a.get("game") != game:
            continue
        if a["type"] == "card":
            rows = _cards(v, [a["key"]])
            now = _price(v, a["key"], rows.get(a["key"]))
        else:
            p = sealedprice.price_for(v, a["key"])
            now = p["price"] if p else None
        if a["dir"] == "below" and a["type"] == "card":
            targeted.add(a["key"])
        if target_hit(a["dir"], now, a["price"]):
            word = "down to" if a["dir"] == "below" else "up to"
            out[f"{game}|t|{a['id']}:{a['price']}"] = {"kind": "target", "title": f"Price alert: {a['name']}", "text": f"Now {{0}} - you wanted it {word} {{1}}",
                                                       "usd": [now, a["price"]], "card": a["key"] if a["type"] == "card" else "", "name": a["name"]}
    labs, assign = wishlabels.of_game(svc, game)                                          # 2. wishlist labels with a price
    if cfg["labels"] and assign:
        wish = v.wishlist_ids()
        ids = [c for c, lid in assign.items() if lid in cfg["labels"] and c in wish and c not in targeted]
        have = {r[0] for r in v.conn.execute("SELECT DISTINCT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, game))}
        rows = _cards(v, ids)
        name = {x["id"]: x["name"] for x in labs}
        for cid in ids:
            if cid in have:
                continue
            now, lim = _price(v, cid, rows.get(cid)), cfg["labels"][assign[cid]]
            if now is not None and now <= lim:
                out[f"{game}|l|{cid}"] = {"kind": "label", "title": f"Wishlist: {rows[cid][0]} is down", "text": f"Now {{0}} - at or below {{1}} ({name.get(assign[cid], 'label')})", "usd": [now, lim], "card": cid, "name": rows[cid][0]}
    if cfg["on"] and marketmovers._main_price_only(v, game):                                # 3. the default move rule on the cards I own (main price history only)
        today = today or datetime.date.today()
        owned = marketmovers.owned_by_game(v).get(game, {})
        if owned:
            days = cfg["days"]
            cutoff = marketmovers.window_start(days, today)
            info = marketmovers._card_info(game, v.data_dir, owned)
            ends = marketmovers._prices(v.conn, game, list(owned), [marketmovers.FAR_FUTURE, cutoff])          # (newest price, newest on or before the cutoff)
            for cid in owned:
                c, (latest, base) = info.get(cid), ends[cid]
                if not c or pricepick.is_ebay(c[3]) or not latest or not base:
                    continue
                if latest[0] <= cutoff or latest[0] <= base[0]:
                    continue
                pct = move_event(base[1], latest[1], cfg["pct"], cfg["min"])
                if pct is not None:
                    up = pct > 0
                    out[f"{game}|m|{cid}|{days}|{'up' if up else 'down'}"] = {"kind": "move", "title": f"{c[0]} {'jumped' if up else 'fell'} {abs(pct):g}%",
                                                                              "text": f"{{0}} to {{1}} in {days} day{'s' if days != 1 else ''}", "usd": [base[1], latest[1]], "card": cid, "name": c[0], "pct": pct}
    return out


def check(svc, today=None):
    """Run the rules once (after the day's prices are in).  -> how many alerts were added to the inbox.  Does nothing when alerts are off for rules that need the switch (targets and labels
    are things the owner set by hand, so they always work; the default move rule has the switch)."""
    if svc.vault is None:
        return 0
    cfg, day = load(svc), (today or datetime.date.today()).isoformat()
    now_true = conditions(svc, today)
    fired, armed = crossings(now_true, cfg["armed"], svc.vault.game)
    cut = ((today or datetime.date.today()) - datetime.timedelta(days=INBOX_DAYS)).isoformat()
    inbox = [a for a in cfg["inbox"] if a.get("day", day) >= cut]
    new = [{"id": f"pw:{new_uuid()[:8]}", "day": day, **e} for e in group(fired)]          # (an id is made once and kept: the bell remembers what was read by it)
    cfg["armed"], cfg["inbox"] = armed, (new + inbox)[:INBOX_MAX]
    save(svc, cfg)
    return len(new)
