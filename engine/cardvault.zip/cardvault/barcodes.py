"""Barcodes (UPC / EAN) of the products in each game's card list, so a scanned box, toy or game is found at once.
Where they come from: a shop's own product page (ShopifyToyProvider reads variants[].barcode on every nightly / weekly run) and the TCGplayer product data (UPC / GTIN) already stored with an entry.
A code is kept ONE way - digits only, UPC-A written as EAN-13 with a leading 0 - so 012345678905 and 0012345678905 find the same item.  Table `barcodes` lives in each game's cards.db."""
import json
import re
import sqlite3

SCHEMA = ("CREATE TABLE IF NOT EXISTS barcodes(code TEXT NOT NULL, card_id TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'card', PRIMARY KEY(code, card_id)); "
          "CREATE INDEX IF NOT EXISTS barcodes_card ON barcodes(card_id)")
NO_CODE = "No item has that barcode yet. Barcodes are collected during the weekly shop check, so it may appear later - or search by name."
BAD_CODE = "That does not look like a barcode. Check the digits (a box barcode has 8, 12 or 13)."


def _check_ok(d):
    """The last digit of a GTIN is a check digit: 3,1,3,1... from the right of the others."""
    body, last = d[:-1], int(d[-1])
    return (10 - sum(int(x) * (3 if i % 2 == 0 else 1) for i, x in enumerate(reversed(body))) % 10) % 10 == last


def canon(code):
    """-> the one form a barcode is stored and searched in ('' when it is not a barcode): digits only, 12 digits (UPC-A) get a leading 0, a wrong check digit is refused."""
    d = re.sub(r"\D", "", str(code or ""))
    if len(d) == 12:
        d = "0" + d
    return d if len(d) in (8, 13, 14) and _check_ok(d) else ""


def ensure(conn):
    conn.executescript(SCHEMA)


def put(conn, card_id, codes, kind="card", keep_old=False):
    """Remember the barcodes of one item (replaces what an earlier run stored for it, unless keep_old).  -> how many were kept."""
    ensure(conn)
    keep = sorted({c for c in (canon(x) for x in codes or ()) if c})
    if not keep_old:
        conn.execute("DELETE FROM barcodes WHERE card_id=?", (card_id,))
    conn.executemany("INSERT OR IGNORE INTO barcodes(code, card_id, kind) VALUES(?,?,?)", [(c, card_id, kind) for c in keep])
    return len(keep)


def shop_codes(product):
    """The barcodes a Shopify product lists on its variants (already part of the products.json page: no extra request)."""
    return [v.get("barcode") for v in product.get("variants") or [] if v.get("barcode")]


def ext_codes(ext):
    """The UPC / GTIN of TCGplayer's product data."""
    return [ext.get("UPC"), ext.get("GTIN")]


def backfill(conn):
    """Barcodes already stored with the entries (the UPC / GTIN TCGplayer gave a Funko Pop! or an accessory), copied into the table once.  -> number of items given a code."""
    ensure(conn)
    if conn.execute("SELECT 1 FROM meta WHERE key='barcodes_backfilled'").fetchone():
        return 0
    n = 0
    for cid, raw in conn.execute("SELECT id, raw FROM cards WHERE raw LIKE '%\"UPC\"%' OR raw LIKE '%\"GTIN\"%'").fetchall():
        try:
            ext = (json.loads(raw) or {}).get("ext") or {}
        except (TypeError, ValueError):
            continue
        n += 1 if put(conn, cid, ext_codes(ext)) else 0
    conn.execute("INSERT OR REPLACE INTO meta VALUES('barcodes_backfilled', '1')")
    conn.commit()
    return n


def prepare(path):
    """Make one game's list ready for barcode lookups (table + the one-time copy of codes it already holds).  Never raises: a list that cannot be written is simply searched as it is."""
    try:
        c = sqlite3.connect(path, timeout=10)
        try:
            backfill(c)
        finally:
            c.close()
    except sqlite3.Error:
        pass


def _picture(gid, base):
    from .db import picture_url
    return (picture_url(base, "low") if gid.startswith("pokemon") else base) if base else ""


def lookup(game_lists, code):
    """game_lists = [(game id, game name, path of its cards.db)].  -> {code, results: [{game, gameName, shelf, shelfName, id, type, set, name, number, rarity, img, price}], message}."""
    from . import shelves
    shown = dict(shelves.SHELVES)
    c = canon(code)
    if not c:
        return {"code": re.sub(r"\D", "", str(code or "")), "results": [], "message": BAD_CODE}
    out = []
    for gid, name, path in game_lists:
        try:
            db = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
        except sqlite3.Error:
            continue
        try:
            shelf = shelves.place_of(gid)[0]
            for cid, kind in db.execute("SELECT card_id, kind FROM barcodes WHERE code=?", (c,)).fetchall():
                if kind == "sealed":
                    r = db.execute("SELECT id, set_name, name, image_base, price_usd, kind FROM sealed_products WHERE id=?", (cid,)).fetchone()
                    row = r and {"id": r[0], "type": "sealed", "set": r[1] or "", "name": r[2], "number": "", "rarity": r[5] or "Sealed product", "img": (r[3] or "").replace("_200w", "_400w"), "price": r[4]}
                else:
                    r = db.execute("SELECT c.id, s.name, c.name, c.local_id, c.rarity, c.image_base, c.price_usd FROM cards c JOIN sets s ON s.id=c.set_id WHERE c.id=?", (cid,)).fetchone()
                    row = r and {"id": r[0], "set": r[1] or "", "name": r[2], "number": r[3] or "", "rarity": r[4] or "", "img": _picture(gid, r[5]), "price": r[6]}
                if row:
                    out.append(dict(row, game=gid, gameName=name, shelf=shelf, shelfName=shown.get(shelf, "")))
        except sqlite3.Error:
            continue                                                  # (this list has no barcodes table yet)
        finally:
            db.close()
    return {"code": c, "results": out, "message": "" if out else NO_CODE}
