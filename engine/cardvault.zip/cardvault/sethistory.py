"""Per-set market price history on Card Data (owner 2026-11-11): graphs and 7/30/90-day stats for cards you do NOT own or wish for.

Your own saved price history only covers the cards you track.  Card Data also keeps one small file per set, built every day by tools/set_history.py from the tcgcsv
market-price archive (TCGplayer market prices only - never eBay asking prices):

    <carddata>/catalog/pricehist/<game>/<file name of the set>.json.gz
    {"v": 1, "game": "pokemon", "set": "sv1", "built": "2026-11-10", "daily": 90,
     "days": ["2024-02-11", ..., "2026-11-10"],          every day of the last 90, one day a week (Sunday) before that
     "cards": {"sv1-1": [0.12, null, ...], ...}}         one price per day above (null: no price that day)

The app reads it only when a card has no history of its own (card.setHistory): from its own cache at once, and fetched in the background when that is missing or old,
so opening a card never waits on it."""
import datetime
import gzip
import hashlib
import json
import os
import re
import threading

FORMAT = 1
DAILY_DAYS = 90             # every day of the last 90 days ...
WEEKDAY = 6                 # ... and one day a week (Sunday) before that, back to the start of the archive (2024-02)
FOLDER = "pricehist"        # under Card Data's catalog/


def fname(set_id):
    """The file name of a set's history file (a set id with characters a web path cannot carry gets a short hash so two sets never share a file)."""
    s = str(set_id or "")
    if re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", s) and not s.startswith("."):
        return s + ".json.gz"
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", s)[:60].strip("_") + "-" + hashlib.sha1(s.encode("utf-8")).hexdigest()[:8] + ".json.gz"


def keep_day(day, newest):
    """Is this archive day kept in the file?  (every day of the last DAILY_DAYS before `newest`, then one a week)"""
    d = datetime.date.fromisoformat(day)
    return (newest - d).days < DAILY_DAYS or d.weekday() == WEEKDAY


def encode(doc):
    """The file's bytes: compact JSON, gzip with no time stamp (the same prices give the same bytes, so an unchanged set is not uploaded again)."""
    return gzip.compress(json.dumps(doc, separators=(",", ":")).encode("utf-8"), 9, mtime=0)


def decode(raw):
    raw = bytes(raw)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)          # (the web server may already have unzipped it in transit)
    if not isinstance(doc, dict) or not isinstance(doc.get("days"), list) or not isinstance(doc.get("cards"), dict):
        raise ValueError("not a set price history file")
    return doc


def series(doc, card_id):
    """[{"day", "usd"}] of one card from a set file (empty when the file has no prices for it)."""
    doc = doc or {}
    vals = (doc.get("cards") or {}).get(str(card_id)) or []
    return [{"day": d, "usd": u} for d, u in zip(doc.get("days") or [], vals) if u is not None]


# ------------------------------------------------------------------------------------------------ the app side
_lock = threading.Lock()
_busy = set()               # (game, set) fetches running in the background now


def _cache_path(svc, game, set_id):
    from .db import game_dir
    return os.path.join(game_dir(svc.cfg["data_dir"], game), FOLDER, fname(set_id))


def _url(svc, game):
    from . import carddata
    from .tcggames import data_slug
    return [f"{b}/{FOLDER}/{data_slug(game)}" for b in carddata.bases(svc, "catalog")]


def _fetch(svc, game, set_id, get=None):
    """Download the set's file into the app's cache.  -> True when a file arrived.  A set Card Data has no file for leaves an empty marker (asked again the next day)."""
    from . import sync
    get = get or (lambda u: sync._get(u, as_json=False, tries=2))
    path = _cache_path(svc, game, set_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    answered = False
    for base in _url(svc, game):
        try:
            raw = get(f"{base}/{fname(set_id)}")
        except Exception:  # noqa: BLE001 - the next place (none answering: asked again the next time the card is opened)
            continue
        answered = True
        if not raw:
            continue
        try:
            decode(raw)
        except (OSError, ValueError):
            continue
        try:
            with open(path, "rb") as f:
                same = f.read() == bytes(raw)
        except OSError:
            same = False
        if same:                                                            # the same file as yesterday: only marked as fetched today (the graph built from it is still right)
            os.utime(path)
            return True
        with open(path + ".part", "wb") as f:
            f.write(bytes(raw))
        os.replace(path + ".part", path)
        return True
    if answered:                                                            # no file for this set today: do not ask again until tomorrow
        with open(path + ".none", "w", encoding="utf-8") as f:
            f.write(datetime.date.today().isoformat())
    return False


def _fresh(path):
    """Was the cached file (or the 'nothing there' marker) fetched today?"""
    for p in (path, path + ".none"):
        try:
            if datetime.date.fromtimestamp(os.path.getmtime(p)) == datetime.date.today():
                return True
        except OSError:
            pass
    return False


def cached(svc, game, set_id):
    """The set's file from the app's cache, or None."""
    try:
        with open(_cache_path(svc, game, set_id), "rb") as f:
            return decode(f.read())
    except (OSError, ValueError):
        return None


def for_card(svc, game, set_id, card_id, get=None, inline=None):
    """-> (history [{"day", "usd"}], pending).  Answers from the cache at once; a missing or old file is fetched in the background (pending=True: ask again shortly).
    In the browser (no threads) the small file is fetched right here, inside the engine's own worker, so the screen still never waits on it."""
    from .runtime import INLINE
    inline = INLINE if inline is None else inline
    path = _cache_path(svc, game, set_id)
    doc = cached(svc, game, set_id)
    if _fresh(path):
        return series(doc, card_id), False
    key = (game, str(set_id))
    if inline:
        try:
            _fetch(svc, game, set_id, get)
        except OSError:
            pass
        return series(cached(svc, game, set_id) or doc, card_id), False
    with _lock:
        if key in _busy:
            return series(doc, card_id), True
        _busy.add(key)

    def run():
        try:
            _fetch(svc, game, set_id, get)
        except Exception:  # noqa: BLE001 - asked again the next time the card is opened
            pass
        finally:
            with _lock:
                _busy.discard(key)

    threading.Thread(target=run, name="sethistory-fetch", daemon=True).start()
    return series(doc, card_id), True


# ------------------------------------------------------------------------------------------------ the value graph (valueseries.py)
_PTS = {}                   # file path -> (its mtime, {card id: [(day, usd)]}): only the cards asked for, only the days the price changed (a whole set never stays in memory)


def points_for(svc, game, set_id, card_ids):
    """{card id: [(day, usd)]} of these cards from the set's cached file (nothing when it is not here yet), each kept as the days its price changed."""
    path = _cache_path(svc, game, set_id)
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return {}
    hit = _PTS.get(path)
    if not hit or hit[0] != mtime:
        hit = _PTS[path] = (mtime, {})
    memo = hit[1]
    want = [str(c) for c in card_ids if str(c) not in memo]
    if want:
        doc = cached(svc, game, set_id) or {}
        days, cards = doc.get("days") or [], doc.get("cards") or {}
        for c in want:
            out, last = [], None
            for d, u in zip(days, cards.get(c) or ()):
                if u is not None and u != last:
                    out.append((d, u))
                    last = u
            memo[c] = out
    return {str(c): memo.get(str(c), []) for c in card_ids}


def warm(svc, game, set_ids):
    """Fetch the set files the value graph would use that are missing or old, in the background, one after another.  Never in the browser (the graph must not wait
    on downloads there) and never with automatic price downloads turned off.  The graph picks them up the next time it is worked out."""
    from .runtime import INLINE
    if INLINE or not svc.cfg.get("auto_prices", True):
        return
    todo = []
    with _lock:
        for sid in set_ids:
            key = (game, str(sid))
            if key not in _busy and not _fresh(_cache_path(svc, game, sid)):
                _busy.add(key)
                todo.append(sid)
    if not todo:
        return

    def run():
        for sid in todo:
            try:
                _fetch(svc, game, sid)
            except Exception:  # noqa: BLE001 - asked again the next time the graph is worked out
                pass
            finally:
                with _lock:
                    _busy.discard((game, str(sid)))

    threading.Thread(target=run, name="sethistory-warm", daemon=True).start()


_stamps = {}                # (data folder, game) -> the folder stamp last answered


def folder_stamp(svc, game):
    """Changes when set files have arrived (the kept value graph is then worked out again) - once per round of downloads, not per file: while warm() is still fetching
    this game's files the last stamp is kept (each of a hundred files a day used to throw the graph being worked out away, so a new graph took minutes to appear)."""
    try:
        m = os.path.getmtime(os.path.dirname(_cache_path(svc, game, "x")))
    except OSError:
        m = 0
    key = (svc.cfg.get("data_dir"), game)
    with _lock:
        if key in _stamps and any(b[0] == game for b in _busy):
            return _stamps[key]
        _stamps[key] = m
    return m
