"""Per-set market price history on Card Data (owner 2026-11-11): graphs and 7/30/90-day stats for cards you do NOT own or wish for.

Your own saved price history only covers the cards you track.  Card Data also keeps one small file per set, built every day by tools/set_history.py from the tcgcsv
market-price archive (TCGplayer market prices only - never eBay asking prices):

    <carddata>/catalog/pricehist/<game>/<file name of the set>.json.gz
    {"v": 1, "game": "pokemon", "set": "sv1", "built": "2026-11-10", "daily": 90,
     "days": ["2024-02-11", ..., "2026-11-10"],          every day of the last 90, one day a week (Sunday) before that
     "cards": {"sv1-1": [0.12, null, ...], ...}}         one price per day above (null: no price that day)

The app reads it only when a card has no history of its own (card.setHistory): from its own cache at once, and fetched in the background when that is missing or old,
so opening a card never waits on it."""
import datetime
import gzip
import hashlib
import json
import os
import re
import threading

FORMAT = 1
DAILY_DAYS = 90             # every day of the last 90 days ...
WEEKDAY = 6                 # ... and one day a week (Sunday) before that, back to the start of the archive (2024-02)
FOLDER = "pricehist"        # under Card Data's catalog/


def fname(set_id):
    """The file name of a set's history file (a set id with characters a web path cannot carry gets a short hash so two sets never share a file)."""
    s = str(set_id or "")
    if re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", s) and not s.startswith("."):
        return s + ".json.gz"
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", s)[:60].strip("_") + "-" + hashlib.sha1(s.encode("utf-8")).hexdigest()[:8] + ".json.gz"


def keep_day(day, newest):
    """Is this archive day kept in the file?  (every day of the last DAILY_DAYS before `newest`, then one a week)"""
    d = datetime.date.fromisoformat(day)
    return (newest - d).days < DAILY_DAYS or d.weekday() == WEEKDAY


def encode(doc):
    """The file's bytes: compact JSON, gzip with no time stamp (the same prices give the same bytes, so an unchanged set is not uploaded again)."""
    return gzip.compress(json.dumps(doc, separators=(",", ":")).encode("utf-8"), 9, mtime=0)


def decode(raw):
    raw = bytes(raw)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)          # (the web server may already have unzipped it in transit)
    if not isinstance(doc, dict) or not isinstance(doc.get("days"), list) or not isinstance(doc.get("cards"), dict):
        raise ValueError("not a set price history file")
    return doc


def series(doc, card_id):
    """[{"day", "usd"}] of one card from a set file (empty when the file has no prices for it)."""
    doc = doc or {}
    vals = (doc.get("cards") or {}).get(str(card_id)) or []
    return [{"day": d, "usd": u} for d, u in zip(doc.get("days") or [], vals) if u is not None]


# ------------------------------------------------------------------------------------------------ the app side
_lock = threading.Lock()
_busy = set()               # (game, set) fetches running in the background now


def _cache_path(svc, game, set_id):
    from .db import game_dir
    return os.path.join(game_dir(svc.cfg["data_dir"], game), FOLDER, fname(set_id))


def _url(svc, game):
    from . import carddata
    from .tcggames import data_slug
    return [f"{b}/{FOLDER}/{data_slug(game)}" for b in carddata.bases(svc, "catalog")]


def _fetch(svc, game, set_id, get=None):
    """Download the set's file into the app's cache.  -> True when a file arrived.  A set Card Data has no file for leaves an empty marker (asked again the next day)."""
    from . import sync
    get = get or (lambda u: sync._get(u, as_json=False, tries=2))
    path = _cache_path(svc, game, set_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    answered = False
    for base in _url(svc, game):
        try:
            raw = get(f"{base}/{fname(set_id)}")
        except Exception:  # noqa: BLE001 - the next place (none answering: asked again the next time the card is opened)
            continue
        answered = True
        if not raw:
            continue
        try:
            decode(raw)
        except (OSError, ValueError):
            continue
        with open(path + ".part", "wb") as f:
            f.write(bytes(raw))
        os.replace(path + ".part", path)
        return True
    if answered:                                                            # no file for this set today: do not ask again until tomorrow
        with open(path + ".none", "w", encoding="utf-8") as f:
            f.write(datetime.date.today().isoformat())
    return False


def _fresh(path):
    """Was the cached file (or the 'nothing there' marker) fetched today?"""
    for p in (path, path + ".none"):
        try:
            if datetime.date.fromtimestamp(os.path.getmtime(p)) == datetime.date.today():
                return True
        except OSError:
            pass
    return False


def cached(svc, game, set_id):
    """The set's file from the app's cache, or None."""
    try:
        with open(_cache_path(svc, game, set_id), "rb") as f:
            return decode(f.read())
    except (OSError, ValueError):
        return None


def for_card(svc, game, set_id, card_id, get=None, inline=None):
    """-> (history [{"day", "usd"}], pending).  Answers from the cache at once; a missing or old file is fetched in the background (pending=True: ask again shortly).
    In the browser (no threads) the small file is fetched right here, inside the engine's own worker, so the screen still never waits on it."""
    from .runtime import INLINE
    inline = INLINE if inline is None else inline
    path = _cache_path(svc, game, set_id)
    doc = cached(svc, game, set_id)
    if _fresh(path):
        return series(doc, card_id), False
    key = (game, str(set_id))
    if inline:
        try:
            _fetch(svc, game, set_id, get)
        except OSError:
            pass
        return series(cached(svc, game, set_id) or doc, card_id), False
    with _lock:
        if key in _busy:
            return series(doc, card_id), True
        _busy.add(key)

    def run():
        try:
            _fetch(svc, game, set_id, get)
        except Exception:  # noqa: BLE001 - asked again the next time the card is opened
            pass
        finally:
            with _lock:
                _busy.discard(key)

    threading.Thread(target=run, name="sethistory-fetch", daemon=True).start()
    return series(doc, card_id), True
