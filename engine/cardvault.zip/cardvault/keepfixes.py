"""Fixes outlive the nightly re-sync.  The daily update re-reads the whole Pokemon list from TCGdex (cardvault/sync.fetch_catalog); without this it would undo the owner's catalog fixes every night.
What a re-sync from a bulk source (the lowest trust in provenance.TRUST) leaves alone:
  RETIRED ids   a card id folded into its twin (meta 'id_redirects' {old: kept}, old != kept) is never added back.
  PICTURES      a card whose picture came from a more trusted source (its provenance 'image' record, else the picture's own host: a TCGplayer picture put in place of TCGdex's) keeps it;
                an empty picture from the source never wipes one we have.
  NAMES         a card whose name has a more trusted provenance 'name' record (the owner's fix: provenance.record(conn, id, 'name', 'fix')) keeps it, and so does a name that differs from the
                source's only in typography (’ for ', spacing, width): ours was straightened on purpose.  The same typography rule holds for set names.
  DATES         a set date a source proved (cardvault/datefix.py stamps it in meta 'setdate_src') stays; an empty date or logo from the source never wipes one we have.
Set logos found by cardvault/setfiling.py live in meta 'setimg_urls', which no re-sync touches."""
import json
import re
import unicodedata

from . import provenance

_QUOTES = str.maketrans({"‘": "'", "’": "'", "ʼ": "'", "′": "'", "´": "'", "“": '"', "”": '"', "–": "-", "—": "-"})


def typography(s):
    """A name with only its typography folded: quotes, dashes, width, spacing, case."""
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s or "").translate(_QUOTES)).strip().casefold()


def _meta(conn, key):
    try:
        return json.loads((conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone() or ["{}"])[0] or "{}")
    except ValueError:
        return {}


class Kept:
    """What one list keeps through a re-sync by `source` (a provenance code).  Read once, before the source's rows are written."""

    def __init__(self, conn, source="tdx"):
        self.level = provenance.trust(source)
        provenance.ensure(conn)
        self.retired = {k for k, v in _meta(conn, "id_redirects").items() if k != v}
        self.dates = set(_meta(conn, "setdate_src"))
        prov = {}
        for cid, field, src in conn.execute("SELECT card_id, field, source FROM provenance WHERE field IN ('image','name')"):
            prov[(cid, field)] = src
        self.pictures, self.names, self.card_names = set(), set(), {}
        for cid, name, img in conn.execute("SELECT id, name, image_base FROM cards"):
            self.card_names[cid] = name
            if img and self._higher(prov.get((cid, "image")) or provenance.IMAGE_HOSTS.get(provenance.host_of(img), "i:")):
                self.pictures.add(cid)
            if self._higher(prov.get((cid, "name"))):
                self.names.add(cid)
        self.set_names = {sid: name for sid, name in conn.execute("SELECT id, name FROM sets")}

    def _higher(self, code):
        return provenance.trust(code) > self.level

    def skip(self, card_id):
        return card_id in self.retired

    def card_name(self, card_id, new):
        """The name to write over ours, or None to keep ours."""
        old = self.card_names.get(card_id)
        if card_id in self.names or not new or (old and typography(old) == typography(new)):
            return None
        return new

    def picture(self, card_id, new):
        """The picture to write over ours, or None to keep ours."""
        return None if (not new or card_id in self.pictures) else new

    def set_name(self, set_id, new):
        old = self.set_names.get(set_id)
        return None if (not new or (old and typography(old) == typography(new))) else new

    def set_date(self, set_id, new):
        return None if set_id in self.dates else (new or None)
