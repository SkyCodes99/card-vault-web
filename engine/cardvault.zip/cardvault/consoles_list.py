"""Consoles of the "Gaming consoles" line: Wikipedia article title -> maker and family (the group in the app).  Facts and pictures are read by tools/harvest_consoles.py into consoles_data.json."""
_N, _S, _M, _G, _A = "Nintendo", "Sony", "Microsoft", "Sega", "Atari"
_rows = [
    (_N, "Nintendo home consoles", ["Nintendo Entertainment System", "Super Nintendo Entertainment System", "Nintendo 64", "GameCube", "Wii", "Wii U", "Nintendo Switch", "Nintendo Switch 2", "Famicom Disk System", "NES Classic Edition", "Super NES Classic Edition", "Virtual Boy"]),
    (_N, "Nintendo handhelds", ["Game Boy", "Game Boy Color", "Game Boy Advance", "Game Boy Advance SP", "Game Boy Micro", "Nintendo DS", "Nintendo DSi", "Nintendo 3DS", "New Nintendo 3DS", "Nintendo 2DS", "New Nintendo 2DS XL"]),
    (_S, "PlayStation home consoles", ["PlayStation (console)", "PlayStation 2", "PlayStation 3", "PlayStation 4", "PlayStation 5", "PlayStation Classic", "PlayStation TV"]),
    (_S, "PlayStation handhelds", ["PlayStation Portable", "PlayStation Vita", "PlayStation Portal"]),
    (_M, "Xbox", ["Xbox (console)", "Xbox 360", "Xbox One", "Xbox Series X and Series S", "ROG Xbox Ally"]),
    (_G, "Sega home consoles", ["SG-1000", "Master System", "Sega Genesis", "Sega CD", "32X", "Sega Saturn", "Dreamcast", "Sega Pico", "Sega Genesis Mini"]),
    (_G, "Sega handhelds", ["Game Gear", "Genesis Nomad"]),
    (_A, "Atari", ["Atari 2600", "Atari 5200", "Atari 7800", "Atari Jaguar", "Atari Lynx", "Atari Jaguar CD", "Atari XEGS"]),
    ("Magnavox", "Early consoles", ["Magnavox Odyssey", "Magnavox Odyssey 2"]),
    ("Mattel", "Early consoles", ["Intellivision"]),
    ("Coleco", "Early consoles", ["ColecoVision"]),
    ("Fairchild", "Early consoles", ["Fairchild Channel F"]),
    ("Commodore", "Other makers", ["Amiga CD32"]),
    ("Tiger Electronics", "Other makers", ["Game.com"]),
    ("Panic", "Other makers", ["Playdate"]),
    ("Ouya Inc.", "Other makers", ["Ouya"]),
    ("General Consumer Electronics", "Early consoles", ["Vectrex"]),
    ("SNK", "SNK Neo Geo", ["Neo Geo", "Neo Geo CD", "Neo Geo Pocket"]),
    ("NEC", "Other makers", ["TurboGrafx-16", "PC-FX", "TurboExpress"]),
    ("Panasonic", "Other makers", ["3DO"]),
    ("Philips", "Other makers", ["CD-i"]),
    ("Bandai", "Other makers", ["WonderSwan"]),
    ("Valve", "PC handhelds", ["Steam Deck"]),
    ("Analogue", "Other makers", ["Analogue Pocket"]),
    ("Blaze Entertainment", "Other makers", ["Evercade"]),
]
# Wikipedia pages that list consoles (the Released/first-column links are read; an Unreleased / Cancelled section is cut off) and the categories whose own pages are read.
LIST_PAGES = ["List of home video game consoles", "List of handheld game consoles", "List of first generation home video game consoles", "List of dedicated video game consoles", "List of microconsoles"]
CATEGORIES = ["Home video game consoles", "Handheld game consoles", "Microconsoles", "Dedicated consoles", "Hybrid video game consoles", "Android-based handheld game consoles", "Linux-based handheld game consoles",
              "Discontinued handheld game consoles", "Evercade", "Game Boy consoles", "Game Gear", "Gizmondo", "Neo Geo Pocket", "Nintendo 3DS", "Nintendo DS", "Game Boy Advance", "PlayStation Portable", "PlayStation Vita",
              "Nintendo Switch", "Nintendo Switch 2", "Atari 2600", "Dreamcast", "FM Towns", "GameCube", "Master System", "Nintendo 64", "Nintendo Entertainment System", "PlayStation (console)", "PlayStation 2", "PlayStation 3",
              "PlayStation 4", "Sega Genesis", "Sega Saturn", "Super Nintendo Entertainment System", "TurboGrafx-16", "Wii", "Wii U", "Xbox", "Xbox (console)", "Xbox 360", "Xbox One", "Xbox Series X and Series S",
              "First-generation video game consoles", "Second-generation video game consoles", "Third-generation video game consoles", "Fourth-generation video game consoles", "Fifth-generation video game consoles",
              "Sixth-generation video game consoles", "Seventh-generation video game consoles", "Eighth-generation video game consoles", "Ninth-generation video game consoles",
              "Video game console revisions", "Retro-oriented video game consoles", "FPGA-based video game consoles", "Crowdfunded video game consoles", "Linux-based video game consoles", "Regionless game consoles"]
# Titles worth trying that the lists may miss (PC handhelds, revisions with their own article, regional machines).  A title with no usable infobox just goes to the left-out list.
EXTRA_TITLES = ["Steam Deck", "ROG Ally", "ROG Ally X", "Lenovo Legion Go", "Lenovo Legion Go S", "Legion Go", "MSI Claw", "GPD Win", "GPD Win 2", "GPD Win Max", "Ayaneo", "AYANEO", "OneXPlayer", "Ayn Odin", "Ayn Odin 2",
                "Nintendo Switch Lite", "Nintendo Switch (OLED model)", "Nintendo Switch OLED", "Game Boy Pocket", "Game Boy Light", "Nintendo DS Lite", "New Nintendo 3DS XL", "Nintendo 3DS XL", "Nintendo DSi XL", "PSP Go", "PlayStation Portable Go",
                "PSone", "PlayStation 4 Pro", "PlayStation 5 Pro", "Xbox One X", "Xbox One S", "Xbox Series S", "Xbox Series X", "Super Famicom", "Family Computer", "Wii Mini", "Mega Drive", "Sega Mark III", "Sega Nomad",
                "Super Cassette Vision", "Epoch Cassette Vision", "Bandai Playdia", "Pioneer LaserActive", "Casio PV-1000", "Tomy Tutor", "Emerson Arcadia 2001", "Atari Video Music", "Atari Flashback", "Nuon (DVD technology)", "Zeebo",
                "Tapwave Zodiac", "GP2X", "Pandora (console)", "Analogue Duo", "Analogue Super Nt", "Analogue Mega Sg", "Analogue Nt", "Analogue 3D", "Polymega", "Evercade EXP", "Miyoo Mini", "Anbernic RG351", "Steam Machine (hardware)",
                "Game & Watch", "Pocket Station", "PlayStation Vita TV", "N-Gage", "N-Gage QD", "Nintendo Switch 2", "ROG Xbox Ally", "Xbox Ally", "Sega Genesis Mini 2", "TurboGrafx-16 Mini", "PC Engine Mini", "Neo Geo Mini", "Atari 2600+", "Atari 7800+",
                "Intellivision Amico", "Intellivision Sprint", "Nintendo Classic Mini", "Wonderswan Color", "WonderSwan Color", "SwanCrystal", "Pocket Challenge V2", "Game Boy Camera"]
SKIP_TITLES = {"Game Boy Camera", "Amiga", "Atari Video Music"}
CONSOLES = []
for maker, family, titles in _rows:
    for t in titles:
        CONSOLES.append({"id": __import__("re").sub(r"[^a-z0-9]+", "-", t.lower()).strip("-"), "title": t, "maker": maker, "family": family})
