"""Asking prices nobody pays.  When a card has never sold, the daily price file falls back to the middle or lowest LISTING (kinds 'mid price' / 'low price').  A seller who does not want to
sell lists at $100,000, and that became the card's price: the Southeast Asia Exclusives set (36 promos, all the others under $25) was "worth" $100,048 because of one Eevee GYM promo.
A listing-only price at or above CAP is a placeholder, not a value: it is never written, and one already in a card list is cleared (the card shows "no price" until it really sells).
Market prices (real sales) are never touched, whatever they are."""

import sqlite3

CAP = 20000.0
LISTING_KINDS = ("mid price", "low price")


def is_placeholder(usd, kind):
    return kind in LISTING_KINDS and usd is not None and usd >= CAP


def clear(conn):
    """Clear the placeholder prices of a card list's cards.  Reads first, so a list that has none opens no write (see askexpiry 28399c0).  -> number of cards cleared (not committed)."""
    marks = ",".join("?" * len(LISTING_KINDS))
    try:
        if not conn.execute(f"SELECT 1 FROM cards WHERE price_usd>=? AND price_kind IN ({marks}) LIMIT 1", (CAP, *LISTING_KINDS)).fetchone():
            return 0
        return conn.execute(f"UPDATE cards SET price_usd=NULL, price_kind=NULL WHERE price_usd>=? AND price_kind IN ({marks})", (CAP, *LISTING_KINDS)).rowcount
    except sqlite3.Error:                         # (an older list without the price columns: nothing to clear)
        return 0


def _stamp(conn):
    try:
        r = conn.execute("SELECT value FROM meta WHERE key='prices_updated'").fetchone()
        return f"{CAP:g}:{(r[0] if r else '') or ''}"
    except sqlite3.Error:
        return None


def clear_once(conn):
    """clear() when the card list's prices changed since it last ran (a new list, or a day's prices written by an older version): opening a list stays a look at one meta row
    (reading all of Magic's 115,000 cards took ~0.1 s every opening).  Not committed."""
    stamp = _stamp(conn)
    if stamp is None:
        return 0
    if (conn.execute("SELECT value FROM meta WHERE key='listingcap'").fetchone() or [None])[0] == stamp:
        return 0
    n = clear(conn)
    mark_done(conn)
    return n


def mark_done(conn):
    """Remember that the card list's prices as they are now have been cleared of placeholders (clear_once then looks no further)."""
    stamp = _stamp(conn)
    if stamp is not None:
        conn.execute("INSERT OR REPLACE INTO meta VALUES('listingcap', ?)", (stamp,))
