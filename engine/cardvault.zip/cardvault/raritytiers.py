"""A rarity "tier" that means the same in every card game, so one filter can say "secret rares" across Pokémon, Yu-Gi-Oh!, One Piece and the rest.

Each game names its rarities its own way (Common / C / UC, Rare / R / Rare Holo, Super Rare / Ultra Rare / SR, Secret Rare / Hyper Rare / Legendary ...).  A tier is matched from those names, so it is an honest
approximation: a rarity name nobody recognises belongs to no tier.
"""

TIERS = [("common", "Common"), ("uncommon", "Uncommon"), ("rare", "Rare"), ("super", "Super / ultra rare"), ("secret", "Secret / special / legendary"), ("promo", "Promo")]      # (the order they are shown in)

# (tier, words that appear in the rarity's name, whole short codes, the words must START the name) - the first that matches wins, so the rare ends of the scale come first
_RULES = [
    ("promo", ("promo",), ("p", "pr"), False),
    ("secret", ("secret", "hyper", "special illustration", "legend", "enchanted", "starlight", "ghost", "gold rare", "rainbow", "collector", "quarter century", "iconic", "epic"), ("sec", "sp", "ssp", "s", "mr"), False),
    ("super", ("ultra", "super", "illustration rare", "double rare", "holo rare v", "shiny", "mythic", "ace spec"), ("sr", "ur", "ssr", "rrr", "m"), False),
    ("uncommon", ("uncommon",), ("u", "uc"), True),
    ("common", ("common",), ("c",), True),
    ("rare", ("rare",), ("r", "rr"), False),
]


def valid(tier):
    """The tier's name if it is one, else '' (anything else a screen sends is ignored)."""
    return tier if tier in {t[0] for t in TIERS} else ""


def tier_case(column):
    """SQL that turns a rarity column into its tier ('common' ... 'promo'), or NULL for a name that is not recognised."""
    rarity = f"lower(coalesce({column}, ''))"
    cases = []
    for tier, words, codes, at_start in _RULES:
        has_word = " OR ".join(f"{rarity} LIKE '{'' if at_start else '%'}{w}%'" for w in words)
        is_code = f"{rarity} IN ({', '.join(repr(c) for c in codes)})"
        cases.append(f"WHEN {has_word} OR {is_code} THEN '{tier}'")
    return "(CASE " + " ".join(cases) + " END)"
