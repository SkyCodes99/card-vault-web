"""The Sports list (game id 'sports'), owner quiz 2026-11-15 q12: "Create the sports category if not there yet and it just goes in sports"; q13: no price on them.

Sports collectibles that are not a card game.  So far the two Costco-only Panini FIFA World Cup 2026 sticker boxes, read from the kept list cardvault/collabmerch_data.json (its
collabmerch.SPORTS_LINES lines; no network at refresh).  They used to be in Accessories under the same item ids: anything of yours on them there (copies, wishlist, tags) follows
to this list (cardvault/gamemoves.py).  No prices: refresh_prices never writes one and the entries carry no retail price.
"""
import time

from . import collabmerch
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider


class SportsProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("sports", 0, type_field="Brand")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the sports list…", 0, 0)
            n = collabmerch.add(conn, time.strftime("%Y-%m-%d"), sports=True)
            conn.execute("DELETE FROM sets WHERE id NOT IN (SELECT DISTINCT set_id FROM cards)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            from . import gamefacets
            gamefacets.ensure(conn, self.game_id, force=True)
            return n
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # owner quiz 2026-11-15 q13: no price on them
