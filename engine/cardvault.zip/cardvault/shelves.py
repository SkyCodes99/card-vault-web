"""Where every list sits in the menus: Shelf (industry) -> Company / maker -> List (owner 2026-11-13: "chomp trading cards should be within the abominable toys category").

ONE table, read by the game menu and the Find & Add page on the computer and the website alike (app.info sends it).  Navigation only: game ids, set ids, item ids, portfolios,
prices and sync never change here.  Every game id in games.GAMES is in COMPANIES exactly once (tests/test_shelves.py).

A company sits on ONE shelf and keeps everything it makes together, its cards included (Takara Tomy: Beyblade X and WIXOSS; Spin Master: the Bakugan toys and the Bakugan TCG).
LINES are shortcuts INTO one list (a product line, or a brand inside a shared list) - the list itself still has one home.

Fandom is not a folder: FANDOMS is a filter across every list (search.query fandom=..., Browse by fandom).  A card game that IS a fandom counts whole; a toy / plush / accessory
list counts the items whose name, set, line or fandom facet says it (the Funko fandom + franchise facets, the accessories' fandom, the Youtooz franchise)."""

SHELVES = (
    ("tcg", "Trading card games"),
    ("toys", "Toys & collectibles"),
    ("video", "Video games"),
    ("skate", "Skate"),
    ("merch", "Accessories & merch"),
)

# (shelf, company, [game ids]) in menu order.  Card-game publishers are named only where the publisher is certain; the rest share "Other publishers".
COMPANIES = (
    ("tcg", "The Pokémon Company", ["pokemon", "pokemon_jp"]),
    ("tcg", "Wizards of the Coast", ["mtg", "transformers"]),
    ("tcg", "Konami", ["yugioh"]),
    ("tcg", "Bandai", ["onepiece", "dbsfw", "dbs", "digimon", "gundam", "unionarena", "battlespirits", "godzilla"]),
    ("tcg", "Ravensburger", ["lorcana"]),
    ("tcg", "Riot Games", ["riftbound"]),
    ("tcg", "Bushiroad", ["weissschwarz", "vanguard", "shadowverse", "buddyfight", "dragoborne"]),
    ("tcg", "Fantasy Flight Games", ["swu", "swdestiny"]),
    ("tcg", "Legend Story Studios", ["fab"]),
    ("tcg", "Square Enix", ["finalfantasy"]),
    ("tcg", "WizKids", ["dicemasters", "munchkin"]),
    ("tcg", "PlayFusion", ["aoschampions", "lightseekers"]),
    ("tcg", "Panini & Score", ["dbz"]),
    ("tcg", "Other publishers", ["fow", "grandarchive", "hololive", "palworld", "metazoo", "universus", "sorcery", "cookierun", "alphaclash", "elestrals", "akora", "kryptik",
                                 "gateruler", "wowtcg", "metax", "zwo", "casterchronicles", "exodus", "chronoclash", "argentsaga", "cyberpunk"]),
    ("toys", "Abominable Toys", ["chomps"]),
    ("toys", "Funko", ["funko"]),
    ("toys", "Youtooz", ["youtooz"]),
    ("toys", "100% Soft", ["dumpsterfires"]),
    ("toys", "Takara Tomy", ["beyblade", "wixoss"]),
    ("toys", "Spin Master", ["bakugan", "bakugantcg"]),
    ("toys", "Schylling", ["needoh"]),
    ("toys", "Plush brands", ["plushies"]),
    ("toys", "My own items", ["other"]),
    ("video", "Console makers", ["consoles"]),
    ("merch", "Playmats & displays", ["accessories"]),
)

# shortcuts into one list: (shelf, company, label, game id, Find & Add filters).  ctype = the list's own Type / Product line; setNameQ = the set (brand) name.
LINES = (
    ("toys", "Abominable Toys", "Chomps", "chomps", {"ctype": "Chomps"}),
    ("toys", "Abominable Toys", "Chompers", "chomps", {"ctype": "Chompers"}),
    ("toys", "Abominable Toys", "Chomp trading cards", "chomps", {"ctype": "Trading cards"}),
    ("skate", "Bear Walker", "Bear Walker skateboards", "accessories", {"setNameQ": "Bear Walker"}),
    ("skate", "Santa Cruz", "Santa Cruz skateboards", "accessories", {"setNameQ": "Santa Cruz"}),
)

# (id, name, card games / lists that ARE the fandom (count whole), words that name it inside a toy's name, set, line or fandom - SQL LIKE pieces, '_' = any one letter)
FANDOMS = (
    ("pokemon", "Pokémon", ["pokemon", "pokemon_jp"], ["pok_mon", "pikachu"]),
    ("marvel", "Marvel", [], ["marvel", "spider-man", "avengers", "x-men"]),
    ("starwars", "Star Wars", ["swu", "swdestiny"], ["star wars", "mandalorian"]),
    ("disney", "Disney & Pixar", ["lorcana"], ["disney", "pixar", "mickey mouse"]),
    ("dc", "DC", [], ["batman", "superman", "wonder woman", "justice league", "dc comics"]),
    ("dragonball", "Dragon Ball", ["dbs", "dbsfw", "dbz"], ["dragon ball"]),
    ("onepiece", "One Piece", ["onepiece"], ["one piece"]),
    ("yugioh", "Yu-Gi-Oh!", ["yugioh"], ["yu-gi-oh", "yugioh"]),
    ("mtg", "Magic: The Gathering", ["mtg"], ["magic: the gathering", "magic the gathering"]),
    ("harrypotter", "Harry Potter", [], ["harry potter", "hogwarts"]),
    ("nintendo", "Mario, Zelda & Nintendo", [], ["super mario", "zelda", "nintendo", "kirby"]),
    ("sonic", "Sonic the Hedgehog", [], ["sonic the hedgehog", "sonic"]),
    ("fnaf", "Five Nights at Freddy's", [], ["five nights", "fnaf"]),
    ("naruto", "Naruto", [], ["naruto"]),
    ("mha", "My Hero Academia", [], ["my hero academia"]),
    ("digimon", "Digimon", ["digimon"], ["digimon"]),
    ("gundam", "Gundam", ["gundam"], ["gundam"]),
    ("transformers", "Transformers", ["transformers"], ["transformers"]),
    ("godzilla", "Godzilla", ["godzilla"], ["godzilla"]),
    ("finalfantasy", "Final Fantasy", ["finalfantasy"], ["final fantasy"]),
    ("beyblade", "Beyblade", ["beyblade"], ["beyblade"]),
    ("bakugan", "Bakugan", ["bakugan", "bakugantcg"], ["bakugan"]),
)

FACETS = ("fandom", "franchise", "line", "brand", "collab")          # the facets of a toy list that say what it is FROM (gamefacets.py)


def place_of(game_id):
    """-> (shelf id, company) of a list, or ("", "") for an id this table does not know."""
    for shelf, company, ids in COMPANIES:
        if game_id in ids:
            return shelf, company
    return "", ""


def tree(game_ids):
    """The menu for the lists offered here (game_ids, in any order): [{id, label, companies: [{name, games: [ids], lines: [{label, game, filters}]}]}].
    A company with nothing offered is left out, and so is an empty shelf; a line shows only when its list is offered.  A list missing from the table lands in Other publishers / Plush brands
    by kind, so a new game is never invisible (the test still asks for its own row)."""
    have = list(dict.fromkeys(game_ids))
    known = {g for _s, _c, ids in COMPANIES for g in ids}
    out = []
    for sid, label in SHELVES:
        comps = []
        for shelf, company, ids in COMPANIES:
            if shelf != sid:
                continue
            gs = [g for g in ids if g in have]
            if shelf == "tcg" and company == "Other publishers":
                gs += [g for g in have if g not in known and not _misc(g)]
            if shelf == "toys" and company == "Plush brands":
                gs += [g for g in have if g not in known and _misc(g)]
            lines = [{"label": lab, "game": g, "filters": dict(f)} for s, c, lab, g, f in LINES if s == sid and c == company and g in have]
            if gs or lines:
                comps.append({"name": company, "games": gs, "lines": lines})
        for s, c, lab, g, f in LINES:                                  # a company that is only lines (Skate: Bear Walker, Santa Cruz)
            if s == sid and g in have and not any(x["name"] == c for x in comps):
                comps.append({"name": c, "games": [], "lines": [{"label": x[2], "game": x[3], "filters": dict(x[4])} for x in LINES if x[0] == sid and x[1] == c and x[3] in have]})
        if comps:
            out.append({"id": sid, "label": label, "companies": comps})
    return out


def _misc(game_id):
    from . import games
    return games.is_misc(game_id)


def fandom_list():
    return [{"id": fid, "name": name} for fid, name, _g, _w in FANDOMS]


def fandom_by_id(fid):
    return next((f for f in FANDOMS if f[0] == fid), None)


def fandom_index_where(fid):
    """The same filter for the all-games search index (webapi/searchindex.py: items i, set names through strs, types t): (sql, args), or ("", {}) for an unknown fandom.
    The index has no facets, so a toy counts by its name, set or type there."""
    f = fandom_by_id(fid)
    if not f:
        return "", {}
    from . import games
    _fid, _name, whole, words = f
    misc = [g.id for g in games.GAMES if games.is_misc(g.id) and g.id not in whole]
    args = {f"fdw{k}": g for k, g in enumerate(whole)}
    args.update({f"fdm{k}": g for k, g in enumerate(misc)})
    match = []
    for i, w in enumerate(words):
        args[f"fd{i}"] = f"%{w}%"
        match.append(f"i.name LIKE :fd{i} OR i.sid IN (SELECT i FROM strs WHERE t LIKE :fd{i}) OR t.t LIKE :fd{i}")
    parts = []
    if whole:
        parts.append("i.game IN (" + ",".join(f":fdw{k}" for k in range(len(whole))) + ")")
    if misc and match:
        parts.append("(i.game IN (" + ",".join(f":fdm{k}" for k in range(len(misc))) + ") AND (" + " OR ".join(match) + "))")
    return "(" + (" OR ".join(parts) or "0") + ")", args


def fandom_where(game_id, fid, has_facets=True, misc=None):
    """How one list is narrowed to a fandom, for SQL over its catalog (cards c JOIN sets s):
    None = nothing in this list (skip it), ("", {}) = the whole list, (sql, args) = only the matching items.  A card game counts only when it IS the fandom: a Magic card named
    'Marvel ...' is still Magic.  Unknown fandom -> ("", {}) (no narrowing)."""
    f = fandom_by_id(fid)
    if not f:
        return "", {}
    _fid, _name, whole, words = f
    if game_id in whole:
        return "", {}
    if not (_misc(game_id) if misc is None else misc):
        return None
    parts, args = [], {}
    for i, w in enumerate(words):
        k = f"fd{i}"
        args[k] = f"%{w}%"
        one = [f"lower(c.name) LIKE :{k}", f"lower(coalesce(s.name,'')) LIKE :{k}", f"lower(coalesce(c.types,'')) LIKE :{k}"]
        if has_facets:
            one.append(f"c.id IN (SELECT card_id FROM card_facets WHERE facet IN ({','.join(repr(x) for x in FACETS)}) AND lower(value) LIKE :{k})")
        parts.append(" OR ".join(one))
    return "(" + " OR ".join(f"({p})" for p in parts) + ")", args
