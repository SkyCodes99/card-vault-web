"""Hot Wheels line: every car in hotwheels_data.json (read by tools/harvest_hotwheels.py from the allowed collector sites - docs/hotwheels_sources.md) as an item of its own, grouped by line and year
("2027 Super Treasure Hunts", "Red Line Club 2026", "Redlines 1968").  No network at refresh.

Each car keeps what its source page states: casting, designer, year, series and number in series, collector number, toy number, case letter, line, colour, wheels, base, country made.
A fact the page does not state is left out (never guessed) and named in the raw ext 'Review' note, the same note the consoles and Nee-Doh use.  Every stated fact gets its own provenance
record (source site, the car's own page as the link, the day it was read).  Pictures: none yet - no allowed source gives a picture we may show for the exact car, so every item says
"No picture yet" and its Review note says why."""
import json
import os
import re
import time

from . import hotwheels_lines as lines
from . import provenance
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hotwheels_data.json")
# (key in the data file, what the item's details call it, asked of every car: named in the Review note when its page does not state it)
FACTS = (("casting", "Casting", True), ("designer", "Designer", True), ("year", "Year", True), ("series", "Series", True), ("series_no", "Number in series", True),
         ("collector_no", "Collector number", True), ("toy_no", "Toy number", True), ("case", "Case", True), ("colour", "Colour", True), ("wheels", "Wheels", True),
         ("wheel_type", "Wheel type", False), ("base", "Base", True), ("base_colour", "Base colour", False), ("country", "Made in", True), ("windows", "Windows", False),
         ("interior", "Interior", False), ("release_date", "Release date", False), ("edition_size", "Edition size", False))
NO_PICTURE = "No picture yet: no source we are allowed to read gives a picture we may show for this exact car"
_MONTHS = {m: i + 1 for i, m in enumerate("january february march april may june july august september october november december".split())}


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def iso_day(text):
    """'October 27, 2026' -> '2026-10-27'; anything else is returned as it was stated."""
    m = re.fullmatch(r"\s*([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})\s*", text or "")
    return "%s-%02d-%02d" % (m.group(3), _MONTHS[m.group(1).lower()], int(m.group(2))) if m and m.group(1).lower() in _MONTHS else (text or "")


def facts_of(item):
    """{detail label: stated value} of one harvested car, in display order; the casting of a Redline page is the page's own car."""
    line = lines.line_of(item)
    out = {"Line": line}
    for key, label, _asked in FACTS:
        v = item.get(key) or ""
        if key == "casting" and not v and not lines.SITES[item["site"]]["prose"]:
            v = item["name"]
        if key == "release_date":
            v = iso_day(v)
        if key == "edition_size" and v:
            v += " made"
        if v:
            out[label] = v
    return out


def review_of(facts):
    missing = [label.lower() for _k, label, asked in FACTS if asked and label not in facts]
    return NO_PICTURE + ("; not stated by the source: " + ", ".join(missing) if missing else "")


def source_code(conn, item):
    """The provenance code of a car's source site ('w:<host>', the code the toy lists already use), registered with the site's name."""
    site = lines.SITES[item["site"]]
    code = "w:" + site["host"].replace("www.", "")
    conn.execute("INSERT OR REPLACE INTO sources(code,name,url_tpl) VALUES(?,?,NULL)", (code, site["name"]))
    return code


class HotWheelsProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("hotwheels", 0, type_field="Casting")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the Hot Wheels list…", 0, 0)
            provenance.ensure(conn)
            made, rows, prov = {}, [], []
            for it in load()["items"]:
                line, year = lines.line_of(it), it["year"]
                if not line:
                    continue                                              # (a page that states no line is not filed anywhere: it stays out, never guessed)
                sid = "hotwheels:" + re.sub(r"[^a-z0-9]+", "-", "%s %s" % (lines.short(line).lower(), year)).strip("-")      # (a club season "2014/2015" -> ...-2014-2015)
                if sid not in made:
                    made[sid] = 0
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, lines.group_name(line, year), line, year, 0, 0))
                made[sid] += 1
                facts = facts_of(it)
                site = lines.SITES[it["site"]]
                ext = {"Source": "%s: %s" % (site["name"], it["url"]), **facts, "Review": review_of(facts)}
                cid = "hotwheels:" + it["id"]
                code = source_code(conn, it)
                prov.append((cid, "card", code, it["read"], it["url"]))
                prov += [(cid, label, code, it["read"], it["url"]) for label in facts]
                rows.append((cid, sid, facts.get("Collector number") or facts.get("Number in series") or "", made[sid], "%s - %s %s" % (it["name"], year, lines.short(line)), "", line, None,
                             facts.get("Casting", ""), "%s - %s, %s. Facts from %s." % (it["name"], line, year, site["name"]), json.dumps({"normal": True}),
                             json.dumps({"source": site["host"].replace("www.", ""), "key": it["id"], "url": it["url"], "ext": ext}, ensure_ascii=False)))
            conn.executemany("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) "
                             "VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)", rows)
            keep = {r[0] for r in rows}
            gone = [(r[0],) for r in conn.execute("SELECT id FROM cards") if r[0] not in keep]          # (a car its source no longer lists leaves the list; the owner's own copies are kept elsewhere)
            conn.executemany("DELETE FROM cards WHERE id=?", gone)
            conn.executemany("DELETE FROM provenance WHERE card_id=?", gone + [(c,) for c in keep])
            provenance.record_many(conn, prov)
            conn.executemany("UPDATE sets SET total=?, official=? WHERE id=?", [(n, n, sid) for sid, n in made.items()])
            conn.execute("DELETE FROM sets WHERE id NOT IN (SELECT DISTINCT set_id FROM cards)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            from . import gamefacets
            gamefacets.ensure(conn, self.game_id, force=True)             # (the sidebar filters are rebuilt with the list, as the wiki toy lists do)
            return len(rows)
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no price source yet (roadmap: "Hot Wheels: prices from several sources"); owners can enter what they paid
