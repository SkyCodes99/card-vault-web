"""Cards in another language: which card lists are the same game in another language ("language siblings"), and the English card that a non-English card IS.

The scanner uses this when a photo does not match the open game well: it also looks in the siblings (an English Pokémon list also looks in the Japanese one), and a match there is shown
as the card the person actually holds, with a link to its English equivalent and that card's price.

The English equivalent is never guessed from a translated name.  A Japanese Pokémon card is linked to an English card only when the catalogs agree on all of:
  * the official English name the Japanese list carries (`name_en`: the TCGplayer product name or the Pokédex species, see tools/translate_jp.py - never machine-translated),
  * the HP (printed number, language-free) and
  * the illustrator (printed in Latin letters on both),
which is the same rule the app already uses for "the same card in another set" (cardprintings.identity, BY_ARTIST).  A card that has all three and no English card answers
'none' (no English printing in the lists - Japan-only so far); a card missing any of them answers 'unknown' (the lists cannot tell), never a guess.
Yu-Gi-Oh! OCG (Japanese) has no card list in the app yet, so it has no sibling; see docs/i18n_names.md."""
from . import cardprintings

# game -> the same game's lists in other languages, in the order to try them (only lists that exist in games.py)
SIBLINGS = {"pokemon": ("pokemon_jp",), "pokemon_jp": ("pokemon",)}
ENGLISH_OF = {"pokemon_jp": "pokemon"}                    # a non-English list -> its English list
LANG = {"pokemon_jp": "ja"}                                # the printed language of a list (English when left out)


def siblings(game):
    return SIBLINGS.get(game, ())


def language(game):
    return LANG.get(game, "en")


def _key(name, hp, artist):
    base = cardprintings.base_name("pokemon", name or "")
    base = base.split(" - ")[0].strip()                    # TCGplayer adds the number to some names: 'Exeggcute - 009/742 (Mirror Holo)'
    return (base.lower(), str(hp or "").strip(), str(artist or "").strip().lower())


def english_of(jp_conn, en_conn, game, card_id, limit=12):
    """The English printings of one non-English card.  -> {status, english: [rows newest first], why}
    status: 'same' (the card is already English), 'linked' (English printings found), 'none' (complete data, no English printing: Japan-only so far), 'unknown' (not enough data to say).
    Each row: id, name, set, setId, number, rarity, price, image_base, released."""
    if game not in ENGLISH_OF:
        return {"status": "same", "english": [], "why": ""}
    row = jp_conn.execute("SELECT name, name_en, hp, illustrator, category FROM cards WHERE id=?", (str(card_id),)).fetchone() if jp_conn is not None else None
    if row is None:
        return {"status": "unknown", "english": [], "why": "not in the list"}
    name_en, hp, artist = row["name_en"] or "", row["hp"], row["illustrator"] or ""
    if not name_en or not artist or (hp in (None, "") and (row["category"] or "") == "Pokemon"):
        return {"status": "unknown", "english": [], "why": "the list has no English name, HP or illustrator for it"}
    if en_conn is None:
        return {"status": "unknown", "english": [], "why": "the English list is not on this device"}
    want = _key(name_en, hp, artist)
    base = want[0]
    rows = en_conn.execute("SELECT c.id, c.name, c.local_id, c.hp, c.illustrator, c.rarity, c.set_id, c.price_usd, c.image_base, s.name AS set_name, s.release_date AS released "
                           "FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.name >= ? COLLATE NOCASE AND c.name < ? COLLATE NOCASE", (base, base + chr(0xFFFF))).fetchall()
    same = [r for r in rows if _key(r["name"], r["hp"], r["illustrator"]) == want]
    if not same:
        return {"status": "none", "english": [], "why": "no English card with the same name, HP and illustrator"}
    same.sort(key=lambda r: (r["released"] or "", str(r["local_id"] or "")), reverse=True)
    return {"status": "linked", "why": "same name, HP and illustrator", "english": [
        {"id": r["id"], "name": r["name"], "set": r["set_name"] or "", "setId": r["set_id"], "number": r["local_id"] or "", "rarity": r["rarity"] or "", "price": r["price_usd"],
         "image_base": r["image_base"] or "", "released": r["released"] or ""} for r in same[:limit]]}
