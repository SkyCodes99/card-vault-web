"""What kind of card is this?  Groups of cards (Art cards, rarity groups, mechanics...) used by the Categories browser,
checklists ("card group is...") and the Checklists page.

"Art card" means a card whose WHOLE body is an illustration:
  * every card the database calls an Illustration Rare (IR) or Special Illustration Rare (SIR),
  * every Trainer Gallery / Galarian Gallery card,
  * every Alt Art card whose artwork runs to the edges of the card.
An Alt Art is recognised from its secret numbering (number higher than the printed set size) on a Pokémon card whose picture's
artwork reaches the card edge (see arttools.py).  You can always override a single card (Card type box in the card panel).
"""
import re
from collections import namedtuple

ART_STD_THRESHOLD = 42.0     # edge-variation score (arttools.edge_score) from which artwork counts as reaching the card edge

Group = namedtuple("Group", "id label parent help")

GROUPS = [
    Group("art", "Art cards", None, "Illustration Rares, Special Illustration Rares, gallery cards and full-illustration Alt Arts."),
    Group("ir", "Illustration Rare", "art", "Cards the database calls Illustration Rare."),
    Group("sir", "Special Illustration Rare", "art", "Cards the database calls Special Illustration Rare."),
    Group("gallery", "Gallery cards", "art", "Trainer Gallery (TG) and Galarian Gallery (GG) cards."),
    Group("tg", "Trainer Gallery", "gallery", ""),
    Group("gg", "Galarian Gallery", "gallery", ""),
    Group("art_alt", "Alt Art (full illustration)", "art", "Alt Arts whose artwork covers the whole card."),
    Group("altart", "Alt Art (all)", None, "Every card recognised as an Alternate Art, whether or not it counts as an Art card."),
    # rarity groups
    Group("r_common", "Common / Uncommon", "rarity", ""),
    Group("r_rare", "Rare (non-holo)", "rarity", ""),
    Group("r_holo", "Holo Rare", "rarity", "Rare Holo, Holo Rare, LV.X, PRIME, LEGEND."),
    Group("r_double", "Double Rare (ex)", "rarity", ""),
    Group("r_ultra", "Ultra Rare (V, VMAX, VSTAR…)", "rarity", ""),
    Group("r_ace", "ACE SPEC Rare", "rarity", ""),
    Group("r_radiant", "Radiant / Amazing Rare", "rarity", ""),
    Group("r_shiny", "Shiny rarities", "rarity", ""),
    Group("r_secret", "Secret / Hyper / Gold", "rarity", "Secret Rare, Hyper rare, Mega Hyper Rare, Black White Rare."),
    Group("r_promo", "Promo", "rarity", ""),
    Group("r_pocket", "TCG Pocket (◆ ★ ♛)", "rarity", "Diamond, Star, Shiny and Crown rarities of Pokémon TCG Pocket."),
    Group("r_other", "Other / unlabelled", "rarity", ""),
    # mechanics
    Group("m_ex", "Pokémon ex", "mechanic", ""),
    Group("m_gx", "GX", "mechanic", ""),
    Group("m_oldex", "EX (older)", "mechanic", ""),
    Group("m_v", "V", "mechanic", ""),
    Group("m_vmax", "VMAX", "mechanic", ""),
    Group("m_vstar", "VSTAR", "mechanic", ""),
    Group("m_break", "BREAK", "mechanic", ""),
    Group("m_mega", "Mega", "mechanic", ""),
    # card type
    Group("c_pokemon", "Pokémon", "ctype", ""),
    Group("c_trainer", "Trainer", "ctype", ""),
    Group("c_energy", "Energy", "ctype", ""),
]
_POKEMON_SECTIONS = [("art", None), ("altart", None), ("rarity", "By rarity"), ("mechanic", "By card mechanic"), ("ctype", "By card type")]
SECTIONS = list(_POKEMON_SECTIONS)            # kept up to date by configure()
LABEL = {g.id: g.label for g in GROUPS}
GROUP_IDS = {g.id for g in GROUPS}
BUILTIN_IDS = frozenset(GROUP_IDS)

_state = {"pokemon": True, "dynamic": [], "custom": [], "custom_meta": {}, "type_label": "Type", "order": ()}


def configure(pokemon, dynamic=(), custom=(), custom_meta=None, type_label="Type", rarity_order=()):
    """Called by the Vault: which groups exist for the open game.  Pokémon = the built-in groups; other games = groups made from their
    own rarities / card types / colours; plus the user's own categories (dev tools) for every game."""
    _state.update(pokemon=bool(pokemon), dynamic=list(dynamic), custom=list(custom), custom_meta=dict(custom_meta or {}),
                  type_label=type_label, order=tuple(rarity_order))
    secs = list(_POKEMON_SECTIONS) if pokemon else [("rarity", "By rarity"), ("ctype", "By card type"), ("color", f"By {type_label.lower()}")]
    if custom:
        secs.append(("custom", "My categories"))
    SECTIONS[:] = secs
    allg = groups()
    LABEL.clear()
    LABEL.update({g.id: g.label for g in allg})
    GROUP_IDS.clear()
    GROUP_IDS.update(g.id for g in allg)


def groups():
    return (list(GROUPS) if _state["pokemon"] else []) + _state["dynamic"] + _state["custom"]


def is_pokemon():
    return _state["pokemon"]


def custom_meta(gid):
    return _state["custom_meta"].get(gid)


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")


def dynamic_groups(rarities, card_types, colours, type_label="Type"):
    """Groups for a non-Pokémon game, made from the values found in its catalogue."""
    out = [Group("r:" + _slug(r), r, "rarity", "") for r in rarities if r]
    out += [Group("t:" + _slug(t), t, "ctype", "") for t in card_types if t]
    out += [Group("k:" + _slug(k), k, "color", "") for k in colours if k]
    return out


def classify_generic(c):
    g = set()
    if c.get("rarity"):
        g.add("r:" + _slug(c["rarity"]))
    if c.get("category"):
        g.add("t:" + _slug(c["category"]))
    for part in (c.get("types") or "").split(","):
        if part.strip():
            g.add("k:" + _slug(part.strip()))
    return frozenset(g)

_RARITY = {
    "common": "r_common", "uncommon": "r_common", "rare": "r_rare",
    "rare holo": "r_holo", "holo rare": "r_holo", "rare holo lv.x": "r_holo", "rare prime": "r_holo", "legend": "r_holo",
    "double rare": "r_double",
    "ultra rare": "r_ultra", "holo rare v": "r_ultra", "holo rare vmax": "r_ultra", "holo rare vstar": "r_ultra",
    "ace spec rare": "r_ace", "radiant rare": "r_radiant", "amazing rare": "r_radiant",
    "shiny rare": "r_shiny", "shiny rare v": "r_shiny", "shiny rare vmax": "r_shiny", "shiny ultra rare": "r_shiny",
    "secret rare": "r_secret", "hyper rare": "r_secret", "mega hyper rare": "r_secret", "black white rare": "r_secret",
    "promo": "r_promo",
    "one diamond": "r_pocket", "two diamond": "r_pocket", "three diamond": "r_pocket", "four diamond": "r_pocket",
    "one star": "r_pocket", "two star": "r_pocket", "three star": "r_pocket", "one shiny": "r_pocket", "two shiny": "r_pocket", "crown": "r_pocket",
}
_MECH = [("m_vmax", re.compile(r"\bVMAX\b")), ("m_vstar", re.compile(r"\bVSTAR\b")), ("m_v", re.compile(r"\bV\b(?!-)")),
         ("m_ex", re.compile(r"\bex\b")), ("m_oldex", re.compile(r"\bEX\b")), ("m_gx", re.compile(r"\bGX\b")),
         ("m_break", re.compile(r"\bBREAK\b")), ("m_mega", re.compile(r"^(Mega|M)\s|\bMega\b"))]


# before Scarlet & Violet the alternate arts are labelled with these rarities; from Scarlet & Violet on they are IR / SIR
_ALT_RARITIES_OLD = {"ultra rare", "holo rare v", "holo rare vmax", "holo rare vstar", "rare holo"}


# usual order of rarities from the easiest to the hardest to pull; used to order the rarity sections of a set
RARITY_ORDER = ["common", "uncommon", "one diamond", "two diamond", "rare", "three diamond", "rare holo", "holo rare", "rare holo lv.x", "rare prime", "legend",
                "double rare", "four diamond", "holo rare v", "holo rare vmax", "holo rare vstar", "ultra rare", "ace spec rare", "radiant rare", "amazing rare",
                "shiny rare", "shiny rare v", "shiny rare vmax", "one shiny", "two shiny", "one star", "illustration rare", "two star", "shiny ultra rare",
                "special illustration rare", "three star", "secret rare", "hyper rare", "black white rare", "mega hyper rare", "crown", "promo"]
_RANK = {r: i for i, r in enumerate(RARITY_ORDER)}


def rarity_rank(rarity):
    low = (rarity or "").lower()
    if not _state["pokemon"]:
        order = [o.lower() for o in _state["order"]]
        for i, o in enumerate(order):                      # 'Common 1-Star' ranks with 'Common'
            if low == o or low.startswith(o + " "):
                return i
        return len(order)
    return _RANK.get(low, len(RARITY_ORDER))


def is_secret_numbered(c):
    lid = str(c.get("local_id", ""))
    return lid.isdigit() and bool(c.get("official")) and int(lid) > c["official"]


def classify(c, tag=None, threshold=None):
    """The set of group ids a card (light dict from Vault.card_index) belongs to.

    `tag` = the user's corrections for this card: {'art': 'yes'|'no', 'altart': 'yes'|'no', '<group id>': 'yes'|'no'}.
    `threshold` = the edge score from which artwork counts as reaching the card edge (learned from the user's corrections)."""
    tag = tag or {}
    thr = ART_STD_THRESHOLD if threshold is None else threshold
    g = set()
    low = (c.get("rarity") or "").lower()
    if "special illustration" in low:
        g.add("sir")
    elif "illustration" in low:
        g.add("ir")
    lid = str(c.get("local_id", "")).upper()
    sid = c.get("set_id") or ""
    if lid.startswith("TG") or sid.endswith("tg"):
        g |= {"gallery", "tg"}
    elif lid.startswith("GG") or sid.endswith("gg"):
        g |= {"gallery", "gg"}
    g.add(_RARITY.get(low, "r_other"))
    name = c.get("name") or ""
    for gid, rx in _MECH:
        if rx.search(name):
            g.add(gid)
    cat = (c.get("category") or "").lower()
    if cat.startswith("pok"):
        g.add("c_pokemon")
    elif cat == "trainer":
        g.add("c_trainer")
    elif cat == "energy":
        g.add("c_energy")

    # explicit corrections for ordinary groups (admin page)
    for gid, val in tag.items():
        if gid in BUILTIN_IDS and gid not in ("art", "altart", "art_alt"):
            if val == "yes":
                if gid.startswith("r_"):
                    g -= {x for x in g if x.startswith("r_")}
                g.add(gid)
            elif val == "no":
                g.discard(gid)
    if g & {"tg", "gg"}:
        g.add("gallery")
    if tag.get("gallery") == "no":
        g -= {"gallery", "tg", "gg"}

    score = c.get("art_score")
    era_ok = low == "secret rare" or (low in _ALT_RARITIES_OLD and (c.get("release_date") or "") < "2023-03-31")
    auto_alt = bool(is_secret_numbered(c) and c.get("category") == "Pokemon" and era_ok and score is not None
                    and score >= thr and not (g & {"ir", "sir"}))
    alt = {"yes": True, "no": False}.get(tag.get("altart"), auto_alt)
    if alt:
        g.add("altart")
    art = bool(g & {"ir", "sir", "gallery"}) or alt
    forced = {"yes": True, "no": False}.get(tag.get("art"))
    if forced is not None:
        art = forced
    if art:
        g.add("art")
        if alt:
            g.add("art_alt")
    return frozenset(g)


def explain(c, groups):
    """One plain-language line for the card panel."""
    bits = [LABEL[x] for x in ("ir", "sir", "tg", "gg", "altart") if x in groups]
    if "art" in groups:
        return "Art card" + (f" - {', '.join(bits)}" if bits else " (set manually)")
    if "altart" in groups:
        return "Alt Art, but not counted as an Art card"
    return ""
