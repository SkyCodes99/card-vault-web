"""What kind of card is this?  Groups of cards (Art cards, rarity groups, mechanics...) used by the Categories browser,
checklists ("card group is...") and the Checklists page.

"Art card" means a card whose WHOLE body is an illustration:
  * every card the database calls an Illustration Rare (IR) or Special Illustration Rare (SIR),
  * every Trainer Gallery / Galarian Gallery card,
  * every Alt Art card whose artwork runs to the edges of the card.
An Alt Art is recognised from its secret numbering (number higher than the printed set size) on a Pokémon card whose picture's
artwork reaches the card edge (see arttools.py).  You can always override a single card (Card type box in the card panel).
"""
import re
from collections import namedtuple

from . import altart_data, art_promos

VERSION = 15                  # bump whenever the classification rules change: the saved classification of every card is then rebuilt
ART_STD_THRESHOLD = 42.0     # edge-variation score (arttools.edge_score) from which artwork counts as reaching the card edge

Group = namedtuple("Group", "id label parent help")

GROUPS = [
    Group("art", "Scene art", None, "Cards where the picture is ONE illustrated scene that runs across the whole card - not just a Pokémon on a plain or textured background."),
    Group("ir", "Illustration Rare", "art", "Scene art of a regular Pokémon (Scarlet & Violet and later)."),
    Group("sir", "Special Illustration Rare", "art", "Scene art of an ex Pokémon or a Trainer (Scarlet & Violet and later)."),
    Group("art_trainer_sir", "Trainer Special Illustration Rare", "art", "Special Illustration Rares that show a Trainer."),
    Group("art_alt", "Alternate Art", "art", "A V, VMAX or Tag Team card with an alternate illustration covering the whole card. Taken from TCGplayer's own 'Alternate Art' labels, so rainbow, gold and plain secret cards are NOT in here."),
    Group("gallery", "Gallery cards", "art", "The numbered Trainer Gallery (TG) and Galarian Gallery (GG) cards inside a set."),
    Group("tg", "Trainer Gallery", "gallery", ""),
    Group("gg", "Galarian Gallery", "gallery", ""),
    Group("art_gallery_alt", "Gallery: alternate art", "art", "Gallery cards that are also an Alternate Art."),
    Group("art_gallery_plain", "Gallery: regular cards", "art", "Gallery cards that are not alternate arts (TG00-TG30, GG00-GG70)."),
    Group("art_pocket", "TCG Pocket illustrated cards", "art", "The illustrated cards of Pokémon TCG Pocket: the ★ / ★★ / ★★★ cards, the shiny cards and the Crown cards. (Their pictures are full illustrations, so they count as art.)"),
    Group("art_promo", "Art promos (full illustration)", "art", "Promo cards whose artwork runs to the edge of the card - alternate-art VMAX / V promos and illustration promos."),
    Group("art_pre_swsh", "Alternate Art before 2020", "art", "Alternate arts from the Sun & Moon era (before February 2020)."),
    Group("art_ancient", "Ancient Trait", "mechanic", "Cards with an Ancient Trait (found in various XY sets). A card rule, not artwork."),
    # rarities, from the easiest to the hardest to pull
    Group("r_common", "Common", "rarity", ""),
    Group("r_uncommon", "Uncommon", "rarity", ""),
    Group("r_rare", "Rare (non-holo)", "rarity", ""),
    Group("r_holo", "Holo Rare", "rarity", "Rare Holo / Holo Rare."),
    Group("r_lvx", "Rare Holo LV.X", "rarity", ""),
    Group("r_prime", "Rare PRIME", "rarity", ""),
    Group("r_legend", "LEGEND (two-part cards)", "rarity", ""),
    Group("r_star", "Pokémon ☆ / ★ (Star)", "rarity", "The older Pokémon-☆ cards."),
    Group("r_shining", "Shining Pokémon", "rarity", "Neo-era 'Shining' cards."),
    Group("r_prism", "Prism Star ◇", "rarity", ""),
    Group("r_delta", "Delta Species δ", "rarity", ""),
    Group("r_double", "Double Rare (ex)", "rarity", ""),
    Group("r_ultra", "Ultra Rare (Full Art Pokémon)", "rarity", "Full-art Pokémon: V, VMAX, VSTAR, GX, EX, ex, Tag Team, BREAK, Mega."),
    Group("r_fa_trainer", "Trainer Full Art", "rarity", "Full-art Trainer / Supporter cards."),
    Group("r_chr", "Character Rare (Japan)", "rarity", "Japanese Sword & Shield character-illustration cards - the older cousin of the Illustration Rare."),
    Group("r_csr", "Character Super Rare (Japan)", "rarity", "Japanese full-art character-illustration cards - the older cousin of the Special Illustration Rare."),
    Group("r_ir", "Illustration Rare", "rarity", ""),
    Group("r_sir", "Special Illustration Rare", "rarity", ""),
    Group("r_trainer_sir", "Trainer Special Illustration Rare", "rarity", ""),
    Group("r_ace", "ACE SPEC Rare", "rarity", ""),
    Group("r_radiant", "Radiant Rare", "rarity", ""),
    Group("r_amazing", "Amazing Rare", "rarity", ""),
    Group("r_shiny_rare", "Shiny Rare", "rarity", "Shiny Pokémon (Shining Fates, Hidden Fates, Paldean Fates...)."),
    Group("r_shiny_ultra", "Shiny Full Art / Ultra", "rarity", "Shiny Ultra Rare, Shiny V and Shiny VMAX."),
    Group("r_rainbow", "Rainbow Rare", "rarity", "Secret-numbered Pokémon V / VMAX / VSTAR / GX that are not alternate arts."),
    Group("r_gold", "Gold Rare (Trainer / Energy)", "rarity", "Secret-numbered Trainer and Energy cards with a gold design."),
    Group("r_hyper", "Hyper Rare (gold)", "rarity", ""),
    Group("r_bw", "Black White Rare", "rarity", ""),
    Group("r_secret", "Secret Rare (other)", "rarity", "Secret-numbered cards that fit none of the groups above."),
    Group("r_promo", "Promo", "rarity", ""),
    Group("r_kit", "Trainer Kit / unlabelled sets", "rarity", ""),
    Group("r_special", "Special (Classic Collection, Pikachu Rare...)", "rarity", "Every special reprint rarity together; each one also has its own group below."),
    Group("r_classic", "Classic Collection", "rarity", "The Classic Collection reprints (Celebrations and 30th Celebration)."),
    Group("r_pikachu", "Pikachu Rare", "rarity", ""),
    Group("r_futuristic", "Futuristic Rare", "rarity", ""),
    Group("r_rgb", "RGB Rare (unnumbered)", "rarity", "The three unnumbered Mew cards (Red, Green, Blue) of the 30th Celebration."),
    Group("r_mega_hyper", "Mega Hyper Rare", "rarity", "The Mega Evolution era's Hyper Rares (kept apart from the older gold Hyper Rares)."),
    Group("r_pk_diamond", "Pocket ◆ (1-4 diamond)", "rarity", ""),
    Group("r_pk_star", "Pocket ★ (1-3 star)", "rarity", ""),
    Group("r_pk_shiny", "Pocket Shiny", "rarity", ""),
    Group("r_pk_crown", "Pocket Crown ♛", "rarity", ""),
    Group("r_other", "Other / unlabelled", "rarity", ""),
    # families that overlap the groups above (kept so older checklists keep working)
    Group("f_ultra", "Ultra Rare family (any full art / ultra)", "family", "Ultra Rare, Full Art Trainer, Rainbow, Gold and the V / GX style rarities."),
    Group("f_shiny", "Shiny family (all shinies)", "family", "Every shiny rarity, including Pocket shinies."),
    Group("f_secret", "Secret family (secret / hyper / gold)", "family", "Secret Rare, Hyper Rare, Mega Hyper Rare, Black White Rare."),
    Group("f_pocket", "TCG Pocket (◆ ★ ♛)", "family", "Diamond, Star, Shiny and Crown rarities of Pokémon TCG Pocket."),
    Group("f_holo", "Holo family", "family", "Holo Rare, LV.X, PRIME, LEGEND."),
    # mechanics
    Group("m_ex", "Pokémon ex", "mechanic", ""),
    Group("m_gx", "GX", "mechanic", ""),
    Group("m_oldex", "EX (older)", "mechanic", ""),
    Group("m_v", "V", "mechanic", ""),
    Group("m_vmax", "VMAX", "mechanic", ""),
    Group("m_vstar", "VSTAR", "mechanic", ""),
    Group("m_break", "BREAK", "mechanic", ""),
    Group("m_mega", "Mega", "mechanic", ""),
    Group("m_tag", "Tag Team GX", "mechanic", ""),
    Group("m_primal", "Primal", "mechanic", ""),
    # card type
    Group("e_pre_swsh", "Before Sword & Shield (1999-2019)", "era", "Every card from the first Base Set up to the end of Sun & Moon - the whole older era in one place."),
    Group("e_wotc", "Original era (1999-2003)", "era", "Base Set, Jungle, Fossil, Gym, Neo, Legendary Collection and e-Card."),
    Group("e_ex", "EX era (2003-2007)", "era", "Ruby & Sapphire up to Power Keepers."),
    Group("e_dp", "Diamond & Pearl to HeartGold (2007-2011)", "era", "Diamond & Pearl, Platinum, HeartGold & SoulSilver and Call of Legends."),
    Group("e_bw", "Black & White (2011-2013)", "era", ""),
    Group("e_xy", "XY (2014-2016)", "era", ""),
    Group("e_sm", "Sun & Moon (2017-2019)", "era", ""),
    Group("e_swsh", "Sword & Shield (2020-2022)", "era", ""),
    Group("e_sv", "Scarlet & Violet (2023-2025)", "era", ""),
    Group("e_mega", "Mega Evolution (2025 on)", "era", ""),
    Group("e_misc", "Promos, kits & specials (any year)", "era", "McDonald's sets, Trainer Kits, POP series and other special releases."),
    Group("c_pokemon", "Pokémon", "ctype", ""),
    Group("c_trainer", "Trainer", "ctype", ""),
    Group("c_energy", "Energy", "ctype", ""),
]
_POKEMON_SECTIONS = [("art", None), ("rarity", "Rarities"), ("family", "Rarity families"), ("mechanic", "By card mechanic"), ("era", "By era"), ("ctype", "By card type")]
SECTIONS = list(_POKEMON_SECTIONS)            # kept up to date by configure()
LABEL = {g.id: g.label for g in GROUPS}
GROUP_IDS = {g.id for g in GROUPS}
BUILTIN_IDS = frozenset(GROUP_IDS)

_state = {"pokemon": True, "dynamic": [], "custom": [], "custom_meta": {}, "type_label": "Type", "order": ()}


def configure(pokemon, dynamic=(), custom=(), custom_meta=None, type_label="Type", rarity_order=()):
    """Called by the Vault: which groups exist for the open game.  Pokémon = the built-in groups; other games = groups made from their
    own rarities / card types / colours; plus the user's own categories (dev tools) for every game."""
    _state.update(pokemon=bool(pokemon), dynamic=list(dynamic), custom=list(custom), custom_meta=dict(custom_meta or {}),
                  type_label=type_label, order=tuple(rarity_order))
    secs = list(_POKEMON_SECTIONS) if pokemon else [("rarity", "By rarity"), ("ctype", "By card type"), ("color", f"By {type_label.lower()}")]
    if custom:
        secs.append(("custom", "My categories"))
    SECTIONS[:] = secs
    allg = groups()
    LABEL.clear()
    LABEL.update({g.id: g.label for g in allg})
    GROUP_IDS.clear()
    GROUP_IDS.update(g.id for g in allg)


def groups():
    return (list(GROUPS) if _state["pokemon"] else []) + _state["dynamic"] + _state["custom"]


def is_pokemon():
    return _state["pokemon"]


def custom_meta(gid):
    return _state["custom_meta"].get(gid)


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")


def dynamic_groups(rarities, card_types, colours, type_label="Type"):
    """Groups for a non-Pokémon game, made from the values found in its catalogue."""
    out = [Group("r:" + _slug(r), r, "rarity", "") for r in list(rarities)[:150] if r]          # a safety cap: a game with thousands of distinct values must not make thousands of boxes
    out += [Group("t:" + _slug(t), t, "ctype", "") for t in list(card_types)[:150] if t]
    out += [Group("k:" + _slug(k), k, "color", "") for k in list(colours)[:150] if k]
    return out


def classify_generic(c):
    g = set()
    if c.get("rarity"):
        g.add("r:" + _slug(c["rarity"]))
    if c.get("category"):
        g.add("t:" + _slug(c["category"]))
    for part in (c.get("types") or "").split(","):
        if part.strip():
            g.add("k:" + _slug(part.strip()))
    return frozenset(g)

_RARITY = {
    "common": "r_common", "uncommon": "r_common", "rare": "r_rare",
    "rare holo": "r_holo", "holo rare": "r_holo", "rare holo lv.x": "r_holo", "rare prime": "r_holo", "legend": "r_holo",
    "double rare": "r_double",
    "ultra rare": "r_ultra", "holo rare v": "r_ultra", "holo rare vmax": "r_ultra", "holo rare vstar": "r_ultra",
    "ace spec rare": "r_ace", "radiant rare": "r_radiant", "amazing rare": "r_radiant",
    "shiny rare": "r_shiny", "shiny rare v": "r_shiny", "shiny rare vmax": "r_shiny", "shiny ultra rare": "r_shiny",
    "secret rare": "r_secret", "hyper rare": "r_secret", "mega hyper rare": "r_secret", "black white rare": "r_secret",
    "promo": "r_promo",
    "one diamond": "r_pocket", "two diamond": "r_pocket", "three diamond": "r_pocket", "four diamond": "r_pocket",
    "one star": "r_pocket", "two star": "r_pocket", "three star": "r_pocket", "one shiny": "r_pocket", "two shiny": "r_pocket", "crown": "r_pocket",
}
_ERA = {"base": "e_wotc", "gym": "e_wotc", "neo": "e_wotc", "legendary collection": "e_wotc", "e-card": "e_wotc", "ex": "e_ex", "diamond & pearl": "e_dp", "platinum": "e_dp",
        "heartgold & soulsilver": "e_dp", "call of legends": "e_dp", "black & white": "e_bw", "xy": "e_xy", "sun & moon": "e_sm", "sword & shield": "e_swsh", "scarlet & violet": "e_sv",
        "mega evolution": "e_mega", "pop": "e_misc", "trainer kits": "e_misc", "miscellaneous": "e_misc", "mcdonald's collection": "e_misc", "prize packs": "e_misc", "world championship decks": "e_misc"}
_PRE_SWSH = {"e_wotc", "e_ex", "e_dp", "e_bw", "e_xy", "e_sm"}
_MECH = [("m_vmax", re.compile(r"\bVMAX\b")), ("m_vstar", re.compile(r"\bVSTAR\b")), ("m_v", re.compile(r"\bV\b(?!-)")),
         ("m_ex", re.compile(r"\bex\b")), ("m_oldex", re.compile(r"\bEX\b")), ("m_gx", re.compile(r"\bGX\b")),
         ("m_break", re.compile(r"\bBREAK\b")), ("m_mega", re.compile(r"^(Mega|M)\s|\bMega\b"))]


# before Scarlet & Violet the alternate arts are labelled with these rarities; from Scarlet & Violet on they are IR / SIR
_ALT_RARITIES_OLD = {"ultra rare", "holo rare v", "holo rare vmax", "holo rare vstar", "rare holo"}


# usual order of rarities from the easiest to the hardest to pull; used to order the rarity sections of a set
RARITY_ORDER = ["common", "uncommon", "rare", "rare holo", "holo rare", "classic collection", "pikachu rare", "futuristic rare", "rare holo lv.x", "rare prime", "legend",
                "double rare", "ace spec rare", "holo rare v", "holo rare vmax", "holo rare vstar", "ultra rare", "triple rare", "full art trainer", "radiant rare", "amazing rare",
                "shiny rare", "shiny rare v", "shiny rare vmax", "shiny ultra rare", "illustration rare", "character rare", "special illustration rare", "character super rare", "secret rare", "hyper rare",
                "black white rare", "mega hyper rare", "promo",
                "one diamond", "two diamond", "three diamond", "four diamond", "one star", "two star", "three star", "one shiny", "two shiny", "crown"]
# the label a card is filed under when a set is shown split by rarity (more exact than the database's own word)
LABEL_ORDER = ["Common", "Uncommon", "Rare", "Holo Rare", "Delta Species", "Prism Star", "Pokémon Star", "Shining Pokémon", "Rare Holo LV.X", "Rare PRIME", "LEGEND",
               "Classic Collection / special", "Double Rare", "ACE SPEC Rare", "Ultra Rare - EX", "Ultra Rare - ex", "Ultra Rare - GX", "Ultra Rare - Tag Team GX",
               "Ultra Rare - BREAK", "Ultra Rare - V", "Ultra Rare - VMAX", "Ultra Rare - VSTAR", "Ultra Rare - Mega / Primal", "Ultra Rare", "Trainer Full Art",
               "Radiant Rare", "Amazing Rare", "Shiny Rare", "Shiny Full Art / Ultra", "Character Rare", "Illustration Rare", "Character Super Rare", "Special Illustration Rare", "Trainer Special Illustration Rare",
               "Alt Art (V / VMAX / VSTAR / ex)", "Rainbow Rare", "Gold Rare (Trainer / Energy)", "Secret Rare", "Hyper Rare", "Mega Hyper Rare", "Black White Rare", "Promo", "Trainer Kit",
               "Pocket ◆", "Pocket ◆◆", "Pocket ◆◆◆", "Pocket ◆◆◆◆", "Pocket ★", "Pocket ★★", "Pocket ★★★", "Pocket Shiny", "Pocket Shiny ★★", "Pocket Crown", "Unlabelled"]
_RANK = {r: i for i, r in enumerate(RARITY_ORDER)}


def rarity_rank(rarity):
    low = (rarity or "").lower()
    if not _state["pokemon"]:
        order = [o.lower() for o in _state["order"]]
        for i, o in enumerate(order):                      # 'Common 1-Star' ranks with 'Common'
            if low == o or low.startswith(o + " "):
                return i
        return len(order)
    return _RANK.get(low, len(RARITY_ORDER))


_FAMILY = {"r_holo": {"f_holo"}, "r_lvx": {"f_holo"}, "r_prime": {"f_holo"}, "r_legend": {"f_holo"}, "r_ultra": {"f_ultra"}, "r_fa_trainer": {"f_ultra"},
           "r_rainbow": {"f_secret"}, "r_gold": {"f_secret"}, "r_hyper": {"f_secret"}, "r_mega_hyper": {"f_secret"}, "r_bw": {"f_secret"}, "r_secret": {"f_secret"},
           "r_shiny_rare": {"f_shiny"}, "r_shiny_ultra": {"f_shiny"}, "r_pk_shiny": {"f_shiny", "f_pocket"}, "r_pk_diamond": {"f_pocket"}, "r_pk_star": {"f_pocket"}, "r_pk_crown": {"f_pocket"}}
_RX_STAR = re.compile(r"[★☆]\s*$|\s[★☆]\s")
_RX_TAG = re.compile(r"&.*\bGX\b")
_PK_DIAMOND = {"one diamond": "◆", "two diamond": "◆◆", "three diamond": "◆◆◆", "four diamond": "◆◆◆◆"}
_PK_STAR = {"one star": "★", "two star": "★★", "three star": "★★★"}


def rarity_groups(c, low, mech):
    """-> (set of rarity group ids, exact label).  Uses the database rarity, the card's name (V, GX, ex, ☆ ...), its kind (Pokémon / Trainer /
    Energy) and the set, because the database lumps many different rarities under 'Ultra Rare' and 'Secret Rare'."""
    name = c.get("name") or ""
    cat = (c.get("category") or "").lower()
    trainer, energy = cat == "trainer", cat == "energy"
    sid = (c.get("set_id") or "")
    g = set()
    label = "Unlabelled"
    if low in ("common", "uncommon"):
        g.add("r_" + low)
        label = low.capitalize()
    elif low == "rare":
        g.add("r_rare")
        label = "Rare"
    elif low in ("rare holo", "holo rare"):
        g |= {"r_holo", "f_holo"}
        label = "Holo Rare"
    elif low == "rare holo lv.x":
        g |= {"r_lvx", "f_holo"}
        label = "Rare Holo LV.X"
    elif low == "rare prime":
        g |= {"r_prime", "f_holo"}
        label = "Rare PRIME"
    elif low == "legend":
        g |= {"r_legend", "f_holo"}
        label = "LEGEND"
    elif low == "double rare":
        g.add("r_double")
        label = "Double Rare"
    elif low == "character rare":
        g.add("r_chr")
        label = "Character Rare"
    elif low == "character super rare":
        g.add("r_csr")
        label = "Character Super Rare"
    elif low in ("ultra rare", "triple rare", "holo rare v", "holo rare vmax", "holo rare vstar", "full art trainer"):
        if trainer or low == "full art trainer":
            g |= {"r_fa_trainer", "f_ultra"}
            label = "Trainer Full Art"
        else:
            g |= {"r_ultra", "f_ultra"}
            label = ("Ultra Rare - VMAX" if "m_vmax" in mech else "Ultra Rare - VSTAR" if "m_vstar" in mech else "Ultra Rare - V" if "m_v" in mech
                     else "Ultra Rare - Tag Team GX" if _RX_TAG.search(name) else "Ultra Rare - GX" if "m_gx" in mech
                     else "Ultra Rare - BREAK" if "m_break" in mech else "Ultra Rare - Mega / Primal" if (mech & {"m_mega", "m_primal"})
                     else "Ultra Rare - ex" if "m_ex" in mech else "Ultra Rare - EX" if "m_oldex" in mech else "Ultra Rare")
    elif low == "illustration rare":
        g.add("r_ir")
        label = "Illustration Rare"
    elif low == "special illustration rare":
        g.add("r_sir")
        label = "Special Illustration Rare"
        if trainer:
            g |= {"r_trainer_sir", "art_trainer_sir"}
            label = "Trainer Special Illustration Rare"
    elif low in ("ace spec rare", "rare ace"):
        g.add("r_ace")
        label = "ACE SPEC Rare"
    elif low == "prism rare":
        g.add("r_prism")
        label = "Prism Star"
    elif low == "rare break":
        g |= {"r_ultra", "f_ultra"}
        label = "Ultra Rare - BREAK"
    elif low == "radiant rare":
        g.add("r_radiant")
        label = "Radiant Rare"
    elif low == "amazing rare":
        g.add("r_amazing")
        label = "Amazing Rare"
    elif low in ("shiny rare", "shiny rare v", "shiny rare vmax", "shiny ultra rare"):
        g |= {"f_shiny"}
        if low == "shiny rare":
            g.add("r_shiny_rare")
            label = "Shiny Rare"
        else:
            g.add("r_shiny_ultra")
            label = "Shiny Full Art / Ultra"
    elif low == "secret rare":
        g.add("f_secret")
        if trainer or energy:
            g |= {"r_gold"}
            label = "Gold Rare (Trainer / Energy)"
        elif mech & {"m_v", "m_vmax", "m_vstar", "m_gx", "m_ex", "m_oldex"}:
            g.add("r_rainbow")
            label = "Rainbow Rare"
        else:
            g.add("r_secret")
            label = "Secret Rare"
    elif low == "hyper rare":
        g |= {"r_hyper", "f_secret"}
        label = "Hyper Rare"
    elif low == "rgb rare":
        g |= {"r_rgb", "f_secret"}
        label = "RGB Rare"
    elif low == "mega hyper rare":
        g |= {"r_mega_hyper", "f_secret"}
        label = "Mega Hyper Rare"
    elif low == "black white rare":
        g |= {"r_bw", "f_secret"}
        label = "Black White Rare"
    elif low == "promo":
        g.add("r_promo")
        label = "Promo"
    elif low in ("classic collection", "pikachu rare", "futuristic rare"):
        g |= {"r_special", {"classic collection": "r_classic", "pikachu rare": "r_pikachu", "futuristic rare": "r_futuristic"}[low]}
        label = "Classic Collection / special"
    elif low in _PK_DIAMOND:
        g |= {"r_pk_diamond", "f_pocket"}
        label = "Pocket " + _PK_DIAMOND[low]
    elif low in _PK_STAR:
        g |= {"r_pk_star", "f_pocket"}
        label = "Pocket " + _PK_STAR[low]
    elif low in ("one shiny", "two shiny"):
        g |= {"r_pk_shiny", "f_pocket", "f_shiny"}
        label = "Pocket Shiny" + (" ★★" if low == "two shiny" else "")
    elif low == "crown":
        g |= {"r_pk_crown", "f_pocket"}
        label = "Pocket Crown"
    else:                                                    # no rarity in the database: use the set / kind of card
        if sid.startswith("tk-") or sid in ("xy0", "2021swsh"):
            g.add("r_kit")
            label = "Trainer Kit"
        elif (sid.lower() in ("p-a", "30th-c", "mfb", "ru1", "bog", "fut2020", "ex5.5") or re.match(r"^20\d\d(bw|xy|sm|swsh|sv)$", sid.lower())
              or sid.lower().startswith(("promo", "svp", "swshp", "smp", "xyp", "bwp", "hsp"))):
            g.add("r_promo")
            label = "Promo"
        else:
            g.add("r_other")
    # traits that matter to collectors, whatever the database says
    if re.match(r"^Shining ", name):
        g |= {"r_shining"}
        label = "Shining Pokémon"
    if _RX_STAR.search(name) and cat.startswith("pok"):
        g.add("r_star")
        label = "Pokémon Star"
    if "◇" in name or "◊" in name:
        g.add("r_prism")
        label = "Prism Star"
    if "δ" in name or "Delta Species" in name:
        g.add("r_delta")
        if label in ("Common", "Uncommon", "Rare", "Holo Rare"):
            label = "Delta Species"
    return g, label


# ---- illustrators: the same person is sometimes typed two ways ('takuyoa' / 'Takuyoa', 'Miki Tanaka' / 'MikiTanaka').  They are merged under the most common spelling.
_ILL_ALIAS = {}
_ILL_SETS = {}
_NO_ILLUSTRATOR = {"n/a", "na", "unknown", "none", "-", "?", "tbd"}


def illustrator_key(name):
    import unicodedata
    n = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]", "", n)


def set_illustrator_aliases(counts):
    """counts = {spelling: how many cards}.  Every spelling of a name maps to the one most cards use."""
    best = {}
    for n, k in counts.items():
        key = illustrator_key(n)
        if key and (key not in best or (k, len(n)) > (counts[best[key]], len(best[key]))):
            best[key] = n
    _ILL_ALIAS.clear()
    _ILL_ALIAS.update(best)
    _ILL_SETS.clear()


def canon_illustrator_set(names):
    """The canonical spellings of a clause's illustrator list (cached; cleared whenever the spellings are re-read)."""
    key = tuple(names)
    hit = _ILL_SETS.get(key)
    if hit is None:
        hit = _ILL_SETS[key] = frozenset(canon_illustrator(n) for n in key)
    return hit


def canon_illustrator(name):
    n = " ".join((name or "").split())
    if n.lower() in _NO_ILLUSTRATOR:
        return ""
    return _ILL_ALIAS.get(illustrator_key(n), n)


# a few cards the database has no rarity for, where the printed rarity is certain
_RARITY_PATCH = {"xy8-146a": "uncommon"}


def is_secret_numbered(c):
    lid = str(c.get("local_id", ""))
    return lid.isdigit() and bool(c.get("official")) and int(lid) > c["official"]


def card_rarity_label(c, groups=None):
    """The exact rarity label of a light card dict (see rarity_groups) - used to file cards under the right heading."""
    if groups and "altart" in groups:
        return "Alt Art (V / VMAX / VSTAR / ex)"
    mech = {gid for gid, rx in _MECH if rx.search(c.get("name") or "")}
    if _RX_TAG.search(c.get("name") or ""):
        mech.add("m_tag")
    if re.match(r"^Primal ", c.get("name") or ""):
        mech.add("m_primal")
    return rarity_groups(c, (c.get("rarity") or "").lower(), mech)[1]


def cool_score(c):
    """How striking a card is (used to pick the picture that stands for an illustrator, a Pokémon or a rarity)."""
    g = c.get("groups") or ()
    score = 0
    for gid, pts in (("sir", 100), ("art_alt", 92), ("altart", 90), ("ir", 80), ("r_hyper", 74), ("r_mega_hyper", 74), ("r_rainbow", 72), ("r_gold", 60), ("r_shiny_ultra", 70), ("r_shiny_rare", 62),
                     ("gallery", 66), ("r_radiant", 64), ("r_amazing", 64), ("r_ultra", 55), ("r_star", 58), ("r_shining", 58), ("m_vmax", 50), ("m_vstar", 48), ("r_holo", 30),
                     ("r_double", 40), ("r_ace", 35), ("r_pk_crown", 45), ("r_pk_star", 25)):
        if gid in g:
            score = max(score, pts)
    return score


def label_rank(label):
    try:
        return LABEL_ORDER.index(label)
    except ValueError:
        return len(LABEL_ORDER)


def classify(c, tag=None, threshold=None):
    """The set of group ids a card (light dict from Vault.card_index) belongs to.

    `tag` = the user's corrections for this card: {'art': 'yes'|'no', 'altart': 'yes'|'no', '<group id>': 'yes'|'no'}.
    `threshold` = the edge score from which artwork counts as reaching the card edge (learned from the user's corrections)."""
    tag = tag or {}
    thr = ART_STD_THRESHOLD if threshold is None else threshold
    g = set()
    low = _RARITY_PATCH.get(c.get("id"), (c.get("rarity") or "").lower())
    if "special illustration" in low or low == "character super rare":
        g.add("sir")
    elif "illustration" in low or low == "character rare":
        g.add("ir")
    if c.get("id") in art_promos.FULL_ART:
        g |= {"r_ultra", "f_ultra"}                              # a full-art promo: the Full Art categories, not Art
    if c.get("id") in art_promos.ILLUSTRATION:
        g.add("ir")                                              # a promo / reprint that is a scene illustration: filed with the Illustration Rares, so lists that pick that category include it
    lid = str(c.get("local_id", "")).upper()
    sid = c.get("set_id") or ""
    if lid.startswith("TG") or sid.endswith("tg"):
        g |= {"gallery", "tg"}
    elif lid.startswith("GG") or sid.endswith("gg"):
        g |= {"gallery", "gg"}
    name = c.get("name") or ""
    for gid, rx in _MECH:
        if rx.search(name):
            g.add(gid)
    if _RX_TAG.search(name):
        g.add("m_tag")
    if re.match(r"^Primal ", name):
        g.add("m_primal")
    era = _ERA.get((c.get("serie") or "").strip().lower())
    if era:
        g.add(era)
        if era in _PRE_SWSH:
            g.add("e_pre_swsh")
    cat = (c.get("category") or "").lower()
    if cat.startswith("pok"):
        g.add("c_pokemon")
    elif cat == "trainer":
        g.add("c_trainer")
    elif cat == "energy":
        g.add("c_energy")
    rg, _label = rarity_groups(c, low, {x for x in g if x.startswith("m_")})
    g |= rg
    if c.get("ancient"):
        g |= {"art_ancient"}

    # explicit corrections for ordinary groups (admin page)
    for gid, val in tag.items():
        if gid in BUILTIN_IDS and gid not in ("art", "altart", "art_alt"):
            if val == "yes":
                if gid.startswith("r_"):
                    g -= {x for x in g if x.startswith("r_")}
                g.add(gid)
            elif val == "no":
                g.discard(gid)
    g -= {x for x in g if x.startswith("f_")}
    for gid in [x for x in g if x in _FAMILY]:                 # the overlapping families follow whatever rarity group the card ended up in
        g |= _FAMILY[gid]
    if g & {"tg", "gg"}:
        g.add("gallery")
    if tag.get("gallery") == "no":
        g -= {"gallery", "tg", "gg"}

    # an Alternate Art is a card TCGplayer itself labels "Alternate Art" (see tools/build_altart.py).  The old guess - "numbered past the set total and the picture reaches
    # the card edge" - also caught every rainbow / shiny / Mega EX full art, which have no scene at all.
    auto_alt = bool((c.get("id") in altart_data.IDS or c.get("id") in art_promos.ALT) and not (g & {"ir", "sir"}))
    alt = {"yes": True, "no": False}.get(tag.get("altart"), auto_alt)
    if alt:
        g.add("altart")
        g -= {"r_rainbow", "r_secret"}                        # an alternate art is not a rainbow / plain secret rare
    pocket_art = bool(g & {"r_pk_star", "r_pk_shiny", "r_pk_crown"})
    promo_art = c.get("id") in art_promos.IDS                    # promos / reprints that are full illustrations (see art_promos.py)
    art = bool(g & {"ir", "sir", "gallery"}) or alt or pocket_art or promo_art
    forced = {"yes": True, "no": False}.get(tag.get("art"))
    if forced is not None:
        art = forced
    if art:
        g.add("art")
        if alt:
            g.add("art_alt")
        if pocket_art:
            g.add("art_pocket")
        if promo_art:
            g.add("art_promo")
        if g & {"tg", "gg"}:
            g.add("art_gallery_alt" if (alt or g & {"m_v", "m_vmax", "m_vstar"}) else "art_gallery_plain")
        if (c.get("release_date") or "9999") < "2020-02-07" and not (g & {"ir", "sir"}):
            g.add("art_pre_swsh")
    return frozenset(g)


def explain(c, groups):
    """One plain-language line for the card panel."""
    bits = [LABEL[x] for x in ("ir", "sir", "tg", "gg", "art_alt") if x in groups and x in LABEL]
    if "art" in groups:
        return "Scene art" + (f" - {', '.join(bits)}" if bits else " (set manually)")
    if "altart" in groups:
        return "Alternate Art, but not counted as scene art"
    return ""
