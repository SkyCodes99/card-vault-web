"""Local accounts, encryption and the lock screen backend."""
