"""Talking to the (optional) account service for emailed-code password reset.  The only online part of the security system, and only used
if the person turned 'Email reset' on."""
import base64
import re
from urllib.parse import urlparse

import requests

UA = "CollectEmAll/3 (account service)"


class ResetError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


def check_url(url):
    u = urlparse((url or "").strip())
    local = u.hostname in ("127.0.0.1", "localhost")
    if u.scheme != "https" and not (u.scheme == "http" and local):
        raise ResetError("The account service address must start with https:// (a plain address is only allowed on this computer).", "bad_url")
    if not u.hostname:
        raise ResetError("That isn't a web address.", "bad_url")
    return url.strip().rstrip("/")


def mask(email):
    m = re.match(r"^(.)([^@]*)(@.+)$", email or "")
    return f"{m.group(1)}{'*' * min(6, len(m.group(2)))}{m.group(3)}" if m else ""


def post(url, path, body, timeout=20):
    base = check_url(url)
    try:
        r = requests.post(base + path, json=body, timeout=timeout, headers={"User-Agent": UA})
    except requests.RequestException:
        raise ResetError("Couldn't reach the account service. Check your internet connection and the service address.", "offline")
    try:
        data = r.json()
    except ValueError:
        data = {}
    if r.status_code != 200:
        raise ResetError(data.get("error") or f"The service answered {r.status_code}.", data.get("code"))
    return data


def b64(b):
    return base64.b64encode(b).decode()


def unb64(s):
    return base64.b64decode(s)
