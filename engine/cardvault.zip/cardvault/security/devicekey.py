"""'Stay signed in' on the Windows desktop app: the key that opens the collection is kept in a file that only THIS Windows user, on THIS computer, can
decrypt (Windows' own data-protection API, DPAPI).  Nothing readable is stored; signing out deletes the file; changing the password makes it useless."""
import os
import sys

ENTROPY = b"collect-em-all/device/v1"


def supported():
    return sys.platform.startswith("win")


def _call(fn_name, data, flags=0):
    import ctypes
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def blob(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return Blob(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    inb, keep1 = blob(data)
    ent, keep2 = blob(ENTROPY)
    out = Blob()
    fn = getattr(crypt32, fn_name)
    if not fn(ctypes.byref(inb), None, ctypes.byref(ent), None, None, flags, ctypes.byref(out)):
        raise OSError("Windows could not protect / open the saved sign-in")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))


def protect(data):
    return _call("CryptProtectData", data, 1)          # 1 = CRYPTPROTECT_UI_FORBIDDEN (never pop a window)


def unprotect(blob):
    return _call("CryptUnprotectData", blob, 1)


def path_for(data_dir, pid):
    return os.path.join(data_dir, f"device_{pid}.bin")


def saved_profiles(data_dir):
    try:
        return [n[len("device_"):-len(".bin")] for n in os.listdir(data_dir) if n.startswith("device_") and n.endswith(".bin")]
    except OSError:
        return []
