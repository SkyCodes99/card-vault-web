"""'Stay signed in' on the Windows desktop app: the key that opens the collection is kept in a file that only THIS Windows user, on THIS computer, can
decrypt (Windows' own data-protection API, DPAPI).  Nothing readable is stored; signing out deletes the file; changing the password makes it useless."""
import os
import sys

ENTROPY = b"collect-em-all/device/v1"


def supported():
    return sys.platform.startswith("win")


def _call(fn_name, data, flags=0):
    import ctypes
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def blob(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return Blob(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    inb, keep1 = blob(data)
    ent, keep2 = blob(ENTROPY)
    out = Blob()
    fn = getattr(crypt32, fn_name)
    if not fn(ctypes.byref(inb), None, ctypes.byref(ent), None, None, flags, ctypes.byref(out)):
        raise OSError("Windows could not protect / open the saved sign-in")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))


def protect(data):
    return _call("CryptProtectData", data, 1)          # 1 = CRYPTPROTECT_UI_FORBIDDEN (never pop a window)


def unprotect(blob):
    return _call("CryptUnprotectData", blob, 1)


def path_for(data_dir, pid):
    return os.path.join(data_dir, f"device_{pid}.bin")


# An update restarts the app: the open collection is handed to the new version once, so nobody signs in again after an update (owner, 2026-11-14:
# "after updates, the user should still be logged in on the app and web").  Same protection as 'Stay signed in'; used once and deleted, and only within these minutes.
# The update window freshens the file's time right before it starts the new version (--handoff), so a slow download does not use these minutes up; 60, not 15, for an older window.
HANDOFF_MINUTES = 60


def handoff_path(data_dir, pid):
    return os.path.join(data_dir, f"device_{pid}.handoff")          # (not .bin: saved_profiles() must never take it for 'Stay signed in')


def handoff_profiles(data_dir):
    try:
        return [n[len("device_"):-len(".handoff")] for n in os.listdir(data_dir) if n.startswith("device_") and n.endswith(".handoff")]
    except OSError:
        return []


def saved_profiles(data_dir):
    try:
        return [n[len("device_"):-len(".bin")] for n in os.listdir(data_dir) if n.startswith("device_") and n.endswith(".bin")]
    except OSError:
        return []
