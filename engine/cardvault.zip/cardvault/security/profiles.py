"""Local accounts ("profiles"): each has its own password, its own encrypted collection and its own secrets (GitHub token, sync key).

Key layout (nothing secret is ever stored in the clear):
  password  --scrypt--> key that wraps the profile's random data key (DEK)
  recovery  --scrypt--> key that also wraps the same DEK  (so a forgotten password can be reset without losing data)
  DEK encrypts  collection.db.enc, secrets.enc and every backup (AES-256-GCM)

While a profile is unlocked the collection is decrypted into a private session folder (under your Windows profile, wiped when you lock or
quit) and encrypted back to disk a few seconds after every change."""
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
import uuid

from . import crypto
from .crypto import CryptoError

PROFILES_FILE = "profiles.json"
ENC_DB, ENC_SECRETS = "collection.db.enc", "secrets.enc"
FREE_TRIES = 5


class AuthError(Exception):
    def __init__(self, code, message, retry_after=0):
        super().__init__(message)
        self.code, self.retry_after = code, retry_after


def session_root():
    """Private folder for the decrypted working copy: LOCALAPPDATA (Windows), the per-user runtime / cache folder elsewhere."""
    if os.environ.get("LOCALAPPDATA"):
        base = os.environ["LOCALAPPDATA"]
    elif sys.platform == "darwin":
        base = os.path.join(os.path.expanduser("~"), "Library", "Caches")
    else:
        base = os.environ.get("XDG_RUNTIME_DIR") or os.environ.get("XDG_CACHE_HOME") or os.path.join(os.path.expanduser("~"), ".cache")
    root = os.path.join(base, "Pokemon Card Vault", "session")
    os.makedirs(root, exist_ok=True)
    try:
        os.chmod(root, 0o700)                    # nobody else on the machine may even list it
    except OSError:
        pass
    return root


def _atomic_write(path, data):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


class Session:
    """An unlocked profile."""

    def __init__(self, mgr, rec, dek):
        self.mgr, self.rec, self.dek = mgr, rec, dek
        self.pid, self.name = rec["id"], rec["name"]
        self.dir = os.path.join(mgr.data_dir, "profiles", self.pid)
        os.makedirs(self.dir, exist_ok=True)
        self.enc_path = os.path.join(self.dir, ENC_DB)
        self.secrets_path = os.path.join(self.dir, ENC_SECRETS)
        self.work = os.path.join(session_root(), f"{self.pid}-{uuid.uuid4().hex[:8]}")
        self.db_path = os.path.join(self.work, "collection.db")
        self._lock = threading.RLock()
        self._secrets = None
        self.locked = False
        self.dirty_since = 0.0
        self._recover_crash()
        self._open_work()

    # ---- encrypted files
    def seal(self, data, purpose):
        return crypto.seal(self.dek, data, f"{self.pid}:{purpose}")

    def open(self, blob, purpose):
        return crypto.open_sealed(self.dek, blob, f"{self.pid}:{purpose}")

    # ---- the working copy of the collection
    def _recover_crash(self):
        """A previous run may have crashed before saving: keep any newer working copy rather than losing those changes."""
        root = session_root()
        for name in os.listdir(root):
            if not name.startswith(self.pid + "-"):
                continue
            p = os.path.join(root, name)
            db = os.path.join(p, "collection.db")
            try:
                if os.path.exists(db) and (not os.path.exists(self.enc_path) or os.path.getmtime(db) >= os.path.getmtime(self.enc_path) - 1):
                    self._encrypt_db_file(db)
            except Exception:  # noqa: BLE001 - a damaged leftover must not block signing in
                pass
            crypto.wipe_tree(p)

    def _open_work(self):
        os.makedirs(self.work, exist_ok=True)
        try:
            os.chmod(self.work, 0o700)
        except OSError:
            pass
        if os.path.exists(self.enc_path):
            with open(self.enc_path, "rb") as f:
                plain = self.open(f.read(), "collection")
            with open(self.db_path, "wb") as f:
                f.write(plain)

    def _encrypt_db_file(self, plain_path):
        """Consistent snapshot of a SQLite file (includes its WAL), encrypted to collection.db.enc.  Keeps one previous version."""
        fd, tmp = tempfile.mkstemp(suffix=".db", dir=os.path.dirname(plain_path))
        os.close(fd)
        try:
            src = sqlite3.connect(plain_path)
            dst = sqlite3.connect(tmp)
            try:
                src.backup(dst)
            finally:
                dst.close()
                src.close()
            with open(tmp, "rb") as f:
                blob = self.seal(f.read(), "collection")
        finally:
            crypto.wipe_file(tmp)
        if os.path.exists(self.enc_path):
            try:
                shutil.copyfile(self.enc_path, self.enc_path + ".prev")
            except OSError:
                pass
        _atomic_write(self.enc_path, blob)

    def persist(self):
        """Write the current collection to disk (encrypted).  Safe to call from any thread."""
        with self._lock:
            if self.locked or not os.path.exists(self.db_path):
                return
            self._encrypt_db_file(self.db_path)
            self.dirty_since = 0.0

    def lock(self):
        """Save, then remove every decrypted copy and forget the key."""
        with self._lock:
            if self.locked:
                return
            try:
                self.persist()
            finally:
                self.locked = True
                crypto.wipe_tree(self.work)
                self.dek = b"\x00" * 32
                self._secrets = None

    # ---- secrets (GitHub token, sync key, per-profile settings, security log)
    def _load_secrets(self):
        if self._secrets is None:
            if os.path.exists(self.secrets_path):
                with open(self.secrets_path, "rb") as f:
                    self._secrets = json.loads(self.open(f.read(), "secrets").decode("utf-8"))
            else:
                self._secrets = {}
        return self._secrets

    def _save_secrets(self):
        _atomic_write(self.secrets_path, self.seal(json.dumps(self._secrets).encode("utf-8"), "secrets"))

    def get(self, key, default=None):
        with self._lock:
            return self._load_secrets().get(key, default)

    def set(self, key, value):
        with self._lock:
            s = self._load_secrets()
            if value is None:
                s.pop(key, None)
            else:
                s[key] = value
            self._save_secrets()

    def log_event(self, kind, detail=""):
        with self._lock:
            s = self._load_secrets()
            log = s.setdefault("security_log", [])
            log.append({"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "kind": kind, "detail": detail})
            del log[:-200]
            self._save_secrets()

    def security_log(self):
        return list(reversed(self.get("security_log", [])))

    # ---- backups: always encrypted
    def backup_dir(self):
        d = os.path.join(self.dir, "backups")
        os.makedirs(d, exist_ok=True)
        return d

    def write_backup(self, plain_path, dest_dir, name):
        with open(plain_path, "rb") as f:
            blob = self.seal(f.read(), "backup")
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, name + ".enc")
        _atomic_write(dest, blob)
        return dest

    def read_backup(self, path):
        """Decrypt a backup into the private working folder; returns the plain file path (wipe it when done)."""
        with open(path, "rb") as f:
            plain = self.open(f.read(), "backup")
        out = os.path.join(self.work, "restore-" + uuid.uuid4().hex[:6] + ".db")
        with open(out, "wb") as f:
            f.write(plain)
        return out

    # ---- passwords
    def change_password(self, old, new):
        self.mgr.verify_password(self.pid, old, count=True)
        problems = crypto.check_password(new, self.name)
        if problems:
            raise AuthError("weak_password", problems[0])
        self.mgr._rewrap(self.rec, self.dek, new)
        self.log_event("password_changed")

    def new_recovery_key(self, password):
        self.mgr.verify_password(self.pid, password, count=True)
        key = self.mgr._set_recovery(self.rec, self.dek)
        self.log_event("recovery_key_renewed")
        return key


class AuthManager:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.path = os.path.join(data_dir, PROFILES_FILE)
        self.lock = threading.RLock()
        os.makedirs(data_dir, exist_ok=True)

    # ---- the profile index
    def _read(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {"version": 1, "profiles": []}

    def _write(self, data):
        _atomic_write(self.path, json.dumps(data, indent=1).encode("utf-8"))

    def _rec(self, pid):
        for r in self._read()["profiles"]:
            if r["id"] == pid:
                return r
        raise AuthError("unknown_profile", "That account doesn't exist.")

    def _save_rec(self, rec):
        data = self._read()
        data["profiles"] = [rec if r["id"] == rec["id"] else r for r in data["profiles"]]
        self._write(data)

    def profiles(self):
        now = time.time()
        from .emailreset import mask
        return [{"id": r["id"], "name": r["name"], "created": r.get("created", ""), "lockedFor": max(0, int(r.get("locked_until", 0) - now)),
                 "emailReset": bool(r.get("ek")), "emailHint": mask(r.get("email", "")) if r.get("ek") else ""} for r in self._read()["profiles"]]

    def has_profiles(self):
        return bool(self._read()["profiles"])

    def legacy_collection(self):
        """An unencrypted collection from an older version, waiting to be protected."""
        return os.path.exists(os.path.join(self.data_dir, "collection.db"))

    # ---- keys
    @staticmethod
    def _wrap(secret, dek):
        salt = crypto.random_bytes(16)
        key = crypto.derive_key(secret, salt)
        return {"salt": crypto.b64(salt), "blob": crypto.b64(crypto.seal(key, dek, "dek")), "n": crypto.KDF_N, "r": crypto.KDF_R, "p": crypto.KDF_P}

    @staticmethod
    def _unwrap(secret, w):
        key = crypto.derive_key(secret, crypto.unb64(w["salt"]), w.get("n", crypto.KDF_N), w.get("r", crypto.KDF_R), w.get("p", crypto.KDF_P))
        return crypto.open_sealed(key, crypto.unb64(w["blob"]), "dek")

    def _rewrap(self, rec, dek, new_password):
        with self.lock:
            rec = self._rec(rec["id"])
            rec["pw"] = self._wrap(new_password, dek)
            rec["fails"], rec["locked_until"] = 0, 0
            self._save_rec(rec)

    def _set_recovery(self, rec, dek):
        key = crypto.new_recovery_key()
        with self.lock:
            rec = self._rec(rec["id"])
            rec["rk"] = self._wrap(crypto.clean_recovery_key(key), dek)
            self._save_rec(rec)
        return key

    # ---- lockout: five free tries, then waits that double (30 s ... 15 min)
    def _check_lockout(self, rec):
        wait = rec.get("locked_until", 0) - time.time()
        if wait > 0:
            raise AuthError("locked_out", f"Too many wrong attempts. Try again in {int(wait) + 1} seconds.", int(wait) + 1)

    def _fail(self, rec):
        rec["fails"] = rec.get("fails", 0) + 1
        if rec["fails"] >= FREE_TRIES:
            rec["locked_until"] = time.time() + min(900, 30 * 2 ** (rec["fails"] - FREE_TRIES))
        self._save_rec(rec)

    def verify_password(self, pid, password, count=False):
        with self.lock:
            rec = self._rec(pid)
            self._check_lockout(rec)
            try:
                dek = self._unwrap(password, rec["pw"])
            except CryptoError:
                self._fail(rec)
                left = FREE_TRIES - rec.get("fails", 0)
                raise AuthError("bad_password", "That password isn't right." + (f" {left} tries left before a wait." if 0 < left < FREE_TRIES else ""),
                                int(max(0, rec.get("locked_until", 0) - time.time())))
            if rec.get("fails"):
                rec["fails"], rec["locked_until"] = 0, 0
                self._save_rec(rec)
            return dek

    # ---- creating / opening
    def create(self, name, password, adopt_legacy=False, extra_dirs=()):
        name = (name or "").strip()
        if not name or len(name) > 40:
            raise AuthError("bad_name", "Give the account a name (up to 40 characters).")
        problems = crypto.check_password(password, name)
        if problems:
            raise AuthError("weak_password", problems[0])
        with self.lock:
            data = self._read()
            if any(p["name"].lower() == name.lower() for p in data["profiles"]):
                raise AuthError("duplicate", "An account with that name already exists.")
            dek = crypto.random_bytes(32)
            rec = {"id": uuid.uuid4().hex[:12], "name": name, "created": time.strftime("%Y-%m-%d"), "pw": self._wrap(password, dek), "fails": 0, "locked_until": 0}
            recovery = crypto.new_recovery_key()
            rec["rk"] = self._wrap(crypto.clean_recovery_key(recovery), dek)
            data["profiles"].append(rec)
            self._write(data)
        sess = Session(self, rec, dek)
        sess.log_event("account_created")
        if adopt_legacy:
            sess.adopted = self._adopt_legacy(sess, extra_dirs)
        return sess, recovery

    def unlock(self, pid, password):
        dek = self.verify_password(pid, password)
        rec = self._rec(pid)
        sess = Session(self, rec, dek)
        sess.log_event("signed_in")
        return sess

    def recover(self, pid, recovery_key, new_password):
        with self.lock:
            rec = self._rec(pid)
            # the recovery key is 160 random bits: guessing is hopeless, so it is not blocked by the password lockout (it is how you get past
            # one) - but every wrong try still costs a second
            try:
                dek = self._unwrap(crypto.clean_recovery_key(recovery_key), rec["rk"])
            except CryptoError:
                time.sleep(1.0)
                raise AuthError("bad_recovery", "That recovery key isn't right.")
            problems = crypto.check_password(new_password, rec["name"])
            if problems:
                raise AuthError("weak_password", problems[0])
            rec["pw"] = self._wrap(new_password, dek)
            rec["fails"], rec["locked_until"] = 0, 0
            self._save_rec(rec)
        sess = Session(self, rec, dek)
        key = self._set_recovery(rec, dek)
        sess.log_event("password_reset_with_recovery_key")
        return sess, key

    # ---- optional: reset by emailed code.  The account service holds a random escrow key; the matching locked copy of the data key stays HERE.
    def email_reset_info(self, pid):
        r = self._rec(pid)
        return {"enabled": bool(r.get("ek")), "email": r.get("email", ""), "service": r.get("service", ""), "account": r.get("account", "")}

    def enable_email_reset(self, sess, email, service, account, escrow_key):
        with self.lock:
            rec = self._rec(sess.pid)
            rec["ek"] = crypto.b64(crypto.seal(escrow_key, sess.dek, "ek"))
            rec["email"], rec["service"], rec["account"] = email, service, account
            self._save_rec(rec)
        sess.log_event("email_reset_enabled")

    def disable_email_reset(self, sess):
        with self.lock:
            rec = self._rec(sess.pid)
            for k in ("ek", "email", "service", "account"):
                rec.pop(k, None)
            self._save_rec(rec)
        sess.set("email_secret", None)
        sess.log_event("email_reset_disabled")

    def reset_with_escrow(self, pid, escrow_key, new_password):
        with self.lock:
            rec = self._rec(pid)
            if not rec.get("ek"):
                raise AuthError("no_email_reset", "Email reset isn't turned on for this account.")
            try:
                dek = crypto.open_sealed(escrow_key, crypto.unb64(rec["ek"]), "ek")
            except CryptoError:
                raise AuthError("bad_escrow", "The reset key from the service doesn't match this account's data (was it enabled on another computer?).")
            problems = crypto.check_password(new_password, rec["name"])
            if problems:
                raise AuthError("weak_password", problems[0])
            rec["pw"] = self._wrap(new_password, dek)
            rec["fails"], rec["locked_until"] = 0, 0
            self._save_rec(rec)
        sess = Session(self, rec, dek)
        key = self._set_recovery(rec, dek)
        sess.log_event("password_reset_by_email")
        return sess, key

    def delete(self, pid, password):
        self.verify_password(pid, password, count=True)
        with self.lock:
            data = self._read()
            data["profiles"] = [r for r in data["profiles"] if r["id"] != pid]
            self._write(data)
        shutil.rmtree(os.path.join(self.data_dir, "profiles", pid), ignore_errors=True)

    # ---- protecting a collection made by an older (unencrypted) version
    def _adopt_legacy(self, sess, extra_dirs=()):
        """Encrypt the old collection.db and its backups into this profile, verify, then wipe the readable originals."""
        moved = {"collection": False, "backups": 0}
        legacy = os.path.join(self.data_dir, "collection.db")
        if os.path.exists(legacy):
            shutil.copyfile(legacy, sess.db_path)
            for suf in ("-wal", "-shm"):
                if os.path.exists(legacy + suf):
                    shutil.copyfile(legacy + suf, sess.db_path + suf)
            sess.persist()
            with open(sess.enc_path, "rb") as f:                    # prove it can be read back before anything is destroyed
                sess.open(f.read(), "collection")
            moved["collection"] = True
            for suf in ("", "-wal", "-shm"):
                crypto.wipe_file(legacy + suf)
        for d in [os.path.join(self.data_dir, "backups"), *[x for x in extra_dirs if x]]:
            if not os.path.isdir(d):
                continue
            for f in os.listdir(d):
                if f.startswith("collection-") and f.endswith(".db"):
                    p = os.path.join(d, f)
                    try:
                        sess.write_backup(p, sess.backup_dir() if d.startswith(self.data_dir) else d, f)
                        crypto.wipe_file(p)
                        moved["backups"] += 1
                    except OSError:
                        pass
        sess.log_event("existing_collection_protected", json.dumps(moved))
        return moved
