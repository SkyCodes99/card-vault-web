"""Cryptographic building blocks (AES-256-GCM, scrypt).  Nothing here talks to disk or the network.

File format of an encrypted blob:  b"CVE1" + 12-byte nonce + AES-GCM ciphertext (with its 16-byte tag).
The "purpose" string is authenticated too, so a file made for one use (a backup) can't be swapped in for another (the collection)."""
import base64
import hashlib
import hmac
import os
import secrets

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"CVE1"
KDF_N, KDF_R, KDF_P = 2 ** 16, 8, 1
KDF_MAXMEM = 256 * 1024 * 1024


class CryptoError(Exception):
    """Wrong key or damaged / tampered data."""


def random_bytes(n):
    return secrets.token_bytes(n)


def derive_key(secret, salt, n=KDF_N, r=KDF_R, p=KDF_P):
    """A 32-byte key from a password / recovery key.  Deliberately slow (about a quarter of a second) to make guessing expensive."""
    if isinstance(secret, str):
        secret = secret.encode("utf-8")
    # the standard scrypt from the cryptography library (identical output to hashlib.scrypt, and also available inside the browser build)
    return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(secret)


def seal(key, plaintext, purpose=""):
    nonce = os.urandom(12)
    return MAGIC + nonce + AESGCM(key).encrypt(nonce, bytes(plaintext), purpose.encode("utf-8"))


def open_sealed(key, blob, purpose=""):
    if len(blob) < 4 + 12 + 16 or blob[:4] != MAGIC:
        raise CryptoError("not an encrypted file made by this app")
    try:
        return AESGCM(key).decrypt(blob[4:16], blob[16:], purpose.encode("utf-8"))
    except InvalidTag:
        raise CryptoError("wrong password or the data was changed")


def b64(b):
    return base64.b64encode(b).decode("ascii")


def unb64(s):
    return base64.b64decode(s.encode("ascii"))


def new_recovery_key():
    """20 random bytes shown as ABCD-EFGH-... (32 characters): the only way back in if the password is forgotten."""
    raw = base64.b32encode(os.urandom(20)).decode("ascii")
    return "-".join(raw[i:i + 4] for i in range(0, len(raw), 4))


def clean_recovery_key(text):
    return "".join(ch for ch in (text or "").upper() if ch.isalnum())


def same(a, b):
    return hmac.compare_digest(a, b)


def wipe_file(path):
    """Overwrite a file with random bytes and delete it.  Best effort (an SSD may keep old blocks), but it removes the easy copies."""
    try:
        size = os.path.getsize(path)
        with open(path, "r+b") as f:
            left = size
            while left > 0:
                n = min(left, 1 << 20)
                f.write(os.urandom(n))
                left -= n
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass
    try:
        os.remove(path)
    except OSError:
        pass


def wipe_tree(path):
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            wipe_file(os.path.join(root, f))
        for d in dirs:
            try:
                os.rmdir(os.path.join(root, d))
            except OSError:
                pass
    try:
        os.rmdir(path)
    except OSError:
        pass


# ------------------------------------------------------------------------------------------------ password rules
COMMON = {"password", "password1", "password123", "123456789", "1234567890", "qwertyuiop", "iloveyou1", "letmein123", "pokemon123", "pikachu123",
          "welcome123", "admin12345", "changeme123", "abc123456", "qwerty12345"}


def check_password(pw, name=""):
    """-> list of problems (empty = fine).  Length matters most: a short phrase of ordinary words beats a short 'complex' password."""
    problems = []
    if len(pw) < 10:
        problems.append("Use at least 10 characters (a few random words make a strong, easy to remember password).")
    low = pw.lower()
    if low in COMMON or (name and low == name.lower()):
        problems.append("That password is too easy to guess.")
    if len(set(pw)) < 5:
        problems.append("Use a bit more variety.")
    return problems
