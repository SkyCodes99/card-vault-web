"""Pokémon World Championships and International Championships merchandise, for the Accessories list (game id 'accessories').

Read from worldsmerch_data.json (written by tools/harvest_worldsmerch.py from pokemonpin.com, Serebii, the events' own sites and Pokémon Center Japan).  No network at refresh, so it survives the nightly rebuild:
AccessoriesProvider.fetch_catalog calls add() after the TCGplayer rows.  Each event is one set, named by year and event ("2024 Pokémon World Championships - Honolulu"); the three kinds are kept apart in the
entry's Rarity column and in its 'Item kind' fact:
    General merchandise        sold to everyone (Pokémon Center pop-up and online store, pins, plush, playmats...)
    Competitor only            welcome kits, competitor pins, World Champion prize items
    Earned or giveaway extra   staff pins, Pin Rally and badge-pickup pins, gift-with-purchase coins
Every entry keeps its picture's source page and licence ('Photo source', 'Photo credit').  The retail price is written only where an official or retailer page states it ('Retail price' + its page).
Anything not confirmed (picture missing, picture shared with a sibling product, listing not confirmed on an official page) carries the raw ext 'Review' note."""
import json
import os

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "worldsmerch_data.json")
SERIE = "Worlds & Internationals merchandise"
KINDS = ("General merchandise", "Competitor only", "Earned or giveaway extra")
SET_PREFIX = "pcw-"


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def card_ext(it, ev):
    ext = {"Event": ev["name"], "Year": str(ev["year"]), "Item kind": it["kind"], "Source": it["source"], "Photo source": it["photo_source"] if it["image"] else "",
           "Photo credit": it["credit"] if it["image"] else ""}
    ext.update(it.get("extra") or {})
    if it.get("price"):
        ext["Retail price"] = it["price"]
        ext["Retail price source"] = it["price_source"]
    why = list(it.get("review") or [])
    if not it["image"]:
        why.insert(0, "no confirmed true photo")
    if why:
        ext["Review"] = "; ".join(why)
    return {k: v for k, v in ext.items() if v}


def add(conn, day):
    """Writes the event sets and their entries into an accessories cards.db (idempotent: INSERT OR REPLACE).  -> number of entries."""
    data = load()
    events = {e["id"]: e for e in data["events"]}
    per_event = {}
    for it in data["items"]:
        ev = events[it["event"]]
        n = per_event[ev["id"]] = per_event.get(ev["id"], 0) + 1
        ext = card_ext(it, ev)
        raw = {"source": "worldsmerch", "url": it["source"], "ext": ext}
        conn.execute(
            "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
            ("wm:" + it["id"], SET_PREFIX + ev["id"], "", 100000 + n, it["name"], it["image"] or "", it["type"], it["kind"], "Pokémon",
             "%s - %s from the %s." % (it["name"], it["kind"].lower(), ev["name"]), json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
    for ev in data["events"]:
        if ev["id"] in per_event:
            conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)",
                         (SET_PREFIX + ev["id"], ev["name"], SERIE, ev["start"] or str(ev["year"]), per_event[ev["id"]], per_event[ev["id"]]))
    return len(data["items"])
