"""Market movers (roadmap "Market movers"): the top 10 price rises and drops over 1, 7 and 30 days, across the games the owner collects.

Only the price history the app already keeps is used (the card-list price saved each day, which is what pricepick gives in "main" mode).
Rules: eBay prices are never used; a card under MIN_PRICE dollars at either end is skipped (so 10c -> 30c is not "+200%");
a game whose price source is set to something other than the main price is left out, because its history is not saved per source.
Read-only: nothing is written here."""
import datetime
import os
import sqlite3

from . import games, pfscope, pricepick
from .db import game_dir

WINDOWS = (1, 7, 30)          # days
TOP = 10
MIN_PRICE = 1.0               # dollars, at both ends of a move
FAR_FUTURE = "9999-12-31"
SCOPE = "scope"              # owned_by_game: the side bar's view


# ----------------------------------------------------------------------------------------------- the rules (pure)
def window_move(base, latest, cutoff, min_price=MIN_PRICE):
    """base = (day, usd) newest price on or before the window's start, latest = (day, usd) newest price overall, cutoff = the window's start day.
    -> {old, new, change, pct, since, day} or None when there is no fair comparison."""
    if not base or not latest or base[1] is None or latest[1] is None:
        return None
    if latest[0] <= cutoff or latest[0] <= base[0]:              # the newest price must be inside the window and after the old one
        return None
    old, new = float(base[1]), float(latest[1])
    if old < min_price or new < min_price:
        return None
    return {"old": round(old, 2), "new": round(new, 2), "change": round(new - old, 2), "pct": round(100.0 * (new - old) / old, 1),
            "since": base[0], "day": latest[0]}


def top_moves(rows, n=TOP):
    """rows with a 'pct' -> (rises, drops): rises biggest % first, drops biggest % fall first, n of each."""
    rises = sorted((r for r in rows if r["pct"] > 0), key=lambda r: -r["pct"])[:n]
    drops = sorted((r for r in rows if r["pct"] < 0), key=lambda r: r["pct"])[:n]
    return rises, drops


def window_start(days, today=None):
    today = today or datetime.date.today()
    return (today - datetime.timedelta(days=days)).isoformat()


# ----------------------------------------------------------------------------------------------- the data
def _prices(conn, game, ids, days):
    """{card id: [(day, usd) or None for each of `days`]} - each card's newest saved price on or before each day, read through the (game, card, day) key one card at a time
    (grouping the whole price history once per window took seconds over a long history)."""
    one = "(SELECT {} FROM u.price_history WHERE game=?1 AND card_id=?2 AND day<=?%d AND usd IS NOT NULL ORDER BY day DESC LIMIT 1)"
    q = "SELECT " + ", ".join(one.format(col) % (3 + i) for i in range(len(days)) for col in ("day", "usd"))
    out = {}
    for cid in ids:
        r = conn.execute(q, (game, cid, *days)).fetchone()
        out[cid] = [(r[2 * i], r[2 * i + 1]) if r[2 * i] is not None else None for i in range(len(days))]
    return out


def _card_info(gid, data_dir, ids):
    """{card id: (name, set id, number, price kind)} from that game's card list (read-only; empty when the list is not on this device)."""
    path = os.path.join(game_dir(data_dir, gid), "cards.db").replace("\\", "/")
    out = {}
    ids = list(ids)
    if not ids:
        return out
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                for r in c.execute(f"SELECT id, name, set_id, local_id, price_kind FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                    out[r[0]] = (r[1], r[2], r[3], r[4])
        finally:
            c.close()
    except sqlite3.Error:
        pass
    return out


def owned_by_game(v, pf=SCOPE):
    """{game id: {card id: copies}} for the cards the owner holds (sealed products excluded).  pf = SCOPE: the side bar's view like the rest of the app;
    None: every portfolio; a list: those portfolios (database ids, '' = the main one)."""
    out = {}
    extra, args = pfscope.where(pf, "l.portfolio") if pf != SCOPE else ("", ())
    for gid, cid, qty in v.conn.execute(f"SELECT l.game, l.card_id, SUM(l.qty) FROM {'lots_s' if pf == SCOPE else 'u.lots'} l WHERE l.user_id=? AND l.deleted=0 AND l.qty>0 "
                                        f"AND l.card_id NOT LIKE 'sealed:%'{extra} GROUP BY l.game, l.card_id", (v.user_id, *args)):
        out.setdefault(gid, {})[cid] = qty
    return out


def with_wishlist(v, owned):
    """owned_by_game() widened by the cards on the wish list (0 copies): the cards the app keeps a price history for are the ones you own or want."""
    out = {g: dict(c) for g, c in owned.items()}
    for gid, cid in v.conn.execute("SELECT game, card_id FROM u.wishlist WHERE user_id=?", (v.user_id,)):
        out.setdefault(gid, {}).setdefault(cid, 0)
    return out


def _main_price_only(v, gid):
    """True when this game's price source is the main price (the only one whose history is kept)."""
    raw = v.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game=? AND key=?", (v.user_id, gid, pricepick.KEY)).fetchone()
    return pricepick.normalize(raw[0] if raw else None, list(pricepick.NAMES))["use"] == "main"


def day_moves(v, ids, today=None):
    """{card id: (move, name, set id) or None} over the 1-day window for these cards of the open game, with the Movers panel's rules (eBay prices never count).
    A card's move depends only on the prices, so Home keeps these and works out only the cards it has not seen yet (homeapi._today)."""
    gid = v.game
    cutoff = window_start(1, today)
    info = _card_info(gid, v.data_dir, ids)
    mine = [cid for cid in ids if cid in info and not pricepick.is_ebay(info[cid][3])]
    ends = _prices(v.conn, gid, mine, [FAR_FUTURE, cutoff])
    out = dict.fromkeys(ids)
    for cid in mine:
        latest, base = ends[cid]
        mv = window_move(base, latest, cutoff, min_price=0.01)                  # (every priced card counts towards the day's change ...)
        if mv:
            out[cid] = (mv, info[cid][0], info[cid][1])
    return out


def my_day(v, owned, today=None, n=3, moves=None):
    """Home's "today" (pages/home/): the open game's cards I hold ({card id: copies}, the side bar's view) over the 1-day window, with the same rules as the Movers panel.
    -> {"compared": cards with a price today and before, "change": what my copies gained / lost in dollars, "top": the n biggest moves in dollars for my copies}.
    `moves`: day_moves() kept from before, covering every card in `owned`.  Nothing to compare (another price source, or today's prices not in yet) -> compared 0."""
    if not owned or not _main_price_only(v, v.game):
        return {"compared": 0, "change": 0.0, "top": []}
    moves = moves if moves is not None else day_moves(v, list(owned), today)
    change, rows, compared = 0.0, [], 0
    for cid, qty in owned.items():
        if not moves.get(cid):
            continue
        mv, name, set_id = moves[cid]
        compared += 1
        change += mv["change"] * qty
        if mv["old"] >= MIN_PRICE and mv["new"] >= MIN_PRICE:                 # (... the movers shown skip cards under a dollar, as the Movers panel does)
            rows.append({"id": cid, "name": name, "set_id": set_id, "qty": qty, **mv, "total": round(mv["change"] * qty, 2)})
    rows.sort(key=lambda r: -abs(r["total"]))
    return {"compared": compared, "change": round(change, 2), "top": rows[:n]}


def movers(v, game=None, data_dir=None, today=None, pf=SCOPE, only_mine=True):
    """game None or 'all' = every game the owner collects, else one game id; pf = which portfolios (owned_by_game).
    only_mine=True (the default) = only the cards I own; False = the cards I own and the ones on my wish list (every card the app saves a price history for).
    -> {"games": [{id, name, cards}], "game": game or "all", "windows": {"1": {"rises", "drops", "compared"}, "7": ..., "30": ...}, "pricing": [game ids left out]}"""
    owned = owned_by_game(v, pf) if only_mine else with_wishlist(v, owned_by_game(v, pf))
    names = {g.id: g.name for g in games.GAMES}
    data_dir = data_dir or v.data_dir
    today = today or datetime.date.today()
    want = list(owned) if game in (None, "", "all") else [game] if game in owned else []
    skipped = []
    rows = {w: [] for w in WINDOWS}
    for gid in want:
        if not _main_price_only(v, gid):
            skipped.append(gid)
            continue
        info = _card_info(gid, data_dir, owned[gid])
        mine = [cid for cid in owned[gid] if cid in info and not pricepick.is_ebay(info[cid][3])]          # never eBay prices
        ends = _prices(v.conn, gid, mine, [FAR_FUTURE, *(window_start(w, today) for w in WINDOWS)])
        for cid in mine:
            c, (latest, *bases) = info[cid], ends[cid]
            if not latest:
                continue
            for w, base in zip(WINDOWS, bases):
                mv = window_move(base, latest, window_start(w, today))
                if mv:
                    rows[w].append({"card_id": cid, "game": gid, "game_name": names.get(gid, gid), "name": c[0], "set_id": c[1], "number": c[2], **mv})
    out_windows = {}
    for w in WINDOWS:
        rises, drops = top_moves(rows[w])
        out_windows[str(w)] = {"rises": rises, "drops": drops, "compared": len(rows[w])}
    return {"games": [{"id": g, "name": names.get(g, g), "cards": len(owned[g])} for g in owned], "game": game or "all",
            "windows": out_windows, "pricing": skipped, "mine": bool(only_mine)}
