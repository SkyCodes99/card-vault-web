"""Market movers (roadmap "Market movers"): the top 10 price rises and drops over 1, 7 and 30 days, across the games the owner collects.

Only the price history the app already keeps is used (the card-list price saved each day, which is what pricepick gives in "main" mode).
Rules: eBay prices are never used; a card under MIN_PRICE dollars at either end is skipped (so 10c -> 30c is not "+200%");
a game whose price source is set to something other than the main price is left out, because its history is not saved per source.
Read-only: nothing is written here."""
import datetime
import os
import sqlite3

from . import games, pricepick
from .db import game_dir

WINDOWS = (1, 7, 30)          # days
TOP = 10
MIN_PRICE = 1.0               # dollars, at both ends of a move
FAR_FUTURE = "9999-12-31"


# ----------------------------------------------------------------------------------------------- the rules (pure)
def window_move(base, latest, cutoff, min_price=MIN_PRICE):
    """base = (day, usd) newest price on or before the window's start, latest = (day, usd) newest price overall, cutoff = the window's start day.
    -> {old, new, change, pct, since, day} or None when there is no fair comparison."""
    if not base or not latest or base[1] is None or latest[1] is None:
        return None
    if latest[0] <= cutoff or latest[0] <= base[0]:              # the newest price must be inside the window and after the old one
        return None
    old, new = float(base[1]), float(latest[1])
    if old < min_price or new < min_price:
        return None
    return {"old": round(old, 2), "new": round(new, 2), "change": round(new - old, 2), "pct": round(100.0 * (new - old) / old, 1),
            "since": base[0], "day": latest[0]}


def top_moves(rows, n=TOP):
    """rows with a 'pct' -> (rises, drops): rises biggest % first, drops biggest % fall first, n of each."""
    rises = sorted((r for r in rows if r["pct"] > 0), key=lambda r: -r["pct"])[:n]
    drops = sorted((r for r in rows if r["pct"] < 0), key=lambda r: r["pct"])[:n]
    return rises, drops


def window_start(days, today=None):
    today = today or datetime.date.today()
    return (today - datetime.timedelta(days=days)).isoformat()


# ----------------------------------------------------------------------------------------------- the data
def _last_prices(conn, game, on_or_before):
    """{card id: (day, usd)} - the newest saved price of each card on or before that day (cards with no price on it are left out)."""
    rows = conn.execute(
        "SELECT h.card_id, h.day, h.usd FROM u.price_history h JOIN (SELECT card_id, MAX(day) AS d FROM u.price_history "
        "WHERE game=? AND day<=? AND usd IS NOT NULL GROUP BY card_id) b ON h.card_id=b.card_id AND h.day=b.d "
        "WHERE h.game=? AND h.usd IS NOT NULL", (game, on_or_before, game)).fetchall()
    return {r[0]: (r[1], r[2]) for r in rows}


def _card_info(gid, data_dir, ids):
    """{card id: (name, set id, number, price kind)} from that game's card list (read-only; empty when the list is not on this device)."""
    path = os.path.join(game_dir(data_dir, gid), "cards.db").replace("\\", "/")
    out = {}
    ids = list(ids)
    if not ids:
        return out
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                for r in c.execute(f"SELECT id, name, set_id, local_id, price_kind FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                    out[r[0]] = (r[1], r[2], r[3], r[4])
        finally:
            c.close()
    except sqlite3.Error:
        pass
    return out


def owned_by_game(v):
    """{game id: {card id: copies}} for the cards the owner holds (sealed products excluded), in the current scope like the rest of the app."""
    out = {}
    for gid, cid, qty in v.conn.execute("SELECT l.game, l.card_id, SUM(l.qty) FROM lots_s l WHERE l.user_id=? AND l.deleted=0 AND l.qty>0 "
                                        "AND l.card_id NOT LIKE 'sealed:%' GROUP BY l.game, l.card_id", (v.user_id,)):
        out.setdefault(gid, {})[cid] = qty
    return out


def _main_price_only(v, gid):
    """True when this game's price source is the main price (the only one whose history is kept)."""
    raw = v.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game=? AND key=?", (v.user_id, gid, pricepick.KEY)).fetchone()
    return pricepick.normalize(raw[0] if raw else None, list(pricepick.NAMES))["use"] == "main"


def movers(v, game=None, data_dir=None, today=None):
    """game None or 'all' = every game the owner collects, else one game id.
    -> {"games": [{id, name, cards}], "game": game or "all", "windows": {"1": {"rises", "drops", "compared"}, "7": ..., "30": ...}, "pricing": [game ids left out]}"""
    owned = owned_by_game(v)
    names = {g.id: g.name for g in games.GAMES}
    data_dir = data_dir or v.data_dir
    today = today or datetime.date.today()
    want = list(owned) if game in (None, "", "all") else [game] if game in owned else []
    skipped = []
    rows = {w: [] for w in WINDOWS}
    for gid in want:
        if not _main_price_only(v, gid):
            skipped.append(gid)
            continue
        latest = _last_prices(v.conn, gid, FAR_FUTURE)
        bases = {w: _last_prices(v.conn, gid, window_start(w, today)) for w in WINDOWS}
        info = _card_info(gid, data_dir, owned[gid])
        for cid, qty in owned[gid].items():
            c = info.get(cid)
            if not c or pricepick.is_ebay(c[3]) or cid not in latest:           # never eBay prices
                continue
            for w in WINDOWS:
                mv = window_move(bases[w].get(cid), latest[cid], window_start(w, today))
                if mv:
                    rows[w].append({"card_id": cid, "game": gid, "game_name": names.get(gid, gid), "name": c[0], "set_id": c[1], "number": c[2], **mv})
    out_windows = {}
    for w in WINDOWS:
        rises, drops = top_moves(rows[w])
        out_windows[str(w)] = {"rises": rises, "drops": drops, "compared": len(rows[w])}
    return {"games": [{"id": g, "name": names.get(g, g), "cards": len(owned[g])} for g in owned], "game": game or "all",
            "windows": out_windows, "pricing": skipped}
