"""The small pieces every game's filters are made of: split a field into its values, count it (0 ... 9, 10+), put a big number in a range.  `values(key)`, `count(key)` and `ranged(key, ...)` build the
extractor a filter needs from the name of the card field it reads; gamefacets.py and tcgfacets.py list the filters of each game with them."""
import re


def split(v, seps=r"[/,;]"):
    return [p.strip() for p in re.split(seps, str(v or "")) if p and p.strip()]


def thousands(v):
    m = re.search(r"\d+", str(v or ""))
    if not m:
        return []
    n = int(m.group())
    n = n // 1000 if n >= 1000 else n
    return [str(n) if n < 10 else "10+"]


def num(v):
    m = re.search(r"\d+", str(0 if v == 0 else (v or "")))
    if not m:
        return []
    n = int(m.group())
    return [str(n) if n < 10 else "10+"]


def bucket(v, step, top):
    """A number as a range of `step` (0, 1-1000, 1001-2000 ... 4001+): attack / power / defense are far too many different values to list one by one."""
    m = re.search(r"\d+", str(0 if v == 0 else (v or "")))
    if not m:
        return []
    n = int(m.group())
    if n == 0:
        return ["0"]
    k = (n - 1) // step
    return [f"{top * step + 1:,}+" if k >= top else f"{k * step + 1:,}-{(k + 1) * step:,}"]


def values(*keys, seps=r"[;,]"):
    """The extractor for a filter that lists the values of one or more fields ('Earthling;Saiyan' -> Earthling, Saiyan)."""
    return lambda e, c: [x for k in keys for x in split(e.get(k), seps)]


def count(key):
    """... for a filter on a small whole number: 0 ... 9, 10+."""
    return lambda e, c: num(e.get(key))


def ranged(key, step, top):
    """... for a filter on a big number (power, HP, DP): in ranges of `step`."""
    return lambda e, c: bucket(e.get(key), step, top)
