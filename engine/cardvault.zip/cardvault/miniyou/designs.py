"""The candidate designs, 2-3 per task; train.py fits each on the training rows and keeps the one with the best held-out result.  Every model is a small plain object (picklable) with one
scoring method:  real -> score(texts) = chance it is a real release;  place -> predict(game, what, text) = (label, confidence);  photo -> score(features a, features b) = chance it is the same item."""
import numpy as np

from . import imgfeat, textfeat


# ---- (b) real vs listing --------------------------------------------------------------------------------------------------------------------------------------------------------------

class TextBinary:
    def __init__(self, name, vec_kind, algo):
        self.name, self.vec_kind, self.algo = name, vec_kind, algo
        self.vec = textfeat.vectorizer(vec_kind)
        self.clf = None

    def fit(self, texts, y):
        from sklearn.linear_model import LogisticRegression
        from sklearn.naive_bayes import ComplementNB
        X = self.vec.transform(texts)
        self.clf = ComplementNB(alpha=0.3) if self.algo == "nb" else LogisticRegression(C=4.0, class_weight="balanced", max_iter=3000)
        self.clf.fit(X, np.asarray(y))
        return self

    def score(self, texts):
        p = self.clf.predict_proba(self.vec.transform(list(texts)))
        return p[:, list(self.clf.classes_).index(1)] if 1 in self.clf.classes_ else np.zeros(len(texts))


def real_designs():
    return [TextBinary("naive-bayes words+chars", "both", "nb"), TextBinary("logistic chars", "char", "lr"), TextBinary("logistic words+chars", "both", "lr")]


# ---- (c) set / line placer ------------------------------------------------------------------------------------------------------------------------------------------------------------

def _ptext(what, text):
    return f"what_{what} {text}"


class Placer:
    """One small model per game (a set's series only ever comes from its own game).  algo: 'knn' (the 5 closest known names vote), 'nb' (Naive Bayes), 'lr' (logistic regression)."""

    def __init__(self, name, algo):
        self.name, self.algo = name, algo
        self.vec = textfeat.vectorizer("both", 2 ** 16)
        self.per_game = {}

    def fit(self, rows):
        from sklearn.linear_model import LogisticRegression
        from sklearn.naive_bayes import ComplementNB
        by = {}
        for r in rows:
            by.setdefault(r["game"], []).append(r)
        for g, rs in by.items():
            labels = sorted({r["label"] for r in rs})
            texts = [_ptext(r["what"], r["text"]) for r in rs]
            y = np.array([labels.index(r["label"]) for r in rs])
            if len(labels) == 1:
                self.per_game[g] = ("one", labels, None)
                continue
            X = self.vec.transform(texts)
            if self.algo == "knn":
                self.per_game[g] = ("knn", labels, (X, y))
            elif self.algo == "nb":
                self.per_game[g] = ("model", labels, ComplementNB(alpha=0.1).fit(X, y))
            else:
                self.per_game[g] = ("model", labels, LogisticRegression(C=8.0, max_iter=2000).fit(X, y))
        return self

    def predict_many(self, game, whats, texts):
        """-> [(label, confidence)]; (None, 0.0) for a game it never saw."""
        if game not in self.per_game:
            return [(None, 0.0)] * len(texts)
        kind, labels, m = self.per_game[game]
        if kind == "one":
            return [(labels[0], 1.0)] * len(texts)
        X = self.vec.transform([_ptext(w, t) for w, t in zip(whats, texts)])
        if kind == "knn":
            Xt, yt = m
            sims = (X @ Xt.T).toarray()
            out = []
            for row in sims:
                top = np.argsort(-row)[:5]
                w = np.maximum(row[top], 0) + 1e-9
                votes = np.bincount(yt[top], weights=w, minlength=len(labels))
                k = int(votes.argmax())
                out.append((labels[k], float(votes[k] / votes.sum()) * float(min(1.0, row[top[0]] + 0.2))))
            return out
        p = m.predict_proba(X)
        cls = list(m.classes_)
        return [(labels[cls[int(i)]], float(row[int(i)])) for row, i in ((r, r.argmax()) for r in p)]

    def predict(self, game, what, text):
        return self.predict_many(game, [what], [text])[0]


def place_designs():
    return [Placer("nearest names (5 votes)", "knn"), Placer("naive-bayes per game", "nb"), Placer("logistic per game", "lr")]


# ---- (a) photo matcher -------------------------------------------------------------------------------------------------------------------------------------------------------------

class Embedding:
    """A small embedding learned from our own product pictures: the main directions of the pictures' numbers (whitened PCA), 24 numbers per picture."""

    def __init__(self, dims=24):
        self.dims, self.mean, self.comp = dims, None, None

    def fit(self, raws):
        X = np.asarray(raws, dtype=np.float64)
        self.mean = X.mean(0)
        _, s, vt = np.linalg.svd(X - self.mean, full_matrices=False)
        k = min(self.dims, len(s))
        self.comp = (vt[:k] / (s[:k, None] / np.sqrt(max(len(X) - 1, 1)) + 1e-6)).astype(np.float32)
        return self

    def __call__(self, f):
        return self.comp @ (imgfeat.raw_vector(f) - self.mean).astype(np.float32)


class HashMatch:
    name = "perceptual hashes only"

    def fit(self, pairs, y):
        return self

    def score(self, fa, fb):
        return 1.0 - (imgfeat.hamming(fa["dhash"], fb["dhash"]) + imgfeat.hamming(fa["phash"], fb["phash"])) / 2


class EmbedMatch:
    name = "learned embedding, cosine"

    def __init__(self):
        self.embed = Embedding()

    def fit(self, pairs, y):
        self.embed.fit([imgfeat.raw_vector(f) for p in pairs for f in p])
        return self

    def score(self, fa, fb):
        a, b = self.embed(fa), self.embed(fb)
        return float((a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-6) + 1) / 2)


class PairNet:
    name = "tiny neural net on hashes + embedding"

    def __init__(self):
        self.embed = Embedding()
        self.net = None

    def fit(self, pairs, y):
        from sklearn.neural_network import MLPClassifier
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        self.embed.fit([imgfeat.raw_vector(f) for p in pairs for f in p])
        X = np.array([imgfeat.pair_vector(a, b, self.embed) for a, b in pairs])
        self.net = make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(24, 12), alpha=1e-3, max_iter=800, random_state=0)).fit(X, np.asarray(y))
        return self

    def score(self, fa, fb):
        return float(self.net.predict_proba(imgfeat.pair_vector(fa, fb, self.embed)[None, :])[0, 1])


class ArtPairNet(PairNet):
    """The tiny net, also shown the artwork window on its own (imgfeat.art_vector): two cards of one set and frame share almost everything but the art."""
    name = "tiny neural net + artwork window"

    def _x(self, a, b):
        return np.concatenate([imgfeat.pair_vector(a, b, self.embed), imgfeat.art_vector(a, b)])

    def fit(self, pairs, y):
        from sklearn.neural_network import MLPClassifier
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        self.embed.fit([imgfeat.raw_vector(f) for p in pairs for f in p])
        X = np.array([self._x(a, b) for a, b in pairs])
        self.net = make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(24, 12), alpha=1e-3, max_iter=800, random_state=0)).fit(X, np.asarray(y))
        return self

    def score(self, fa, fb):
        return float(self.net.predict_proba(self._x(fa, fb)[None, :])[0, 1])


def photo_designs():
    return [HashMatch(), EmbedMatch(), PairNet(), ArtPairNet()]
