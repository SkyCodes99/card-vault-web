"""docs/miniyou_report.md: the held-out scores of the models in use and of every design that was tried, in plain words."""
from . import TARGET_PRECISION, evaluate, registry

WHAT = {"photo": "Photo matcher - is this product photo the same item?", "real": "Real release vs custom / bundle / shop listing", "place": "Set / line placer - which series or line?"}
NOTES = {"photo": "Same-item pairs are a product picture against a made-up shop-style copy of it (small crop, new size, light, JPEG); different-item pairs are two items of the same set, "
                   "and HARD pairs: two cards of the same set and the same frame (rarity, card kind, type, stage) with different names - Clefable vs Wigglytuff. "
                   "In the daily update a high same-item score between a NEW item's picture and another item's sends the new one to review (it may be a stand-in picture).",
         "real": "The real 'not real' rows are few (the shop products the toy rules leave out and toyrules.NOT_OFFICIAL, about 50), so most 'not real' rows are made up by rule from real "
                 "names (lots, customs, graded copies, merch). The real-rows-only line is the honest one for real shop listings; the owner's 'no' answers on the review list add real ones each week.",
         "place": "One model per game. The logistic design is slow to train (about 25 minutes on a busy PC), which is fine for a weekly retrain."}
UNIT = {"photo": "picture pairs", "real": "items", "place": "sets, products and toys"}


def _pct(v):
    return "-" if v is None else f"{v * 100:.1f} %"


def _extra(h):
    out = []
    if h.get("hard"):
        x, o = h["hard"], h["hard"].get("other_half") or {}
        out += [f"Hard look-alike pairs only (same set + frame, another name; {x['hard_pairs']} of them next to the same-item pairs), same threshold: precision {_pct(x['precision'])} | "
                f"recall {_pct(x['recall'])} | AUC {x['auc']}. Stricter: threshold picked on half the held-out items ({o.get('threshold') if o.get('threshold') is not None else 'none'}), "
                f"measured on the other half: precision {_pct(o.get('precision'))} | recall {_pct(o.get('recall'))} | hard pairs wrongly called the same {o.get('accepted_wrong', 0)} of {o.get('hard_pairs', 0)}.", ""]
    if h.get("real_rows_only"):
        o = h["real_rows_only"]
        out += [f"Real rows only (no made-up listings), same threshold: precision {_pct(o['precision'])} | recall {_pct(o['recall'])} | review rate {_pct(o['review_rate'])} | wrong ones caught {_pct(o.get('wrong_caught'))} | AUC {o['auc']} "
                f"(held-out {o['n']}, of them not real {o['n'] - o['positives']}). Not-real rows that would be auto-accepted: {h.get('not_real_accepted', 0)}.", ""]
    return out


def text():
    lines = ["# Mini you - model report", "",
             f"Small models built from scratch and trained on this computer, on the app's own catalog (no paid AI, no downloaded weights). Held-out rows are a fixed quarter of the data the models never saw while training. "
             f"Auto-accept happens only above a threshold where held-out precision is at least {TARGET_PRECISION * 100:.0f} %; everything below it goes to the review list.", "",
             "- precision: of what would be auto-accepted, how much was right", "- recall: of everything right, how much would be auto-accepted",
             "- review rate: share of all items that would still go to the owner's review list", "- wrong ones caught: of the wrong ones (not real, wrong series, a different item), the share sent to review instead of auto-accepted", "- AUC: how well the score ranks right above wrong (1.0 = perfect)", ""]
    for task in ("photo", "real", "place"):
        m = registry.meta(task)
        lines += [f"## {WHAT[task]}", ""]
        if not m:
            lines += ["Not trained yet.", ""]
            continue
        h = m["heldout"]
        lines += [f"In use: **v{m['version']} - {m['design']}**, trained {m['trained']}. Rows: " + ", ".join(f"{k} {v}" for k, v in m["rows"].items()) + f". Owner answers used: {m.get('answers', 0)}.", "",
                  f"Threshold {h['threshold'] if h['threshold'] is not None else 'none (nothing auto-accepted)'} | precision {_pct(h['precision'])} | recall {_pct(h['recall'])} | review rate {_pct(h['review_rate'])} | wrong ones caught {_pct(h.get('wrong_caught'))} | AUC {h['auc']}"
                  + (f" | accuracy {_pct(h.get('accuracy'))}" if h.get("accuracy") is not None else "") + f" (held-out {UNIT[task]}: {h['n']})", "",
                  *_extra(h), NOTES[task], "", ("**Auto mode: allowed** - above the threshold it may act on its own when the daily update runs with --miniyou=auto." if evaluate.auto_ok(m) else "**Auto mode: not allowed** - it only scores and logs, even with --miniyou=auto (the held-out result did not clear the bar)."), "",
                  "| Design tried | Threshold | Precision | Recall | Review rate | AUC | Seconds |", "|---|---|---|---|---|---|---|"]
        for d in m["designs"]:
            x = d["heldout"]
            t = "none" if x["threshold"] is None else f"{x['threshold']:.3f}"
            lines.append(f"| {d['name']}{' (kept)' if d['name'] == m['design'] else ''} | {t} | {_pct(x['precision'])} | {_pct(x['recall'])} | {_pct(x['review_rate'])} | {x['auc']} | {d['seconds']} |")
        lines.append("")
    return "\n".join(lines)


def write(path):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text())
    return path
