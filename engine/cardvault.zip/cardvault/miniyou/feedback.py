"""Mini you and the ONE review list (cardvault/reviewlist.py, review_list.db next to the daily update log): a low score is put on the list as an ordinary question, and the owner's
confirmed answers there are read back as training labels for the next (weekly) retrain.  No second list: the answers stay in review_list.db.

Kinds: miniyou_real (is it a real release?), miniyou_place (is this the right series / line? the owner may type the right one), miniyou_photo (are these two pictures the same item?).
A yes / no only teaches the models: the catalog itself is changed by the checks that put the item there (gates, reviewfix ...), never by a Mini you answer."""
from cardvault import reviewlist

SOURCE = "Mini you (small local model)"
KINDS = {"real": "miniyou_real", "place": "miniyou_place", "photo": "miniyou_photo"}


def _apply(item, ans, value, ctx):
    return "noted: Mini you learns from this answer at its next weekly retrain"


for _k in KINDS.values():
    reviewlist.register(_k, apply=_apply)


def queue(task, game, item_id, question, before, score):
    """Put a low-scoring item on the review list (never twice; an answered one stays locked).  `before` keeps what the model saw, so the answer can be learned from.  -> the review item id"""
    return reviewlist.add_item(KINDS[task], game, item_id, question, before=dict(before, score=round(float(score), 4)), source=SOURCE)


def revert_answer(entry):
    """The owner took back a change Mini you made (Dev Tools > Changes): that is a 'no' to Mini you, kept as a confirmed answer so the next weekly retrain learns from it.
    entry: the fix log line, with entry['miniyou'] = what the model saw ({task, text, label, what, name} for a move; 'right' = the line / set it had before).  -> review item id or None"""
    seen = entry.get("miniyou") or {}
    task = seen.get("task")
    if task not in KINDS:
        return None
    q = f"You took back Mini you's change to {entry.get('name') or entry['item_id']} (Dev Tools > Changes)."
    before = {k: v for k, v in seen.items() if k not in ("task", "right")}
    before["score"] = entry.get("score")
    if task == "place" and seen.get("right"):                       # (the line it was on before is the right one: a typed answer, like the owner's own on the review list)
        return reviewlist.record_answer(KINDS[task], entry["game"], "revert:" + entry["id"], q, before, "value", seen["right"], "learned at the next weekly retrain", SOURCE)
    return reviewlist.record_answer(KINDS[task], entry["game"], "revert:" + entry["id"], q, before, "no", None, "learned at the next weekly retrain", SOURCE)


def labels(task):
    """The owner's confirmed answers for one task, as training rows (same shape as datasets.py's).  Never fails: no list yet -> []."""
    try:
        done = reviewlist.items(status="confirmed", kind=KINDS[task])
    except Exception:  # noqa: BLE001
        return []
    out = []
    for it in done:
        b, ans = it.get("before") or {}, it.get("answer")
        key = f"review:{it['id']}"
        if task == "real" and b.get("text") and ans in ("yes", "no"):
            out.append({"key": key, "game": it["game"], "text": b["text"], "y": int(ans == "yes"), "source": "owner answer"})
        elif task == "place" and b.get("text") and b.get("label"):
            right = b["label"] if ans == "yes" else (it.get("final") if ans == "value" and isinstance(it.get("final"), str) else None)
            if right:
                out.append({"key": key, "game": it["game"], "text": b["text"], "label": right, "what": b.get("what") or "set"})
        elif task == "photo" and b.get("a") and b.get("b") and ans in ("yes", "no"):
            out.append({"key": key, "game": it["game"], "a": b["a"], "b": b["b"], "y": int(ans == "yes")})
    return out
