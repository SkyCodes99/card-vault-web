"""Held-out evaluation: a fixed split (by a hash of each row's key, so it never changes between runs) and the auto-accept threshold whose held-out precision is >= the target."""
import hashlib

import numpy as np

from . import TARGET_PRECISION

MIN_ACCEPTED = 20          # a threshold is only trusted when at least this many held-out rows clear it


def is_heldout(key, share=0.25):
    h = int(hashlib.sha1(str(key).encode("utf-8")).hexdigest()[:8], 16)
    return (h % 10000) < share * 10000


def split(keys, share=0.25):
    """-> (train index array, held-out index array)"""
    held = np.array([is_heldout(k, share) for k in keys], dtype=bool)
    return np.flatnonzero(~held), np.flatnonzero(held)


def threshold_at(y, p, target=TARGET_PRECISION, min_accepted=MIN_ACCEPTED):
    """The LOWEST score threshold t where every row with score >= t is right at least `target` of the time (and at least min_accepted rows clear it).  -> t or None (nothing is auto-accepted)."""
    y, p = np.asarray(y, dtype=float), np.asarray(p, dtype=float)
    order = np.argsort(-p, kind="stable")
    ys, ps = y[order], p[order]
    hits = np.cumsum(ys)
    n = np.arange(1, len(ys) + 1)
    best = None
    for i in range(len(ys)):
        if i + 1 < len(ys) and ps[i + 1] == ps[i]:
            continue                                    # a threshold accepts every row with that same score
        if n[i] >= min_accepted and hits[i] / n[i] >= target:
            best = float(ps[i])
    return best


def report(y, p, t):
    """Precision of what is auto-accepted, recall (share of the right rows auto-accepted), review rate (share of all rows sent to the owner), plus the ranking quality."""
    y, p = np.asarray(y, dtype=float), np.asarray(p, dtype=float)
    acc = p >= t if t is not None else np.zeros(len(p), dtype=bool)
    tp = float((y[acc] == 1).sum())
    out = {"n": int(len(y)), "positives": int(y.sum()), "threshold": t,
           "precision": round(tp / acc.sum(), 4) if acc.sum() else None,
           "recall": round(tp / y.sum(), 4) if y.sum() else None,
           "review_rate": round(1 - acc.mean(), 4) if len(y) else None,
           "wrong_caught": round(float((~acc[y == 0]).mean()), 4) if (y == 0).any() else None,     # of the wrong rows, the share sent to review (not auto-accepted)
           "auc": round(auc(y, p), 4)}
    return out


def auc(y, p):
    """Area under the ROC curve (rank form, ties shared)."""
    y, p = np.asarray(y), np.asarray(p, dtype=float)
    pos, neg = (y == 1).sum(), (y == 0).sum()
    if not pos or not neg:
        return 1.0
    from scipy.stats import rankdata
    r = rankdata(p)
    return float((r[y == 1].sum() - pos * (pos + 1) / 2) / (pos * neg))


MIN_CAUGHT = 0.9           # on the real rows, at least this share of the wrong ones must be sent to review


def auto_ok(meta):
    """May this model act in 'auto' mode?  Held-out precision >= the target at its threshold, and where a real-rows-only score exists (the real-release model, whose not-real rows are
    mostly made up), that one must hold too and catch at least MIN_CAUGHT of the real wrong ones.  -> bool"""
    h = (meta or {}).get("heldout") or {}
    if h.get("threshold") is None or (h.get("precision") or 0) < TARGET_PRECISION:
        return False
    hard = h.get("hard")
    if hard is not None and ((hard.get("precision") or 0) < TARGET_PRECISION or ((hard.get("other_half") or {}).get("precision") or 0) < TARGET_PRECISION):
        return False                                     # (the photo matcher must also hold on the hard look-alikes, on both halves)
    o = h.get("real_rows_only")
    if o is not None and ((o.get("precision") or 0) < TARGET_PRECISION or (o.get("wrong_caught") or 0) < MIN_CAUGHT):
        return False
    return True


def better(a, b):
    """Is held-out result a better than b?  Most auto-accepted at >= 99 % first (recall), then ranking quality."""
    return (a.get("recall") or 0, a.get("auc") or 0) > (b.get("recall") or 0, b.get("auc") or 0)
