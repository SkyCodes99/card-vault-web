"""Train every design of a task on the training rows, score each on the held-out rows (evaluate.py), keep the best, and save it (registry.py) with its threshold and scores.
A new version is only saved when it is not worse than the one in use (a bad week of data never replaces a good model), unless force=True."""
import hashlib
import time

import numpy as np

from . import datasets, designs, evaluate, feedback, imgfeat, registry


def _pick(results):
    best = None
    for r in results:
        if best is None or evaluate.better(r["heldout"], best["heldout"]):
            best = r
    return best


def _finish(task, results, rows_info, force):
    best = _pick(results)
    meta = {"design": best["name"], "threshold": best["heldout"]["threshold"], "heldout": best["heldout"], "designs": [{"name": r["name"], "heldout": r["heldout"], "seconds": r["seconds"]} for r in results],
            "rows": rows_info, "trained": time.strftime("%Y-%m-%dT%H:%M:%S"), "answers": len(feedback.labels(task))}
    cur = registry.meta(task)
    harder = "hard" in best["heldout"] and "hard" not in (cur or {}).get("heldout", {})        # (a model measured without the hard pairs was measured on an easier test: not comparable)
    if cur and not force and not harder and evaluate.better(cur["heldout"], best["heldout"]):
        meta["saved"] = False
        meta["kept_version"] = cur["version"]
        return meta
    meta["saved"] = True
    meta["version"] = registry.save(task, best["model"], meta)
    return meta


def train_real(rows, force=False):
    keys = [r["key"] for r in rows]
    tr, ho = evaluate.split(keys)
    texts = np.array([r["text"] for r in rows], dtype=object)
    y = np.array([r["y"] for r in rows])
    results = []
    for d in designs.real_designs():
        t0 = time.time()
        d.fit(list(texts[tr]), y[tr])
        p = d.score(list(texts[ho]))
        t = evaluate.threshold_at(y[ho], p)
        rep = evaluate.report(y[ho], p, t)
        own = np.array([rows[i].get("source") != datasets.SYNTH for i in ho], dtype=bool)
        if own.any():
            rep["real_rows_only"] = evaluate.report(y[ho][own], p[own], t)      # the same threshold on the held-out rows that are not made-up listings
        rep["not_real_accepted"] = int(((p >= t) & (y[ho] == 0)).sum()) if t is not None else 0
        results.append({"name": d.name, "model": d, "heldout": rep, "seconds": round(time.time() - t0, 1)})
    return _finish("real", results, {"train": int(len(tr)), "heldout": int(len(ho)), "real": int(y.sum()), "not_real": int((y == 0).sum()),
                                     "made_up_listings": sum(r.get("source") == datasets.SYNTH for r in rows)}, force)


def train_place(rows, force=False):
    tr, ho = evaluate.split([r["key"] for r in rows])
    train_rows = [rows[i] for i in tr]
    seen = {r["game"] for r in train_rows}
    test_rows = [rows[i] for i in ho if rows[i]["game"] in seen]
    results = []
    for d in designs.place_designs():
        t0 = time.time()
        d.fit(train_rows)
        y, p = [], []
        by = {}
        for r in test_rows:
            by.setdefault(r["game"], []).append(r)
        for g, rs in by.items():
            for r, (lab, conf) in zip(rs, d.predict_many(g, [x["what"] for x in rs], [x["text"] for x in rs])):
                y.append(int(lab == r["label"]))
                p.append(conf)
        t = evaluate.threshold_at(y, p)
        rep = evaluate.report(y, p, t)
        rep["accuracy"] = round(float(np.mean(y)), 4) if y else None
        results.append({"name": d.name, "model": d, "heldout": rep, "seconds": round(time.time() - t0, 1)})
    return _finish("place", results, {"train": len(train_rows), "heldout": len(test_rows), "games": len(seen)}, force)


def _seed(key, salt):
    return int(hashlib.sha1(f"{key}|{salt}".encode()).hexdigest()[:8], 16)


POS, EASY, HARD = "same", "other", "hard"


def photo_pairs(items, with_kinds=False):
    """Per item: one 'same item' pair (its own picture vs a made-up variation of its other copy), one 'different item' pair (a variation of it vs another item of the same set)
    and a HARD 'different item' pair per hard look-alike (same set, same frame, another name: datasets.photo_items).
    -> (pairs of features, labels, item keys[, kinds])"""
    pairs, y, keys, kinds = [], [], [], []
    for it in items:
        try:
            a = imgfeat.open_image(it["paths"][0])
            b = imgfeat.open_image(it["paths"][-1])
            o = imgfeat.open_image(it["other"])
            hs = [imgfeat.open_image(h) for h in it.get("hard") or ()]
        except Exception:  # noqa: BLE001  (a broken cached file is skipped)
            continue
        rng = np.random.default_rng(_seed(it["key"], "pos"))
        fa = imgfeat.features(a)
        pairs.append((fa, imgfeat.features(imgfeat.vary(b, rng))))
        va = imgfeat.features(imgfeat.vary(a, np.random.default_rng(_seed(it["key"], "neg"))))
        pairs.append((va, imgfeat.features(o)))
        y += [1, 0]
        kinds += [POS, EASY]
        for h in hs:
            pairs.append((va, imgfeat.features(h)))
            y.append(0)
            kinds.append(HARD)
        keys += [it["key"]] * (2 + len(hs))
    return (pairs, np.array(y), keys, kinds) if with_kinds else (pairs, np.array(y), keys)


def hard_report(y, p, kinds, keys, t):
    """The held-out result on the HARD pairs only (the same-item pairs + the same-frame look-alikes): at the model's threshold, and - the honest one - with the threshold picked on
    one half of the held-out items and measured on the other half."""
    sel = np.array([k != EASY for k in kinds])
    if not sel.any() or not (np.asarray(kinds) == HARD).any():
        return None
    ys, ps, ks = np.asarray(y)[sel], np.asarray(p)[sel], [k for k, s in zip(keys, sel) if s]
    out = evaluate.report(ys, ps, t)
    out["hard_pairs"] = int((ys == 0).sum())
    cal = np.array([evaluate.is_heldout(k + "|cal", 0.5) for k in ks])
    tc = evaluate.threshold_at(ys[cal], ps[cal])
    other = evaluate.report(ys[~cal], ps[~cal], tc)
    out["other_half"] = {"threshold": tc, "precision": other["precision"], "recall": other["recall"], "n": other["n"], "hard_pairs": int((ys[~cal] == 0).sum()),
                         "accepted_wrong": int(((ps[~cal] >= tc) & (ys[~cal] == 0)).sum()) if tc is not None else 0}
    return out


def feedback_pairs(rows):
    pairs, y, keys = [], [], []
    for r in rows:
        try:
            pairs.append((imgfeat.features(r["a"]), imgfeat.features(r["b"])))
        except Exception:  # noqa: BLE001  (the owner's answer is kept on the list; a picture no longer on disk is skipped)
            continue
        y.append(r["y"])
        keys.append(r["key"])
    return pairs, np.array(y, dtype=int), keys


def train_photo(items, extra=(), force=False):
    pairs, y, keys, kinds = photo_pairs(items, with_kinds=True)
    if extra:
        p2, y2, k2 = feedback_pairs(extra)
        pairs, y, keys, kinds = pairs + p2, np.concatenate([y, y2]), keys + k2, kinds + [POS if v else HARD for v in y2]      # (an owner's 'not the same' is a hard pair)
    tr, ho = evaluate.split(keys)
    results = []
    for d in designs.photo_designs():
        t0 = time.time()
        d.fit([pairs[i] for i in tr], y[tr])
        p = np.array([d.score(*pairs[i]) for i in ho])
        t = evaluate.threshold_at(y[ho], p)
        h = evaluate.report(y[ho], p, t)
        hr = hard_report(y[ho], p, [kinds[i] for i in ho], [keys[i] for i in ho], t)
        if hr:
            h["hard"] = hr
        results.append({"name": d.name, "model": d, "heldout": h, "seconds": round(time.time() - t0, 1)})
    return _finish("photo", results, {"train_pairs": int(len(tr)), "heldout_pairs": int(len(ho)), "items": len(items), "hard_pairs": kinds.count(HARD)}, force)


def train_all(data_dir, tasks=("photo", "real", "place"), force=False, photo_limit=1200, log=print):
    out = {}
    if "real" in tasks:
        rows = datasets.real_rows(data_dir)
        log(f"real: {len(rows)} rows")
        out["real"] = train_real(rows, force)
    if "place" in tasks:
        rows = datasets.place_rows(data_dir)
        log(f"place: {len(rows)} rows")
        out["place"] = train_place(rows, force)
    if "photo" in tasks:
        items = datasets.photo_items(data_dir, photo_limit)
        log(f"photo: {len(items)} pictured items")
        if len(items) >= 20:
            out["photo"] = train_photo(items, feedback.labels("photo"), force)
    return out
