"""MINI YOU: small models built from scratch and trained here, on the app's own catalog data (owner 2026-11-05, quiz 12 2026-11-13).  No paid AI service, no downloaded weights.
They only SCORE; plain code still fetches and applies the rules.  A low score sends the item to the owner's ONE review list (cardvault/reviewlist.py), and his yes / no answers there are
read back as new training labels (feedback.py).

  photo   is this product photo the same item?   (perceptual hashes + a learned embedding / pair model; product pictures from the catalog cache only, never anybody's own photos)
  real    is this a real release, or a custom / bundle / shop listing?   (small text model)
  place   which series / line does a new set or product belong to?   (small text model per game)

Modules: registry (versioned model files, git-ignored), textfeat / imgfeat (features), datasets (training rows), evaluate (held-out split + the 99 % precision threshold),
designs (2-3 candidate designs per task), train (pick the best), score (load + decide), feedback (the review list in and out), hook (the daily update's step)."""

TASKS = ("photo", "real", "place")
TARGET_PRECISION = 0.99          # auto-accept only above a threshold whose held-out precision is at least this
