"""Training rows for the three models, read (read-only) from the app's own catalog: games/<game>/cards.db, the toy shops' archived product feeds, and the catalog's own cached PRODUCT
pictures (games/<game>/images/<size>/<set>/<id>.<ext>).  Never the collection, profiles or anybody's uploaded photos.  Plus the owner's answers on the review list (feedback.py)."""
import glob
import json
import os
import random
import re
import sqlite3

from . import feedback, textfeat

PER_GAME = 1500                 # rows per game and kind at most (the big games would drown the small ones)
IMAGE_EXT = (".webp", ".jpg", ".jpeg", ".png")


def _games_dir(data_dir):
    return os.path.join(data_dir, "games")


def _ro(db):
    c = sqlite3.connect("file:" + db.replace("\\", "/") + "?mode=ro", uri=True, timeout=30)
    return c


def catalogs(data_dir):
    """-> [(game id, path of its cards.db)]"""
    return [(os.path.basename(os.path.dirname(p)), p) for p in sorted(glob.glob(os.path.join(_games_dir(data_dir), "*", "cards.db")))]


def _family(game):
    try:
        from cardvault import games
        g = games.game_by_id(game)
        return getattr(g, "family", "") if g else ""
    except Exception:  # noqa: BLE001
        return ""


def _sample(rows, n, seed):
    rows = sorted(rows)
    if len(rows) <= n:
        return rows
    return random.Random(seed).sample(rows, n)


def _table_cols(conn, table):
    return {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}


# ---- (b) real release vs custom / bundle / listing -------------------------------------------------------------------------------------------------------------------------------

def _shop_rules(game):
    from cardvault import toyrules
    return {"chomps": (toyrules._chomp_keep, toyrules._NOT_TOY), "dumpsterfires": (toyrules._df_keep, toyrules._NOT_TOY_SOFT)}.get(game)


def real_rows(data_dir):
    """-> [{key, game, text, y, source}]: y 1 = a real release, 0 = not one (a shop listing, an accessory, a bundle, a fan custom).
    1: the catalog's own rows (toy lists in full, plus sealed products of every game);  0: archived shop products the toy rules leave out, toyrules.NOT_OFFICIAL, and owner 'no' answers."""
    from cardvault import toyrules
    out = []
    for game, db in catalogs(data_dir):
        c = _ro(db)
        try:
            toy = _family(game) == "collectibles"
            if toy:
                rows = [(i, n) for i, n in c.execute("SELECT id, name FROM cards") if i not in toyrules.NOT_OFFICIAL]
                for i, n in _sample(rows, PER_GAME, game):
                    out.append({"key": f"{game}:{i}", "game": game, "text": textfeat.norm(n), "y": 1, "source": "catalog"})
            if "sealed_products" in {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
                rows = list(c.execute("SELECT id, name FROM sealed_products"))
                for i, n in _sample(rows, PER_GAME // 5, game):
                    out.append({"key": f"{game}:sealed:{i}", "game": game, "text": textfeat.norm(n), "y": 1, "source": "catalog"})
        finally:
            c.close()
        arch = os.path.join(os.path.dirname(db), "archive_products.json")
        rules = _shop_rules(game)
        if os.path.exists(arch) and rules:
            keep, exclude = rules
            with open(arch, encoding="utf-8") as f:
                shops = json.load(f)
            for shop, prods in shops.items():
                if shop.startswith("_") or not isinstance(prods, dict):
                    continue
                for h, p in prods.items():
                    if not isinstance(p, dict):
                        continue                                # a gone product is kept as null
                    t = p.get("title") or ""
                    official = keep(p) and not exclude.search(toyrules._core(t)) and f"shp:{h}" not in toyrules.NOT_OFFICIAL
                    out.append({"key": f"{game}:{shop}:{h}", "game": game, "text": textfeat.norm(toyrules._clean_title(t)), "y": int(official), "source": f"shop archive {shop}"})
    for i in sorted(toyrules.NOT_OFFICIAL):
        out.append({"key": f"notofficial:{i}", "game": "", "text": textfeat.norm(i.split(":", 1)[-1].replace("-", " ")), "y": 0, "source": "toyrules.NOT_OFFICIAL"})
    out += feedback.labels("real")
    out = [r for r in out if r["text"]]
    return out + listing_rows(out)


# What shops and auction listings wrap around a real name: lots, customs, graded copies, merch, parts.  The real negatives above are few (a few dozen), so these rule-made ones (marked
# source 'made-up listing') teach the model what a listing looks like; the report scores the real rows on their own too, so the made-up ones never flatter the result.
LISTING_TEMPLATES = ("lot of {k} {n}", "{n} lot of {k}", "{n} x{k} lot", "{n} custom painted", "custom {n} fan made", "{n} fan art print", "{n} psa {g} graded", "{n} bgs {g} gem mint",
                     "{n} cgc {g}", "{n} proxy", "{n} replica", "{n} reprint not original", "{n} t-shirt", "{n} hoodie size l", "{n} enamel pin", "{n} keychain", "{n} sticker sheet",
                     "{n} empty box only", "{n} display stand only", "{n} damaged box read description", "{n} with free pin bundle", "{n} mystery bundle {k} items", "{n} free shipping",
                     "{n} pick your own", "{n} you choose", "{n} 3d printed", "{n} unofficial", "{n} bootleg", "{n} knock off", "{n} gift card", "{n} poster", "{n} coffee mug")


def listing_rows(rows, share=0.35, seed=11):
    """Rule-made listing titles from real names: about `share` as many as the real rows, picked the same way every run.  -> [{key, game, text, y=0, source}]"""
    real = sorted((r for r in rows if r["y"] == 1), key=lambda r: r["key"])
    rng = random.Random(seed)
    out = []
    for r in rng.sample(real, min(len(real), int(len(real) * share))):
        t = rng.choice(LISTING_TEMPLATES).format(n=r["text"], k=rng.randint(2, 12), g=rng.choice((7, 8, 9, 10)))
        out.append({"key": "listing:" + r["key"], "game": r["game"], "text": textfeat.norm(t), "y": 0, "source": SYNTH})
    return out


SYNTH = "made-up listing"


# ---- (c) set / line placer -------------------------------------------------------------------------------------------------------------------------------------------------------------

def place_text(name, code="", date="", source=""):
    return " ".join(x for x in (textfeat.norm(name), textfeat.code_tokens(code), textfeat.year_token(date), ("src_" + textfeat.norm(source).replace(" ", "_")) if source else "") if x)


def place_rows(data_dir):
    """-> [{key, game, text, label, what}]: a set -> its series; a sealed product -> its series; a toy -> its line (the toy lists' 'sets')."""
    out = []
    for game, db in catalogs(data_dir):
        c = _ro(db)
        try:
            tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            sets = {i: (n, s, d) for i, n, s, d in c.execute("SELECT id, name, serie, release_date FROM sets")}
            for i, (n, s, d) in sets.items():
                if s:
                    out.append({"key": f"{game}:set:{i}", "game": game, "text": place_text(n, i, d), "label": s, "what": "set"})
            if "sealed_products" in tables and "serie" in _table_cols(c, "sealed_products"):
                rows = [(i, n, s, r) for i, n, s, r in c.execute("SELECT id, name, serie, released FROM sealed_products WHERE serie IS NOT NULL AND serie != ''")]
                for i, n, s, r in _sample(rows, PER_GAME, game):
                    out.append({"key": f"{game}:sealed:{i}", "game": game, "text": place_text(n, "", r), "label": s, "what": "product"})
            if _family(game) == "collectibles" and len(sets) > 1:
                rows = [(i, n, s) for i, n, s in c.execute("SELECT id, name, set_id FROM cards") if s in sets]
                for i, n, s in _sample(rows, PER_GAME, game):
                    out.append({"key": f"{game}:item:{i}", "game": game, "text": place_text(n), "label": "line:" + (sets[s][0] or s), "what": "item"})
        finally:
            c.close()
    out += feedback.labels("place")
    return [r for r in out if r["text"]]


# ---- (a) photo matcher -------------------------------------------------------------------------------------------------------------------------------------------------------------------

def picture_index(game_dir):
    """One game's cached product pictures -> {(set id, item id): [paths]}.  Two layouts: images/<size>/<set>/<id>.<ext>, and the flat images/<size>/<id>.<ext> (the set then comes from cards.db)."""
    found, flat = {}, {}
    for size in ("low", "high"):
        base = os.path.join(game_dir, "images", size)
        if not os.path.isdir(base):
            continue
        for e in os.scandir(base):
            if e.is_dir():
                for f in os.scandir(e.path):
                    stem, ext = os.path.splitext(f.name)
                    if ext.lower() in IMAGE_EXT:
                        found.setdefault((e.name, stem), []).append(f.path)
            else:
                stem, ext = os.path.splitext(e.name)
                if ext.lower() in IMAGE_EXT:
                    flat.setdefault(stem, []).append(e.path)
    db = os.path.join(game_dir, "cards.db")
    if flat and os.path.exists(db):
        c = _ro(db)
        try:
            ids = sorted(flat)
            for k in range(0, len(ids), 500):
                chunk = ids[k:k + 500]
                for i, sid in c.execute(f"SELECT id, set_id FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                    found.setdefault((str(sid or "_"), i), []).extend(flat[i])
        finally:
            c.close()
    return found


FRAME_COLS = ("rarity", "category", "types", "stage")          # what decides a card's frame (border, colour, layout), where the list has it
HARD_PER_ITEM = 2


def base_name(name):
    """'Clefable (Holo)' and 'Clefable - 63/102' are both 'clefable': two items with the same base name may share a picture on purpose."""
    s = re.sub(r"\s*[\(\[].*?[\)\]]", "", str(name or "")).split(" - ")[0]
    return re.sub(r"[^a-z0-9]+", "", s.lower())


def _frames(game_dir, ids):
    """{item id: (frame key, base name)} for the given items, read from the list (empty when it has no cards table with names)."""
    db = os.path.join(game_dir, "cards.db")
    if not os.path.exists(db):
        return {}
    c = _ro(db)
    try:
        have = set(_table_cols(c, "cards"))
        if "name" not in have:
            return {}
        cols = [k for k in FRAME_COLS if k in have]
        out, ids = {}, sorted(ids)
        for k in range(0, len(ids), 500):
            chunk = ids[k:k + 500]
            for row in c.execute(f"SELECT id, name{''.join(', ' + x for x in cols)} FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                out[str(row[0])] = (tuple(str(v or "") for v in row[2:]), base_name(row[1]))
        return out
    except sqlite3.Error:
        return {}
    finally:
        c.close()


def photo_items(data_dir, limit=1200, seed=7):
    """The catalog's cached product pictures: -> [{key, game, set, id, paths, other, hard}] (one item may have a small and a large copy; `other` is another item of the same set;
    `hard` = up to HARD_PER_ITEM pictures of HARD look-alikes: same set, same frame (rarity, card kind, type, stage) and a different name - Clefable vs Wigglytuff).
    At most `limit` items, shared evenly between the games that have pictures, picked the same way every run."""
    per_game = {}
    for game_dir in sorted(glob.glob(os.path.join(_games_dir(data_dir), "*"))):
        if os.path.isdir(os.path.join(game_dir, "images")):
            idx = picture_index(game_dir)
            if idx:
                per_game[os.path.basename(game_dir)] = (idx, game_dir)
    rng = random.Random(seed)
    out, budget, left = [], limit, len(per_game)
    for game in sorted(per_game, key=lambda g: (len(per_game[g][0]), g)):   # small games first; what they cannot fill goes to the bigger ones
        found, gdir = per_game[game]
        by_set = {}
        for k in sorted(found):
            by_set.setdefault(k[0], []).append(k)
        keys = [k for k in sorted(found) if len(by_set[k[0]]) > 1]        # an item needs a neighbour in its own set to be a 'different item' example
        take = _sample(keys, budget // left, f"{seed}:{game}")
        budget, left = budget - len(take), left - 1
        frames = _frames(gdir, {o[1] for k in take for o in by_set[k[0]]})
        for k in take:
            others = [o for o in by_set[k[0]] if o != k]
            mine = frames.get(k[1])
            hard = [o for o in others if o[1] in frames and frames[o[1]][0] == mine[0] and frames[o[1]][1] != mine[1]] if mine and mine[1] else []
            hard = random.Random(f"{seed}:hard:{game}:{k}").sample(hard, min(HARD_PER_ITEM, len(hard)))
            out.append({"key": f"{game}:{k[0]}:{k[1]}", "game": game, "set": k[0], "id": k[1], "paths": sorted(found[k]), "other": sorted(found[rng.choice(others)])[0],
                        "hard": [sorted(found[o])[0] for o in hard]})
    return out
