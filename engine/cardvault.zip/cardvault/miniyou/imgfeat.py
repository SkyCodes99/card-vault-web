"""Picture features for the photo matcher, all plain numpy / Pillow: perceptual hashes (difference hash and DCT hash), a small grey thumbnail, a colour histogram and an edge-direction
histogram.  Also the made-up variations (crop, scale, brightness, re-compression) used as 'same item' examples.  PRODUCT pictures only: callers never pass anybody's own photos."""
import io

import numpy as np
from PIL import Image, ImageEnhance

THUMB = 16


def open_image(src):
    """A path, bytes or a PIL image -> an RGB PIL image."""
    if isinstance(src, Image.Image):
        im = src
    elif isinstance(src, (bytes, bytearray)):
        im = Image.open(io.BytesIO(src))
    else:
        im = Image.open(src)
    im.load()
    return im.convert("RGB")


def dhash(im, size=8):
    g = np.asarray(im.convert("L").resize((size + 1, size), Image.BILINEAR), dtype=np.float32)
    return (g[:, 1:] > g[:, :-1]).flatten()


def phash(im, size=8):
    from scipy.fft import dctn
    g = np.asarray(im.convert("L").resize((32, 32), Image.BILINEAR), dtype=np.float32)
    d = dctn(g, norm="ortho")[:size, :size].flatten()
    return d[1:] > np.median(d[1:])


def thumb(im):
    g = np.asarray(im.convert("L").resize((THUMB, THUMB), Image.BILINEAR), dtype=np.float32).flatten()
    g -= g.mean()
    return g / (np.linalg.norm(g) + 1e-6)


def colour_hist(im, bins=4):
    a = np.asarray(im.resize((48, 48), Image.BILINEAR), dtype=np.int32) * bins // 256
    idx = (a[..., 0] * bins + a[..., 1]) * bins + a[..., 2]
    h = np.bincount(idx.flatten(), minlength=bins ** 3).astype(np.float32)
    return h / (h.sum() + 1e-6)


def edge_hist(im, bins=8, grid=2):
    g = np.asarray(im.convert("L").resize((64, 64), Image.BILINEAR), dtype=np.float32)
    gx, gy = np.gradient(g)
    mag, ang = np.hypot(gx, gy), (np.arctan2(gy, gx) % np.pi)
    b = np.minimum((ang / np.pi * bins).astype(int), bins - 1)
    out = []
    step = 64 // grid
    for i in range(grid):
        for j in range(grid):
            sl = (slice(i * step, (i + 1) * step), slice(j * step, (j + 1) * step))
            out.append(np.bincount(b[sl].flatten(), weights=mag[sl].flatten(), minlength=bins))
    h = np.concatenate(out).astype(np.float32)
    return h / (np.linalg.norm(h) + 1e-6)


ART_BOX = (0.10, 0.10, 0.90, 0.55)        # left, top, right, bottom: where a card's artwork sits (and the middle of a toy's box picture) - what tells two same-frame items apart


def art(im):
    w, h = im.size
    l, t, r, b = ART_BOX
    return im.crop((int(w * l), int(h * t), max(int(w * r), int(w * l) + 8), max(int(h * b), int(h * t) + 8)))


def features(src):
    """-> dict of the picture's features (the hashes as bool arrays); the art_* ones are the same numbers for the artwork window only."""
    im = open_image(src)
    a = art(im)
    return {"dhash": dhash(im), "phash": phash(im), "thumb": thumb(im), "colour": colour_hist(im), "edge": edge_hist(im), "aspect": im.width / max(im.height, 1),
            "art_dhash": dhash(a, 12), "art_phash": phash(a, 12), "art_thumb": thumb(a), "art_colour": colour_hist(a), "art_edge": edge_hist(a)}


def vary(im, rng):
    """One made-up variation of a product picture: a small crop, a new size, brightness / contrast and a JPEG re-save (what another shop's copy of the same picture looks like)."""
    w, h = im.size
    c = rng.uniform(0.0, 0.08, 4)
    im = im.crop((int(w * c[0]), int(h * c[1]), max(int(w * (1 - c[2])), int(w * c[0]) + 8), max(int(h * (1 - c[3])), int(h * c[1]) + 8)))
    s = rng.uniform(0.5, 1.3)
    im = im.resize((max(16, int(im.width * s)), max(16, int(im.height * s))), Image.BILINEAR)
    im = ImageEnhance.Brightness(im).enhance(rng.uniform(0.8, 1.2))
    im = ImageEnhance.Contrast(im).enhance(rng.uniform(0.8, 1.2))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=int(rng.integers(45, 90)))
    return open_image(buf.getvalue())


def hamming(a, b):
    return float(np.count_nonzero(a != b)) / len(a)


def pair_vector(fa, fb, embed=None):
    """The numbers the pair models look at: hash distances, how alike the thumbnails / colours / edges are, the aspect ratio gap, and (with a learned embedding) its cosine."""
    v = [hamming(fa["dhash"], fb["dhash"]), hamming(fa["phash"], fb["phash"]), float(fa["thumb"] @ fb["thumb"]),
         float(np.minimum(fa["colour"], fb["colour"]).sum()), float(fa["edge"] @ fb["edge"]), abs(np.log(fa["aspect"] / fb["aspect"]))]
    if embed is not None:
        ea, eb = embed(fa), embed(fb)
        v.append(float(ea @ eb / (np.linalg.norm(ea) * np.linalg.norm(eb) + 1e-6)))
        v.extend(np.abs(ea - eb)[:8])
    return np.array(v, dtype=np.float32)


def art_vector(fa, fb):
    """How alike the two artwork windows are (hash distances, thumbnail / colour / edge likeness): the part of a picture that differs between two cards of one frame."""
    return np.array([hamming(fa["art_dhash"], fb["art_dhash"]), hamming(fa["art_phash"], fb["art_phash"]), float(fa["art_thumb"] @ fb["art_thumb"]),
                     float(np.minimum(fa["art_colour"], fb["art_colour"]).sum()), float(fa["art_edge"] @ fb["art_edge"])], dtype=np.float32)


def raw_vector(f):
    """The picture's own numbers, input of the learned embedding."""
    return np.concatenate([f["thumb"], f["colour"], f["edge"]])
