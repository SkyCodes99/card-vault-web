"""The daily update's Mini you step (tools/daily_update.py): scores what plain code just added to one game and writes every decision into the day's log (kind 'miniyou', with its source).

Modes (--miniyou=<mode> or MINIYOU_MODE; default 'score'):
  off     nothing
  score   score + log only: the log says what Mini you WOULD do; nothing is queued
  auto    a score above the model's threshold (held-out precision >= 99 %) is logged as auto-accepted; everything else goes on the owner's review list (feedback.queue).
          The ONE change Mini you may make to a list (owner, chat 2026-11-13: "2 as in the mini me"): its line placer, sure of another line for a new toy, MOVES it - only
          when the model passed evaluate.auto_ok AND 1+ independent source agrees (cardvault/accuracy/moves.py), through the fix log (by 'mini you'), so Dev Tools > Changes
          shows it with Revert.  Nothing Mini you changes bypasses the fix log.  The real-vs-custom model stays score-only (it did not pass auto_ok).
          tools/run_daily_update.bat runs the daily update with --miniyou=auto.
Otherwise scoring never changes the catalog: plain code and its gates still decide what is added.  A failing model never stops the daily run (the caller catches and logs)."""
import os
import sqlite3

from cardvault import dailylog

from . import datasets, evaluate, feedback, textfeat
from .score import Scorer

MODES = ("off", "score", "auto")
DEFAULT = "score"
CAP = 200                        # decisions logged one by one per game and model; the rest as one count


def mode_from(argv=(), env=None):
    env = os.environ if env is None else env
    for a in argv:
        if a.startswith("--miniyou="):
            m = a.split("=", 1)[1].strip().lower()
            return m if m in MODES else DEFAULT
    m = (env.get("MINIYOU_MODE") or DEFAULT).strip().lower()
    return m if m in MODES else DEFAULT


def _rows(db, sql, ids):
    if not ids:
        return []
    c = sqlite3.connect(db, timeout=60)
    try:
        out = []
        ids = list(ids)
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            out += c.execute(sql.format(",".join("?" * len(chunk))), chunk).fetchall()
        return out
    except sqlite3.Error:
        return []
    finally:
        c.close()


class Step:
    def __init__(self, mode, scorer=None):
        self.mode, self.scorer = mode, scorer or Scorer()
        self.counts = {}

    def _auto(self, task):
        """'auto' acts only for a model whose held-out result cleared the bar (evaluate.auto_ok); any other model stays score + log only, even in 'auto'."""
        return self.mode == "auto" and evaluate.auto_ok(self.scorer._get(task)[1])

    def _log(self, events, game, task, name, item_id, score, decision, note):
        key = (game, task)
        n = self.counts[key] = self.counts.get(key, 0) + 1
        if n == CAP + 1:
            events.append(dailylog.event(game, "miniyou", self.scorer.label(task), note="more decisions not listed one by one (see the counts)"))
        if n > CAP:
            return
        what = {"accept": "auto-accepted" if self._auto(task) else "would auto-accept", "review": "sent to your review list" if self._auto(task) else "would send to your review list",
                "moved": "MOVED (fix log, Dev Tools > Changes)", "asked": "the checkers disagree: one question on your review list"}[decision]
        if task == "photo" and decision == "accept":
            what = "no look-alike found"
        events.append(dailylog.event(game, "miniyou", self.scorer.label(task), name, item_id, 1, f"{task} score {score:.3f}: {what}. {note}".strip()))

    def _review(self, task, game, item_id, question, before, score):
        if self._auto(task):
            feedback.queue(task, game, item_id, question, before, score)

    def real(self, events, game, items):
        """items: [(id, name)] just added."""
        if not items or not self.scorer.available("real"):
            return
        texts = [textfeat.norm(n) for _, n in items]
        for (i, n), t, (p, d) in zip(items, texts, self.scorer.real(texts)):
            self._log(events, game, "real", n, i, p, d, "")
            if d == "review":
                self._review("real", game, i, f'Is "{n}" a real release (not a custom, a bundle or a shop listing)?', {"text": t, "name": n}, p)

    def place(self, events, game, rows):
        """rows: [(id, name, code, date, the series / line plain code gave it, what)] -> agree + confident = accept, else review."""
        if not rows or not self.scorer.available("place"):
            return
        thr = (self.scorer._get("place")[1] or {}).get("threshold")
        for i, n, code, date, have, what in rows:
            text = datasets.place_text(n, code, date)
            lab, conf = self.scorer.place(game, what, text)
            agree = lab is not None and lab == have
            d = "accept" if agree and thr is not None and conf >= thr else "review"
            note = f'model says "{lab}", the list has "{have}"'
            if d == "review" and what == "item" and lab and thr is not None and conf >= thr and self._auto("place") and getattr(self, "_db", None):
                d, note = self._move(game, i, lab, conf, have, note)
            self._log(events, game, "place", n, i, conf, d, note)
            if d == "review":
                self._review("place", game, i, f'Is "{have}" the right {"line" if what == "item" else "series"} for "{n}"? (Mini you thinks "{lab}")', {"text": text, "label": have, "what": what, "name": n}, conf)

    def _move(self, game, item_id, lab, conf, have, note):
        """Sure of another line: move it when a source agrees (cardvault/accuracy/moves.py, through the fix log) -> (decision, note)."""
        from cardvault.accuracy import moves
        try:
            how, what = moves.miniyou_move(game, self._db, item_id, lab, conf, self.scorer.label("place"), have)
        except Exception as e:  # noqa: BLE001 - a move that cannot be made is asked instead
            return "review", f"{note}; not moved ({str(e)[:80]})"
        if how == "moved":
            return "moved", f"{note}; moved, fix {what['id']}"
        return ("asked", f"{note}; {what}") if how == "asked" else ("review", f"{note}; not moved: {what}")

    def photos(self, events, game, gdir, new_ids):
        """A new item whose cached product picture looks like ANOTHER item's picture of the same set (a stand-in picture) -> review.  Only pictures already in the catalog's cache."""
        if not new_ids or not self.scorer.available("photo"):
            return
        for i, best, who, pics in lookalikes(self.scorer, gdir, new_ids):
            d = self.scorer.lookalike(best)
            self._log(events, game, "photo", "", i, best, d, f"closest other item: {who or 'none'}")
            if d == "review":
                self._review("photo", game, i, f"The picture of {i} looks like the picture of {who}. Are they the same item?", {"a": pics[i], "b": pics[who]}, best)

    def run(self, events, game, db, new_cards, new_sealed, new_set_ids, family=""):
        """The whole step for one game after its list was refreshed.  new_cards / new_sealed: {id: name}; new_set_ids: ids of sets that were not there before."""
        if self.mode == "off":
            return
        self._db = db
        self.real(events, game, sorted(new_cards.items()) + sorted(new_sealed.items()))
        rows = [(i, n, i, d, s, "set") for i, n, s, d in _rows(db, "SELECT id, name, serie, release_date FROM sets WHERE id IN ({})", new_set_ids) if s]
        rows += [(i, n, "", r, s, "product") for i, n, s, r in _rows(db, "SELECT id, name, serie, released FROM sealed_products WHERE id IN ({})", list(new_sealed)) if s]
        if family == "collectibles":
            rows += [(i, n, "", "", "line:" + (sn or s), "item") for i, n, s, sn in _rows(db, "SELECT c.id, c.name, c.set_id, s.name FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id IN ({})", list(new_cards))]
        self.place(events, game, rows)
        self.photos(events, game, os.path.dirname(db), list(new_cards))


def lookalikes(scorer, gdir, ids, per_set=30):
    """For each of `ids` that has a cached product picture: the other item of its set whose picture looks most like it.  Yields (item id, best same-item score, that other item's id,
    {item id: picture path} of the set).  Only pictures already in the catalog's cache; the daily step above and the daily accuracy check (cardvault/accuracy) both read it."""
    want = set(ids)
    by_set = {}
    for (s, i), paths in datasets.picture_index(gdir).items():          # both picture layouts (per-set folders, or flat with the set from cards.db)
        by_set.setdefault(s, {})[i] = sorted(paths)[0]
    for pics in by_set.values():
        for i in sorted(want & set(pics)):
            best, who = 0.0, ""
            for o in sorted(k for k in pics if k != i)[:per_set]:
                s = scorer.photo(pics[i], pics[o])
                if s is not None and s > best:
                    best, who = s, o
            yield i, best, who, pics
