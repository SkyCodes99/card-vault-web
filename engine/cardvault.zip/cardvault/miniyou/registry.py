"""Versioned model files: <models dir>/<task>/v0001.pkl + v0001.json (the scores and threshold it was kept with).  The models dir is git-ignored (models/miniyou/ in the project, or MINIYOU_MODELS).
The newest version is the one in use; the last KEEP versions are kept so a bad one can be rolled back by deleting the newest pair."""
import glob
import json
import os
import pickle
import re

KEEP = 3
_V = re.compile(r"v(\d{4})\.pkl$")


def models_dir():
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.environ.get("MINIYOU_MODELS") or os.path.join(root, "models", "miniyou")


def versions(task):
    """-> [1, 2, ...] oldest first"""
    return sorted(int(m.group(1)) for f in glob.glob(os.path.join(models_dir(), task, "v*.pkl")) if (m := _V.search(f)))


def save(task, model, meta):
    """Write the next version; old ones beyond KEEP are removed (only this task's own files in the models dir).  -> the version number"""
    d = os.path.join(models_dir(), task)
    os.makedirs(d, exist_ok=True)
    have = versions(task)
    v = (have[-1] if have else 0) + 1
    base = os.path.join(d, f"v{v:04d}")
    with open(base + ".pkl.tmp", "wb") as f:
        pickle.dump(model, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(base + ".json", "w", encoding="utf-8") as f:
        json.dump(dict(meta, version=v, task=task), f, indent=1, ensure_ascii=False)
    os.replace(base + ".pkl.tmp", base + ".pkl")                  # the model appears last, so a half-written version is never loaded
    for old in versions(task)[:-KEEP]:
        for ext in (".pkl", ".json"):
            p = os.path.join(d, f"v{old:04d}{ext}")
            if os.path.exists(p):
                os.remove(p)
    return v


def meta(task, version=None):
    have = versions(task)
    if not have:
        return None
    v = version or have[-1]
    p = os.path.join(models_dir(), task, f"v{v:04d}.json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def load(task, version=None):
    """-> (model, meta) of the newest (or the given) version, or (None, None).  Only our own files, written by save(), are ever unpickled."""
    have = versions(task)
    if not have:
        return None, None
    v = version or have[-1]
    with open(os.path.join(models_dir(), task, f"v{v:04d}.pkl"), "rb") as f:
        return pickle.load(f), meta(task, v)
