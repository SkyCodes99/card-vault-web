"""Text features for the small text models: one normal form of a name, and hashed word + character n-grams (no vocabulary file to keep in step)."""
import html
import re
import unicodedata

_WS = re.compile(r"\s+")
_NONWORD = re.compile(r"[^0-9a-z#&+/' -]+")
_CODE = re.compile(r"([a-z]+)(\d*)")


def norm(s):
    s = unicodedata.normalize("NFKD", html.unescape(str(s or ""))).encode("ascii", "ignore").decode().lower()
    return _WS.sub(" ", _NONWORD.sub(" ", s)).strip()


def code_tokens(code):
    """'swsh12pt5' -> 'code_swsh code_swsh12'; 'sv-p' -> 'code_sv code_p': the letters of a set code say a lot about its series."""
    out = []
    for part in re.split(r"[^0-9a-z]+", str(code or "").lower().split(":")[-1]):
        m = _CODE.match(part)
        if m and m.group(1):
            out.append("code_" + m.group(1))
            if m.group(2):
                out.append("code_" + m.group(1) + m.group(2))
    return " ".join(out)


def year_token(date):
    m = re.match(r"(\d{4})", str(date or ""))
    return f"year_{m.group(1)} decade_{m.group(1)[:3]}" if m else "year_none"


def vectorizer(kind="char", n_features=2 ** 18):
    """kind: 'word' (words + word pairs), 'char' (character 2-5 grams inside words), 'both'.  Counts are non-negative so Naive Bayes can use them too."""
    from sklearn.feature_extraction.text import HashingVectorizer
    from sklearn.pipeline import FeatureUnion
    word = HashingVectorizer(analyzer="word", ngram_range=(1, 2), n_features=n_features, alternate_sign=False, norm="l2", token_pattern=r"[^ ]+")
    char = HashingVectorizer(analyzer="char_wb", ngram_range=(2, 5), n_features=n_features, alternate_sign=False, norm="l2")
    if kind == "word":
        return word
    if kind == "char":
        return char
    return FeatureUnion([("w", word), ("c", char)])
