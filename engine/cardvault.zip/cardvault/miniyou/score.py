"""Load the models in use and score with them.  decide(): 'accept' only when the model has a threshold (held-out precision >= 99 %) and the score clears it; everything else is 'review'."""
from . import evaluate, imgfeat, registry


class Scorer:
    FEATURES_KEPT = 4000             # picture files whose features are remembered while a run compares one picture with many others

    def __init__(self):
        self._m = {}
        self._feat = {}

    def _features(self, src):
        """A picture's features; a picture FILE is read once per run, not once per comparison (a new item is compared with up to 30 others of its set)."""
        if not isinstance(src, str):
            return imgfeat.features(src)
        if src not in self._feat:
            if len(self._feat) >= self.FEATURES_KEPT:
                self._feat.clear()
            self._feat[src] = imgfeat.features(src)
        return self._feat[src]

    def _get(self, task):
        if task not in self._m:
            self._m[task] = registry.load(task)
        return self._m[task]

    def available(self, task):
        return self._get(task)[0] is not None

    def version(self, task):
        meta = self._get(task)[1]
        return meta["version"] if meta else None

    def label(self, task):
        """'real-release model v3 (logistic chars)' - the source written next to every decision in the daily log."""
        meta = self._get(task)[1]
        return f"Mini you {task} model v{meta['version']} ({meta['design']})" if meta else f"Mini you {task} model (not trained)"

    def threshold(self, task):
        """The model's auto-accept threshold (held-out precision >= 99 %), or None."""
        return (self._get(task)[1] or {}).get("threshold")

    def may_act(self, task):
        """Did the model in use pass evaluate.auto_ok (may it act on its own in 'auto' mode)?"""
        return evaluate.auto_ok(self._get(task)[1])

    def decide(self, task, score):
        meta = self._get(task)[1]
        t = meta.get("threshold") if meta else None
        return "accept" if t is not None and score >= t else "review"

    def real(self, texts):
        """-> [(chance it is a real release, decision)]"""
        m = self._get("real")[0]
        if m is None:
            return [(None, "review")] * len(texts)
        return [(float(p), self.decide("real", p)) for p in m.score(list(texts))]

    def place(self, game, what, text):
        """-> (predicted series / line, confidence)"""
        m = self._get("place")[0]
        return m.predict(game, what, text) if m is not None else (None, 0.0)

    def photo(self, a, b):
        """a, b: picture paths / bytes / PIL images.  -> chance they show the same item"""
        m = self._get("photo")[0]
        if m is None:
            return None
        return float(m.score(self._features(a), self._features(b)))

    def hard_tested(self):
        """Has the photo model in use passed the hard look-alike test (same set + frame, another name - Clefable vs Wigglytuff) at 99 % on both halves?
        Only then may its look-alike doubt go on the owner's review list (an older model without that test stays counted, not listed)."""
        meta = self._get("photo")[1]
        return bool(meta and (meta.get("heldout") or {}).get("hard")) and evaluate.auto_ok(meta)

    def lookalike(self, score):
        """Two DIFFERENT items' pictures scored as the same item: 'review' at or above the model's threshold (one of them may be a stand-in picture), else 'accept'."""
        t = (self._get("photo")[1] or {}).get("threshold")
        return "review" if t is not None and score >= t else "accept"
