"""Signed copies: a copy (u.lots row) can be marked signed, with who signed it and what the autograph cost (owner, 2026-11-14: "an option to mark signed
individually for each copy of a pop ... the name of the signer and cost of the autograph").

Four columns on u.lots, added by the idempotent migration in db.py (old data: not signed, nothing else changes):
    signed          1 = signed, 0 / NULL = not
    signer          who signed it ("" = not said)
    autograph_cost  what the autograph cost, each copy, in USD like purchase_price (NULL = not said)
    bought_signed   1 = the copy was bought already signed (owner quiz 2026-11-15 q3: "the only downside is when someone buys something pre-autographed"):
                    the price paid already includes the autograph, so it has no autograph cost and nothing extra is counted anywhere
They are normal copy fields like slab_status (cardvault/slabs.py): edited with lot.update (one undo), kept when a stack is split or moved, synced in the snapshot,
written by the CSV / spreadsheet exports and read back by the import.  A copy that stops being signed loses its signer, cost and bought-signed tick.  The autograph
cost counts in what the copy cost (stats spent, portfolio spent, profit and loss, holdings, sold records) unless the copy was bought signed - every sum goes through
cost_sql() / lot_costs() / counted() here.

Which items offer the Signed controls (owner quiz 2026-11-15 q1: "for now, do funko pops, youtooz, and any posters") - allowed():
    every item of the Funko and Youtooz lists, plus any item whose NAME or PRODUCT TYPE (cards.category; an item of your own's category) says poster(s), plus an
    item of your own whose category says Funko or Youtooz.  There is no posters list: posters live in other lists (the Pokémon x Target posters in Accessories,
    an item of your own typed "Poster") and are found by that word.  card.detail sends it as options.signable; the phone engine has the same rule in
    ui/src/phone/signedrule.js (tests/phone_signed.mjs checks both say the same).  Only the controls follow it: a copy already signed on another item keeps its data,
    its badge, its costs and its Signed tick (so it can be unticked).

For other code:
    clean(fields)       -> the same dict with the signed fields made tidy (only the keys present, plus clearing the others when signed goes off)
    lot_costs(v, base)  -> base {lot id: extra cost} with each signed copy's autograph cost (qty x cost) added
    cost_sql(alias)     -> SQL for one copy's counted autograph cost
    counted(row)        -> the same for one row (a dict / sqlite Row), or None
"""
import re

COLUMNS = ("signed", "signer", "autograph_cost", "bought_signed")
DDL = {"signed": "INTEGER DEFAULT 0", "signer": "TEXT", "autograph_cost": "REAL", "bought_signed": "INTEGER DEFAULT 0"}
GAMES = ("funko", "youtooz")
_POSTER = re.compile(r"\bposters?\b", re.I | re.A)                # (re.A: word edges as in JavaScript)
_OWN_KIND = re.compile(r"\b(funko|youtooz)\b", re.I | re.A)


def allowed(game, name="", category=""):
    """Does this item offer the Signed tick box?  (the rule above; the same in ui/src/phone/signedrule.js)"""
    return game in GAMES or bool(_POSTER.search(f"{name or ''} {category or ''}")) or bool(_OWN_KIND.search(category or ""))


def migrate(c, lot_cols):
    for col in COLUMNS:
        if col not in lot_cols:
            c.execute(f"ALTER TABLE u.lots ADD COLUMN {col} {DDL[col]}")


def cost(value):
    """What the person typed as the autograph cost -> a number of 0 or more, or None."""
    if value in (None, ""):
        return None
    try:
        n = float(value)
    except (TypeError, ValueError):
        raise ValueError("The autograph cost must be a number.") from None
    if n < 0:
        raise ValueError("The autograph cost must be zero or more.")
    return round(n, 2)


def clean(fields):
    out = dict(fields)
    if "bought_signed" in out:
        out["bought_signed"] = 1 if out["bought_signed"] else 0
        if out["bought_signed"]:
            out["autograph_cost"] = None                                     # (the price paid already includes the autograph)
    if "signed" in out:
        out["signed"] = 1 if out["signed"] else 0
        if not out["signed"]:
            out["signer"], out["autograph_cost"], out["bought_signed"] = "", None, 0
    if "signer" in out:
        out["signer"] = str(out["signer"] or "").strip()[:80]
    if "autograph_cost" in out:
        out["autograph_cost"] = cost(out["autograph_cost"])
    return out


def cost_sql(alias=""):
    p = f"{alias}." if alias else ""
    return f"(CASE WHEN COALESCE({p}signed,0)=1 AND COALESCE({p}bought_signed,0)=0 THEN COALESCE({p}autograph_cost,0) ELSE 0 END)"


def counted(r):
    k = r.keys()
    if "autograph_cost" not in k or not r["signed"] or ("bought_signed" in k and r["bought_signed"]):
        return None
    return r["autograph_cost"]


def lot_costs(v, base=None):
    out = dict(base or {})
    for lid, extra in v.conn.execute("SELECT id, qty*autograph_cost FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND signed=1 AND COALESCE(bought_signed,0)=0 "
                                     "AND autograph_cost IS NOT NULL", (v.user_id, v.game)):
        out[lid] = out.get(lid, 0.0) + (extra or 0.0)
    return out
