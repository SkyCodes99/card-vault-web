"""Pokemon English checklists (Sun & Moon through the newest set) checked against PokeCottage, and what to do with the differences (roadmap: "Pokemon English and Japanese filled in").

compare(conn, set_id, page_cards)  ->  {"missing": [...], "names": [...], "rarity": [...], "extra": n}   (pure: no network, writes nothing)
queue(report, game="pokemon")      ->  puts every difference on the owner's review list (kind 'pokemon_list'); nothing is changed until the owner says yes.

Rules (owner: "true photo, exact facts, right place"):
  * A card the page lists and we do not have is NOT written from page text alone: its name, number and picture must come from its own TCGplayer product record, so it waits on the review list.
  * A name or rarity that differs is only a proposal (before -> after); the page's alt text has typos and tails ("Holo Rare Trainer Card"), so only clear differences are proposed.
  * Rarity is compared only on pages that carry clean structured data (schema.org list); older pages spell rarities their own way.
Every item names its source: PokeCottage (credit kept) and the page link."""
import re

from . import provenance, reviewlist

KIND = "pokemon_list"
SOURCE = "PokeCottage"


def _norm(x):
    x = (x or "").lower().replace("é", "e").replace("♀", "f").replace("♂", "m").replace("◇", "prismstar")
    x = x.replace("nidoran f", "nidoranf").replace("nidoran m", "nidoranm")
    return re.sub(r"[^a-z0-9]+", "", x)


def same_name(ours, page):
    """True when the two names agree once typography is ignored; a page name may carry a tail ("Holo Rare Trainer Card", "(half 1)", "Promos")."""
    a, b = _norm(ours), _norm(page)
    return not a or not b or a == b or b.startswith(a) or a.startswith(b)


def _key(number):
    return re.sub(r"^0+", "", str(number).split("/")[0]).lower()


def compare(conn, set_id, page_cards):
    ours = {}
    for r in conn.execute("SELECT id, local_id, name, rarity FROM cards WHERE set_id=?", (set_id,)):
        ours[_key(r[1])] = {"id": r[0], "number": r[1], "name": r[2], "rarity": r[3]}
    seen, rep = set(), {"missing": [], "names": [], "rarity": [], "extra": 0}
    for c in page_cards:
        k = _key(c["number"])
        seen.add(k)
        o = ours.get(k)
        if o is None:
            rep["missing"].append({"number": c["number"], "name": c["name"], "rarity": c["rarity"], "product": c.get("product", ""), "image": c.get("image", "")})
            continue
        if c["name"] and not same_name(o["name"], c["name"]):
            rep["names"].append({"id": o["id"], "number": c["number"], "before": o["name"], "after": c["name"]})
        if c["rarity"] and not c.get("css") and (o["rarity"] or "").lower() != c["rarity"].lower():      # structured pages only (no css class)
            rep["rarity"].append({"id": o["id"], "number": c["number"], "before": o["rarity"], "after": c["rarity"]})
    rep["extra"] = len([k for k in ours if k not in seen])
    named = len([c for c in page_cards if c["name"]])
    rep["page_numbering"] = len(rep["names"]) > max(3, named // 10)          # that many differences means the page numbers this set its own way, not that our names are wrong
    if rep["page_numbering"]:
        rep["names"] = []
    return rep


def queue(set_id, set_name, url, rep, game="pokemon"):
    """Put one set's differences on the review list.  -> number of items listed."""
    n = 0
    for m in rep["missing"]:
        q = f"{SOURCE} lists {set_name} {m['number']} {m['name']!r} ({m['rarity'] or 'rarity not given'}) and our list has no card with that number. Add it from its TCGplayer record?"
        n += bool(reviewlist.add_item(KIND, game, f"{set_id}:missing:{m['number']}", q, None, m, f"{SOURCE} {url}"))
    for field in ("names", "rarity"):
        for d in rep[field]:
            what = "name" if field == "names" else "rarity"
            q = f"{set_name} {d['number']}: our {what} is {d['before']!r}, {SOURCE} says {d['after']!r}. Change it?"
            n += bool(reviewlist.add_item(KIND, game, f"{d['id']}:{what}", q, d["before"], d["after"], f"{SOURCE} {url}"))
    return n


def _apply(item, ans, value, ctx):
    """yes on a name or rarity fix writes it (provenance 'fix' keeps the nightly re-sync from undoing it); a 'missing' card is only a note for a later TCGplayer add."""
    if ans not in ("yes", "value") or ":missing:" in item["item_id"]:
        return "noted" if ans in ("yes", "value") else "kept as it was"
    import os
    import sqlite3

    from .db import game_dir
    from .paths import release_data_dir
    ctx = ctx or {}
    card_id, what = item["item_id"].rsplit(":", 1)
    conn = sqlite3.connect(os.path.join(game_dir(ctx.get("data_dir") or release_data_dir(), item["game"]), "cards.db"), timeout=60)
    try:
        conn.execute(f"UPDATE cards SET {'name' if what == 'name' else 'rarity'}=? WHERE id=?", (value if value else item["after"], card_id))
        provenance.record(conn, card_id, what, "fix")
        conn.commit()
    finally:
        conn.close()
    return "applied"


reviewlist.register(KIND, apply=_apply)
