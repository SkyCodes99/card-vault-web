"""The wishlist's own labels.  A label IS a priority level: the labels are kept in the order the person dragged them into (top = most wanted), and a wishlist card carries at most one of them.
Kept as one account setting (like the price alerts), so labels and their order follow the account to every device.
  {"labels": [{"id", "name"}, ...] in priority order, "assign": {"<game id>": {"<card id>": "<label id>"}}}"""
import json

from .db import new_uuid

KEY = "wish_labels"
MAX_LABELS, MAX_NAME = 40, 40


def load(svc):
    try:
        d = json.loads(svc.pget(KEY) or "{}")
    except ValueError:
        d = {}
    d = d if isinstance(d, dict) else {}
    labels = [{"id": str(x["id"]), "name": str(x.get("name") or "").strip()[:MAX_NAME]} for x in d.get("labels", []) if isinstance(x, dict) and x.get("id")]
    assign = d.get("assign") if isinstance(d.get("assign"), dict) else {}
    return {"labels": [x for x in labels if x["name"]], "assign": {g: dict(m) for g, m in assign.items() if isinstance(m, dict)}}


def _save(svc, d):
    svc.pset(KEY, json.dumps(d, ensure_ascii=False))


def set_labels(svc, labels):
    """Replace the labels with this list [{id?, name}] (its order is the priority order); a new one (no id) gets an id; a label left out of the list is gone and its cards have no label."""
    d, seen, out = load(svc), set(), []
    for x in labels or []:
        name = str((x or {}).get("name") or "").strip()[:MAX_NAME]
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        have = {y["id"] for y in d["labels"]}
        lid = x["id"] if x.get("id") in have else "l" + new_uuid()[:8]
        out.append({"id": lid, "name": name})
    out = out[:MAX_LABELS]
    keep = {x["id"] for x in out}
    d["labels"] = out
    d["assign"] = {g: {c: lid for c, lid in m.items() if lid in keep} for g, m in d["assign"].items()}
    d["assign"] = {g: m for g, m in d["assign"].items() if m}
    _save(svc, d)
    return d["labels"]


def assign(svc, game, card_ids, label_id):
    """Give these cards of one game the label (label_id "" = take the label off).  -> how many cards changed."""
    d = load(svc)
    if label_id and label_id not in {x["id"] for x in d["labels"]}:
        raise LookupError("label not found")
    m = d["assign"].setdefault(game, {})
    n = 0
    for c in card_ids:
        if label_id:
            n += m.get(c) != label_id
            m[c] = label_id
        else:
            n += m.pop(c, None) is not None
    if not m:
        d["assign"].pop(game, None)
    _save(svc, d)
    return n


def of_game(svc, game):
    """-> (labels in priority order, {card id: label id}) for one game."""
    d = load(svc)
    return d["labels"], d["assign"].get(game, {})
