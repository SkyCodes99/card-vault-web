"""Start-up progress without any window toolkit: the Windows launcher watches a file; other systems just don't show one."""
import os


class FileSplash:
    """Used when the launcher shows the start-up window: progress goes to the file the launcher is watching."""

    def __init__(self, path):
        self.path = path

    def _write(self, text):
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(text)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def step(self, text, fraction):
        self._write(f"{min(1.0, fraction):.3f}|{text}")

    def pump(self):
        pass

    def finish(self):
        self._write("done|")


class NullSplash:
    def step(self, text, fraction):
        pass

    def pump(self):
        pass

    def finish(self):
        pass
