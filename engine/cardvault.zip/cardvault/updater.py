"""Updates: look for a newer release in your private GitHub repository and install it.

The repository is private, so reading its releases needs a token.  The app looks for one in this order:
  1. a token you pasted into Settings (stored encrypted for your Windows account),
  2. your GitHub CLI sign-in (`gh auth token`).
Only download requests are made; nothing about you or your collection is sent.
"""
import ctypes
import hashlib
import ctypes.wintypes as wt
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile

import requests

from .version import VERSION

UPDATE_REPO = "SkyCodes99/card-vault"            # where releases are published (overridable in Settings)
DATA_REPO = "SkyCodes99/card-vault-data"         # where the shared collection data lives (overridable in Settings)
def _platform_tag():
    return "win64" if sys.platform.startswith("win") else "macos" if sys.platform == "darwin" else "linux-x64"


ASSET_PREFIX = f"CollectEmAll-{_platform_tag()}-"        # each system downloads its own build
ASSET_EXTS = (".zip", ".tar.gz")
UA = "CollectEmAll/2 (update check)"
_NO_WINDOW = 0x08000000 if sys.platform.startswith("win") else 0


# ------------------------------------------------------------------------------------------------- token storage
class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def protect(text):
    """Encrypt a token for this Windows account (DPAPI) -> hex text.  Falls back to plain text off Windows."""
    if not text:
        return ""
    try:
        data = text.encode("utf-8")
        buf = ctypes.create_string_buffer(data, len(data))
        inb, outb = _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), _Blob()
        if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(inb), "CardVault", None, None, None, 0, ctypes.byref(outb)):
            raise OSError("CryptProtectData failed")
        try:
            return "dpapi:" + ctypes.string_at(outb.pbData, outb.cbData).hex()
        finally:
            ctypes.windll.kernel32.LocalFree(outb.pbData)
    except (AttributeError, OSError):
        return "plain:" + text


def unprotect(stored):
    if not stored:
        return ""
    if stored.startswith("plain:"):
        return stored[6:]
    if stored.startswith("dpapi:"):
        try:
            data = bytes.fromhex(stored[6:])
            buf = ctypes.create_string_buffer(data, len(data))
            inb, outb = _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), _Blob()
            if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(inb), None, None, None, None, 0, ctypes.byref(outb)):
                return ""
            try:
                return ctypes.string_at(outb.pbData, outb.cbData).decode("utf-8")
            finally:
                ctypes.windll.kernel32.LocalFree(outb.pbData)
        except (AttributeError, OSError, ValueError):
            return ""
    return ""


def gh_exe():
    for p in (r"C:\Program Files\GitHub CLI\gh.exe", r"C:\Program Files (x86)\GitHub CLI\gh.exe", "gh"):
        if p == "gh" or os.path.exists(p):
            return p
    return None


def gh_token():
    exe = gh_exe()
    if not exe:
        return ""
    try:
        r = subprocess.run([exe, "auth", "token"], capture_output=True, text=True, timeout=15, **({"creationflags": _NO_WINDOW} if _NO_WINDOW else {}))
        return r.stdout.strip() if r.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def get_token(cfg):
    """(token, where it came from)."""
    t = unprotect(cfg.get("github_token", ""))
    if t:
        return t, "saved token"
    t = gh_token()
    return (t, "GitHub CLI sign-in") if t else ("", "")


# ------------------------------------------------------------------------------------------------- checking
def parse_version(text):
    nums = re.findall(r"\d+", text or "")
    return tuple(int(n) for n in nums[:4]) or (0,)


def _headers(token):
    h = {"User-Agent": UA, "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def check(repo, token, current=VERSION):
    """-> {'update': bool, 'latest': '2.2.0', 'notes': str, 'asset': {...} | None, 'error': str}"""
    out = {"update": False, "latest": current, "notes": "", "asset": None, "error": ""}
    try:
        r = requests.get(f"https://api.github.com/repos/{repo}/releases/latest", headers=_headers(token), timeout=25)
        if r.status_code == 404:
            out["error"] = "No release found yet (or the token cannot see the repository)." if token else "Not signed in to GitHub - the repository is private."
            return out
        if r.status_code in (401, 403):
            out["error"] = "GitHub refused access - sign in with the GitHub CLI or paste a token in Settings."
            return out
        r.raise_for_status()
        rel = r.json()
    except (requests.RequestException, ValueError) as e:
        out["error"] = f"Could not reach GitHub ({e.__class__.__name__})."
        return out
    out["latest"] = (rel.get("tag_name") or "").lstrip("v")
    out["notes"] = rel.get("body") or ""
    out["asset"] = next(({"id": a["id"], "name": a["name"], "size": a["size"], "url": a["url"]} for a in rel.get("assets", [])
                         if a["name"].startswith(ASSET_PREFIX) and a["name"].endswith(ASSET_EXTS)), None)
    out["page"] = rel.get("html_url") or ""
    # integrity: the release carries the file's SHA-256 (as a small <zip>.sha256 asset, and in the notes); an update with no checksum is refused
    out["sha256"] = ""
    if out["asset"]:
        side = next((a for a in rel.get("assets", []) if a["name"] == out["asset"]["name"] + ".sha256"), None)
        try:
            if side:
                h = _headers(token)
                h["Accept"] = "application/octet-stream"
                out["sha256"] = requests.get(side["url"], headers=h, timeout=25).text.strip().split()[0].lower()
        except (requests.RequestException, IndexError):
            pass
        if not out["sha256"]:
            m = re.search(r"sha256:\s*([0-9a-fA-F]{64})", out["notes"])
            out["sha256"] = m.group(1).lower() if m else ""
        out["asset"]["sha256"] = out["sha256"]
    out["update"] = parse_version(out["latest"]) > parse_version(current) and out["asset"] is not None and bool(out["sha256"])
    if out["asset"] is not None and not out["sha256"] and parse_version(out["latest"]) > parse_version(current):
        out["error"] = "A newer version exists but it has no checksum, so it was not offered (a safety rule)."
    return out


def download(asset, token, dest, progress=None):
    """Download the update and check its SHA-256 against the published one.  A file that doesn't match is deleted and refused."""
    expected = (asset.get("sha256") or "").lower()
    if not expected:
        raise ValueError("This update has no checksum, so it can't be verified.")
    h = _headers(token)
    h["Accept"] = "application/octet-stream"
    digest = hashlib.sha256()
    with requests.get(asset["url"], headers=h, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length") or asset.get("size") or 0)
        done = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
                digest.update(chunk)
                done += len(chunk)
                if progress:
                    progress(done, total)
    if digest.hexdigest() != expected:
        try:
            os.remove(dest)
        except OSError:
            pass
        raise ValueError("The downloaded update does not match its checksum - it was discarded (it may be damaged or tampered with).")
    return dest


# ------------------------------------------------------------------------------------------------- installing
def app_dir():
    """Folder of the running program when installed (…\\Collect Em All Files), else None (running from source)."""
    return os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else None


def stage(zip_path):
    """Unpack the downloaded update next to the temp folder and check it looks right.  Returns the staging folder."""
    dest = tempfile.mkdtemp(prefix="cardvault_update_")
    root = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():                       # never let an entry write outside the staging folder
            target = os.path.realpath(os.path.join(dest, info.filename))
            if os.path.isabs(info.filename) or not (target == root or target.startswith(root + os.sep)):
                raise ValueError("The update file contains an unsafe path and was refused.")
        z.extractall(dest)
    if not os.path.exists(os.path.join(dest, "Collect Em All Files", "CollectEmAllApp.exe")):
        raise ValueError("The update file doesn't contain the program.")
    return dest


def write_installer(staging, target_dir, pid):
    """A tiny batch file that waits for the app to close, copies the new files over the old ones and starts the app again."""
    launcher_dst = os.path.join(os.path.dirname(target_dir), "Collect Em All.exe")
    bat = os.path.join(tempfile.mkdtemp(prefix="cardvault_apply_"), "apply_update.bat")   # a fresh private folder, so the script can't be swapped beforehand
    lines = [
        "@echo off", "setlocal",
        ":wait", f'tasklist /fi "pid eq {pid}" 2>nul | findstr /c:"{pid}" >nul', "if not errorlevel 1 (", "  timeout /t 1 /nobreak >nul", "  goto wait", ")",
        f'robocopy "{os.path.join(staging, "Collect Em All Files")}" "{target_dir}" /E /R:3 /W:1 /NFL /NDL /NJH /NJS /NP >nul',
        "if errorlevel 8 goto failed",
        f'if exist "{os.path.join(staging, "Collect Em All.exe")}" copy /y "{os.path.join(staging, "Collect Em All.exe")}" "{launcher_dst}" >nul',
        f'start "" "{launcher_dst}"', "goto end",
        ":failed", 'echo The update could not be copied - close Collect Em All and try again.', "pause",
        ":end", f'rmdir /s /q "{staging}" 2>nul', '(goto) 2>nul & del "%~f0"',
    ]
    with open(bat, "w", encoding="utf-8") as f:
        f.write("\r\n".join(lines) + "\r\n")
    return bat


def launch_installer(bat):
    subprocess.Popen(["cmd", "/c", bat], creationflags=0x00000008 | 0x00000200 | _NO_WINDOW, close_fds=True)


def can_self_update():
    """Windows replaces itself; macOS and Linux open the download page (the system asks before replacing an app)."""
    return sys.platform.startswith("win") and app_dir() is not None
