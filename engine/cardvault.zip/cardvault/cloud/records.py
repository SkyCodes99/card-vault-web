"""The change-only sync (3.50.136, docs/speed136_sync_design.md): each device keeps an OUTBOX of the records it changed (filled by SQLite triggers), pushes only those records - each one
sealed on its own with the account's key - to the account server's existing record feed (POST /v1/records), and pulls only what other devices pushed since its CURSOR (GET /v1/records).
Every row is applied with the same newest-wins rule as the per-game snapshots (cloud/snapshot.py), so the two paths converge whichever way a change travelled; the per-game documents
stay as background checkpoints (webapi/cloudapi.py) for new devices, devices on 3.50.135 and older, and the way back.

Record format (language-neutral: a JS client can be written against tests/skycloud_vectors.json "records"):
    plaintext = UTF-8 JSON {"v":1, "k":kind, "g":game, "key":key, "ts":ts, "r":record}   (keys sorted, no spaces; "r" is the dict export_snapshot writes for that record)
    rec_key = HKDF-SHA256(dek, "skycloud/v1/records"),  id_key = HKDF-SHA256(dek, "skycloud/v1/record-ids")
    id      = base64url(HMAC-SHA256(id_key, "kind|game|key"))[:32]          coll = "cv"
    nonce   = HMAC-SHA256(rec_key, "nonce:" + id + plaintext)[:12]          blob = base64(nonce || AES-256-GCM(rec_key, nonce, plaintext, aad="cv-rec:" + id))
    server updated_at = ts as Unix seconds; deleted = the record is a removal
The server sees only opaque ids, times and sizes; identical content gives an identical blob, so a row the server already holds is not stored again (no wake-up storms)."""
import base64
import datetime
import hashlib
import hmac
import json
import sqlite3
import time

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import snapshot

COLL = "cv"
VERSION = 1
PAGE = 200                     # rows per request (the server's limit)
PIECE = 64                     # rows built / applied per piece of a job (the browser's engine does one piece per quiet moment)
MAX_POST = 4 << 20             # bytes per POST (the server takes 6 MiB; an own item's picture can be big)
FUTURE = 86400                 # a pulled stamp more than a day ahead of this device's (corrected) clock is kept, but logged and never moves the clock

# record kind -> (snapshot list it belongs to, reader, writer).  Every reader/writer is the one export_snapshot / apply_snapshot use (one definition of "what a record is").
PLAIN = {
    "lot": ("lots", snapshot.rows_lots, snapshot.apply_lots),
    "sealed": ("sealed", snapshot.rows_sealed, snapshot.apply_sealed),
    "trade": ("trades", snapshot.rows_trades, snapshot.apply_trades),
    "binder": ("dream_binders", snapshot.rows_binders, snapshot.apply_binders),
    "spending": ("spending", snapshot.rows_spending, snapshot.apply_spending),
    "grading": ("grading", snapshot.rows_grading, snapshot.apply_grading),
    "sold": ("sold", snapshot.rows_sold, snapshot.apply_sold),
    "deck": ("decks", snapshot.rows_decks, snapshot.apply_decks),
    "item": ("custom_items", snapshot.rows_items, snapshot.apply_items),
    "share": ("shares", snapshot.rows_shares, snapshot.apply_shares),
    "portfolio": ("portfolios", snapshot.rows_portfolios, snapshot.apply_portfolios),
    "checklist": ("checklists", snapshot.rows_checklists, snapshot.apply_checklists),
    "group": ("custom_groups", snapshot.rows_groups, snapshot.apply_groups),
}
SPECIAL = ("wish", "tag", "packart", "goals", "vh", "look", "here", "dev")
KINDS = tuple(PLAIN) + SPECIAL
LIST_OF = {**{k: v[0] for k, v in PLAIN.items()}, "wish": "wishlist", "tag": "tags", "packart": "pack_arts", "goals": "set_goals", "vh": "value_history"}
MERGED = ("goals", "vh")                       # kinds that hold several entries merged entry by entry (a set's goal, a day's value): both sides' entries are kept
ACCOUNT_WIDE = ("portfolio", "look", "here", "dev")
NOT_NEWS = ("here", "dev")                     # arrives without a "changes from your other devices" note
TAXONOMY = ("group", "tag")                    # changes which groups cards are in: the card index is worked out again

# ------------------------------------------------------------------------------------------------ keys, ids, sealing
def _hkdf(dek, info):
    from .skycloud import hkdf
    return hkdf(dek, info)


def keys(dek):
    """(rec_key, id_key) of an account's data key."""
    return _hkdf(dek, "skycloud/v1/records"), _hkdf(dek, "skycloud/v1/record-ids")


def record_id(id_key, kind, game, key):
    return base64.urlsafe_b64encode(hmac.new(id_key, f"{kind}|{game}|{key}".encode("utf-8"), hashlib.sha256).digest()).decode("ascii")[:32]


def plaintext(kind, game, key, ts, rec):
    return json.dumps({"v": VERSION, "k": kind, "g": game, "key": key, "ts": ts, "r": rec}, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def seal(rec_key, rid, pt):
    nonce = hmac.new(rec_key, b"nonce:" + rid.encode("ascii") + pt, hashlib.sha256).digest()[:12]
    return base64.b64encode(nonce + AESGCM(rec_key).encrypt(nonce, pt, b"cv-rec:" + rid.encode("ascii"))).decode("ascii")


def unseal(rec_key, rid, blob):
    raw = base64.b64decode(blob.encode("ascii"), validate=True)
    return AESGCM(rec_key).decrypt(raw[:12], raw[12:], b"cv-rec:" + rid.encode("ascii"))


def seconds(ts):
    """An ISO stamp ('2026-11-15T10:00:00.123456Z', or an older date-only one) as Unix seconds (0 when it is not a time at all)."""
    s = (ts or "").strip()
    if not s:
        return 0.0
    try:
        if len(s) == 10:
            d = datetime.datetime.strptime(s, "%Y-%m-%d")
        else:
            d = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=datetime.timezone.utc)
        return d.timestamp()
    except ValueError:
        return 0.0


def digest(blob):
    return hashlib.sha1(blob.encode("ascii")).hexdigest()[:20]


# ------------------------------------------------------------------------------------------------ what a record's time and deletion are
def rec_ts(kind, r):
    if r is None:
        return ""
    if kind in ("wish", "tag") and r.get("deleted"):
        return r.get("deleted_at") or ""
    if kind == "goals":
        return max(((x or {}).get("updated_at") or "" for x in r.values()), default="")
    if kind == "vh":
        return max(((d or {}).get("updated_at") or "" for d in r.get("days") or ()), default="")
    if kind == "dev":
        return r.get("last_seen") or ""
    return r.get("updated_at") or ""


def is_deleted(kind, r):
    return bool(r and r.get("deleted"))


def wins(kind, a, b):
    """Does record `a` (arrived) win over `b` (here)?  The snapshot merge's rules exactly: the later stamp wins; an exact tie goes to the larger canonical text; for the wishlist and
    tags a removal wins a tie with the entry it removes (snapshot._merge_hard)."""
    if b is None:
        return a is not None
    ta, tb = rec_ts(kind, a), rec_ts(kind, b)
    if ta != tb:
        return ta > tb
    if kind in ("wish", "tag") and bool(a.get("deleted")) != bool(b.get("deleted")):
        return bool(a.get("deleted"))
    return snapshot._newer(a, b)


# ------------------------------------------------------------------------------------------------ the local tables
TABLES = (
    "CREATE TABLE IF NOT EXISTS u.sync_outbox(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, game TEXT NOT NULL, key TEXT NOT NULL, UNIQUE(kind, game, key))",
    "CREATE TABLE IF NOT EXISTS u.sync_known(kind TEXT NOT NULL, game TEXT NOT NULL, key TEXT NOT NULL, ts TEXT, digest TEXT, deleted INTEGER DEFAULT 0, PRIMARY KEY(kind, game, key))",
    "CREATE TABLE IF NOT EXISTS u.sync_state(account TEXT PRIMARY KEY, cursor INTEGER, info TEXT)",
    "CREATE TABLE IF NOT EXISTS u.sync_parked(kind TEXT NOT NULL, game TEXT NOT NULL, key TEXT NOT NULL, ts TEXT, plain TEXT, digest TEXT, PRIMARY KEY(kind, game, key))",
)
INDEXES = (                                  # (cause 4 of the design: each changed copy's UPDATE ... WHERE uuid=? scanned the whole table - 10,000 changed copies took 25 s)
    "CREATE INDEX IF NOT EXISTS u.lots_uuid ON lots(uuid, user_id, game)",           # (all three: a look by uuid + person + game must not take the per-game card index and scan the game)
    "CREATE INDEX IF NOT EXISTS u.spending_uuid ON spending(uuid)",
    "CREATE INDEX IF NOT EXISTS u.checklists_uuid ON checklists(uuid, user_id, game)",
    "CREATE INDEX IF NOT EXISTS u.custom_groups_key ON custom_groups(user_id, game, key)",
    "CREATE INDEX IF NOT EXISTS u.shares_uuid ON shares(uuid)",
)
# table -> (kind, game, key, extra condition, columns an UPDATE must touch to count); X stands for NEW / OLD.  The names inside are unqualified: a TEMP trigger may not name a database there,
# and the collection's tables are found in "u" (the card list has none of these names).
TRIGGERS = (
    ("lots", "'lot'", "X.game", "X.uuid", "", snapshot.LOT_COLS),
    ("sealed", "'sealed'", "X.game", "X.uuid", "", None),
    ("trades", "'trade'", "X.game", "X.uuid", "", None),
    ("dream_binders", "'binder'", "X.game", "X.uuid", "", None),
    ("spending", "'spending'", "X.game", "X.uuid", "", None),
    ("grading", "'grading'", "X.game", "X.uuid", "", None),
    ("sold", "'sold'", "X.game", "X.uuid", "", None),
    ("decks", "'deck'", "X.game", "X.uuid", "", None),
    ("custom_items", "'item'", "X.game", "X.uuid", "", None),
    ("shares", "'share'", "X.game", "X.uuid", "", None),
    ("portfolios", "'portfolio'", "''", "X.uuid", "", None),
    ("checklists", "'checklist'", "X.game", "X.uuid", "", None),
    ("checklist_items", "'checklist'", "(SELECT game FROM checklists WHERE id=X.checklist_id)", "(SELECT uuid FROM checklists WHERE id=X.checklist_id)",
     "(SELECT uuid FROM checklists WHERE id=X.checklist_id) IS NOT NULL", None),
    ("checklist_picks", "'checklist'", "(SELECT game FROM checklists WHERE id=X.checklist_id)", "(SELECT uuid FROM checklists WHERE id=X.checklist_id)",
     "(SELECT uuid FROM checklists WHERE id=X.checklist_id) IS NOT NULL", None),
    ("custom_groups", "'group'", "X.game", "X.key", "", None),
    ("wishlist", "'wish'", "X.game", "X.card_id", "", None),
    ("card_tags", "'tag'", "X.game", "X.card_id || '|' || X.tag", "", None),
    ("tombstones", "CASE X.kind WHEN 'wishlist' THEN 'wish' ELSE 'tag' END", "X.game", "X.key", "X.kind IN ('wishlist', 'tag')", None),
    ("sealed_arts", "'packart'", "X.game", "X.sealed_uuid || '|' || X.art", "", None),
    ("snapshots", "'vh'", "X.game", "substr(X.day, 1, 7)", "", None),
    ("settings", "CASE X.key WHEN 'look' THEN 'look' WHEN 'here' THEN 'here' ELSE 'goals' END", "CASE X.game WHEN '*' THEN '' ELSE X.game END", "''",
     "((X.game='*' AND X.key IN ('look', 'here')) OR (X.game<>'*' AND X.key='set_goals'))", None),
)


def ensure(conn):
    """The outbox, what this device knows of the feed, the cursor per account, rows waiting for what they point at.  Safe to run on every open."""
    for sql in TABLES:
        conn.execute(sql)


def ensure_indexes(conn):
    for sql in INDEXES:
        try:
            conn.execute(sql)
        except sqlite3.OperationalError:          # (a table an older collection does not have yet)
            pass


def install(conn):
    """The outbox triggers of one connection (TEMP: they belong to this connection; made again at every open and after a backup is restored, as a re-attached database loses them).
    Writes made while quiet(conn) is on (applying what the feed brought) do not refill the outbox."""
    ensure(conn)
    conn.execute("CREATE TEMP TABLE IF NOT EXISTS cv_quiet(x)")
    have = {r[0] for r in conn.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}
    # A trigger must never make the person's own write fail: no NULL key (an old row without a uuid is simply not sent), and no conflict clause - inside a trigger SQLite replaces
    # the trigger's OR REPLACE / OR IGNORE by the outer statement's own policy (an upsert's ABORT failed every pack-art count) - so the old entry is deleted, then a new one added.
    for table, kind, game, key, cond, cols in TRIGGERS:
        if table not in have:
            continue
        for ev, x in (("INSERT", "NEW"), ("UPDATE", "NEW"), ("DELETE", "OLD")):
            k, g, ky = kind.replace("X.", x + "."), f"COALESCE({game.replace('X.', x + '.')}, '')", key.replace("X.", x + ".")
            name = f"cv_out_{table}_{ev.lower()}"
            conn.execute(f"DROP TRIGGER IF EXISTS temp.{name}")
            when = f"NOT EXISTS (SELECT 1 FROM temp.cv_quiet) AND ({ky}) IS NOT NULL" + (f" AND {cond.replace('X.', x + '.')}" if cond else "")
            on = f"UPDATE OF {', '.join(c for c in cols)}" if (ev == "UPDATE" and cols) else ev
            conn.execute(f"CREATE TEMP TRIGGER {name} AFTER {on} ON u.{table} FOR EACH ROW WHEN {when} BEGIN "
                         f"DELETE FROM sync_outbox WHERE kind={k} AND game={g} AND key={ky}; "
                         f"INSERT INTO sync_outbox(kind, game, key) VALUES({k}, {g}, {ky}); END")
            if ev == "UPDATE" and table in ("wishlist", "card_tags", "tombstones", "sealed_arts", "settings"):
                old = f"cv_out_{table}_update_old"                    # (a row whose key itself changed: the old key is a change too)
                k, g, ky = kind.replace("X.", "OLD."), f"COALESCE({game.replace('X.', 'OLD.')}, '')", key.replace("X.", "OLD.")
                conn.execute(f"DROP TRIGGER IF EXISTS temp.{old}")
                when_o = f"NOT EXISTS (SELECT 1 FROM temp.cv_quiet) AND ({ky}) IS NOT NULL" + (f" AND {cond.replace('X.', 'OLD.')}" if cond else "")
                conn.execute(f"CREATE TEMP TRIGGER {old} AFTER UPDATE ON u.{table} FOR EACH ROW WHEN {when_o} BEGIN "
                             f"INSERT INTO sync_outbox(kind, game, key) SELECT {k}, {g}, {ky} WHERE NOT EXISTS "
                             f"(SELECT 1 FROM sync_outbox WHERE kind={k} AND game={g} AND key={ky}); END")


def quiet(conn, on=True):
    conn.execute("CREATE TEMP TABLE IF NOT EXISTS cv_quiet(x)")
    conn.execute("DELETE FROM temp.cv_quiet")
    if on:
        conn.execute("INSERT INTO temp.cv_quiet VALUES(1)")


def enqueue(conn, kind, game, key):
    conn.execute("INSERT OR REPLACE INTO u.sync_outbox(kind, game, key) VALUES(?,?,?)", (kind, game or "", key or ""))


def outbox_top(user_path):
    conn = open_conn(user_path)
    try:
        return conn.execute("SELECT COALESCE(MAX(id), 0) FROM u.sync_outbox").fetchone()[0]
    finally:
        conn.close()


def drop_checkpointed(user_path, games, upto):
    """A new device's first start wrote these games' documents from everything it holds: its outbox entries for them (and for the account-wide records every document carries) are
    in the account already, so they do not go to the feed as well - a collection made before signing in is not uploaded twice.  Only entries made before the documents were read
    (id <= upto): a change made while they were being written still goes out.  -> how many were dropped."""
    games = {g for g in games if g}
    if not games:
        return 0
    conn = open_conn(user_path)
    try:
        n = 0
        for g in games:
            n += conn.execute("DELETE FROM u.sync_outbox WHERE game=? AND id<=? AND kind NOT IN ('dev', 'ckpt')", (g, upto)).rowcount or 0
        n += conn.execute("DELETE FROM u.sync_outbox WHERE game='' AND id<=? AND kind IN ('portfolio', 'look', 'here')", (upto,)).rowcount or 0
        conn.commit()
        return n
    finally:
        conn.close()


def waiting(conn):
    try:
        return conn.execute("SELECT COUNT(*) FROM u.sync_outbox").fetchone()[0]
    except sqlite3.Error:
        return 0


def open_conn(user_path):
    """A connection of the sync's own to the collection (only its own tables are needed: no card list).  It has no outbox triggers, so what it writes never refills the outbox."""
    conn = sqlite3.connect(":memory:", timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("ATTACH DATABASE ? AS u", (user_path,))
    ensure(conn)
    conn.commit()
    return conn


class State:
    """This device's place in one account's feed: the cursor, plus a few notes (kept in the collection, so it is encrypted at rest and travels with backups)."""

    def __init__(self, conn, account):
        self.conn, self.account = conn, account
        row = conn.execute("SELECT cursor, info FROM u.sync_state WHERE account=?", (account,)).fetchone()
        self.cursor = None if row is None or row[0] is None else int(row[0])
        try:
            self.info = json.loads(row[1]) if row and row[1] else {}
        except ValueError:
            self.info = {}

    def save(self):
        self.conn.execute("INSERT OR REPLACE INTO u.sync_state(account, cursor, info) VALUES(?,?,?)", (self.account, self.cursor, json.dumps(self.info, sort_keys=True)))


def state_of(user_path, account):
    conn = open_conn(user_path)
    try:
        return State(conn, account)
    finally:
        conn.close()


def set_cursor(user_path, account, cursor, **info):
    conn = open_conn(user_path)
    try:
        st = State(conn, account)
        st.cursor = cursor
        st.info.update(info)
        st.save()
        conn.commit()
    finally:
        conn.close()


# ------------------------------------------------------------------------------------------------ one record of the collection
class View:
    """Just enough of a Vault for one game of the collection's own tables (setgoals, packarts, customitems.ensure, conflicts take it): no card list is needed."""
    _defer = True
    _cl_rev = 0

    def __init__(self, conn, user_id, game):
        self.conn, self.user_id, self.game = conn, user_id, game

    def _commit(self):
        pass

    def get_setting(self, key, default=None):
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game=? AND key=?", (self.user_id, self.game, key)).fetchone()
        return r[0] if r else default

    def set_setting(self, key, value):
        if value is None:
            self.conn.execute("DELETE FROM u.settings WHERE user_id=? AND game=? AND key=?", (self.user_id, self.game, key))
        else:
            self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, self.game, key, str(value)))

    def _star(self, key):
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game='*' AND key=?", (self.user_id, key)).fetchone()
        try:
            d = json.loads(r[0]) if r else {}
        except ValueError:
            d = {}
        return d if isinstance(d, dict) else {}

    def look_get(self):
        return self._star("look")

    def here_get(self):
        return self._star("here")

    def look_set(self, look):
        self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, "*", "look", json.dumps(look, sort_keys=True)))

    def here_set(self, here):
        self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, "*", "here", json.dumps(here, sort_keys=True)))


class LightVault(View):
    """One game of the collection opened WITHOUT its card list (the snapshot sync of a game whose list is not on this device, cloud/engine.sync_records_steps): its own connection,
    the outbox triggers on (quiet() turns them off), nothing that needs the card list (no card index, no own-item cards - those are made when the game is opened).  It replaces a
    whole scratch collection per game (~100 ms each, cause 3 of the design)."""
    light = True

    def __init__(self, user_path, game, user_id="local"):
        conn = sqlite3.connect(":memory:", timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("ATTACH DATABASE ? AS u", (user_path,))
        View.__init__(self, conn, user_id, game)
        self._defer = False
        install(conn)
        conn.commit()

    def _commit(self):
        if not self._defer:
            self.conn.commit()

    def set_setting(self, key, value):
        View.set_setting(self, key, value)
        self._commit()

    def look_set(self, look):
        View.look_set(self, look)
        self._commit()

    def here_set(self, here):
        View.here_set(self, here)
        self._commit()

    def invalidate_index(self):
        pass

    def _register_taxonomy(self):
        pass

    def card_count(self):
        return 0

    def close(self):
        try:
            self.conn.commit()
        finally:
            self.conn.close()


def export_one(conn, user_id, kind, game, key):
    """The record as it is on this device now (the dict export_snapshot writes for it), or None when this device has none."""
    c = conn
    if kind in PLAIN:
        rows = PLAIN[kind][1](c, user_id, game, key)
        return rows[0] if rows else None
    v = View(conn, user_id, game)
    if kind in ("wish", "tag"):
        live = (snapshot.rows_wishlist if kind == "wish" else snapshot.rows_tags)(c, user_id, game, key)
        if live:
            return live[0]
        t = snapshot.rows_tombstones(c, user_id, game, "wishlist" if kind == "wish" else "tag", key)
        if not t:
            return None
        if kind == "wish":
            return {"card_id": key, "deleted": True, "deleted_at": t[0]["deleted_at"]}
        cid, _, tag = key.partition("|")
        return {"card_id": cid, "tag": tag, "deleted": True, "deleted_at": t[0]["deleted_at"]}
    if kind == "packart":
        rows = snapshot.rows_packarts(c, user_id, game, key)
        return rows[0] if rows else None
    if kind == "goals":
        from .. import setgoals
        return setgoals.raw(v) or None
    if kind == "vh":
        days = snapshot.rows_history(c, user_id, game, key)
        return {"month": key, "days": days} if days else None
    if kind == "look":
        return v.look_get() or None
    if kind == "here":
        return v.here_get() or None
    return None


def apply_one(conn, user_id, kind, game, rec, force=False, missing=None):
    """Write one record that won (wins() said so) into this device.  -> how many rows changed."""
    c, u = conn, (user_id, game)
    if kind in PLAIN:
        if kind == "item":
            from .. import customitems
            customitems.ensure(View(conn, user_id, game))
        elif kind == "deck":
            from .. import decks
            decks.ensure(View(conn, user_id, game))
        if kind == "grading":
            return snapshot.apply_grading(c, u, [rec], force, missing)
        return PLAIN[kind][2](c, u, [rec], force)
    v = View(conn, user_id, game)
    if kind == "wish":
        cid = rec.get("card_id")
        if rec.get("deleted"):
            n = c.execute("DELETE FROM u.wishlist WHERE user_id=? AND game=? AND card_id=?", (*u, cid)).rowcount
            c.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (*u, "wishlist", cid, rec.get("deleted_at")))
            return max(1, n)
        c.execute("INSERT OR REPLACE INTO u.wishlist VALUES(?,?,?,?,?)", (*u, cid, rec.get("note", ""), rec.get("updated_at")))
        c.execute("DELETE FROM u.tombstones WHERE user_id=? AND game=? AND kind='wishlist' AND key=?", (*u, cid))
        return 1
    if kind == "tag":
        cid, tag = rec.get("card_id"), rec.get("tag")
        if rec.get("deleted"):
            c.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (*u, cid, tag))
            c.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (*u, "tag", f"{cid}|{tag}", rec.get("deleted_at")))
            return 1
        c.execute("INSERT OR REPLACE INTO u.card_tags VALUES(?,?,?,?,?,?)", (*u, cid, tag, rec.get("value"), rec.get("updated_at")))
        c.execute("DELETE FROM u.tombstones WHERE user_id=? AND game=? AND kind='tag' AND key=?", (*u, f"{cid}|{tag}"))
        return 1
    if kind == "packart":
        from .. import packarts
        if force:
            c.execute("DELETE FROM u.sealed_arts WHERE user_id=? AND game=? AND sealed_uuid=? AND art=?", (*u, rec.get("sealed"), rec.get("art")))
        return packarts.apply_rows(v, [rec])
    if kind == "goals":
        from .. import setgoals
        return setgoals.apply(v, rec)
    if kind == "vh":
        return snapshot.apply_history(c, u, rec.get("days") or [])
    if kind == "look":
        v.look_set(rec)
        return 1
    if kind == "here":
        v.here_set(rec)
        return 1
    return 0


def _restamp(kind, rec):
    """The same record one microsecond later (an exact tie this device won: its copy goes out again so the server's converges too)."""
    ts = rec_ts(kind, rec)
    t = seconds(ts)
    if not t or kind in MERGED:
        return None
    new = (datetime.datetime.fromtimestamp(t, datetime.timezone.utc) + datetime.timedelta(microseconds=1)).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    out = dict(rec)
    out["deleted_at" if (kind in ("wish", "tag") and rec.get("deleted")) else "updated_at"] = new
    return out


# ------------------------------------------------------------------------------------------------ push and pull
class Feed:
    """One account's feed on this device: sealing keys + where the collection is."""

    def __init__(self, acct, user_path, account_key, user_id="local"):
        self.acct, self.user_path, self.account, self.user_id = acct, user_path, account_key, user_id
        self.rec_key, self.id_key = keys(acct.dek)

    def row_for(self, kind, game, key, rec):
        ts = rec_ts(kind, rec)
        rid = record_id(self.id_key, kind, game, key)
        blob = seal(self.rec_key, rid, plaintext(kind, game, key, ts, rec))
        return {"coll": COLL, "id": rid, "updated_at": seconds(ts), "deleted": is_deleted(kind, rec), "blob": blob}, ts

    def open(self):
        return open_conn(self.user_path)

    # ---- push
    def push_steps(self, conn, stats, st=None):
        """Everything in the outbox goes out, PAGE rows (and at most MAX_POST bytes) per request.  An entry is removed only once the server took it, and only if it was not changed again meanwhile."""
        pushed = stats.setdefault("pushed_keys", set())
        top = conn.execute("SELECT COALESCE(MAX(id), 0) FROM u.sync_outbox").fetchone()[0]       # (only what was waiting when this push began: somebody clicking away meanwhile never keeps one sync going)
        while True:
            entries = conn.execute("SELECT id, kind, game, key FROM u.sync_outbox WHERE id<=? ORDER BY id LIMIT ?", (top, PAGE)).fetchall()
            if not entries:
                return
            rows, done, known, size = [], [], [], 0
            for i, (oid, kind, game, key) in enumerate(entries):
                rec = export_one(conn, self.user_id, kind, game, key) if kind in KINDS and kind != "dev" else (stats.get("dev") if kind == "dev" else None)
                if rec is None:
                    done.append(oid)                                  # (gone for good - a row removed outright - or a kind this version does not know: nothing to send)
                    continue
                row, ts = self.row_for(kind, game, key, rec)
                dg = digest(row["blob"])
                have = conn.execute("SELECT digest FROM u.sync_known WHERE kind=? AND game=? AND key=?", (kind, game, key)).fetchone()
                if have is not None and have[0] == dg:
                    done.append(oid)                                  # the account already holds exactly this (pulled from it, or sent before)
                    continue
                if rows and size + len(row["blob"]) > MAX_POST:
                    break
                rows.append(row)
                size += len(row["blob"]) + 200
                done.append(oid)
                known.append((kind, game, key, ts, dg, 1 if row["deleted"] else 0))
                if (i + 1) % PIECE == 0:
                    yield                                             # (sealing is a piece of its own every PIECE rows)
            if rows:
                yield from self.acct.call_steps("POST", "/v1/records", {"rows": rows}, timeout=120, patient=True)
                stats["requests"] = stats.get("requests", 0) + 1
                stats["pushed"] = stats.get("pushed", 0) + len(rows)
                stats["bytes_up"] = stats.get("bytes_up", 0) + size
            conn.executemany("DELETE FROM u.sync_outbox WHERE id=?", [(i,) for i in done])
            conn.executemany("INSERT OR REPLACE INTO u.sync_known(kind, game, key, ts, digest, deleted) VALUES(?,?,?,?,?,?)", known)
            pushed.update((k[0], k[1], k[2]) for k in known)
            games = {k[1] or stats.get("open_game") or "" for k in known if k[0] not in ("dev", "here")}
            games.discard("")
            if games:                                                 # changed here since their last checkpoint (webapi/cloudapi.start_checkpoint: the documents follow in the background)
                st = st or State(conn, self.account)                  # (the caller's State when it has one: saving a second copy would undo this)
                d = st.info.setdefault("dirty", {})
                for g in games:
                    d[g] = time.time()
                st.save()
            conn.commit()
            yield

    # ---- pull
    def pull_steps(self, conn, st, stats):
        """Everything other devices pushed since this device's cursor, applied row by row (newest wins).  The cursor moves only after a page is applied."""
        while True:
            out = yield from self.acct.call_steps("GET", f"/v1/records?cursor={int(st.cursor or 0)}&limit={PAGE}", timeout=60, patient=True)
            stats["requests"] = stats.get("requests", 0) + 1
            rows = out.get("rows") or []
            for i in range(0, len(rows), PIECE):
                self.apply_rows(conn, rows[i:i + PIECE], stats)
                conn.commit()
                if i + PIECE < len(rows):
                    yield
            try:
                st.cursor = max(int(st.cursor or 0), int(out.get("cursor") or 0))
            except (TypeError, ValueError):
                pass
            st.save()
            conn.commit()
            if not out.get("more") or not rows:
                break
            yield
        self.retry_parked(conn, stats)
        conn.commit()

    def apply_rows(self, conn, rows, stats):
        from . import conflicts
        from ..db import hlc_observe
        quiet(conn, True)
        try:
            pending = {(k, g, key) for k, g, key in conn.execute("SELECT kind, game, key FROM u.sync_outbox")} if rows else set()
            pending |= stats.get("pushed_keys", set())
            for row in rows:
                if row.get("coll") != COLL:
                    continue
                rid, blob = str(row.get("id") or ""), row.get("blob") or ""
                try:
                    d = json.loads(unseal(self.rec_key, rid, blob).decode("utf-8"))
                    kind, game, key, rec = d["k"], d.get("g") or "", d.get("key") or "", d.get("r")
                except Exception:  # noqa: BLE001 - not ours (another key) or damaged: skipped, never applied
                    stats["unreadable"] = stats.get("unreadable", 0) + 1
                    continue
                if record_id(self.id_key, kind, game, key) != rid:
                    stats["unreadable"] = stats.get("unreadable", 0) + 1
                    continue
                self.apply_record(conn, kind, game, key, rec, digest(blob), stats, pending, conflicts, hlc_observe)
        finally:
            quiet(conn, False)

    def apply_record(self, conn, kind, game, key, rec, dg, stats, pending, conflicts, hlc_observe):
        known = conn.execute("SELECT digest FROM u.sync_known WHERE kind=? AND game=? AND key=?", (kind, game, key)).fetchone()
        if known is not None and known[0] == dg:
            return                                                    # (this device's own row coming back, or one it already has)
        ts = rec_ts(kind, rec)
        if not hlc_observe(ts):
            stats.setdefault("future", []).append(ts)                 # a stamp far ahead of the server's time: kept, logged, the clock left alone
        def remember():
            conn.execute("INSERT OR REPLACE INTO u.sync_known(kind, game, key, ts, digest, deleted) VALUES(?,?,?,?,?,?)", (kind, game, key, ts, dg, 1 if is_deleted(kind, rec) else 0))
        if kind == "dev":
            devs = stats.setdefault("devices", {})
            devs[key] = rec
            remember()
            return
        if kind == "ckpt":
            if isinstance(rec, dict):
                stats.setdefault("ckpt", {})[game] = rec              # another 136+ device wrote this game's document from what is in the feed (cloudapi._marks_from_announcements)
            remember()
            return
        if kind not in KINDS or not isinstance(rec, dict):
            remember()                                                # (a kind a newer version added: nothing here to write it into - kept on the server for the devices that know it)
            return
        local = export_one(conn, self.user_id, kind, game, key)
        if kind in MERGED:
            n = apply_one(conn, self.user_id, kind, game, rec)
            after = export_one(conn, self.user_id, kind, game, key)
            remember()
            if after != rec:
                enqueue(conn, kind, game, key)                        # (this device holds entries the other did not: the merged whole goes out)
            if n:
                self._count(stats, kind, game, n)
            return
        if local == rec:
            remember()
            return
        both = (kind, game, key) in pending and local is not None
        lst = LIST_OF.get(kind)
        if wins(kind, rec, local):
            if both and lst in _CONFLICT_LISTS:
                conflicts.record(View(conn, self.user_id, game), [{"kind": lst, "key": key, "mine": local, "theirs": rec, "kept": "theirs"}])
                stats["review"] = stats.get("review", 0) + 1
            missing = []
            n = apply_one(conn, self.user_id, kind, game, rec, force=local is not None and rec_ts(kind, rec) == rec_ts(kind, local), missing=missing)
            if missing:
                conn.execute("INSERT OR REPLACE INTO u.sync_parked(kind, game, key, ts, plain, digest) VALUES(?,?,?,?,?,?)", (kind, game, key, ts, json.dumps(rec), dg))
                return                                                # (a grading submission whose copy has not arrived yet: tried again after the next page)
            remember()
            self._count(stats, kind, game, max(1, n))
            return
        # this device's copy wins: it goes (back) out, so the account's copy converges too
        if both and lst in _CONFLICT_LISTS:
            conflicts.record(View(conn, self.user_id, game), [{"kind": lst, "key": key, "mine": local, "theirs": rec, "kept": "mine"}])
            stats["review"] = stats.get("review", 0) + 1
        if rec_ts(kind, rec) == rec_ts(kind, local):
            again = _restamp(kind, local)
            if again is not None:
                apply_one(conn, self.user_id, kind, game, again, force=True)
                self._count(stats, kind, game, 1)
        remember()
        enqueue(conn, kind, game, key)

    def retry_parked(self, conn, stats):
        from . import conflicts
        from ..db import hlc_observe
        rows = conn.execute("SELECT kind, game, key, plain, digest FROM u.sync_parked").fetchall()
        if not rows:
            return
        quiet(conn, True)
        try:
            for kind, game, key, plain, dg in rows:
                conn.execute("DELETE FROM u.sync_parked WHERE kind=? AND game=? AND key=?", (kind, game, key))
                self.apply_record(conn, kind, game, key, json.loads(plain), dg, stats, set(), conflicts, hlc_observe)
        finally:
            quiet(conn, False)

    @staticmethod
    def _count(stats, kind, game, n):
        if kind not in NOT_NEWS:
            stats["pulled"] = stats.get("pulled", 0) + n
            stats.setdefault("games", set()).add(game)
        if kind in TAXONOMY:
            stats.setdefault("taxonomy", set()).add(game)
        if kind == "item":
            stats.setdefault("items", set()).add(game)
        if kind in ("look", "here"):
            stats.setdefault("account", set()).add(kind)


_CONFLICT_LISTS = {k for k, _f in __import__("cardvault.cloud.conflicts", fromlist=["x"]).KINDS}


# ------------------------------------------------------------------------------------------------ a whole document's records (a new device's start, without a card list)
def apply_document(conn, user_id, game, snap):
    """Every record of one game's snapshot document, applied record by record with the feed's rule (newest wins) - no card list, no scratch collection, no merge of whole snapshots.
    -> (rows changed, {"taxonomy", "items"} that changed).  Runs with the outbox quiet: what is already in the account is not sent back to it."""
    changed, flags = 0, set()
    quiet(conn, True)
    try:
        for kind, (lst, _r, _w) in PLAIN.items():
            for rec in snap.get(lst) or ():
                key = rec.get("key") if kind == "group" else rec.get("uuid")
                if key is None:
                    continue
                g = "" if kind == "portfolio" else game
                local = export_one(conn, user_id, kind, g, key)
                if local != rec and wins(kind, rec, local):
                    changed += apply_one(conn, user_id, kind, g, rec, force=local is not None and rec_ts(kind, rec) == rec_ts(kind, local))
                    if kind in TAXONOMY:
                        flags.add("taxonomy")
                    if kind == "item":
                        flags.add("items")
        tombs = {(t["kind"], t["key"]): t["deleted_at"] for t in snap.get("tombstones") or ()}
        for w in snap.get("wishlist") or ():
            changed += _doc_one(conn, user_id, "wish", game, w["card_id"], w)
        for t in snap.get("tags") or ():
            n = _doc_one(conn, user_id, "tag", game, f"{t['card_id']}|{t['tag']}", t)
            changed += n
            if n:
                flags.add("taxonomy")
        for (k, key), ts in tombs.items():
            if k == "wishlist":
                changed += _doc_one(conn, user_id, "wish", game, key, {"card_id": key, "deleted": True, "deleted_at": ts})
            elif k == "tag":
                cid, _, tag = key.partition("|")
                n = _doc_one(conn, user_id, "tag", game, key, {"card_id": cid, "tag": tag, "deleted": True, "deleted_at": ts})
                changed += n
                if n:
                    flags.add("taxonomy")
        for a in snap.get("pack_arts") or ():
            changed += _doc_one(conn, user_id, "packart", game, f"{a.get('sealed')}|{a.get('art')}", a)
        if snap.get("set_goals"):
            from .. import setgoals
            changed += setgoals.apply(View(conn, user_id, game), snap["set_goals"])
        changed += snapshot.apply_history(conn, (user_id, game), snap.get("value_history") or [])
        for kind in ("look", "here"):
            rec = snap.get(kind) or {}
            if rec:
                _doc_one(conn, user_id, kind, "", "", rec)
    finally:
        quiet(conn, False)
    return changed, flags


def _doc_one(conn, user_id, kind, game, key, rec):
    local = export_one(conn, user_id, kind, game, key)
    if local == rec or not wins(kind, rec, local):
        return 0
    return max(1, apply_one(conn, user_id, kind, game, rec, force=local is not None and rec_ts(kind, rec) == rec_ts(kind, local)))


# ------------------------------------------------------------------------------------------------ the safety net and the account's games
SWEEP = (            # (table, kind, game, key, time column) for the once-a-session sweep: anything changed after the last sweep that the outbox did not hear about (a writer without the triggers)
    ("lots", "lot", "game", "uuid", "COALESCE(updated_at, added)"), ("sealed", "sealed", "game", "uuid", "updated_at"), ("trades", "trade", "game", "uuid", "updated_at"),
    ("dream_binders", "binder", "game", "uuid", "updated_at"), ("spending", "spending", "game", "uuid", "updated_at"), ("grading", "grading", "game", "uuid", "updated_at"),
    ("sold", "sold", "game", "uuid", "updated_at"), ("decks", "deck", "game", "uuid", "updated_at"), ("custom_items", "item", "game", "uuid", "updated_at"),
    ("shares", "share", "game", "uuid", "updated_at"), ("portfolios", "portfolio", "''", "uuid", "updated_at"), ("checklists", "checklist", "game", "uuid", "updated_at"),
    ("custom_groups", "group", "game", "key", "updated_at"), ("wishlist", "wish", "game", "card_id", "added"), ("card_tags", "tag", "game", "card_id || '|' || tag", "updated_at"),
    ("sealed_arts", "packart", "game", "sealed_uuid || '|' || art", "updated_at"),
)


def sweep(conn, since):
    """Put into the outbox every record changed after `since` that is not what the feed already holds.  -> how many."""
    if not since:
        return 0
    n = 0
    have = {r[0] for r in conn.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}
    for table, kind, game, key, when in SWEEP:
        if table not in have:
            continue
        cur = conn.execute(f"INSERT OR IGNORE INTO u.sync_outbox(kind, game, key) SELECT '{kind}', {game}, {key} FROM u.{table} t WHERE {when} > ? AND NOT EXISTS "
                           f"(SELECT 1 FROM u.sync_known k WHERE k.kind='{kind}' AND k.game={game} AND k.key={key} AND k.ts={when})", (since,))
        n += max(0, cur.rowcount or 0)
    return n


def games_with_items(conn, user_id="local"):
    """The games this device holds something of (copies, wishlist, checklists, sealed) - what the feed and the documents brought in, with no download: replaces reading every game's
    whole document to see whether it holds anything (cloudapi._has_items)."""
    out = set()
    for sql in ("SELECT DISTINCT game FROM u.lots WHERE user_id=? AND deleted=0", "SELECT DISTINCT game FROM u.wishlist WHERE user_id=?",
                "SELECT DISTINCT game FROM u.checklists WHERE user_id=? AND deleted=0", "SELECT DISTINCT game FROM u.sealed WHERE user_id=? AND deleted=0"):
        try:
            out |= {r[0] for r in conn.execute(sql, (user_id,)) if r[0]}
        except sqlite3.Error:
            pass
    return out


def now_server_ok(ts, offset=0.0):
    """Is a pulled stamp believable (not more than FUTURE seconds after the corrected now)?"""
    return seconds(ts) <= time.time() + offset + FUTURE
