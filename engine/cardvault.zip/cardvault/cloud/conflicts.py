"""The sync review list: nothing is lost when the same thing was changed on two devices.

Merging keeps the newer copy of each record (last writer wins, see snapshot.merge - every device picks the same one, so they all end up equal).  That is right when only ONE side
changed the record since the two last met.  When BOTH changed it (say the phone edited a card's notes offline while the PC changed its quantity), the older copy would simply vanish.
Now that copy is kept here instead: the newer one is used, and the other waits on the review list (Account > Cloud saving) until the person keeps it or switches to it.

"Since the two last met" is the time the last finished sync of this game started on this device (kept in the device's own settings, never synced).
"""
import json

from ..db import now_iso

SEEN_KEY = "_sync_seen"
# what can clash: (snapshot list, the record's key).  Value history and share links are left out: every device writes its own day's value, and links are made on one device only.
KINDS = (
    ("lots", lambda r: r["uuid"]), ("sealed", lambda r: r["uuid"]), ("trades", lambda r: r["uuid"]), ("portfolios", lambda r: r["uuid"]),
    ("checklists", lambda r: r["uuid"]), ("custom_groups", lambda r: r["key"]), ("spending", lambda r: r["uuid"]), ("dream_binders", lambda r: r["uuid"]), ("grading", lambda r: r["uuid"]), ("sold", lambda r: r["uuid"]), ("custom_items", lambda r: r["uuid"]),
    ("wishlist", lambda r: r["card_id"]), ("tags", lambda r: f"{r['card_id']}|{r['tag']}"),
)
_KEYS = dict(KINDS)
_SQL = ("CREATE TABLE IF NOT EXISTS u.sync_conflicts(id INTEGER PRIMARY KEY, user_id TEXT, game TEXT, kind TEXT, key TEXT, mine TEXT, theirs TEXT, kept TEXT, at TEXT, "
        "done INTEGER DEFAULT 0, UNIQUE(user_id, game, kind, key, mine, theirs))")


def _ts(r):
    return (r or {}).get("updated_at") or ""


def find(local, remote, merged, since):
    """Records changed on BOTH sides after `since` that do not agree -> [{kind, key, mine, theirs, kept: 'mine'|'theirs'}].  No `since` (this device never finished a sync) -> nothing."""
    if not since or not remote:
        return []
    out = []
    for kind, key in KINDS:
        theirs = {key(r): r for r in remote.get(kind) or ()}
        if not theirs:
            continue
        kept = {key(r): r for r in merged.get(kind) or ()}
        for mine in local.get(kind) or ():
            k = key(mine)
            other = theirs.get(k)
            if other is None or other == mine or _ts(mine) <= since or _ts(other) <= since:
                continue
            out.append({"kind": kind, "key": k, "mine": mine, "theirs": other, "kept": "mine" if kept.get(k) == mine else "theirs"})
    return out


def _ensure(conn):
    conn.execute(_SQL)


def record(v, items):
    """Put clashes on the review list (the same pair twice is kept once).  -> how many were new."""
    if not items:
        return 0
    _ensure(v.conn)
    at, n = now_iso(), 0
    for it in items:
        cur = v.conn.execute("INSERT OR IGNORE INTO u.sync_conflicts(user_id, game, kind, key, mine, theirs, kept, at) VALUES(?,?,?,?,?,?,?,?)",
                             (v.user_id, v.game, it["kind"], it["key"], json.dumps(it["mine"], sort_keys=True), json.dumps(it["theirs"], sort_keys=True), it["kept"], at))
        n += cur.rowcount or 0
    v.conn.commit()
    return n


def last_seen(v):
    return v.get_setting(SEEN_KEY) or ""


def mark_seen(v, started):
    v.set_setting(SEEN_KEY, started)


def pending(conn, user_id, game=None):
    """The open review items, newest first (all games, or one)."""
    _ensure(conn)
    q = "SELECT id, game, kind, key, mine, theirs, kept, at FROM u.sync_conflicts WHERE user_id=? AND done=0" + (" AND game=?" if game else "") + " ORDER BY id DESC"
    rows = conn.execute(q, (user_id, game) if game else (user_id,)).fetchall()
    return [{"id": r[0], "game": r[1], "kind": r[2], "key": r[3], "mine": json.loads(r[4]), "theirs": json.loads(r[5]), "kept": r[6], "at": r[7]} for r in rows]


def count(conn, user_id):
    try:
        _ensure(conn)
        return conn.execute("SELECT COUNT(*) FROM u.sync_conflicts WHERE user_id=? AND done=0", (user_id,)).fetchone()[0]
    except Exception:  # noqa: BLE001 - a status line must never fail
        return 0


def resolve(v, item_id, use="kept"):
    """Settle one item.  use='kept' leaves what is showing; use='other' brings the copy that lost back (as a fresh change, so it travels to every device at the next sync)."""
    from .snapshot import apply_snapshot, export_snapshot
    _ensure(v.conn)
    r = v.conn.execute("SELECT kind, key, mine, theirs, kept FROM u.sync_conflicts WHERE id=? AND user_id=? AND game=?", (item_id, v.user_id, v.game)).fetchone()
    if r is None:
        return False
    if use == "other":
        kind, k = r[0], r[1]
        rec = json.loads(r[3] if r[4] == "mine" else r[2])
        rec["updated_at"] = now_iso()
        snap = export_snapshot(v)
        key = _KEYS[kind]
        snap[kind] = [x for x in snap.get(kind) or () if key(x) != k] + [rec]
        if kind == "wishlist":
            snap["tombstones"] = [t for t in snap.get("tombstones") or () if not (t["kind"] == "wishlist" and t["key"] == k)]
        apply_snapshot(v, snap)
    v.conn.execute("UPDATE u.sync_conflicts SET done=1 WHERE id=?", (item_id,))
    v.conn.commit()
    return True
