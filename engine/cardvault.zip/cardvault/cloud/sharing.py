"""Sharing a portfolio with another account (protocol: SkyCloud\\SHARING.md).  Everything is sealed on the device; the server only stores ciphertext.

    account key pair  X25519, private half sealed with the account's own document key (so every device of the account can use it)
    box               a message sealed to someone's public key:  ephemeral X25519 -> ECDH -> HKDF -> AES-256-GCM        b64(eph_pub32 || nonce12 || ct)
    group key         32 random bytes; seals the group's name, label and every record
"""
import json
import secrets
import time

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey

from . import skycloud as sc

RAW = serialization.Encoding.Raw, serialization.PublicFormat.Raw


def _pub_bytes(priv):
    return priv.public_key().public_bytes(*RAW)


def _priv_bytes(priv):
    return priv.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())


def ensure_keypair(acct):
    """-> (private key object, public key b64).  Makes and uploads the key pair the first time; later devices fetch it."""
    dk = sc.doc_key(acct.dek)
    cur = acct.call("GET", "/v1/keypair")
    if cur.get("pubkey") and cur.get("priv_wrapped"):
        raw = sc.unseal(dk, cur["priv_wrapped"], b"sharing/keypair")
        return X25519PrivateKey.from_private_bytes(raw), cur["pubkey"]
    priv = X25519PrivateKey.generate()
    pub = sc.b64(_pub_bytes(priv))
    acct.call("PUT", "/v1/keypair", {"pubkey": pub, "priv_wrapped": sc.seal(dk, _priv_bytes(priv), b"sharing/keypair")})
    return priv, pub


def has_keypair(acct):
    return bool(acct.call("GET", "/v1/keypair").get("pubkey"))


def box_seal(pub_b64, data):
    pub = sc.unb64(pub_b64)
    eph = X25519PrivateKey.generate()
    key = sc.hkdf(eph.exchange(X25519PublicKey.from_public_bytes(pub)), "skycloud/v1/box")
    ep = _pub_bytes(eph)
    return sc.b64(ep + sc.unb64(sc.seal(key, data, ep + pub)))


def box_open(priv, blob):
    raw = sc.unb64(blob)
    ep, rest = raw[:32], sc.b64(raw[32:])
    pub = _pub_bytes(priv)
    key = sc.hkdf(priv.exchange(X25519PublicKey.from_public_bytes(ep)), "skycloud/v1/box")
    return sc.unseal(key, rest, ep + pub)


def new_group_key():
    return secrets.token_bytes(32)


def seal_json(key, obj, aad):
    return sc.seal(key, json.dumps(obj, separators=(",", ":")).encode(), aad.encode())


def open_json(key, blob, aad):
    return json.loads(sc.unseal(key, blob, aad.encode()))


def new_id():
    return secrets.token_urlsafe(18)


def push_rows(acct, gid, key, rows, chunk=100):
    """rows: [(coll, id, object-or-None)]; None deletes.  Sealed with the group key (aad = coll/id) and uploaded."""
    now = time.time()
    out = []
    for coll, rid, obj in rows:
        out.append({"coll": coll, "id": rid, "updated_at": now, "deleted": obj is None, "blob": seal_json(key, obj if obj is not None else {}, f"{coll}/{rid}")})
    for i in range(0, len(out), chunk):
        acct.call("POST", f"/v1/groups/{gid}/records", {"rows": out[i:i + chunk]}, timeout=120)


def pull_rows(acct, gid, key):
    """-> {(coll, id): object} of everything currently in the group (deleted ones dropped)."""
    cur, have = "0", {}
    while True:
        out = acct.call("GET", f"/v1/groups/{gid}/records?cursor={cur}&limit=200", timeout=120)
        for r in out.get("rows", []):
            k = (r["coll"], r["id"])
            if r.get("deleted"):
                have.pop(k, None)
                continue
            try:
                have[k] = open_json(key, r["blob"], f"{r['coll']}/{r['id']}")
            except Exception:  # noqa: BLE001 - a record sealed with an older key is skipped, not fatal
                pass
        cur = out.get("cursor", cur)
        if not out.get("more"):
            return have


def pull_rows_cached(acct, gid, key, cache):
    """Like pull_rows, but `cache` (a dict the caller keeps) remembers where it got to: the next call only fetches what changed since, so looking again every few seconds is nearly free."""
    c = cache.setdefault(gid, {"cur": "0", "rows": {}})
    while True:
        out = acct.call("GET", f"/v1/groups/{gid}/records?cursor={c['cur']}&limit=200", timeout=120)
        for r in out.get("rows", []):
            k = (r["coll"], r["id"])
            if r.get("deleted"):
                c["rows"].pop(k, None)
                continue
            try:
                c["rows"][k] = open_json(key, r["blob"], f"{r['coll']}/{r['id']}")
            except Exception:  # noqa: BLE001
                pass
        c["cur"] = out.get("cursor", c["cur"])
        if not out.get("more"):
            return dict(c["rows"])
