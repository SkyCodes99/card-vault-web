"""End-to-end encryption of what is stored in the sync repository.

Your devices share one random 256-bit "sync key" (made on this computer, entered once on the phone as a link code).  Everything written
to the repository - your collection snapshot and the card lists - is encrypted with it first, so GitHub (or anyone who got hold of the
repository or its token) sees only unreadable data.

Format:  {"cve": 1, "n": <nonce>, "c": <AES-256-GCM ciphertext>}   (the nonce is derived from the content, so unchanged data stays
byte-identical and isn't re-uploaded; the file path is authenticated, so a file can't be swapped for another)."""
import base64
import hashlib
import hmac
import json

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class SyncKeyError(Exception):
    pass


def new_key():
    import os
    return os.urandom(32)


def is_wrapped(raw):
    return bool(raw) and raw[:1] == b"{" and b'"cve"' in raw[:24]


def wrap(key, plaintext, path):
    nonce = hmac.new(key, b"nonce:" + path.encode() + plaintext, hashlib.sha256).digest()[:12]
    ct = AESGCM(key).encrypt(nonce, plaintext, b"cardvault-sync:" + path.encode())
    return json.dumps({"cve": 1, "n": base64.b64encode(nonce).decode(), "c": base64.b64encode(ct).decode()}, separators=(",", ":")).encode()


def unwrap(key, raw, path):
    if not is_wrapped(raw):
        return raw                                   # an older, unencrypted copy: readable, and re-written encrypted at the next save
    if not key:
        raise SyncKeyError("The synced data is encrypted. Enter this account's sync key (Settings > Sync).")
    try:
        d = json.loads(raw.decode("utf-8"))
        return AESGCM(key).decrypt(base64.b64decode(d["n"]), base64.b64decode(d["c"]), b"cardvault-sync:" + path.encode())
    except (InvalidTag, KeyError, ValueError):
        raise SyncKeyError("The synced data could not be decrypted - it was written with a different sync key or was altered.")


# a link code is the key as 8 groups of 8 base32 characters:  ABCDEFGH-IJKLMNOP-...
def to_code(key):
    s = base64.b32encode(key).decode().rstrip("=")
    return "-".join(s[i:i + 8] for i in range(0, len(s), 8))


def from_code(code):
    s = "".join(ch for ch in (code or "").upper() if ch.isalnum())
    try:
        key = base64.b32decode(s + "=" * (-len(s) % 8))
    except ValueError:
        raise SyncKeyError("That sync key isn't valid.")
    if len(key) != 32:
        raise SyncKeyError("That sync key isn't valid.")
    return key
