"""Keeps this PC's data and the shared copy in step: read the shared copy, merge, apply what's new locally, write back what's new remotely.
Nothing is ever uploaded unless sync is switched on in Settings and set up with your own repository + token."""
import gzip
import hashlib
import json
import os
import uuid

from ..db import Vault, now_iso
from . import e2e
from .backend import Conflict
from .snapshot import apply_snapshot, build_derived, canonical, export_snapshot, merge

MAX_RETRIES = 4


def device_id(cfg):
    if not cfg.get("device_id"):
        cfg["device_id"] = "pc-" + uuid.uuid4().hex[:8]
    return cfg["device_id"]


def data_path(user, game):
    return f"users/{user}/{game}.json"


def sync_game(data_dir, game, backend, device="pc", user="local", publish_catalog=True, key=None, user_path=None):
    """One round trip for one game.  Returns {'pulled': n, 'pushed': bool, 'conflicts': n}."""
    v = Vault(data_dir, game, user, user_path=user_path)      # an account's collection lives in its (decrypted, private) working copy
    try:
        path = data_path(user, game)
        stats = {"game": game, "pulled": 0, "pushed": False, "conflicts": 0}
        for attempt in range(MAX_RETRIES):
            raw, etag = backend.read(path)
            upgrade = bool(key and raw and not e2e.is_wrapped(raw))      # an older unencrypted copy: write it back encrypted
            raw = e2e.unwrap(key, raw, path) if raw else raw
            remote = json.loads(raw.decode("utf-8")) if raw else None
            local = export_snapshot(v, device)
            merged = merge(local, remote)
            if canonical(merged) != canonical(local):
                stats["pulled"] += apply_snapshot(v, merged)
            derived = build_derived(v)
            if remote is None or upgrade or canonical(merged) != canonical(remote) or derived != (remote or {}).get("derived"):
                merged["derived"] = derived
                merged["device"] = device
                merged["exported"] = now_iso()
                try:
                    body = json.dumps(merged, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                    backend.write(path, e2e.wrap(key, body, path) if key else body, etag, f"Sync from {device}")
                    stats["pushed"] = True
                except Conflict:
                    stats["conflicts"] += 1
                    continue          # somebody else saved in between: read again and merge again
            break
        if publish_catalog and v.card_count():
            try:
                stats["catalog"] = publish_catalog_file(v, backend, key)
            except Exception as e:  # noqa: BLE001 - the phone's card list is a bonus; never fail the data sync for it
                stats["catalog_error"] = str(e)
        return stats
    finally:
        v.close()


def build_catalog(v):
    """A compact card list for the phone app: sets + cards (id, number, name, rarity, price, picture, plus what it needs to browse by
    category / illustrator / Pokemon exactly like the computer does)."""
    from .. import checklists, games, taxonomy
    try:
        extra_urls = json.loads(v.meta("setimg_urls") or "{}")
    except ValueError:
        extra_urls = {}
    sets = [[s["id"], s["name"], s["serie"] or "", (s["release_date"] or "")[:10], s["n"] or 0,
             (s["logo"] + ".webp") if s["logo"] else extra_urls.get(s["id"], "")] for s in v.sets()]
    set_idx = {s[0]: i for i, s in enumerate(sets)}
    index = v.card_index()
    rarities = sorted({c["rarity"] for c in index if c.get("rarity")})
    rar_idx = {r: i for i, r in enumerate(rarities)}
    illustrators = sorted({c["illustrator"] for c in index if c.get("illustrator")})
    ill_idx = {n: i for i, n in enumerate(illustrators)}
    light = {c["id"]: c for c in index}
    cards = []
    for c in v.conn.execute("SELECT id, set_id, local_id, name, rarity, price_usd, image_base, types, variants FROM cards ORDER BY set_id, sort_key, local_id"):
        lc = light.get(c["id"], {})
        cards.append([c["id"], set_idx.get(c["set_id"], -1), c["local_id"], c["name"], rar_idx.get(c["rarity"], -1),
                      None if c["price_usd"] is None else round(c["price_usd"], 2), c["image_base"] or "", c["types"] or "", v.default_variant(c["id"]),
                      ill_idx.get(lc.get("illustrator"), -1), lc.get("dex") or "", ",".join(lc.get("groups") or [])])
    g = games.game_by_id(v.game)
    out = {"format": 2, "game": v.game, "name": g.name, "pokemon": g.pokemon, "sets": sets, "rarities": rarities, "cards": cards, "illustrators": illustrators,
           "groups": [{"id": x.id, "label": x.label, "parent": x.parent, "help": getattr(x, "help", "")} for x in taxonomy.groups()],
           "sections": [[sec, title] for sec, title in taxonomy.SECTIONS], "image_suffix": "/low.webp" if g.pokemon else ""}
    if g.pokemon:
        out["dex_names"] = {str(d): n for d, n in checklists.dex_names(v).items()}
    return out


def publish_catalog_file(v, backend, key=None):
    """Upload the phone's card list when it changed (skipped when the same content is already there)."""
    data = gzip.compress(json.dumps(build_catalog(v), ensure_ascii=False, separators=(",", ":")).encode("utf-8"), 9, mtime=0)
    path = f"catalog/{v.game}.json.gz"
    data = e2e.wrap(key, data, path) if key else data
    digest = hashlib.sha1(data).hexdigest()
    raw, etag = backend.read(path)
    if raw is not None and hashlib.sha1(raw).hexdigest() == digest:
        return "unchanged"
    backend.write(path, data, etag, f"Card list for {v.game}")
    return f"published {len(data) // 1024} KB"


def publish_other_catalogs(data_dir, backend, skip=(), key=None, user_path=None):
    """Put the card list of every downloaded game on the phone's menu (Japanese, One Piece...), even before you own a card from it."""
    from .. import games
    from ..db import game_dir
    out = {}
    for g in games.GAMES:
        if not g.available or g.id in skip or not os.path.exists(os.path.join(game_dir(data_dir, g.id), "cards.db")):
            continue
        try:
            v = Vault(data_dir, g.id, "local", user_path=user_path)
            try:
                if v.card_count():
                    out[g.id] = publish_catalog_file(v, backend, key)
            finally:
                v.close()
        except Exception as e:  # noqa: BLE001 - a bonus; never fail the sync
            out[g.id] = f"error: {e}"
    return out
