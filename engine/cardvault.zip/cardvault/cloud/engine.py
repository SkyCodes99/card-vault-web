"""Keeps this PC's data and the shared copy in step: read the shared copy, merge, apply what's new locally, write back what's new remotely.
Nothing is ever uploaded unless sync is switched on in Settings and set up with your own repository + token."""
import gzip
import hashlib
import json
import os
import sqlite3
import uuid

from ..db import Vault, now_iso
from ..steps import run
from . import conflicts, e2e
from .backend import Conflict
from . import syncmarks
from .snapshot import apply_snapshot, export_snapshot, merge, same

MAX_RETRIES = 4


def device_id(cfg):
    if not cfg.get("device_id"):
        cfg["device_id"] = "pc-" + uuid.uuid4().hex[:8]
    return cfg["device_id"]


def data_path(user, game):
    return f"users/{user}/{game}.json"


def sync_game(data_dir, game, backend, device="pc", user="local", publish_catalog=True, key=None, user_path=None):
    """One round trip for one game.  Returns {'pulled': n, 'pushed': bool, 'conflicts': n, 'taxonomy': bool}; 'failed' is set when it could not be settled (somebody kept saving in between)."""
    return run(sync_game_steps(data_dir, game, backend, device, user, publish_catalog, key, user_path))


def sync_game_steps(data_dir, game, backend, device="pc", user="local", publish_catalog=True, key=None, user_path=None):
    """sync_game in pieces (it yields after the download, after the merge and after the upload): the browser build does one piece per moment, so a click is never held up by a whole sync."""
    v = Vault(data_dir, game, user, user_path=user_path)      # an account's collection lives in its (decrypted, private) working copy
    try:
        path = data_path(user, game)
        stats = {"game": game, "pulled": 0, "pushed": False, "conflicts": 0, "review": 0}
        touched = set()
        since = conflicts.last_seen(v)                           # when this device and the account last met (for the review list, see conflicts.py)
        for attempt in range(MAX_RETRIES):
            raw, etag = yield from _steps(backend, "read", path)              # (the download is handed out in the browser - see steps.py)
            yield
            upgrade = bool(key and raw and not e2e.is_wrapped(raw))      # an older unencrypted copy: write it back encrypted
            raw = e2e.unwrap(key, raw, path) if raw else raw
            remote = json.loads(raw.decode("utf-8")) if raw else None
            local = export_snapshot(v, device)
            merged = merge(local, remote)
            stats["review"] += conflicts.record(v, conflicts.find(local, remote, merged, since))     # changed on both sides: the copy that loses is kept for review, never dropped
            if not same(merged, local):
                stats["pulled"] += apply_snapshot(v, merged, touched)
            yield
            if remote is None or upgrade or not same(merged, remote):
                merged["device"] = device
                merged["exported"] = now_iso()
                if remote and "derived" in remote:
                    merged["derived"] = remote["derived"]                # (only the old phone app ever read it; nothing works it out any more, but what is there stays as it was)
                try:
                    body = json.dumps(merged, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                    body = e2e.wrap(key, body, path) if key else body
                    yield                                                         # (packing a big collection is a step of its own; the upload is handed out)
                    yield from _steps(backend, "write", path, body, etag, f"Sync from {device}")
                    stats["pushed"] = True
                    yield
                except Conflict:
                    stats["conflicts"] += 1
                    continue          # somebody else saved in between: read again and merge again
            break
        else:
            stats["failed"] = True
        if not stats.get("failed"):
            conflicts.mark_seen(v, now_iso())
        stats["taxonomy"] = "taxonomy" in touched
        if publish_catalog and v.card_count():
            try:
                stats["catalog"] = publish_catalog_file(v, backend, key)
            except Exception as e:  # noqa: BLE001 - the phone's card list is a bonus; never fail the data sync for it
                stats["catalog_error"] = str(e)
        return stats
    finally:
        v.close()


def _steps(backend, what, *args):
    """backend.read / backend.write as steps (a backend without them simply does it)."""
    fn = getattr(backend, what + "_steps", None)
    if fn is None:
        return getattr(backend, what)(*args)
    return (yield from fn(*args))


def sync_changed(data_dir, game, backend, device, marks, versions, force=False, user="local", **kw):
    return run(sync_changed_steps(data_dir, game, backend, device, marks, versions, force, user, **kw))


def sync_changed_steps(data_dir, game, backend, device, marks, versions, force=False, user="local", **kw):
    """sync_game (in pieces) - unless neither the account's copy of this game nor this device's data for it has moved since the last sync that finished (see syncmarks).  `marks` is None for a backend that
    cannot say which version a document is at; `versions` is {document: version} as the account listed them at the start of this sync."""
    path = data_path(user, game)
    stamp = syncmarks.local_stamp(kw.get("user_path") or os.path.join(data_dir, "collection.db"), game, user) if marks is not None else None
    if marks is not None and not force and marks.unchanged(game, versions.get(path), stamp):
        return {"game": game, "pulled": 0, "pushed": False, "conflicts": 0, "skipped": True}
    stats = yield from sync_game_steps(data_dir, game, backend, device, user=user, **kw)
    if marks is not None:
        if stats.get("failed") or stats["pulled"]:
            marks.forget(game)                    # (what arrived changed this device's data: the next sync looks once more and then remembers)
        else:
            marks.keep(game, getattr(backend, "seen", {}).get(path), stamp)          # (the stamp is from BEFORE the sync, so an edit made while it ran still counts as a change next time)
    return stats


def sync_photos(data_dir, game, backend, user_path=None, user="local", limit=None):
    from . import photos
    conn = sqlite3.connect(":memory:", timeout=30)          # the photo step only needs your own tables: opening the whole collection (card list, groups...) for it cost a fifth of a second every sync
    try:
        conn.execute("ATTACH DATABASE ? AS u", (user_path or os.path.join(data_dir, "collection.db"),))
        have = {r[0] for r in conn.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}
        if {"lot_photos", "photo_deleted", "lots", "sealed"} <= have:
            return photos.sync_photos(conn, backend, limit)
    finally:
        conn.close()
    v = Vault(data_dir, game, user, user_path=user_path)                  # (an older collection without the photo tables yet: the full open adds them)
    try:
        return photos.sync_photos(v.conn, backend, limit)
    finally:
        v.close()


def merge_in(data_dir, game, backend, user="local", user_path=None, device="merge"):
    """Bring another account's collection for one game into this one.  Reads the other account only - nothing is written back to it.  -> number of records pulled."""
    v = Vault(data_dir, game, user, user_path=user_path)
    try:
        raw, _etag = backend.read(data_path(user, game))
        if not raw:
            return 0
        remote = json.loads(raw.decode("utf-8"))
        local = export_snapshot(v, device)
        merged = merge(local, remote)
        return apply_snapshot(v, merged) if not same(merged, local) else 0
    finally:
        v.close()


def build_catalog(v):
    """A compact card list for the phone app: sets + cards (id, number, name, rarity, price, picture, plus what it needs to browse by
    category / illustrator / Pokemon exactly like the computer does).  The price is the one Settings > Price sources picks (pricepick), so the phone's totals, tiles and
    cost to complete are the desktop's numbers; slot 12 is the Cardmarket euro price (the desktop's "on Cardmarket" total)."""
    from .. import checklists, games, portfoliooptions, pricepick, taxonomy
    try:
        extra_urls = json.loads(v.meta("setimg_urls") or "{}")
    except ValueError:
        extra_urls = {}
    sets = [[s["id"], s["name"], s["serie"] or "", (s["release_date"] or "")[:10], s["n"] or 0,
             (s["logo"] + ".webp") if s["logo"] else extra_urls.get(s["id"], "")] for s in v.sets()]
    set_idx = {s[0]: i for i, s in enumerate(sets)}
    index = v.card_index()
    rarities = sorted({c["rarity"] for c in index if c.get("rarity")})
    rar_idx = {r: i for i, r in enumerate(rarities)}
    illustrators = sorted({c["illustrator"] for c in index if c.get("illustrator")})
    ill_idx = {n: i for i, n in enumerate(illustrators)}
    light = {c["id"]: c for c in index}
    split, per = portfoliooptions.phone_split(v)                       # (slots 13 / 14: a card's colour and product type, for the value splits that need them - ui/src/phone/portfolio.js)
    wide = bool(split["colors"] or split["products"])
    cards = []
    for c in v.conn.execute("SELECT id, set_id, local_id, name, rarity, price_usd, price_eur, image_base, types, variants FROM cards ORDER BY set_id, sort_key, local_id"):
        lc = light.get(c["id"], {})
        usd = pricepick.price_for(v, c["id"], c["price_usd"])
        cards.append([c["id"], set_idx.get(c["set_id"], -1), c["local_id"], c["name"], rar_idx.get(c["rarity"], -1),
                      None if usd is None else round(usd, 2), c["image_base"] or "", c["types"] or "", v.default_variant(c["id"]),
                      ill_idx.get(lc.get("illustrator"), -1), lc.get("dex") or "", ",".join(sorted(lc.get("groups") or [])), None if c["price_eur"] is None else round(c["price_eur"], 2)] + (per.get(c["id"], [-1, -1]) if wide else []))
    g = games.game_by_id(v.game)
    out = {"format": 3, "price_basis": "" if pricepick.prices(v) is None else pricepick.label(v), "game": v.game, "name": g.name, "pokemon": g.pokemon, "sets": sets, "rarities": rarities, "cards": cards, "illustrators": illustrators,
           "groups": [{"id": x.id, "label": x.label, "parent": x.parent, "help": getattr(x, "help", "")} for x in taxonomy.groups()],
           "sections": [[sec, title] for sec, title in taxonomy.SECTIONS], "image_suffix": "/low.webp" if g.pokemon else "", "split": split}
    if g.pokemon:
        out["dex_names"] = {str(d): n for d, n in checklists.dex_names(v).items()}
    return out


def publish_catalog_file(v, backend, key=None):
    """Upload the phone's card list when it changed (skipped when the same content is already there)."""
    data = gzip.compress(json.dumps(build_catalog(v), ensure_ascii=False, separators=(",", ":")).encode("utf-8"), 9, mtime=0)
    path = f"catalog/{v.game}.json.gz"
    data = e2e.wrap(key, data, path) if key else data
    digest = hashlib.sha1(data).hexdigest()
    raw, etag = backend.read(path)
    if raw is not None and hashlib.sha1(raw).hexdigest() == digest:
        return "unchanged"
    backend.write(path, data, etag, f"Card list for {v.game}")
    return f"published {len(data) // 1024} KB"


def publish_other_catalogs(data_dir, backend, skip=(), key=None, user_path=None):
    """Put the card list of every downloaded game on the phone's menu (Japanese, One Piece...), even before you own a card from it."""
    from .. import games
    from ..db import game_dir
    out = {}
    for g in games.GAMES:
        if not g.available or g.id in skip or not os.path.exists(os.path.join(game_dir(data_dir, g.id), "cards.db")):
            continue
        try:
            v = Vault(data_dir, g.id, "local", user_path=user_path)
            try:
                if v.card_count():
                    out[g.id] = publish_catalog_file(v, backend, key)
            finally:
                v.close()
        except Exception as e:  # noqa: BLE001 - a bonus; never fail the sync
            out[g.id] = f"error: {e}"
    return out
