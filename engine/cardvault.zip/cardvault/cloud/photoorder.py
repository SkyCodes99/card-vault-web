"""The order of an item's photos (which one is the cover) travels with the account, so every device shows the same cover.

Each item whose photos were arranged has ONE tiny document in the account: 'photoorder/<item uuid>/<time>' holding the photos' fingerprints in order (nothing else - never a picture).
Arranging again writes the newer document and removes the older one; the newest time wins on every device.  Locally u.photo_order remembers when each item was last arranged
(`at`) and what was last sent or applied (`pushed`).  Only positions change here: this module never adds, removes or rewrites a photo."""
import hashlib
import re
import sqlite3

from ..db import now_iso

PREFIX = "photoorder/"
_STAMP = re.compile(r"\D")


def ensure(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS u.photo_order(lot_uuid TEXT PRIMARY KEY, at TEXT, pushed TEXT)")


def changed(conn, owner):
    """This item's photos were just arranged on this device (the next sync sends the new order)."""
    ensure(conn)
    conn.execute("INSERT INTO u.photo_order(lot_uuid, at, pushed) VALUES(?,?,NULL) ON CONFLICT(lot_uuid) DO UPDATE SET at=excluded.at", (owner, _STAMP.sub("", now_iso())))


def _fp(data):
    return hashlib.sha1(data).hexdigest()[:20]


def _remote(names):
    """{item uuid: (time, [document names])} from the account's document list."""
    out = {}
    for n in names:
        if n.startswith(PREFIX) and n.count("/") == 2:
            lot, stamp = n[len(PREFIX):].split("/")
            at, docs = out.get(lot, ("", []))
            out[lot] = (max(at, stamp), docs + [n])
    return out


def sync(conn, backend, names, have):
    """Run after the photos themselves are up and down.  names: every document name in the account; have: the photo keys the account holds.  -> True when something changed here."""
    if not hasattr(backend, "delete"):
        return False
    try:
        ensure(conn)
        local = {r[0]: (r[1] or "", r[2] or "") for r in conn.execute("SELECT lot_uuid, at, pushed FROM u.photo_order")}
        remote = _remote(names)
        touched = False
        for lot in set(local) | set(remote):
            at, pushed = local.get(lot, ("", ""))
            r_at, r_docs = remote.get(lot, ("", []))
            if at and at != pushed and at >= r_at:                                  # arranged here, newer than anything in the account: send it
                order = [_fp(d) for (d,) in conn.execute("SELECT data FROM u.lot_photos WHERE lot_uuid=? AND data IS NOT NULL ORDER BY pos IS NULL, pos, id", (lot,))]
                backend.write(f"{PREFIX}{lot}/{at}", ",".join(order).encode(), None)
                for n in r_docs:
                    if n != f"{PREFIX}{lot}/{at}":
                        backend.delete(n)
                conn.execute("UPDATE u.photo_order SET pushed=? WHERE lot_uuid=?", (at, lot))
            elif r_at and r_at > at:                                                # arranged on another device, later: apply it here
                touched |= _apply(conn, backend, lot, r_at, r_docs, have)
        return touched
    except sqlite3.OperationalError:                                                 # (a collection from before photos could be arranged: nothing to do yet)
        return False


def _apply(conn, backend, lot, r_at, r_docs, have):
    raw, _ = backend.read(f"{PREFIX}{lot}/{r_at}")
    wanted = (raw or b"").decode("ascii", "ignore").split(",") if raw else []
    wanted = [w for w in wanted if w]
    ids = {}
    for pid, data in conn.execute("SELECT id, data FROM u.lot_photos WHERE lot_uuid=? AND data IS NOT NULL ORDER BY pos IS NULL, pos, id", (lot,)):
        ids[_fp(data)] = pid
    final = [ids[w] for w in wanted if w in ids] + [p for f, p in ids.items() if f not in wanted]
    for n, pid in enumerate(final, 1):
        conn.execute("UPDATE u.lot_photos SET pos=? WHERE id=?", (n, pid))
    waiting = any(w not in ids and f"{lot}/{w}" in have for w in wanted)           # (a photo of that order is still on its way down: look at the order again next time)
    if not waiting:
        conn.execute("INSERT INTO u.photo_order(lot_uuid, at, pushed) VALUES(?,?,?) ON CONFLICT(lot_uuid) DO UPDATE SET at=excluded.at, pushed=excluded.pushed", (lot, r_at, r_at))
    return bool(final)
