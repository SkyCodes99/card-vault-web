"""Your data as a portable snapshot, and the rules for merging two snapshots (this PC + the phone / another PC).

A snapshot holds everything you entered for ONE game: copies you own (lots), wishlist, checklists (with their hand-picked cards and chosen
slot cards), your own categories, and per-card category corrections.  Every record has a stable id (uuid / key) and an updated_at time;
deleted things are kept as 'deleted' records or tombstones.  Merging is last-writer-wins per record, so the result is the same whichever
device merges first - the same rules are implemented in the phone app (web/js/merge.js).
"""
import itertools
import json

from .. import customitems, decks, setgoals, sold

FORMAT = 1
PER_DEVICE = ("device", "exported", "derived")          # what a snapshot says about who wrote it and when (never part of the data); 'derived' was only ever read by the old phone app


def _ts(r):
    return (r or {}).get("updated_at") or ""


# ------------------------------------------------------------------------------------------------------- export
def export_snapshot(v, device=""):
    """Everything of this game that syncs.  Every list comes out in the order merge() gives it (so two snapshots of the same data compare equal with ==, see same())."""
    c, u = v.conn, (v.user_id, v.game)
    lots = [dict(r) for r in c.execute(
        "SELECT uuid, card_id, variant, condition, language, qty, graded, grade_company, grade, cert, slab_status, purchase_price, notes, location, edition, purchased, source, portfolio, added, updated_at, deleted "
        "FROM u.lots WHERE user_id=? AND game=? ORDER BY uuid", u)]
    for r in lots:
        r["updated_at"] = r["updated_at"] or r["added"] or ""
    wishlist = [{"card_id": r[0], "note": r[1] or "", "updated_at": r[2] or ""} for r in
                c.execute("SELECT card_id, note, added FROM u.wishlist WHERE user_id=? AND game=? ORDER BY card_id", u)]
    checklists = []
    for r in c.execute("SELECT * FROM u.checklists WHERE user_id=? AND game=? ORDER BY uuid", u).fetchall():
        checklists.append({
            "uuid": r["uuid"], "name": r["name"], "mode": r["mode"], "per_variant": r["per_variant"], "rules": r["rules"], "notes": r["notes"] or "",
            "created_at": r["created_at"], "updated_at": r["updated_at"] or r["created_at"] or "", "deleted": r["deleted"] or 0,
            "items": [[a, b] for a, b in c.execute("SELECT card_id, source FROM u.checklist_items WHERE checklist_id=? ORDER BY card_id", (r["id"],))],
            "picks": {k: cid for k, cid in c.execute("SELECT slot_key, card_id FROM u.checklist_picks WHERE checklist_id=?", (r["id"],))},
        })
    groups = [{"key": r["key"], "label": r["label"], "section": r["section"], "help": r["help"] or "", "rules": r["rules"],
               "counts_as_art": r["counts_as_art"] or 0, "created_at": r["created_at"], "updated_at": r["updated_at"] or r["created_at"] or "",
               "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.custom_groups WHERE user_id=? AND game=? ORDER BY key", u)]
    tags = [{"card_id": a, "tag": b, "value": val, "updated_at": ts or ""} for a, b, val, ts in
            c.execute("SELECT card_id, tag, value, updated_at FROM u.card_tags WHERE user_id=? AND game=? ORDER BY card_id, tag", u)]
    tombs = [{"kind": a, "key": b, "deleted_at": ts} for a, b, ts in
             c.execute("SELECT kind, key, deleted_at FROM u.tombstones WHERE user_id=? AND game=? ORDER BY kind, key", u)]
    pfs = [{"uuid": r["uuid"], "name": r["name"], "color": r["color"] or "", "created_at": r["created_at"], "updated_at": r["updated_at"] or r["created_at"] or "",
            "meta": r["meta"] or "", "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.portfolios WHERE user_id=? ORDER BY uuid", (v.user_id,))]
    trades = [{"uuid": r["uuid"], "ts": r["ts"], "partner": r["partner"] or "", "notes": r["notes"] or "", "data": r["data"] or "{}", "updated_at": r["updated_at"] or r["ts"] or "",
               "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.trades WHERE user_id=? AND game=? ORDER BY uuid", u)]
    sealed = [{"uuid": r["uuid"], "upc": r["upc"] or "", "name": r["name"] or "", "qty": r["qty"], "paid": r["paid"], "purchased": r["purchased"] or "", "source": r["source"] or "", "notes": r["notes"] or "",
               "portfolio": r["portfolio"] or "", "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? ORDER BY uuid", u)]
    binders = [{"uuid": r["uuid"], "name": r["name"], "rows": r["rows"], "cols": r["cols"], "pages": r["pages"], "slots": r["slots"] or "{}", "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0}
               for r in c.execute("SELECT * FROM u.dream_binders WHERE user_id=? AND game=? ORDER BY uuid", u)]
    spending = [{"uuid": r["uuid"], "day": r["day"], "amount_usd": r["amount_usd"], "category": r["category"] or "", "note": r["note"] or "", "deleted": r["deleted"] or 0,
                 "updated_at": r["updated_at"] or ""} for r in c.execute("SELECT * FROM u.spending WHERE user_id=? AND game=? ORDER BY uuid", u)]
    shares = [{"uuid": r["uuid"], "token": r["token"], "title": r["title"] or "", "kind": r["kind"] or "", "scope": r["scope"] or "", "perms": r["perms"] or "", "expires_at": r["expires_at"] or "",
               "created_at": r["created_at"] or "", "updated_at": r["updated_at"] or r["created_at"] or "", "revoked": r["revoked"] or 0, "published_url": r["published_url"] or ""}
              for r in c.execute("SELECT * FROM u.shares WHERE user_id=? AND game=? ORDER BY uuid", u)]
    history = [{"day": r["day"], "total_usd": r["total_usd"], "total_eur": r["total_eur"], "copies": r["copies"], "unique_cards": r["unique_cards"], "breakdown": r["breakdown"] or "{}",
                "updated_at": r["ts"] or r["day"] or ""} for r in c.execute("SELECT * FROM u.snapshots WHERE user_id=? AND game=? ORDER BY day", u)]
    graded = [{"uuid": r["uuid"], "lot": r["lot_uuid"], "card_id": r["card_id"], "company": r["company"], "service": r["service"] or "", "sent": r["sent"], "cost": r["cost"] or 0.0,
               "submission": r["submission"] or "", "status": r["status"], "received": r["received"], "grade": r["grade"], "cert": r["cert"], "graded_on": r["graded_on"],
               "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0}
              for r in c.execute("SELECT g.*, l.uuid AS lot_uuid FROM u.grading g JOIN u.lots l ON l.id=g.lot_id WHERE g.user_id=? AND g.game=? ORDER BY g.uuid", u)]      # (the copy is named by its uuid: ids differ per device)
    out = {"format": FORMAT, "game": v.game, "user": v.user_id, "device": device, "spending": spending, "shares": shares, "value_history": history, "lots": lots, "wishlist": wishlist,
           "checklists": checklists, "custom_groups": groups, "tags": tags, "tombstones": tombs, "portfolios": pfs, "trades": trades, "sealed": sealed, "dream_binders": binders, "look": v.look_get()}
    if graded:
        out["grading"] = graded                                    # grading submissions (cardvault/grading.py) - only present once something was sent
    sold_rows = [{"uuid": r["uuid"], **{k: r[k] for k in sold.COLS}, "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0}
                 for r in c.execute("SELECT * FROM u.sold WHERE user_id=? AND game=? ORDER BY uuid", u)]      # (a sold row holds its own card name, price paid and grading cost: no copy link is needed)
    if sold_rows:
        out["sold"] = sold_rows                                    # sold history (cardvault/sold.py) - only present once something was sold
    own_rows = [{"uuid": r["uuid"], **{k: r[k] for k in customitems.COLS}, "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0}
                for r in c.execute("SELECT * FROM u.custom_items WHERE user_id=? AND game=? ORDER BY uuid", u)]
    if own_rows:
        out["custom_items"] = own_rows                             # your own items (cardvault/customitems.py) - only present once one was added; the picture itself travels as a photo of your account
    deck_rows = [{"uuid": r["uuid"], **{k: r[k] for k in decks.COLS}, "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0}
                 for r in c.execute("SELECT * FROM u.decks WHERE user_id=? AND game=? ORDER BY uuid", u)]
    if deck_rows:
        out["decks"] = deck_rows                                   # the decks (cardvault/decks.py) - only present once one was made
    goals = setgoals.raw(v)
    if goals:
        out["set_goals"] = goals                                   # the goal (Standard / Master / Extra) picked for each set - only present once one was picked
    here = v.here_get()
    if here:
        out["here"] = here                                         # "where I was" (webapi/hereapi.py): travels with every game, newest wins - only present once there is one
    return out


# ------------------------------------------------------------------------------------------------------- merge
def _newer(a, b):
    """Does record `a` win over record `b` (the same thing seen on two devices)?  The later updated_at wins; an exact tie goes to whichever sorts later as text, so every device picks the same one.
    Almost every record is the same on both sides: that is settled by == and never needs the text."""
    ta, tb = _ts(a), _ts(b)
    if ta != tb:
        return ta > tb
    if a == b:
        return False
    return json.dumps(a, sort_keys=True) > json.dumps(b, sort_keys=True)


def _latest(a_list, b_list, key):
    out = {}
    for rec in itertools.chain(a_list or (), b_list or ()):
        k = key(rec)
        if k not in out or _newer(rec, out[k]):
            out[k] = rec
    return out


def _merge_hard(local, remote, kind, key, ts_of):
    """Entities that are removed for real (wishlist, tags): a record survives only if it is newer than the matching tombstone."""
    recs = _latest(local.get(kind[0]), remote.get(kind[0]), key)
    tombs = {}
    for t in list(local.get("tombstones", [])) + list(remote.get("tombstones", [])):
        if t["kind"] == kind[1] and (t["key"] not in tombs or t["deleted_at"] > tombs[t["key"]]["deleted_at"]):
            tombs[t["key"]] = t
    alive, dead = [], []
    for k, rec in recs.items():
        t = tombs.get(k)
        if t and t["deleted_at"] >= ts_of(rec):
            continue
        alive.append(rec)
    for k, t in tombs.items():
        if k not in recs or t["deleted_at"] >= ts_of(recs[k]):
            dead.append(t)
    return alive, dead


def merge(local, remote):
    """Merge two snapshots of the same game.  remote may be None (nothing stored yet)."""
    remote = remote or {}
    out = {"format": FORMAT, "game": local.get("game"), "user": local.get("user")}
    out["lots"] = sorted(_latest(local.get("lots"), remote.get("lots"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["sealed"] = sorted(_latest(local.get("sealed"), remote.get("sealed"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["dream_binders"] = sorted(_latest(local.get("dream_binders"), remote.get("dream_binders"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["trades"] = sorted(_latest(local.get("trades"), remote.get("trades"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["portfolios"] = sorted(_latest(local.get("portfolios"), remote.get("portfolios"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["checklists"] = sorted(_latest(local.get("checklists"), remote.get("checklists"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["custom_groups"] = sorted(_latest(local.get("custom_groups"), remote.get("custom_groups"), lambda r: r["key"]).values(), key=lambda r: r["key"])
    if local.get("grading") or remote.get("grading"):
        out["grading"] = sorted(_latest(local.get("grading"), remote.get("grading"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    if local.get("sold") or remote.get("sold"):
        out["sold"] = sorted(_latest(local.get("sold"), remote.get("sold"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    if local.get("custom_items") or remote.get("custom_items"):
        out["custom_items"] = sorted(_latest(local.get("custom_items"), remote.get("custom_items"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    if local.get("decks") or remote.get("decks"):
        out["decks"] = sorted(_latest(local.get("decks"), remote.get("decks"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["spending"] = sorted(_latest(local.get("spending"), remote.get("spending"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["shares"] = sorted(_latest(local.get("shares"), remote.get("shares"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["value_history"] = sorted(_latest(local.get("value_history"), remote.get("value_history"), lambda r: r["day"]).values(), key=lambda r: r["day"])
    a, b = local.get("look") or {}, remote.get("look") or {}
    out["look"] = b if _ts(b) > _ts(a) else a                      # the most recently chosen look wins (the local one on an exact tie)
    goals = setgoals.merge(local.get("set_goals"), remote.get("set_goals"))
    if goals:
        out["set_goals"] = goals                                   # newest pick per set wins
    a, b = local.get("here") or {}, remote.get("here") or {}
    if a or b:
        out["here"] = b if _ts(b) > _ts(a) else a                  # "where I was": the newest one wins (an old one from another device never replaces a newer one)
    wl, wl_dead = _merge_hard(local, remote, ("wishlist", "wishlist"), lambda r: r["card_id"], _ts)
    tg, tg_dead = _merge_hard(local, remote, ("tags", "tag"), lambda r: f"{r['card_id']}|{r['tag']}", _ts)
    out["wishlist"] = sorted(wl, key=lambda r: r["card_id"])
    out["tags"] = sorted(tg, key=lambda r: (r["card_id"], r["tag"]))
    out["tombstones"] = sorted(wl_dead + tg_dead, key=lambda t: (t["kind"], t["key"]))
    for k in (set(remote) | set(local)) - set(out) - set(PER_DEVICE):
        out[k] = remote[k] if k in remote else local[k]           # (3.50.132) a kind of data a NEWER version added is passed on untouched, never dropped from the account copy
    return out


def canonical(snapshot):
    """Stable text of a snapshot without per-device fields."""
    s = {k: v for k, v in snapshot.items() if k not in PER_DEVICE}
    return json.dumps(s, sort_keys=True, ensure_ascii=False)


def same(a, b):
    """Do two snapshots hold the same data (whoever wrote them, whenever)?  export_snapshot and merge give every list in the same order, so == answers it - far faster than writing both out as text."""
    return {k: v for k, v in a.items() if k not in PER_DEVICE} == {k: v for k, v in b.items() if k not in PER_DEVICE}


# ------------------------------------------------------------------------------------------------------- apply
def _update_present(c, table, cols, r, where, args):
    """UPDATE only the columns the record carries: a record from a device on an older version lacks the newer fields (slab_status...), and those keep their value here instead of being wiped."""
    ks = [k for k in cols if k in r]
    if ks:
        c.execute(f"UPDATE {table} SET " + ",".join(f"{k}=?" for k in ks) + " WHERE " + where, (*[r[k] for k in ks], *args))


def apply_snapshot(v, merged, touched=None):
    """Write a merged snapshot into the local collection.  Returns how many records changed.  `touched` (a set), when given, is told "taxonomy" if something that decides which groups a card is in
    (a correction to a card, a category of your own) changed - then the card index has to be worked out again; copies you own, wishlists, checklists... do not need that."""
    c, u = v.conn, (v.user_id, v.game)
    changed = 0
    taxonomy = False
    items_changed = False
    v._defer = True
    try:
        look = merged.get("look") or {}
        if look and _ts(look) > _ts(v.look_get()):
            v.look_set(look)
        here = merged.get("here") or {}
        if here and _ts(here) > _ts(v.here_get()):
            v.here_set(here)                                       # (not counted as a change: moving between pages is no news worth a "changes arrived" note)
        changed += setgoals.apply(v, merged.get("set_goals"))
        for sp in merged.get("spending", []):
            old = c.execute("SELECT updated_at FROM u.spending WHERE uuid=?", (sp["uuid"],)).fetchone()
            if old is None:
                c.execute("INSERT INTO u.spending(uuid,user_id,game,day,amount_usd,category,note,deleted,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                          (sp["uuid"], u[0], u[1], sp.get("day"), sp.get("amount_usd"), sp.get("category"), sp.get("note"), sp.get("deleted", 0), sp.get("updated_at")))
                changed += 1
            elif (old[0] or "") != (sp.get("updated_at") or ""):
                c.execute("UPDATE u.spending SET day=?, amount_usd=?, category=?, note=?, deleted=?, updated_at=? WHERE uuid=?",
                          (sp.get("day"), sp.get("amount_usd"), sp.get("category"), sp.get("note"), sp.get("deleted", 0), sp.get("updated_at"), sp["uuid"]))
                changed += 1
        for sh in merged.get("shares", []):
            old = c.execute("SELECT updated_at FROM u.shares WHERE uuid=?", (sh["uuid"],)).fetchone()
            vals = (sh.get("token"), sh.get("title"), sh.get("kind"), sh.get("scope"), sh.get("perms"), sh.get("expires_at"), sh.get("created_at"), sh.get("updated_at"), sh.get("revoked", 0), sh.get("published_url"))
            if old is None:
                c.execute("INSERT INTO u.shares(uuid,user_id,game,token,title,kind,scope,perms,expires_at,created_at,updated_at,revoked,published_url) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (sh["uuid"], u[0], u[1], *vals))
                changed += 1
            elif (old[0] or "") != (sh.get("updated_at") or ""):
                c.execute("UPDATE u.shares SET token=?, title=?, kind=?, scope=?, perms=?, expires_at=?, created_at=?, updated_at=?, revoked=?, published_url=? WHERE uuid=?", (*vals, sh["uuid"]))
                changed += 1
        for hv in merged.get("value_history", []):            # the saved value-over-time points: a day recorded on any device is kept (the newest reading of a day wins)
            old = c.execute("SELECT ts FROM u.snapshots WHERE user_id=? AND game=? AND day=?", (*u, hv["day"])).fetchone()
            if old is None or (old[0] or "") < (hv.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.snapshots(user_id,game,day,ts,total_usd,total_eur,copies,unique_cards,breakdown) VALUES(?,?,?,?,?,?,?,?,?)",
                          (*u, hv["day"], hv.get("updated_at"), hv.get("total_usd"), hv.get("total_eur"), hv.get("copies"), hv.get("unique_cards"), hv.get("breakdown")))
                changed += 1
        # lots
        have = {r["uuid"]: r for r in c.execute("SELECT uuid, updated_at, deleted, qty FROM u.lots WHERE user_id=? AND game=?", u)}
        cols = ("card_id", "variant", "condition", "language", "qty", "graded", "grade_company", "grade", "cert", "slab_status", "purchase_price", "notes", "location", "edition", "purchased", "source", "portfolio", "added", "updated_at", "deleted")
        for sl in merged.get("sealed", []):
            old = c.execute("SELECT updated_at FROM u.sealed WHERE uuid=?", (sl["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (sl.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (sl["uuid"], u[0], u[1], sl.get("upc"), sl.get("name"), sl.get("qty"), sl.get("paid"), sl.get("purchased"), sl.get("source"), sl.get("notes"), sl.get("portfolio"), sl.get("updated_at"), sl.get("deleted", 0)))
                changed += 1
        for bd in merged.get("dream_binders", []):
            old = c.execute("SELECT updated_at FROM u.dream_binders WHERE uuid=?", (bd["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (bd.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.dream_binders(uuid,user_id,game,name,rows,cols,pages,slots,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (bd["uuid"], u[0], u[1], bd.get("name"), bd.get("rows"), bd.get("cols"), bd.get("pages"), bd.get("slots"), bd.get("updated_at"), bd.get("deleted", 0)))
                changed += 1
        for tr in merged.get("trades", []):
            old = c.execute("SELECT updated_at FROM u.trades WHERE uuid=?", (tr["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (tr.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.trades(uuid,user_id,game,ts,partner,notes,data,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?)",
                          (tr["uuid"], u[0], u[1], tr.get("ts"), tr.get("partner"), tr.get("notes"), tr.get("data"), tr.get("updated_at"), tr.get("deleted", 0)))
                changed += 1
        for pf in merged.get("portfolios", []):
            old = c.execute("SELECT updated_at FROM u.portfolios WHERE uuid=?", (pf["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (pf.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.portfolios(uuid,user_id,name,color,created_at,updated_at,deleted,meta) VALUES(?,?,?,?,?,?,?,?)",
                          (pf["uuid"], u[0], pf["name"], pf.get("color", ""), pf.get("created_at"), pf.get("updated_at"), pf.get("deleted", 0), pf.get("meta") or None))
                changed += 1
        for r in merged["lots"]:
            cur = have.get(r["uuid"])
            if cur is None:
                c.execute("INSERT INTO u.lots(uuid,user_id,game," + ",".join(cols) + ") VALUES(?,?,?," + ",".join("?" * len(cols)) + ")",
                          (r["uuid"], *u, *[r.get(k) for k in cols]))
                changed += 1
            elif (cur["updated_at"] or "") != (r.get("updated_at") or ""):
                _update_present(c, "u.lots", cols, r, "uuid=? AND user_id=? AND game=?", (r["uuid"], *u))
                changed += 1
        # grading submissions (after the copies: each one points at its copy by uuid)
        if merged.get("grading"):
            lot_ids = {uu: i for uu, i in c.execute("SELECT uuid, id FROM u.lots WHERE user_id=? AND game=?", u)}
            have_g = {uu: ts for uu, ts in c.execute("SELECT uuid, updated_at FROM u.grading WHERE user_id=? AND game=?", u)}
            gcols = ("card_id", "company", "service", "sent", "cost", "submission", "status", "received", "grade", "cert", "graded_on", "updated_at", "deleted")
            for r in merged["grading"]:
                lot = lot_ids.get(r.get("lot"))
                if lot is None:
                    continue
                if r["uuid"] not in have_g:
                    c.execute("INSERT INTO u.grading(uuid,user_id,game,lot_id," + ",".join(gcols) + ") VALUES(?,?,?,?," + ",".join("?" * len(gcols)) + ")", (r["uuid"], *u, lot, *[r.get(k) for k in gcols]))
                    changed += 1
                elif (have_g[r["uuid"]] or "") != (r.get("updated_at") or ""):
                    c.execute("UPDATE u.grading SET lot_id=?," + ",".join(f"{k}=?" for k in gcols) + " WHERE uuid=?", (lot, *[r.get(k) for k in gcols], r["uuid"]))
                    changed += 1
        # sold history (self-contained rows: the copies leaving the collection travel with the lots)
        if merged.get("sold"):
            have_s = {uu: ts for uu, ts in c.execute("SELECT uuid, updated_at FROM u.sold WHERE user_id=? AND game=?", u)}
            for r in merged["sold"]:
                if r["uuid"] not in have_s:
                    c.execute("INSERT INTO u.sold(uuid,user_id,game," + ",".join(sold.COLS) + ") VALUES(?,?,?," + ",".join("?" * len(sold.COLS)) + ")", (r["uuid"], *u, *[r.get(k) for k in sold.COLS]))
                    changed += 1
                elif (have_s[r["uuid"]] or "") != (r.get("updated_at") or ""):
                    _update_present(c, "u.sold", sold.COLS, r, "uuid=?", (r["uuid"],))
                    changed += 1
        # decks
        if merged.get("decks"):
            decks.ensure(v)
            have_d = {uu: ts for uu, ts in c.execute("SELECT uuid, updated_at FROM u.decks WHERE user_id=? AND game=?", u)}
            for r in merged["decks"]:
                if r["uuid"] not in have_d:
                    c.execute("INSERT INTO u.decks(uuid,user_id,game," + ",".join(decks.COLS) + ") VALUES(?,?,?," + ",".join("?" * len(decks.COLS)) + ")", (r["uuid"], *u, *[r.get(k) for k in decks.COLS]))
                    changed += 1
                elif (have_d[r["uuid"]] or "") != (r.get("updated_at") or ""):
                    _update_present(c, "u.decks", decks.COLS, r, "uuid=?", (r["uuid"],))
                    changed += 1
        # your own items (the card-list copy is rebuilt below, once everything is written)
        if merged.get("custom_items"):
            customitems.ensure(v)
            have_i = {uu: ts for uu, ts in c.execute("SELECT uuid, updated_at FROM u.custom_items WHERE user_id=? AND game=?", u)}
            for r in merged["custom_items"]:
                if r["uuid"] not in have_i:
                    c.execute("INSERT INTO u.custom_items(uuid,user_id,game," + ",".join(customitems.COLS) + ") VALUES(?,?,?," + ",".join("?" * len(customitems.COLS)) + ")", (r["uuid"], *u, *[r.get(k) for k in customitems.COLS]))
                    changed += 1
                elif (have_i[r["uuid"]] or "") != (r.get("updated_at") or ""):
                    _update_present(c, "u.custom_items", customitems.COLS, r, "uuid=?", (r["uuid"],))
                    changed += 1
                    items_changed = True
                else:
                    continue
                items_changed = True
        # wishlist
        want = {r["card_id"]: r for r in merged["wishlist"]}
        cur = {r[0]: r for r in c.execute("SELECT card_id, note, added FROM u.wishlist WHERE user_id=? AND game=?", u)}
        for cid, r in want.items():
            if cid not in cur or (cur[cid][2] or "") != r["updated_at"]:
                c.execute("INSERT OR REPLACE INTO u.wishlist VALUES(?,?,?,?,?)", (*u, cid, r.get("note", ""), r["updated_at"]))
                changed += 1
        for cid in set(cur) - set(want):
            c.execute("DELETE FROM u.wishlist WHERE user_id=? AND game=? AND card_id=?", (*u, cid))
            changed += 1
        # tags
        want = {(r["card_id"], r["tag"]): r for r in merged["tags"]}
        cur = {(a, b): (val, ts) for a, b, val, ts in c.execute("SELECT card_id, tag, value, updated_at FROM u.card_tags WHERE user_id=? AND game=?", u)}
        for k, r in want.items():
            if k not in cur or cur[k] != (r["value"], r["updated_at"]):
                c.execute("INSERT OR REPLACE INTO u.card_tags VALUES(?,?,?,?,?,?)", (*u, k[0], k[1], r["value"], r["updated_at"]))
                changed += 1
                taxonomy = True
        for k in set(cur) - set(want):
            c.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (*u, *k))
            changed += 1
            taxonomy = True
        # your own categories
        have = {r["key"]: r for r in c.execute("SELECT key, updated_at FROM u.custom_groups WHERE user_id=? AND game=?", u)}
        for r in merged["custom_groups"]:
            vals = (r["label"], r["section"], r["help"], r["rules"], r["counts_as_art"], r["created_at"], r["updated_at"], r["deleted"])
            if r["key"] not in have:
                c.execute("INSERT INTO u.custom_groups(uuid,user_id,game,key,label,section,help,rules,counts_as_art,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                          (r["key"], *u, r["key"], *vals))
                changed += 1
                taxonomy = True
            elif (have[r["key"]]["updated_at"] or "") != r["updated_at"]:
                c.execute("UPDATE u.custom_groups SET label=?, section=?, help=?, rules=?, counts_as_art=?, created_at=?, updated_at=?, deleted=? WHERE user_id=? AND game=? AND key=?",
                          (*vals, *u, r["key"]))
                changed += 1
                taxonomy = True
        # checklists (items and slot picks travel with their checklist)
        have = {r["uuid"]: r for r in c.execute("SELECT id, uuid, updated_at FROM u.checklists WHERE user_id=? AND game=?", u)}
        for r in merged["checklists"]:
            cur = have.get(r["uuid"])
            vals = (r["name"], r["mode"], r["per_variant"], r["rules"], r["notes"], r["created_at"], r["updated_at"], r["deleted"])
            if cur is None:
                cid = c.execute("INSERT INTO u.checklists(uuid,user_id,game,name,mode,per_variant,rules,notes,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                                (r["uuid"], *u, *vals)).lastrowid
            elif (cur["updated_at"] or "") != r["updated_at"]:
                cid = cur["id"]
                c.execute("UPDATE u.checklists SET name=?, mode=?, per_variant=?, rules=?, notes=?, created_at=?, updated_at=?, deleted=? WHERE id=?", (*vals, cid))
            else:
                continue
            c.execute("DELETE FROM u.checklist_items WHERE checklist_id=?", (cid,))
            c.execute("DELETE FROM u.checklist_picks WHERE checklist_id=?", (cid,))
            for card_id, source in r.get("items", []):
                c.execute("INSERT OR REPLACE INTO u.checklist_items VALUES(?,?,?)", (cid, card_id, source))
            for slot, card_id in (r.get("picks") or {}).items():
                c.execute("INSERT OR REPLACE INTO u.checklist_picks VALUES(?,?,?)", (cid, slot, card_id))
            changed += 1
        # tombstones
        c.execute("DELETE FROM u.tombstones WHERE user_id=? AND game=?", u)
        for t in merged["tombstones"]:
            c.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (*u, t["kind"], t["key"], t["deleted_at"]))
    finally:
        v._defer = False
        v.conn.commit()
    if items_changed:
        customitems.materialize(v)                                 # (their cards in the list)
    if changed:
        v._cl_rev += 1
        if taxonomy:
            v.invalidate_index()
            v._register_taxonomy()
            if touched is not None:
                touched.add("taxonomy")
    return changed

