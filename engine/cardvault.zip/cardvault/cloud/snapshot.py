"""Your data as a portable snapshot, and the rules for merging two snapshots (this PC + the phone / another PC).

A snapshot holds everything you entered for ONE game: copies you own (lots), wishlist, checklists (with their hand-picked cards and chosen
slot cards), your own categories, and per-card category corrections.  Every record has a stable id (uuid / key) and an updated_at time;
deleted things are kept as 'deleted' records or tombstones.  Merging is last-writer-wins per record, so the result is the same whichever
device merges first - the same rules are implemented in the phone app (web/js/merge.js).
"""
import json

FORMAT = 1


def _ts(r):
    return (r or {}).get("updated_at") or ""


# ------------------------------------------------------------------------------------------------------- export
def export_snapshot(v, device=""):
    c, u = v.conn, (v.user_id, v.game)
    lots = [dict(r) for r in c.execute(
        "SELECT uuid, card_id, variant, condition, language, qty, graded, grade_company, grade, cert, purchase_price, notes, location, edition, purchased, source, portfolio, added, updated_at, deleted "
        "FROM u.lots WHERE user_id=? AND game=?", u)]
    for r in lots:
        r["updated_at"] = r["updated_at"] or r["added"] or ""
    wishlist = [{"card_id": r[0], "note": r[1] or "", "updated_at": r[2] or ""} for r in
                c.execute("SELECT card_id, note, added FROM u.wishlist WHERE user_id=? AND game=?", u)]
    checklists = []
    for r in c.execute("SELECT * FROM u.checklists WHERE user_id=? AND game=?", u).fetchall():
        checklists.append({
            "uuid": r["uuid"], "name": r["name"], "mode": r["mode"], "per_variant": r["per_variant"], "rules": r["rules"], "notes": r["notes"] or "",
            "created_at": r["created_at"], "updated_at": r["updated_at"] or r["created_at"] or "", "deleted": r["deleted"] or 0,
            "items": [[a, b] for a, b in c.execute("SELECT card_id, source FROM u.checklist_items WHERE checklist_id=? ORDER BY card_id", (r["id"],))],
            "picks": {k: cid for k, cid in c.execute("SELECT slot_key, card_id FROM u.checklist_picks WHERE checklist_id=?", (r["id"],))},
        })
    groups = [{"key": r["key"], "label": r["label"], "section": r["section"], "help": r["help"] or "", "rules": r["rules"],
               "counts_as_art": r["counts_as_art"] or 0, "created_at": r["created_at"], "updated_at": r["updated_at"] or r["created_at"] or "",
               "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.custom_groups WHERE user_id=? AND game=?", u)]
    tags = [{"card_id": a, "tag": b, "value": val, "updated_at": ts or ""} for a, b, val, ts in
            c.execute("SELECT card_id, tag, value, updated_at FROM u.card_tags WHERE user_id=? AND game=?", u)]
    tombs = [{"kind": a, "key": b, "deleted_at": ts} for a, b, ts in
             c.execute("SELECT kind, key, deleted_at FROM u.tombstones WHERE user_id=? AND game=?", u)]
    pfs = [{"uuid": r["uuid"], "name": r["name"], "color": r["color"] or "", "created_at": r["created_at"], "updated_at": r["updated_at"] or r["created_at"] or "",
            "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.portfolios WHERE user_id=?", (v.user_id,))]
    trades = [{"uuid": r["uuid"], "ts": r["ts"], "partner": r["partner"] or "", "notes": r["notes"] or "", "data": r["data"] or "{}", "updated_at": r["updated_at"] or r["ts"] or "",
               "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.trades WHERE user_id=? AND game=?", u)]
    sealed = [{"uuid": r["uuid"], "upc": r["upc"] or "", "name": r["name"] or "", "qty": r["qty"], "paid": r["paid"], "purchased": r["purchased"] or "", "source": r["source"] or "", "notes": r["notes"] or "",
               "portfolio": r["portfolio"] or "", "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0} for r in c.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=?", u)]
    binders = [{"uuid": r["uuid"], "name": r["name"], "rows": r["rows"], "cols": r["cols"], "pages": r["pages"], "slots": r["slots"] or "{}", "updated_at": r["updated_at"] or "", "deleted": r["deleted"] or 0}
               for r in c.execute("SELECT * FROM u.dream_binders WHERE user_id=? AND game=?", u)]
    return {"format": FORMAT, "game": v.game, "user": v.user_id, "device": device, "lots": lots, "wishlist": wishlist,
            "checklists": checklists, "custom_groups": groups, "tags": tags, "tombstones": tombs, "portfolios": pfs, "trades": trades, "sealed": sealed, "dream_binders": binders}


# ------------------------------------------------------------------------------------------------------- merge
def _latest(a_list, b_list, key):
    out = {}
    for rec in list(a_list or []) + list(b_list or []):
        k = key(rec)
        if k not in out or (_ts(rec), json.dumps(rec, sort_keys=True)) > (_ts(out[k]), json.dumps(out[k], sort_keys=True)):
            out[k] = rec
    return out


def _merge_hard(local, remote, kind, key, ts_of):
    """Entities that are removed for real (wishlist, tags): a record survives only if it is newer than the matching tombstone."""
    recs = _latest(local.get(kind[0]), remote.get(kind[0]), key)
    tombs = {}
    for t in list(local.get("tombstones", [])) + list(remote.get("tombstones", [])):
        if t["kind"] == kind[1] and (t["key"] not in tombs or t["deleted_at"] > tombs[t["key"]]["deleted_at"]):
            tombs[t["key"]] = t
    alive, dead = [], []
    for k, rec in recs.items():
        t = tombs.get(k)
        if t and t["deleted_at"] >= ts_of(rec):
            continue
        alive.append(rec)
    for k, t in tombs.items():
        if k not in recs or t["deleted_at"] >= ts_of(recs[k]):
            dead.append(t)
    return alive, dead


def merge(local, remote):
    """Merge two snapshots of the same game.  remote may be None (nothing stored yet)."""
    remote = remote or {}
    out = {"format": FORMAT, "game": local.get("game"), "user": local.get("user")}
    out["lots"] = sorted(_latest(local.get("lots"), remote.get("lots"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["sealed"] = sorted(_latest(local.get("sealed"), remote.get("sealed"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["dream_binders"] = sorted(_latest(local.get("dream_binders"), remote.get("dream_binders"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["trades"] = sorted(_latest(local.get("trades"), remote.get("trades"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["portfolios"] = sorted(_latest(local.get("portfolios"), remote.get("portfolios"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["checklists"] = sorted(_latest(local.get("checklists"), remote.get("checklists"), lambda r: r["uuid"]).values(), key=lambda r: r["uuid"])
    out["custom_groups"] = sorted(_latest(local.get("custom_groups"), remote.get("custom_groups"), lambda r: r["key"]).values(), key=lambda r: r["key"])
    wl, wl_dead = _merge_hard(local, remote, ("wishlist", "wishlist"), lambda r: r["card_id"], _ts)
    tg, tg_dead = _merge_hard(local, remote, ("tags", "tag"), lambda r: f"{r['card_id']}|{r['tag']}", _ts)
    out["wishlist"] = sorted(wl, key=lambda r: r["card_id"])
    out["tags"] = sorted(tg, key=lambda r: (r["card_id"], r["tag"]))
    out["tombstones"] = sorted(wl_dead + tg_dead, key=lambda t: (t["kind"], t["key"]))
    return out


def canonical(snapshot):
    """Stable text of a snapshot without per-device fields - used to tell whether anything really changed."""
    s = {k: v for k, v in snapshot.items() if k not in ("device", "exported", "derived")}
    return json.dumps(s, sort_keys=True, ensure_ascii=False)


# ------------------------------------------------------------------------------------------------------- apply
def apply_snapshot(v, merged):
    """Write a merged snapshot into the local collection.  Returns how many records changed."""
    c, u = v.conn, (v.user_id, v.game)
    changed = 0
    v._defer = True
    try:
        # lots
        have = {r["uuid"]: r for r in c.execute("SELECT uuid, updated_at, deleted, qty FROM u.lots WHERE user_id=? AND game=?", u)}
        cols = ("card_id", "variant", "condition", "language", "qty", "graded", "grade_company", "grade", "cert", "purchase_price", "notes", "location", "edition", "purchased", "source", "portfolio", "added", "updated_at", "deleted")
        for sl in merged.get("sealed", []):
            old = c.execute("SELECT updated_at FROM u.sealed WHERE uuid=?", (sl["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (sl.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (sl["uuid"], u[0], u[1], sl.get("upc"), sl.get("name"), sl.get("qty"), sl.get("paid"), sl.get("purchased"), sl.get("source"), sl.get("notes"), sl.get("portfolio"), sl.get("updated_at"), sl.get("deleted", 0)))
                changed += 1
        for bd in merged.get("dream_binders", []):
            old = c.execute("SELECT updated_at FROM u.dream_binders WHERE uuid=?", (bd["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (bd.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.dream_binders(uuid,user_id,game,name,rows,cols,pages,slots,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (bd["uuid"], u[0], u[1], bd.get("name"), bd.get("rows"), bd.get("cols"), bd.get("pages"), bd.get("slots"), bd.get("updated_at"), bd.get("deleted", 0)))
                changed += 1
        for tr in merged.get("trades", []):
            old = c.execute("SELECT updated_at FROM u.trades WHERE uuid=?", (tr["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (tr.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.trades(uuid,user_id,game,ts,partner,notes,data,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?)",
                          (tr["uuid"], u[0], u[1], tr.get("ts"), tr.get("partner"), tr.get("notes"), tr.get("data"), tr.get("updated_at"), tr.get("deleted", 0)))
                changed += 1
        for pf in merged.get("portfolios", []):
            old = c.execute("SELECT updated_at FROM u.portfolios WHERE uuid=?", (pf["uuid"],)).fetchone()
            if old is None or (old[0] or "") != (pf.get("updated_at") or ""):
                c.execute("INSERT OR REPLACE INTO u.portfolios(uuid,user_id,name,color,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?)",
                          (pf["uuid"], u[0], pf["name"], pf.get("color", ""), pf.get("created_at"), pf.get("updated_at"), pf.get("deleted", 0)))
                changed += 1
        for r in merged["lots"]:
            cur = have.get(r["uuid"])
            if cur is None:
                c.execute("INSERT INTO u.lots(uuid,user_id,game," + ",".join(cols) + ") VALUES(?,?,?," + ",".join("?" * len(cols)) + ")",
                          (r["uuid"], *u, *[r.get(k) for k in cols]))
                changed += 1
            elif (cur["updated_at"] or "") != (r.get("updated_at") or ""):
                c.execute("UPDATE u.lots SET " + ",".join(f"{k}=?" for k in cols) + " WHERE uuid=? AND user_id=? AND game=?",
                          (*[r.get(k) for k in cols], r["uuid"], *u))
                changed += 1
        # wishlist
        want = {r["card_id"]: r for r in merged["wishlist"]}
        cur = {r[0]: r for r in c.execute("SELECT card_id, note, added FROM u.wishlist WHERE user_id=? AND game=?", u)}
        for cid, r in want.items():
            if cid not in cur or (cur[cid][2] or "") != r["updated_at"]:
                c.execute("INSERT OR REPLACE INTO u.wishlist VALUES(?,?,?,?,?)", (*u, cid, r.get("note", ""), r["updated_at"]))
                changed += 1
        for cid in set(cur) - set(want):
            c.execute("DELETE FROM u.wishlist WHERE user_id=? AND game=? AND card_id=?", (*u, cid))
            changed += 1
        # tags
        want = {(r["card_id"], r["tag"]): r for r in merged["tags"]}
        cur = {(a, b): (val, ts) for a, b, val, ts in c.execute("SELECT card_id, tag, value, updated_at FROM u.card_tags WHERE user_id=? AND game=?", u)}
        for k, r in want.items():
            if k not in cur or cur[k] != (r["value"], r["updated_at"]):
                c.execute("INSERT OR REPLACE INTO u.card_tags VALUES(?,?,?,?,?,?)", (*u, k[0], k[1], r["value"], r["updated_at"]))
                changed += 1
        for k in set(cur) - set(want):
            c.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (*u, *k))
            changed += 1
        # your own categories
        have = {r["key"]: r for r in c.execute("SELECT key, updated_at FROM u.custom_groups WHERE user_id=? AND game=?", u)}
        for r in merged["custom_groups"]:
            vals = (r["label"], r["section"], r["help"], r["rules"], r["counts_as_art"], r["created_at"], r["updated_at"], r["deleted"])
            if r["key"] not in have:
                c.execute("INSERT INTO u.custom_groups(uuid,user_id,game,key,label,section,help,rules,counts_as_art,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                          (r["key"], *u, r["key"], *vals))
                changed += 1
            elif (have[r["key"]]["updated_at"] or "") != r["updated_at"]:
                c.execute("UPDATE u.custom_groups SET label=?, section=?, help=?, rules=?, counts_as_art=?, created_at=?, updated_at=?, deleted=? WHERE user_id=? AND game=? AND key=?",
                          (*vals, *u, r["key"]))
                changed += 1
        # checklists (items and slot picks travel with their checklist)
        have = {r["uuid"]: r for r in c.execute("SELECT id, uuid, updated_at FROM u.checklists WHERE user_id=? AND game=?", u)}
        for r in merged["checklists"]:
            cur = have.get(r["uuid"])
            vals = (r["name"], r["mode"], r["per_variant"], r["rules"], r["notes"], r["created_at"], r["updated_at"], r["deleted"])
            if cur is None:
                cid = c.execute("INSERT INTO u.checklists(uuid,user_id,game,name,mode,per_variant,rules,notes,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                                (r["uuid"], *u, *vals)).lastrowid
            elif (cur["updated_at"] or "") != r["updated_at"]:
                cid = cur["id"]
                c.execute("UPDATE u.checklists SET name=?, mode=?, per_variant=?, rules=?, notes=?, created_at=?, updated_at=?, deleted=? WHERE id=?", (*vals, cid))
            else:
                continue
            c.execute("DELETE FROM u.checklist_items WHERE checklist_id=?", (cid,))
            c.execute("DELETE FROM u.checklist_picks WHERE checklist_id=?", (cid,))
            for card_id, source in r.get("items", []):
                c.execute("INSERT OR REPLACE INTO u.checklist_items VALUES(?,?,?)", (cid, card_id, source))
            for slot, card_id in (r.get("picks") or {}).items():
                c.execute("INSERT OR REPLACE INTO u.checklist_picks VALUES(?,?,?)", (cid, slot, card_id))
            changed += 1
        # tombstones
        c.execute("DELETE FROM u.tombstones WHERE user_id=? AND game=?", u)
        for t in merged["tombstones"]:
            c.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (*u, t["kind"], t["key"], t["deleted_at"]))
    finally:
        v._defer = False
        v.conn.commit()
    if changed:
        v._cl_rev += 1
        v.invalidate_index()
        v._register_taxonomy()
    return changed


def build_derived(v):
    """Read-only facts the phone app can't work out itself (it has no rules engine): which cards are on each checklist and, for Pokédex /
    rarity style lists, the slots with their candidate cards.  Rebuilt by the desktop at every sync; ignored when merging."""
    from .. import checklists
    out = {}
    for cl in v.checklists():
        if cl["mode"] in ("dex", "rarity"):
            prog = checklists.progress_for_checklist(v, cl)
            out[cl["uuid"]] = {"mode": cl["mode"], "slots": [{"key": t.key, "label": t.label, "cands": t.candidates} for t in prog.tiles]}
        else:
            out[cl["uuid"]] = {"mode": "cards", "members": v.checklist_members(cl["id"])}
    return {"checklists": out}
