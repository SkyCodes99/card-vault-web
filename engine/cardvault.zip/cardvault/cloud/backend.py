"""Where the shared copy of your data lives.  Everything else talks to this small interface, so the storage can be swapped
(a GitHub repo today, a cloud database later) without touching the app, the sync rules or the phone app's data format.

A backend stores named byte blobs ("files") and does optimistic concurrency: read() returns an opaque version tag (etag) and write()
only succeeds if the file still has that version - otherwise it raises Conflict and the engine re-reads, re-merges and retries.
"""
import base64
import hashlib
import json
import os

import requests

UA = "PokemonCardVault/2 (personal sync)"


class Conflict(Exception):
    """The file changed on the server since it was read."""


class BackendError(Exception):
    pass


class SyncBackend:
    name = "backend"

    def read(self, path):
        """-> (bytes, etag), or (None, None) when the file doesn't exist yet."""
        raise NotImplementedError

    def write(self, path, data, etag, message="Update"):
        """Store bytes; etag = the version read before (None for a new file).  Returns the new etag.  Raises Conflict."""
        raise NotImplementedError

    def describe(self):
        return self.name


class FolderBackend(SyncBackend):
    """A plain folder (a second PC, a Dropbox / OneDrive folder, or tests)."""
    name = "folder"

    def __init__(self, root):
        self.root = root

    def _p(self, path):
        return os.path.join(self.root, *path.split("/"))

    def read(self, path):
        p = self._p(path)
        if not os.path.exists(p):
            return None, None
        with open(p, "rb") as f:
            data = f.read()
        return data, hashlib.sha1(data).hexdigest()

    def write(self, path, data, etag, message="Update"):
        cur, cur_tag = self.read(path)
        if cur_tag != etag:
            raise Conflict(path)
        p = self._p(path)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p + ".tmp", "wb") as f:
            f.write(data)
        os.replace(p + ".tmp", p)
        return hashlib.sha1(data).hexdigest()

    def describe(self):
        return f"folder {self.root}"


class GitHubRepoBackend(SyncBackend):
    """A private GitHub repository used as a tiny file store (REST 'contents' API).  Every save is a commit, so the history is a backup."""
    name = "github"

    def __init__(self, repo, token, branch="main"):
        self.repo, self.token, self.branch = repo, token, branch
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {token}", "User-Agent": UA, "X-GitHub-Api-Version": "2022-11-28"})

    def _url(self, path):
        return f"https://api.github.com/repos/{self.repo}/contents/{path}"

    def read(self, path):
        r = self.s.get(self._url(path), params={"ref": self.branch}, timeout=40)
        if r.status_code == 404:
            return None, None
        if r.status_code in (401, 403):
            raise BackendError(f"GitHub refused access ({r.status_code}) - check the token / repository name")
        r.raise_for_status()
        meta = r.json()
        if isinstance(meta, list):
            raise BackendError(f"{path} is a folder")
        if meta.get("content"):
            return base64.b64decode(meta["content"]), meta["sha"]
        raw = self.s.get(self._url(path), params={"ref": self.branch}, headers={"Accept": "application/vnd.github.raw+json"}, timeout=120)
        raw.raise_for_status()
        return raw.content, meta["sha"]

    def write(self, path, data, etag, message="Update"):
        body = {"message": message, "content": base64.b64encode(data).decode(), "branch": self.branch}
        if etag:
            body["sha"] = etag
        r = self.s.put(self._url(path), json=body, timeout=120)
        if r.status_code in (409, 422):
            raise Conflict(path)
        if r.status_code in (401, 403):
            raise BackendError(f"GitHub refused to save ({r.status_code}) - the token needs write access to the data repository")
        r.raise_for_status()
        return r.json()["content"]["sha"]

    def describe(self):
        return f"GitHub repository {self.repo}"


class CloudDbBackend(SyncBackend):
    """PLACEHOLDER for the cloud database that will replace the GitHub file store.

    Implement read() / write() with the same semantics and nothing else in the app changes:
      * map `path` (e.g. 'users/local/pokemon.json') to a document / row key,
      * return a monotonically changing version (row version, updated-at, etc.) as the etag,
      * make write() fail with Conflict when the stored version differs from `etag` (compare-and-set / transaction).
    Records inside the snapshot already carry uuid + updated_at + deleted, so a real database can later store them as individual rows and the
    merge rules in cloud/snapshot.py stay exactly the same (see docs/SYNC.md)."""
    name = "cloud-db"

    def read(self, path):
        raise NotImplementedError("cloud database backend not available yet")

    def write(self, path, data, etag, message="Update"):
        raise NotImplementedError("cloud database backend not available yet")


def make_backend(cfg, token=None):
    kind = cfg.get("sync_backend", "github")
    if kind == "folder":
        return FolderBackend(cfg["sync_folder"])
    if kind == "github":
        if not cfg.get("sync_repo") or not token:
            raise BackendError("sync is not set up (repository / token missing)")
        return GitHubRepoBackend(cfg["sync_repo"], token, cfg.get("sync_branch", "main"))
    if kind == "cloud-db":
        return CloudDbBackend()
    raise BackendError(f"unknown sync backend {kind}")
