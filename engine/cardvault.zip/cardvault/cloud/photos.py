"""Photos of your copies travel with the account too: one small encrypted document per photo (named after the copy and a fingerprint of the picture, so the
same photo is never stored twice), and a tiny 'removed' marker when you delete one so it doesn't come back from another device."""
import hashlib

MAX_PHOTO = 600_000                    # a photo is already shrunk to a few hundred KB; anything bigger stays on this device
ACCOUNT_BUDGET = 400 * 1024 * 1024     # all photos together: stop adding past this (the account's room is limited)


def key_for(lot_uuid, data):
    return f"{lot_uuid}/{hashlib.sha1(data).hexdigest()[:20]}"


def sync_photos(conn, backend):
    """conn: the open collection (with the 'u' tables).  -> {'up': n, 'down': n, 'removed': n, 'skipped_big': n}"""
    stats = {"up": 0, "down": 0, "removed": 0, "skipped_big": 0}
    if not hasattr(backend, "list_docs"):
        return stats
    remote = backend.list_docs()                                            # {document name: size}
    have = {n[len("photos/"):] for n in remote if n.startswith("photos/")}
    gone_remote = {n[len("photodel/"):] for n in remote if n.startswith("photodel/")}
    gone_local = {r[0] for r in conn.execute("SELECT key FROM u.photo_deleted")}
    local = {}
    for pid, lot, side, data in conn.execute("SELECT id, lot_uuid, side, data FROM u.lot_photos"):
        if data:
            local[key_for(lot, data)] = (pid, lot, side or "other", data)
    # 1. a photo deleted on another device goes here too
    for k in gone_remote:
        if k in local:
            conn.execute("DELETE FROM u.lot_photos WHERE id=?", (local.pop(k)[0],))
            stats["removed"] += 1
        conn.execute("INSERT OR IGNORE INTO u.photo_deleted VALUES(?,datetime('now'))", (k,))
        gone_local.add(k)
    # 2. a photo deleted here is announced
    for k in gone_local - gone_remote:
        backend.write(f"photodel/{k}", b"x", None)
    # 3. new photos go up
    used = sum(size for n, size in remote.items() if n.startswith("photos/"))
    for k, (pid, lot, side, data) in local.items():
        if k in have or k in gone_local:
            continue
        if len(data) > MAX_PHOTO or used + len(data) > ACCOUNT_BUDGET:
            stats["skipped_big"] += 1
            continue
        backend.write(f"photos/{k}", side.encode() + b"\n" + data, None)
        used += len(data)
        stats["up"] += 1
    # 4. photos from other devices come down (for copies this device has)
    lots = {r[0] for r in conn.execute("SELECT uuid FROM u.lots WHERE deleted=0")} | {r[0] for r in conn.execute("SELECT uuid FROM u.sealed WHERE deleted=0")}          # (a photo belongs to a card copy or to a sealed purchase)
    try:
        lots |= {r[0] for r in conn.execute("SELECT uuid FROM u.custom_items WHERE deleted=0")}          # (the picture of one of your own items)
    except Exception:  # noqa: BLE001 - a collection from before your own items
        pass
    for k in sorted(have):
        lot = k.split("/")[0]
        if k in local or k in gone_local or lot not in lots:
            continue
        raw, _ = backend.read(f"photos/{k}")
        if not raw or b"\n" not in raw:
            continue
        side, data = raw.split(b"\n", 1)
        conn.execute("INSERT INTO u.lot_photos(lot_uuid, side, data, added) VALUES(?,?,?,datetime('now'))", (lot, side.decode("ascii", "ignore") or "other", data))
        stats["down"] += 1
    conn.commit()
    return stats
