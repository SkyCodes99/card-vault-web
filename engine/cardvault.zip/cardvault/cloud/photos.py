"""Photos of your copies travel with the account too: one small encrypted document per photo (named after the copy and a fingerprint of the picture, so the
same photo is never stored twice), and a tiny 'removed' marker when you delete one so it doesn't come back from another device."""
import hashlib

from .backend import BackendError
from .. import photolimit
from . import photoorder

MAX_PHOTO = 600_000                    # a photo is already shrunk to a few hundred KB; anything bigger stays on this device
ACCOUNT_BUDGET = 8 * 1024 ** 3         # all photos together: only a safety net - photos are limited by their number (photolimit.py)


def key_for(lot_uuid, data):
    return f"{lot_uuid}/{hashlib.sha1(data).hexdigest()[:20]}"


def revive(conn, lot_uuid, data):
    """A photo is stored (again) on this device: a 'removed' marker for the very same picture would make the next sync delete it again, so the marker goes and the
    account is told the photo is back (3.50.132: deleting a photo and adding the identical one again lost it at the next sync).  Call after every local insert."""
    k = key_for(lot_uuid, data)
    if conn.execute("DELETE FROM u.photo_deleted WHERE key=?", (k,)).rowcount:
        conn.execute("CREATE TABLE IF NOT EXISTS u.photo_revived(key TEXT PRIMARY KEY, at TEXT)")
        conn.execute("INSERT OR REPLACE INTO u.photo_revived VALUES(?,datetime('now'))", (k,))


def _revived(conn):
    try:
        return dict(conn.execute("SELECT key, at FROM u.photo_revived"))
    except Exception:  # noqa: BLE001 - a collection from before photos could come back
        return {}


def sync_photos(conn, backend, limit=None, progress=None):
    """conn: the open collection (with the 'u' tables).  limit: how many photos the account may hold (photolimit.limit_for).
    -> {'up': n, 'down': n, 'removed': n, 'skipped_big': n, 'skipped_limit': n (kept on this device, not uploaded: the account is at its photo limit)}
    progress(done, total): photos to send + photos to receive, counted as each one is dealt with (the sync's progress bar)."""
    stats = {"up": 0, "down": 0, "removed": 0, "skipped_big": 0, "skipped_limit": 0}
    limit = limit or photolimit.limit_for()
    if not hasattr(backend, "list_docs"):
        return stats
    remote = backend.list_docs()                                            # {document name: size}
    have = {n[len("photos/"):] for n in remote if n.startswith("photos/")}
    gone_remote = {n[len("photodel/"):] for n in remote if n.startswith("photodel/")}
    back_remote = {n[len("photoback/"):] for n in remote if n.startswith("photoback/")}
    gone_local = dict(conn.execute("SELECT key, COALESCE(at, '') FROM u.photo_deleted"))          # {key: when this device deleted it ('' = only heard of it from the account)}
    # 0. a photo added here again after it was deleted: its 'removed' marker leaves the account and a 'back' marker (with the time) tells the other devices
    for k, at in _revived(conn).items():
        if k in gone_remote and hasattr(backend, "delete"):
            backend.delete(f"photodel/{k}")
        backend.write(f"photoback/{k}", (at or "").encode(), None)
        gone_remote.discard(k)
        back_remote.add(k)
        gone_local.pop(k, None)
        conn.execute("DELETE FROM u.photo_revived WHERE key=?", (k,))
    # 0b. a removal this device knows of that is older than the photo coming back on another device: the photo is back here too (downloaded in step 4)
    for k in (set(gone_local) & back_remote) - gone_remote:
        raw, _ = backend.read(f"photoback/{k}")
        back_at = (raw or b"").decode("ascii", "ignore")
        if gone_local[k] < back_at:                                        # (later one wins; the same second: the removal)
            conn.execute("DELETE FROM u.photo_deleted WHERE key=?", (k,))
            del gone_local[k]
    gone_local = set(gone_local)
    local = {}
    for pid, lot, side, data in conn.execute("SELECT id, lot_uuid, side, data FROM u.lot_photos"):
        if data:
            local[key_for(lot, data)] = (pid, lot, side or "other", data)
    # 1. a photo deleted on another device goes here too
    for k in gone_remote:
        if k in local:
            conn.execute("DELETE FROM u.lot_photos WHERE id=?", (local.pop(k)[0],))
            stats["removed"] += 1
        conn.execute("INSERT OR IGNORE INTO u.photo_deleted VALUES(?,'')", (k,))          # ('' = heard from the account: a later 'back' marker always wins over it)
        gone_local.add(k)
    # 2. a photo deleted here is announced - and its copy leaves the account, so the place it took counts again toward the photo limit
    for k in gone_local - gone_remote:
        backend.write(f"photodel/{k}", b"x", None)
        if k in back_remote and hasattr(backend, "delete"):                  # (deleted again after it came back: the old 'back' marker must not revive it elsewhere)
            backend.delete(f"photoback/{k}")
    if hasattr(backend, "delete"):
        for k in gone_local & have:
            backend.delete(f"photos/{k}")
        have -= gone_local
    # 3. new photos go up
    lots = {r[0] for r in conn.execute("SELECT uuid FROM u.lots WHERE deleted=0")} | {r[0] for r in conn.execute("SELECT uuid FROM u.sealed WHERE deleted=0")}          # (a photo belongs to a card copy or to a sealed purchase)
    try:
        lots |= {r[0] for r in conn.execute("SELECT uuid FROM u.custom_items WHERE deleted=0")}          # (the picture of one of your own items)
    except Exception:  # noqa: BLE001 - a collection from before your own items
        pass
    ups = [k for k in local if k not in have and k not in gone_local]
    downs = [k for k in sorted(have) if k not in local and k not in gone_local and k.split("/")[0] in lots]
    total, moved = len(ups) + len(downs), [0]
    def step():
        moved[0] += 1
        if progress:
            progress(moved[0], total)
    if progress and total:
        progress(0, total)
    used = sum(size for n, size in remote.items() if n.startswith("photos/"))
    stored = len(have - gone_local)                                          # photos the account holds now
    full = False
    for k, (pid, lot, side, data) in local.items():
        if k in have or k in gone_local:
            continue
        step()
        if len(data) > MAX_PHOTO or used + len(data) > ACCOUNT_BUDGET:
            stats["skipped_big"] += 1
            continue
        if full or stored >= limit:                                          # the account is at its photo limit: this one stays on this device, nothing is removed anywhere
            stats["skipped_limit"] += 1
            continue
        try:
            backend.write(f"photos/{k}", side.encode() + b"\n" + data, None)
        except BackendError as e:
            if photolimit.MARKER not in str(e):
                raise
            full = True                                                      # (the server is the authority: it may count differently, e.g. photos from another device not listed yet)
            stats["skipped_limit"] += 1
            continue
        used += len(data)
        stored += 1
        stats["up"] += 1
    # 4. photos from other devices come down (for copies this device has; `lots` above)
    for k in downs:
        lot = k.split("/")[0]
        step()
        raw, _ = backend.read(f"photos/{k}")
        if not raw or b"\n" not in raw:
            continue
        side, data = raw.split(b"\n", 1)
        conn.execute("INSERT INTO u.lot_photos(lot_uuid, side, data, added) VALUES(?,?,?,datetime('now'))", (lot, side.decode("ascii", "ignore") or "other", data))
        stats["down"] += 1
    photoorder.sync(conn, backend, remote, have)                              # 5. which photo is the cover travels too (cardvault/cloud/photoorder.py)
    conn.commit()
    return stats
