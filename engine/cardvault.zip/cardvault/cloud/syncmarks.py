"""What the last sync of each game left behind, so a sync only touches the games that really changed.

A sync used to read, merge and rewrite EVERY game's document each time - seconds per game for a big collection, and in the browser all of that happens while the whole app is frozen.
Now each game remembers two facts from the last sync that finished: the version of its document in the account, and a fingerprint of what this device holds for it.  When neither has moved
there is nothing to fetch and nothing to send for that game, and it is skipped without even opening it."""
import hashlib
import json
import sqlite3

LOCAL_USER = "local"

# What travels in a snapshot (see snapshot.export_snapshot): (table, belongs to one game?, the column that says when a row last changed, more columns whose total tells an edit that forgot to touch it)
_TABLES = (
    ("lots", True, "COALESCE(updated_at, added, '')", ("deleted", "qty")),
    ("wishlist", True, "COALESCE(added, '')", ("LENGTH(COALESCE(note, ''))",)),
    ("checklists", True, "COALESCE(updated_at, created_at, '')", ("deleted",)),
    ("custom_groups", True, "COALESCE(updated_at, created_at, '')", ("deleted",)),
    ("card_tags", True, "COALESCE(updated_at, '')", ("LENGTH(COALESCE(value, ''))",)),
    ("tombstones", True, "COALESCE(deleted_at, '')", ()),
    ("trades", True, "COALESCE(updated_at, ts, '')", ("deleted",)),
    ("sealed", True, "COALESCE(updated_at, '')", ("deleted", "qty")),
    ("dream_binders", True, "COALESCE(updated_at, '')", ("deleted",)),
    ("spending", True, "COALESCE(updated_at, '')", ("deleted",)),
    ("grading", True, "COALESCE(updated_at, '')", ("deleted",)),
    ("sold", True, "COALESCE(updated_at, '')", ("deleted", "qty")),
    ("custom_items", True, "COALESCE(updated_at, '')", ("deleted", "LENGTH(COALESCE(pic, ''))")),
    ("shares", True, "COALESCE(updated_at, created_at, '')", ("revoked",)),
    ("snapshots", True, "COALESCE(ts, day, '')", ()),
    ("portfolios", False, "COALESCE(updated_at, created_at, '')", ("deleted",)),          # (shared by every game of the account)
)
_CHECKLIST_PARTS = ("checklist_items", "checklist_picks")                                  # (they hang off a checklist and travel with it)


def _sql(table, per_game, when, extra):
    sums = "".join(f", COALESCE(SUM({c}), 0)" for c in extra)
    return f"SELECT COUNT(*), COALESCE(MAX({when}), ''){sums} FROM {table} WHERE user_id=?" + (" AND game=?" if per_game else "")


def local_stamp(user_path, game, user=LOCAL_USER):
    """A short fingerprint of everything this device holds for one game that a sync would carry (None when it cannot be worked out: then the game is simply synced).
    Every edit changes a row's last-changed time (that is how merging picks the newer copy), so any edit - or anything arriving from another device - changes this."""
    try:
        conn = sqlite3.connect(user_path, timeout=5)
        conn.execute("PRAGMA query_only=ON")                                     # (this only ever reads)
    except sqlite3.Error:
        return None
    try:
        parts = []
        for table, per_game, when, extra in _TABLES:
            args = (user, game) if per_game else (user,)
            parts.append(conn.execute(_sql(table, per_game, when, extra), args).fetchone())
        for table in _CHECKLIST_PARTS:
            parts.append(conn.execute(f"SELECT COUNT(*) FROM {table} WHERE checklist_id IN (SELECT id FROM checklists WHERE user_id=? AND game=?)", (user, game)).fetchone())
        parts.append(conn.execute("SELECT value FROM settings WHERE user_id=? AND game='*' AND key='look'", (user,)).fetchone())          # (the chosen look travels with every game)
        parts.append(conn.execute("SELECT value FROM settings WHERE user_id=? AND game=? AND key='set_goals'", (user, game)).fetchone())      # (so do the goals picked for sets)
        here = conn.execute("SELECT value FROM settings WHERE user_id=? AND game='*' AND key='here'", (user,)).fetchone()
        if here and '"game": %s' % json.dumps(game) in here[0]:
            parts.append(here)                                                   # "where I was" goes out with the game it is in (not every game: moving between pages would resend them all)
    except sqlite3.Error:
        return None
    finally:
        conn.close()
    return hashlib.sha1(repr(parts).encode("utf-8", "replace")).hexdigest()[:20]


class Marks:
    """The per-game memory of one account on this device: {game: [document version, local stamp]} (kept in the device's settings, so it survives a restart)."""

    def __init__(self, store):
        self.store = store

    def unchanged(self, game, version, stamp):
        """True when the account's copy is still the version we last synced AND this device's data for the game is still what it was then."""
        return bool(version) and bool(stamp) and self.store.get(game) == [str(version), stamp]

    def keep(self, game, version, stamp):
        if version and stamp:
            self.store[game] = [str(version), stamp]
        else:
            self.store.pop(game, None)

    def forget(self, game=None):
        if game is None:
            self.store.clear()
        else:
            self.store.pop(game, None)


KEEP_ACCOUNTS = 3


def account_key(account):
    """Who the marks belong to: this server + this sign-in (a hash of its token: a new sign-in, or another account, starts with no marks)."""
    return hashlib.sha1(f"{account.base}|{account.token}".encode("utf-8", "replace")).hexdigest()[:16]


def for_account(cfg, account):
    """The marks of this signed-in account.  Only the few most recent accounts are remembered."""
    key, every = account_key(account), cfg.setdefault("_sync_marks", {})
    store = every.pop(key, {})
    every[key] = store                                                      # (most recently used last)
    while len(every) > KEEP_ACCOUNTS:
        every.pop(next(iter(every)))
    return Marks(store)
