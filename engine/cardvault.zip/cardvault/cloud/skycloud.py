"""Client for the app's own cloud account server ("Sky Cloud", protocol v1).  Everything secret is derived ON THIS DEVICE: the server only ever receives a login proof
and ciphertext, so it can neither read the collection nor learn the password.  Same code runs in the desktop engine and in the browser build.

The derivation is frozen (tests/skycloud_vectors.json): any change to it is a new protocol version, never an edit.
    master = PBKDF2-SHA256(NFKC(password), "skycloud/v1/<service>/<email>", 600000, 32)   auth_key / wrap_key = HKDF-SHA256(master, info)
    dek    = 32 random bytes made once at registration;  doc_key = HKDF(dek, "skycloud/v1/docs");  blobs = base64(nonce12 || AES-256-GCM(doc_key, nonce12, data, aad=name))
"""
import base64
import hashlib
import json
import os
import re
import secrets
import time
import unicodedata
import urllib.parse

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from ..steps import Await, Pause, run as run_steps
from .backend import BackendError, Conflict, SyncBackend

SERVICE = "collect"
ITERATIONS = 600_000
PATIENCE = 20 if __import__("cardvault.runtime", fromlist=["x"]).IN_BROWSER else 120          # seconds a background sync keeps retrying a briefly unavailable server (short in the browser, where waiting freezes the page)
DEFAULT_URL = os.environ.get("CEA_CLOUD_URL", "https://gottacollectemall.online")       # the app's own address; set once the server is deployed (or per device in Settings > Account)
b64 = lambda b: base64.b64encode(b).decode("ascii")
unb64 = lambda s: base64.b64decode(s.encode("ascii"), validate=True)


class CloudError(Exception):
    def __init__(self, message, status=0, extra=None):
        super().__init__(message)
        self.status, self.extra = status, extra or {}


# ------------------------------------------------------------------------------------------------ the derivation (frozen)
def hkdf(key, info, length=32):
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=None, info=info.encode()).derive(key)


def seal(key, plaintext, aad, nonce=None):
    nonce = nonce or secrets.token_bytes(12)
    return b64(nonce + AESGCM(key).encrypt(nonce, plaintext, aad))


def unseal(key, blob, aad):
    raw = unb64(blob)
    return AESGCM(key).decrypt(raw[:12], raw[12:], aad)


SITE_BASE = ""          # the browser build: the address the page was loaded from (set by webapi/inline.boot) - where its service worker answers /__pbkdf2


def _pbkdf2_in_browser(password, salt, iterations):
    """Signing in used to take many seconds in the browser: 600,000 rounds of PBKDF2 inside WebAssembly (~30x slower than the browser's own crypto).  The page's service worker
    does the same maths with the browser's NATIVE WebCrypto and answers a synchronous request from here (a worker may block on one).  Same bytes out; None if anything is off,
    and the caller falls back to the slow-but-sure way."""
    if not SITE_BASE:
        return None
    try:
        from js import XMLHttpRequest  # noqa: PLC0415 - only exists in the browser
        x = XMLHttpRequest.new()
        x.open("POST", SITE_BASE.rstrip("/") + "/__pbkdf2", False)
        x.setRequestHeader("Content-Type", "application/json")
        x.send(json.dumps({"pw": b64(password), "salt": b64(salt), "iter": int(iterations)}))
        if int(x.status) != 200:
            return None
        j = json.loads(str(x.responseText))
        if not j.get("ok"):
            return None
        out = unb64(j["key"])
        return out if len(out) == 32 else None
    except Exception:  # noqa: BLE001 - not controlled by the service worker yet, blocked, offline: use the built-in way
        return None


def _pbkdf2(password, salt, iterations):
    if __import__("cardvault.runtime", fromlist=["x"]).IN_BROWSER:
        fast = _pbkdf2_in_browser(password, salt, iterations)
        if fast is not None:
            return fast
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations).derive(password)


def derive(email, password, iterations=ITERATIONS, service=SERVICE, lsalt=None):
    """-> (auth_key, wrap_key).
    v1 (older accounts): the PBKDF2 salt is "skycloud/v1/<service>/<email>".
    v2 (accounts that can also sign in by username): the salt is "skycloud/v2/<service>/<lsalt>", lsalt = the account's random login salt exactly as text.
    Everything after PBKDF2 is the same for both."""
    salt = f"skycloud/v2/{service}/{lsalt}" if lsalt else f"skycloud/v1/{service}/{(email or '').strip().lower()}"
    # the cryptography library's PBKDF2 (same result as hashlib.pbkdf2_hmac, and present in the browser build where hashlib has none)
    master = _pbkdf2(unicodedata.normalize("NFKC", password).encode(), salt.encode(), iterations)
    return hkdf(master, "skycloud/v1/auth"), hkdf(master, "skycloud/v1/wrap")


def recovery_keys(rk):
    return hkdf(rk, "skycloud/v1/rec-auth"), hkdf(rk, "skycloud/v1/rec-wrap")


def format_recovery_key(rk):
    s = base64.b32encode(rk).decode().rstrip("=")
    return "-".join(s[i:i + 4] for i in range(0, len(s), 4))


def parse_recovery_key(text):
    s = "".join(ch for ch in (text or "").upper() if ch.isalnum())
    try:
        rk = base64.b32decode(s + "=" * (-len(s) % 8))
    except ValueError:
        raise CloudError("That recovery key isn't valid.")
    if len(rk) != 20:
        raise CloudError("That recovery key isn't valid.")
    return rk


def doc_key(dek):
    return hkdf(dek, "skycloud/v1/docs")


def new_lsalt():
    return b64(secrets.token_bytes(16))


def registration(email, password, device="", iterations=ITERATIONS, lsalt=None):
    """-> (request body for POST /v1/register, dek, recovery key bytes).  With an lsalt the account is v2 (it can sign in by username)."""
    auth, wrap = derive(email, password, iterations, lsalt=lsalt)
    dek, rk = secrets.token_bytes(32), secrets.token_bytes(20)
    rauth, rwrap = recovery_keys(rk)
    body = {"email": email.strip().lower(), "auth_key": b64(auth), "recovery_auth": b64(rauth), "device": device,
            "dek_wrapped": seal(wrap, dek, b"skycloud/v1/dek"), "rec_wrapped": seal(rwrap, dek, b"skycloud/v1/dek")}
    if lsalt:
        body["lsalt"] = lsalt
    return body, dek, rk


# ------------------------------------------------------------------------------------------------ talking to the server
class Request(Await):
    """One question to the account server, as a step of a job (see steps.py): the desktop asks it on the spot, the browser build hands it to the page, which asks it with fetch()
    while the engine keeps answering clicks (a whole collection's upload used to freeze every screen for seconds)."""

    def __init__(self, method, url, body=None, token=None, timeout=30):
        self.method, self.url, self.token, self.timeout, self.payload = method, url, token, timeout, body

    @property
    def body(self):
        """The request body as the page sends it (JSON text), or None."""
        return json.dumps(self.payload, separators=(",", ":")) if self.payload is not None else None

    def now(self):
        return _http(self.method, self.url, self.payload, self.token, self.timeout)

    def headers(self):
        h = {"Content-Type": "application/json"}
        if self.token:
            h["Authorization"] = "Bearer " + self.token
        return h

    @staticmethod
    def answer(status, text, error=""):
        """What the page's fetch() came back with -> (status, data) as now() gives it, or the same CloudError."""
        if error:
            why = "the server took too long to answer" if error == "timeout" else "the connection was refused or dropped"
            raise CloudError(f"Couldn't connect ({why}). Check your internet connection - we'll keep trying.")
        try:
            data = json.loads(text) if text else {}
        except ValueError:
            data = {}
        return int(status), data if isinstance(data, dict) else {}


def _http(method, url, body=None, token=None, timeout=30):
    import requests
    headers = {"Content-Type": "application/json", "User-Agent": "CollectEmAll/3 (account)"}
    if token:
        headers["Authorization"] = "Bearer " + token
    try:
        r = requests.request(method, url, data=json.dumps(body) if body is not None else None, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        import requests as _rq
        why = ("the server took too long to answer" if isinstance(e, _rq.Timeout) else "a secure-connection (certificate or clock) problem" if isinstance(e, _rq.exceptions.SSLError)
               else "the server's address couldn't be found" if "getaddrinfo" in str(e) or "Name or service" in str(e) else "the connection was refused or dropped")
        raise CloudError(f"Couldn't connect ({why}). Check your internet connection - we'll keep trying.") from e
    try:
        data = r.json() if r.content else {}
    except ValueError:
        data = {}
    return r.status_code, data


USERNAME_RE = re.compile(r"[a-z0-9][a-z0-9._-]{2,23}")


def display_username(u):
    """-> the username as the person typed it (capitals kept - it is also their display name), or "" if it isn't valid.  Matching is case-insensitive."""
    u = (u or "").strip()
    return u if USERNAME_RE.fullmatch(u.lower()) else ""


def clean_username(u):
    """-> the username in its stored form (lower case), or "" if it isn't a valid one."""
    u = (u or "").strip().lower()
    return u if USERNAME_RE.fullmatch(u) else ""


class Account:
    """One signed-in (or signing-in) person on one device."""

    WRONG = "Wrong email, username or password."          # the same words for an unknown name and a wrong password: nothing about who exists is revealed

    def __init__(self, base, token=None, dek=None, email="", lsalt=""):
        self.base, self.token, self.dek, self.email = (base or "").rstrip("/"), token, dek, email
        self.lsalt, self.username = lsalt or "", ""

    def call(self, method, path, body=None, timeout=30, patient=False):
        """patient=True (background sync): a server that is briefly unavailable (a deploy: 502/503/504, reset connection) is retried quietly for up to ~2 minutes
        before giving up, so nobody sees an error for an update that takes seconds.  Interactive calls (sign-in) fail straight away."""
        return run_steps(self.call_steps(method, path, body, timeout, patient))

    def call_steps(self, method, path, body=None, timeout=30, patient=False):
        """call() as a step of a job: it yields the request (and any pause before a retry) instead of waiting for it - see Request."""
        if not self.base:
            raise CloudError("Accounts aren't available right now.")
        deadline, delay = time.time() + (PATIENCE if patient else 0), 1.0
        req = Request(method, self.base + path, body, self.token, timeout)
        while True:
            try:
                st, out = yield req
                busy = st in (502, 503, 504)
            except CloudError:
                if time.time() + delay > deadline:
                    raise
                st, out, busy = 0, {}, True
            if not busy or time.time() + delay > deadline:
                break
            yield Pause(delay)
            delay = min(delay * 2, 15.0)
        if st == 0:
            raise CloudError("Couldn't connect. Check your internet connection - we'll keep trying.")
        if st >= 400:
            raise CloudError(out.get("error") or "Something went wrong on our side. Please try again in a moment.", st, out)
        return out

    def health(self):
        return self.call("GET", "/v1/health")

    def prelogin(self, identifier):
        """-> {"kdf": 1} or {"kdf": 2, "salt": ...} for an email or a username (never contains an email).  None if this server doesn't have it yet."""
        return run_steps(self.prelogin_steps(identifier))

    def prelogin_steps(self, identifier):
        try:
            return (yield from self.call_steps("POST", "/v1/prelogin", {"identifier": identifier.strip().lower()}))
        except CloudError as e:
            if e.status in (404, 405):
                return None
            raise

    def supports_usernames(self):
        if getattr(self, "_v2", None) is None:
            self._v2 = self.prelogin("probe@example.invalid") is not None
        return self._v2

    def register(self, email, password, device="", username="", remember=None):
        """-> the recovery key (show it once; it is the only way back in after a forgotten password).  New accounts get a random login salt so they can sign in by username too."""
        ls = new_lsalt() if self.supports_usernames() else None
        body, dek, rk = registration(email, password, device, lsalt=ls)
        if username:
            body["username"] = display_username(username)
        if remember is not None:
            body["remember"] = bool(remember)
        out = self.call("POST", "/v1/register", body)
        self.token, self.dek, self.email, self.lsalt = out["token"], dek, body["email"], ls or ""
        self.username = out.get("username") or body.get("username", "")
        self.admin = bool(out.get("admin"))
        return format_recovery_key(rk)

    def login(self, identifier, password, device="", totp="", remember=None):
        """identifier = email OR username.  An older account that signs in with its email is moved to the username-capable scheme right after."""
        return run_steps(self.login_steps(identifier, password, device, totp, remember))

    def login_steps(self, identifier, password, device="", totp="", remember=None):
        """login() as steps of a job (its questions are yielded: the browser's page sends them) - used to sign in to the account with the password that just unlocked this device."""
        ident = (identifier or "").strip().lower()
        pre = yield from self.prelogin_steps(ident)
        if pre is None:                                   # a server without usernames yet: the old way (email only)
            if "@" not in ident:
                raise CloudError("Signing in with a username isn't available yet - use your email address.", 404)
            pre = {"kdf": 1}
        ls = pre.get("salt") if pre.get("kdf") == 2 else None
        auth, wrap = derive(ident, password, lsalt=ls)
        body = {"identifier": ident, "auth_key": b64(auth), "device": device}
        if totp:
            body["totp"] = totp
        if remember is not None:
            body["remember"] = bool(remember)
        try:
            out = yield from self.call_steps("POST", "/v1/login", body)
        except CloudError as e:
            if e.status == 401 and not e.extra.get("need_totp"):
                raise CloudError(self.WRONG, 401, e.extra)
            raise
        self.token, self.username = out["token"], out.get("username") or ""
        self.admin = bool(out.get("admin"))
        self.email = ident if "@" in ident else (self.email or "")
        self.lsalt = out.get("lsalt") or ls or ""
        try:
            self.dek = unseal(wrap, out["dek_wrapped"], b"skycloud/v1/dek")
        except Exception:  # noqa: BLE001
            raise CloudError(self.WRONG, 401)
        if out.get("kdf") == 1 and "@" in ident:
            try:
                yield from self.upgrade_kdf_steps(ident, password, auth)
            except CloudError:
                pass                                       # not fatal: it is tried again at the next sign-in
        return out

    def upgrade_kdf(self, email, password, old_auth=None):
        """Move an older account to a random login salt (same password, same data key; other signed-in devices stay signed in)."""
        return run_steps(self.upgrade_kdf_steps(email, password, old_auth))

    def upgrade_kdf_steps(self, email, password, old_auth=None):
        old_auth = old_auth or derive(email, password)[0]
        ls = new_lsalt()
        new_auth, new_wrap = derive(email, password, lsalt=ls)
        out = yield from self.call_steps("POST", "/v1/kdf-upgrade", {"old_auth_key": b64(old_auth), "new_auth_key": b64(new_auth), "lsalt": ls, "dek_wrapped": seal(new_wrap, self.dek, b"skycloud/v1/dek")})
        if out.get("upgraded"):
            self.lsalt = ls
        return bool(out.get("upgraded"))

    def set_username(self, username):
        u = display_username(username)
        if not u:
            raise CloudError("A username is 3-24 letters, numbers, dots, dashes or underscores.")
        try:
            out = self.call("POST", "/v1/username", {"username": u})
        except CloudError as e:
            if e.status in (404, 405):
                raise CloudError("Usernames aren't available yet - please try again soon.", e.status)
            raise
        self.username = out.get("username") or u
        return self.username

    # ---- two-step sign-in (a 6-digit code from an authenticator app)
    def twofa_setup(self):
        """-> {"secret": the key to type in by hand, "uri": the otpauth:// link a QR code carries}.  Not active until twofa_enable() is given a correct code."""
        return self.call("POST", "/v1/2fa/setup", {})

    def twofa_enable(self, code):
        self.call("POST", "/v1/2fa/enable", {"code": str(code or "").strip()})

    def twofa_disable(self, email, password, code=""):
        auth, _ = derive(email, password, lsalt=self.lsalt or None)
        self.call("POST", "/v1/2fa/disable", {"auth_key": b64(auth), "code": str(code or "").strip()})

    def delete_now(self, identifier, password, code=""):
        """Erase this account, its documents and its username immediately (the server also offers a grace-period delete without now=True)."""
        auth, _ = derive(identifier, password, lsalt=self.lsalt or None)
        body = {"auth_key": b64(auth), "now": True}
        if code:
            body["code"] = str(code).strip()
        return self.call("POST", "/v1/delete-account", body)

    def schedule_delete(self, identifier, password):
        """The server's grace-period delete: nothing is removed until the restore window ends.  -> {delete_at: epoch seconds}"""
        auth, _ = derive(identifier, password, lsalt=self.lsalt or None)
        return self.call("POST", "/v1/delete-account", {"auth_key": b64(auth)})

    def restore_account(self, identifier, password):
        """Cancel a scheduled deletion (inside the restore window)."""
        auth, _ = derive(identifier, password, lsalt=self.lsalt or None)
        return self.call("POST", "/v1/restore-account", {"auth_key": b64(auth)})

    def username_available(self, name):
        """-> (available, reason)"""
        u = clean_username(name)
        if not u:
            return False, "3-24 letters, numbers, dots, dashes or underscores."
        try:
            out = self.call("GET", "/v1/username/available?name=" + urllib.parse.quote(u))
        except CloudError as e:
            if e.status in (404, 405):
                return True, ""
            raise
        return bool(out.get("available")), out.get("reason") or ""

    def logout(self):
        try:
            self.call("POST", "/v1/logout", {})
        except CloudError:
            pass
        self.token = None

    def change_password(self, email, old_password, new_password):
        old_auth, _ = derive(email, old_password, lsalt=self.lsalt or None)
        ls = self.lsalt or (new_lsalt() if self.supports_usernames() else "")          # an older account becomes username-capable here
        new_auth, new_wrap = derive(email, new_password, lsalt=ls or None)
        self.call("POST", "/v1/password", {"old_auth_key": b64(old_auth), "new_auth_key": b64(new_auth), "dek_wrapped": seal(new_wrap, self.dek, b"skycloud/v1/dek"), **({"lsalt": ls} if ls else {})})
        self.lsalt = ls

    def _salt_for(self, email):
        """The login salt a new password should be derived with: the account's own (from prelogin), or a fresh one (an older account becomes username-capable); None on a server without usernames."""
        pre = self.prelogin(email)
        if pre is None:
            return None
        return pre.get("salt") if pre.get("kdf") == 2 else new_lsalt()

    def recover(self, email, recovery_key, new_password, device="", remember=None):
        """Forgot the password, still have the recovery key: opens the data key with it and sets a new password (the data is kept)."""
        rk = parse_recovery_key(recovery_key)
        rauth, rwrap = recovery_keys(rk)
        first = self.call("POST", "/v1/recover", {"email": email.strip().lower(), "recovery_auth": b64(rauth)})
        try:
            dek = unseal(rwrap, first["rec_wrapped"], b"skycloud/v1/dek")
        except Exception:  # noqa: BLE001
            raise CloudError("That recovery key doesn't open this account.")
        ls = self._salt_for(email)
        new_auth, new_wrap = derive(email, new_password, lsalt=ls)
        body = {"email": email.strip().lower(), "recovery_auth": b64(rauth), "new_auth_key": b64(new_auth), "dek_wrapped": seal(new_wrap, dek, b"skycloud/v1/dek"), "device": device}
        if ls:
            body["lsalt"] = ls
        if remember is not None:
            body["remember"] = bool(remember)
        out = self.call("POST", "/v1/recover", body)
        self.token, self.dek, self.email, self.lsalt = out["token"], dek, email.strip().lower(), ls or ""

    def recover_with_totp(self, identifier, code, new_password, device="", remember=None):
        """Forgot the password and no recovery key, but 2-step sign-in is on: a valid code restores the ACCOUNT with a new password.  The server holds no key, so
        the old encrypted contents cannot be opened: the account gets a fresh empty vault and a NEW recovery key (returned, shown once).  Callers must warn first."""
        ident = identifier.strip().lower()
        pre = self.prelogin(ident) or {}
        ls = pre["salt"] if pre.get("kdf") == 2 else new_lsalt()
        auth, wrap = derive(ident, new_password, lsalt=ls)
        dek, rk = secrets.token_bytes(32), secrets.token_bytes(20)
        rauth, rwrap = recovery_keys(rk)
        body = {"identifier": ident, "code": str(code or "").strip(), "new_auth_key": b64(auth), "lsalt": ls, "device": device, "discard_data": True,
                "dek_wrapped": seal(wrap, dek, b"skycloud/v1/dek"), "recovery_auth": b64(rauth), "rec_wrapped": seal(rwrap, dek, b"skycloud/v1/dek")}
        if remember is not None:
            body["remember"] = bool(remember)
        out = self.call("POST", "/v1/recover/totp", body)
        self.token, self.dek, self.username, self.lsalt = out["token"], dek, out.get("username") or "", ls
        self.email = ident if "@" in ident else (self.email or "")
        self.admin = bool(out.get("admin"))
        return format_recovery_key(rk)

    def change_email(self, password, new_email, totp=""):
        """Step 1: the server emails a 6-digit code to the NEW address (needs the password, and the 2-step code when 2-step is on)."""
        me = self.me()
        ident = me.get("email") or self.email
        pre = self.prelogin(ident) or {}
        auth, _ = derive(ident, password, lsalt=pre.get("salt") if pre.get("kdf") == 2 else None)
        self.call("POST", "/v1/email/change", {"auth_key": b64(auth), "new_email": new_email.strip().lower(), **({"totp": str(totp).strip()} if totp else {})})

    def confirm_email(self, code):
        """Step 2: the emailed code; the address changes.  Sign-in keys do not depend on the email (v2 accounts), so nothing else changes."""
        out = self.call("POST", "/v1/email/confirm", {"code": str(code or "").strip()})
        self.email = out.get("email") or self.email
        return self.email

    def reset_request(self, email):
        self.call("POST", "/v1/reset/request", {"email": email.strip().lower()})

    def reset_confirm(self, email, code, new_password, keep=False, device="", remember=None):
        """After the emailed code: keep=True re-wraps the data key this device already holds; keep=False starts the account's data afresh."""
        ls = self._salt_for(email)
        new_auth, new_wrap = derive(email, new_password, lsalt=ls)
        body = {"email": email.strip().lower(), "code": code, "new_auth_key": b64(new_auth), "device": device}
        if ls:
            body["lsalt"] = ls
        if remember is not None:
            body["remember"] = bool(remember)
        recovery = None
        if keep and self.dek:
            body["dek_wrapped"] = seal(new_wrap, self.dek, b"skycloud/v1/dek")
            dek = self.dek
        else:
            dek, rk = secrets.token_bytes(32), secrets.token_bytes(20)
            rauth, rwrap = recovery_keys(rk)
            body.update(discard_data=True, dek_wrapped=seal(new_wrap, dek, b"skycloud/v1/dek"), rec_wrapped=seal(rwrap, dek, b"skycloud/v1/dek"), recovery_auth=b64(rauth))
            recovery = format_recovery_key(rk)
        out = self.call("POST", "/v1/reset/confirm", body)
        self.token, self.dek, self.email, self.lsalt = out["token"], dek, email.strip().lower(), ls or ""
        return recovery

    def devices(self):
        return self.call("GET", "/v1/devices")["devices"]

    def revoke(self, device_id):
        self.call("DELETE", "/v1/devices/" + device_id)

    def revoke_others(self):
        self.call("DELETE", "/v1/devices/others")

    def me(self, timeout=30):
        return self.call("GET", "/v1/me", timeout=timeout)

    def wait(self, fp="", timeout=25):
        """Long poll: returns {fp, changed} as soon as another device changed something (or after `timeout` seconds)."""
        return self.call("GET", f"/v1/wait?fp={urllib.parse.quote(fp)}&timeout={int(timeout)}", timeout=timeout + 10)

    def fingerprint(self):
        return self.call("GET", "/v1/docs", patient=True).get("fp", "")

    def docs_state(self):
        """(fingerprint, {document name: version}) in one question - used to tell whether another device saved something WHILE this device's sync was running."""
        out = self.call("GET", "/v1/docs", patient=True)
        return out.get("fp", ""), {urllib.parse.unquote(str(d.get("name"))): str(d.get("version")) for d in out.get("docs", [])}


# ------------------------------------------------------------------------------------------------ the sync backend
class SkyCloudBackend(SyncBackend):
    """The same read / write-with-version interface the GitHub backend has, over the account server's versioned documents."""
    name = "skycloud"
    _copies = {}                                          # (account, document) -> (version, contents): what this device last read or wrote - while the account still lists that version, nothing else
                                                          # has saved it since, so a sync does not download it again (a big game is megabytes, and in the browser every download holds up the screens)

    def __init__(self, account):
        if not (account.token and account.dek):
            raise BackendError("Not signed in to your account.")
        self.acct, self._key = account, doc_key(account.dek)
        self._who = hashlib.sha256(account.dek + str(account.token).encode()).hexdigest()[:16]        # (this account, signed in on this device)
        self.seen = {}                                    # document -> the version this sync last read or wrote (see cloudapi.start_sync: a version we did not see means another device saved meanwhile)
        self.listed = {}                                  # document -> the version the account listed at the start of this sync (see state()): lets read() use the copy above
        self.wrote = {}                                   # document -> size, for everything this backend saved
        self._sizes = None                                # document -> size from that same listing, so the photo step needs no second listing
        self._pending = {}                                # document -> its download already under way (prefetch)

    def state(self):
        """(fingerprint, {document name: version}) - one look at the account, remembered for the rest of this sync."""
        return run_steps(self.state_steps())

    def state_steps(self):
        out = yield from self.acct.call_steps("GET", "/v1/docs", patient=True)
        docs = out.get("docs", [])
        self.listed = {urllib.parse.unquote(str(d.get("name"))): str(d.get("version")) for d in docs}
        self._sizes = {d["name"]: d.get("size", 0) for d in docs}
        return out.get("fp", ""), dict(self.listed)

    def _keep(self, path, version, data):
        if len(data) <= 32 << 20:
            SkyCloudBackend._copies[(self._who, path)] = (version, data)

    @staticmethod
    def _name(path):
        return urllib.parse.quote(path, safe="/")

    PREFETCH = 6                                          # documents coming down side by side (the desktop's first sync of a big account: 40 games one round trip after another)

    def prefetch(self, paths):
        """The desktop: start downloading these documents now, several at a time, on threads of their own; read() then takes each one as soon as it is in (or asks itself if that
        download failed).  Only documents the listing at the start of this sync named, and only when the copy kept here is not already that version.  Nothing happens in the browser
        (its downloads are made by the page)."""
        from concurrent.futures import ThreadPoolExecutor
        todo = []
        for path in paths:
            name = urllib.parse.unquote(path)
            ver = self.listed.get(name)
            have = SkyCloudBackend._copies.get((self._who, name))
            if ver and not (have and have[0] == ver) and name not in self._pending:
                todo.append((path, name, ver))
        if len(todo) < 2:
            return 0
        pool = ThreadPoolExecutor(min(self.PREFETCH, len(todo)), thread_name_prefix="sync-get")
        for path, name, ver in todo:
            self._pending[name] = pool.submit(self._fetch, path, name, ver)
        pool.shutdown(wait=False)                         # (the downloads go on; the threads end with the last one)
        return len(todo)

    def _fetch(self, path, name, ver):
        out = self.acct.call("GET", "/v1/docs/" + self._name(path), patient=True)
        data, version = unseal(self._key, out["blob"], path.encode()), str(out["version"])
        if version == ver:
            self._keep(name, version, data)
        return version

    def read(self, path):
        return run_steps(self.read_steps(path))

    def read_steps(self, path):
        """read() as steps of a job: the download is handed out (see Request), so in the browser the screens keep answering while it comes in."""
        name = urllib.parse.unquote(path)
        fut = self._pending.pop(name, None)
        if fut is not None:                               # (prefetch: being downloaded already - wait for that one rather than asking a second time)
            try:
                fut.result(timeout=300)
            except Exception:  # noqa: BLE001 - it failed: asked again below, where the error is reported properly
                pass
        have = SkyCloudBackend._copies.get((self._who, name))
        if have and self.listed.get(name) == have[0]:
            self.seen[name] = have[0]
            return have[1], have[0]
        try:
            out = yield from self.acct.call_steps("GET", "/v1/docs/" + self._name(path), patient=True)
        except CloudError as e:
            if e.status == 404:
                return None, None
            if e.status == 401:
                raise BackendError("You were signed out of your account - sign in again.")
            raise BackendError(str(e))
        try:
            data, version = unseal(self._key, out["blob"], path.encode()), str(out["version"])
        except Exception:  # noqa: BLE001
            raise BackendError("A document in your account couldn't be opened (wrong key).")
        self.seen[name] = version
        self._keep(name, version, data)
        return data, version

    def write(self, path, data, etag, message="Update"):
        return run_steps(self.write_steps(path, data, etag, message))

    def write_steps(self, path, data, etag, message="Update"):
        """write() as steps of a job: the upload is handed out (see Request) - a big collection is megabytes, and the screens must not wait for it."""
        blob = seal(self._key, data, path.encode())
        yield                                                                        # (sealing a big collection is a step of its own)
        try:
            out = yield from self.acct.call_steps("PUT", "/v1/docs/" + self._name(path), {"blob": blob, "base_version": int(etag or 0)}, timeout=120, patient=True)
        except CloudError as e:
            if e.status == 409:
                raise Conflict(path)
            if e.status == 401:
                raise BackendError("You were signed out of your account - sign in again.")
            if e.status == 413 and str(e) == "photo limit":                   # (cloud/photos.py keeps the photo on this device and carries on)
                raise BackendError("photo limit")
            raise BackendError(str(e))
        name = urllib.parse.unquote(path)
        self.seen[name] = str(out["version"])
        self.wrote[path] = len(data)
        self._keep(name, self.seen[name], data)
        return self.seen[name]

    def delete(self, path):
        """Remove one document from the account (a photo you deleted: it must stop counting toward the photo limit).  A document that is already gone is fine."""
        return run_steps(self.delete_steps(path))

    def delete_steps(self, path):
        """delete() as steps of a job (the request is handed out in the browser - see Request)."""
        try:
            yield from self.acct.call_steps("DELETE", "/v1/docs/" + self._name(path), timeout=60, patient=True)
        except CloudError as e:
            if e.status not in (404,):
                raise BackendError(str(e))
        self.wrote.pop(path, None)
        if self._sizes is not None:
            self._sizes.pop(urllib.parse.unquote(path), None)

    def list_docs(self):
        """{document name: size} of everything in the account."""
        if self._sizes is not None:
            return {**self._sizes, **self.wrote}
        try:
            return {d["name"]: d.get("size", 0) for d in self.acct.call("GET", "/v1/docs", patient=True).get("docs", [])}
        except CloudError as e:
            raise BackendError(str(e))

    def describe(self):
        return f"cloud account {self.acct.email}"
