"""Client for the app's own cloud account server ("Sky Cloud", protocol v1).  Everything secret is derived ON THIS DEVICE: the server only ever receives a login proof
and ciphertext, so it can neither read the collection nor learn the password.  Same code runs in the desktop engine and in the browser build.

The derivation is frozen (tests/skycloud_vectors.json): any change to it is a new protocol version, never an edit.
    master = PBKDF2-SHA256(NFKC(password), "skycloud/v1/<service>/<email>", 600000, 32)   auth_key / wrap_key = HKDF-SHA256(master, info)
    dek    = 32 random bytes made once at registration;  doc_key = HKDF(dek, "skycloud/v1/docs");  blobs = base64(nonce12 || AES-256-GCM(doc_key, nonce12, data, aad=name))
"""
import base64
import json
import os
import secrets
import unicodedata
import urllib.parse

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from .backend import BackendError, Conflict, SyncBackend

SERVICE = "collect"
ITERATIONS = 600_000
DEFAULT_URL = os.environ.get("CEA_CLOUD_URL", "")       # the app's own address; set once the server is deployed (or per device in Settings > Account)
b64 = lambda b: base64.b64encode(b).decode("ascii")
unb64 = lambda s: base64.b64decode(s.encode("ascii"), validate=True)


class CloudError(Exception):
    def __init__(self, message, status=0, extra=None):
        super().__init__(message)
        self.status, self.extra = status, extra or {}


# ------------------------------------------------------------------------------------------------ the derivation (frozen)
def hkdf(key, info, length=32):
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=None, info=info.encode()).derive(key)


def seal(key, plaintext, aad, nonce=None):
    nonce = nonce or secrets.token_bytes(12)
    return b64(nonce + AESGCM(key).encrypt(nonce, plaintext, aad))


def unseal(key, blob, aad):
    raw = unb64(blob)
    return AESGCM(key).decrypt(raw[:12], raw[12:], aad)


def derive(email, password, iterations=ITERATIONS, service=SERVICE):
    """-> (auth_key, wrap_key)"""
    email = email.strip().lower()
    # the cryptography library's PBKDF2 (same result as hashlib.pbkdf2_hmac, and present in the browser build where hashlib has none)
    master = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=f"skycloud/v1/{service}/{email}".encode(), iterations=iterations).derive(unicodedata.normalize("NFKC", password).encode())
    return hkdf(master, "skycloud/v1/auth"), hkdf(master, "skycloud/v1/wrap")


def recovery_keys(rk):
    return hkdf(rk, "skycloud/v1/rec-auth"), hkdf(rk, "skycloud/v1/rec-wrap")


def format_recovery_key(rk):
    s = base64.b32encode(rk).decode().rstrip("=")
    return "-".join(s[i:i + 4] for i in range(0, len(s), 4))


def parse_recovery_key(text):
    s = "".join(ch for ch in (text or "").upper() if ch.isalnum())
    try:
        rk = base64.b32decode(s + "=" * (-len(s) % 8))
    except ValueError:
        raise CloudError("That recovery key isn't valid.")
    if len(rk) != 20:
        raise CloudError("That recovery key isn't valid.")
    return rk


def doc_key(dek):
    return hkdf(dek, "skycloud/v1/docs")


def registration(email, password, device="", iterations=ITERATIONS):
    """-> (request body for POST /v1/register, dek, recovery key bytes)"""
    auth, wrap = derive(email, password, iterations)
    dek, rk = secrets.token_bytes(32), secrets.token_bytes(20)
    rauth, rwrap = recovery_keys(rk)
    body = {"email": email.strip().lower(), "auth_key": b64(auth), "recovery_auth": b64(rauth), "device": device,
            "dek_wrapped": seal(wrap, dek, b"skycloud/v1/dek"), "rec_wrapped": seal(rwrap, dek, b"skycloud/v1/dek")}
    return body, dek, rk


# ------------------------------------------------------------------------------------------------ talking to the server
def _http(method, url, body=None, token=None, timeout=30):
    import requests
    headers = {"Content-Type": "application/json", "User-Agent": "CollectEmAll/3 (account)"}
    if token:
        headers["Authorization"] = "Bearer " + token
    try:
        r = requests.request(method, url, data=json.dumps(body) if body is not None else None, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        raise CloudError("Can't reach the account server. Check your connection.") from e
    try:
        data = r.json() if r.content else {}
    except ValueError:
        data = {}
    return r.status_code, data


class Account:
    """One signed-in (or signing-in) person on one device."""

    def __init__(self, base, token=None, dek=None, email=""):
        self.base, self.token, self.dek, self.email = (base or "").rstrip("/"), token, dek, email

    def call(self, method, path, body=None, timeout=30):
        if not self.base:
            raise CloudError("The account server address isn't set yet.")
        st, out = _http(method, self.base + path, body, self.token, timeout)
        if st >= 400:
            raise CloudError(out.get("error") or f"The account server answered {st}.", st, out)
        return out

    def health(self):
        return self.call("GET", "/v1/health")

    def register(self, email, password, device=""):
        """-> the recovery key (show it once; it is the only way back in after a forgotten password)."""
        body, dek, rk = registration(email, password, device)
        out = self.call("POST", "/v1/register", body)
        self.token, self.dek, self.email = out["token"], dek, body["email"]
        return format_recovery_key(rk)

    def login(self, email, password, device="", totp=""):
        auth, wrap = derive(email, password)
        out = self.call("POST", "/v1/login", {"email": email.strip().lower(), "auth_key": b64(auth), "device": device, **({"totp": totp} if totp else {})})
        self.token, self.email = out["token"], email.strip().lower()
        try:
            self.dek = unseal(wrap, out["dek_wrapped"], b"skycloud/v1/dek")
        except Exception:  # noqa: BLE001
            raise CloudError("The account data couldn't be opened with that password.")
        return out

    def logout(self):
        try:
            self.call("POST", "/v1/logout", {})
        except CloudError:
            pass
        self.token = None

    def change_password(self, email, old_password, new_password):
        old_auth, _ = derive(email, old_password)
        new_auth, new_wrap = derive(email, new_password)
        self.call("POST", "/v1/password", {"old_auth_key": b64(old_auth), "new_auth_key": b64(new_auth), "dek_wrapped": seal(new_wrap, self.dek, b"skycloud/v1/dek")})

    def recover(self, email, recovery_key, new_password, device=""):
        """Forgot the password, still have the recovery key: opens the data key with it and sets a new password (the data is kept)."""
        rk = parse_recovery_key(recovery_key)
        rauth, rwrap = recovery_keys(rk)
        first = self.call("POST", "/v1/recover", {"email": email.strip().lower(), "recovery_auth": b64(rauth)})
        try:
            dek = unseal(rwrap, first["rec_wrapped"], b"skycloud/v1/dek")
        except Exception:  # noqa: BLE001
            raise CloudError("That recovery key doesn't open this account.")
        new_auth, new_wrap = derive(email, new_password)
        out = self.call("POST", "/v1/recover", {"email": email.strip().lower(), "recovery_auth": b64(rauth), "new_auth_key": b64(new_auth),
                                               "dek_wrapped": seal(new_wrap, dek, b"skycloud/v1/dek"), "device": device})
        self.token, self.dek, self.email = out["token"], dek, email.strip().lower()

    def reset_request(self, email):
        self.call("POST", "/v1/reset/request", {"email": email.strip().lower()})

    def reset_confirm(self, email, code, new_password, keep=False, device=""):
        """After the emailed code: keep=True re-wraps the data key this device already holds; keep=False starts the account's data afresh."""
        new_auth, new_wrap = derive(email, new_password)
        body = {"email": email.strip().lower(), "code": code, "new_auth_key": b64(new_auth), "device": device}
        recovery = None
        if keep and self.dek:
            body["dek_wrapped"] = seal(new_wrap, self.dek, b"skycloud/v1/dek")
            dek = self.dek
        else:
            dek, rk = secrets.token_bytes(32), secrets.token_bytes(20)
            rauth, rwrap = recovery_keys(rk)
            body.update(discard_data=True, dek_wrapped=seal(new_wrap, dek, b"skycloud/v1/dek"), rec_wrapped=seal(rwrap, dek, b"skycloud/v1/dek"), recovery_auth=b64(rauth))
            recovery = format_recovery_key(rk)
        out = self.call("POST", "/v1/reset/confirm", body)
        self.token, self.dek, self.email = out["token"], dek, email.strip().lower()
        return recovery

    def devices(self):
        return self.call("GET", "/v1/devices")["devices"]

    def revoke(self, device_id):
        self.call("DELETE", "/v1/devices/" + device_id)

    def revoke_others(self):
        self.call("DELETE", "/v1/devices/others")

    def me(self):
        return self.call("GET", "/v1/me")

    def wait(self, fp="", timeout=25):
        """Long poll: returns {fp, changed} as soon as another device changed something (or after `timeout` seconds)."""
        return self.call("GET", f"/v1/wait?fp={urllib.parse.quote(fp)}&timeout={int(timeout)}", timeout=timeout + 10)

    def fingerprint(self):
        return self.call("GET", "/v1/docs").get("fp", "")


# ------------------------------------------------------------------------------------------------ the sync backend
class SkyCloudBackend(SyncBackend):
    """The same read / write-with-version interface the GitHub backend has, over the account server's versioned documents."""
    name = "skycloud"

    def __init__(self, account):
        if not (account.token and account.dek):
            raise BackendError("Not signed in to your account.")
        self.acct, self._key = account, doc_key(account.dek)

    @staticmethod
    def _name(path):
        return urllib.parse.quote(path, safe="/")

    def read(self, path):
        try:
            out = self.acct.call("GET", "/v1/docs/" + self._name(path))
        except CloudError as e:
            if e.status == 404:
                return None, None
            if e.status == 401:
                raise BackendError("You were signed out of your account - sign in again.")
            raise BackendError(str(e))
        try:
            return unseal(self._key, out["blob"], path.encode()), str(out["version"])
        except Exception:  # noqa: BLE001
            raise BackendError("A document in your account couldn't be opened (wrong key).")

    def write(self, path, data, etag, message="Update"):
        try:
            out = self.acct.call("PUT", "/v1/docs/" + self._name(path), {"blob": seal(self._key, data, path.encode()), "base_version": int(etag or 0)}, timeout=120)
        except CloudError as e:
            if e.status == 409:
                raise Conflict(path)
            if e.status == 401:
                raise BackendError("You were signed out of your account - sign in again.")
            raise BackendError(str(e))
        return str(out["version"])

    def describe(self):
        return f"cloud account {self.acct.email}"
