"""Rules for the Plushies list (Pokemon plush from Bulbapedia, Squishmallows from the Squishmallows wiki): what is not a plush at all, a name the source garbled, how a squad-less Squishmallow is filed, and
the review notes (raw ext 'Review') for what could not be confirmed.  Pure functions, applied by collectibles.PlushProvider on every rebuild so the nightly refresh keeps them.  Usage of the test: python -I tests/test_plushrules.py"""
import json
import os
import re

NOT_LISTED = "Squad not listed"                                  # shown name of the set that holds Squishmallows whose wiki page names no squad
_JUNK = re.compile(r"(?:\bSquad|^List of .*|^Category:.*|^Template:.*|\bdisambiguation)$", re.I)           # wiki pages that are a squad / list page, not one plush
_FIX = {"Cun�gonde": "Cunégonde", "G�nther": "Günther", "Mexican Corn Se�or": "Mexican Corn Señor", "Mexican Corn Se�orita": "Mexican Corn Señorita"}   # garbled by the source, spelling certain
POKEMON_FIT_REVIEW = "The Pokemon fit (Japan) release of this Pokemon is not confirmed by the source (it only lists Sitting Cuties) and no photo of the plush could be loaded: the picture is the official artwork."
POKEMON_ART_REVIEW = "No photo of this plush could be loaded (the picture host blocks it): the picture is the Pokemon's official artwork, not the plush."


def fit_sources():
    """{Pokedex number as text: a Pokemon Center Online product page of its Pokemon fit plush}: the releases an official shop page confirms (cardvault/data/plush_fit_confirmed.json)."""
    try:
        return json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "plush_fit_confirmed.json"), encoding="utf-8")).get("by_dex") or {}
    except (OSError, ValueError):
        return {}


def is_junk_page(title):
    """A squad / list / category page of the wiki ('Star Wars Squad'), not a plush."""
    return bool(_JUNK.search((title or "").strip()))


def clean_name(title):
    """(name, review note or ''): garbled letters repaired when certain, else the entry goes on the review list."""
    t = (title or "").strip()
    t = _FIX.get(t, t)
    if "�" in t:
        return t, "The source garbled a letter of this name; the exact spelling is not confirmed."
    return t, ""


def squad_label(squad):
    return NOT_LISTED if squad == "Other Squishmallows" else squad


def pokemon_review(tag, has_artwork, fit_url=""):
    """Review note of a Pokemon plush row ('' when its picture is the real plush's)."""
    if tag == "fit" and not fit_url:
        return POKEMON_FIT_REVIEW
    return POKEMON_ART_REVIEW if has_artwork else ""
