"""The SAFETY NET around the daily run (roadmap 1.12, tools/daily_update.py):
  - a backup of each game's cards.db before its run (SQLite backup API, safe while the list is open), the last KEEP kept per game, under <data>/backups/daily/<game>/;
    `python tools/undo_daily.py [game]` puts the latest one back (one-step undo);
  - a run that would change more than about BIG_SHARE of a game's rows (cards + sealed products added, removed or renamed; prices do not count - they move every day)
    is NOT applied: the list goes back to the backup, the proposed list waits in <data>/backups/pending/<game>/<run>.db and the owner's review list asks.  Yes = it is
    applied (a backup is taken first, so undo still works); No = it is thrown away."""
import datetime
import gc
import glob
import os
import re
import sqlite3

from . import reviewlist
from .db import game_dir
from .paths import release_data_dir

KEEP = 7
BIG_SHARE = 0.05
BIG_FLOOR = 25                  # fewer changed rows than this never wait (a small list that adds a handful of new items)
KIND = "daily_big_change"
SOURCE = "the daily update"
_STAMP = re.compile(r"^\d{8}-\d{6}-\d{6}\.db$")
OWNER_DRIVE = "D:/Collect Em All Backups"   # owner (quiz 4, 2026-11-10): backups of the real lists go on drive D (C is nearly full); later they move to the home server


def backup_root(data_dir):
    """Where backups live: CEA_BACKUP_ROOT if set; drive D for the real data folder when D exists; otherwise <data>/backups (tests and other copies)."""
    env = os.environ.get("CEA_BACKUP_ROOT")
    if env:
        return env
    try:
        real = os.path.normcase(os.path.abspath(data_dir)) == os.path.normcase(os.path.abspath(release_data_dir()))
    except Exception:  # noqa: BLE001 - no real data folder: use the copy's own
        real = False
    if real and os.path.isdir("D:/"):
        return OWNER_DRIVE
    return os.path.join(data_dir, "backups")


# ---------------------------------------------------------------------------------------------- backups
def copy_db(src, dst):
    """Copy one SQLite list into another with the backup API (never a file copy of an open database).  Raises sqlite3.OperationalError when the target stays locked
    for a minute (the backup call itself would wait forever)."""
    gc.collect()                                                    # a connection left behind by a failed step (kept alive by its traceback) lets go of its lock
    s, d = sqlite3.connect(src, timeout=60), sqlite3.connect(dst, timeout=60)
    try:
        d.execute("BEGIN IMMEDIATE")                                # waits up to the timeout for any writer, then fails instead of hanging
        d.rollback()
        s.backup(d)
    finally:
        d.close()
        s.close()


def _db(data_dir, game):
    return os.path.join(game_dir(data_dir, game), "cards.db")


def backup_dir(data_dir, game):
    return os.path.join(backup_root(data_dir), "daily", game)


def snapshots(data_dir, game):
    """The game's daily backups, newest first."""
    d = backup_dir(data_dir, game)
    return sorted((os.path.join(d, f) for f in (os.listdir(d) if os.path.isdir(d) else []) if _STAMP.match(f)), reverse=True)


def snapshot(data_dir, game, keep=KEEP):
    """Back up the game's list now and keep only the newest `keep`.  -> the backup's path (None when the game has no list yet)."""
    src = _db(data_dir, game)
    if not os.path.exists(src):
        return None
    os.makedirs(backup_dir(data_dir, game), exist_ok=True)
    dst = os.path.join(backup_dir(data_dir, game), datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".db")
    copy_db(src, dst + ".part")
    os.replace(dst + ".part", dst)
    for old in snapshots(data_dir, game)[keep:]:
        os.remove(old)
    return dst


def restore(data_dir, game, snap=None):
    """Put a backup (default: the newest) back into the game's list.  -> the backup used, or None when there is none."""
    snap = snap or next(iter(snapshots(data_dir, game)), None)
    if snap:
        copy_db(snap, _db(data_dir, game))
    return snap


# ---------------------------------------------------------------------------------------------- how much a run changes
def rows_of(db):
    """{(table, id): name} of the cards and sealed products in a list."""
    out = {}
    if not os.path.exists(db):
        return out
    c = sqlite3.connect(db)
    try:
        for table in ("cards", "sealed_products"):
            try:
                out.update({(table, r[0]): r[1] for r in c.execute(f"SELECT id, name FROM {table}")})
            except sqlite3.Error:
                pass
    finally:
        c.close()
    return out


def change(before, after):
    """-> {added, removed, renamed, changed, rows} between two rows_of() results."""
    added = sum(1 for k in after if k not in before)
    removed = sum(1 for k in before if k not in after)
    renamed = sum(1 for k, v in after.items() if k in before and before[k] != v)
    return {"added": added, "removed": removed, "renamed": renamed, "changed": added + removed + renamed, "rows": len(before)}


def is_big(ch):
    """More than about BIG_SHARE of the game's rows (and at least BIG_FLOOR of them).  A first, empty list never waits."""
    return ch["rows"] > 0 and ch["changed"] >= BIG_FLOOR and ch["changed"] > BIG_SHARE * ch["rows"]


def reason(game, ch):
    pct = 100.0 * ch["changed"] / max(1, ch["rows"])
    return (f"Today's run would change {ch['changed']} of {ch['rows']} rows in {game} ({pct:.0f}%: {ch['added']} added, {ch['removed']} removed, {ch['renamed']} renamed)."
            f" Apply it?")


# ---------------------------------------------------------------------------------------------- waiting for the owner
def pending_path(data_dir, game, run):
    return os.path.join(backup_root(data_dir), "pending", game, f"{run}.db")


def hold(data_dir, game, ch, snap):
    """Keep the proposed list aside, put the game's list back as it was before the run, and ask the owner (one question per run).  -> the review item's id"""
    run = datetime.datetime.now().strftime("%Y-%m-%dT%H%M%S-%f")
    dst = pending_path(data_dir, game, run)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    for old in glob.glob(os.path.join(os.path.dirname(dst), "*.db")):          # only the newest proposal is kept; an older question then says so
        if old != dst:
            os.remove(old)
    copy_db(_db(data_dir, game), dst)
    restore(data_dir, game, snap)
    return reviewlist.add_item(KIND, game, run, reason(game, ch), before=ch, source=SOURCE)


def _apply(item, ans, value, ctx):
    data_dir = (ctx or {}).get("data_dir") or release_data_dir()
    src = pending_path(data_dir, item["game"], item["item_id"])
    if not os.path.exists(src):
        return "nothing to apply: a newer daily run replaced this one (answer the newer question)"
    if ans != "yes":
        os.remove(src)
        return "left out: the list stays as it was"
    snapshot(data_dir, item["game"])
    copy_db(src, _db(data_dir, item["game"]))
    os.remove(src)
    return f"applied (undo: python tools/undo_daily.py {item['game']}); it reaches Card Data with the next publish"


reviewlist.register(KIND, apply=_apply)
