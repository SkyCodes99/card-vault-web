"""Undo for changes made with plain SQL (moving a portfolio's items, deleting a binder, ...), the same recent-actions log as every other Undo.
track() takes a picture of the rows a change can touch, runs the change, takes the picture again, and remembers - for each row that differs - exactly the columns that changed.
Undo (restore) puts those columns back; a row the change made comes back as deleted; a row that was physically removed is written again.  ONE log entry per call."""

TABLES = {"lots": "id", "sealed": "uuid", "portfolios": "uuid", "dream_binders": "uuid", "trades": "uuid"}      # the tables a log entry may touch, and each one's key
_SKIP = ("updated_at",)                                                                                         # (always changes: not a difference worth remembering)


def _cols(conn, table):
    return [r[1] for r in conn.execute(f"PRAGMA u.table_info({table})")]


def _rows(conn, table, where, params, keys=()):
    """{key: row as dict} for the rows matching `where` (None: only the rows with these keys), plus the rows with these keys (they may have moved out of `where`)."""
    pk = TABLES[table]
    out = {r[pk]: dict(r) for r in conn.execute(f"SELECT * FROM u.{table} WHERE {where}", params)} if where else {}
    keys = [k for k in keys if k not in out]
    for i in range(0, len(keys), 500):
        part = keys[i:i + 500]
        for r in conn.execute(f"SELECT * FROM u.{table} WHERE {pk} IN ({','.join('?' * len(part))})", part):
            out[r[pk]] = dict(r)
    return out


def track(vault, label, specs, fn):
    """Run fn() as ONE undoable action.  specs = [(table, where, params)]: where finds the rows fn may change (include the user in it); or (table, [keys]) for known rows.  -> what fn returned."""
    conn = vault.conn
    specs = [(sp[0], None, (), list(sp[1])) if len(sp) == 2 else (*sp, []) for sp in specs]
    before = [_rows(conn, t, w, p, k) for t, w, p, k in specs]
    with vault.action(label) as act:
        if label:
            act.label = label
        out = fn()
        for (table, where, params, _k), was in zip(specs, before):
            now = _rows(conn, table, where, params, list(was))
            pk = TABLES[table]
            for key, old in was.items():
                new = now.get(key)
                if new is None:
                    vault._remember({"t": "row", "table": table, "id": key, "full": old})
                    continue
                prev = {c: old[c] for c in old if c not in _SKIP and old[c] != new.get(c)}
                if prev:
                    vault._remember({"t": "row", "table": table, "id": key, "prev": prev})
            for key in now:
                if key not in was:
                    vault._remember({"t": "row", "table": table, "id": key, "gone": 1})
    return out


def restore(vault, op, ts):
    """Put one remembered row change back (called by Vault.undo_action)."""
    table = op.get("table")
    if table not in TABLES:
        return
    conn, pk = vault.conn, TABLES[table]
    cols = _cols(conn, table)
    if op.get("full"):
        row = {c: v for c, v in op["full"].items() if c in cols}
        conn.execute(f"INSERT OR REPLACE INTO u.{table}({','.join(row)}) VALUES({','.join('?' * len(row))})", list(row.values()))
        return
    sets = {"deleted": 1} if op.get("gone") and "deleted" in cols else {c: v for c, v in (op.get("prev") or {}).items() if c in cols and c != pk}
    if op.get("gone") and "deleted" not in cols:
        conn.execute(f"DELETE FROM u.{table} WHERE {pk}=?", (op["id"],))
        return
    if "updated_at" in cols:
        sets["updated_at"] = ts
    if sets:
        conn.execute(f"UPDATE u.{table} SET {','.join(f'{c}=?' for c in sets)} WHERE {pk}=?", (*sets.values(), op["id"]))
