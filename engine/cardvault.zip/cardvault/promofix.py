"""Roadmap 2.7: the nine Yu Nagaba promos (SV-P 062-070) get their true pictures; the Generations Jolteon-EX 28a copies fold into one.

Pictures: a picture is written only when the card's OWN TCGplayer product record confirms it (same product number, same English name) AND it passes the picture gate
(gates.screen_picture) - never guessed; anything unsure is left alone / waits on the review list.  Copies: only certain pairs (same number + letter, same name once the hyphen and the
' - 28a/83' tail are ignored), folded with tcgsync._fold_into so owned copies follow through id_redirects."""
import json
import re
import sqlite3
import time

from . import gates, provenance, searchfold, tcgsync
from .tcgcsv import norm_name

# the nine promos: game, set, TCGplayer category / group, card numbers
NAGABA = {"game": "pokemon_jp", "set": "SV-P", "cat": "85", "group": "23779", "numbers": tuple(f"{n:03d}" for n in range(62, 71))}
# (duplicate, the card it folds into)
JOLTEON_28A = (("131697", "xya-28a"), ("g1-28a", "xya-28a"))      # TCGplayer's 28a/83 product and TCGdex's Generations copy are the Yellow A Alternate card (Ryo Ueda art, printed 28a/83)
XYA_GROUP = ("3", "1938")                           # TCGplayer's 'Alternate Art Promos' = the Yellow A Alternate set


def _num(s):
    return re.sub(r"^0+", "", str(s or "").split("/")[0].strip().lower()) or "0"


def _title(s):
    s = re.sub(r"\s+-\s+\S+$", "", str(s or "").strip())                      # 'Jolteon EX - 28a/83' -> 'Jolteon EX'
    return norm_name(s.replace("-", " "))


def products_by_id(rows):
    """TCGplayer product list -> {productId: product}."""
    return {int(p["productId"]): p for p in rows or []}


def _number_of(p):
    return next((e["value"] for e in p.get("extendedData", []) if e.get("name") == "Number"), "")


def confirmed(card, product):
    """True when this TCGplayer product record is certainly the card: same printed number and same name."""
    if not product or not product.get("imageUrl"):
        return False
    return _num(_number_of(product)) == _num(card["local_id"]) and _title(product["name"]) == _title(card.get("name_en") or card["name"])


def fill_exact_pictures(game, conn, products, ids, image_fetch=None, day=None, replace=()):
    """Picture + English name + provenance for these cards from their own product record.  -> {'filled': n, 'waiting': n, 'skipped': n}"""
    day = day or time.strftime("%Y-%m-%d")
    ctx = gates.Context(conn, game, image_fetch)
    out = {"filled": 0, "waiting": 0, "skipped": 0}
    for cid in ids:
        r = conn.execute("SELECT id, local_id, name, name_en, tcg_id, image_base FROM cards WHERE id=?", (cid,)).fetchone()
        if not r:
            out["skipped"] += 1
            continue
        card = dict(zip(("id", "local_id", "name", "name_en", "tcg_id", "image_base"), r))
        p = products.get(int(card["tcg_id"])) if str(card["tcg_id"] or "").isdigit() else None
        if not confirmed(card, p):
            out["skipped"] += 1
            continue
        if not card["name_en"]:
            conn.execute("UPDATE cards SET name_en=? WHERE id=?", (re.sub(r"\s+-\s+\S+$", "", p["name"]).strip(), cid))
        provenance.record(conn, cid, "card", "tcgp", day)
        if card["image_base"] and cid not in replace:                  # (replace = a picture known to be of ANOTHER card)
            continue
        if not gates.screen_picture(game, conn, cid, p["imageUrl"], "TCGplayer product record via tcgcsv.com", ctx):
            out["waiting"] += 1
            continue
        out["filled"] += conn.execute("UPDATE cards SET image_base=? WHERE id=? AND (image_base IS NULL OR image_base='' OR ?)", (p["imageUrl"], cid, int(cid in replace))).rowcount
        provenance.record_image(conn, cid, p["imageUrl"], day)
    return out


def _same_card(a, b):
    return _num(a["local_id"]) == _num(b["local_id"]) and _title(a["name"]) == _title(b["name"])


def fold_pairs(conn, pairs):
    """Fold each certain (duplicate, keep) pair.  Certain = both exist, same printed number (with its letter) + name.  The duplicate's link and price move over only when the keeper has no link of its own
    (a copy's link to a different product - g1-28a carried the plain 28/83's - is dropped, never copied).  -> [folded dup ids]"""
    cols = "id, local_id, name, tcg_id, price_usd, price_kind, price_updated"
    red = json.loads((conn.execute("SELECT value FROM meta WHERE key='id_redirects'").fetchone() or ["{}"])[0] or "{}")
    done = []
    for dup, keep in pairs:
        d = conn.execute(f"SELECT {cols} FROM cards WHERE id=?", (dup,)).fetchone()
        k = conn.execute(f"SELECT {cols} FROM cards WHERE id=?", (keep,)).fetchone()
        if not d or not k:
            continue
        dd, kk = dict(zip(cols.split(", "), d)), dict(zip(cols.split(", "), k))
        if not _same_card(dd, kk):
            continue
        row = d if not kk["tcg_id"] else (dd["id"], dd["local_id"], dd["name"], kk["tcg_id"], None, None, None)
        red = tcgsync._fold_into(conn, red, row, keep)
        try:
            conn.execute("DELETE FROM card_facets WHERE card_id=?", (dup,))
        except sqlite3.OperationalError:                                  # (a list without facets)
            pass
        done.append(dup)
    if done:
        conn.execute("INSERT OR REPLACE INTO meta VALUES('id_redirects', ?)", (json.dumps(red, ensure_ascii=False, sort_keys=True),))
    return done


def run(data_dir, getter=None, image_fetch=None, apply=True):
    """Both fixes on the live lists under data_dir (a temp copy for the dry run).  -> report dict."""
    import os
    getter = getter or tcgsync.fetch_get
    rep = {}
    jp = os.path.join(data_dir, "games", NAGABA["game"], "cards.db")
    c = sqlite3.connect(jp, timeout=60)
    try:
        prods = products_by_id(getter(f"{NAGABA['cat']}/{NAGABA['group']}/products"))
        ids = [f"{NAGABA['set']}-{n}" for n in NAGABA["numbers"]]
        rep["nagaba"] = fill_exact_pictures(NAGABA["game"], c, prods, ids, image_fetch)
        searchfold.fill(c)
        c.commit()
    finally:
        c.close()
    pk = os.path.join(data_dir, "games", "pokemon", "cards.db")
    c = sqlite3.connect(pk, timeout=60)
    try:
        rep["folded"] = fold_pairs(c, JOLTEON_28A)
        prods = products_by_id(getter(f"{XYA_GROUP[0]}/{XYA_GROUP[1]}/products"))
        rep["xya"] = fill_exact_pictures("pokemon", c, prods, ["xya-28a"], image_fetch)
        g1 = products_by_id(getter("3/1728/products"))                          # g1-28's TCGdex picture is the 28a/83 alt art (Ryo Ueda); its own product record has the real 28/83 picture
        rep["g1-28"] = fill_exact_pictures("pokemon", c, g1, ["g1-28"], image_fetch, replace=("g1-28",))
        searchfold.fill(c)
        c.commit()
    finally:
        c.close()
    return rep
