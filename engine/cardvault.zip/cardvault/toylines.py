"""Keeps a toy list tidy: every entry in the line its words say, who it is exclusive to written one way, and entries in order of their release.

A toy list is fed from several places (a maker's shop, other shops, a collector's master list), and each knew nothing of the others' habits: the master list never heard of 'Mini Chomps', a convention
was 'NYCC' in one place and 'New York Comic Con' in another, and 'Mystery' was filed as somebody the toy is exclusive to.  Run after every refresh, this puts the whole list right again, whoever added
what - and changes nothing when nothing is wrong, so it is safe to run as often as the list is refreshed.  Ids never change: only the line (set) an entry sits in, its filter words and its order do."""
import json
import re

from . import toyexclusive

PROOFS = "Art proofs & prototypes"


def set_id_of(game_id, line):
    return f"{game_id}:" + re.sub(r"[^a-z0-9]+", "-", line.lower()).strip("-")


def ensure_set(conn, game_id, line, serie="Toys"):
    """The id of the line's set, made when the list has none yet (`serie` groups lines under one heading when a person browses)."""
    sid = set_id_of(game_id, line)
    conn.execute("INSERT OR IGNORE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, line, serie, "", 0, 0, None))
    return sid


def sort_key_for(day, sub=0):
    """Order within a line: oldest first, a toy with no known release last, and the figures of one release in their own order (`sub`, 0-99)."""
    digits = re.sub(r"\D", "", str(day or ""))[:8]
    return (int(digits) if len(digits) == 8 else 99999999) * 100 + sub


def _as_product(name, raw, category, kind_word, cid=""):
    """An entry read back from the list as the product the line rules understand.  A master-list name is only the toy's own ('Barista', 'Red Gumball Mini'): `kind_word` ('Chomp') says what kind of toy
    the list is about, so a name that does not say it still lands in the list's main line."""
    ext = raw.get("ext") or {}
    return {"title": ext.get("Shop name") or "", "_shop_title": ext.get("Listed as") or "", "name": f"{name} {kind_word}".strip() if kind_word.lower() not in name.lower() else name,
            "tags": raw.get("tags") or [], "product_type": category or "", "_cid": cid}


def _exclusives(raw, desc):
    """-> (the entry's raw record with 'who it is exclusive to' written one way, its description with the same words, whether anything changed)."""
    ext = raw.setdefault("ext", {})
    old = raw.get("exclusive") or toyexclusive.split(ext.get("Exclusive to"))
    new = toyexclusive.labels(old)
    line = ", ".join(new)
    changed = new != (raw.get("exclusive") or []) or (ext.get("Exclusive to") is not None and ext["Exclusive to"] != (line or "Not exclusive"))
    if changed:
        raw["exclusive"] = new
        ext["Exclusive to"] = line or "Not exclusive"
        was = ", ".join(old)
        if was and (desc or "").startswith(was + ". "):
            desc = (line + ". " if line else "") + desc[len(was) + 2:]
    return raw, desc, changed


def recategorize(conn, game_id, line_of, kind_word="", fixed=("fc:",)):
    """Put every entry in the line `line_of(product)` says, with its filter words and its order made the same way for all (an entry no line fits is left where it is, and so is one whose id starts with
    a prefix in `fixed`: those were put in their own line on purpose).  -> how many entries changed."""
    moved = 0
    lines = dict(conn.execute("SELECT id, name FROM sets WHERE id LIKE ?", (game_id + ":%",)))
    for cid, name, set_id, category, raw_json, desc, order in conn.execute("SELECT id, name, set_id, category, raw, description, sort_key FROM cards").fetchall():
        raw = json.loads(raw_json or "{}")
        line = line_of(_as_product(name, raw, category, kind_word, cid))
        sets = {}
        if line not in (PROOFS, "Misc") and set_id_of(game_id, line) != set_id and not cid.startswith(tuple(fixed)):
            sets = {"set_id": ensure_set(conn, game_id, line), "types": line}
            if category == lines.get(set_id):
                sets["category"] = line                                       # (the entry's kind was only its line's name)
        raw, desc2, changed = _exclusives(raw, desc)
        day = (raw.get("ext") or {}).get("Released")
        key = sort_key_for(day, int(raw.get("series_order") or 0))
        if sets or changed or key != order:
            conn.execute("UPDATE cards SET set_id=COALESCE(?, set_id), types=COALESCE(?, types), category=COALESCE(?, category), description=?, raw=?, sort_key=? WHERE id=?",
                         (sets.get("set_id"), sets.get("types"), sets.get("category"), desc2, json.dumps(raw, ensure_ascii=False), key, cid))
            moved += 1
    return moved


def refresh_sets(conn, game_id, lines_first=()):
    """Every line's size and first release (the main lines sort first), no empty lines, and no proofs line (the proofs wait in their own table until the person shows them)."""
    conn.execute("DELETE FROM sets WHERE id LIKE ? AND id LIKE '%:proofs'", (game_id + ":%",))
    for sid, name in conn.execute("SELECT id, name FROM sets WHERE id LIKE ?", (game_id + ":%",)).fetchall():
        first = conn.execute("SELECT MIN(json_extract(raw, '$.ext.Released')) FROM cards WHERE set_id=? AND json_extract(raw, '$.ext.Released') GLOB '[0-9][0-9][0-9][0-9]-*'", (sid,)).fetchone()[0] or ""
        conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), release_date=? WHERE id=?",
                     ("0000-01-01" if name in lines_first else first, sid))
    conn.execute("DELETE FROM sets WHERE id LIKE ? AND NOT EXISTS (SELECT 1 FROM cards WHERE set_id=sets.id)", (game_id + ":%",))


# ------------------------------------------------------------------------------------------------ one toy listed twice
def _plain(name):
    return re.sub(r"\([^)]*\)", " ", name or "")                           # '(Jul 2023)', '($25 sticker)': a note, not part of the name


def _shared(words, other):
    """The words of `words` that `other` has too (a word also counts when one begins with the other: founder / founders)."""
    return {a for a in words if a in other or any(len(a) >= 4 and len(b) >= 4 and (a.startswith(b) or b.startswith(a)) for b in other)}


def duplicates(rows):
    """{id of a master-list entry: id of the shop entry that is the same toy} for rows of (id, name, released day, how many were made).  The same toy is a shop's entry whose release is within three weeks,
    whose name has every word of the master list's (a master-list entry that says more - 'Red Gumball Mini' for the shop's 'Gumball Mini' - is another toy), with a word that names it (not a colour
    or a finish), and whose number made is the same or unknown on either side."""
    from . import toymatch
    shop = [(i, set(toymatch.norm(_plain(n), toymatch.SHOP_NOISE)), toymatch.to_date(d), e) for i, n, d, e in rows if i.startswith(("shp:", "rtl:"))]
    out = {}
    for sid, name, day, made in rows:
        if not sid.startswith("sheet:"):
            continue
        words, when = set(toymatch.norm(_plain(name), toymatch.SHOP_NOISE)), toymatch.to_date(day)
        if not words or not when:
            continue
        for pid, pwords, pwhen, pmade in shop:
            near = pwhen and abs((pwhen - when).days) <= toymatch.CLOSE_DAYS
            inside = _shared(words, pwords) == words
            if near and (not made or not pmade or made == pmade) and inside and (_shared(pwords, words) == pwords or words - toymatch.COMMON):          # (the same words, or a word that names it)
                out[sid] = pid
                break
    return out


def retire_duplicates(conn):
    """Take a master-list entry out of the list when a shop's entry is the same toy, and say so in the list's 'id_redirects' so that anything of anybody's that still points at it (copies they own, wishlist,
    checklists ...) moves to the entry that stays when the app opens the list.  -> how many were retired."""
    rows = conn.execute("SELECT id, name, json_extract(raw, '$.ext.Released'), json_extract(raw, '$.edition') FROM cards").fetchall()
    gone = duplicates([tuple(r) for r in rows])
    if not gone:
        return 0
    try:
        red = json.loads((conn.execute("SELECT value FROM meta WHERE key='id_redirects'").fetchone() or ["{}"])[0] or "{}")
    except (ValueError, TypeError):
        red = {}
    red.update(gone)
    conn.execute("INSERT OR REPLACE INTO meta VALUES('id_redirects', ?)", (json.dumps(red, sort_keys=True),))
    for old in gone:
        conn.execute("DELETE FROM cards WHERE id=?", (old,))
    return len(gone)


_STOCK_TAIL = re.compile(r"\s*\((?:sold out|in stock)\)\s*$", re.I)
_STOCK_SENTENCE = re.compile(r"[^.!?\n]*\b(?:sold[ -]?out|out of stock|back in stock|in stock (?:at|now)|restock notifications?|available for pre-?order)\b[^.!?\n]*[.!?]?\s*", re.I)
_STOCK_KEYS = ("Availability",)


def drop_stock_notes(conn):
    """Whether a shop had a toy in stock the day its page was read is not a fact about the toy (owner 2026-11-05: "you literally just pulled the name with that from a site"):
    '(sold out)' after an edition, 'Sold out, but available at ...' in a description and the shop's Availability line are taken out of every entry.  -> entries changed."""
    n = 0
    for table in ("cards", "cards_extra"):
        try:
            rows = conn.execute(f"SELECT id, rarity, description, raw FROM {table}").fetchall()
        except Exception:  # noqa: BLE001 - a list without that table
            continue
        for cid, rarity, desc, raw in rows:
            r2 = _STOCK_TAIL.sub("", rarity) if rarity else rarity
            d2 = _STOCK_SENTENCE.sub("", desc).strip() if desc else desc
            raw2 = raw
            if raw and "vailab" in raw:
                try:
                    j = json.loads(raw)
                    ext = j.get("ext") if isinstance(j, dict) else None
                    if isinstance(ext, dict) and any(k in ext for k in _STOCK_KEYS):
                        for k in _STOCK_KEYS:
                            ext.pop(k, None)
                        j.pop("available", None)
                        raw2 = json.dumps(j, ensure_ascii=False)
                except ValueError:
                    pass
            if (r2, d2, raw2) != (rarity, desc, raw):
                conn.execute(f"UPDATE {table} SET rarity=?, description=?, raw=? WHERE id=?", (r2, d2, raw2, cid))
                n += 1
    return n
