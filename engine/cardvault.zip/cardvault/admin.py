"""Admin editing of the card lists: add / remove cards from any card group (Art cards, Alt Art, rarity groups...) or any of your
checklists.  Every change is saved straight away in collection.db (as a per-card override) and is also the training data
used by training.py.

A list reference is ('group', group id) or ('checklist', checklist id).
"""
from . import taxonomy

ADD, REMOVE = "add", "remove"


def _group_tags(gid):
    """How an add / remove / reset on a card group is stored as card tags: [(tag, add value, remove value)]."""
    if gid == "art":
        return [("art", "yes", "no")]
    if gid == "altart":
        return [("altart", "yes", "no")]
    if gid == "art_alt":
        return [("altart", "yes", None), ("art", "yes", "no")]   # add: alt art + counts as art; remove: stays alt art, no longer Art
    return [(gid, "yes", "no")]


def label(vault, ref):
    kind, ident = ref
    if kind == "group":
        return taxonomy.LABEL.get(ident, ident)
    cl = vault.checklist(ident)
    return cl["name"] if cl else str(ident)


def members(vault, ref):
    kind, ident = ref
    return vault.group_ids(ident) if kind == "group" else vault.checklist_members(ident)


def overrides(vault, ref):
    """{card_id: 'add' | 'remove'} - the corrections made by hand for this list."""
    kind, ident = ref
    out = {}
    if kind == "checklist":
        m = vault.checklist_manual(ident)
        out.update({c: ADD for c in m["manual"]})
        out.update({c: REMOVE for c in m["excluded"]})
        return out
    tags = vault.card_tags()
    spec = _group_tags(ident)
    for cid, t in tags.items():
        if ident == "art_alt":
            if t.get("altart") == "yes" and t.get("art") != "no":
                out[cid] = ADD
            elif t.get("art") == "no":
                out[cid] = REMOVE
            continue
        tag, add_v, rem_v = spec[0]
        v = t.get(tag)
        if v == add_v:
            out[cid] = ADD
        elif v == rem_v and rem_v is not None:
            out[cid] = REMOVE
    return out


def _apply(vault, ref, card_ids, action):
    kind, ident = ref
    with vault.action():
        for cid in card_ids:
            if kind == "checklist":
                state = {ADD: "manual", REMOVE: "excluded", None: None}[action]
                vault.set_checklist_card(ident, cid, state)
                continue
            for tag, add_v, rem_v in _group_tags(ident):
                val = add_v if action == ADD else (rem_v if action == REMOVE else None)
                if action == REMOVE and rem_v is None:
                    continue
                vault.set_card_tag(cid, tag, val)
            if action is None and ident == "art_alt":
                vault.set_card_tag(cid, "altart", None)
                vault.set_card_tag(cid, "art", None)


def add(vault, ref, card_ids):
    _apply(vault, ref, list(card_ids), ADD)


def remove(vault, ref, card_ids):
    _apply(vault, ref, list(card_ids), REMOVE)


def reset(vault, ref, card_ids):
    """Forget the hand correction and go back to the automatic rules for these cards."""
    _apply(vault, ref, list(card_ids), None)


def clear_all(vault, ref):
    ids = list(overrides(vault, ref))
    reset(vault, ref, ids)
    return len(ids)


def all_corrections(vault):
    """Every hand correction across all groups: [(card_id, group id, 'add'|'remove')] - for the summary and training export."""
    out = []
    for g in taxonomy.groups():
        for cid, act in overrides(vault, ("group", g.id)).items():
            out.append((cid, g.id, act))
    return out
