"""Gaming consoles line: every console model from consoles_data.json (read by tools/harvest_consoles.py from Wikipedia infoboxes; pictures are Wikimedia Commons files with their licence kept as the photo credit)
and, under each model, its colour variants, bundles and limited / special editions as items of their own ("Edition of <model>"; the model lists them under "Editions" and raw 'editions').
No network at refresh.  Anything that cannot be confirmed (photo licence, launch price, release date) is left empty and written to the raw ext 'Review' note, the same way NeeDoh does it."""
import json
import os
import time
import urllib.parse

from . import sync
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "consoles_data.json")
FILEPATH = "https://commons.wikimedia.org/wiki/Special:FilePath/"


def _kind(t):
    low = (t or "").lower()
    return "Handheld console" if "handheld" in low or "portable" in low else ("Home console" if "home" in low or "microconsole" not in low and "console" in low else "Console")


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def _photo_ok(it):
    lic = it.get("image_licence") or ""
    return bool(it.get("image")) and bool(lic) and "logo" not in lic.lower() and lic.count(",") <= 2


class ConsolesProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("consoles", 0, type_field="Maker")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the consoles list…", 0, 0)
            data = load()
            models, editions = data["items"], data.get("editions", [])
            by_parent = {}
            for e in editions:
                by_parent.setdefault(e["parent"], []).append(e)
            order = {m["id"]: n for n, m in enumerate(sorted(models, key=lambda m: (m["family"], m["release_date"] or "9999", m["name"])))}
            names = {m["id"]: m["name"] for m in models}
            made = {}
            for it in models + editions:
                sid = "consoles:" + it["family"].lower().replace(" ", "-")
                if sid not in made:
                    made[sid] = it["family"]
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, it["family"], it["maker"], "", 0, 0))
                is_ed = "parent" in it
                ok = _photo_ok(it)
                why = []
                if not ok:
                    why.append("no confirmed true photo (Commons file or licence not confirmed)")
                if not it["msrp"]:
                    why.append("launch MSRP not confirmed: " + ("; ".join(w for w in it["why"] if "price" in w) or "none stated"))
                if not it["release_date"]:
                    why.append("release date not stated on the source page")
                if is_ed:
                    ext = {"Source": "Wikipedia: " + it["url"], "Maker": it["maker"], "Family": it["family"], "Console type": it["edition_type"], "Edition of": it["parent_name"], "Edition": it["label"],
                           "Region": it["region"], "Release date": it["release_date"], "Edition size": ("%s units" % it["edition_size"]) if it["edition_size"] else "", "Source says": it["evidence"]}
                    kind, parent_id = "Console edition", "consoles:" + it["parent"]
                else:
                    kids = by_parent.get(it["id"], [])
                    ext = {"Source": "Wikipedia: " + it["url"], "Maker": it["maker"], "Family": it["family"], "Console type": it["kind"] or "", "Release dates": it["released_text"], "Release date": it["release_date"],
                           "Launch price (as stated)": it["price_text"], "Revision of": names.get(it.get("revision_of", ""), ""), "Editions": "; ".join(k["name"] for k in kids), "Edition count": str(len(kids)) if kids else ""}
                    kind, parent_id = _kind(it["kind"]), ""
                if it["msrp"]:
                    ext["Retail price"] = it["msrp"]
                if ok:
                    ext["Photo credit"] = "%s, %s, Wikimedia Commons File:%s" % (it["image_author"] or "author on file page", it["image_licence"], it["image"])
                if why:
                    ext["Review"] = "; ".join(why)
                ext = {k: v for k, v in ext.items() if v}
                img = FILEPATH + urllib.parse.quote(it["image"]) + "?width=600" if ok else ""
                n = (list(by_parent.get(it["parent"], [])).index(it) + 1) if is_ed else 0
                raw = {"source": "wikipedia.org", "key": it["id"], "ext": ext}
                if is_ed:
                    raw["parent"] = parent_id
                elif by_parent.get(it["id"]):
                    raw["editions"] = ["consoles:" + k["id"] for k in by_parent[it["id"]]]
                conn.execute(
                    "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                    ("consoles:" + it["id"], sid, "", order.get(it["parent"] if is_ed else it["id"], 0) * 1000 + n, it["name"], img, kind, it["maker"], it["edition_type"] if is_ed else it["maker"],
                     ("%s - %s of the %s, %s." % (it["name"], it["edition_type"].lower(), it["parent_name"], "first released " + it["release_date"] if it["release_date"] else "release date unconfirmed")) if is_ed else
                     "%s - %s (%s), first released %s." % (it["name"], _kind(it["kind"]).lower(), it["maker"], it["release_date"] or "date unconfirmed"), json.dumps({"normal": True}),
                     json.dumps(raw, ensure_ascii=False)))
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no market-price source from an allowed site; owners can enter what they paid
