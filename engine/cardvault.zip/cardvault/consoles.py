"""Gaming consoles line: every console model from consoles_data.json (read by tools/harvest_consoles.py from Wikipedia infoboxes; pictures are Wikimedia Commons files with their licence kept as the photo credit)
and, under each model, its colour variants, bundles and limited / special editions as items of their own ("Edition of <model>"; the model lists them under "Editions" and raw 'editions').
No network at refresh.  Anything that cannot be confirmed (photo licence, launch price, release date) is left empty and written to the raw ext 'Review' note, the same way NeeDoh does it."""
import json
import os
import time
import urllib.parse

from . import photoverify, sync
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "consoles_data.json")
FILEPATH = "https://commons.wikimedia.org/wiki/Special:FilePath/"


def _kind(t):
    low = (t or "").lower()
    return "Handheld console" if "handheld" in low or "portable" in low else ("Home console" if "home" in low or "microconsole" not in low and "console" in low else "Console")


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def _site(url):
    """'Wikipedia' / 'Sega Retro' / host name of a source page (the first source used to be labelled Wikipedia whatever it was)."""
    host = urllib.parse.urlparse(url or "").netloc.lower().replace("www.", "")
    return "Wikipedia" if "wikipedia.org" in host else host or "Wikipedia"


def _regional(it):
    """Per-region release dates / launch prices, never-sold flag and the other sources of an item, as raw ext facts (the single 'Release date' / 'Retail price' stay for everything that reads them)."""
    out = {}
    if it.get("release"):
        out["Release dates by region"] = "; ".join("%s: %s" % (r["region"], r["date"]) for r in it["release"])
    if it.get("price"):
        out["Launch prices by region"] = "; ".join("%s: %s" % (p["region"], p["amount"]) for p in it["price"])
    if it.get("release_text"):
        out["Release (as written by the source)"] = it["release_text"]
    if it.get("unreleased"):
        out["Never sold in shops"] = {"prize": "prize console", "promo": "promotional console", "prototype": "prototype"}.get(it.get("promo") or "", "not on general sale")
    more = []
    for s in it.get("sources", []):
        if s["url"] != it.get("url") and s["url"] not in more:
            more.append(s["url"])
    if more:
        out["More sources"] = "; ".join(more[:5])
    if it.get("research_note"):
        out["Research note"] = it["research_note"]
    return out


def _photo_ok(it, gate=None):
    """A Commons photo is shown only when it has a licence on record AND the automatic check (photoverify) passed it for this exact image URL (or the owner said yes on the review list)."""
    lic = it.get("image_licence") or ""
    if not (bool(it.get("image")) and bool(lic) and "logo" not in lic.lower() and lic.count(",") <= 2):
        return False
    return gate is None or gate.ok("consoles:" + it["id"], FILEPATH + urllib.parse.quote(it["image"]) + "?width=600")[0]


class ConsolesProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("consoles", 0, type_field="Maker")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the consoles list…", 0, 0)
            data = load()
            models, editions = data["items"], data.get("editions", [])
            by_parent = {}
            for e in editions:
                by_parent.setdefault(e["parent"], []).append(e)
            order = {m["id"]: n for n, m in enumerate(sorted(models, key=lambda m: (m["family"], m["release_date"] or "9999", m["name"])))}
            names = {m["id"]: m["name"] for m in models}
            made = {}
            gate = photoverify.Gate("consoles")
            for it in models + editions:
                sid = "consoles:" + it["family"].lower().replace(" ", "-")
                if sid not in made:
                    made[sid] = it["family"]
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, it["family"], it["maker"], "", 0, 0))
                is_ed = "parent" in it
                ok = _photo_ok(it, gate)
                why = []
                if not ok:
                    why.append("no confirmed true photo (Commons file or licence not confirmed; picture check: %s)" % (gate.ok("consoles:" + it["id"], FILEPATH + urllib.parse.quote(it["image"]) + "?width=600")[1] or "licence missing" if it.get("image") else "no picture"))
                if not it["msrp"]:
                    why.append("launch MSRP not confirmed: " + ("; ".join(w for w in it["why"] if "price" in w) or "none stated"))
                if not it["release_date"]:
                    why.append("release date not stated on the source page")
                if is_ed:
                    ext = {"Source": _site(it["url"]) + ": " + it["url"], "Maker": it["maker"], "Family": it["family"], "Console type": it["edition_type"], "Edition of": it["parent_name"], "Edition": it["label"],
                           "Region": it["region"], "Release date": it["release_date"], "Edition size": ("%s units" % it["edition_size"]) if it["edition_size"] else "", "Source says": it["evidence"]}
                    kind, parent_id = "Console edition", "consoles:" + it["parent"]
                else:
                    kids = by_parent.get(it["id"], [])
                    ext = {"Source": _site(it["url"]) + ": " + it["url"], "Maker": it["maker"], "Family": it["family"], "Console type": it["kind"] or "", "Release dates": it["released_text"], "Release date": it["release_date"],
                           "Launch price (as stated)": it["price_text"], "Revision of": names.get(it.get("revision_of", ""), ""), "Editions": "; ".join(k["name"] for k in kids), "Edition count": str(len(kids)) if kids else ""}
                    kind, parent_id = _kind(it["kind"]), ""
                ext.update(_regional(it))
                if it["msrp"]:
                    ext["Retail price"] = it["msrp"]
                if ok:
                    ext["Photo credit"] = "%s, %s, Wikimedia Commons File:%s" % (it["image_author"] or "author on file page", it["image_licence"], it["image"])
                if why:
                    ext["Review"] = "; ".join(why)
                ext = {k: v for k, v in ext.items() if v}
                img = FILEPATH + urllib.parse.quote(it["image"]) + "?width=600" if ok else ""
                n = (list(by_parent.get(it["parent"], [])).index(it) + 1) if is_ed else 0
                raw = {"source": "wikipedia.org", "key": it["id"], "ext": ext}
                if is_ed:
                    raw["parent"] = parent_id
                elif by_parent.get(it["id"]):
                    raw["editions"] = ["consoles:" + k["id"] for k in by_parent[it["id"]]]
                conn.execute(
                    "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                    ("consoles:" + it["id"], sid, "", order.get(it["parent"] if is_ed else it["id"], 0) * 1000 + n, it["name"], img, kind, it["maker"], it["edition_type"] if is_ed else it["maker"],
                     ("%s - %s of the %s%s, %s." % (it["name"], it["edition_type"].lower(), it["parent_name"], " (never sold in shops)" if it.get("unreleased") else "", "first released " + it["release_date"] if it["release_date"] else "release date unconfirmed")) if is_ed else
                     "%s - %s (%s), first released %s." % (it["name"], _kind(it["kind"]).lower(), it["maker"], it["release_date"] or "date unconfirmed"), json.dumps({"normal": True}),
                     json.dumps(raw, ensure_ascii=False)))
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), "
                             "release_date=COALESCE((SELECT MIN(json_extract(raw, '$.ext.\"Release date\"')) FROM cards WHERE set_id=sets.id AND json_extract(raw, '$.ext.\"Release date\"') GLOB '[1-9][0-9][0-9][0-9]*'), '') "
                             "WHERE id=?", (sid,))                       # (a family's first release = its earliest model's stated day: audit L6.5)
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no market-price source from an allowed site; owners can enter what they paid
