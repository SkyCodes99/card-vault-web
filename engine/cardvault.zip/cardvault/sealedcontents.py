"""What is inside a sealed product ("What's inside"): the packs and items a box, ETB or bundle holds, as short lines.

Only what a source STATES is kept - never a guess.  Sources, in order:
  1. the product description TCGplayer / tcgcsv carries (CardText): the "... includes:" / "... contains:" list, or a sentence that gives a pack count;
  2. a pack count written in the product name ("Booster Box (36 packs)", "3-Pack Blister").
A product that no source describes has no contents (blank).  Stored in sealed_products.contents as lines joined with a newline; the rules run when the lists are built,
so the nightly refresh keeps them."""
import html
import re

MAX_LINES = 16
MAX_LEN = 110
_MARK = re.compile(r"\b(?:includes|contains|inside)\s*:", re.I)
_STOP = re.compile(r"^(?:\*|contents?\b|colors?\b|colours?\b|packaging\b|sold\b|product\b|note\b|please\b|warning\b|ages?\b|for ages\b|available\b|while supplies)", re.I)
_SENTENCE = re.compile(r"\b(?:[Cc]ontains?|[Ii]ncludes?|[Hh]olds?|[Pp]acked with|[Ww]ith)\s+(\d{1,3})\s+((?:[A-Z&][\w&'’:\-]*\s+){0,6}?)(booster\s+)?packs\b")
_NAME = re.compile(r"\b(\d{1,3})[\s-]*(?:count\s+)?(booster\s+)?packs?\b", re.I)
_NAME_PAREN = re.compile(r"[\(\[]\s*(\d{1,3})\s*(?:x\s*)?(?:count\s+)?(booster\s+)?packs?\s*[\)\]]", re.I)


def _fix(t):
    """Text with a damaged character (a replacement mark where an accent or apostrophe was lost) put right where that is certain, else the mark is dropped."""
    t = t.replace("Pok�mon", "Pokémon").replace("POK�MON", "POKÉMON")
    t = re.sub(r"(?<=[a-z])�(?=s\b)", "'", t)
    t = re.sub(r"(?<=[a-z0-9])�(?=[A-Z])", " ", t)
    return t.replace("�", "")


def _text(raw):
    t = html.unescape(str(raw or ""))
    t = re.sub(r"(?i)<\s*(?:br|/p|/li|li|p)\s*/?>", "\n", t)
    t = re.sub(r"<[^>]+>", " ", t)
    return _fix(t.replace("\r", "\n"))


def _line(s):
    s = re.sub(r"^[^0-9A-Za-z(]+", "", s.strip())               # bullets and stray marks
    s = re.sub(r"\s+", " ", s).strip().rstrip(".;")
    return s


def from_list(raw):
    """The list after "... includes:" in a description, as clean lines ([] when the description has none)."""
    text = _text(raw)
    m = _MARK.search(text)
    if not m:
        return []
    out = []
    for ln in text[m.end():].split("\n"):
        s = _line(ln)
        if not s:
            continue
        if _STOP.match(s) or len(s) > 160:
            break
        out.append(s[:MAX_LEN])
        if len(out) >= MAX_LINES:
            break
    return out


def from_sentence(raw):
    """A pack count a description states in a sentence ("contains 36 booster packs") -> ["36 booster packs"], else []."""
    m = _SENTENCE.search(_text(raw))
    if not m:
        return []
    n, words, booster = int(m.group(1)), re.sub(r"\s+", " ", m.group(2)).strip(), bool(m.group(3))
    return [f"{n} {'booster ' if booster else ''}packs"] if n > 0 else []


def from_name(name):
    """A pack count written in the product's name ("Booster Box (36 Packs)", "3-Pack Blister") -> ["36 packs"], else []."""
    nm = html.unescape(str(name or ""))
    m = _NAME_PAREN.search(nm) or _NAME.search(nm)
    if not m or int(m.group(1)) <= 0:
        return []
    n = int(m.group(1))
    return [f"{n} {'booster ' if m.group(2) else ''}pack{'s' if n != 1 else ''}"]


def contents_of(name, description=""):
    """The lines for one product: the description's list, else a pack count it states, else one in the name; [] when nothing states it."""
    return from_list(description) or from_sentence(description) or from_name(name)


def pack(lines):
    return "\n".join(lines) if lines else None


def unpack(text):
    return [x for x in str(text or "").split("\n") if x.strip()]
