"""Free daily Yu-Gi-Oh! prices from YGOPRODeck (roadmap 1.2), shown NEXT TO the TCGplayer and eBay prices, never over them.

One bulk call a day: https://db.ygoprodeck.com/api/v7/cardinfo.php  (their guide: cache it, stay under 20 requests a second, cached 2 days on their side).
What we keep (stored in the same small table the Magic readers use, cardvault.freeprices.source_prices, source = 'ygoprodeck'):
    card_sets[].set_price  -> vendor 'ygoprodeck', finish 'printing', USD   the price of that set + rarity printing (0 = unknown, skipped)
    card_prices.cardmarket_price    -> vendor 'cardmarket',    finish 'lowest', EUR   (lowest across all printings of the card)
    card_prices.coolstuffinc_price  -> vendor 'coolstuffinc',  finish 'lowest', USD
Never stored: ebay_price (our own eBay rules forbid mixing eBay figures), tcgplayer_price (we read TCGplayer ourselves), amazon_price.
YGOPRODeck gives no TCGplayer product id, so a printing is matched to our card by set code + rarity (tiers below) and the stored row is filed under
that card's own tcg_id.  cards.price_usd / price_kind / price_updated are never touched."""
import re

from . import freeprices, legality, provenance
from .sources import rules

SOURCE = "ygoprodeck"
URL = "https://db.ygoprodeck.com/api/v7/cardinfo.php?misc=yes"      # misc=yes adds the TCG / OCG release dates (format legality, cardvault/legality.py)
DAY_AGE = 20 * 3600                                  # read the bulk file at most about once a day

rules.add(rules.SiteRule("ygoprodeck", "YGOPRODeck", ("db.ygoprodeck.com",), 0.25, "data",
                         "Free card + price API: cache locally, stay under 20 requests a second (we make one call a day), no hotlinking of pictures; credit YGOPRODeck. "
                         "eBay/Amazon/TCGplayer figures in the answer are NOT kept.", "https://ygoprodeck.com/api-guide/"))
provenance.SOURCES.setdefault("ygop", ("YGOPRODeck", "https://ygoprodeck.com"))

LANG_CODE = re.compile(r"^([A-Z0-9]+)-(?:EN|DE|FR|IT|PT|SP|JP|KR|AE|SC|TC)(.*\d.*)$")


def num(v):
    """A price string -> float, or None for missing / 0 / junk (YGOPRODeck writes '0' when it does not know)."""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f > 0 else None


def norm_rarity(r):
    return re.sub(r"[^a-z0-9]", "", (r or "").lower())


def norm_code(code):
    """'LOB-EN098' and 'LOB-098' -> 'LOB-098' (the language letters are dropped)."""
    code = (code or "").strip().upper()
    m = LANG_CODE.match(code)
    return f"{m.group(1)}-{m.group(2)}" if m else code


def index(cards):
    """cardinfo 'data' list -> (by_exact {(set_code, rarity): [entry]}, by_code {norm_code: [entry]}, count).
    entry = (set_price or None, cardmarket or None, coolstuffinc or None, norm_rarity)."""
    exact, by_code, n = {}, {}, 0
    for c in cards or ():
        prices = (c.get("card_prices") or [{}])[0] or {}
        cm, csi = num(prices.get("cardmarket_price")), num(prices.get("coolstuffinc_price"))
        for s in c.get("card_sets") or ():
            code = (s.get("set_code") or "").strip().upper()
            if not code:
                continue
            n += 1
            e = (num(s.get("set_price")), cm, csi, norm_rarity(s.get("set_rarity")))
            exact.setdefault((code, s.get("set_rarity") or ""), []).append(e)
            by_code.setdefault(norm_code(code), []).append(e)
    return exact, by_code, n


def _best(entries):
    """Several entries for one printing (a card listed twice): the first one that has a price, else the first."""
    return next((e for e in entries if e[0] is not None), entries[0])


def match(card_code, card_rarity, exact, by_code):
    """-> (entry, tier) or (None, None).  tier 1 = same set code + rarity; 2 = same code (language dropped) + rarity spelled the same way
    once punctuation is ignored; 3 = the code has one single rarity in YGOPRODeck, so there is nothing to confuse it with."""
    code = (card_code or "").strip().upper()
    e = exact.get((code, card_rarity or ""))
    if e:
        return _best(e), 1
    cands = by_code.get(norm_code(code))
    if not cands:
        return None, None
    nr = norm_rarity(card_rarity)
    same = [x for x in cands if x[3] == nr]
    if same:
        return _best(same), 2
    if len({x[3] for x in cands}) == 1:
        return _best(cands), 3
    return None, None


def ygo_rows(conn, cards, day):
    """-> (list of (tcg_id, vendor, finish, currency, price, day), stats).  stats: printings (in YGOPRODeck), cards (ours), matched (ours), tiers, priced."""
    exact, by_code, n = index(cards)
    stats = {"entries": n, "cards_checked": 0, "matched": 0, "priced": 0, "tiers": {1: 0, 2: 0, 3: 0}}
    rows = []
    for tcg_id, code, rarity in conn.execute("SELECT tcg_id, local_id, rarity FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''"):
        stats["cards_checked"] += 1
        e, tier = match(code, rarity, exact, by_code)
        if e is None:
            continue
        stats["matched"] += 1
        stats["tiers"][tier] += 1
        sp, cm, csi, _ = e
        got = [("ygoprodeck", "printing", "USD", sp), ("cardmarket", "lowest", "EUR", cm), ("coolstuffinc", "lowest", "USD", csi)]
        got = [(str(tcg_id), v, f, cur, p, day) for v, f, cur, p in got if p is not None]
        if got:
            stats["priced"] += 1
            rows.extend(got)
    return rows, stats


def run(conn, fetcher):
    """Fetch (cached for a day), match and store.  Returns the describe()-able result dict."""
    freeprices.ensure(conn)
    got = fetcher.get(URL, max_age=DAY_AGE)
    data = got.json() if got.status == 200 else None
    cards = data.get("data") if isinstance(data, dict) else None
    if not cards:
        return {"source": SOURCE, "written": False, "error": f"cardinfo not available (HTTP {got.status})"}
    day = got.fetched_at[:10]
    rows, stats = ygo_rows(conn, cards, day)
    res = freeprices.write(conn, SOURCE, rows)
    res.update(stats, day=day, from_cache=got.from_cache, stale=got.stale)
    leg = legality.ygo_write(conn, cards, day)                 # format legality (TCG / OCG and their bans) from the same file
    res["legality"] = {"rows": leg["rows"], "cards": leg["cards"], "written": leg["written"]}
    res["entries_matched"] = stats["matched"]                  # describe() reads: our cards matched out of the source's printings
    return res
