"""A real picture for every set.  Tiers, best first - a set keeps the best it can get and never a blank:
  1. the set's own logo (already in the card list)
  2. an official logo from a public source (pokemontcg.io for Pokemon, YGOPRODeck for Yu-Gi-Oh!, Scryfall icons for Magic)
  3. the picture of the set's own sealed product (its booster box, else a booster pack, bundle, deck ...) from TCGplayer
  4. the picture of the set's best card (most valuable, else the first) - so even a promo group or a set with no sealed product shows real artwork
Toy lists (Funko, Chomps, plush ...) have groups, not sets: the group is shown with the picture of one of its own items (tier 4).
Everything lands in the list's setimg_urls, which the screens already read; nothing in the list is deleted or replaced."""
import json
import re
import sqlite3

_PREFER = ("booster box", "booster display", "display", "booster pack", "booster bundle", "elite trainer", "starter deck", "bundle", "collection", "tin", "box")
PTCGIO = "https://api.pokemontcg.io/v2/sets"
YGO = "https://db.ygoprodeck.com/api/v7/cardsets.php"
SCRYFALL = "https://api.scryfall.com/sets"


def _norm(s):
    s = (s or "").lower().replace("&", " and ").replace("é", "e").replace("'", "").replace("’", "")
    s = re.sub(r"^(sv|swsh|sm|xy|bw|dp|hgss|ex|pl|me)\s*[:\-]\s*", "", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def _score(name):
    low = (name or "").lower()
    for i, w in enumerate(_PREFER):
        if w in low:
            return i
    return len(_PREFER)


def _urls(conn):
    try:
        row = conn.execute("SELECT value FROM meta WHERE key='setimg_urls'").fetchone()
        d = json.loads(row[0]) if row and row[0] else {}
        return d if isinstance(d, dict) else {}
    except (sqlite3.Error, ValueError):
        return {}


def _save(conn, urls):
    conn.execute("INSERT OR REPLACE INTO meta VALUES('setimg_urls', ?)", (json.dumps(urls),))
    conn.commit()


def _needing(conn, urls):
    try:
        return [(r[0], r[1]) for r in conn.execute("SELECT id, name FROM sets WHERE (logo IS NULL OR logo='')") if r[0] not in urls]
    except sqlite3.Error:
        return []


def fill_from_sealed(conn):
    """Tier 3."""
    urls = _urls(conn)
    try:
        best = {}
        for sid, name, img in conn.execute("SELECT set_id, name, image_base FROM sealed_products WHERE image_base IS NOT NULL AND image_base!=''"):
            sc = _score(name)
            if sid not in best or sc < best[sid][0]:
                best[sid] = (sc, img.replace("_200w", "_400w"))
    except sqlite3.Error:
        return 0
    n = 0
    for sid, _nm in _needing(conn, urls):
        if sid in best:
            urls[sid] = best[sid][1]
            n += 1
    if n:
        _save(conn, urls)
    return n


def fill_external(conn, game, getjson):
    """Tier 2: official logos from public sources, matched by set name.  getjson(url) -> parsed JSON or None (network failures just fill nothing)."""
    urls = _urls(conn)
    todo = _needing(conn, urls)
    if not todo:
        return 0
    found = {}
    try:
        if game == "pokemon":
            d = (getjson(PTCGIO) or {}).get("data") or []
            found = {_norm(x["name"]): x["images"]["logo"] for x in d if x.get("images", {}).get("logo")}
        elif game == "yugioh":
            d = getjson(YGO) or []
            found = {_norm(x["set_name"]): x["set_image"] for x in d if isinstance(x, dict) and x.get("set_image")}
        elif game == "mtg":
            d = (getjson(SCRYFALL) or {}).get("data") or []
            found = {_norm(x["name"]): x["icon_svg_uri"] for x in d if x.get("icon_svg_uri")}
    except (KeyError, TypeError, ValueError):
        found = {}
    n = 0
    for sid, name in todo:
        key = _norm(name)
        hit = found.get(key) or found.get(key.replace(" and ", " ")) or found.get(re.sub(r"\b(booster|expansion|set|series)\b", "", key).strip())
        if hit:
            urls[sid] = hit
            n += 1
    if n:
        _save(conn, urls)
    return n


def fill_from_cards(conn, game, picture_url=None):
    """Tier 4: the best card of the set (or group).  Always found, so a set can never be blank."""
    from .db import picture_url as pic
    urls = _urls(conn)
    n = 0
    for sid, _nm in _needing(conn, urls):
        r = conn.execute("SELECT image_base FROM cards WHERE set_id=? AND image_base IS NOT NULL AND image_base!='' ORDER BY (price_usd IS NULL), price_usd DESC, sort_key LIMIT 1", (sid,)).fetchone()
        if not r:
            continue
        base = r[0]
        url = pic(base, "high") if game.startswith("pokemon") else base.replace("_200w", "_400w")
        urls[sid] = url
        n += 1
    if n:
        _save(conn, urls)
    return n


def fill_from_series(conn, game):
    """Tier 5: a set with no pictures of its own (older Japanese sets whose cards have no scans) shows the best card of its own series - real artwork from that era."""
    from .db import picture_url as pic
    urls = _urls(conn)
    n = 0
    for sid, _nm in _needing(conn, urls):
        r = conn.execute(
            "SELECT c.image_base FROM cards c JOIN sets s ON s.id=c.set_id WHERE s.serie=(SELECT serie FROM sets WHERE id=?) AND c.image_base IS NOT NULL AND c.image_base!='' "
            "ORDER BY (c.price_usd IS NULL), c.price_usd DESC LIMIT 1", (sid,)).fetchone()
        if not r:
            continue
        urls[sid] = pic(r[0], "high") if game.startswith("pokemon") else r[0].replace("_200w", "_400w")
        n += 1
    if n:
        _save(conn, urls)
    return n


def fill_all(conn, game, getjson=None):
    """Runs every tier in order; -> how many sets got a picture, and how many are still without."""
    got = fill_external(conn, game, getjson) if getjson else 0
    got += fill_from_sealed(conn)
    got += fill_from_cards(conn, game)
    got += fill_from_series(conn, game)
    return got, len(_needing(conn, _urls(conn)))
