"""A picture for every set that has none: the picture of the set's own sealed product (its booster box, else a booster pack, bundle, deck ...) from TCGplayer.
Sets that already have a logo or a picture keep theirs - this only fills the gaps (many sets of the TCGplayer-based games have no logo anywhere)."""
import json
import sqlite3

_PREFER = ("booster box", "booster display", "display", "booster pack", "booster bundle", "elite trainer", "starter deck", "bundle", "collection", "tin", "box")


def _score(name):
    low = (name or "").lower()
    for i, w in enumerate(_PREFER):
        if w in low:
            return i
    return len(_PREFER)


def fill_from_sealed(conn):
    """Adds {set id: picture address} to the list's setimg_urls for sets with neither a logo nor a picture.  -> number of sets filled."""
    try:
        row = conn.execute("SELECT value FROM meta WHERE key='setimg_urls'").fetchone()
        urls = json.loads(row[0]) if row and row[0] else {}
    except (sqlite3.Error, ValueError):
        urls = {}
    try:
        sets = [r[0] for r in conn.execute("SELECT id FROM sets WHERE logo IS NULL OR logo=''")]
        best = {}
        for sid, name, img in conn.execute("SELECT set_id, name, image_base FROM sealed_products WHERE image_base IS NOT NULL AND image_base!=''"):
            sc = _score(name)
            if sid not in best or sc < best[sid][0]:
                best[sid] = (sc, img.replace("_200w", "_400w"))
    except sqlite3.Error:
        return 0
    n = 0
    for sid in sets:
        if sid not in urls and sid in best:
            urls[sid] = best[sid][1]
            n += 1
    if n:
        conn.execute("INSERT OR REPLACE INTO meta VALUES('setimg_urls', ?)", (json.dumps(urls),))
        conn.commit()
    return n
