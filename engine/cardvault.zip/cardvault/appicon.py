"""App icon: renders the embedded SVG (same art as docs/brand/icon.svg) so it works when packaged."""
from PySide6.QtCore import QByteArray, QRectF, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1b2a55"/><stop offset="1" stop-color="#0e1220"/></linearGradient>
    <linearGradient id="art" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6b9bff"/><stop offset="1" stop-color="#2a6df0"/></linearGradient>
  </defs>
  <rect width="512" height="512" rx="112" fill="url(#bg)"/>
  <g id="mark">
    <g transform="rotate(-16 256 400)"><rect x="150" y="96" width="212" height="292" rx="26" fill="#2a4a9a" stroke="#0e1220" stroke-width="8"/></g>
    <g transform="rotate(15 256 400)"><rect x="150" y="96" width="212" height="292" rx="26" fill="#6b9bff" stroke="#0e1220" stroke-width="8"/></g>
    <rect x="150" y="96" width="212" height="292" rx="26" fill="#f4f7ff" stroke="#0e1220" stroke-width="8"/>
    <rect x="174" y="120" width="164" height="150" rx="14" fill="url(#art)"/>
    <path d="M256 150 L270 197 L317 211 L270 225 L256 272 L242 225 L195 211 L242 197 Z" fill="#ffc94a"/>
    <rect x="178" y="296" width="156" height="14" rx="7" fill="#9fb4e6"/>
    <rect x="178" y="324" width="96" height="14" rx="7" fill="#c9d6f5"/>
  </g>
</svg>
"""


def make_pixmap(s):
    pm = QPixmap(s, s)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    QSvgRenderer(QByteArray(ICON_SVG.encode("utf-8"))).render(p, QRectF(0, 0, s, s))
    p.end()
    return pm


def make_icon():
    ic = QIcon()
    for s in (16, 32, 64, 128, 256):
        ic.addPixmap(make_pixmap(s))
    return ic
