from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap


def make_pixmap(s):
    pm = QPixmap(s, s)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    # card
    w, h = s * 0.62, s * 0.88
    card = QRectF((s - w) / 2, (s - h) / 2, w, h)
    p.setBrush(QColor("#f4c430"))
    p.setPen(QPen(QColor("#2b2b2b"), max(1, s / 22)))
    p.drawRoundedRect(card, s / 12, s / 12)
    art = QRectF(card.x() + w * 0.1, card.y() + h * 0.1, w * 0.8, h * 0.5)
    p.setBrush(QColor("#d7263d"))
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(art, s / 20, s / 20)
    # poke-ball motif
    cx, cy, r = s / 2, art.center().y(), art.height() * 0.32
    p.setBrush(QColor("white"))
    p.drawEllipse(QRectF(cx - r, cy - r, 2 * r, 2 * r))
    p.setBrush(QColor("#2b2b2b"))
    p.drawEllipse(QRectF(cx - r * 0.35, cy - r * 0.35, r * 0.7, r * 0.7))
    p.end()
    return pm


def make_icon():
    ic = QIcon()
    for s in (16, 32, 64, 128, 256):
        ic.addPixmap(make_pixmap(s))
    return ic
