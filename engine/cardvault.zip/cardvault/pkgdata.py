"""Open a data file that ships inside the cardvault package (cardvault/data/*.json) - on the desktop it is a plain file; on the website the package is imported straight from
cardvault.zip, so the path is "/cardvault.zip/cardvault/data/x.json" and a plain open() fails (every such list was silently empty there: pull rates, set eras, "What's inside" ...).
Same use as open(path, encoding="utf-8") for reading text."""
import io
import os
import zipfile


def open_text(path):
    try:
        return open(path, encoding="utf-8")
    except OSError:
        norm = str(path).replace("\\", "/")
        cut = norm.find(".zip/")
        if cut < 0:
            raise
        archive, member = norm[:cut + 4], norm[cut + 5:]
        try:
            with zipfile.ZipFile(archive) as z:
                return io.TextIOWrapper(io.BytesIO(z.read(member)), encoding="utf-8")       # (text mode, like open(): line endings read the same)
        except (OSError, KeyError, zipfile.BadZipFile):
            raise FileNotFoundError(path) from None
