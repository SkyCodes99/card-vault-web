"""The checker's side of the player reports: the items players reported go FIRST on the checker's next run.
The owner's account pulls the server's list (dev.reports.pull in webapi/reportapi.py) into a small file next to the daily update log; the checkers call first() to put those items at the front of
their work, and the reports also land on the review list (kind "user_report") so nothing a player found is lost.  done() clears an item once a run has looked at it."""
import json
import os

from . import dailylog, reviewlist

KIND = "user_report"
SOURCE = "players' reports of a problem"
REASONS = {"no_picture": "no picture", "wrong_picture": "wrong picture", "wrong_info": "wrong name, number or set", "wrong_price": "wrong price", "duplicate": "a duplicate", "fake": "doesn't exist / fake", "other": "something else"}


def path():
    return os.path.join(dailylog.log_dir(), "reported_items.json")


def load():
    try:
        with open(path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d):
    os.makedirs(dailylog.log_dir(), exist_ok=True)
    with open(path(), "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


def store(items):
    """Keep the server's list [{game, item_id, name, count, reasons: {reason: n}, notes: [..]}], most reported first.  -> how many items"""
    d = {}
    for it in sorted(items or [], key=lambda x: -int(x.get("count") or 0)):
        if it.get("game") and it.get("item_id"):
            d.setdefault(it["game"], {})[str(it["item_id"])] = {"name": it.get("name", ""), "count": int(it.get("count") or 0), "reasons": it.get("reasons") or {}, "notes": (it.get("notes") or [])[:5]}
    _save(d)
    return sum(len(v) for v in d.values())


def ids(game):
    """The reported item ids of a game, most reported first."""
    return list(load().get(game, {}))


def first(game, rows, key=lambda r: r):
    """rows with the reported ones at the front (most reported first), the others in their own order."""
    rank = {i: n for n, i in enumerate(ids(game))}
    return sorted(rows, key=lambda r: rank.get(str(key(r)), len(rank)))


def done(game, item_ids):
    """A run looked at these: they are no longer 'to do first'.  -> the ids that were on the list"""
    d = load()
    gone = [str(i) for i in item_ids if str(i) in d.get(game, {})]
    for i in gone:
        d[game].pop(i)
    if gone:
        _save(d)
    return gone


def to_review_list():
    """Every reported item waits on the owner's review list with what players said.  -> how many were listed"""
    n = 0
    for game, items in load().items():
        for iid, it in items.items():
            why = ", ".join(f"{REASONS.get(k, k)} x{v}" for k, v in sorted(it["reasons"].items(), key=lambda kv: -kv[1])) or "a problem"
            notes = (" Players wrote: " + " / ".join(f'"{x[:120]}"' for x in it["notes"]) + ".") if it["notes"] else ""
            plural = "s" if it["count"] != 1 else ""
            q = f"Players reported a problem with {it['name'] or iid} ({it['count']} report{plural}): {why}.{notes} Yes = there is a problem (it stays on your list to fix); No = it is fine."
            if reviewlist.add_item(KIND, game, iid, q, source=SOURCE):
                n += 1
    return n


reviewlist.register(KIND, apply=lambda item, answer, value, ctx: "a real problem, noted" if answer == "yes" else "checked: no problem")
