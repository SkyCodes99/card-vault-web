"""Set pictures for sets the card database has no logo for: the pictures listed on Collectr's Pokémon sets page, matched by set name."""
import re

_URL = "https://public.getcollectr.com/public-assets/catalog-groups/group_{}.png?optimizer=image&format=webp&width=600&quality=80"
_cache = {}


def _norm(s):
    s = (s or "").lower().replace("&", " and ").replace("é", "e").replace("'", "").replace("’", "")
    s = re.sub(r"^(sv|swsh|sm|xy|bw|dp|hgss)\s*[:\-]\s*", "", s)
    s = s.replace("pokemon", "").replace("pokémon", "")
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    return s


def _groups():
    if "g" not in _cache:
        from .collectr_data import GROUPS             # a python module (not a data file) so it also works inside the packaged app and the browser build
        _cache["g"] = {_norm(n): gid for n, gid in GROUPS}
    return _cache["g"]


_ALIAS = {"base": "base set unlimited", "base set": "base set unlimited", "151": "151", "mcdonalds collection": "mcdonalds promos",
          "scarlet and violet": "scarlet and violet base set", "sword and shield": "sword and shield base set", "sun and moon": "sun and moon base set",
          "xy": "xy base set", "black and white": "black and white", "crown zenith galarian gallery": "crown zenith galarian gallery",
          "shining fates shiny vault": "shining fates shiny vault", "hidden fates shiny vault": "hidden fates shiny vault",
          "30th classic collection": "30th celebration classic collection", "celebrations classic collection": "celebrations classic collection",
          "radiant collection": "generations radiant collection", "svp black star promos": "scarlet and violet promo", "swsh black star promos": "sword and shield promo",
          "sm black star promos": "sun and moon promo", "xy black star promos": "xy promos", "bw black star promos": "black and white promos",
          "hgss black star promos": "hgss promos", "dp black star promos": "diamond and pearl promos", "mep black star promos": "mega evolution promos",
          "wizards black star promos": "wotc promo", "pop series": "pop series", "pokemon go": "go", "mega evolution energy": "", "scarlet and violet energy": ""}


def group_for(set_id, name):
    """Collectr group id for a set, or None."""
    g = _groups()
    n = _norm(name)
    m = re.match(r"^mcdonalds collection (\d{4})$", n)
    if m:
        return g.get("mcdonalds 25th anniversary promos") if m.group(1) == "2021" else g.get("mcdonalds promos " + m.group(1))
    for cand in (n, _ALIAS.get(n), n.replace(" trainer gallery", " trainer gallery"), re.sub(r"^ex ", "ex ", n)):
        if cand and cand in g:
            return g[cand]
    if "ex " + n in g:
        return g["ex " + n]
    return None


def url_for(set_id, name):
    gid = group_for(set_id, name)
    return _URL.format(gid) if gid else ""
