"""Collectibles beyond the card games: Funko Pop! figures and accessories (playmats, displays...).  Read once from free public sources and stored in the same kind of list as a card game, so owning,
portfolios, search, prices and pictures all work the same way.

  funko        TCGplayer's Funko category (names, number, fandom, exclusive / chase, prices) joined with the open hobbyDB-derived list kennymkchan/funko-pop-data (MIT licence: ~24,000 names and pictures,
               no prices).  A fandom (Television, Movies, Animation, Disney, Marvel, Games ...) is a "set"; the product line (Pop! Vinyl, Wacky Wobblers, Pocket Pop! ...) is its "series".
  accessories  TCGplayer's Playmats category (every brand, Pokémon and other games) plus the deck-box / storage groups that name a game.  A brand's group is a "set"; the kind of thing is the "series".

Pictures stay on the sources' own servers (only the addresses are stored), so the list is a few megabytes."""
import csv
import io
import json
import os
import re
import time

from . import sync
from .db import open_cards_conn, sort_key  # noqa: F401
from .tcgcsv import BASE, TcgCsvProvider, _clean, _ext, norm_name, pick_price_row

FUNKO_CSV = "https://raw.githubusercontent.com/kennymkchan/funko-pop-data/master/funko_pop.csv"

# ----------------------------------------------------------------------------------------------------- Funko
_GENRE_FIX = {"televsion": "Television", "movie": "Movies", "game": "Games", "video games": "Games", "icons": "Icons", "": "Other", "funko": "Funko Originals", "custom": "Other"}
_BUCKET = {
    "Television": "TV & Movies", "Movies": "TV & Movies", "Movie Moments": "TV & Movies", "Star Wars": "TV & Movies", "Harry Potter": "TV & Movies", "Game of Thrones": "TV & Movies",
    "Fantastic Beasts and Where to Find Them": "TV & Movies", "Doctor Who": "TV & Movies", "Stranger Things": "TV & Movies", "Director": "TV & Movies", "Broadway": "TV & Movies", "SNL": "TV & Movies",
    "Animation": "Animation & Cartoons", "Disney": "Animation & Cartoons", "Pixar": "Animation & Cartoons", "Hello Kitty": "Animation & Cartoons", "Sanrio": "Animation & Cartoons",
    "South Park": "Animation & Cartoons", "Sesame Street": "Animation & Cartoons", "Pokemon": "Animation & Cartoons", "Asia": "Animation & Cartoons", "Monster High": "Animation & Cartoons",
    "Marvel": "Comics & Heroes", "Heroes": "Comics & Heroes", "DC": "Comics & Heroes", "Comics": "Comics & Heroes", "Comic Moments": "Comics & Heroes", "Books": "Comics & Heroes",
    "Games": "Video & Board Games", "8-Bit": "Video & Board Games", "Halo": "Video & Board Games", "Board Games": "Video & Board Games", "Dorbz": "Video & Board Games",
    "NFL": "Sports", "NBA": "Sports", "MLB": "Sports", "NHL": "Sports", "WWE": "Sports", "UFC": "Sports", "Football": "Sports", "Basketball": "Sports", "Hockey": "Sports", "Wrestling": "Sports",
    "Rocks": "Music", "Music": "Music", "Royals": "Music", "Drag Queens": "Music",
}
_LINES = ("Wacky Wobblers", "Pocket Pop!", "Dorbz", "Plushies", "ReAction Figures", "Funko Prototypes", "Pop! Pins", "Pop! Tees & Apparel", "Pop! Rides", "Pop! Keychain", "Mystery Minis", "Vinyl Soda",
          "Pop! Deluxe", "Pop! Albums", "Pop! Moments", "Paka Paka", "Pop! Pez", "Pop! Pins")
_FANDOM_TAGS_SKIP = {"Pop! Vinyl", "Pop! Pins", "Pop! Tees & Apparel", "Pop! Keychain", "Pop! Rides", "Pop! Deluxe", "Pop! Albums", "Pop! Moments", "Pop! Pez", "Pop! Pop!", "Chase Pieces"}


def _fandom_from_tags(tags):
    """'Pop! Television;Pop! Vinyl' -> 'Television' (the fandom the person browses by)."""
    keep = lambda rest: ("Pop! " + rest) if rest[:1].islower() else rest                 # 'Pop! and Shirt Pack' is not 'and Shirt Pack'
    for t in tags:
        if t.startswith("Pop! ") and t not in _FANDOM_TAGS_SKIP:
            return keep(t[5:].strip())
    for t in tags:
        if t not in _FANDOM_TAGS_SKIP and "xclusive" not in t and "hase" not in t and t != "Pop! Vinyl":
            return keep(t.replace("Pop! ", "").strip()) or "Other"
    return "Other"


def _line_from_tags(tags):
    for t in tags:
        if t in _LINES and t != "Pop! Pins":
            return t
    if "Pop! Pins" in tags:
        return "Pop! Pins"
    return "Pop! Vinyl"


def _rarity_from_tags(tags):
    t = ";".join(tags).lower()
    if "chase" in t:
        return "Chase"
    if "exclusive" in t:
        return "Exclusive"
    return "Standard"


class FunkoProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("funko", 29, type_field="Series")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            day = time.strftime("%Y-%m-%d")
            progress("Reading Funko Pop! from TCGplayer…", 0, 0)
            made = {}
            seen_names = set()

            def put_set(fandom):
                sid = "fd:" + re.sub(r"[^a-z0-9]+", "-", fandom.lower()).strip("-")
                if sid not in made:
                    made[sid] = fandom
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, fandom, _BUCKET.get(fandom, "Other fandoms"), "", 0, 0, None))
                return sid

            n = 0
            for g in self._get("groups"):
                if cancel.is_set():
                    return n
                gid = g["groupId"]
                products, prices = self._get(f"{gid}/products"), self._get(f"{gid}/prices")
                by_pid = {}
                for pr in prices:
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                for p in products:
                    ext = _ext(p)
                    genre = _GENRE_FIX.get((ext.get("Genre") or "").strip().lower(), (ext.get("Genre") or "").strip() or "Other")
                    sid = put_set(genre)
                    usd, kind = pick_price_row(by_pid.get(p["productId"], {}))
                    number = str(ext.get("Number") or "")
                    nums = re.findall(r"\d+", number)
                    nm = p["name"].strip()
                    raw = {"productId": p["productId"], "url": p.get("url"), "ext": {k: v for k, v in ext.items() if k in ("Series", "Model", "UPC", "GTIN", "Printing", "Genre")}}
                    conn.execute(
                        "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                        (str(p["productId"]), sid, number, int(nums[-1]) if nums else 100000, nm, p.get("imageUrl"), "Pop! Vinyl", ext.get("Rarity") or "Standard", ext.get("Series") or "",
                         _clean(ext.get("Description")), usd, kind, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
                    seen_names.add(norm_name(re.sub(r"\s*\(.*?\)\s*$", "", nm.split(": ")[-1])))
                    n += 1
            conn.commit()
            # ---- the open list of ~24,000 more names and pictures (no prices)
            progress("Reading the open Funko Pop! list…", 0, 0)
            raw_csv = sync._get(FUNKO_CSV, as_json=False)
            added = 0
            if raw_csv:
                text = raw_csv.decode("utf-8", errors="replace")
                for row in csv.DictReader(io.StringIO(text)):
                    title, handle, img = (row.get("title") or "").strip(), (row.get("handle") or "").strip(), (row.get("imageName") or "").strip()
                    if not title or not handle:
                        continue
                    tags = [t.strip() for t in (row.get("series") or "").split(";") if t.strip()]
                    fandom = _fandom_from_tags(tags)
                    if norm_name(title) in seen_names and fandom != "Other":
                        continue                                   # already listed (with a price) from TCGplayer
                    sid = put_set(fandom)
                    conn.execute(
                        "INSERT OR IGNORE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                        ("hdb:" + handle, sid, "", 100000, title, img, _line_from_tags(tags), _rarity_from_tags(tags), "; ".join(t for t in tags if t != "Pop! Vinyl")[:120], "", json.dumps({"normal": True}),
                         json.dumps({"handle": handle, "tags": tags}, ensure_ascii=False)))
                    added += 1
                    if added % 4000 == 0:
                        conn.commit()
                        progress("Reading the open Funko Pop! list…", added, 24000)
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
            conn.execute("DELETE FROM sets WHERE id LIKE 'fd:%' AND NOT EXISTS (SELECT 1 FROM cards WHERE set_id=sets.id)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        conn = open_cards_conn(gdir)
        try:
            day, hit = time.strftime("%Y-%m-%d"), 0
            for g in self._get("groups"):
                by_pid = {}
                for pr in self._get(f"{g['groupId']}/prices"):
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                for pid, subs in by_pid.items():
                    usd, kind = pick_price_row(subs)
                    if usd is not None:
                        conn.execute("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", (usd, kind, day, str(pid)))
                        hit += 1
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return hit
        finally:
            conn.close()


# ------------------------------------------------------------------------------------------------ accessories
_GAME_WORDS = [("pokemon", "Pokémon"), ("pokémon", "Pokémon"), ("magic", "Magic: The Gathering"), ("mtg", "Magic: The Gathering"), ("yu-gi-oh", "Yu-Gi-Oh!"), ("yugioh", "Yu-Gi-Oh!"), ("one piece", "One Piece"),
               ("lorcana", "Lorcana"), ("riftbound", "Riftbound"), ("flesh and blood", "Flesh and Blood"), ("dragon ball", "Dragon Ball"), ("union arena", "Union Arena"), ("gundam", "Gundam"),
               ("digimon", "Digimon"), ("star wars", "Star Wars"), ("marvel", "Marvel"), ("sorcery", "Sorcery"), ("keyforge", "KeyForge"), ("hololive", "hololive"), ("cookierun", "CookieRun"),
               ("vanguard", "Cardfight!! Vanguard"), ("weiss", "Weiss Schwarz"), ("wand company", "The Wand Company")]


def _game_of(name, group):
    low = (name + " " + group).lower()
    for w, label in _GAME_WORDS:
        if w in low:
            return label
    return "Other games"


class AccessoriesProvider(TcgCsvProvider):
    """Playmats (TCGplayer category 35: every brand) plus the deck-box / storage / display groups of category 14 and 51 that name a game."""
    SOURCES = ((35, "Playmats", None), (14, "Deck boxes, sleeves & storage", ("pokemon", "playmat", "display", "wand", "anime")), (51, "Collectible storage & displays", ("pokemon", "display", "wand")))

    def __init__(self):
        super().__init__("accessories", 35, type_field="Series")

    def _cat(self, cat, path):
        d = sync._get(f"{BASE}/{cat}/{path}")
        return (d or {}).get("results", [])

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        self._gdir = gdir
        conn = open_cards_conn(gdir)
        try:
            day = time.strftime("%Y-%m-%d")
            groups = []
            for cat, serie, want in self.SOURCES:
                for g in self._cat(cat, "groups"):
                    if want is None or any(w in g["name"].lower() for w in want):
                        groups.append((cat, serie, g))
            done = [0]

            def one(item):
                cat, _serie, g = item
                return self._cat(cat, f"{g['groupId']}/products"), self._cat(cat, f"{g['groupId']}/prices")

            def got(item, result):
                cat, serie, g = item
                products, prices = result
                done[0] += 1
                if products:
                    sid = f"{cat}-{g['groupId']}"
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, re.sub(r"\s+Playmats?$", "", g["name"]) if cat == 35 else g["name"], serie, (g.get("publishedOn") or "")[:10], len(products), len(products), None))
                    by_pid = {}
                    for pr in prices:
                        by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                    for p in products:
                        usd, kind = pick_price_row(by_pid.get(p["productId"], {}))
                        ext = _ext(p)
                        name = re.sub(r"\s+", " ", p["name"]).strip()
                        raw = {"productId": p["productId"], "url": p.get("url"), "ext": {k: v for k, v in ext.items() if k in ("Series", "Model", "UPC", "GTIN", "Printing")}}
                        conn.execute(
                            "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                            (str(p["productId"]), sid, "", 100000, name, p.get("imageUrl"), serie, ext.get("Rarity") or "", _game_of(name, g["name"]), _clean(ext.get("Description")), usd, kind, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
                if done[0] % 8 == 0:
                    conn.commit()
                progress("Reading accessories…", done[0], len(groups))

            sync._pool(groups, one, cancel, got, workers=6)
            conn.commit()
            self._wand_company(conn, day)
            try:
                self._skate_decks(conn, day, cancel)
            except Exception as e:  # noqa: BLE001 - the skateboards are an extra: the rest of the list is fine without them today
                print("accessories: skateboards not read:", str(e)[:80], flush=True)
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    # ---- licensed skateboards: Bear Walker and Santa Cruz make decks with the pop-culture fandoms the app already follows (Pokemon, Marvel, Star Wars, Yu-Gi-Oh!, One Piece ...)
    FANDOMS = (("Pokémon", r"pok[eé]mon|pikachu|charizard|eevee|gengar|mewtwo|gyarados|cubone"), ("Yu-Gi-Oh!", r"yu-?gi-?oh|blue-eyes|dark magician|exodia"), ("One Piece", r"one piece|straw hat|luffy|kaido"),
               ("Marvel", r"marvel|spider-?man|iron man|hulk|wolverine|black panther|venom|avengers|deadpool|x-men|thor\b|captain america"), ("Star Wars", r"star wars|mandalorian|darth|yoda|grogu|stormtrooper"),
               ("DC", r"\bdc\b|batman|joker|mr\.? freeze|superman|wonder woman|harley"), ("TMNT", r"tmnt|ninja turtles|mutant mayhem"), ("Godzilla", r"godzilla|kong\b"), ("Stranger Things", r"stranger things"),
               ("Destiny", r"destiny"), ("Disney", r"disney|mickey|pixar|toy story|lilo|stitch"), ("Dragon Ball", r"dragon ball|goku|vegeta"), ("Lorcana", r"lorcana"), ("Sanrio", r"sanrio|hello kitty|kuromi|cinnamoroll"),
               ("Magic: The Gathering", r"magic: the gathering|magic the gathering|\bmtg\b|planeswalker"), ("Digimon", r"digimon"), ("Sonic", r"sonic the hedgehog|\bsonic\b"), ("Nintendo", r"nintendo|mario|zelda|kirby"),
               ("The Simpsons", r"simpsons"), ("Transformers", r"transformers|optimus"), ("Jurassic Park", r"jurassic"), ("Halo", r"\bhalo\b"))

    def _fandom_of(self, text):
        for name, rx in self.FANDOMS:
            if re.search(rx, text, re.I):
                return name
        return ""

    def _santa_cruz_licensed(self, cancel, seen):
        """Santa Cruz's licensed decks / completes / griptape from the skate shop's whole product feed (about 10,000 products, so it is read once a week and the matches are kept)."""
        path = os.path.join(getattr(self, "_gdir", "") or "", "santacruz_licensed.json")
        try:
            if os.path.exists(path) and time.time() - os.path.getmtime(path) < 7 * 86400:
                return [p for p in json.load(open(path, encoding="utf-8")) if p["id"] not in seen]
        except (OSError, ValueError):
            pass
        found = []
        for pg in range(1, 60):
            if cancel.is_set():
                return []
            d = _shop_get(f"https://tgmskateboards.com/products.json?limit=250&page={pg}").get("products") or []
            if not d:
                break
            for p in d:
                if "santa cruz" in ((p.get("vendor") or "") + " " + p.get("title", "")).lower() and self._fandom_of(p.get("title", "") + " " + " ".join(p.get("tags") or [])) and                         (p.get("product_type") in ("Decks", "Completes", "Grip Tape") or re.search(r"deck|complete|grip", p.get("title", ""), re.I)):
                    found.append({k: p.get(k) for k in ("id", "handle", "title", "vendor", "product_type", "tags", "variants", "images", "body_html")})
            time.sleep(0.4)
        if found:
            try:
                json.dump(found, open(path, "w", encoding="utf-8"))
            except OSError:
                pass
        return [p for p in found if p["id"] not in seen]

    def _skate_decks(self, conn, day, cancel):
        """Bear Walker (its own Shopify shop) and Santa Cruz (through a skate shop's feed, since Santa Cruz's own site has none): decks / completes / griptape of the licensed fandoms only."""
        src = []
        for pg in range(1, 12):
            if cancel.is_set():
                return 0
            d = _shop_get(f"https://bearwalker.com/products.json?limit=250&page={pg}").get("products") or []
            if not d:
                break
            src += [("Bear Walker", "https://bearwalker.com", p) for p in d if re.search(r"deck|cruiser|complete", (p.get("product_type") or "") + " " + p.get("title", ""), re.I) and not re.search(r"guitar|hoodie|tee\b|shirt", p.get("title", ""), re.I)]
            time.sleep(0.4)
        seen = set()
        for path in ("/collections/santa-cruz-x-pokemon/products.json", "/collections/stranger-things-x-santa-cruz/products.json", "/collections/skateboard-deck/products.json"):
            for pg in range(1, 8):
                if cancel.is_set():
                    return 0
                d = _shop_get(f"https://tgmskateboards.com{path}?limit=250&page={pg}").get("products") or []
                if not d:
                    break
                for p in d:
                    if p["id"] in seen or "santa cruz" not in ((p.get("vendor") or "") + " " + p.get("title", "")).lower():
                        continue
                    if p.get("product_type") in ("Decks", "Completes", "Grip Tape") or re.search(r"deck|complete|grip", p.get("title", ""), re.I):
                        seen.add(p["id"])
                        src.append(("Santa Cruz Skateboards", "https://tgmskateboards.com", p))
                time.sleep(0.4)
        for p in self._santa_cruz_licensed(cancel, seen):
            src.append(("Santa Cruz Skateboards", "https://tgmskateboards.com", p))
        n = 0
        for brand, base, p in src:
            text = p.get("title", "") + " " + " ".join(p.get("tags") or [])
            fandom = self._fandom_of(text)
            if not fandom:
                continue                                                        # an artist deck or a plain logo deck: not one of the app's fandoms
            sid = "skate-" + re.sub(r"[^a-z0-9]+", "-", brand.lower()).strip("-")
            conn.execute("INSERT OR IGNORE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,0,0,NULL)", (sid, brand, "Skateboards", ""))
            v0 = (p.get("variants") or [{}])[0]
            try:
                price = float(v0.get("price")) if v0.get("price") else None
            except ValueError:
                price = None
            kind = "Skateboard completes" if re.search(r"complete", p.get("title", ""), re.I) else "Griptape" if re.search(r"grip", p.get("title", ""), re.I) and not re.search(r"deck", p.get("title", ""), re.I) else "Skateboard decks"
            img = ((p.get("images") or [{}])[0].get("src") or "").split("?")[0]
            avail = any(x.get("available") for x in p.get("variants") or [])
            raw = {"url": f"{base}/products/{p.get('handle')}", "tags": p.get("tags") or [], "ext": {"Brand": brand, "Availability": "In stock at the shop" if avail else "Sold out"}}
            conn.execute("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                         (f"skate:{sid}:{p.get('handle')}", sid, "", 100000 + n, html_unescape(p.get("title", "")), img, kind, "", fandom,
                          re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html_unescape(p.get("body_html") or "")))[:400], price, "retail price" if price is not None else None, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
            n += 1
        for sid in ("skate-bear-walker", "skate-santa-cruz-skateboards"):
            conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
        conn.commit()
        return n

    def _wand_company(self, conn, day):
        """The Wand Company's Pokemon Poke Ball replicas with their display cases (they are not sold through TCGplayer): read from the maker's own image library page."""
        try:
            raw = sync._get("https://www.thewandcompany.com/photos/sets/pokemon-1/", as_json=False)
            text = raw.decode("utf-8", errors="replace") if raw else ""
        except Exception:  # noqa: BLE001
            return 0
        n, pics = 0, {}
        conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", ("wand-pokemon", "The Wand Company - Pokemon Poke Balls", "Displays & replicas", "", 0, 0, None))
        for chunk in text.split('<li class="album">')[1:]:
            src = re.search(r'src="(https://www\.thewandcompany\.com/koken/[^"]+\.jpg)"', chunk)
            nm = re.search(r"<h4>\s*<a[^>]*>\s*([^<]+?)\s*</a>", chunk)
            ds = re.search(r"<p>\s*([^<]+?)\s*</p>", chunk)
            if not src or not nm:
                continue
            name = nm.group(1).strip()
            if "range" in name.lower():
                continue
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
            conn.execute(
                "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                ("wand:" + slug, "wand-pokemon", "", 1000 + n, name + " (The Wand Company)", src.group(1), "Displays & replicas", "Replica with display case", "Pok\u00e9mon",
                 (ds.group(1).strip() if ds else "") + " Die-cast electronic replica with its own display case.", json.dumps({"normal": True}), json.dumps({"source": "thewandcompany.com"})))
            n += 1
            pics[name.lower()] = src.group(1)
        # The 25th Anniversary editions (2021) are not separate albums on the maker's site: the first production run came in a limited silver 'Anniversary Year' case (later runs: black),
        # and the Master Ball was a Pokemon Center exclusive limited to 5,000 numbered pieces with the 25th anniversary logo on its case.
        for ball, what, extra in (("Poké Ball", "25th Anniversary Silver Box Edition", "First production run, in the limited silver 25th Anniversary Year display case (later runs came in a black case)."),
                                  ("Ultra Ball", "25th Anniversary Silver Box Edition", "First production run, in the limited silver 25th Anniversary Year display case (later runs came in a black case)."),
                                  ("Master Ball", "25th Anniversary Edition (Pokémon Center exclusive)", "Pokémon Center exclusive, limited to 5,000 individually numbered pieces, with the 25th anniversary logo on its illuminated case.")):
            pic = pics.get(ball.lower()) or pics.get(ball.lower().replace("é", "e"))
            if not pic:
                continue
            slug = re.sub(r"[^a-z0-9]+", "-", f"{ball} 25th anniversary".lower()).strip("-")
            conn.execute(
                "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                ("wand:" + slug, "wand-pokemon", "", 2000 + n, f"{ball} - {what} (The Wand Company)", pic, "Displays & replicas", "Replica with display case", "Pokémon",
                 extra + " Die-cast electronic replica with its own display case.", json.dumps({"normal": True}), json.dumps({"source": "thewandcompany.com + retailer listings", "edition": "25th Anniversary"})))
            n += 1
        conn.execute("UPDATE sets SET total=?, official=? WHERE id='wand-pokemon'", (n, n))
        conn.commit()
        return n

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        conn = open_cards_conn(gdir)
        try:
            day, hit = time.strftime("%Y-%m-%d"), 0
            for (sid,) in conn.execute("SELECT id FROM sets WHERE id NOT LIKE 'wand%'").fetchall():
                cat, gid = sid.split("-", 1)
                by_pid = {}
                for pr in self._cat(int(cat), f"{gid}/prices"):
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                for pid, subs in by_pid.items():
                    usd, kind = pick_price_row(subs)
                    if usd is not None:
                        conn.execute("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", (usd, kind, day, str(pid)))
                        hit += 1
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return hit
        finally:
            conn.close()


# ------------------------------------------------------------------------------------------ designer toys from open shop feeds
# A Shopify shop lists everything it sells at <shop>/products.json (public, no key).  Each toy becomes one list entry with its picture, price, edition size ("limited edition of 250") and what makes it exclusive.
# Entries are never deleted when the shop stops listing them, so a daily refresh only ever ADDS: new releases arrive and sold-out toys stay in the list.
_EDITION = re.compile(r"(?:limited edition of|edition of|limited to|limited edition|\bLE\b[:\s]+|limited run of|run of)\s*(?:only\s*)?(\d[\d,]*)(?![\d,]*\s*(?:\"|inch|in\b|oz|-piece|piece puzzle|per\b|each\b|a\s+person|/))", re.I)
_EXCL = (("creature club", "Creature Club members"), ("convention", "Convention exclusive"), ("sdcc", "San Diego Comic-Con"), ("nycc", "New York Comic Con"), ("lottery", "Lottery"),
         ("early access", "Early access"), ("exclusive", "Exclusive"), ("prototype", "Prototype"), ("artist proof", "Artist proof"), ("blind box", "Blind box"), ("mystery", "Mystery"))


def html_unescape(s):
    import html as _h
    return _h.unescape(s or "")


def _shop_get(url):
    raw = sync._get(url, as_json=False)
    try:
        return json.loads(raw.decode("utf-8")) if raw else {}
    except ValueError:
        return {}


def _clean_title(t):
    """The toy's own name: pre-order notes and the like are not part of it."""
    t = re.sub(r"\s*[-–]?\s*(pre-?order|preorder)\b.*$", "", t or "", flags=re.I)
    t = re.sub(r"\s*[-–]?\s*DAMAGED CARTON\s*$", "", t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()


_PROOF = re.compile(r"\b(art(?:ist)? proofs?|prototypes?|protos?|proof)\b", re.I)
_NAME_NOISE = re.compile(r"\b(limited|edition|vinyl|figures?|resin|officially licensed|licensed|exclusive|soft|chomp|chomper|dumpster fire|collector'?s)\b", re.I)
_EXCL_TAIL = re.compile(r"\b(NYCC|SDCC|C2E2|DCon|Dcon|HMBR|Creature Club)\b(?:\s+Exclusive)?", re.I)


def short_name(title, game):
    """'Limited Silver Skeleton Edition Chomp Vinyl Figure' -> 'Silver Skeleton'; 'Dumpster Fire - Donut Green Vinyl Figure' -> 'Donut Green'.  What kind of toy it is stays in its group (Chomps, Chompers, Plush ...)."""
    t = html_unescape(title or "")
    if re.search(r'I\s*"?Chomp"?\s*NY', t, re.I):
        return "I Chomp NY"
    if re.search(r"chomp and chomper", t, re.I):
        return "Chomp & Chomper (Plush)" if re.search(r"plush", t, re.I) else "Chomp & Chomper"
    t = re.sub(r"\s+[Bb]y\s+[A-Z][^()\[\]]*$", "", t)                                  # '... By Jaide Sen Su' is the designer, shown in the details
    t = re.sub(r"\bFrozen Culture\b", " ", t, flags=re.I)
    t = _EXCL_TAIL.sub(" ", t)
    squishy = bool(re.search(r"\bsquishy\b", t, re.I))
    mini = bool(re.search(r"\bmini\b", t, re.I))
    plush = bool(re.search(r"\bplush\b", t, re.I))
    if game == "dumpsterfires":
        t = re.sub(r"\bDumpster Fire\b", " ", t, flags=re.I)
    t = _NAME_NOISE.sub(" ", t)
    t = re.sub(r"\b(squishy|mini|plush|single|single figure|set|bundle)\b", " ", t, flags=re.I)
    t = re.sub(r"\s+[-–|:]+\s+", " - ", t)
    t = re.sub(r"\s+", " ", t).strip(" -–|:,&")
    t = re.sub(r"^(?:-\s*)+|(?:\s*-)+$", "", t).strip()
    if not t:
        t = "Original"
    suffix = " (Squishy)" if squishy else " (Mini)" if mini else ""
    if plush and "plush" not in t.lower():
        suffix = suffix or " (Plush)"
    return (t + suffix).strip()


class ShopifyToyProvider(TcgCsvProvider):
    """game_id, shop address, optional collections to read first (they include sold-out toys), a test for which products are toys, and how to name the line each belongs to."""

    def __init__(self, game_id, base, collections=(), keep=None, line=None, type_field="Designer", exclude=None, lines_first=()):
        super().__init__(game_id, 0, type_field=type_field)
        self.base, self.collections, self.keep, self.line = base.rstrip("/"), tuple(collections), keep or (lambda p: True), line or (lambda p: "Toys")
        self.exclude = exclude
        self.lines_first = tuple(lines_first)

    def _products(self, cancel):
        seen, out = set(), []
        paths = [f"/collections/{c}/products.json" for c in self.collections] + ["/products.json"]
        for path in paths:
            for pg in range(1, 40):
                if cancel.is_set():
                    return out
                d = _shop_get(f"{self.base}{path}?limit=250&page={pg}").get("products") or []
                if not d:
                    break
                for p in d:
                    if p["id"] not in seen:
                        seen.add(p["id"])
                        out.append(p)
        return out

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the shop…", 0, 0)
            day = time.strftime("%Y-%m-%d")
            made = {}
            if self.exclude:                                                  # entries kept from earlier runs that the rules now leave out (coffee, patches, hats, duplicates ...)
                for cid, nm in conn.execute("SELECT id, name FROM cards WHERE id LIKE 'shp:%'").fetchall():
                    if self.exclude.search(nm) or re.search(r"pre-?order|damaged-carton", cid):
                        conn.execute("DELETE FROM cards WHERE id=?", (cid,))
            conn.execute("CREATE TABLE IF NOT EXISTS cards_extra AS SELECT * FROM cards WHERE 0")      # art proofs and prototypes wait here; they are shown only when the person turns them on
            conn.execute("DELETE FROM cards_extra WHERE id LIKE 'shp:%'")
            seen_titles = set()
            used_names, line_first = {}, {}
            products = self._products(cancel)
            norm = lambda p: re.sub(r"[^a-z0-9]+", " ", _clean_title(p["title"]).lower()).strip()
            is_pre = lambda p: bool(re.search(r"pre-?order", (p.get("handle") or "") + " " + (p.get("title") or ""), re.I))
            regular = {norm(p) for p in products if not is_pre(p)}
            for p in products:
                if not self.keep(p):
                    continue
                tkey = norm(p)
                if tkey in seen_titles or (is_pre(p) and tkey in regular):
                    continue                                                  # a pre-order copy of a toy that is already listed
                seen_titles.add(tkey)
                line = self.line(p)
                sid = f"{self.game_id}:" + re.sub(r"[^a-z0-9]+", "-", line.lower()).strip("-")
                if sid not in made:
                    made[sid] = line
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, line, "Toys", "", 0, 0, None))
                body = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html_unescape(p.get("body_html") or ""))).strip()
                title = _clean_title(html_unescape(p["title"]))
                m = _EDITION.search(title + " " + body)
                edition = int(m.group(1).replace(",", "")) if m else None
                if re.search(r"timed edition|determine the edition|size of the edition is determined", body, re.I):
                    edition = None                                              # a pre-order run: the number made is decided by the orders, there is no fixed count
                low = (title + " " + " ".join(p.get("tags") or []) + " " + body[:400]).lower()
                excl = [label for key, label in _EXCL if key in low]
                v0 = (p.get("variants") or [{}])[0]
                try:
                    price = float(v0.get("price")) if v0.get("price") else None
                except ValueError:
                    price = None
                avail = any(v.get("available") for v in p.get("variants") or [])
                by = re.search(r"\bby ([A-Z][^|(\[]{2,40}?)(?:\s*$|\s+[-|(\[])", title)
                img = ((p.get("images") or [{}])[0].get("src") or "").split("?")[0]
                published = (p.get("published_at") or "")[:10]
                rarity = (f"Limited edition of {edition:,}" if edition else "Open edition") + ("" if avail else " (sold out)")
                facts = {"Edition": (f"Limited to {edition:,} pieces" if edition else "Open edition (no stated limit)"), "Exclusive to": ", ".join(excl) if excl else "Not exclusive",
                         "Released": published or "unknown", "Availability": "In stock at the shop" if avail else "Sold out", "Designer": (by.group(1).strip() if by else ""), "Shop page": f"{self.base}/products/{p.get('handle')}"}
                raw = {"handle": p.get("handle"), "url": f"{self.base}/products/{p.get('handle')}", "edition": edition, "exclusive": excl, "available": avail, "published": published,
                       "tags": p.get("tags") or [], "images": [i.get("src") for i in (p.get("images") or [])[:6]], "ext": {k: v for k, v in facts.items() if v}}
                lines_order = 0 if line in self.lines_first else 1
                order = lines_order * 100000000 + (int(published.replace("-", "") or 0) if published else 99999999)           # main line first, oldest to newest
                proof = bool(_PROOF.search(title)) or line == "Art proofs & prototypes"
                nm = short_name(title, self.game_id)
                if nm.lower() in used_names and used_names[nm.lower()] != str(p.get("handle")):
                    tag = (excl[0] if excl else (published[:4] if published else "")).strip()
                    nm = f"{nm} ({tag})" if tag else f"{nm} ({published or 'II'})"
                used_names[nm.lower()] = str(p.get("handle"))
                if published and (sid not in line_first or published < line_first[sid]):
                    line_first[sid] = published                              # a group is dated by its first toy, so groups sit oldest first too
                raw["ext"]["Shop name"] = title
                if proof:
                    sid = f"{self.game_id}:proofs"
                    made.setdefault(sid, "Art proofs & prototypes")
                table = "cards_extra" if proof else "cards"
                cid = "shp:" + str(p.get("handle"))
                conn.execute("DELETE FROM cards_extra WHERE id=?", (cid,))
                if proof:
                    conn.execute("DELETE FROM cards WHERE id=?", (cid,))
                conn.execute(
                    f"INSERT OR REPLACE INTO {table}(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                    (cid, sid, "", order, nm, img, p.get("product_type") or line, rarity,
                     line, (", ".join(excl) + ". " if excl else "") + body[:600], price, "retail price" if price is not None else None, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
            conn.execute("DELETE FROM sets WHERE id LIKE ? AND id LIKE '%:proofs'", (self.game_id + ":%",))             # the proofs group exists only while the person shows them (see proofs.py)
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), release_date=? WHERE id=?", ("0000-01-01" if made.get(sid) in self.lines_first else line_first.get(sid, ""), sid))      # the main line sorts first
            conn.execute("DELETE FROM sets WHERE id LIKE ? AND NOT EXISTS (SELECT 1 FROM cards WHERE set_id=sets.id)", (self.game_id + ":%",))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            try:                                                   # product type, availability, edition, exclusive-to, designer: filters worked out from what the shop says
                from . import gamefacets
                gamefacets.ensure(conn, self.game_id, force=True)
            except Exception as e:  # noqa: BLE001
                print(f"{self.game_id}: filters not built ({str(e)[:80]})", flush=True)
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return self.fetch_catalog(gdir, cancel, progress)          # the shop feed carries the prices: one pass does both


_ACC = re.compile(r"\b(patch|tote|apron|hat|beanie|socks?|grip|protector|prints?|posters?|lottery|membership|trading cards?|full case|case of|shirt|tee|t-shirt|hoodie|mug|tankard|stickers?|pins?|lanyard|luggage|"
                  r"ornament|night light|snow globe|string lights|journal|coloring book|puzzle|deck|ashtray|crochet|pattern|digital|keychain|badge reel|gift card|magnet|flashlight|post ?card|coin|comic|pre-?orders?|damaged carton)\b", re.I)
_COFFEE = re.compile(r"\bchomp coffee\b|\bcoffee (?:pack|bag|cup)\b|\b\d+ ?oz\b|\broast\b", re.I)
_NOT_TOY = re.compile(_ACC.pattern + "|" + _COFFEE.pattern, re.I)                  # what a purge of older entries removes from the Abominable Toys list
_NOT_TOY_SOFT = _ACC                                                              # 100% Soft has real toys with 'coffee' in the name (Coffee Rat), so only the accessory words apply


def _core(title):
    """The toy itself: 'Classic Edition Chomp Vinyl Figure with Sticker' is a figure (the sticker is a free extra), not a sticker."""
    t = _clean_title(title or "")
    t = re.sub(r"\s+(?:with|w/|and)\s+(?:a\s+)?(?:free\s+)?(?:gold\s+)?(?:sticker|pin)s?\b.*$", "", t, flags=re.I)
    t = re.sub(r"\s+bundle\s+with\s+free\b.*$", " bundle", t, flags=re.I)
    return t


_TOY_WORDS = ("figure", "plush", "squishy", "blind bag", "blind box", "gumdrop", "mini chomp", "chomp", "chomper", "mystery box", "resin", "vinyl", "bundle", "set of", "toy")


def _chomp_keep(p):
    t = _core(p.get("title") or "")
    if _ACC.search(t) or _COFFEE.search(t) or p.get("product_type") in ("Apparel", "Print", "Sticker", "Luggage Tag", "Enamel Pin", "Mug", "Gift Card"):
        return False
    low = t.lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    return bool(tags & {"figure", "plush", "squishy"}) or any(w in low for w in _TOY_WORDS)


def _chomp_line(p):
    t = (p.get("title") or "").lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    if _PROOF.search(t):
        return "Art proofs & prototypes"
    if "chomper" in t or "chomper" in tags:
        return "Chompers"
    if "frozen culture" in t:
        return "Frozen Culture"
    if "plush" in t:
        return "Plush"
    if "blind" in t or "mystery" in t or "blind box" in tags or "blind bag" in tags:
        return "Blind boxes"
    if "swomp" in t or "swomp" in tags:
        return "Swomp"
    if "hope" in t and "turtle" in t:
        return "Hope Turtle"
    if "licensed" in tags or "collaboration" in tags or any(w in t for w in ("godzilla", "mothra", "rodan", "bob ross", "zoltar", "care bears", "madballs")):
        return "Collaborations & licensed"
    if "creature club" in tags or "creature club" in t:
        return "Creature Club limited"
    if "chomp" in t or "chomp" in tags:
        return "Chomps"
    return "Misc"                                                    # whatever fits no line above


def _df_keep(p):
    t = _core(p.get("title") or "")
    if _NOT_TOY_SOFT.search(t) or p.get("product_type") in ("Enamel Pin", "Shirts", "Stickers", "Print", "Patch", "Keychain", "AirPods Case", "Board Game", "Journal", "Card Deck", "Coloring Book"):
        return False
    low = t.lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    return p.get("product_type") in ("Toys", "Plush Toy", "Blind Box") or "vinyl figure" in tags or any(w in low for w in ("figure", "plush", "squishy", "ceramic", "mystery box", "blind"))


def _df_line(p):
    t = (p.get("title") or "").lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    if _PROOF.search(t):
        return "Art proofs & prototypes"
    if p.get("product_type") == "Plush Toy" or "plush" in t:
        return "Plush"
    if "squishy" in t or "ceramic" in t:
        return "Squishy & ceramic"
    if "melted" in t:
        return "Melted (artist editions)"
    if "ice cream" in t:
        return "Dumpster Ice Cream"
    if "blind" in t or "mystery box" in t or p.get("product_type") == "Blind Box" or "blind box" in tags:
        return "Blind boxes"
    if "megamoji" in t or "megamoji" in tags:
        return "MEGAMOJI busts"
    if "kaiju kitties" in tags or "kaiju kitt" in t or "screaming boomu" in t:
        return "Kaiju Kitties"
    if "bad vibes" in tags or "bad vibes" in t:
        return "Bad Vibes"
    if "trash fire friends" in tags or "lil meltdown" in t or "pizza rat" in t and "dumpster" not in t or "trash panda" in t and "dumpster" not in t:
        return "Trash Fire Friends"
    if any(w in t for w in ("marvel", "deadpool", "venom", "ghost rider", "x-men", "avengers", "pusheen", "care bears", "galactus", "infinity gauntlet")) or "marvel" in tags:
        return "Collaborations"
    if "dumpster" in t or "dumpster fire" in tags:
        return "Dumpster Fires"
    return "Misc"                                                    # whatever fits no line above


def chomps_provider():
    return ShopifyToyProvider("chomps", "https://abominabletoys.com", keep=_chomp_keep, line=_chomp_line, exclude=_NOT_TOY, lines_first=("Chomps",))


def dumpsterfire_provider():
    return ShopifyToyProvider("dumpsterfires", "https://100soft.shop", collections=("dumpster-fire-archives", "dumpster-fire-toys"), keep=_df_keep, line=_df_line, exclude=_NOT_TOY_SOFT, lines_first=("Dumpster Fires",))


# ------------------------------------------------------------------------------------------------ Pokemon plush (Sitting Cuties / Pokemon fit)
# The regional pages of Bulbapedia (CC BY-NC-SA, read through its public API) list every plush with its picture.  Each Pokemon appears twice - the US "Sitting Cuties" and the Japanese "Pokemon fit"
# - so a person can mark which one they have.
BULBA = "https://bulbapedia.bulbagarden.net/w/api.php"
PLUSH_REGIONS = ("Kanto", "Johto", "Hoenn", "Sinnoh", "Unova", "Kalos", "Alola", "Galar", "Paldea")


def _bulba(params):
    from urllib.parse import urlencode
    return _shop_get(BULBA + "?" + urlencode({**params, "format": "json"}))


# Bulbagarden turns away every request for its picture files (from programs and from other sites' pages alike), so a Pokemon plush shows the Pokemon's official artwork instead (PokeAPI's
# sprite collection on GitHub, which allows it), and says so in its description.
ARTWORK = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/{}.png"
ARTWORK_NOTE = " (The picture is the Pokemon's official artwork: no photo of this plush could be loaded.)"


def poke_slug(name):
    import unicodedata
    s = (name or "").replace("\u2640", "-f").replace("\u2642", "-m")
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"[.'\u2019:]", "", s)
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")


def pokeapi_numbers(gdir):
    """{PokeAPI name: its number}, species first (so 'darmanitan' is its Pokedex number), then every form; kept for a month."""
    path = os.path.join(gdir, "pokeapi_names.json")
    try:
        d = json.load(open(path, encoding="utf-8"))
        if time.time() - d.get("at", 0) < 30 * 86400 and d.get("map"):
            return d["map"]
    except (OSError, ValueError):
        pass
    out = {}
    for kind in ("pokemon-species", "pokemon"):
        for x in (_shop_get(f"https://pokeapi.co/api/v2/{kind}?limit=3000").get("results") or []):
            try:
                out.setdefault(x["name"], int(x["url"].rstrip("/").split("/")[-1]))
            except (KeyError, ValueError):
                pass
    if out:
        os.makedirs(gdir, exist_ok=True)
        json.dump({"at": time.time(), "map": out}, open(path, "w", encoding="utf-8"))
    return out


def artwork_for(numbers, name):
    """The official-artwork address for a Pokemon plush's name ('Darmanitan-Zen' falls back to 'Darmanitan' when the form has no artwork of its own); '' when the name is unknown."""
    parts = poke_slug(name).split("-")
    while parts:
        n = numbers.get("-".join(parts))
        if n:
            return ARTWORK.format(n)
        parts = parts[:-1]
    return ""


class PlushProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("plushies", 0, type_field="Series")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            day = time.strftime("%Y-%m-%d")
            try:
                numbers = pokeapi_numbers(gdir)
            except Exception:  # noqa: BLE001 - without it the plush keep the Bulbapedia picture address (which may not load)
                numbers = {}
            for i, region in enumerate(PLUSH_REGIONS):
                if cancel.is_set():
                    break
                progress("Reading Bulbapedia…", i, len(PLUSH_REGIONS))
                d = _bulba({"action": "parse", "page": f"Sitting_Cuties/{region}", "prop": "wikitext"})
                text = ((d.get("parse") or {}).get("wikitext") or {}).get("*") or ""
                rows = re.findall(r"^\s*([^|\n<]+?\.(?:jpg|png|jpeg|gif))\s*\|\s*(.+)$", text, re.M | re.I)
                names = []
                for fname, cap in rows:
                    m = re.search(r"\{\{p\|([^}|]+)\}\}", cap)
                    if m:
                        names.append((fname.strip(), m.group(1).strip()))
                if not names:
                    continue
                urls = {}
                for k in range(0, len(names), 40):
                    chunk = names[k:k + 40]
                    q = _bulba({"action": "query", "titles": "|".join("File:" + f for f, _ in chunk), "prop": "imageinfo", "iiprop": "url", "iiurlwidth": 300})
                    for pg in ((q.get("query") or {}).get("pages") or {}).values():
                        info = (pg.get("imageinfo") or [{}])[0]
                        urls[(pg.get("title") or "").replace("File:", "").replace("_", " ")] = info.get("thumburl") or info.get("url") or ""
                sid = "plush:" + region.lower()
                conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, f"{region} region", "Pokemon plush", "", len(names) * 2, len(names) * 2, None))
                for n, (fname, mon) in enumerate(names, 1):
                    thumb = urls.get(fname.replace("_", " "), "")
                    art = artwork_for(numbers, mon)
                    img = art or thumb
                    for label, tag in (("Sitting Cuties (US)", "sc"), ("Pokemon fit (Japan)", "fit")):
                        conn.execute(
                            "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                            (f"{sid}:{re.sub(r'[^a-z0-9]+', '-', mon.lower())}:{tag}", sid, str(n), n * 2 + (tag == "fit"), f"{mon} - {label}", img, "Plush", label, "Pokemon - " + ("Sitting Cuties (US)" if tag == "sc" else "Pokemon fit (Japan)"),
                             f"{mon} plush from the {region} region. {label}." + (ARTWORK_NOTE if art else ""), json.dumps({"normal": True}), json.dumps({"pokemon": mon, "region": region, "line": label, "source": "Bulbapedia (CC BY-NC-SA)", "thumb": thumb}, ensure_ascii=False)))
            try:
                self._squishmallows(conn, cancel, progress)
            except Exception:  # noqa: BLE001 - the Pokemon plush are already in; Squishmallows are added when their wiki answers
                pass
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def _squishmallows(self, conn, cancel, progress):
        """Every Squishmallow of the community wiki (squishmallows.fandom.com, CC BY-SA): name, picture, squad, sizes, year, animal."""
        api = "https://squishmallows.fandom.com/api.php"
        cont, n, seen_sets = {}, 0, {}
        while not cancel.is_set():
            from urllib.parse import urlencode
            q = {"action": "query", "generator": "allpages", "gaplimit": 50, "gapnamespace": 0, "prop": "pageimages|categories", "piprop": "original", "cllimit": "max", "format": "json", **cont}
            d = _shop_get(api + "?" + urlencode(q))
            for pg in ((d.get("query") or {}).get("pages") or {}).values():
                cats = [c["title"].replace("Category:", "") for c in pg.get("categories", [])]
                sizes = sorted({c for c in cats if re.fullmatch(r"[\d.]+ ?[Ii]nch", c)}, key=lambda x: float(re.match(r"[\d.]+", x).group(0)))
                img = (pg.get("original") or {}).get("source") or ""
                if not sizes or not img or "Candidates for deletion" in cats:
                    continue
                squad = next((c for c in cats if c.endswith(" Squad")), "Other Squishmallows")
                year = next((c for c in cats if re.fullmatch(r"20\d\d", c)), "")
                animal = next((c for c in cats if c in ("Cat", "Dog", "Bear", "Bunny", "Bird", "Cow", "Axolotl", "Bat", "Bigfoot", "Dragon", "Unicorn", "Caticorn", "Fox", "Frog", "Penguin", "Shark", "Turtle", "Octopus", "Pig", "Monkey", "Dinosaur", "Llama", "Alpaca", "Owl", "Hedgehog", "Sloth", "Otter")), "")
                sid = "sq:" + re.sub(r"[^a-z0-9]+", "-", squad.lower()).strip("-")
                if sid not in seen_sets:
                    seen_sets[sid] = squad
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, squad, "Squishmallows", "", 0, 0))
                ext = {"Brand": "Squishmallows (Kelly Toy / Jazwares)", "Sizes": ", ".join(sizes), "Squad": squad, "Year": year or "unknown", "Animal": animal or "", "Wiki page": "https://squishmallows.fandom.com/wiki/" + pg["title"].replace(" ", "_")}
                conn.execute(
                    "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                    (f"sq:{pg['pageid']}", sid, "", int(year or 0) * 10 + 1 if year else 99999, pg["title"], img.split("/revision")[0], "Plush", ", ".join(sizes), "Squishmallows",
                     f"{pg['title']} - a Squishmallow from the {squad}." + (f" Sizes: {', '.join(sizes)}." if sizes else ""), json.dumps({"normal": True}), json.dumps({"source": "squishmallows.fandom.com (CC BY-SA)", "ext": {k: v for k, v in ext.items() if v}}, ensure_ascii=False)))
                n += 1
            cont = d.get("continue")
            if not cont:
                break
            progress("Reading Squishmallows…", n, 3400)
            time.sleep(0.2)
        for sid in seen_sets:
            conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
        conn.commit()
        return n

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no market price source for these (a person can still enter what they paid)


# ------------------------------------------------------------------------------------------------ Nee-Doh (Schylling stress toys)
# needoh.org is an unofficial catalogue of every Nee-Doh with its picture; the page lists them all in one go.
NEEDOH_SITE = "https://needoh.org"


def _needoh_line(name):
    low = name.lower()
    rules = (("Christmas & winter", ("squishmas", "santa", "snow", "advent", "reindeer", "christmas", "candy cane", "ice baby", "gingerbread")),
             ("Halloween", ("jack-glow", "pumpkin", "boo", "fright", "sugar skull", "halloween", "ghost", "spooky")),
             ("Glow & color change", ("glow", "color change", "colour change", "galactic", "atomic")),
             ("Animals & characters", ("cool cats", "wild cats", "funky pup", "gummy bear", "cat", "dog", "bear", "bunny", "panda")),
             ("Fuzzy", ("fuzz", "shaggy", "wonder waves")),
             ("Minis & collectibles", ("teenie", "mini", "dohjee", "baby")),
             ("Core shapes", ("nice cube", "nice berg", "niceberg", "gumdrop", "gum drop", "classic", "groovy", "cloud pleaser", "dream drop", "dohnut", "jelly")))
    for line, words in rules:
        if any(w in low for w in words):
            return line
    return "Specials & collaborations"


class NeeDohProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("needoh", 0, type_field="Line")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the Nee-Doh catalogue…", 0, 0)
            raw = sync._get(NEEDOH_SITE, as_json=False)
            text = raw.decode("utf-8", errors="replace") if raw else ""
            day, made, n = time.strftime("%Y-%m-%d"), {}, 0
            items = [(key, cohort, name, src) for key, cohort, name, src in re.findall(r'<article data-ph-product-key="([^"]+)" data-ph-cohort="([^"]+)" data-ph-product="([^"]+)"[^>]*>.*?<img alt="[^"]*"[^>]*src="([^"]+)"', text, re.S) if cohort != "test"]
            have = {re.sub(r"[^a-z0-9]+", "", html_unescape(i[2]).lower().replace("needoh", "")) for i in items}
            try:                                                              # the tracker page lists a few more (seasonal, minis, the smallest ...)
                raw2 = sync._get(NEEDOH_SITE + "/tracker/", as_json=False)
                t2 = raw2.decode("utf-8", errors="replace") if raw2 else ""
                for alt, src in re.findall(r'<img[^>]*?alt="([^"]{3,70})"[^>]*?src="(/images/[^"]+)"', t2):
                    nm = html_unescape(alt).strip()
                    k = re.sub(r"[^a-z0-9]+", "", nm.lower().replace("needoh", ""))
                    if k and k not in have:
                        have.add(k)
                        items.append((re.sub(r"[^a-z0-9]+", "-", nm.lower()).strip("-"), "tracker", ("NeeDoh " + nm) if "needoh" not in nm.lower() else nm, src))
            except Exception:  # noqa: BLE001 - the main page is enough if the tracker is down
                pass
            for key, cohort, name, src in items:
                name = html_unescape(name).strip()
                line = _needoh_line(name)
                sid = "needoh:" + re.sub(r"[^a-z0-9]+", "-", line.lower()).strip("-")
                if sid not in made:
                    made[sid] = line
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, line, "Nee-Doh", "", 0, 0))
                img = NEEDOH_SITE + src.split("?")[0] if src.startswith("/") else src.split("?")[0]
                conn.execute(
                    "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                    ("needoh:" + key, sid, "", 100000, name, img, "Nee-Doh", "Core" if cohort == "core" else "Catalogue", "Schylling", name + " - a Schylling Nee-Doh stress toy.", json.dumps({"normal": True}),
                     json.dumps({"source": "needoh.org", "key": key, "cohort": cohort}, ensure_ascii=False)))
                n += 1
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0


# ------------------------------------------------------------------------------------------------ Youtooz
# youtooz.com is a Shopify shop (about 5,400 figures and plush, past drops included).  Its product type is the franchise ("FNAF", "Hazbin Hotel", "Gaming"...) except for plush, which say only "Plush":
# those take the franchise from the collection of that name.  Pins, keychains, apparel and the like are not listed (only the figures and plush).
_YT_NOT = re.compile(r"\b(pins?|keychains?|key chains?|shirts?|tees?|hoodies?|hats?|caps?|beanies?|socks?|posters?|stickers?|prints?|gift cards?|mugs?|bags?|totes?|blankets?|pillows?|candles?|"
                     r"ornaments?|lanyards?|wallets?|sleeves?|playmats?|mousepads?|phone cases?|stands?|digital)\b", re.I)


def _yt_keep(p):
    t = _clean_title(p.get("title") or "")
    pt = (p.get("product_type") or "").strip().lower()
    if pt in ("pins", "fnaf pins", "apparel", "gift card", "accessories", "digital") or pt.endswith(" pins"):
        return False
    if re.search(r"\bplush\b", t, re.I) and not re.search(r"\b(keychain|key chain|pin)\b", t, re.I):
        return True                                                       # a plush is kept even when a word like 'stand' or 'bag' is in its name
    return not _YT_NOT.search(t)


class YoutoozProvider(ShopifyToyProvider):
    def __init__(self):
        super().__init__("youtooz", "https://youtooz.com", keep=_yt_keep, line=lambda p: p.get("_line") or "Misc", type_field="Franchise", exclude=_YT_NOT, lines_first=("Original",))

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        self._gdir = gdir
        return super().fetch_catalog(gdir, cancel, progress, only_sets)

    def _plush_map(self, cancel, franchise):
        """{product id: franchise} for plush, from the shop's collections.  The shop slows down a caller that asks for too much, so this is read gently and kept for a week."""
        path = os.path.join(getattr(self, "_gdir", "") or "", "youtooz_collections.json")
        try:
            if os.path.exists(path) and time.time() - os.path.getmtime(path) < 7 * 86400:
                return {int(k): v for k, v in json.load(open(path, encoding="utf-8")).items()}
        except (OSError, ValueError):
            pass
        best = {}
        try:
            cols = _shop_get(f"{self.base}/collections.json?limit=250").get("collections") or []
            generic = re.compile(r"^(all|anime|anime-collection|new|best-sellers?|featured|frontpage|home|sale|exclusives?|gifts?|plush|plushies|collectibles|figures?|preorders?|pre-orders?|restock|in-stock|bundles?|"
                                 r"holiday.*|black-friday.*|cyber.*|.*-drop|.*-sale|.*-bundle|under-.*|.*gift.*|.*under.*)$", re.I)
            for c in sorted(cols, key=lambda c: c.get("products_count", 0)):                       # the SMALLEST collection holding a product is the most specific one
                if generic.match(c.get("handle") or "") or not 0 < c.get("products_count", 0) <= 450:
                    continue
                for pg in range(1, 4):
                    if cancel.is_set():
                        return {}
                    time.sleep(0.5)
                    d = _shop_get(f"{self.base}/collections/{c['handle']}/products.json?limit=250&page={pg}").get("products") or []
                    if not d:
                        break
                    for q in d:
                        if q["id"] not in best or c["products_count"] < best[q["id"]][0]:
                            k = re.sub(r"[^a-z0-9]+", "", (c.get("title") or "").lower())
                            best[q["id"]] = (c["products_count"], franchise.get(k) or (c.get("title") or "").strip())
        except Exception as e:  # noqa: BLE001 - a busy shop: plush stay under 'Plush' this time and the next run tries again
            print("youtooz: collections not read:", str(e)[:80], flush=True)
            return {}
        out = {i: v[1] for i, v in best.items()}
        try:
            json.dump(out, open(path, "w", encoding="utf-8"))
        except OSError:
            pass
        return out

    def _products(self, cancel):
        ps = super()._products(cancel)
        canon, count = {}, {}
        for p in ps:                                                        # one spelling per franchise ('SpongeBob Squarepants' / 'Spongebob Squarepants' / 'SpongeBob SquarePants')
            k = re.sub(r"[^a-z0-9]+", "", (p.get("product_type") or "").lower())
            if k:
                count.setdefault(k, {})
                count[k][p["product_type"].strip()] = count[k].get(p["product_type"].strip(), 0) + 1
        for k, spell in count.items():
            canon[k] = max(spell.items(), key=lambda kv: (kv[1], sum(ch.isupper() for ch in kv[0])))[0]
        plush_types = {"plush", "plushes"}
        franchise = {k: v for k, v in canon.items() if k not in plush_types}
        by_id = self._plush_map(cancel, franchise)
        for p in ps:
            k = re.sub(r"[^a-z0-9]+", "", (p.get("product_type") or "").lower())
            if k and k not in plush_types:
                p["_line"] = canon[k]
            else:
                p["_line"] = by_id.get(p["id"]) or ("Plush (other)" if k in plush_types else "Misc")
        return ps


def youtooz_provider():
    return YoutoozProvider()
