"""Collectibles beyond the card games: Funko Pop! figures and accessories (playmats, displays...).  Read once from free public sources and stored in the same kind of list as a card game, so owning,
portfolios, search, prices and pictures all work the same way.

  funko        TCGplayer's Funko category (names, number, fandom, exclusive / chase, prices) joined with the open hobbyDB-derived list kennymkchan/funko-pop-data (MIT licence: ~24,000 names and pictures,
               no prices).  A fandom (Television, Movies, Animation, Disney, Marvel, Games ...) is a "set"; the product line (Pop! Vinyl, Wacky Wobblers, Pocket Pop! ...) is its "series".
  accessories  TCGplayer's Playmats category (every brand, Pokémon and other games) plus the deck-box / storage groups that name a game.  A brand's group is a "set"; the kind of thing is the "series".

Pictures stay on the sources' own servers (only the addresses are stored), so the list is a few megabytes."""
import csv
import io
import json
import os
import re
import time

from . import sync
from .db import open_cards_conn, sort_key  # noqa: F401
from .tcgcsv import BASE, TcgCsvProvider, _clean, _ext, norm_name, pick_price_row

FUNKO_CSV = "https://raw.githubusercontent.com/kennymkchan/funko-pop-data/master/funko_pop.csv"

# ----------------------------------------------------------------------------------------------------- Funko
_GENRE_FIX = {"televsion": "Television", "movie": "Movies", "game": "Games", "video games": "Games", "icons": "Icons", "": "Other", "funko": "Funko Originals", "custom": "Other"}
_BUCKET = {
    "Television": "TV & Movies", "Movies": "TV & Movies", "Movie Moments": "TV & Movies", "Star Wars": "TV & Movies", "Harry Potter": "TV & Movies", "Game of Thrones": "TV & Movies",
    "Fantastic Beasts and Where to Find Them": "TV & Movies", "Doctor Who": "TV & Movies", "Stranger Things": "TV & Movies", "Director": "TV & Movies", "Broadway": "TV & Movies", "SNL": "TV & Movies",
    "Animation": "Animation & Cartoons", "Disney": "Animation & Cartoons", "Pixar": "Animation & Cartoons", "Hello Kitty": "Animation & Cartoons", "Sanrio": "Animation & Cartoons",
    "South Park": "Animation & Cartoons", "Sesame Street": "Animation & Cartoons", "Pokemon": "Animation & Cartoons", "Asia": "Animation & Cartoons", "Monster High": "Animation & Cartoons",
    "Marvel": "Comics & Heroes", "Heroes": "Comics & Heroes", "DC": "Comics & Heroes", "Comics": "Comics & Heroes", "Comic Moments": "Comics & Heroes", "Books": "Comics & Heroes",
    "Games": "Video & Board Games", "8-Bit": "Video & Board Games", "Halo": "Video & Board Games", "Board Games": "Video & Board Games", "Dorbz": "Video & Board Games",
    "NFL": "Sports", "NBA": "Sports", "MLB": "Sports", "NHL": "Sports", "WWE": "Sports", "UFC": "Sports", "Football": "Sports", "Basketball": "Sports", "Hockey": "Sports", "Wrestling": "Sports",
    "Rocks": "Music", "Music": "Music", "Royals": "Music", "Drag Queens": "Music",
}
_LINES = ("Wacky Wobblers", "Pocket Pop!", "Dorbz", "Plushies", "ReAction Figures", "Funko Prototypes", "Pop! Pins", "Pop! Tees & Apparel", "Pop! Rides", "Pop! Keychain", "Mystery Minis", "Vinyl Soda",
          "Pop! Deluxe", "Pop! Albums", "Pop! Moments", "Paka Paka", "Pop! Pez", "Pop! Pins")
_FANDOM_TAGS_SKIP = {"Pop! Vinyl", "Pop! Pins", "Pop! Tees & Apparel", "Pop! Keychain", "Pop! Rides", "Pop! Deluxe", "Pop! Albums", "Pop! Moments", "Pop! Pez", "Pop! Pop!", "Chase Pieces"}


def _fandom_from_tags(tags):
    """'Pop! Television;Pop! Vinyl' -> 'Television' (the fandom the person browses by)."""
    for t in tags:
        if t.startswith("Pop! ") and t not in _FANDOM_TAGS_SKIP:
            return t[5:].strip()
    for t in tags:
        if t not in _FANDOM_TAGS_SKIP and "xclusive" not in t and "hase" not in t and t != "Pop! Vinyl":
            return t.replace("Pop! ", "").strip() or "Other"
    return "Other"


def _line_from_tags(tags):
    for t in tags:
        if t in _LINES and t != "Pop! Pins":
            return t
    if "Pop! Pins" in tags:
        return "Pop! Pins"
    return "Pop! Vinyl"


def _rarity_from_tags(tags):
    t = ";".join(tags).lower()
    if "chase" in t:
        return "Chase"
    if "exclusive" in t:
        return "Exclusive"
    return "Standard"


class FunkoProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("funko", 29, type_field="Series")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            day = time.strftime("%Y-%m-%d")
            progress("Reading Funko Pop! from TCGplayer…", 0, 0)
            made = {}
            seen_names = set()

            def put_set(fandom):
                sid = "fd:" + re.sub(r"[^a-z0-9]+", "-", fandom.lower()).strip("-")
                if sid not in made:
                    made[sid] = fandom
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, fandom, _BUCKET.get(fandom, "Other fandoms"), "", 0, 0, None))
                return sid

            n = 0
            for g in self._get("groups"):
                if cancel.is_set():
                    return n
                gid = g["groupId"]
                products, prices = self._get(f"{gid}/products"), self._get(f"{gid}/prices")
                by_pid = {}
                for pr in prices:
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                for p in products:
                    ext = _ext(p)
                    genre = _GENRE_FIX.get((ext.get("Genre") or "").strip().lower(), (ext.get("Genre") or "").strip() or "Other")
                    sid = put_set(genre)
                    usd, kind = pick_price_row(by_pid.get(p["productId"], {}))
                    number = str(ext.get("Number") or "")
                    nums = re.findall(r"\d+", number)
                    nm = p["name"].strip()
                    raw = {"productId": p["productId"], "url": p.get("url"), "ext": {k: v for k, v in ext.items() if k in ("Series", "Model", "UPC", "GTIN", "Printing", "Genre")}}
                    conn.execute(
                        "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                        (str(p["productId"]), sid, number, int(nums[-1]) if nums else 100000, nm, p.get("imageUrl"), "Pop! Vinyl", ext.get("Rarity") or "Standard", ext.get("Series") or "",
                         _clean(ext.get("Description")), usd, kind, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
                    seen_names.add(norm_name(re.sub(r"\s*\(.*?\)\s*$", "", nm.split(": ")[-1])))
                    n += 1
            conn.commit()
            # ---- the open list of ~24,000 more names and pictures (no prices)
            progress("Reading the open Funko Pop! list…", 0, 0)
            raw_csv = sync._get(FUNKO_CSV, as_json=False)
            added = 0
            if raw_csv:
                text = raw_csv.decode("utf-8", errors="replace")
                for row in csv.DictReader(io.StringIO(text)):
                    title, handle, img = (row.get("title") or "").strip(), (row.get("handle") or "").strip(), (row.get("imageName") or "").strip()
                    if not title or not handle:
                        continue
                    tags = [t.strip() for t in (row.get("series") or "").split(";") if t.strip()]
                    fandom = _fandom_from_tags(tags)
                    if norm_name(title) in seen_names and fandom != "Other":
                        continue                                   # already listed (with a price) from TCGplayer
                    sid = put_set(fandom)
                    conn.execute(
                        "INSERT OR IGNORE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                        ("hdb:" + handle, sid, "", 100000, title, img, _line_from_tags(tags), _rarity_from_tags(tags), "; ".join(t for t in tags if t != "Pop! Vinyl")[:120], "", json.dumps({"normal": True}),
                         json.dumps({"handle": handle, "tags": tags}, ensure_ascii=False)))
                    added += 1
                    if added % 4000 == 0:
                        conn.commit()
                        progress("Reading the open Funko Pop! list…", added, 24000)
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        conn = open_cards_conn(gdir)
        try:
            day, hit = time.strftime("%Y-%m-%d"), 0
            for g in self._get("groups"):
                by_pid = {}
                for pr in self._get(f"{g['groupId']}/prices"):
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                for pid, subs in by_pid.items():
                    usd, kind = pick_price_row(subs)
                    if usd is not None:
                        conn.execute("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", (usd, kind, day, str(pid)))
                        hit += 1
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return hit
        finally:
            conn.close()


# ------------------------------------------------------------------------------------------------ accessories
_GAME_WORDS = [("pokemon", "Pokémon"), ("pokémon", "Pokémon"), ("magic", "Magic: The Gathering"), ("mtg", "Magic: The Gathering"), ("yu-gi-oh", "Yu-Gi-Oh!"), ("yugioh", "Yu-Gi-Oh!"), ("one piece", "One Piece"),
               ("lorcana", "Lorcana"), ("riftbound", "Riftbound"), ("flesh and blood", "Flesh and Blood"), ("dragon ball", "Dragon Ball"), ("union arena", "Union Arena"), ("gundam", "Gundam"),
               ("digimon", "Digimon"), ("star wars", "Star Wars"), ("marvel", "Marvel"), ("sorcery", "Sorcery"), ("keyforge", "KeyForge"), ("hololive", "hololive"), ("cookierun", "CookieRun"),
               ("vanguard", "Cardfight!! Vanguard"), ("weiss", "Weiss Schwarz"), ("wand company", "The Wand Company")]


def _game_of(name, group):
    low = (name + " " + group).lower()
    for w, label in _GAME_WORDS:
        if w in low:
            return label
    return "Other games"


class AccessoriesProvider(TcgCsvProvider):
    """Playmats (TCGplayer category 35: every brand) plus the deck-box / storage / display groups of category 14 and 51 that name a game."""
    SOURCES = ((35, "Playmats", None), (14, "Deck boxes, sleeves & storage", ("pokemon", "playmat", "display", "wand", "anime")), (51, "Collectible storage & displays", ("pokemon", "display", "wand")))

    def __init__(self):
        super().__init__("accessories", 35, type_field="Series")

    def _cat(self, cat, path):
        d = sync._get(f"{BASE}/{cat}/{path}")
        return (d or {}).get("results", [])

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            day = time.strftime("%Y-%m-%d")
            groups = []
            for cat, serie, want in self.SOURCES:
                for g in self._cat(cat, "groups"):
                    if want is None or any(w in g["name"].lower() for w in want):
                        groups.append((cat, serie, g))
            done = [0]

            def one(item):
                cat, _serie, g = item
                return self._cat(cat, f"{g['groupId']}/products"), self._cat(cat, f"{g['groupId']}/prices")

            def got(item, result):
                cat, serie, g = item
                products, prices = result
                done[0] += 1
                if products:
                    sid = f"{cat}-{g['groupId']}"
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, re.sub(r"\s+Playmats?$", "", g["name"]) if cat == 35 else g["name"], serie, (g.get("publishedOn") or "")[:10], len(products), len(products), None))
                    by_pid = {}
                    for pr in prices:
                        by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                    for p in products:
                        usd, kind = pick_price_row(by_pid.get(p["productId"], {}))
                        ext = _ext(p)
                        name = re.sub(r"\s+", " ", p["name"]).strip()
                        raw = {"productId": p["productId"], "url": p.get("url"), "ext": {k: v for k, v in ext.items() if k in ("Series", "Model", "UPC", "GTIN", "Printing")}}
                        conn.execute(
                            "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                            (str(p["productId"]), sid, "", 100000, name, p.get("imageUrl"), serie, ext.get("Rarity") or "", _game_of(name, g["name"]), _clean(ext.get("Description")), usd, kind, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
                if done[0] % 8 == 0:
                    conn.commit()
                progress("Reading accessories…", done[0], len(groups))

            sync._pool(groups, one, cancel, got, workers=6)
            conn.commit()
            self._wand_company(conn, day)
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def _wand_company(self, conn, day):
        """The Wand Company's Pokemon Poke Ball replicas with their display cases (they are not sold through TCGplayer): read from the maker's own image library page."""
        try:
            raw = sync._get("https://www.thewandcompany.com/photos/sets/pokemon-1/", as_json=False)
            text = raw.decode("utf-8", errors="replace") if raw else ""
        except Exception:  # noqa: BLE001
            return 0
        n = 0
        conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", ("wand-pokemon", "The Wand Company - Pokemon Poke Balls", "Displays & replicas", "", 0, 0, None))
        for chunk in text.split('<li class="album">')[1:]:
            src = re.search(r'src="(https://www\.thewandcompany\.com/koken/[^"]+\.jpg)"', chunk)
            nm = re.search(r"<h4>\s*<a[^>]*>\s*([^<]+?)\s*</a>", chunk)
            ds = re.search(r"<p>\s*([^<]+?)\s*</p>", chunk)
            if not src or not nm:
                continue
            name = nm.group(1).strip()
            if "range" in name.lower():
                continue
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
            conn.execute(
                "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                ("wand:" + slug, "wand-pokemon", "", 1000 + n, name + " (The Wand Company)", src.group(1), "Displays & replicas", "Replica with display case", "Pok\u00e9mon",
                 (ds.group(1).strip() if ds else "") + " Die-cast electronic replica with its own display case.", json.dumps({"normal": True}), json.dumps({"source": "thewandcompany.com"})))
            n += 1
        conn.execute("UPDATE sets SET total=?, official=? WHERE id='wand-pokemon'", (n, n))
        conn.commit()
        return n

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        conn = open_cards_conn(gdir)
        try:
            day, hit = time.strftime("%Y-%m-%d"), 0
            for (sid,) in conn.execute("SELECT id FROM sets WHERE id NOT LIKE 'wand%'").fetchall():
                cat, gid = sid.split("-", 1)
                by_pid = {}
                for pr in self._cat(int(cat), f"{gid}/prices"):
                    by_pid.setdefault(pr["productId"], {})[pr.get("subTypeName") or "Normal"] = pr
                for pid, subs in by_pid.items():
                    usd, kind = pick_price_row(subs)
                    if usd is not None:
                        conn.execute("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", (usd, kind, day, str(pid)))
                        hit += 1
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return hit
        finally:
            conn.close()


# ------------------------------------------------------------------------------------------ designer toys from open shop feeds
# A Shopify shop lists everything it sells at <shop>/products.json (public, no key).  Each toy becomes one list entry with its picture, price, edition size ("limited edition of 250") and what makes it exclusive.
# Entries are never deleted when the shop stops listing them, so a daily refresh only ever ADDS: new releases arrive and sold-out toys stay in the list.
_EDITION = re.compile(r"(?:limited edition of|edition of|limited to|limited edition|\bLE\b[:\s]+|limited run of|run of)\s*(?:only\s*)?(\d[\d,]*)(?![\d,]*\s*(?:\"|inch|in\b|oz|-piece|piece puzzle|per\b|each\b|a\s+person|/))", re.I)
_EXCL = (("creature club", "Creature Club members"), ("convention", "Convention exclusive"), ("sdcc", "San Diego Comic-Con"), ("nycc", "New York Comic Con"), ("lottery", "Lottery"),
         ("early access", "Early access"), ("exclusive", "Exclusive"), ("prototype", "Prototype"), ("artist proof", "Artist proof"), ("blind box", "Blind box"), ("mystery", "Mystery"))


def html_unescape(s):
    import html as _h
    return _h.unescape(s or "")


def _shop_get(url):
    raw = sync._get(url, as_json=False)
    try:
        return json.loads(raw.decode("utf-8")) if raw else {}
    except ValueError:
        return {}


def _clean_title(t):
    """The toy's own name: pre-order notes and the like are not part of it."""
    t = re.sub(r"\s*[-–]?\s*(pre-?order|preorder)\b.*$", "", t or "", flags=re.I)
    t = re.sub(r"\s*[-–]?\s*DAMAGED CARTON\s*$", "", t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()


_PROOF = re.compile(r"\b(art(?:ist)? proofs?|prototypes?|protos?|proof)\b", re.I)
_NAME_NOISE = re.compile(r"\b(limited|edition|vinyl|figures?|resin|officially licensed|licensed|exclusive|soft|chomp|chomper|dumpster fire|collector'?s)\b", re.I)
_EXCL_TAIL = re.compile(r"\b(NYCC|SDCC|C2E2|DCon|Dcon|HMBR|Creature Club)\b(?:\s+Exclusive)?", re.I)


def short_name(title, game):
    """'Limited Silver Skeleton Edition Chomp Vinyl Figure' -> 'Silver Skeleton'; 'Dumpster Fire - Donut Green Vinyl Figure' -> 'Donut Green'.  What kind of toy it is stays in its group (Chomps, Chompers, Plush ...)."""
    t = html_unescape(title or "")
    if re.search(r'I\s*"?Chomp"?\s*NY', t, re.I):
        return "I Chomp NY"
    if re.search(r"chomp and chomper", t, re.I):
        return "Chomp & Chomper (Plush)" if re.search(r"plush", t, re.I) else "Chomp & Chomper"
    t = re.sub(r"\s+[Bb]y\s+[A-Z][^()\[\]]*$", "", t)                                  # '... By Jaide Sen Su' is the designer, shown in the details
    t = re.sub(r"\bFrozen Culture\b", " ", t, flags=re.I)
    t = _EXCL_TAIL.sub(" ", t)
    squishy = bool(re.search(r"\bsquishy\b", t, re.I))
    mini = bool(re.search(r"\bmini\b", t, re.I))
    plush = bool(re.search(r"\bplush\b", t, re.I))
    if game == "dumpsterfires":
        t = re.sub(r"\bDumpster Fire\b", " ", t, flags=re.I)
    t = _NAME_NOISE.sub(" ", t)
    t = re.sub(r"\b(squishy|mini|plush|single|single figure|set|bundle)\b", " ", t, flags=re.I)
    t = re.sub(r"\s+[-–|:]+\s+", " - ", t)
    t = re.sub(r"\s+", " ", t).strip(" -–|:,&")
    t = re.sub(r"^(?:-\s*)+|(?:\s*-)+$", "", t).strip()
    if not t:
        t = "Original"
    suffix = " (Squishy)" if squishy else " (Mini)" if mini else ""
    if plush and "plush" not in t.lower():
        suffix = suffix or " (Plush)"
    return (t + suffix).strip()


class ShopifyToyProvider(TcgCsvProvider):
    """game_id, shop address, optional collections to read first (they include sold-out toys), a test for which products are toys, and how to name the line each belongs to."""

    def __init__(self, game_id, base, collections=(), keep=None, line=None, type_field="Designer", exclude=None):
        super().__init__(game_id, 0, type_field=type_field)
        self.base, self.collections, self.keep, self.line = base.rstrip("/"), tuple(collections), keep or (lambda p: True), line or (lambda p: "Toys")
        self.exclude = exclude
        self.main_line = None

    def _products(self, cancel):
        seen, out = set(), []
        paths = [f"/collections/{c}/products.json" for c in self.collections] + ["/products.json"]
        for path in paths:
            for pg in range(1, 40):
                if cancel.is_set():
                    return out
                d = _shop_get(f"{self.base}{path}?limit=250&page={pg}").get("products") or []
                if not d:
                    break
                for p in d:
                    if p["id"] not in seen:
                        seen.add(p["id"])
                        out.append(p)
        return out

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the shop…", 0, 0)
            day = time.strftime("%Y-%m-%d")
            made = {}
            if self.exclude:                                                  # entries kept from earlier runs that the rules now leave out (coffee, patches, hats, duplicates ...)
                for cid, nm in conn.execute("SELECT id, name FROM cards WHERE id LIKE 'shp:%'").fetchall():
                    if self.exclude.search(nm) or re.search(r"pre-?order|damaged-carton", cid):
                        conn.execute("DELETE FROM cards WHERE id=?", (cid,))
            conn.execute("CREATE TABLE IF NOT EXISTS cards_extra AS SELECT * FROM cards WHERE 0")      # art proofs and prototypes wait here; they are shown only when the person turns them on
            conn.execute("DELETE FROM cards_extra WHERE id LIKE 'shp:%'")
            seen_titles = set()
            used_names, line_first = {}, {}
            products = self._products(cancel)
            norm = lambda p: re.sub(r"[^a-z0-9]+", " ", _clean_title(p["title"]).lower()).strip()
            is_pre = lambda p: bool(re.search(r"pre-?order", (p.get("handle") or "") + " " + (p.get("title") or ""), re.I))
            regular = {norm(p) for p in products if not is_pre(p)}
            for p in products:
                if not self.keep(p):
                    continue
                tkey = norm(p)
                if tkey in seen_titles or (is_pre(p) and tkey in regular):
                    continue                                                  # a pre-order copy of a toy that is already listed
                seen_titles.add(tkey)
                line = self.line(p)
                sid = f"{self.game_id}:" + re.sub(r"[^a-z0-9]+", "-", line.lower()).strip("-")
                if sid not in made:
                    made[sid] = line
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, line, "Toys", "", 0, 0, None))
                body = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html_unescape(p.get("body_html") or ""))).strip()
                title = _clean_title(html_unescape(p["title"]))
                m = _EDITION.search(title + " " + body)
                edition = int(m.group(1).replace(",", "")) if m else None
                if re.search(r"timed edition|determine the edition|size of the edition is determined", body, re.I):
                    edition = None                                              # a pre-order run: the number made is decided by the orders, there is no fixed count
                low = (title + " " + " ".join(p.get("tags") or []) + " " + body[:400]).lower()
                excl = [label for key, label in _EXCL if key in low]
                v0 = (p.get("variants") or [{}])[0]
                try:
                    price = float(v0.get("price")) if v0.get("price") else None
                except ValueError:
                    price = None
                avail = any(v.get("available") for v in p.get("variants") or [])
                by = re.search(r"\bby ([A-Z][^|(\[]{2,40}?)(?:\s*$|\s+[-|(\[])", title)
                img = ((p.get("images") or [{}])[0].get("src") or "").split("?")[0]
                published = (p.get("published_at") or "")[:10]
                rarity = (f"Limited edition of {edition:,}" if edition else "Open edition") + ("" if avail else " (sold out)")
                facts = {"Edition": (f"Limited to {edition:,} pieces" if edition else "Open edition (no stated limit)"), "Exclusive to": ", ".join(excl) if excl else "Not exclusive",
                         "Released": published or "unknown", "Availability": "In stock at the shop" if avail else "Sold out", "Designer": (by.group(1).strip() if by else ""), "Shop page": f"{self.base}/products/{p.get('handle')}"}
                raw = {"handle": p.get("handle"), "url": f"{self.base}/products/{p.get('handle')}", "edition": edition, "exclusive": excl, "available": avail, "published": published,
                       "tags": p.get("tags") or [], "images": [i.get("src") for i in (p.get("images") or [])[:6]], "ext": {k: v for k, v in facts.items() if v}}
                lines_order = {"Chomps": 0, "Vinyl figures": 0}.get(line, 1)
                order = lines_order * 100000000 + (int(published.replace("-", "") or 0) if published else 99999999)           # main line first, oldest to newest
                proof = bool(_PROOF.search(title))
                nm = short_name(title, self.game_id)
                if nm.lower() in used_names and used_names[nm.lower()] != str(p.get("handle")):
                    tag = (excl[0] if excl else (published[:4] if published else "")).strip()
                    nm = f"{nm} ({tag})" if tag else f"{nm} ({published or 'II'})"
                used_names[nm.lower()] = str(p.get("handle"))
                if published and (sid not in line_first or published < line_first[sid]):
                    line_first[sid] = published                              # a group is dated by its first toy, so groups sit oldest first too
                raw["ext"]["Shop name"] = title
                if proof:
                    sid = f"{self.game_id}:proofs"
                    made.setdefault(sid, "Art proofs & prototypes")
                table = "cards_extra" if proof else "cards"
                cid = "shp:" + str(p.get("handle"))
                conn.execute("DELETE FROM cards_extra WHERE id=?", (cid,))
                if proof:
                    conn.execute("DELETE FROM cards WHERE id=?", (cid,))
                conn.execute(
                    f"INSERT OR REPLACE INTO {table}(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)",
                    (cid, sid, "", order, nm, img, p.get("product_type") or line, rarity,
                     (by.group(1).strip() if by else ""), (", ".join(excl) + ". " if excl else "") + body[:600], price, "retail price" if price is not None else None, day, json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
            conn.execute("DELETE FROM sets WHERE id LIKE ? AND id LIKE '%:proofs'", (self.game_id + ":%",))             # the proofs group exists only while the person shows them (see proofs.py)
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), release_date=? WHERE id=?", (line_first.get(sid, ""), sid))
            conn.execute("DELETE FROM sets WHERE id LIKE ? AND NOT EXISTS (SELECT 1 FROM cards WHERE set_id=sets.id)", (self.game_id + ":%",))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return self.fetch_catalog(gdir, cancel, progress)          # the shop feed carries the prices: one pass does both


_NOT_TOY = re.compile(r"\b(coffee|patch|tote|apron|hat|beanie|socks?|grip|protector|prints?|poster|lottery|membership|trading card|full case|case of|shirt|hoodie|mug|sticker|pin|lanyard|luggage|ornament|"
                      r"night light|snow globe|string lights|journal|coloring book|puzzle|deck|ashtray|crochet|pattern|digital|bundle of prints|hat|keychain|gift card|pre-?orders?|damaged carton)\b", re.I)


def _chomp_keep(p):
    t = _clean_title(p.get("title") or "")
    if _NOT_TOY.search(t) or p.get("product_type") in ("Apparel", "Print", "Sticker", "Luggage Tag", "Enamel Pin", "Mug", "Gift Card"):
        return False
    low = t.lower()
    return any(w in low for w in ("figure", "plush", "chomp", "chomper", "squishy", "gumdrop", "blind bag", "blind box")) and "chomp coffee" not in low


def _chomp_line(p):
    t = (p.get("title") or "").lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    if "chomper" in t or "chomper" in tags:
        return "Chompers"
    if "frozen culture" in t:
        return "Frozen Culture"
    if "plush" in t:
        return "Plush"
    if "licensed" in tags or "collaboration" in tags or "godzilla" in t or "mothra" in t or "bob ross" in t or "zoltar" in t:
        return "Collaborations & licensed"
    if "creature club" in tags or "creature club" in t:
        return "Creature Club limited"
    return "Chomps"


def _df_keep(p):
    t = _clean_title(p.get("title") or "")
    if _NOT_TOY.search(t) or p.get("product_type") in ("Enamel Pin", "Shirts", "Stickers", "Print", "Patch", "Keychain", "AirPods Case", "Board Game"):
        return False
    low = t.lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    return ("dumpster" in low or "dumpster fire" in tags) and any(w in low for w in ("figure", "plush", "squishy", "ice cream", "stump", "frankendumpster", "bride of", "dumpster fire", "ceramic", "fried chicken", "set"))


def _df_line(p):
    t = (p.get("title") or "").lower()
    if p.get("product_type") == "Plush Toy" or "plush" in t:
        return "Plush"
    if "squishy" in t or "ceramic" in t:
        return "Squishy & ceramic"
    if any(w in t for w in ("marvel", "deadpool", "venom", "ghost rider", "x-men", "avengers", "pusheen", "care bears")):
        return "Collaborations"
    if "ice cream" in t:
        return "Dumpster Ice Cream"
    if "melted" in t:
        return "Melted (artist editions)"
    if "blind" in t or p.get("product_type") == "Blind Box":
        return "Blind boxes"
    return "Vinyl figures"


def chomps_provider():
    return ShopifyToyProvider("chomps", "https://abominabletoys.com", keep=_chomp_keep, line=_chomp_line, exclude=_NOT_TOY)


def dumpsterfire_provider():
    return ShopifyToyProvider("dumpsterfires", "https://100soft.shop", collections=("dumpster-fire-archives", "dumpster-fire-toys"), keep=_df_keep, line=_df_line, exclude=_NOT_TOY)


# ------------------------------------------------------------------------------------------------ Pokemon plush (Sitting Cuties / Pokemon fit)
# The regional pages of Bulbapedia (CC BY-NC-SA, read through its public API) list every plush with its picture.  Each Pokemon appears twice - the US "Sitting Cuties" and the Japanese "Pokemon fit"
# - so a person can mark which one they have.
BULBA = "https://bulbapedia.bulbagarden.net/w/api.php"
PLUSH_REGIONS = ("Kanto", "Johto", "Hoenn", "Sinnoh", "Unova", "Kalos", "Alola", "Galar", "Paldea")


def _bulba(params):
    from urllib.parse import urlencode
    return _shop_get(BULBA + "?" + urlencode({**params, "format": "json"}))


class PlushProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("plushies", 0, type_field="Series")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            day = time.strftime("%Y-%m-%d")
            for i, region in enumerate(PLUSH_REGIONS):
                if cancel.is_set():
                    break
                progress("Reading Bulbapedia…", i, len(PLUSH_REGIONS))
                d = _bulba({"action": "parse", "page": f"Sitting_Cuties/{region}", "prop": "wikitext"})
                text = ((d.get("parse") or {}).get("wikitext") or {}).get("*") or ""
                rows = re.findall(r"^\s*([^|\n<]+?\.(?:jpg|png|jpeg|gif))\s*\|\s*(.+)$", text, re.M | re.I)
                names = []
                for fname, cap in rows:
                    m = re.search(r"\{\{p\|([^}|]+)\}\}", cap)
                    if m:
                        names.append((fname.strip(), m.group(1).strip()))
                if not names:
                    continue
                urls = {}
                for k in range(0, len(names), 40):
                    chunk = names[k:k + 40]
                    q = _bulba({"action": "query", "titles": "|".join("File:" + f for f, _ in chunk), "prop": "imageinfo", "iiprop": "url", "iiurlwidth": 300})
                    for pg in ((q.get("query") or {}).get("pages") or {}).values():
                        info = (pg.get("imageinfo") or [{}])[0]
                        urls[(pg.get("title") or "").replace("File:", "").replace("_", " ")] = info.get("thumburl") or info.get("url") or ""
                sid = "plush:" + region.lower()
                conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?)", (sid, f"{region} region", "Pokemon plush", "", len(names) * 2, len(names) * 2, None))
                for n, (fname, mon) in enumerate(names, 1):
                    img = urls.get(fname.replace("_", " "), "")
                    for label, tag in (("Sitting Cuties (US)", "sc"), ("Pokemon fit (Japan)", "fit")):
                        conn.execute(
                            "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                            (f"{sid}:{re.sub(r'[^a-z0-9]+', '-', mon.lower())}:{tag}", sid, str(n), n * 2 + (tag == "fit"), f"{mon} - {label}", img, "Plush", label, region,
                             f"{mon} plush from the {region} region. {label}.", json.dumps({"normal": True}), json.dumps({"pokemon": mon, "region": region, "line": label, "source": "Bulbapedia (CC BY-NC-SA)"}, ensure_ascii=False)))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no market price source for these (a person can still enter what they paid)


# ------------------------------------------------------------------------------------------------ Nee-Doh (Schylling stress toys)
# needoh.org is an unofficial catalogue of every Nee-Doh with its picture; the page lists them all in one go.
NEEDOH_SITE = "https://needoh.org"


def _needoh_line(name):
    low = name.lower()
    rules = (("Christmas & winter", ("squishmas", "santa", "snow", "advent", "reindeer", "christmas", "candy cane", "ice baby", "gingerbread")),
             ("Halloween", ("jack-glow", "pumpkin", "boo", "fright", "sugar skull", "halloween", "ghost", "spooky")),
             ("Glow & color change", ("glow", "color change", "colour change", "galactic", "atomic")),
             ("Animals & characters", ("cool cats", "wild cats", "funky pup", "gummy bear", "cat", "dog", "bear", "bunny", "panda")),
             ("Fuzzy", ("fuzz", "shaggy", "wonder waves")),
             ("Minis & collectibles", ("teenie", "mini", "dohjee", "baby")),
             ("Core shapes", ("nice cube", "nice berg", "niceberg", "gumdrop", "gum drop", "classic", "groovy", "cloud pleaser", "dream drop", "dohnut", "jelly")))
    for line, words in rules:
        if any(w in low for w in words):
            return line
    return "Specials & collaborations"


class NeeDohProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("needoh", 0, type_field="Line")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the Nee-Doh catalogue…", 0, 0)
            raw = sync._get(NEEDOH_SITE, as_json=False)
            text = raw.decode("utf-8", errors="replace") if raw else ""
            day, made, n = time.strftime("%Y-%m-%d"), {}, 0
            for key, cohort, name, src in re.findall(r'<article data-ph-product-key="([^"]+)" data-ph-cohort="([^"]+)" data-ph-product="([^"]+)"[^>]*>.*?<img alt="[^"]*"[^>]*src="([^"]+)"', text, re.S):
                if cohort == "test":
                    continue
                name = html_unescape(name).strip()
                line = _needoh_line(name)
                sid = "needoh:" + re.sub(r"[^a-z0-9]+", "-", line.lower()).strip("-")
                if sid not in made:
                    made[sid] = line
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, line, "Nee-Doh", "", 0, 0))
                img = NEEDOH_SITE + src.split("?")[0] if src.startswith("/") else src.split("?")[0]
                conn.execute(
                    "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
                    ("needoh:" + key, sid, "", 100000, name, img, "Nee-Doh", "Core" if cohort == "core" else "Catalogue", "Schylling", name + " - a Schylling Nee-Doh stress toy.", json.dumps({"normal": True}),
                     json.dumps({"source": "needoh.org", "key": key, "cohort": cohort}, ensure_ascii=False)))
                n += 1
            for sid in made:
                conn.execute("UPDATE sets SET total=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id), official=(SELECT COUNT(*) FROM cards WHERE set_id=sets.id) WHERE id=?", (sid,))
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0
