"""IMPORT A LIST: read a pasted list or a CSV / TSV file of products (cards or sealed), how many, which portfolio, and optionally the price paid and the date.

This part only READS the text: which column is which (by its header, or guessed from the values when there is none), and each row's fields cleaned up
(quantities, "$1,234.50", dates in the usual ways of writing them).  Matching to cards / products and adding them is cardvault/webapi/listimportapi.py."""
import csv
import datetime
import io
import re

from .importers import COND_MAP, SYN, norm

FIELDS = ("name", "set", "number", "qty", "portfolio", "paid", "total", "date", "condition", "game")
LABELS = {"name": "Product", "set": "Set", "number": "Number", "qty": "Quantity", "portfolio": "Portfolio", "paid": "Price paid (each)", "total": "Price paid (total)",
          "date": "Purchase date", "condition": "Condition", "game": "Game", "": "(not used)"}
HEADS = {
    "name": SYN["name"] + ("item", "item name", "title", "description", "product title", "sealed", "sealed product"),
    "set": SYN["set"] + ("set code",),
    "number": SYN["number"],
    "qty": SYN["qty"] + ("copies", "how many", "units", "quantity owned"),
    "portfolio": SYN["portfolio"] + ("target", "target portfolio", "folder", "collection", "destination", "portfolios"),
    "paid": SYN["paid"] + ("price", "unit price", "unit cost", "buy price", "bought for", "each", "price per item"),
    "total": ("total", "total paid", "total cost", "total price", "line total", "amount paid"),
    "date": SYN["purchased"] + ("date", "order date", "bought", "date bought", "bought on", "when"),
    "condition": SYN["condition"],
    "game": ("game", "tcg", "category", "product line"),
}
_NOT = {"paid": ("market", "value", "current", "override", "sold", "sell", "total"), "date": ("release", "released", "sold"), "name": ("portfolio", "set"), "qty": ("price",)}


def _head_field(cell, taken, loose):
    """Which field a header cell names (exact words first; `loose`: a header that CONTAINS the field's words, like 'Price paid ($)')."""
    h = norm(cell)
    if not h:
        return ""
    for f in FIELDS:
        if f not in taken and h in [norm(x) for x in HEADS[f]]:
            return f
    if not loose:
        return ""
    for f in FIELDS:
        if f in taken or any(w in h.split() for w in _NOT.get(f, ())):
            continue
        if any(re.search(r"\b" + re.escape(norm(x)) + r"\b", h) for x in HEADS[f] if len(norm(x)) >= 3):
            return f
    return ""


def header_fields(cells):
    """[field or ''] for each cell of a header row."""
    out, taken = [""] * len(cells), set()
    for loose in (False, True):
        for i, c in enumerate(cells):
            if not out[i]:
                f = _head_field(c, taken, loose)
                if f:
                    out[i] = f
                    taken.add(f)
    return out


# ---------------------------------------------------------------------------------------------------------------- values
def parse_money(s):
    """'$1,234.50' / '1234.5' / 'USD 12' / '12,50' (a comma for cents) -> float, or None."""
    t = re.sub(r"[^0-9.,\-]", "", str(s or ""))
    if not re.search(r"\d", t):
        return None
    if "," in t and "." in t:
        t = t.replace(",", "") if t.rfind(".") > t.rfind(",") else t.replace(".", "").replace(",", ".")
    elif "," in t:
        t = t.replace(",", ".") if re.search(r",\d{2}$", t) and t.count(",") == 1 else t.replace(",", "")
    try:
        return round(float(t), 2)
    except ValueError:
        return None


def parse_qty(s, default=1):
    """'2' / 'x2' / '2x' / '2.0' / '' -> a whole number of at least 1."""
    m = re.search(r"\d+(?:\.\d+)?", str(s or ""))
    if not m:
        return default
    return max(1, min(int(float(m.group(0))), 99999))


_MONTHS = {m: i for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}


def _ymd(y, m, d):
    y = int(y)
    if y < 100:
        y += 2000 if y < 70 else 1900
    try:
        return datetime.date(y, int(m), int(d)).isoformat()
    except ValueError:
        return ""


def parse_date(s):
    """A purchase date written the usual ways -> 'YYYY-MM-DD' ('' when it isn't a date).
    2025-03-04, 2025/3/4, 2025-03-04 10:00, 3/4/2025 and 3/4/25 (month first, unless the first number can only be a day: 25/3/2025), 4.3.2025 (day first),
    Mar 4 2025, March 4, 2025, 4 Mar 2025, 4-Mar-25, and a spreadsheet's day number (45720)."""
    t = str(s or "").strip()
    if not t:
        return ""
    m = re.match(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    if m:
        return _ymd(*m.groups())
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{2,4})\b", t) or re.match(r"^(\d{1,2})-(\d{1,2})-(\d{2,4})\b", t)
    if m:
        a, b, y = (int(x) for x in m.groups())
        return _ymd(y, b, a) if a > 12 else _ymd(y, a, b)
    m = re.match(r"^(\d{1,2})\.(\d{1,2})\.(\d{2,4})\b", t)
    if m:
        a, b, y = (int(x) for x in m.groups())
        return _ymd(y, a, b) if b > 12 else _ymd(y, b, a)
    w = re.findall(r"[a-z]+|\d+", t.lower())
    mon = next((_MONTHS[x[:3]] for x in w if x[:3] in _MONTHS and x.isalpha()), None)
    nums = [int(x) for x in w if x.isdigit()]
    if mon and len(nums) >= 2:
        y = next((n for n in nums if n > 31), nums[-1])
        d = next((n for n in nums if n != y), None)
        return _ymd(y, mon, d) if d else ""
    if re.fullmatch(r"\d{5}(\.\d+)?", t) and 20000 < float(t) < 80000:          # a spreadsheet's own day count (days since 1899-12-30)
        return (datetime.date(1899, 12, 30) + datetime.timedelta(days=int(float(t)))).isoformat()
    return ""


def parse_cond(s):
    k = norm(s)
    return COND_MAP.get(k, "")


# ---------------------------------------------------------------------------------------------------------------- the table
def split_rows(text):
    """-> (rows as lists of cells, the delimiter: '\\t' / ',' / ';' / '|' / '' for one product per line)."""
    lines = [ln for ln in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n") if ln.strip()]
    if not lines:
        return [], ""
    sample = lines[:30]
    if any("\t" in ln for ln in sample):
        delim = "\t"
    else:
        delim = ""
        best = 0
        for d in (",", ";", "|"):
            counts = [len(next(csv.reader([ln], delimiter=d), [])) - 1 for ln in sample]
            hits = sum(1 for c in counts if c > 0)
            if hits >= max(1, len(sample) * 0.6) and hits > best:
                best, delim = hits, d
    if not delim:
        return [[ln.strip()] for ln in lines], ""
    rows = [[c.strip() for c in r] for r in csv.reader(io.StringIO("\n".join(lines)), delimiter=delim)]
    return [r for r in rows if any(r)], delim


def _is_header(cells):
    f = header_fields(cells)
    named = sum(1 for x in f if x)
    filled = sum(1 for c in cells if c.strip())
    if not named:
        return False
    if any(parse_money(c) is not None and re.search(r"\d", c) and not re.search(r"[a-z]{3}", c.lower()) for c in cells):
        return False                                               # (a header has no plain numbers in it)
    return named >= max(1, (filled + 1) // 2)


def guess_fields(rows, portfolio_names=(), set_names=()):
    """No header: what each column probably is, from its values.  The person can change any of it."""
    n = max((len(r) for r in rows), default=0)
    cols = [[(r[i] if i < len(r) else "").strip() for r in rows[:60]] for i in range(n)]
    pfs, sets = {norm(x) for x in portfolio_names if x}, {norm(x) for x in set_names if x}
    out = [""] * n

    def share(vals, ok):
        vals = [v for v in vals if v]
        return (sum(1 for v in vals if ok(v)) / len(vals)) if vals else 0
    ints = []
    for i, vals in enumerate(cols):
        if not any(vals):
            continue
        if share(vals, lambda v: bool(parse_date(v)) and not re.fullmatch(r"\d+", v)) >= .7:
            out[i] = "date"
        elif share(vals, lambda v: "$" in v or "€" in v or "£" in v or bool(re.fullmatch(r"-?[\d,]*\.\d{2}", v))) >= .7:
            out[i] = "paid"
        elif share(vals, lambda v: bool(re.fullmatch(r"\d{1,4}", v))) >= .9:
            ints.append(i)
        elif share(vals, lambda v: bool(re.fullmatch(r"[xX]?\d{1,4}[xX]?", v))) >= .9:
            out[i] = "qty"
        elif share(vals, lambda v: bool(parse_cond(v))) >= .7:
            out[i] = "condition"
        elif share(vals, lambda v: bool(re.fullmatch(r"[A-Za-z]{0,6}\d{1,4}[a-z]?(/[A-Za-z]{0,6}\d{1,4})?", v))) >= .7:
            out[i] = "number"
        elif pfs and share(vals, lambda v: norm(v) in pfs) >= .5:
            out[i] = "portfolio"
        elif sets and share(vals, lambda v: norm(v) in sets) >= .5:
            out[i] = "set"
    mean = lambda i: sum(int(v) for v in cols[i] if v) / max(1, sum(1 for v in cols[i] if v))
    if "qty" not in out and ints:                                  # whole numbers: the smallest on average is how many; another one is the card number
        q = min(ints, key=mean)
        if len(ints) > 1 or mean(q) <= 5:
            out[q] = "qty"
    for i in ints:
        if not out[i] and "number" not in out:
            out[i] = "number"
    for f in ("name", "set", "portfolio"):                         # the text columns left, left to right: the product, then its set, then the portfolio
        i = next((k for k in range(n) if not out[k] and any(cols[k])), None)
        if i is None or f in out:
            continue
        out[i] = f
    return out


def read_table(text, mapping=None, portfolio_names=(), set_names=()):
    """-> {'rows': [{fields}], 'columns': [{i, head, field, sample}], 'header': bool, 'delimiter'}.  mapping = [field or '' per column] chosen by the person (wins over everything)."""
    rows, delim = split_rows(text)
    if not rows:
        return {"rows": [], "columns": [], "header": False, "delimiter": delim}
    header = bool(delim) and _is_header(rows[0]) or (not delim and len(rows) > 1 and bool(header_fields(rows[0])[0]) and norm(rows[0][0]) in [norm(x) for x in HEADS["name"]])
    body = rows[1:] if header else rows
    n = max(len(r) for r in rows)
    if not delim:
        fields = ["name"]
    elif header:
        fields = header_fields(rows[0]) + [""] * (n - len(rows[0]))
        if "name" not in fields:                                   # a header that names everything but the product: the first unnamed text column is it
            guess = guess_fields(body, portfolio_names, set_names)
            i = next((k for k in range(n) if not fields[k] and guess[k] in ("name", "set", "portfolio", "")), None)
            if i is not None:
                fields[i] = "name"
    else:
        fields = guess_fields(body, portfolio_names, set_names)
    if mapping:
        fields = [(mapping[i] if i < len(mapping) and mapping[i] in FIELDS else "") for i in range(n)]
    cols = [{"i": i, "head": rows[0][i] if header and i < len(rows[0]) else f"Column {i + 1}", "field": fields[i], "sample": [r[i] for r in body[:3] if i < len(r)]} for i in range(n)]
    out = []
    for k, r in enumerate(body):
        g = {}
        for i, f in enumerate(fields):
            if f and i < len(r) and r[i] and f not in g:
                g[f] = r[i]
        line = r[0] if not delim else " | ".join(c for c in r if c)
        name, qty, cond = g.get("name", ""), None, ""
        if not delim:                                              # one product per line: "charizard ex 151 x2 nm" (how many and the condition are read out of it)
            from .webapi.insights import _parse_line
            qty, cond, name = _parse_line(name)
            cond = cond if re.search(r"\b(nm|lp|mp|hp|dmg|near mint|lightly|moderately|heavily|damaged|mint|played)\b", line.lower()) else ""
        q = parse_qty(g.get("qty"), qty or 1)
        paid = parse_money(g.get("paid"))
        total = parse_money(g.get("total"))
        if paid is None and total is not None:
            paid = round(total / q, 2)
        out.append({"i": k, "line": line, "name": name.strip(), "set": g.get("set", ""), "number": g.get("number", ""), "qty": q, "paid": paid,
                    "date": parse_date(g.get("date")), "dateText": g.get("date", ""), "condition": parse_cond(g.get("condition")) or cond, "portfolio": g.get("portfolio", "").strip(), "game": g.get("game", "")})
    return {"rows": out, "columns": cols, "header": header, "delimiter": delim}


# ---------------------------------------------------------------------------------------------------------------- the plan
def plan(items, names=None):
    """What will be added, by portfolio.  items = [{pf, qty, paid, price}] -> [{pf, name, items, copies, paid, value}] (paid = the money paid where it is known; value = today's price x copies)."""
    by = {}
    for it in items:
        pf = it.get("pf") or ""
        d = by.setdefault(pf, {"pf": pf, "name": (names or {}).get(pf) or (pf[4:] if pf.startswith("new:") else pf), "items": 0, "copies": 0, "paid": 0.0, "value": 0.0})
        q = int(it.get("qty") or 1)
        d["items"] += 1
        d["copies"] += q
        if it.get("paid") is not None:
            d["paid"] = round(d["paid"] + float(it["paid"]) * q, 2)
        if it.get("price") is not None:
            d["value"] = round(d["value"] + float(it["price"]) * q, 2)
    return sorted(by.values(), key=lambda d: (-d["copies"], d["name"].lower()))
