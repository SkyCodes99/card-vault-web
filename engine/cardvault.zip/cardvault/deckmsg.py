"""The deck rules' sentences, each with a code and its values, so the screen can show them in the chosen language: deck.rule.<code> in the UI's language files,
with this English as the fallback (ui/src/i18n/deckRuleText.js keeps the same English for the language check; tests/test_decks.py checks they match).
A Msg is still a plain English str, so everything that reads the problems as text keeps working."""

TEXT = {
    "gone": "A card in this deck isn't in the card list any more.",
    "copies": "Only {max} copies of {name} are allowed. You have {n}.",
    "banned": "{name} is banned in {fmt}.",
    "pkSize": "A deck needs exactly {size} cards. This one has {n}.",
    "pkMark": "{name} ({set}) isn't allowed in {fmt}: its mark is {mark}.",
    "pkNotAllowed": "{name} ({set}) isn't allowed in {fmt}.",
    "pkAce": "Only 1 ACE SPEC card is allowed. You have {n}.",
    "pkRadiant": "Only 1 Radiant Pokémon is allowed. You have {n}.",
    "pkBasic": "A deck needs at least 1 Basic Pokémon.",
    "opLeader": "A deck needs exactly 1 Leader.",
    "opLeaderN": "A deck needs exactly 1 Leader. This one has {n}.",
    "opSize": "A deck needs exactly {size} cards besides the Leader. This one has {n}.",
    "opColour": "{name} is {colors}, which doesn't match the Leader's colour ({lead}).",
    "opBanned": "{name} ({code}) is banned.",
    "opPair": "{a} ({ac}) and {b} ({bc}) can't be in the same deck.",
    "opBlock": "{name} ({code}) is Block {block}. Standard from {from} to {to} allows Blocks {lo}-{hi}.",
    "mtgCmdSize": "A Commander deck has exactly {size} cards, the commander included. This one has {n}.",
    "mtgChooseCmd": "Choose a commander (use the Commander button on a card).",
    "mtgCmdMax": "A Commander deck has at most {max} commanders. This one has {n}.",
    "mtgCmdSide": {"one": "A Commander deck has no sideboard. Move or remove its {n} sideboard card.",
                   "other": "A Commander deck has no sideboard. Move or remove its {n} sideboard cards."},
    "mtgMin": "A {fmt} deck needs at least {min} cards. This one has {n}.",
    "mtgSide": "A sideboard has at most {max} cards. This one has {n}.",
    "mtgCmdOnly": {"one": "Commander cards only go in a Commander deck. Move the {n} commander card to the main deck.",
                   "other": "Commander cards only go in a Commander deck. Move the {n} commander cards to the main deck."},
    "mtgNotLegal": "{name} isn't legal in {fmt}.",
    "mtgCopy1": "Only 1 copy of {name} allowed in {fmt}. You have {n}.",
    "mtgCopies": "Only {max} copies of {name} allowed in {fmt}. You have {n}.",
    "mtgIdent": "{name} has {ident} in its colour identity, outside the commander's ({cmd}).",
    "ygoMain": "A Main Deck needs {lo} to {hi} cards. This one has {n}.",
    "ygoExtra": "An Extra Deck can have {lo} to {hi} cards. This one has {n}.",
    "ygoSide": "A Side Deck can have {lo} to {hi} cards. This one has {n}.",
    "ygoPool": "{name} isn't in the {fmt} card pool.",
    "ygoForbidden": "{name} is Forbidden in the {fmt}: none allowed. You have {n}.",
    "ygoLimited": "{name} is Limited in the {fmt}: only 1 copy allowed. You have {n}.",
    "ygoSemi": "{name} is Semi-Limited in the {fmt}: only 2 copies allowed. You have {n}.",
    "ygoCopy1": "Only 1 copy of {name} allowed. You have {n}.",
    "ygoCopies": "Only {max} copies of {name} allowed. You have {n}.",
    "uaSize": "A deck needs exactly {size} cards besides the Action Point cards. This one has {n}.",
    "uaAp": "A deck needs exactly {size} Action Point cards. This one has {n}.",
    "uaSeries": "A deck can use cards of one source material only. This one has {list}.",
    "uaCopy1": "Only 1 copy of {name} allowed. You have {n}.",
    "uaCopies": "Only {max} copies of {name} allowed. You have {n}.",
    "uaCopy1R": "Only 1 copy of {name} allowed (restricted card). You have {n}.",
    "uaCopiesR": "Only {max} copies of {name} allowed (restricted card). You have {n}.",
}


def english(code, vals):
    t = TEXT[code]
    if isinstance(t, dict):
        t = t["one"] if vals.get("n") == 1 else t["other"]
    return t.format(**vals)


class Msg(str):
    """One rules sentence: str(msg) is the English; .code and .vals let the screen word it in another language."""

    def __new__(cls, code, /, **vals):                               # (positional-only: a sentence may have a value called 'code')
        s = super().__new__(cls, english(code, vals))
        s.code, s.vals = code, vals
        return s


def coded(items):
    """-> [{k, v}] beside the problems list (k is '' for a sentence without a code)."""
    return [{"k": getattr(m, "code", ""), "v": getattr(m, "vals", {})} for m in items]
