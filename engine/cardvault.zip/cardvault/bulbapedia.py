"""Optional second online source: set logos and set symbols from Bulbapedia's "List of Pokémon Trading Card Game expansions".

Download-only, one page plus the small pictures (~300 files, a few MB), a few at a time, with an identifying User-Agent.
Bulbapedia text is CC BY-NC-SA; the pictures are The Pokémon Company's artwork shown for identification - for personal use.
Used only when you press "Get set logos & symbols" on the Games page.
"""
import datetime
import difflib
import html
import json
import os
import re
import threading

from .runtime import INLINE
from concurrent.futures import ThreadPoolExecutor

import requests

from .db import open_cards_conn

PAGE = "https://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_Trading_Card_Game_expansions"
UA = "PokemonCardVault/1.0 (personal collection app; downloads set logos and symbols once)"
CREDIT = "Set logos and symbols: Bulbapedia (bulbapedia.bulbagarden.net), CC BY-NC-SA; artwork © The Pokémon Company."

_IMG = re.compile(r'<img[^>]+?src="([^"]+)"([^>]*)>', re.S)
_DATE = re.compile(r"([A-Z][a-z]+) (\d{1,2}), (\d{4})")


def setart_dir(gdir):
    return os.path.join(gdir, "images", "setart")


def art_path(gdir, set_id, kind):
    """kind: 'logo' | 'symbol'"""
    return os.path.join(setart_dir(gdir), f"{set_id.replace('/', '_')}_{kind}.png")


def _norm(name):
    n = html.unescape(name).lower()
    n = n.replace("pokémon", "pokemon").replace("&", "and")
    n = re.sub(r"\b(pokemon tcg|pokemon|expansion|set|tcg|and)\b", " ", n)
    n = re.sub(r"[^a-z0-9]+", " ", n)
    return re.sub(r"\s+", " ", n).strip()


def _best_url(src, attrs):
    """Prefer the 2x version from srcset (sharper, still small); otherwise the plain src."""
    m = re.search(r'srcset="([^"]+)"', attrs)
    if m:
        cands = [c.strip().split() for c in m.group(1).split(",")]
        two = [c[0] for c in cands if len(c) > 1 and c[1] == "2x"]
        if two:
            return html.unescape(two[0])
    return html.unescape(src)


def parse_page(text):
    """[{name, year, symbol, logo}] for every expansion row that has pictures."""
    out = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", text, re.S):
        imgs = _IMG.findall(row)
        sym = next(((s, a) for s, a in imgs if "SetSymbol" in s), None)
        logo = next(((s, a) for s, a in imgs if "_Logo" in s or "Logo_" in s), None)
        if not sym and not logo:
            continue
        cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)
        name = ""
        if len(cells) >= 7 and "<img" not in cells[3]:        # number | symbol | logo | name | type | cards | date | abbreviation
            name = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", cells[3])).strip())
        for c in ([] if name else cells):
            if "<img" in c:
                continue
            t = html.unescape(re.sub(r"<[^>]+>", "", c)).strip()
            if t and not t.isdigit() and not _DATE.search(t) and "Expansion" not in t and len(t) > 2 and not re.fullmatch(r"[A-Z0-9]{1,5}", t):
                name = re.sub(r"\s+", " ", t)
                break
        if not name:
            continue
        m = _DATE.search(html.unescape(re.sub(r"<[^>]+>", " ", row)))
        out.append({"name": name, "year": int(m.group(3)) if m else None,
                    "symbol": _best_url(*sym) if sym else None, "logo": _best_url(*logo) if logo else None})
    return out


_PREFIXES = ["ex", "diamond pearl", "platinum", "heartgold soulsilver", "hs", "black white", "bw", "xy", "sun moon", "sm",
             "sword shield", "swsh", "scarlet violet", "sv", "mega evolution", "call of legends"]


def _keys(name):
    """Every plausible short form of a Bulbapedia expansion name: 'HS—Undaunted' -> {'hs undaunted', 'undaunted'}."""
    raw = html.unescape(name)
    keys = {_norm(raw)}
    for part in re.split(r"\s*[—–\-:]\s*|�", raw):
        if part.strip():
            keys.add(_norm(part))
    for k in list(keys):
        for pre in _PREFIXES:
            if k.startswith(pre + " ") and len(k) > len(pre) + 2:
                keys.add(k[len(pre) + 1:])
    return {k for k in keys if k}


def match_sets(entries, sets):
    """Pair Bulbapedia rows with our sets: {set_id: entry}.  sets: [(id, name, release_date)]."""
    index = {}
    for e in entries:
        for k in _keys(e["name"]):
            index.setdefault(k, []).append(e)
    result = {}
    for sid, name, rel in sets:
        year = int(rel[:4]) if rel else None
        best = None
        for k in sorted(_keys(name), key=len, reverse=True):
            pool = index.get(k)
            if not pool:
                continue
            ok = [e for e in pool if year is None or e["year"] is None or abs(e["year"] - year) <= 1]
            if ok:
                best = min(ok, key=lambda e: abs((e["year"] or 0) - (year or 0)))
                break
        if best is None and "promo" not in name.lower():
            n = _norm(name)
            close = difflib.get_close_matches(n, list(index), n=1, cutoff=0.92)
            if close:
                ok = [e for e in index[close[0]] if year is None or e["year"] is None or abs(e["year"] - year) <= 1]
                if ok:
                    best = ok[0]
        if best is not None:
            result[sid] = best
    # galleries, shiny vaults and classic collections share the picture of the set they belong to
    names = {sid: _norm(n) for sid, n, _ in sets}
    for sid, name, rel in sets:
        if sid in result:
            continue
        n = _norm(name)
        for pid, pn in sorted(names.items(), key=lambda kv: -len(kv[1])):
            if pid in result and pid != sid and n.startswith(pn + " ") and n[len(pn) + 1:] in ("trainer gallery", "galarian gallery", "shiny vault", "classic collection"):
                result[sid] = result[pid]
                break
    return result


def _get(url, tries=4):
    import time
    last = None
    for i in range(tries):
        try:
            r = requests.get(url, timeout=40, headers={"User-Agent": UA})
            if r.status_code == 404:
                return None
            if r.status_code in (429,) or r.status_code >= 500:
                raise requests.HTTPError(f"HTTP {r.status_code}")
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            last = e
            time.sleep(2 * (i + 1))
    raise RuntimeError(f"Could not reach {url}: {last}")


def fetch_set_art(gdir, cancel, progress):
    """Download the logo and symbol of every set we can match.  Returns {'matched': n, 'downloaded': n, 'unmatched': [names]}."""
    conn = open_cards_conn(gdir)
    try:
        sets = [(r[0], r[1], r[2]) for r in conn.execute("SELECT id, name, release_date FROM sets")]
    finally:
        conn.close()
    progress("Reading Bulbapedia's list of expansions…", 0, 0)
    entries = parse_page(_get(PAGE).text)
    matches = match_sets(entries, sets)
    todo = []
    for sid, e in matches.items():
        for kind in ("logo", "symbol"):
            if e.get(kind) and not (os.path.exists(art_path(gdir, sid, kind)) and os.path.getsize(art_path(gdir, sid, kind)) > 0):
                todo.append((sid, kind, e[kind]))
    os.makedirs(setart_dir(gdir), exist_ok=True)
    done = [0]
    lock = threading.Lock()

    def one(item):
        sid, kind, url = item
        if cancel.is_set():
            return False
        r = _get(url)
        if r is not None and r.content:
            p = art_path(gdir, sid, kind)
            with open(p + ".part", "wb") as f:
                f.write(r.content)
            os.replace(p + ".part", p)
        with lock:
            done[0] += 1
            progress("Downloading set logos and symbols…", done[0], len(todo))
        return True

    if todo:
        progress("Downloading set logos and symbols…", 0, len(todo))
        if INLINE:
            for it in todo:
                one(it)
        else:
            with ThreadPoolExecutor(max_workers=3) as ex:
                list(ex.map(one, todo))
    meta = {"fetched": datetime.date.today().isoformat(), "matched": len(matches), "credit": CREDIT}
    with open(os.path.join(setart_dir(gdir), "setart.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f)
    unmatched = [n for sid, n, _ in sets if sid not in matches]
    return {"matched": len(matches), "downloaded": len(todo), "unmatched": unmatched, "total_sets": len(sets)}
