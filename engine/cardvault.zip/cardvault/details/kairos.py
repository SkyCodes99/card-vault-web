"""Sorcery: Contested Realm card details from the Sorcery Card Registry (Kairos Archive, https://kairosarchive.net/usage, the one file the accuracy check already reads each day): the printing's
artist, its flavour text, the rules text and keywords.  The registry has no TCGplayer id, so a card is tied by its exact name AND its exact set (Alpha, Beta, Arthurian Legends, Gothic,
Dragonlord); an artist is taken only when every printing of that card in that set names the same one - a card with two artists in one set is left blank, not guessed."""
from . import match

SOURCE = "sorc"
REGISTRY = "https://raw.githubusercontent.com/sadkinglabs/sorcery-registry/main/export/registry.json"


def read(fetcher):
    got = fetcher.get(REGISTRY, max_age=20 * 3600)
    d = got.json() if got.status == 200 else None
    if not isinstance(d, dict) or not isinstance(d.get("cards"), list) or not isinstance(d.get("printings"), list):
        raise ValueError(f"the Sorcery Card Registry is not available (HTTP {got.status})")
    return d


def facts(registry, ours):
    """ours: [(card id, name, set name)] -> ({card id: facts}, {"matched": n, "artist_unsure": n})."""
    cards = {c["codex_id"]: c for c in registry.get("cards") or () if c.get("codex_id")}
    by = {}
    for p in registry.get("printings") or ():
        c = cards.get(p.get("codex_id"))
        if c:
            by.setdefault((match.fold(c["name"]), match.fold(p.get("set_name"))), []).append((c, p))
    out, n = {}, {"matched": 0, "artist_unsure": 0}
    for cid, name, set_name in ours:
        hit = by.get((match.fold(match.base_name(name)), match.fold(set_name)))
        if not hit:
            continue
        c = hit[0][0]
        artists = {match.artist(p.get("artist")) for _c, p in hit if match.artist(p.get("artist"))}
        flavour = {match.clean(p.get("flavour_text")) for _c, p in hit if match.clean(p.get("flavour_text"))}
        if len(artists) > 1:
            n["artist_unsure"] += 1
        n["matched"] += 1
        ext = {"Keywords": match.joined(c.get("keywords")), "Flavor Text": next(iter(flavour)) if len(flavour) == 1 else ""}
        out[cid] = {"illustrator": next(iter(artists)) if len(artists) == 1 else "", "description": match.clean(c.get("rules_text")), "ext": {k: v for k, v in ext.items() if v}}
    return out, n
