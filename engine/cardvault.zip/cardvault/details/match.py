"""The small rules every card-detail source shares: how a source's record is tied to OUR card, and how its words are cleaned.

A record is only ever used when it is tied to the card by the card's own TCGplayer product id (or, where a source has no such id, by an exact name + set) AND its name still agrees with ours
(`same_card`) - the same "facts must agree" gate cardvault/gates.py puts on a new card.  Nothing is guessed: a record that does not agree is counted and left out."""
import html
import re
import unicodedata

_TAIL = re.compile(r"\s*[\(\[][^()\[\]]*[\)\]]")                    # '(Foil)', '[Extended Art]', '(Borderless)'


def fold(s):
    """'Pokémon  Ranger!' -> 'pokemonranger': letters and digits only, no accents, lower case."""
    s = unicodedata.normalize("NFKD", html.unescape(str(s or ""))).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", s)


_CODE = re.compile(r"\s+-\s+[A-Z]{2,5}\d{1,4}$")                       # 'Vynnset - HER112': the card's promo code


def base_name(name):
    """The name without the finish / product tails TCGplayer adds ('Sol Ring (Extended Art)' -> 'Sol Ring', 'Vynnset - HER112' -> 'Vynnset')."""
    s = str(name or "")
    while True:
        t = _CODE.sub("", _TAIL.sub("", s, count=1).strip())
        if t == s:
            return s.strip()
        s = t


def same_card(ours, theirs):
    """True when two names are the same card: equal once folded, or one starts with the other (TCGplayer's 'Name - Version' / a trailing finish word).  A two-faced card ('Front // Back') is the
    same card as either face, so the halves are compared one by one."""
    halves = lambda n: [fold(h) for h in re.split(r"\s+//\s+", base_name(n)) if fold(h)]
    for a in halves(ours):
        for b in halves(theirs):
            if a == b or a.startswith(b) or b.startswith(a):
                return True
    return False


def clean(text):
    """A source's text with its own markup out: HTML tags and entities, runs of blanks."""
    s = html.unescape(re.sub(r"<br\s*/?>|</p>", "\n", str(text or ""), flags=re.I))
    s = re.sub(r"<[^>]+>", "", s)
    return "\n".join(re.sub(r"[ \t]+", " ", ln).strip() for ln in s.split("\n") if ln.strip()).strip()


def artist(value):
    """One artist or a list of them -> 'A' or 'A, B' ('' when there is none / a placeholder)."""
    items = value if isinstance(value, (list, tuple)) else [value]
    seen = []
    for a in items:
        a = re.sub(r"\s+", " ", str(a or "")).strip()
        if a and a.lower() not in ("n/a", "unknown", "none", "-") and a not in seen:
            seen.append(a)
    return ", ".join(seen)


def joined(values, sep=";"):
    """['Flying', 'Haste'] -> 'Flying;Haste' (the way TCGplayer's own fields hold several values: the detail screen and the filters split on ';')."""
    out = []
    for v in values or ():
        v = re.sub(r"\s+", " ", str(v or "")).strip()
        if v and v not in out:
            out.append(v)
    return sep.join(out)


def number(value):
    """A source's number -> a short plain string ('' for missing); whole floats lose '.0'."""
    if value is None or value == "":
        return ""
    if isinstance(value, float) and value == int(value):
        value = int(value)
    return str(value).strip()
