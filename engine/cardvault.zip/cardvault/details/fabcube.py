"""Flesh and Blood card details from The FaB Cube (https://github.com/the-fab-cube/flesh-and-blood-cards, the open data set the accuracy check already reads): the printing's artist(s), its flavour text,
keywords, the figures TCGplayer leaves blank and the formats the card may be played in.  A printing is tied to our card by its TCGplayer product id and must still carry our card's name."""
from . import match

SOURCE = "fabc"
BASE = "https://raw.githubusercontent.com/the-fab-cube/flesh-and-blood-cards/develop/json/english/"
# the data set's format flags -> (format shown, its legal flag, its banned flag, the flag of a card held back for a while, what that is called here).  A suspended card cannot be played until it is
# reinstated, so it counts as banned; Living Legend's "restricted" is the same word the app already uses.
FORMATS = (("Classic Constructed", "cc_legal", "cc_banned", "cc_suspended", "banned"), ("Blitz", "blitz_legal", "blitz_banned", "blitz_suspended", "banned"),
           ("Commoner", "commoner_legal", "commoner_banned", None, ""), ("Living Legend", "ll_legal", "ll_banned", "ll_restricted", "restricted"), ("Silver Age", "silver_age_legal", "silver_age_banned", None, ""))


def read(fetcher):
    got = fetcher.get(BASE + "card.json", max_age=20 * 3600)
    data = got.json() if got.status == 200 else None
    if not isinstance(data, list) or len(data) < 1000:
        raise ValueError(f"the FaB Cube card file is not available (HTTP {got.status})")
    return data


def _ext(card, printing):
    ext = {"Keywords": match.joined(card.get("card_keywords")), "Flavor Text": match.clean(printing.get("flavor_text_plain") or printing.get("flavor_text")),
           "Cost": match.number(card.get("cost")), "Pitch Value": match.number(card.get("pitch")), "Power": match.number(card.get("power")), "Defense Value": match.number(card.get("defense")),
           "Life": match.number(card.get("health")), "Intellect": match.number(card.get("intelligence")), "Arcane": match.number(card.get("arcane"))}
    return {k: v for k, v in ext.items() if v}


def legality_of(card):
    out = []
    for label, legal, banned, held, held_status in FORMATS:
        if card.get(banned):
            out.append((label, "banned"))
        elif held and card.get(held):
            out.append((label, held_status))
        elif card.get(legal):
            out.append((label, "legal"))
    return out


def facts(records, ours):
    """records: the card.json list; ours: [(card id, tcg id, name)] -> ({card id: facts}, {card id: [(format, status)]}, {"matched": n, "disagree": n})."""
    by = {}
    for card in records or ():
        for p in card.get("printings") or ():
            if p.get("tcgplayer_product_id"):
                by[str(p["tcgplayer_product_id"])] = (card, p)
    out, legal, n = {}, {}, {"matched": 0, "disagree": 0}
    for cid, tcg, name in ours:
        hit = by.get(str(tcg or ""))
        if not hit:
            continue
        card, p = hit
        if not match.same_card(name, card.get("name")):
            n["disagree"] += 1
            continue
        n["matched"] += 1
        out[cid] = {"illustrator": match.artist(p.get("artists")), "description": match.clean(card.get("functional_text_plain")), "ext": _ext(card, p)}
        legal[cid] = legality_of(card)
    return out, legal, n
