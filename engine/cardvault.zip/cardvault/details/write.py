"""Writes what a source says about a card into the card list - and only into what is EMPTY.

    facts = {card id: {"illustrator": "Hadjie Joos", "description": "card text", "ext": {"Keywords": "Flying;Haste", "Level": "4"}}}

  - illustrator / description / hp / stage (columns of the card): filled when the card has none yet; never replaced.
  - ext (the fields of the shop's own record inside cards.raw): a key is added when the card does not have it (or has it blank); a value TCGplayer gave is never replaced.
  - provenance: each card that gained something gets one record, field 'details', naming the source and the day (the card detail's "Sources" line shows it).
Safe to run again (a second run changes nothing).  TCGplayer's daily refresh writes cards.raw afresh, so the nightly run (tools/enrich_details.py) puts the details back."""
import json

from .. import provenance

FIELD = "details"
BLANK = ("", None, "N/A", "n/a")


def _blank(v):
    return v in BLANK or (isinstance(v, str) and not v.strip())


def fill(conn, source, facts, day=None, dry=False):
    """-> {"cards": cards that gained something, "illustrator": n, "description": n, "ext": {key: n}}.  The caller commits (a dry run writes nothing)."""
    out = {"cards": 0, "illustrator": 0, "description": 0, "hp": 0, "stage": 0, "ext": {}}
    ids = [i for i in facts if facts[i]]
    updates, prov = [], []
    for i in range(0, len(ids), 900):
        part = ids[i:i + 900]
        rows = conn.execute(f"SELECT id, illustrator, description, raw, hp, stage FROM cards WHERE id IN ({','.join('?' * len(part))})", part).fetchall()
        for cid, illus, desc, raw, hp, stage in rows:
            f = facts[cid]
            new_illus, new_desc, changed = None, None, False
            if f.get("illustrator") and _blank(illus):
                new_illus, changed = f["illustrator"], True
                out["illustrator"] += 1
            if f.get("description") and _blank(desc):
                new_desc, changed = f["description"], True
                out["description"] += 1
            new_hp = new_stage = None
            if f.get("hp") and not hp:
                new_hp, changed = int(f["hp"]), True
                out["hp"] += 1
            if f.get("stage") and _blank(stage):
                new_stage, changed = f["stage"], True
                out["stage"] += 1
            new_raw = None
            if f.get("ext"):
                try:
                    doc = json.loads(raw) if raw else {}
                except ValueError:
                    doc = {}
                if isinstance(doc, dict):
                    ext = doc.setdefault("ext", {}) if isinstance(doc.get("ext", {}), dict) else {}
                    got = False
                    for k, v in f["ext"].items():
                        if not _blank(v) and _blank(ext.get(k)):
                            ext[k] = v
                            out["ext"][k] = out["ext"].get(k, 0) + 1
                            got = True
                    if got:
                        doc["ext"] = ext
                        new_raw, changed = json.dumps(doc, ensure_ascii=False), True
            if changed:
                out["cards"] += 1
                updates.append((new_illus, new_desc, new_raw, new_hp, new_stage, cid))
                prov.append((cid, FIELD, source, day))
    if updates and not dry:
        conn.executemany("UPDATE cards SET illustrator=COALESCE(?, illustrator), description=COALESCE(?, description), raw=COALESCE(?, raw), hp=COALESCE(?, hp), stage=COALESCE(?, stage) WHERE id=?", updates)
        provenance.record_many(conn, prov)
        _refold(conn, [u[5] for u in updates if u[0]])
    return out


def _refold(conn, ids):
    """The search words of a card hold its artist: a card that just got one has them made again (cardvault/searchfold.py fills only the cards whose words are empty)."""
    if not ids or not any(r[1] == "fold" for r in conn.execute("PRAGMA table_info(cards)")):
        return
    for i in range(0, len(ids), 900):
        part = ids[i:i + 900]
        conn.execute(f"UPDATE cards SET fold=NULL WHERE id IN ({','.join('?' * len(part))})", part)
    from .. import searchfold
    searchfold.fill(conn)
