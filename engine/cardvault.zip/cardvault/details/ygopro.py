"""Yu-Gi-Oh! card details from YGOPRODeck (https://ygoprodeck.com, the one cardinfo file the daily free-price check already reads): the card's level or rank, link rating and arrows, pendulum scale,
archetype and the monster type / ATK / DEF TCGplayer leaves blank.  A card is tied to ours by its set code (+ rarity) the way the free prices and the accuracy check do it, only when that
code names ONE card in the source, and the card's name must still agree with ours.  (There is no artist for a Yu-Gi-Oh! card: the game does not credit one.)"""
from . import match
from ..freeprices_ygo import URL, norm_code, norm_rarity

SOURCE = "ygop"


def read(fetcher):
    got = fetcher.get(URL, max_age=20 * 3600)
    data = got.json() if got.status == 200 else None
    cards = data.get("data") if isinstance(data, dict) else None
    if not cards or len(cards) < 5000:
        raise ValueError(f"the YGOPRODeck card file is not available (HTTP {got.status})")
    return cards


def facts_of(c):
    kind = str(c.get("type") or "")
    ext = {"Archetype": match.clean(c.get("archetype")), "Pendulum Scale": match.number(c.get("scale")), "MonsterType": match.clean(c.get("race")) if "Monster" in kind else "",
           "Attack": match.number(c.get("atk")), "Defense": match.number(c.get("def")), "LinkArrows": match.joined(c.get("linkmarkers"))}
    if "Link" in kind:
        ext["LinkRating"] = match.number(c.get("linkval"))
    elif "XYZ" in kind.upper():
        ext["Rank"] = match.number(c.get("level"))
    elif "Monster" in kind:
        ext["Level"] = match.number(c.get("level"))
    return {"description": match.clean(c.get("desc")), "ext": {k: v for k, v in ext.items() if v}}


def facts(cards, ours):
    """ours: [(card id, set code, rarity, name)] -> ({card id: facts}, {"matched": n, "disagree": n, "ambiguous": n})."""
    exact, by_code = {}, {}
    for c in cards or ():
        for s in c.get("card_sets") or ():
            code = (s.get("set_code") or "").strip().upper()
            if code:
                exact.setdefault((code, norm_rarity(s.get("set_rarity"))), {})[c["id"]] = c
                by_code.setdefault(norm_code(code), {})[c["id"]] = c
    out, n = {}, {"matched": 0, "disagree": 0, "ambiguous": 0}
    for cid, code, rarity, name in ours:
        code = (code or "").strip().upper()
        if not code or code == "N/A":
            continue
        cands = exact.get((code, norm_rarity(rarity))) or by_code.get(norm_code(code)) or {}
        if len(cands) != 1:
            n["ambiguous"] += 1 if cands else 0
            continue
        c = next(iter(cands.values()))
        if not match.same_card(name, c.get("name")):
            n["disagree"] += 1
            continue
        n["matched"] += 1
        out[cid] = facts_of(c)
    return out, n
