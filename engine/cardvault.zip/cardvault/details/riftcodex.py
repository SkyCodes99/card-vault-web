"""Riftbound card details from Riftcodex (https://riftcodex.com, the free fan API the accuracy check already reads): the artist, the flavour line, the card text and the figures TCGplayer leaves
blank.  A Riftcodex card is tied to ours by its TCGplayer product id (`tcgplayer_id`) and must still carry our card's name."""
from . import match

SOURCE = "rift"
URL = "https://api.riftcodex.com/cards?size=100&page={page}"


def read(fetcher):
    """-> every Riftcodex card (15 pages of 100, kept a day by the polite reader).  Raises when a page is missing: half a list is not used."""
    cards, page = [], 1
    while page < 60:
        got = fetcher.get(URL.format(page=page), max_age=20 * 3600)
        d = got.json() if got.status == 200 else None
        if not isinstance(d, dict) or not isinstance(d.get("items"), list):
            raise ValueError(f"Riftcodex page {page} not available (HTTP {got.status})")
        cards += d["items"]
        if page >= int(d.get("pages") or 1):
            return cards
        page += 1
    return cards


def facts_of(c):
    a, cl, text = c.get("attributes") or {}, c.get("classification") or {}, c.get("text") or {}
    ext = {"Energy Cost": match.number(a.get("energy")), "Might": match.number(a.get("might")), "Power Cost": match.number(a.get("power")), "Card Type": match.clean(cl.get("type")),
           "Supertype": match.clean(cl.get("supertype")), "Domain": match.joined(cl.get("domain")), "Tag": match.joined(c.get("tags")), "Flavor Text": match.clean(text.get("flavour"))}
    return {"illustrator": match.artist((c.get("media") or {}).get("artist")), "description": match.clean(text.get("rich") or text.get("plain")), "ext": {k: v for k, v in ext.items() if v}}


def facts(records, ours):
    """-> ({card id: facts}, {"matched": n, "disagree": n}); ours: [(card id, tcg id, name)]."""
    by = {str(c["tcgplayer_id"]): c for c in records or () if c.get("tcgplayer_id")}
    out, n = {}, {"matched": 0, "disagree": 0}
    for cid, tcg, name in ours:
        c = by.get(str(tcg or ""))
        if not c:
            continue
        if not match.same_card(name, c.get("name")):
            n["disagree"] += 1
            continue
        n["matched"] += 1
        out[cid] = facts_of(c)
    return out, n
