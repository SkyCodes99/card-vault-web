"""Pokemon cards that exist only in TCGplayer's catalogue (promo packs, prize packs, World Championship decks, trainer kits ... TCGdex does not list them) carry their HP and stage inside the
shop's own record (cards.raw ext 'HP', 'Stage') but not in the card's HP / stage columns, so they would never show up under the HP or stage filters.  This copies exactly what the card's OWN record
says into the empty columns - no other source, no guess.  (Their artist is in no source the app reads: left empty.)"""
import json
import re

SOURCE = "tcgp"
_STAGES = {"basic", "stage 1", "stage 2", "vmax", "vstar", "v-union", "mega", "break", "level-up", "restored", "baby", "stage1", "stage2"}


def facts(conn):
    """-> {card id: {"hp": int, "stage": str}} for the cards whose own record has them and whose columns are empty."""
    out = {}
    for cid, raw in conn.execute("SELECT id, raw FROM cards WHERE (hp IS NULL OR hp = 0 OR stage IS NULL OR stage = '') AND raw LIKE '%\"ext\"%'"):
        try:
            ext = (json.loads(raw) or {}).get("ext") or {}
        except ValueError:
            continue
        f = {}
        m = re.fullmatch(r"\s*(\d{1,4})\s*", str(ext.get("HP") or ""))
        if m and int(m.group(1)) > 0:
            f["hp"] = int(m.group(1))
        stage = str(ext.get("Stage") or "").strip()
        if stage.lower() in _STAGES:
            f["stage"] = stage
        if f:
            out[cid] = f
    return out
