"""Full card details for every card game (roadmap: artist, rarity, HP, attacks and abilities, card text, regulation mark and the like - all searchable).

What each game's list holds comes from two places: the shop's own record (TCGplayer: rarity, card type, cost, power, text ...) and, for Pokemon, TCGdex's (HP, attacks, abilities, regulation mark,
artist).  This package fills the gaps from the free sources the app already reads, through the same polite reader (cardvault/sources: robots.txt, rate limit, cache):

    game        source (module)                   adds
    lorcana     Lorcast (lorcast.py)              illustrator, card text, keywords, move cost, flavour text, Core / Infinity legality
    fab         The FaB Cube (fabcube.py)         artist(s), keywords, flavour text, formats (Classic Constructed, Blitz, Commoner, Living Legend, Silver Age)
    riftbound   Riftcodex (riftcodex.py)          artist, flavour text, card text, tags
    sorcery     Sorcery Card Registry (kairos.py) artist, flavour text, card text, keywords
    yugioh      YGOPRODeck (ygopro.py)            level / rank, link rating + arrows, pendulum scale, archetype, monster type, ATK / DEF
    mtg         Scryfall (tools/enrich_mtg.py)    artist, keywords, loyalty, defense, colours, mana cost, power / toughness

Every fact is exact: the source's record is tied to the card by the card's TCGplayer product id (or, where the source has none, its exact name + set), its name must still agree with ours
(match.same_card), only EMPTY fields are filled, and each card that gained something gets a provenance record (field 'details') naming the source and the day.  A game none of these cover keeps
what its shop record says; docs/card_details.md lists, per game, what is complete and what no allowed free source can give.

apply(conn, game) is safe to run again; the daily update and the catalog publish both call it (TCGplayer's refresh rewrites cards.raw, so the details are put back each night)."""
import datetime

from .. import legality
from .write import fill

GAMES = ("lorcana", "fab", "riftbound", "sorcery", "yugioh", "pokemon", "pokemon_jp")           # (Magic goes through tools/enrich_mtg.py)


def _rows(conn, sql):
    return conn.execute(sql).fetchall()


def apply(conn, game, fetcher=None, records=None, day=None, dry=False):
    """Fill one game's list from its source.  records: what the source's read() gave (tests pass their own; otherwise it is read now through the polite reader).
    -> {"game", "source", "cards" (gained something), "illustrator", "description", "ext": {key: n}, "matched", "legality" (cards with formats), ...}.  The caller commits."""
    if game not in GAMES:
        return {"game": game, "skipped": "no card-detail source for this game"}
    from . import fabcube, kairos, lorcast, pokemon, riftcodex, ygopro        # (read only when a list is filled in: the screens never need the source readers)
    day = day or datetime.date.today().isoformat()
    if game in ("pokemon", "pokemon_jp"):                                       # the cards only TCGplayer lists: their HP / stage from their own record (no network)
        res = fill(conn, pokemon.SOURCE, pokemon.facts(conn), day=day, dry=dry)
        res.update(game=game, source=pokemon.SOURCE)
        return res
    if records is None:
        if fetcher is None:
            from .. import sources
            fetcher = sources.default()
        records = {"lorcana": lorcast, "fab": fabcube, "riftbound": riftcodex, "sorcery": kairos, "yugioh": ygopro}[game].read(fetcher)
    legal, extra = {}, {}
    if game == "lorcana":
        facts, legal, extra = lorcast.facts(records, _rows(conn, "SELECT id, tcg_id, name FROM cards"))
        source = lorcast.SOURCE
    elif game == "fab":
        facts, legal, extra = fabcube.facts(records, _rows(conn, "SELECT id, tcg_id, name FROM cards"))
        source = fabcube.SOURCE
    elif game == "riftbound":
        facts, extra = riftcodex.facts(records, _rows(conn, "SELECT id, tcg_id, name FROM cards"))
        source = riftcodex.SOURCE
    elif game == "sorcery":
        facts, extra = kairos.facts(records, _rows(conn, "SELECT c.id, c.name, s.name FROM cards c LEFT JOIN sets s ON s.id=c.set_id"))
        source = kairos.SOURCE
    else:
        facts, extra = ygopro.facts(records, _rows(conn, "SELECT id, local_id, rarity, name FROM cards"))
        source = ygopro.SOURCE
    res = fill(conn, source, facts, day=day, dry=dry)
    res.update(game=game, source=source, **extra)
    if legal and not dry:
        rows = [(cid, f, st, day) for cid, fs in legal.items() for f, st in fs]
        if rows:
            legality.replace_source(conn, source, rows, min_rows=0)
            res["legality"] = len(legal)
    return res
