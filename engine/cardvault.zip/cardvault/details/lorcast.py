"""Disney Lorcana card details from Lorcast (https://lorcast.com/, the free API the daily price check already reads): the card's illustrator, its card text, its keywords and the figures TCGplayer
leaves blank.  A Lorcast card is tied to ours by the TCGplayer product id it carries (`tcgplayer_id`) and must still carry our card's name ('Name - Version')."""
from . import match

SOURCE = "lorc"


def read(fetcher):
    """-> Lorcast's card objects (one file per set, kept a day by the polite reader).  Raises when a set is missing: half a list is not used."""
    from ..freeprices_lorcana import read_all
    return read_all(fetcher)[0]


def _name(c):
    return f"{c.get('name') or ''} - {c['version']}" if c.get("version") else (c.get("name") or "")


def facts_of(c):
    """One Lorcast card -> the facts we keep (see write.fill)."""
    ext = {"Keywords": match.joined(c.get("keywords")), "Move Cost": match.number(c.get("move_cost")), "Cost Ink": match.number(c.get("cost")),
           "Strength": match.number(c.get("strength")), "Willpower": match.number(c.get("willpower")), "Lore Value": match.number(c.get("lore")),
           "Classification": match.joined(c.get("classifications")), "Flavor Text": match.clean(c.get("flavor_text"))}
    return {"illustrator": match.artist(c.get("illustrators")), "description": match.clean(c.get("text")), "ext": {k: v for k, v in ext.items() if v}}


def legality_of(c):
    """Lorcast's own legalities -> [(format, status)]: Core and Infinity, when legal."""
    return [(label, "legal") for key, label in (("core", "Core"), ("infinity", "Infinity")) if (c.get("legalities") or {}).get(key) == "legal"]


def facts(records, ours):
    """records: Lorcast cards; ours: [(card id, tcg id, name)] -> ({card id: facts}, {card id: [(format, status)]}, {"matched": n, "disagree": n})."""
    by = {str(c["tcgplayer_id"]): c for c in records or () if c.get("tcgplayer_id")}
    by_name = {}
    for c in records or ():
        by_name.setdefault(match.fold(_name(c)), []).append(c)
    out, legal, n = {}, {}, {"matched": 0, "disagree": 0, "by_name": 0}
    for cid, tcg, name in ours:
        c = by.get(str(tcg or ""))
        if not c:                                                  # a promo TCGplayer files under its own product (Lorcast has none for it): the card's artist when EVERY printing of that exact name + version names the same one
            artists = {match.artist(x.get("illustrators")) for x in by_name.get(match.fold(match.base_name(name)), ())} - {""}
            if len(artists) == 1:
                out[cid] = {"illustrator": next(iter(artists))}
                n["by_name"] += 1
            continue
        if not match.same_card(name, _name(c)):
            n["disagree"] += 1
            continue
        n["matched"] += 1
        out[cid], legal[cid] = facts_of(c), legality_of(c)
    return out, legal, n
