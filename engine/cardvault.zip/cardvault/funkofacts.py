"""Edition size and review notes for the Funko list, written into each Pop's raw ext on every rebuild (so the nightly refresh keeps them).

EDITION: a Pop's edition size ("Limited to 5,000 pieces") is written ONLY when a source's own text states it ('Limited Edition of 5000', 'limited to 2,500 pieces').  It is never guessed from the word
'exclusive' or 'limited edition' alone.  A Pop marked 'Limited Edition' whose text gives no number gets a review note instead.
REVIEW: raw ext 'Review' lists what could not be confirmed - a fandom no rule recognised, an edition size no source states.  Pure text rules + one idempotent pass over the open connection."""
import json
import re

_EDITION = re.compile(r"(?:limited\s+(?:edition\s+)?(?:of|to)|edition\s+of|run\s+of)\s*(?:only\s*)?(\d[\d,]*)\s*(?:pieces|pcs|units|copies)?(?![\d,]*\s*(?:\"|inch|in\b|oz|-piece|per\b|each\b|/))", re.I)
_LIMITED = re.compile(r"limited edition", re.I)
FANDOM_REVIEW = "Fandom not confirmed: no source or name rule says which fandom this Pop belongs to, so it stays in 'Other'."
EDITION_REVIEW = "Marked 'Limited Edition' but no source states how many were made, so no piece count is shown."


def edition_of(text):
    """The piece count a text states ('Limited Edition of 5000' -> 5000), or None.  A year, a size or a pack count is not an edition size."""
    m = _EDITION.search(text or "")
    if not m:
        return None
    n = int(m.group(1).replace(",", ""))
    return n if n >= 2 and not 1900 <= n <= 2100 else None


def notes_for(name, rarity, description, set_id):
    """-> (edition, [review notes]) for one Pop."""
    edition = edition_of(description)
    review = []
    if set_id == "fd:other":
        review.append(FANDOM_REVIEW)
    if edition is None and (str(rarity or "").startswith("Limited Edition") or _LIMITED.search(name or "")):
        review.append(EDITION_REVIEW)
    return edition, review


def apply(conn):
    """Write Edition + Review into every Pop's raw ext; rewrite a row only when its notes changed.  -> (editions stated, rows on review)."""
    stated = reviewed = 0
    for cid, name, rarity, desc, set_id, raw in conn.execute("SELECT id, name, rarity, description, set_id, raw FROM cards").fetchall():
        edition, review = notes_for(name, rarity, desc, set_id)
        stated += edition is not None
        reviewed += bool(review)
        try:
            doc = json.loads(raw or "{}")
        except ValueError:
            continue
        ext = doc.get("ext") if isinstance(doc.get("ext"), dict) else {}
        want = dict(ext)
        for key in ("Edition", "Review"):
            want.pop(key, None)
        if edition:
            want["Edition"] = f"Limited to {edition:,} pieces"
        if review:
            want["Review"] = " ".join(review)
        if want != ext:
            doc["ext"] = want
            conn.execute("UPDATE cards SET raw=? WHERE id=?", (json.dumps(doc, ensure_ascii=False), cid))
    return stated, reviewed
