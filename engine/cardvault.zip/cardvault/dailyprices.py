"""The once-a-day price update.

TCGplayer's free price feed (tcgcsv.com) refreshes once a day, around 20:00 UTC.  Our website reads it at 20:03 UTC (three minutes later) and publishes one small
file per game with the price of every card and product.  This app takes those files: it looks once after 20:03 UTC each day; if the website has not published
the new day yet it looks again every 5 minutes (every hour after 8 hours) until it has, applies it, and then does not look again until the next day."""
import datetime
import gzip
import json
import os
import sqlite3

from . import sync
from .tcggames import by_game_id, data_slug

RUN_HOUR, RUN_MINUTE = 20, 3                       # UTC: three minutes after the price feed's own daily update
RETRY_SECONDS = 300
KINDS = {0: None, 1: "market (other printing)", 2: "mid price", 3: "low price"}


def expected_day(now=None):
    """The price day we should have by now: today's once 20:03 UTC has passed, otherwise yesterday's."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    return (now if now >= cut else now - datetime.timedelta(days=1)).strftime("%Y-%m-%d")


def next_daily_run(now=None):
    """Seconds from now until the next 20:03 UTC."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    if now >= cut:
        cut += datetime.timedelta(days=1)
    return (cut - now).total_seconds()


def retry_delay(now=None):
    """5 minutes while the day is fresh (the update may just be late); hourly once it has been missing for 8+ hours."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    if now < cut:
        cut -= datetime.timedelta(days=1)
    return RETRY_SECONDS if (now - cut).total_seconds() < 8 * 3600 else 3600


def base_for(catalog_base):
    b = catalog_base.rstrip("/")
    return (b.rsplit("/", 1)[0] + "/prices") if "/" in b else "prices"


def manifest(base):
    d = sync._get(base.rstrip("/") + "/manifest.json", tries=1)
    return {**d, "games": by_game_id(d["games"])} if isinstance(d, dict) and isinstance(d.get("games"), dict) else None          # (the games under the app's own ids: Card Data names some of them differently)


def _mark(gdir):
    return os.path.join(gdir, "prices_built.txt")


def _db_meta(gdir, key):
    try:
        c = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=30)
        try:
            r = c.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        finally:
            c.close()
        return (r[0] if r else "") or ""
    except sqlite3.Error:
        return ""


def local_built(gdir):
    """The day of the prices that are really IN this card list.  The marker file says what we last applied; but a refreshed card list (downloaded later) brings its own, older prices
    and leaves the marker behind - so the card list's own record (meta 'prices_updated') must agree, else the day counts as the older one and today's prices are fetched again."""
    try:
        mark = open(_mark(gdir), encoding="utf-8").read().strip()
    except OSError:
        return ""
    own = _db_meta(gdir, "prices_updated")[:10]
    return min(mark, own) if own and mark else mark


def apply(gdir, doc):
    """Write a day's prices into this game's card list (and sealed products).  Only prices that exist are written; a card never loses the price it has.  -> number of prices applied."""
    day = str(doc.get("built") or "")
    items = doc.get("items")
    if not day or not isinstance(items, dict):
        raise ValueError("the price file is not readable")
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=60)
    n = 0
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(cards)")}
        rows = [(float(v[0]), KINDS.get(int(v[1]) if len(v) > 1 else 0), day, str(k)) for k, v in items.items() if isinstance(v, list) and v and v[0] is not None]
        if "tcg_id" in cols:
            conn.executemany("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE tcg_id=?", rows)
            n = len(rows)
        try:
            conn.executemany("UPDATE sealed_products SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", rows)
        except sqlite3.Error:
            pass
        conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (day,))
        conn.commit()
    finally:
        conn.close()
    with open(_mark(gdir), "w", encoding="utf-8") as f:
        f.write(day)
    return n


def _subtypes_mark(gdir):
    return os.path.join(gdir, "subtypes_built2.txt")          # (2: the printings fix - existing copies fetch the file once more)


def apply_subtypes(gdir, doc):
    """Store the price of every printing of every card (from <game>.subtypes.json.gz) -> number of cards updated."""
    items = doc.get("items")
    day = str(doc.get("built") or "")
    if not day or not isinstance(items, dict):
        raise ValueError("the printing-price file is not readable")
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=60)
    try:
        if "variant_prices" not in {r[1] for r in conn.execute("PRAGMA table_info(cards)")}:
            conn.execute("ALTER TABLE cards ADD COLUMN variant_prices TEXT")
        rows = []
        for pid, subs in items.items():
            if not isinstance(subs, dict):
                continue
            one = {k: v[0] for k, v in subs.items() if isinstance(v, list) and v and isinstance(v[0], (int, float)) and v[0] > 0}
            if one:
                rows.append((json.dumps(one, separators=(",", ":")), str(pid)))
        conn.executemany("UPDATE cards SET variant_prices=? WHERE tcg_id=?", rows)
        fixed = _fix_variants(conn, items)
        conn.execute("INSERT OR REPLACE INTO meta VALUES('subtypes_built', ?)", (day,))        # recorded IN the card list too, so a replaced list is noticed
        conn.commit()
    finally:
        conn.close()
    with open(_subtypes_mark(gdir), "w", encoding="utf-8") as f:
        f.write(day)
    return len(rows)


def _flags_from(subs):
    """The printing flags TCGplayer's price list implies for one card: {'normal','reverse','holo','firstEdition'} that are True."""
    keys = set(subs)
    out = {}
    plain = keys & {"Normal", "Unlimited", "Unlimited Normal"}
    if plain:
        out["normal"] = True
    if "Reverse Holofoil" in keys:
        out["reverse"] = True
    if keys & {"Holofoil", "Unlimited Holofoil", "1st Edition Holofoil"}:
        out["holo"] = True
    if keys & {"1st Edition", "1st Edition Normal", "1st Edition Holofoil"}:
        out["firstEdition"] = True
    if keys and not plain and not (keys & {"1st Edition", "1st Edition Normal", "Reverse Holofoil"}) and out.get("holo"):
        out["holoOnly"] = True                           # only ever printed as a holo: it has no plain version
    nv, hv = subs.get("Normal"), subs.get("Holofoil")
    if isinstance(nv, (list, tuple)) and nv and nv[0] is None and isinstance(hv, (list, tuple)) and hv and hv[0] is not None:
        out["ghostNormal"] = True                        # a 'Normal' entry that has never sold (no market price) next to a holofoil that has: the card is a holo (Rocket's Scyther ex)
    return out


def _fix_variants(conn, items):
    """The card list says which printings a card has (normal / reverse / holo / 1st Edition) from one source, and it is often missing the reverse holo of
    cards whose sets did have them (Dark Explorers, Boundaries Crossed, Lost Thunder, Hidden Fates...).  TCGplayer's list of printings fills those in (it only ever ADDS
    a printing; a holo-only card also loses a 'normal' it never had)."""
    cur, size = {}, {}
    for cid, t, v, sid, tot in conn.execute("SELECT c.id, c.tcg_id, c.variants, c.set_id, COALESCE(s.total, 0) FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.tcg_id IS NOT NULL"):
        cur.setdefault(str(t), []).append((cid, v, sid))            # several cards can share one TCGplayer product (a reprint, a kit card)
        size[sid] = tot
    upd = []
    for pid, subs in items.items():
        if not isinstance(subs, dict) or str(pid) not in cur:
            continue
        add = _flags_from(subs)
        sets_here = {sid for _c, _v, sid in cur[str(pid)]}
        owner = max(sets_here, key=lambda x: size.get(x, 0)) if len(sets_here) > 1 else None          # a product shared by cards of DIFFERENT sets belongs to the biggest one:
        for cid, raw, sid in cur[str(pid)]:                         # a kit's or a reprint set's card never gets a printing (reverse holo...) only the other set's card has
            if owner is not None and size.get(sid, 0) < size.get(owner, 0):
                continue
            try:
                flags = json.loads(raw) if raw else {}
            except ValueError:
                continue
            new = dict(flags)
            changed = False
            for k in ("normal", "reverse", "holo", "firstEdition"):
                if add.get(k) and not new.get(k):
                    new[k] = True; changed = True
            if (add.get("holoOnly") or add.get("ghostNormal")) and new.get("normal") and (not add.get("normal") or add.get("ghostNormal")):
                new["normal"] = False; changed = True              # TCGplayer lists only a holofoil: the card has no plain version (Rocket's Scyther ex, the EX-era ex cards...)
            if changed:
                upd.append((json.dumps(new, separators=(", ", ": ")), cid))
    conn.executemany("UPDATE cards SET variants=? WHERE id=?", upd)
    return len(upd)


def subtypes_built(gdir):
    try:
        mark = open(_subtypes_mark(gdir), encoding="utf-8").read().strip()
    except OSError:
        return ""
    return mark if mark and _db_meta(gdir, "subtypes_built") == mark else ""        # the card list itself must carry the printings too (it does not after a refreshed list)


def fetch_subtypes(gdir, base, game_id):
    data = sync._get(f"{base.rstrip('/')}/{data_slug(game_id)}.subtypes.json.gz", as_json=False)
    if not data:
        return 0
    raw = bytes(data)
    return apply_subtypes(gdir, json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw))


def fetch_and_apply(gdir, base, game_id):
    data = sync._get(f"{base.rstrip('/')}/{data_slug(game_id)}.json.gz", as_json=False)
    if not data:
        return 0
    raw = bytes(data)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw)      # the web server may already have unzipped it in transit
    n = apply(gdir, doc)
    try:
        fetch_subtypes(gdir, base, game_id)                    # every printing's own price (best effort: the headline prices above are already in)
    except Exception:  # noqa: BLE001
        pass
    return n
