"""The once-a-day price update.

TCGplayer's free price feed (tcgcsv.com) refreshes once a day, around 20:00 UTC.  Our website reads it at 20:03 UTC (three minutes later) and publishes one small
file per game with the price of every card and product.  This app takes those files: it looks once after 20:03 UTC each day; if the website has not published
the new day yet it looks again every 5 minutes (every hour after 8 hours) until it has, applies it, and then does not look again until the next day."""
import datetime
import gzip
import json
import os
import sqlite3

from . import sync

RUN_HOUR, RUN_MINUTE = 20, 3                       # UTC: three minutes after the price feed's own daily update
RETRY_SECONDS = 300
KINDS = {0: None, 1: "market (other printing)", 2: "mid price", 3: "low price"}


def expected_day(now=None):
    """The price day we should have by now: today's once 20:03 UTC has passed, otherwise yesterday's."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    return (now if now >= cut else now - datetime.timedelta(days=1)).strftime("%Y-%m-%d")


def next_daily_run(now=None):
    """Seconds from now until the next 20:03 UTC."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    if now >= cut:
        cut += datetime.timedelta(days=1)
    return (cut - now).total_seconds()


def retry_delay(now=None):
    """5 minutes while the day is fresh (the update may just be late); hourly once it has been missing for 8+ hours."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    if now < cut:
        cut -= datetime.timedelta(days=1)
    return RETRY_SECONDS if (now - cut).total_seconds() < 8 * 3600 else 3600


def base_for(catalog_base):
    b = catalog_base.rstrip("/")
    return (b.rsplit("/", 1)[0] + "/prices") if "/" in b else "prices"


def manifest(base):
    d = sync._get(base.rstrip("/") + "/manifest.json", tries=1)
    return d if isinstance(d, dict) and isinstance(d.get("games"), dict) else None


def _mark(gdir):
    return os.path.join(gdir, "prices_built.txt")


def local_built(gdir):
    try:
        return open(_mark(gdir), encoding="utf-8").read().strip()
    except OSError:
        return ""


def apply(gdir, doc):
    """Write a day's prices into this game's card list (and sealed products).  Only prices that exist are written; a card never loses the price it has.  -> number of prices applied."""
    day = str(doc.get("built") or "")
    items = doc.get("items")
    if not day or not isinstance(items, dict):
        raise ValueError("the price file is not readable")
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=60)
    n = 0
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(cards)")}
        rows = [(float(v[0]), KINDS.get(int(v[1]) if len(v) > 1 else 0), day, str(k)) for k, v in items.items() if isinstance(v, list) and v and v[0] is not None]
        if "tcg_id" in cols:
            conn.executemany("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE tcg_id=?", rows)
            n = len(rows)
        try:
            conn.executemany("UPDATE sealed_products SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", rows)
        except sqlite3.Error:
            pass
        conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (day,))
        conn.commit()
    finally:
        conn.close()
    with open(_mark(gdir), "w", encoding="utf-8") as f:
        f.write(day)
    return n


def _subtypes_mark(gdir):
    return os.path.join(gdir, "subtypes_built2.txt")          # (2: the printings fix - existing copies fetch the file once more)


def apply_subtypes(gdir, doc):
    """Store the price of every printing of every card (from <game>.subtypes.json.gz) -> number of cards updated."""
    items = doc.get("items")
    day = str(doc.get("built") or "")
    if not day or not isinstance(items, dict):
        raise ValueError("the printing-price file is not readable")
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=60)
    try:
        if "variant_prices" not in {r[1] for r in conn.execute("PRAGMA table_info(cards)")}:
            conn.execute("ALTER TABLE cards ADD COLUMN variant_prices TEXT")
        rows = []
        for pid, subs in items.items():
            if not isinstance(subs, dict):
                continue
            one = {k: v[0] for k, v in subs.items() if isinstance(v, list) and v and isinstance(v[0], (int, float)) and v[0] > 0}
            if one:
                rows.append((json.dumps(one, separators=(",", ":")), str(pid)))
        conn.executemany("UPDATE cards SET variant_prices=? WHERE tcg_id=?", rows)
        fixed = _fix_variants(conn, items)
        conn.commit()
    finally:
        conn.close()
    with open(_subtypes_mark(gdir), "w", encoding="utf-8") as f:
        f.write(day)
    return len(rows)


def _flags_from(subs):
    """The printing flags TCGplayer's price list implies for one card: {'normal','reverse','holo','firstEdition'} that are True."""
    keys = set(subs)
    out = {}
    plain = keys & {"Normal", "Unlimited", "Unlimited Normal"}
    if plain:
        out["normal"] = True
    if "Reverse Holofoil" in keys:
        out["reverse"] = True
    if keys & {"Holofoil", "Unlimited Holofoil", "1st Edition Holofoil"}:
        out["holo"] = True
    if keys & {"1st Edition", "1st Edition Normal", "1st Edition Holofoil"}:
        out["firstEdition"] = True
    if keys and not plain and not (keys & {"1st Edition", "1st Edition Normal", "Reverse Holofoil"}) and out.get("holo"):
        out["holoOnly"] = True                           # only ever printed as a holo: it has no plain version
    return out


def _fix_variants(conn, items):
    """The card list says which printings a card has (normal / reverse / holo / 1st Edition) from one source, and it is often missing the reverse holo of
    cards whose sets did have them (Dark Explorers, Boundaries Crossed, Lost Thunder, Hidden Fates...).  TCGplayer's list of printings fills those in (it only ever ADDS
    a printing; a holo-only card also loses a 'normal' it never had)."""
    cur = {str(t): (cid, v) for cid, t, v in conn.execute("SELECT id, tcg_id, variants FROM cards WHERE tcg_id IS NOT NULL")}
    upd = []
    for pid, subs in items.items():
        if not isinstance(subs, dict) or str(pid) not in cur:
            continue
        cid, raw = cur[str(pid)]
        try:
            flags = json.loads(raw) if raw else {}
        except ValueError:
            continue
        add = _flags_from(subs)
        new = dict(flags)
        changed = False
        for k in ("normal", "reverse", "holo", "firstEdition"):
            if add.get(k) and not new.get(k):
                new[k] = True; changed = True
        if add.get("holoOnly") and new.get("normal") and not add.get("normal") and not flags.get("holo"):
            new["normal"] = False; changed = True
        if changed:
            upd.append((json.dumps(new, separators=(", ", ": ")), cid))
    conn.executemany("UPDATE cards SET variants=? WHERE id=?", upd)
    return len(upd)


def subtypes_built(gdir):
    try:
        return open(_subtypes_mark(gdir), encoding="utf-8").read().strip()
    except OSError:
        return ""


def fetch_subtypes(gdir, base, game_id):
    data = sync._get(f"{base.rstrip('/')}/{game_id}.subtypes.json.gz", as_json=False)
    if not data:
        return 0
    raw = bytes(data)
    return apply_subtypes(gdir, json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw))


def fetch_and_apply(gdir, base, game_id):
    data = sync._get(f"{base.rstrip('/')}/{game_id}.json.gz", as_json=False)
    if not data:
        return 0
    raw = bytes(data)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw)      # the web server may already have unzipped it in transit
    n = apply(gdir, doc)
    try:
        fetch_subtypes(gdir, base, game_id)                    # every printing's own price (best effort: the headline prices above are already in)
    except Exception:  # noqa: BLE001
        pass
    return n
