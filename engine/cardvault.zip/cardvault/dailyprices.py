"""The once-a-day price update.

TCGplayer's free price feed (tcgcsv.com) refreshes once a day, around 20:00 UTC.  Our website reads it at 20:03 UTC (three minutes later) and publishes one small
file per game with the price of every card and product.  This app takes those files: it looks once after 20:03 UTC each day; if the website has not published
the new day yet it looks again every 5 minutes (every hour after 8 hours) until it has, applies it, and then does not look again until the next day."""
import datetime
import gzip
import json
import os
import sqlite3

from . import sync

RUN_HOUR, RUN_MINUTE = 20, 3                       # UTC: three minutes after the price feed's own daily update
RETRY_SECONDS = 300
KINDS = {0: None, 1: "market (other printing)", 2: "mid price", 3: "low price"}


def expected_day(now=None):
    """The price day we should have by now: today's once 20:03 UTC has passed, otherwise yesterday's."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    return (now if now >= cut else now - datetime.timedelta(days=1)).strftime("%Y-%m-%d")


def next_daily_run(now=None):
    """Seconds from now until the next 20:03 UTC."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    if now >= cut:
        cut += datetime.timedelta(days=1)
    return (cut - now).total_seconds()


def retry_delay(now=None):
    """5 minutes while the day is fresh (the update may just be late); hourly once it has been missing for 8+ hours."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    cut = now.replace(hour=RUN_HOUR, minute=RUN_MINUTE, second=0, microsecond=0)
    if now < cut:
        cut -= datetime.timedelta(days=1)
    return RETRY_SECONDS if (now - cut).total_seconds() < 8 * 3600 else 3600


def base_for(catalog_base):
    b = catalog_base.rstrip("/")
    return (b.rsplit("/", 1)[0] + "/prices") if "/" in b else "prices"


def manifest(base):
    d = sync._get(base.rstrip("/") + "/manifest.json", tries=1)
    return d if isinstance(d, dict) and isinstance(d.get("games"), dict) else None


def _mark(gdir):
    return os.path.join(gdir, "prices_built.txt")


def local_built(gdir):
    try:
        return open(_mark(gdir), encoding="utf-8").read().strip()
    except OSError:
        return ""


def apply(gdir, doc):
    """Write a day's prices into this game's card list (and sealed products).  Only prices that exist are written; a card never loses the price it has.  -> number of prices applied."""
    day = str(doc.get("built") or "")
    items = doc.get("items")
    if not day or not isinstance(items, dict):
        raise ValueError("the price file is not readable")
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=60)
    n = 0
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(cards)")}
        rows = [(float(v[0]), KINDS.get(int(v[1]) if len(v) > 1 else 0), day, str(k)) for k, v in items.items() if isinstance(v, list) and v and v[0] is not None]
        if "tcg_id" in cols:
            conn.executemany("UPDATE cards SET price_usd=?, price_kind=?, price_updated=? WHERE tcg_id=?", rows)
            n = len(rows)
        try:
            conn.executemany("UPDATE sealed_products SET price_usd=?, price_kind=?, price_updated=? WHERE id=?", rows)
        except sqlite3.Error:
            pass
        conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (day,))
        conn.commit()
    finally:
        conn.close()
    with open(_mark(gdir), "w", encoding="utf-8") as f:
        f.write(day)
    return n


def fetch_and_apply(gdir, base, game_id):
    data = sync._get(f"{base.rstrip('/')}/{game_id}.json.gz", as_json=False)
    if not data:
        return 0
    raw = bytes(data)
    doc = json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw)      # the web server may already have unzipped it in transit
    return apply(gdir, doc)
