"""The ONLY part of the app that touches the internet.

It talks to the free TCGdex service (api.tcgdex.net for card data, assets.tcgdex.net for images) and nothing else.
It only ever downloads; it never sends anything about you or your collection.
"""
import json
import os
import threading

from .runtime import INLINE
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

from . import keepfixes, legality, provenance
from .db import image_file, logo_file, open_cards_conn, picture_url, sort_key

API = "https://api.tcgdex.net/v2/en"
WORKERS = 12
AVG_BYTES = {"low": 22_000, "high": 85_000}

_local = threading.local()


def _session():
    s = getattr(_local, "s", None)
    if s is None:
        s = requests.Session()
        s.headers["User-Agent"] = "CollectEmAll/1.0 (personal collection app)"
        _local.s = s
    return s


def _get(url, as_json=True, tries=5):
    # TODO(roadmap 1.1): move onto cardvault.sources.Fetcher (rules, cache, provenance) in its own tested change; the daily job relies on this exact behaviour.
    last = None
    for attempt in range(tries):
        try:
            r = _session().get(url, timeout=30)
            if r.status_code == 404:
                return None
            if r.status_code == 429 or r.status_code >= 500:
                raise requests.HTTPError(f"HTTP {r.status_code}")
            r.raise_for_status()
            return r.json() if as_json else r.content
        except (requests.RequestException, ValueError) as e:
            last = e
            if attempt + 1 < tries:                                     # (no wait after the last try: in the browser a sleep holds every screen up)
                time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Could not reach {url}: {last}")


class Cancelled(Exception):
    pass


def _pool(items, fn, cancel, on_result, workers=WORKERS):
    """Run fn over items in threads; on_result runs on the calling thread."""
    if INLINE:
        for it in items:
            if cancel.is_set():
                raise Cancelled()
            on_result(it, fn(it))
        return
    ex = ThreadPoolExecutor(max_workers=workers)
    try:
        futs = {ex.submit(fn, it): it for it in items}
        for fut in as_completed(futs):
            if cancel.is_set():
                raise Cancelled()
            on_result(futs[fut], fut.result())
    except BaseException:
        ex.shutdown(wait=False, cancel_futures=True)
        raise
    ex.shutdown(wait=True)


def fetch_catalog(gdir, cancel, progress, only_sets=None, api=API, skip_empty=False):
    """Download the list of sets and the brief card list of each set.  Returns the number of cards."""
    conn = open_cards_conn(gdir)
    try:
        progress("Reading the list of sets...", 0, 0)
        sets = _get(f"{api}/sets")
        if only_sets:
            sets = [s for s in sets if s["id"] in only_sets]
        done = [0]

        def one(s):
            return _get(f"{api}/sets/{s['id']}")

        kept = keepfixes.Kept(conn, "tdx")                                  # the owner's fixes and better sources' fields are not undone by this re-read

        def got(s, d):
            done[0] += 1
            if d and skip_empty and not d.get("cards"):
                d = None                                                    # (a set the source lists with no cards yet - the Chinese lists have many - is not shown as an empty tile)
            if d:
                count = d.get("cardCount") or {}
                conn.execute(                                               # (an upsert, not INSERT OR REPLACE: a replace would also blank the set's search words and other columns)
                    "INSERT INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,?) "
                    "ON CONFLICT(id) DO UPDATE SET name=COALESCE(?, name), serie=excluded.serie, release_date=COALESCE(?, release_date), "
                    "total=excluded.total, official=excluded.official, logo=COALESCE(excluded.logo, logo), "
                    "fold=CASE WHEN COALESCE(?, name) IS NOT name THEN NULL ELSE fold END",
                    (d["id"], d.get("name"), (d.get("serie") or {}).get("name"), d.get("releaseDate"), count.get("total"), count.get("official"), d.get("logo"),
                     kept.set_name(d["id"], d.get("name")), kept.set_date(d["id"], d.get("releaseDate")), kept.set_name(d["id"], d.get("name"))))
                for c in d.get("cards") or []:
                    if kept.skip(c["id"]):
                        continue                                            # a copy folded into its twin stays retired
                    name, image = kept.card_name(c["id"], c.get("name")), kept.picture(c["id"], c.get("image"))
                    conn.execute(
                        "INSERT INTO cards(id,set_id,local_id,sort_key,name,image_base) VALUES(?,?,?,?,?,?) "
                        "ON CONFLICT(id) DO UPDATE SET name=COALESCE(?, name), image_base=COALESCE(?, image_base), "
                        "local_id=excluded.local_id, set_id=excluded.set_id, fold=CASE WHEN COALESCE(?, name) IS NOT name THEN NULL ELSE fold END",
                        (c["id"], d["id"], c["localId"], sort_key(c["localId"]), c.get("name"), c.get("image"), name, image, name))
                    provenance.record_many(conn, [(c["id"], "card", "tdx")] + ([(c["id"], "image", "tdx.i")] if image else []))
            if done[0] % 10 == 0:
                conn.commit()
            progress("Reading sets...", done[0], len(sets))

        _pool(sets, one, cancel, got)
        conn.commit()
        return conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
    finally:
        conn.close()


def _parse_prices(d):
    pr = d.get("pricing") or {}
    usd = eur = None
    tp = pr.get("tcgplayer") or {}
    for key in ("normal", "holofoil", "reverse-holofoil", "1st-edition-holofoil", "1st-edition-normal"):
        v = tp.get(key)
        if isinstance(v, dict) and v.get("marketPrice"):
            usd = v["marketPrice"]
            break
    if usd is None:
        for v in tp.values():
            if isinstance(v, dict) and v.get("marketPrice"):
                usd = v["marketPrice"]
                break
    cm = pr.get("cardmarket") or {}
    eur = cm.get("trend") or cm.get("avg")
    return usd, eur


def _store_detail(conn, cid, d):
    if not d:
        conn.execute("UPDATE cards SET detailed=1 WHERE id=?", (cid,))
        return
    usd, eur = _parse_prices(d)
    variants = d.get("variants") or {}
    detailed = d.pop("variants_detailed", None) or []
    d["variants_detailed"] = [{k: v.get(k) for k in ("type", "subtype", "size", "stamp")} for v in detailed]
    types = ", ".join(d.get("types") or [])
    conn.execute(
        "UPDATE cards SET detailed=1, category=?, rarity=?, hp=?, types=?, illustrator=?, stage=?, evolve_from=?, "
        "description=?, price_usd=?, price_eur=?, variants=?, raw=?, dex=?, price_updated=? WHERE id=?",
        (d.get("category"), d.get("rarity"), d.get("hp") if isinstance(d.get("hp"), int) else None, types,
         d.get("illustrator"), d.get("stage"), d.get("evolveFrom"), d.get("description"), usd, eur,
         json.dumps(variants), json.dumps(d, ensure_ascii=False),
         ",".join(str(int(x)) for x in d.get("dexId") or []), time.strftime("%Y-%m-%d"), cid))
    if usd is not None or eur is not None:
        provenance.record(conn, cid, "price", "tdx")
    legality.store_card(conn, cid, legality.tdx_rows(d), "tdx", time.strftime("%Y-%m-%d"))      # format legality (Standard / Expanded) from the same record


def fetch_details(gdir, cancel, progress, refresh_all=False, only_ids=None, api=API):
    conn = open_cards_conn(gdir)
    try:
        if only_ids is not None:
            ids = list(only_ids)
        else:
            if refresh_all:
                conn.execute("UPDATE cards SET detailed=0")
                conn.commit()
            ids = [r[0] for r in conn.execute("SELECT id FROM cards WHERE detailed=0")]
        total = len(ids)
        count = [0]

        def one(cid):
            return _get(f"{api}/cards/{cid}")  # ids from the API are already URL-safe

        def got(cid, d):
            _store_detail(conn, cid, d)
            count[0] += 1
            if count[0] % 200 == 0:
                conn.commit()
                progress("Downloading card info...", count[0], total)

        progress("Downloading card info...", 0, total)
        try:
            _pool(ids, one, cancel, got)
        finally:
            conn.commit()
        progress("Downloading card info...", total, total)
        return total
    finally:
        conn.close()


def pending_images(gdir, quality):
    conn = open_cards_conn(gdir)
    try:
        rows = conn.execute("SELECT id, set_id, image_base FROM cards WHERE image_base IS NOT NULL AND image_base!=''").fetchall()
    finally:
        conn.close()
    todo = []
    for cid, set_id, base in rows:
        p = image_file(gdir, quality, cid, set_id)
        if not (os.path.exists(p) and os.path.getsize(p) > 0):
            todo.append((cid, set_id, base))
    return todo, len(rows)


def fetch_images(gdir, quality, cancel, progress):
    todo, _ = pending_images(gdir, quality)
    total = len(todo)
    count = [0]

    def one(item):
        cid, set_id, base = item
        data = _get(picture_url(base, quality), as_json=False)
        if data:
            p = image_file(gdir, quality, cid, set_id)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            tmp = p + ".part"
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, p)
        return bool(data)

    def got(item, ok):
        count[0] += 1
        if count[0] % 25 == 0 or count[0] == total:
            progress("Downloading images...", count[0], total)

    progress("Downloading images...", 0, total)
    _pool(todo, one, cancel, got)
    fetch_logos(gdir, cancel, progress)
    return total


def fetch_logos(gdir, cancel, progress):
    """The small logo of every set (shown on the set boxes).  Sets the source has no logo for are simply skipped."""
    conn = open_cards_conn(gdir)
    try:
        rows = conn.execute("SELECT id, logo FROM sets WHERE logo IS NOT NULL AND logo!=''").fetchall()
    finally:
        conn.close()
    todo = [(sid, url) for sid, url in rows if not (os.path.exists(logo_file(gdir, sid)) and os.path.getsize(logo_file(gdir, sid)) > 0)]
    count = [0]

    def one(item):
        sid, url = item
        data = _get(url + ".webp", as_json=False)
        if data:
            p = logo_file(gdir, sid)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p + ".part", "wb") as f:
                f.write(data)
            os.replace(p + ".part", p)
        return bool(data)

    def got(item, ok):
        count[0] += 1
        progress("Downloading set logos...", count[0], len(todo))

    if todo:
        _pool(todo, one, cancel, got)
    return len(todo)


def estimate(gdir, quality):
    """How much is still left to download, for the confirmation screen."""
    conn = open_cards_conn(gdir)
    try:
        n_cards = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        n_sets = conn.execute("SELECT COUNT(*) FROM sets").fetchone()[0]
        n_detail_missing = conn.execute("SELECT COUNT(*) FROM cards WHERE detailed=0").fetchone()[0]
    finally:
        conn.close()
    todo, with_img = pending_images(gdir, quality)
    conn = open_cards_conn(gdir)
    try:
        logo_rows = conn.execute("SELECT id FROM sets WHERE logo IS NOT NULL AND logo!=''").fetchall()
    finally:
        conn.close()
    logos_missing = sum(1 for (sid,) in logo_rows if not (os.path.exists(logo_file(gdir, sid)) and os.path.getsize(logo_file(gdir, sid)) > 0))
    return {"logos_missing": logos_missing, "cards": n_cards, "sets": n_sets, "details_missing": n_detail_missing,
            "images_missing": len(todo), "images_total": with_img,
            "image_mb": len(todo) * AVG_BYTES[quality] / 1_000_000}


def refresh_prices(gdir, cancel, progress, priority_ids=(), limit=None, api=API):
    """Re-read the market price of cards (owned / wishlist cards first, then the stalest).  Only the price columns change."""
    conn = open_cards_conn(gdir)
    try:
        rows = conn.execute("SELECT id, COALESCE(price_updated,'') FROM cards WHERE detailed=1 ORDER BY 2, id").fetchall()
        prio = [c for c in priority_ids]
        pset = set(prio)
        ids = prio + [r[0] for r in rows if r[0] not in pset]
        if limit:
            ids = ids[:limit]
        total, count = len(ids), [0]
        day = time.strftime("%Y-%m-%d")

        def one(cid):
            return _get(f"{api}/cards/{cid}")

        def got(cid, d):
            if d:
                usd, eur = _parse_prices(d)
                conn.execute("UPDATE cards SET price_usd=COALESCE(?, price_usd), price_eur=COALESCE(?, price_eur), price_updated=CASE WHEN ? IS NULL AND ? IS NULL THEN price_updated ELSE ? END WHERE id=?", (usd, eur, usd, eur, day, cid))
                if usd is not None or eur is not None:
                    provenance.record(conn, cid, "price", "tdx", day)
                legality.store_card(conn, cid, legality.tdx_rows(d), "tdx", day)
            count[0] += 1
            if count[0] % 100 == 0:
                conn.commit()
                progress("Updating prices...", count[0], total)

        progress("Updating prices...", 0, total)
        try:
            _pool(ids, one, cancel, got)
        finally:
            conn.commit()
        conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
        conn.commit()
        progress("Updating prices...", total, total)
        return total
    finally:
        conn.close()
