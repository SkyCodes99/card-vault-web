"""skyrelaunch - the one safe way for an app to hand over to a newer copy of itself ("Restart to update").

MASTER COPY lives in C:\\Users\\Sky\\SkyUpdateKit; every Python app carries its own verbatim copy (so each repo stays standalone).
If you change this file, change the master and re-copy it - see README.md in this folder.

Why it exists (found 2026-10-13 by reproducing it with throw-away PyInstaller builds):
  * A frozen (PyInstaller) app that starts another frozen app inherits its parent's _PYI_* environment variables.  When the child is the
    SAME exe path (a one-file build swapped in place, "Post Z.exe" -> "Post Z.exe") it believes it is the parent's helper process, re-uses
    the parent's temp extraction folder, and dies the moment the parent exits.  -> the restart "just fails".
    Fix: start the child with a cleaned environment (+ PYINSTALLER_RESET_ENVIRONMENT=1, which the bootloader consumes).
  * The new copy used to be started while the old one was still shutting down, so it ran into the single-instance lock / the phone-server
    port / the database lock / the shared save file, and either quit or showed an error.
    Fix: the new copy is started with SKY_WAIT_PID=<old pid> and calls wait_for_old_instance() as the very first thing it does.

  * (found 2026-10-13) `subprocess.Popen(["cmd", "/c", script.bat], creationflags=DETACHED_PROCESS | ...)` NEVER RUNS: a cmd.exe without a console
    exits at once, so every "wait for the app to close, swap the file, start it" batch helper silently did nothing (Post Z swap, TCG Batch Finder
    restart/swap, Collect Em All installer).  Batch helpers must use CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP - see spawn_cmd().

Usage:
    # at the very top of the program's entry point (before any lock, port, window, database):
    import skyrelaunch; skyrelaunch.wait_for_old_instance()

    # when the user confirms "Restart now" (after saving):
    skyrelaunch.spawn_new([new_exe, *args], cwd=folder)      # then close normally; call skyrelaunch.exit_watchdog(8) first for a hard guarantee
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time

WAIT_ENV = "SKY_WAIT_PID"
RESTARTED_ENV = "SKY_RESTARTED"          # "1" in a copy that was started by "Restart to update" (apps may use it to reopen what was open)
DETACHED = 0x00000008 | 0x00000200       # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP: the new copy must outlive this one
NO_WINDOW = 0x08000000


def clean_env(base: dict | None = None, **extra: str) -> dict:
    """A copy of the environment that is safe to hand to another frozen program (no inherited PyInstaller bookkeeping)."""
    env = dict(os.environ if base is None else base)
    for k in list(env):
        if k.upper().startswith("_PYI") or k.upper() in ("_MEIPASS2", "PYINSTALLER_RESET_ENVIRONMENT"):
            env.pop(k, None)
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    env.update({k: str(v) for k, v in extra.items()})
    return env


def spawn_new(argv: list[str], cwd: str | None = None, wait: bool = True, **extra_env: str) -> subprocess.Popen:
    """Start `argv` as an independent program.  With wait=True it first waits for THIS process to exit (see wait_for_old_instance)."""
    extra = dict(extra_env)
    extra[RESTARTED_ENV] = "1"
    if wait:
        extra[WAIT_ENV] = str(os.getpid())
    kw = {"creationflags": DETACHED} if os.name == "nt" else {"start_new_session": True}
    return subprocess.Popen(list(argv), cwd=cwd or os.path.dirname(os.path.abspath(argv[0])), env=clean_env(**extra), close_fds=True,
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)


def spawn_cmd(argv_after_cmd_c: list[str], cwd: str | None = None, **extra_env: str) -> subprocess.Popen:
    """Run a cmd.exe helper (`cmd /c <script or command>`) that outlives this process.  Windows only.
    Never uses DETACHED_PROCESS: a console-less cmd.exe dies immediately and the script never runs."""
    extra = {RESTARTED_ENV: "1", **extra_env}
    return subprocess.Popen(["cmd", "/c", *argv_after_cmd_c], cwd=cwd, env=clean_env(**extra), close_fds=True, stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x00000200 | NO_WINDOW)


def _pid_alive(pid: int) -> bool:
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    k = ctypes.windll.kernel32
    k.OpenProcess.restype = ctypes.c_void_p
    h = k.OpenProcess(0x00100000 | 0x1000, False, pid)          # SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False                                              # no such process any more
    try:
        return k.WaitForSingleObject(ctypes.c_void_p(h), 0) == 0x102     # WAIT_TIMEOUT -> still running
    finally:
        k.CloseHandle(ctypes.c_void_p(h))


def wait_for_old_instance(timeout: float = 45.0) -> bool:
    """Call first thing at start-up.  If a previous copy asked to be replaced, block until it has really exited.  Returns True if it did wait."""
    raw = os.environ.pop(WAIT_ENV, "")
    if not raw.isdigit():
        return False
    pid = int(raw)
    if pid == os.getpid():
        return False
    end = time.time() + timeout
    while time.time() < end and _pid_alive(pid):
        time.sleep(0.1)
    time.sleep(0.25)                                              # let the OS release the old copy's locks (files, ports, mutexes)
    return True


def exit_watchdog(seconds: float = 8.0) -> None:
    """Guarantee this process ends: if the normal shutdown has not finished `seconds` after the restart was confirmed, force it."""
    def go():
        time.sleep(seconds)
        os._exit(0)
    threading.Thread(target=go, daemon=True, name="restart-watchdog").start()


def was_restarted() -> bool:
    return os.environ.get(RESTARTED_ENV) == "1"
