"""Learning from your corrections.

Every time you add or remove a card on an admin list, that is a labelled example ("this card IS / IS NOT an Alt Art").
This module
  * measures how well the automatic Alt Art rule agrees with your labels,
  * re-calibrates the one adjustable number in that rule (the artwork edge threshold) so it agrees with them as often as possible,
  * exports every label together with the card's measurable features (rarity, numbering, edge score...) as a CSV for deeper
    analysis later (for example to teach a better rule for Alt Arts numbered inside a set).
It is plain statistics on this PC - no AI model and nothing leaves the computer.
"""
import csv

from . import taxonomy
from .db import now_iso

MIN_EACH = 3     # need at least this many 'yes' and 'no' examples with an edge score before the threshold is adjusted


def examples(vault):
    """Labelled alt-art examples: [(card dict, label bool)] from the hand-set 'altart' tags."""
    tags = vault.card_tags()
    out = []
    for cid, t in tags.items():
        lab = t.get("altart")
        if lab in ("yes", "no"):
            c = vault.card_light(cid)
            if c:
                out.append((c, lab == "yes"))
    return out


def _auto_alt(c, threshold):
    low = (c.get("rarity") or "").lower()
    era_ok = low == "secret rare" or (low in taxonomy._ALT_RARITIES_OLD and (c.get("release_date") or "") < "2023-03-31")
    score = c.get("art_score")
    return bool(taxonomy.is_secret_numbered(c) and c.get("category") == "Pokemon" and era_ok and score is not None and score >= threshold)


def evaluate(vault, threshold=None):
    thr = vault.art_threshold() if threshold is None else threshold
    tp = fp = fn = tn = 0
    for c, label in examples(vault):
        guess = _auto_alt(c, thr)
        if guess and label:
            tp += 1
        elif guess and not label:
            fp += 1
        elif not guess and label:
            fn += 1
        else:
            tn += 1
    n = tp + fp + fn + tn
    return {"n": n, "tp": tp, "fp": fp, "fn": fn, "tn": tn, "accuracy": (tp + tn) / n if n else None, "threshold": thr}


def summary(vault):
    ex = examples(vault)
    scored = [(c["art_score"], l) for c, l in ex if c.get("art_score") is not None and taxonomy.is_secret_numbered(c)]
    yes = sum(1 for _, l in scored if l)
    outside = sum(1 for c, l in ex if l and not taxonomy.is_secret_numbered(c))
    ev = evaluate(vault)
    ev.update({"labelled": len(ex), "scored_yes": yes, "scored_no": len(scored) - yes, "outside_rule": outside,
               "can_learn": yes >= MIN_EACH and (len(scored) - yes) >= MIN_EACH, "default": taxonomy.ART_STD_THRESHOLD,
               "learned_at": vault.get_setting("art_threshold_learned_at", "")})
    return ev


def learn_threshold(vault):
    """Choose the edge-score threshold that agrees with the most labelled cards.  Returns a description dict."""
    s0 = summary(vault)
    if not s0["can_learn"]:
        return {"changed": False, "reason": f"Need at least {MIN_EACH} labelled Alt Arts and {MIN_EACH} labelled non-Alt-Arts that have "
                                            f"a picture score (you have {s0['scored_yes']} / {s0['scored_no']})."}
    pts = sorted((c["art_score"], l) for c, l in examples(vault) if c.get("art_score") is not None and taxonomy.is_secret_numbered(c))
    scores = [p[0] for p in pts]
    cands = [(scores[i] + scores[i + 1]) / 2 for i in range(len(scores) - 1) if scores[i] != scores[i + 1]]
    cands += [scores[0] - 1, scores[-1] + 1]
    best, best_acc = None, -1.0
    for t in cands:
        acc = sum(1 for sc, l in pts if (sc >= t) == l) / len(pts)
        # prefer higher accuracy; on ties stay closest to the current threshold
        if acc > best_acc + 1e-9 or (abs(acc - best_acc) < 1e-9 and abs(t - s0["threshold"]) < abs(best - s0["threshold"])):
            best, best_acc = t, acc
    best = max(15.0, min(80.0, round(best, 1)))
    before = evaluate(vault)["accuracy"]
    vault.set_setting("art_threshold", best)
    vault.set_setting("art_threshold_learned_at", now_iso())
    vault.log("training.threshold", "setting", "", {"old": s0["threshold"], "new": best, "examples": len(pts)})
    vault.invalidate_index()
    after = evaluate(vault)["accuracy"]
    return {"changed": abs(best - s0["threshold"]) > 1e-9, "old": s0["threshold"], "new": best, "accuracy_before": before, "accuracy_after": after,
            "examples": len(pts)}


def reset_threshold(vault):
    vault.set_setting("art_threshold", None)
    vault.set_setting("art_threshold_learned_at", None)
    vault.invalidate_index()


COLUMNS = ["card_id", "name", "set_id", "number", "official_size", "rarity", "release_date", "category", "art_score", "secret_numbered",
           "auto_alt_art", "group", "correction"]


def export_csv(vault, path):
    """One row per hand correction with the card's features - raw material for improving the detection rules later."""
    from . import admin
    thr = vault.art_threshold()
    n = 0
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(COLUMNS)
        for cid, gid, act in admin.all_corrections(vault):
            c = vault.card_light(cid)
            if not c:
                continue
            w.writerow([cid, c["name"], c["set_id"], c["local_id"], c.get("official"), c.get("rarity"), c.get("release_date"), c.get("category"),
                        c.get("art_score"), int(taxonomy.is_secret_numbered(c)), int(_auto_alt(c, thr)), gid, act])
            n += 1
    return n
