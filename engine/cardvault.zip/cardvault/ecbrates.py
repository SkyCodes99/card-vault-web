"""Daily exchange rates from the European Central Bank (roadmap "Your currency").

The daily job (tools/daily_update.py) calls refresh() once a day: it reads the ECB's daily reference rates XML, checks robots.txt first, and writes
<catalog folder>/fx.json next to manifest.json.  publish_carddata.py sends that file to Card Data, and the apps read it from there (currency.fetch_fx).
Rates are units of each currency per 1 euro, with the date the ECB published them.  A failed download never overwrites the last good file.
"""
import datetime
import json
import os
import urllib.robotparser
import urllib.request
import xml.etree.ElementTree as ET

URL = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml"
ROBOTS = "https://www.ecb.europa.eu/robots.txt"
FILE = "fx.json"
AGENT = "CollectEmAll/2 (currency)"


def parse(xml_bytes):
    """ECB XML -> {"date": "YYYY-MM-DD", "eur": {"USD": 1.09, ...}}.  Raises ValueError when the file has no date or no rates."""
    root = ET.fromstring(xml_bytes)
    day, eur = None, {}
    for el in root.iter():
        if not el.tag.endswith("Cube"):
            continue
        if el.get("time"):
            day = el.get("time")
        elif el.get("currency") and el.get("rate"):
            try:
                v = float(el.get("rate"))
            except ValueError:
                continue
            if v > 0:
                eur[el.get("currency")] = v
    datetime.date.fromisoformat(day or "")          # raises ValueError when the date is missing or odd
    if "USD" not in eur or len(eur) < 10:
        raise ValueError("the ECB file has too few rates")
    return {"date": day, "eur": eur}


def allowed(fetch_text=None):
    """robots.txt for the ECB rates page: True when a robot may read it (the daily job stops if not)."""
    rp = urllib.robotparser.RobotFileParser()
    try:
        if fetch_text is None:
            req = urllib.request.Request(ROBOTS, headers={"User-Agent": AGENT})
            with urllib.request.urlopen(req, timeout=20) as r:
                fetch_text = r.read().decode("utf-8", "replace")
        rp.parse(fetch_text.splitlines())
    except Exception:  # noqa: BLE001 - no robots.txt answer: do not read the page today
        return False
    return rp.can_fetch(AGENT, URL)


def download(timeout=30):
    req = urllib.request.Request(URL, headers={"User-Agent": AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def refresh(out_dir, fetch=None, robots=None):
    """Fetch the ECB rates and write out_dir/fx.json.  -> {"ok": bool, "date": ..., "note": ...}.  Never raises: a failure keeps the last good file."""
    path = os.path.join(out_dir, FILE)
    try:
        if not (robots() if robots else allowed()):
            return _kept(path, "robots.txt does not allow it; kept the last rates")
        data = parse((fetch or download)())
    except Exception as e:  # noqa: BLE001 - a bad day at the ECB must not stop the daily job
        return _kept(path, f"ECB rates not updated ({str(e)[:80]}); kept the last rates")
    doc = {"source": "European Central Bank daily reference rates", "url": URL, "base": "EUR", "date": data["date"],
           "fetched": datetime.date.today().isoformat(), "eur": data["eur"]}
    os.makedirs(out_dir, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, sort_keys=True)
    os.replace(tmp, path)
    return {"ok": True, "date": data["date"], "note": f"ECB rates for {data['date']} written"}


def _kept(path, note):
    try:
        with open(path, encoding="utf-8") as f:
            return {"ok": False, "date": json.load(f).get("date"), "note": note}
    except (OSError, ValueError):
        return {"ok": False, "date": None, "note": note + " (no earlier file either)"}
