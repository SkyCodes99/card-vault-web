"""A card's kind (Monster / Spell / Trap, Character / Event / Climax ...) for the cards whose shop data left it out.

TCGplayer's extended data names a card's kind - but not for every product: compilation reprints (Legendary Collection 2), tokens, release-event promos and markers arrive without one, and landed under 'Other'
or with no kind at all (about 1,100 cards in four games, missing from the 'Card type' filter).  The rest of the card's own data usually says it: a Yu-Gi-Oh! 'Attribute' is SPELL, TRAP or a monster's; a Weiss
Schwarz Character has Power and a Trait while a Climax has trigger icons and no Power; a Dragon Ball Battle card has Combo Power; 'Energy Marker - ...' is an Energy Marker.  Where the data is silent, the other
printings of the same name settle it when they all agree (Union Arena, Yu-Gi-Oh!).  Each rule was checked against the cards whose kind IS known (99 % right where it speaks); a card nothing places stays as it was.
`python tools/audit_card_kinds.py` repeats that check."""
import json
import re

EMPTY = ("", "Other")
_MONSTER_ATTRIBUTES = {"DARK", "LIGHT", "EARTH", "WATER", "FIRE", "WIND", "DIVINE"}


def _has(ext, key):
    return str(ext.get(key) or "").strip() not in ("", "-", "N/A", "None")


def _ygo(name, ext):
    if _has(ext, "Card Type"):
        return ""
    if re.match(r"token: ", name, re.I):
        return "Monster"                                                    # (a token is filed as a monster, like the 90 tokens whose kind the shop did give)
    attribute = str(ext.get("Attribute") or "").strip().upper()
    if attribute in ("SPELL", "TRAP", "SKILL"):
        return attribute.capitalize()
    return "Monster" if attribute in _MONSTER_ATTRIBUTES else ""


def _weiss(name, ext):
    if _has(ext, "Power") and _has(ext, "Trait"):
        return "Character"
    if _has(ext, "Triggers"):
        return "Climax"
    return "Event" if _has(ext, "Level") or _has(ext, "Cost") else ""


def _dbs(name, ext):
    if re.match(r"energy marker\b", name, re.I):
        return "Energy Marker"
    if re.search(r"\(merit card\)", name, re.I):
        return "Merit Card"
    return "Battle" if _has(ext, "Combo Power") else ""


def _union_arena(name, ext):
    return "Action Point" if re.match(r"action point card\b", name, re.I) else ""


_VG_KINDS = (("order", "Order"), ("guardian", "G Guardian"), ("crest", "Crest"), ("token", "Token"), ("gift", "Gift / Marker"), ("marker", "Gift / Marker"), ("trigger", "Trigger Unit"))


def _vanguard(name, ext):
    """Vanguard cards carry no card type: the shop's 'Unit' field says it, in about a hundred spellings ('Normal', 'Nornal', 'Normal Order Arms', 'Set Order/Research', 'G-Guardian' ...)."""
    unit = re.sub(r"[^a-z]+", " ", str(ext.get("Unit") or "").lower()).strip()
    for word, kind in _VG_KINDS:
        if word in unit:
            return kind
    if unit in ("g", "g unit"):
        return "G Unit"
    if re.fullmatch(r"n[a-z]{3,5}l( unit)?|unit", unit):                           # normal / nornal / nomral / nornmal
        return "Normal Unit"
    return "Normal Unit" if _has(ext, "Grade") and _has(ext, "Power") else ""      # (no Unit written: a card with a grade and a power is a unit)


def _elestrals(name, ext):
    if _has(ext, "RuneType"):
        return "Rune"
    return "Elestral" if _has(ext, "Attack") and _has(ext, "Defense") else ""


def _hololive(name, ext):
    if _has(ext, "Oshi Skill"):
        return "Oshi holomem"
    return "holomem" if _has(ext, "HP") else ""


def _godzilla(name, ext):
    return "Rage" if re.match(r"rage\b", name, re.I) else ""


def _kryptik(name, ext):
    if _has(ext, "Attack"):
        return "Citizen"
    return "Spell" if _has(ext, "SoulCost") else ""


def _final_fantasy(name, ext):
    return "Token" if re.search(r"\btoken\b", name, re.I) else ""


_BY_DATA = {"yugioh": _ygo, "weissschwarz": _weiss, "dbs": _dbs, "dbsfw": _dbs, "unionarena": _union_arena, "vanguard": _vanguard, "elestrals": _elestrals, "hololive": _hololive, "godzilla": _godzilla,
            "kryptik": _kryptik, "finalfantasy": _final_fantasy}
_BY_NAME = ("yugioh", "unionarena")                                          # games where one name is one card, whatever the printing


def _ext(raw):
    try:
        return (json.loads(raw) or {}).get("ext") or {}
    except (TypeError, ValueError):
        return {}


def _key(name):
    return re.sub(r"\s+", " ", (name or "").strip().lower())


def joined(kind):
    """A card that is two kinds at once is written both ways round ('Item;Regalia', 'Regalia;Item', 'Digimon/Option'): the same pair always reads the same ('Item / Regalia')."""
    return " / ".join(sorted({p.strip() for p in re.split(r"[;/]", kind or "") if p.strip()}))


def _kinds_by_name(conn):
    """{name: {kinds}} over the cards that have a kind."""
    kinds = {}
    for name, kind in conn.execute("SELECT name, category FROM cards WHERE category IS NOT NULL AND category NOT IN ('', 'Other')"):
        kinds.setdefault(_key(name), set()).add(kind)
    return kinds


def tidy(conn, game):
    """Give the cards of `game` that have no kind one, where the card says - or every other printing of its name says - what it is.  Safe to run again.  -> how many were given a kind."""
    from_data = _BY_DATA.get(game)
    if from_data is None:
        return 0
    gaps = conn.execute("SELECT id, name, raw FROM cards WHERE category IS NULL OR category IN ('', 'Other')").fetchall()
    if not gaps:
        return 0
    same_name = _kinds_by_name(conn) if game in _BY_NAME else {}
    updates = []
    for cid, name, raw in gaps:
        kind = from_data(name or "", _ext(raw))
        if not kind:
            agreed = same_name.get(_key(name)) or ()
            kind = next(iter(agreed)) if len(agreed) == 1 else ""
        if kind:
            updates.append((kind, cid))
    conn.executemany("UPDATE cards SET category=? WHERE id=?", updates)
    return len(updates)
