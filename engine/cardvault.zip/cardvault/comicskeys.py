"""Comics: what makes an issue a KEY ISSUE, and nothing else about it.

A key issue is only ever one a source STATES to be one ("First appearance of Superman", "Origin of ...", "Death of ..."): the label is saved in the issue's `rarity` column (so the sidebar,
the sort and the tile marker all read the one place), the stated words in its details.  Nothing here guesses from an issue's price, age or name.

`notes_in(text)` reads such statements out of a source's free-text notes (the Grand Comics Database writes them as plain sentences); it keeps only a sentence that STARTS with the claim and
is not a note about a reprint or a mention, so a reprint of Action Comics #1 is not itself a first appearance."""
import re

KEY = "Key issue"                 # the `rarity` of a key issue
ISSUE = "Issue"                   # an ordinary issue
VARIANT = "Variant cover"         # an ordinary issue that is one of several covers / editions
ORDER = (ISSUE, VARIANT, KEY)     # easiest to hardest to find (games.py rarity_order)

_CLAIM = re.compile(r"^(?:(?:note|notes)\s*:\s*)?((?:(?:first|1st)(?:\s+(?:full|cameo|team|complete|live[- ]action))?\s+appearance|origin|death|debut|only appearance|last appearance)\s+of\s+.+)$", re.I)
_NOT = re.compile(r"\b(?:reprint\w*|collected in|flashback|mentioned|mention|retcon\w*|in this issue only if|see also|according to|cover only)\b", re.I)
_SENTENCE = re.compile(r"(?<=[.!?])\s+|\n+")
MAX_NOTES, MAX_LEN = 3, 160


def is_key(rarity):
    return rarity == KEY


def notes_in(*texts):
    """The key-issue statements found in free-text notes: ['First appearance of Venom (full)', ...], at most three, each at most 160 characters, in the order met."""
    out = []
    for text in texts:
        for sentence in _SENTENCE.split(str(text or "")):
            s = sentence.strip().rstrip(".;")
            m = _CLAIM.match(s)
            if not m or _NOT.search(s) or len(s) > MAX_LEN:
                continue
            note = m.group(1)[0].upper() + m.group(1)[1:]
            if note.lower() not in (x.lower() for x in out):
                out.append(note)
    return out[:MAX_NOTES]
