"""What the card list's legality table (cards.db card_legality, filled by the daily update from Scryfall and YGOPRODeck - see legality.py) says about the cards in a deck.
Read from the saved table only, never fetched.  Legality belongs to the card, not to one printing, so the rows of every print with the same name are put together.
status(...) answers: 'legal' | 'limited' | 'semi-limited' | 'restricted' | 'banned' | 'not legal' (the card has rows, just none for this format) | None (the table has nothing on this card)."""
import sqlite3

from . import deckcards, legality

_RANK = {"banned": 5, "limited": 4, "semi-limited": 3, "restricted": 3, "legal": 1}      # when prints disagree, the stricter one counts


def _chunks(items, n=400):
    items = list(items)
    for i in range(0, len(items), n):
        yield items[i:i + n]


def rows_for(v, info):
    """{play key: {format label: status}} for the cards in info ({card_id: describe()}).  {} when the table is missing or empty."""
    try:
        by_id = {}
        for part in _chunks({c["name"] for c in info.values()}):
            for r in v.conn.execute(f"SELECT id, name FROM cards WHERE name IN ({','.join('?' * len(part))})", part):
                by_id[r[0]] = deckcards.play_key(v.game, r[1], "")
        for cid, c in info.items():
            by_id.setdefault(cid, c["key"])
        out = {}
        for part in _chunks(by_id):
            for cid, fmt, st in v.conn.execute(f"SELECT card_id, format, status FROM card_legality WHERE card_id IN ({','.join('?' * len(part))})", part):
                d = out.setdefault(by_id[cid], {})
                if fmt not in d or _RANK.get(st, 0) > _RANK.get(d[fmt], 0):
                    d[fmt] = st
        return out
    except sqlite3.Error:
        return {}


def meta(v, source):
    """-> {dated, source (url), has}: the day the table was last filled from this source, where it is from, and whether it has any rows at all."""
    name, url = legality.SOURCE_NAMES.get(source, (source, ""))
    try:
        day = v.conn.execute("SELECT MAX(day), COUNT(*) FROM card_legality WHERE source=?", (source,)).fetchone()
    except sqlite3.Error:
        day = (None, 0)
    return {"dated": day[0] or "", "has": bool(day[1]), "name": name, "url": url}


def status(rows, key, fmt_label):
    d = rows.get(key)
    if not d:
        return None
    return d.get(fmt_label) or "not legal"
