"""A BROKEN SITE IS SWITCHED OFF BY ITSELF (roadmap 1.12): after OFF_AFTER daily runs in a row in which every list read from a site failed, the daily run stops asking that
site for a rest (REST_DAYS, doubling each time it is switched off again, up to REST_CAP_DAYS) and then tries it once more by itself.  One good run switches it back on.
Kept in the sources store (cardvault/sources/store.py, table site_runs), so the readers and the daily run share one record."""
import re
import time

from .sources import rules

OFF_AFTER = 3
REST_DAYS, REST_CAP_DAYS = 2, 14
_DOMAIN = re.compile(r"\b((?:[a-z0-9-]+\.)+[a-z]{2,})\b", re.I)


def site_of(game):
    """The site a game's list is read from: the first web address named in its source (games.Game.source), as a sources rule id; else the game itself."""
    m = _DOMAIN.search(game.source or "")
    return rules.rule_for("https://" + m.group(1).lower()).id if m else game.id


def is_off(store, site, now=None):
    """-> the time the site rests until (0 when it is on)."""
    until = store.run_health(site)["off_until"] or 0.0
    return until if until > (now or time.time()) else 0.0


def record(store, site, ok, error="", now=None, day=""):
    """One daily run of a site: ok = at least one of its lists was read.  -> 'off' (just switched off), 'on' (back after a rest) or ''."""
    now = now or time.time()
    h = store.run_health(site)
    was_off = h["times_off"] > 0
    h["last_run"] = day or time.strftime("%Y-%m-%d", time.localtime(now))
    if ok:
        h.update(failed_runs=0, times_off=0, off_until=0.0, last_error=None)
        store.save_run_health(h)
        return "on" if was_off else ""
    h["failed_runs"] += 1
    h["last_error"] = (error or "")[:200]
    turned = ""
    if h["failed_runs"] >= OFF_AFTER:
        h["off_until"] = now + 86400 * min(REST_CAP_DAYS, REST_DAYS * 2 ** h["times_off"])
        h["times_off"] += 1
        turned = "off"
    store.save_run_health(h)
    return turned


def until_text(t):
    return time.strftime("%Y-%m-%d", time.localtime(t))
