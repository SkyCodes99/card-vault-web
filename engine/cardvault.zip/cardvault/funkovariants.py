"""Funko Pops that differ only by a sticker or a finish: telling them apart, naming them, keeping the signed ones apart, and folding the ones that are really the SAME Pop listed twice.

A Pop is often sold in several versions: a store sticker (Hot Topic, GameStop, Target ...), a convention sticker (SDCC, NYCC ...), a finish (Glow, Flocked, Metallic, Diamond ...), a Chase, a Special
Edition, or signed by the person it shows.  Each of those is its OWN item - its own price, its own owners.  This module (pure text rules + idempotent passes over the open connection, run on every
rebuild after the wiki step):

  tokens(...)      the sticker / finish / chase / signed marks a text states ('GameStop', 'Glow', 'Chase' ...); a mark is read only where it is stated (a bracket, a store tag, a wiki note), never guessed
  base_key(name)   the plain name for comparing: no franchise prefix, no mark brackets, descriptive brackets kept ('Sesshomaru as Demon Dog')
  signed pass      'Signed by X' Pops move to their own set 'Signed Pops' (their fandom is kept in ext 'Fandom'); they never take part in a merge or a 'has this variant?' check
  merge pass       a TCGplayer row and a hobbyDB row of the same set, same base name and EXACTLY the same marks are one Pop listed twice: the TCGplayer row stays (price, number), takes the hobbyDB
                   name and picture, the hobbyDB id goes into meta id_redirects (so owned copies, wishlist and ticks move) and is never added back.  Anything that only half agrees is NOT merged: it is
                   offered to the owner's review list (kind duplicate_card, `queue_review`)
  label pass       hobbyDB / wiki names get their marks in brackets: 'Sesshomaru as Demon Dog (GameStop Exclusive)', 'Spider-Man (Glow in the Dark, Chase)'; a mark the name already says is not added again"""
import html
import json
import re

SIGNED_SET = "Signed Pops"
_RETAILERS = (("Hot Topic", r"hot ?topic"), ("BoxLunch", r"box ?lunch"), ("GameStop", r"game ?stop"), ("Target", r"\btarget\b"), ("Walmart", r"wal-?mart"),
              ("Funko Shop", r"funko[- ]shop|funko\.com"), ("Amazon", r"\bamazon"), ("Barnes & Noble", r"barnes"), ("FYE", r"\bfye\b"), ("Walgreens", r"walgreens"),
              ("Toys R Us", r"toys ?\"?r\"? ?us"), ("Entertainment Earth", r"entertainment earth"), ("Books-A-Million", r"books-a-million"), ("Toy Tokyo", r"toy tokyo"),
              ("Previews", r"\bpreviews\b"), ("Loot Crate", r"loot crate"), ("Hallmark", r"hallmark"), ("Kohl's", r"kohl'?s"), ("ThinkGeek", r"thinkgeek"), ("Meijer", r"meijer"),
              ("Spencer's", r"spencer'?s"), ("Fred Meyer", r"fred meyer"), ("Disney Store", r"disney (?:store|parks)"),
              ("Special Edition", r"\bspecial edition\b"))
_CONVENTIONS = (("SDCC", r"sdcc|san diego comic"), ("NYCC", r"nycc|new york comic"), ("ECCC", r"eccc|emerald city"), ("C2E2", r"c2e2"), ("WonderCon", r"wondercon"),
                ("Fan Expo", r"fan expo"), ("ACE Comic Con", r"ace comic"), ("Funko Fundays", r"fundays"), ("Star Wars Celebration", r"star wars celebration"), ("D23", r"\bd23\b"),
                ("Anime Expo", r"anime expo"), ("MCM", r"\bmcm\b"), ("Toy Fair", r"toy fair"), ("PAX", r"\bpax\b"), ("Designer Con", r"designer ?con"), ("Galactic Convention", r"galactic con"))
_FINISHES = (("Glow in the Dark", r"\bglow|\bgitd\b"), ("Flocked", r"\bflocked\b"), ("Metallic", r"\bmetallic\b"), ("Diamond", r"\bdiamond\b"), ("Glitter", r"\bglitter\b"),
             ("Translucent", r"\btranslucent\b"), ("Blacklight", r"black ?light"), ("Pearlescent", r"\bpearlescent\b"), ("Scented", r"\bscented\b"), ("Chrome", r"\bchrome\b"),
             ("Chase", r"\bchase\b"))
_SIGNED = re.compile(r"\(\s*(?:signed|autograph(?:ed)?)(?:\s+by\s+[^)]*)?\)|\bsigned by\b|\bautograph(?:ed)?\b", re.I)
_SIGNED_BY = re.compile(r"signed by\s+([^)]*)", re.I)
_PLAIN = re.compile(r"bobble-?head|vinyl figure|^\d+(?:\.\d+)?\s*(?:\"|-?inch|in)$|exclusives?\b|limited edition|^signed|autograph|\bexc\b", re.I)
_GROUP = re.compile(r"\(([^()]*)\)|\[([^\[\]]*)\]")
_ORIGINAL = re.compile(r"^(?:original|regular|standard|normal|common|base|non-?chase|n/?a)\b", re.I)

_RET = tuple((k, re.compile(p, re.I)) for k, p in _RETAILERS)
_CON = tuple((k, re.compile(p, re.I)) for k, p in _CONVENTIONS)
_FIN = tuple((k, re.compile(p, re.I)) for k, p in _FINISHES)
GENERIC = "Exclusive"


def _unescape(s):
    return html.unescape(s or "").strip()


def segments(name, tags=(), note="", groups_trusted=False):
    """[(text, trusted)] - what to read marks from: the brackets of the name, every tag, the wiki note.  trusted = a tag / note (a store there means 'sold at'); a bracket needs the word 'exclusive'."""
    out = [(g[0] or g[1], groups_trusted) for g in _GROUP.findall(_unescape(name))]
    out += [(_unescape(t), True) for t in tags or [] if t]
    if note:
        out.append((_unescape(note), True))
    return out


def tokens(name, tags=(), note="", rarity="", groups_trusted=False):
    """-> {mark: label text} for every mark stated: store / convention stickers ('GameStop' -> 'GameStop Exclusive'), finishes, 'Chase', 'Special Edition', 'Limited Edition', 'Signed'.
    A store word counts only in a tag, a note, or a bracket that says 'exclusive'; the generic 'Exclusive' is kept only when nothing says which store."""
    marks, generic = {}, False
    for text, trusted in segments(name, tags, note, groups_trusted):
        exclusive = bool(re.search(r"exclusive", text, re.I))
        generic = generic or exclusive
        for key, rule in _RET:
            if (trusted or exclusive or key == "Special Edition") and rule.search(text):
                marks[key] = key if key == "Special Edition" else f"{key} Exclusive"
        for key, rule in _CON:
            m = rule.search(text)
            if m:
                year = re.search(r"\b(20\d\d)\b", text)
                marks[key] = f"{key} {year.group(1)} Exclusive" if year else f"{key} Exclusive"
        for key, rule in _FIN:
            if rule.search(text):
                marks[key] = key
        if re.search(r"limited edition", text, re.I):
            marks["Limited Edition"] = "Limited Edition"
    r = (rarity or "").lower()
    if "chase" in r:
        marks.setdefault("Chase", "Chase")
    if "limited edition" in r:
        marks.setdefault("Limited Edition", "Limited Edition")
    if r.startswith("exclusive"):
        generic = True
    if _SIGNED.search(_unescape(name)):
        marks["Signed"] = "Signed"
    if generic and not any(k in _store_keys() for k in marks):
        marks[GENERIC] = GENERIC
    return marks


def _store_keys():
    return _STORE_KEYS


_STORE_KEYS = {k for k, _ in _RETAILERS if k != "Special Edition"} | {k for k, _ in _CONVENTIONS}


def sig(marks):
    return frozenset(marks)


def _is_mark_group(text):
    if _PLAIN.search(text.strip()):
        return True
    return bool(tokens("(" + text + ")", (), "", "")) and not re.search(r"^as |^with |^in ", text.strip(), re.I) or any(r.search(text) for _, r in _FIN + _CON)


def base_key(name):
    """The plain name for comparing: the part after the franchise prefix, without mark brackets ((Glow), (GameStop Exclusive), (Bobble-Head) ...), descriptive brackets kept."""
    s = _unescape(name)
    if ": " in s:
        s = s.split(": ")[-1]
    keep = []

    def sub(m):
        text = (m.group(1) or m.group(2) or "").strip()
        if not _is_mark_group(text):
            keep.append(text)
        return " "
    base = re.sub(r"\s*\d+(?:\.\d+)?\s*(?:\"|-?inch)", "", _GROUP.sub(sub, s))
    return re.sub(r"[^a-z0-9]+", " ", (base + " " + " ".join(keep)).lower()).strip()


def is_signed(name):
    return bool(_SIGNED.search(_unescape(name)))


def signer(name):
    m = _SIGNED_BY.search(_unescape(name))
    return m.group(1).strip(" )") if m else ""


def flat_label(item, extra=()):
    """One-level bracket text for a wiki variant ('Chase - White GITD (GameStop Exclusive)' -> 'Chase - White GITD, GameStop Exclusive'; 'Blue GITD (SE SDCC 500 pcs)' -> 'Blue GITD, SDCC Special
    Edition, 500 pcs').  `extra` = {mark: label} from the row's note, added only when the item states no such mark itself.  Repeats are dropped."""
    cons = "|".join(k for k, _ in _CONVENTIONS)
    text = re.sub(r"\bSE\b", "Special Edition", _unescape(item))
    parts = []
    for piece in re.split(r"[()\[\]]", text):
        piece = re.sub(r"\s+", " ", piece).strip(" ,-")
        piece = re.sub(r"\bSpecial Edition (" + cons + r")\b", r"\1 Special Edition", piece)
        m = re.search(r"\s*,?\s*(\d[\d,]*\s*pcs)\b", piece, re.I)
        if m:
            piece = (piece[:m.start()] + piece[m.end():]).strip(" ,-")
            parts += [piece, m.group(1)] if piece else [m.group(1)]
        elif piece:
            parts.append(piece)
    stated = tokens("", (), text, "")
    parts += [v for k, v in dict(extra).items() if k not in stated]
    out = []
    for p in parts:
        if p.lower() not in {x.lower() for x in out}:
            out.append(p)
    return ", ".join(out)


def label_for(name, tags=(), note="", rarity=""):
    """The bracket text a name still lacks, or '' ('GameStop Exclusive, Glow in the Dark').  Marks the name already states are left out; 'Signed' and the generic marks are never added."""
    have = tokens(name, (), "", "", groups_trusted=True)          # a store written in a bracket of the name, with or without 'Exclusive', is stated
    plain = _unescape(name)
    for key, rule in _FIN[:-1] + _CON:                       # a mark written outside any bracket ('Chase - White GITD, ...') counts as stated too (Chase itself may be a character's name)
        if rule.search(plain):
            have.setdefault(key, key)
    want = tokens(name, tags, note, rarity)
    parts = []
    order = [k for k, _ in _RET if k != "Special Edition"] + [k for k, _ in _CON] + ["Special Edition"] + [k for k, _ in _FIN]
    for key in order:
        if key in want and key not in have and key not in parts:
            parts.append(key)
    if "Chase" in parts and "Chase" in have:
        parts.remove("Chase")
    # an exclusive that the name only names generically ('(Exclusive)') still gets its store
    return ", ".join(want[k] for k in parts)


# ------------------------------------------------------------------------------------------------ the index (what the list has)
def _doc(raw):
    try:
        d = json.loads(raw or "{}")
    except ValueError:
        return {}
    return d if isinstance(d, dict) else {}


def rows(conn):
    """[{id, set, key, marks, signed, tcg}] for every row - the list's own view for twin checks."""
    out = []
    for cid, sid, name, rarity, raw in conn.execute("SELECT id, set_id, name, rarity, raw FROM cards").fetchall():
        d = _doc(raw)
        marks = tokens(name, d.get("tags") or [], d.get("note") or "", rarity)
        out.append({"id": cid, "set": sid, "key": base_key(name), "marks": marks, "signed": is_signed(name), "tcg": str(cid).isdigit(), "name": name})
    return out


class Index:
    """(set, base name) -> the marks of every NON-signed row there; a signed Pop is never somebody's twin."""

    def __init__(self, conn):
        self.by = {}
        for r in rows(conn):
            if not r["signed"]:
                self.by.setdefault((r["set"], r["key"]), []).append(r)

    def has(self, set_id, name, marks):
        """True when the set already has this base name with every one of `marks` (and no mark of ours is missing)."""
        want = {k for k in marks if k != GENERIC}
        for r in self.by.get((set_id, base_key(name)), []):
            have = {k for k in r["marks"] if k != GENERIC}
            if want <= have and (want or not have):
                return True
        return False

    def has_base(self, set_id, name):
        return bool(self.by.get((set_id, base_key(name))))


# ------------------------------------------------------------------------------------------------ signed
def move_signed(conn, put_set):
    """Signed Pops go to their own set; the fandom they sat in is kept in ext 'Fandom' (and 'Signed by').  -> how many were moved (0 on a second run)"""
    from . import funkofandoms
    moved = 0
    for cid, sid, name, setname, raw in conn.execute("SELECT c.id, c.set_id, c.name, s.name, c.raw FROM cards c LEFT JOIN sets s ON s.id=c.set_id").fetchall():
        if not is_signed(name):
            continue
        d = _doc(raw)
        ext = d.get("ext") if isinstance(d.get("ext"), dict) else {}
        want = dict(ext)
        want["Signed by"] = signer(name) or "Signed"
        if setname != SIGNED_SET:
            want["Fandom"] = funkofandoms.fandom_for(setname or "", _unescape(name))
        new_set = put_set(SIGNED_SET)
        if want != ext or sid != new_set:
            d["ext"] = want
            conn.execute("UPDATE cards SET set_id=?, raw=? WHERE id=?", (new_set, json.dumps(d, ensure_ascii=False), cid))
            moved += sid != new_set
    return moved


# ------------------------------------------------------------------------------------------------ twins
def _compatible(a, b):
    """Half-agreeing marks (one side states more, or only 'Exclusive' against a store): a question for the owner, never a merge.  Two different stores are two Pops."""
    x, y = {k for k in a if k != GENERIC}, {k for k in b if k != GENERIC}
    if "Signed" in x | y:
        return False
    return (a != b) if x == y else (x <= y or y <= x)


def find_twins(conn):
    """-> (certain, fuzzy): certain = [(hobbyDB id, TCGplayer id)] the same Pop listed twice (same set, same base name, EXACTLY the same marks, one on each side);
    fuzzy = [(hobbyDB id, TCGplayer id, why)] that agree on set and base name but differ in how much the marks say - for the review list.  Signed rows never appear."""
    rs = [r for r in rows(conn) if not r["signed"]]
    hdb, tcg = {}, {}
    for r in rs:
        key = (r["set"], r["key"])
        if r["id"].startswith("hdb:"):
            hdb.setdefault(key, []).append(r)
        elif r["tcg"]:
            tcg.setdefault(key, []).append(r)
    certain, fuzzy = [], []
    for key, ts in tcg.items():
        hs = hdb.get(key)
        if not hs or not key[1]:
            continue
        for t in ts:
            same = [h for h in hs if sig(h["marks"]) == sig(t["marks"])]
            twin_t = [x for x in ts if sig(x["marks"]) == sig(t["marks"])]
            if len(same) == 1 and len(twin_t) == 1:
                certain.append((same[0]["id"], t["id"]))
                continue
            if same:
                continue                                           # several of the same kind: not certain, not asked either (no way to tell which)
            near = [h for h in hs if _compatible(h["marks"], t["marks"])]
            if len(near) == 1 and len(ts) == 1:
                fuzzy.append((near[0]["id"], t["id"], f"same name, but the marks differ: {', '.join(sorted(near[0]['marks'])) or 'none'} against {', '.join(sorted(t['marks'])) or 'none'}"))
    return certain, fuzzy


def _redirects(conn):
    try:
        return json.loads((conn.execute("SELECT value FROM meta WHERE key='id_redirects'").fetchone() or ["{}"])[0] or "{}")
    except ValueError:
        return {}


def _franchise_prefix(name):
    s = _unescape(name)
    return s.rsplit(": ", 1)[0] if ": " in s else ""


def fold(conn, red, hdb_id, keep_id):
    """The hobbyDB row folded into the TCGplayer row: the kept row takes the hobbyDB name and picture and tags, the hobbyDB id redirects.  -> the new redirects"""
    h = conn.execute("SELECT name, image_base, types, rarity, raw FROM cards WHERE id=?", (hdb_id,)).fetchone()
    k = conn.execute("SELECT name, image_base, types, rarity, raw FROM cards WHERE id=?", (keep_id,)).fetchone()
    if not h or not k:
        return red
    hd, kd = _doc(h[4]), _doc(k[4])
    ext = dict(kd.get("ext") or {})
    prefix = _franchise_prefix(k[0])
    if prefix:
        ext["Franchise"] = prefix
    kd["ext"] = ext
    kd["tags"] = hd.get("tags") or []
    kd["hdb"] = hd.get("handle") or hdb_id
    name = _unescape(h[0])
    state = {"name": name, "image": h[1] or k[1], "types": h[2] or k[2], "tags": kd["tags"], "franchise": prefix, "hdb": hdb_id}
    rarity = k[3] if k[3] and k[3] != "Standard" else (h[3] or k[3])
    conn.execute("UPDATE cards SET name=?, image_base=?, types=?, rarity=?, raw=? WHERE id=?", (name, state["image"], state["types"], rarity, json.dumps(kd, ensure_ascii=False), keep_id))
    conn.execute("DELETE FROM cards WHERE id=?", (hdb_id,))
    red = {a: (keep_id if b == hdb_id else b) for a, b in red.items()}
    red[hdb_id] = keep_id
    kept = _meta_json(conn, "funko_merged")
    kept[str(keep_id)] = state
    conn.execute("INSERT OR REPLACE INTO meta VALUES('funko_merged', ?)", (json.dumps(kept, ensure_ascii=False, sort_keys=True),))
    return red


def _meta_json(conn, key):
    try:
        return json.loads((conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone() or ["{}"])[0] or "{}")
    except ValueError:
        return {}


def retired(conn):
    """The hobbyDB ids folded away: a rebuild must not add them back."""
    return {k for k, v in _redirects(conn).items() if k != v and str(k).startswith("hdb:")}


def reapply_merged(conn):
    """A rebuild writes the TCGplayer rows again (their own name and picture): give the merged ones the hobbyDB name / picture / tags back."""
    n = 0
    for cid, st in _meta_json(conn, "funko_merged").items():
        row = conn.execute("SELECT name, image_base, raw FROM cards WHERE id=?", (cid,)).fetchone()
        if not row:
            continue
        d = _doc(row[2])
        ext = dict(d.get("ext") or {})
        if st.get("franchise"):
            ext["Franchise"] = st["franchise"]
        d["ext"], d["tags"] = ext, st.get("tags") or []
        if not row[0].startswith(st["name"]) or row[1] != st["image"] or _doc(row[2]) != d:
            name = row[0] if row[0].startswith(st["name"]) else st["name"]                  # (a name that already carries its marks stays)
            conn.execute("UPDATE cards SET name=?, image_base=?, types=?, raw=? WHERE id=?", (name, st["image"], st["types"], json.dumps(d, ensure_ascii=False), cid))
            n += 1
    return n


def merge_certain(conn):
    certain, _ = find_twins(conn)
    if not certain:
        return 0
    red = _redirects(conn)
    for hdb_id, keep in certain:
        red = fold(conn, red, hdb_id, keep)
    conn.execute("INSERT OR REPLACE INTO meta VALUES('id_redirects', ?)", (json.dumps(red, ensure_ascii=False, sort_keys=True),))
    return len(certain)


def queue_review(conn, game="funko"):
    """The half-agreeing pairs go on the owner's review list (kind duplicate_card; his yes folds the hobbyDB row into the TCGplayer one).  -> how many were queued"""
    from . import dedupe, reviewlist
    _, fuzzy = find_twins(conn)
    names = dict(conn.execute("SELECT id, name FROM cards"))
    n = 0
    for hdb_id, keep, why in fuzzy:
        q = f'Funko "{_unescape(names.get(hdb_id))}" (hobbyDB) and "{_unescape(names.get(keep))}" (TCGplayer {keep}) look like the same Pop, but the stickers / finish do not match exactly ({why}). They stay separate unless you say yes. Merge the first into the second?'
        reviewlist.add_item(dedupe.KIND, game, hdb_id, q, before={"copy": hdb_id, "keep": keep, "name": names.get(hdb_id), "why": why, "set": "", "setName": ""}, source="funko variants check")
        n += 1
    return n


# ------------------------------------------------------------------------------------------------ names
def label_names(conn):
    """Add the missing marks to hobbyDB / wiki / merged names ('Sesshomaru as Demon Dog' -> '... (GameStop Exclusive)'); also drops '&amp;' left in a name.  Idempotent.  -> (names labelled, names unescaped)"""
    done = clean = 0
    for cid, name, rarity, raw in conn.execute("SELECT id, name, rarity, raw FROM cards WHERE id LIKE 'hdb:%' OR id LIKE 'fw:%' OR raw LIKE '%\"tags\"%'").fetchall():
        d = _doc(raw)
        new = _unescape(name)
        if is_signed(new):
            lab = ""
        else:
            lab = label_for(new, d.get("tags") or [], d.get("note") or "", rarity)
        if lab:
            new = f"{new} ({lab})"
        if new != name:
            conn.execute("UPDATE cards SET name=? WHERE id=?", (new, cid))
            done += bool(lab)
            clean += not lab
    return done, clean


def apply(conn, put_set):
    """The whole pass, in order: merged rows get their hobbyDB name back, signed Pops move, certain twins merge, names get their marks.  -> a dict of counts"""
    reapply_merged(conn)
    signed = move_signed(conn, put_set)
    merged = merge_certain(conn)
    labelled, cleaned = label_names(conn)
    conn.commit()
    return {"signed": signed, "merged": merged, "labelled": labelled, "unescaped": cleaned}


# ------------------------------------------------------------------------------------------------ facets
def facet_stickers(name, tags, ext=None):
    return sorted({k for k in tokens(name, tags, "", "") if k in _STORE_KEYS})


def facet_finishes(name, tags):
    return sorted({k for k in tokens(name, tags, "", "") if k in {x for x, _ in _FIN}})
