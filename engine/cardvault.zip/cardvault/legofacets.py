"""LEGO: the sidebar filters, read from each set's stated facts (raw ext written by cardvault/lego.py).  Pure text rules, used by cardvault/gamefacets.py.

A filter value is always what Rebrickable states: the subtheme, the year, the kind (building set, collectible minifigure ...), and the part / minifigure counts put in plain ranges.
A set whose count is not stated has no value in that filter (never 0)."""
import re

PART_RANGES = ((99, "1-99"), (249, "100-249"), (499, "250-499"), (999, "500-999"), (1999, "1,000-1,999"), (3999, "2,000-3,999"))


def _one(key):
    return lambda e, c: [str(e[key]).strip()] if e.get(key) else []


def parts(e, c):
    m = re.fullmatch(r"[\d,]+", str(e.get("Parts (Rebrickable count)") or ""))
    if not m:
        return []
    n = int(m.group(0).replace(",", ""))
    return [next((label for top, label in PART_RANGES if n <= top), "4,000 or more")]


def minifigs(e, c):
    v = str(e.get("Minifigures") or "")
    if not v.isdigit():
        return []
    n = int(v)
    return ["None" if n == 0 else "1" if n == 1 else "2-4" if n <= 4 else "5-9" if n <= 9 else "10 or more"]


FACETS = [("subtheme", "Subtheme", _one("Subtheme")), ("year", "Year", _one("Year")), ("kind", "Kind", _one("Kind")),
          ("parts", "Parts", parts), ("minifigs", "Minifigures", minifigs)]
