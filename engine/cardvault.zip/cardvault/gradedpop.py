"""Graded population ("pop") per card per grade and the Gem Rate (Collect Em All roadmap 'Graded pop reports and Gem Rate').  Research and source decisions: docs/pop_sources.md.

The only source wired in is an OFFICIAL, key-based API: PokemonPriceTracker's /api/v2/population (PSA, BGS, CGC, SGC counts per grade; a Business-plan key).  Nothing is scraped: PSA, CGC, BGS, SGC and
TAG have no public pop API and their terms forbid (CGC, TAG) or do not allow (PSA needs a login; BGS, SGC and GemRate block plain readers) automatic reading of their pop pages.  Without a key the card shows "source not connected" and nothing is guessed.

Gem Rate = copies graded 10 / all copies graded by that company, worked out here from the counts (never taken from a source's own percentage, whose scale is not documented).
Polite: one card per request, only when its drawer is opened and the answer is older than a week; at least 1.2 s between calls; a refusal (wrong key, plan, limit) pauses calls for an hour.
The key is read from the environment (CV_POP_KEY) or this profile's encrypted secrets (pop_key) and is never printed, logged or stored anywhere else."""
import json
import os
import re
import threading
import time

URL = "https://www.pokemonpricetracker.com/api/v2/population"
SOURCE = {"name": "PokemonPriceTracker", "url": "https://www.pokemonpricetracker.com/api-reference"}
GRADERS = ("PSA", "BGS", "CGC", "SGC")
FRESH_DAYS = 7           # a stored answer is used this long before it is asked again
EMPTY_DAYS = 3           # "no pop for this card" is remembered this long
PAUSE_SECONDS = 3600     # after a refusal (wrong key / plan / daily limit) no call is made for this long
GAP_SECONDS = 1.2        # between two calls
TIMEOUT = 20
_lock = threading.Lock()
_last_call = [0.0]
_pause = {"until": 0.0, "state": ""}
_GRADE = re.compile(r"^g(\d+)(?:_(5))?$")


def key(secret=None):
    """The pop key: the environment first, then the profile's secret (a callable or a string); '' when none."""
    k = os.environ.get("CV_POP_KEY") or (secret() if callable(secret) else secret) or ""
    return str(k).strip()


def parse(body):
    """One card's answer ({'data': {...}} or the inner dict) -> {'graders': {'PSA': {'total', 'grades': {'10': n, ...}, 'gem'}}, 'updated': 'YYYY-MM-DD'} or None when the card has no pop.
    Counts are read defensively: a missing or odd value is skipped, never guessed."""
    d = body.get("data") if isinstance(body, dict) and "data" in body else body
    if isinstance(d, list):
        d = d[0] if d else None
    if not isinstance(d, dict):
        return None
    by = d.get("populationByGrader")
    if not isinstance(by, dict):
        return None
    out = {}
    for g in GRADERS:
        row = by.get(g)
        if not isinstance(row, dict):
            continue
        grades = {}
        for k, v in row.items():
            m = _GRADE.match(k)
            if m and isinstance(v, int) and not isinstance(v, bool) and v >= 0:
                grades[m.group(1) + ("." + m.group(2) if m.group(2) else "")] = v
        for k, label in (("auth", "Authentic"), ("pristine", "Pristine"), ("perfect", "Perfect")):
            if isinstance(row.get(k), int) and not isinstance(row.get(k), bool) and row[k] > 0:
                grades[label] = row[k]
        total = sum(grades.values())
        if isinstance(row.get("totalPopulation"), int) and row["totalPopulation"] > total:
            total = row["totalPopulation"]
        if total > 0:
            out[g] = {"total": total, "grades": grades, "gem": gem_rate(grades, total)}
    if not out:
        return None
    upd = str(d.get("lastFetchedDate") or d.get("updatedAt") or "")[:10]
    return {"graders": out, "updated": upd if re.match(r"^\d{4}-\d{2}-\d{2}$", upd) else ""}


def gem_rate(grades, total):
    """Percent of this company's graded copies that got a 10 (one decimal; None when nothing is graded)."""
    return round(100.0 * grades.get("10", 0) / total, 1) if total else None


def _order(label):
    try:
        return -float(label)
    except ValueError:
        return 1                                     # Authentic / Pristine ... after the numbers


def public(pop):
    """What the screen gets: per company the grades from the top down (zeros left out), the total and the Gem Rate."""
    rows = []
    for g in GRADERS:
        r = (pop.get("graders") or {}).get(g)
        if r:
            rows.append({"company": g, "total": r["total"], "gem": r["gem"],
                         "grades": [{"grade": k, "n": v} for k, v in sorted(r["grades"].items(), key=lambda kv: _order(kv[0])) if v]})
    return rows


def _table(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS graded_pop(tcg_id TEXT PRIMARY KEY, at TEXT NOT NULL, body TEXT)")


def _stored(conn, tcg_id, now):
    """(found, pop or None) from the cache when it is still fresh."""
    _table(conn)
    r = conn.execute("SELECT at, body FROM graded_pop WHERE tcg_id=?", (tcg_id,)).fetchone()
    if not r:
        return False, None
    try:
        age = (now - time.mktime(time.strptime(r[0], "%Y-%m-%d"))) / 86400
    except ValueError:
        return False, None
    pop = json.loads(r[1]) if r[1] else None
    if age < (FRESH_DAYS if pop else EMPTY_DAYS):
        return True, pop
    return False, pop                                 # stale: ask again (the old numbers stay if the ask fails)


def fetch(tcg_id, k, get=None):
    """Ask the API for one card.  -> ('ok', body) | ('nodata', None) | ('badkey' | 'plan' | 'limit' | 'error', None).  Never raises."""
    if get is None:
        import requests
        get = requests.get
    with _lock:                                       # one call at a time, spaced
        if time.time() < _pause["until"]:
            return _pause["state"], None
        wait = _last_call[0] + GAP_SECONDS - time.time()
        if wait > 0:
            time.sleep(wait)
        try:
            r = get(URL, params={"tcgPlayerId": str(tcg_id)}, headers={"Authorization": "Bearer " + k, "User-Agent": "CollectEmAll/1.0 (personal collection app)"}, timeout=TIMEOUT)
        except Exception:  # noqa: BLE001
            return "error", None
        finally:
            _last_call[0] = time.time()
        st = r.status_code
        if st in (401, 403, 429):
            state = {401: "badkey", 403: "plan", 429: "limit"}[st]
            _pause["until"], _pause["state"] = time.time() + PAUSE_SECONDS, state
            return state, None
        if st == 404:
            return "nodata", None
        if st != 200:
            return "error", None
        try:
            return "ok", r.json()
        except ValueError:
            return "error", None


def for_card(conn, tcg_id, secret=None, get=None, now=None):
    """{'state': 'notconnected' | 'ok' | 'nodata' | 'badkey' | 'plan' | 'limit' | 'error', 'rows': [...], 'updated', 'source'}.
    No key: 'notconnected' (nothing is asked).  A fresh stored answer is used without a call."""
    now = now or time.time()
    out = {"state": "notconnected", "rows": [], "updated": "", "source": SOURCE}
    tcg_id = str(tcg_id or "").strip()
    k = key(secret)
    if not k or not tcg_id:
        out["state"] = "notconnected" if not k else "nodata"
        return out
    fresh, pop = _stored(conn, tcg_id, now)
    if not fresh:
        state, body = fetch(tcg_id, k, get)
        if state in ("ok", "nodata"):
            pop = parse(body) if state == "ok" else None
            conn.execute("INSERT OR REPLACE INTO graded_pop(tcg_id, at, body) VALUES (?,?,?)", (tcg_id, time.strftime("%Y-%m-%d", time.localtime(now)), json.dumps(pop) if pop else None))
            conn.commit()
        elif not pop:
            out["state"] = state
            return out                                # refused / failed and nothing older to show
    if not pop:
        out["state"] = "nodata"
        return out
    out.update(state="ok", rows=public(pop), updated=pop.get("updated", ""))
    return out
