"""Roadmap 2.9 "Release dates fixed everywhere": ONE module that checks every release date against its sources and fixes only what a source proves.  Used by tools/audit_dates.py (read only),
tools/fix_dates.py (the live / dry run) and setfiling.file_new_sets (every set the daily update adds).

WHERE A DATE LIVES   A card has no date of its own: it always shows its SET's release_date (sets.release_date).  A sealed product has its own (sealed_products.released, the TCGplayer group's date
                     when it was filed).  A toy has its own day inside its record (raw ext.Released / published); a toy LINE (a sets row) takes the earliest of its toys.
UNKNOWN              stays EMPTY ('').  The Newest / Oldest sorts put empty dates LAST in both directions (db.eff_date_sql).  '0000-01-01' on a toy line is the documented "main line sorts first" mark
                     (toylines.refresh_sets): it is left alone and counted as a mark, never as an impossible date.
SOURCES (no network here: getjson(url) -> parsed JSON or None is passed in; tests pass a fake)
   tier 1  the game's own set list: Scryfall (Magic, by TCGplayer group id, else name), YGOPRODeck (Yu-Gi-Oh!), Lorcast (Lorcana), pokemontcg.io (Pokemon: same id + name, else name + card count).
           TCGdex's API is closed to robots (robots.txt) so it is not read here.  When two tier-1 lists disagree with each other the set is "contested" and left alone.
   tier 2  the TCGplayer group's publishedOn (tcgcsv.com) for any set / product filed under that group id.
A source day is only believed when it is a real date between 1990 and a year from today.  A match that lies more than MATCH_GUARD days from the date we have is "contested", not applied (a reprint with
the same name; a catch-all promo group Scryfall files under some other promo set).  Differences up to `days` (default 3) are noise (street date vs listing date) and are left alone.
TCGplayer's group date only FILLS a set with no day (it is a listing date: old catch-all groups get a new one whenever a product is added; the daily update already rewrites it for sets it touches).
A sealed product keeps a day it has (its own TCGplayer listing day); only an empty / unreadable one is filled: the group's day, else its set's (stamped inherit).
STAMPS   sealed products: provenance(product id, 'date', source) with source tcgp.d (TCGplayer group), inherit (its set's date); sets: meta key 'setdate_src' {set id: [source, day]}."""
import datetime
import json
import re
import sqlite3

from . import provenance
from .setfiling import _by_name, _norm, _pick
from .tcggames import CATEGORIES

SENTINEL = "0000-01-01"
MIN_DAY = "1990-01-01"
DEFAULT_DAYS = 3
MATCH_GUARD = 400
META_KEY = "setdate_src"


# ------------------------------------------------------------------------------------------------ one date
def today_iso():
    return datetime.date.today().isoformat()


def day_of(s):
    """-> 'YYYY-MM-DD' for a real calendar day written 2026-11-13, 2026-11-13T00:00:00 or 2026/11/13; '' for anything else."""
    m = re.match(r"^\s*(\d{4})[-/](\d{2})[-/](\d{2})(?!\d)", str(s or ""))
    if not m:
        return ""
    try:
        return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
    except ValueError:
        return ""


def limit_day(today=None):
    t = datetime.date.fromisoformat(today) if today else datetime.date.today()
    return (t + datetime.timedelta(days=365)).isoformat()


def plausible(d, today=None):
    return bool(d) and MIN_DAY <= d <= limit_day(today)


def classify(v, today=None):
    """'blank' | 'mark' (the toy-line sentinel) | 'format' (a real day not written plainly YYYY-MM-DD) | 'bad' (not a date at all) | 'impossible' (before 1990 / over a year ahead) | 'ok'"""
    s = str(v or "").strip()
    if not s:
        return "blank"
    if s == SENTINEL:
        return "mark"
    d = day_of(s)
    if not d:
        return "bad"
    if not plausible(d, today):
        return "impossible"
    return "ok" if s == d else "format"


def usable(v, today=None):
    """The plain day when `v` is a believable date (a 'format' one is read), else ''."""
    d = day_of(v)
    return d if plausible(d, today) else ""


def gap(a, b):
    """days between two plain days (None when either is missing)"""
    try:
        return abs((datetime.date.fromisoformat(a) - datetime.date.fromisoformat(b)).days)
    except (TypeError, ValueError):
        return None


# ------------------------------------------------------------------------------------------------ the sources: each -> {set id: (day, source code, exact)}
def _rows_of(conn):
    return [{"id": str(r[0]), "name": r[1], "date": r[2], "total": r[3]} for r in conn.execute("SELECT id, name, release_date, total FROM sets")]


def group_days(getjson, game, memo=None):
    """{TCGplayer group id: plain day} for a game (empty when the game has no TCGplayer category or the list is not at hand)."""
    cat = CATEGORIES.get(game)
    if not cat or not getjson:
        return {}
    if memo is not None and game in memo:
        return memo[game]
    data = getjson(f"https://tcgcsv.com/tcgplayer/{cat}/groups")
    out = {}
    for g in ((data or {}).get("results") or []) if isinstance(data, dict) else []:
        if isinstance(g, dict) and g.get("groupId") is not None and usable(g.get("publishedOn")):
            out[str(g["groupId"])] = usable(g.get("publishedOn"))
    if memo is not None:
        memo[game] = out
    return out


def tcgplayer_dates(getjson, game, rows, memo=None):
    days = group_days(getjson, game, memo)
    return {r["id"]: (days[r["id"]], "tcgp.d", True) for r in rows if r["id"] in days}


def scryfall_dates(getjson, game, rows, memo=None):
    data = (getjson("https://api.scryfall.com/sets") or {}).get("data") or []
    data = [x for x in data if isinstance(x, dict) and usable(x.get("released_at"))]
    by_id = {str(x["tcgplayer_id"]): x for x in data if x.get("tcgplayer_id")}
    names = _by_name([{"name": x.get("name"), "day": usable(x["released_at"]), "year": x["released_at"]} for x in data])
    out = {}
    for r in rows:
        hit = by_id.get(r["id"])
        if hit:
            out[r["id"]] = (usable(hit["released_at"]), "scry.d", True)
            continue
        pick = _pick(names.get(_norm(r["name"])), r)
        if pick:
            out[r["id"]] = (pick["day"], "scry.d", False)
    return out


def ygoprodeck_dates(getjson, game, rows, memo=None):
    data = getjson("https://db.ygoprodeck.com/api/v7/cardsets.php") or []
    names = _by_name([{"name": x.get("set_name"), "day": usable(x.get("tcg_date")), "year": x.get("tcg_date") or ""} for x in data if isinstance(x, dict) and usable(x.get("tcg_date"))])
    out = {}
    for r in rows:
        pick = _pick(names.get(_norm(r["name"])), r)
        if pick:
            out[r["id"]] = (pick["day"], "ygo.d", False)
    return out


def lorcast_dates(getjson, game, rows, memo=None):
    data = getjson("https://api.lorcast.com/v0/sets")
    data = (data.get("results") or data.get("data") or []) if isinstance(data, dict) else (data or [])
    names = _by_name([{"name": x.get("name"), "day": usable(x.get("released_at")), "year": x.get("released_at") or ""} for x in data if isinstance(x, dict) and usable(x.get("released_at"))])
    out = {}
    for r in rows:
        pick = _pick(names.get(_norm(r["name"])), r)
        if pick:
            out[r["id"]] = (pick["day"], "lorcast.d", False)
    return out


def pokemontcg_dates(getjson, game, rows, memo=None):
    """pokemontcg.io: a set with the same id AND name is the same set (exact); otherwise the name and the card count must both agree and be the only such set."""
    data = (getjson("https://api.pokemontcg.io/v2/sets?pageSize=250") or {}).get("data") or []
    data = [x for x in data if isinstance(x, dict) and usable(x.get("releaseDate"))]
    by_id = {str(x.get("id")): x for x in data}
    names = _by_name([{"name": x.get("name"), "day": usable(x["releaseDate"]), "year": x["releaseDate"], "total": x.get("total"), "printed": x.get("printedTotal")} for x in data])
    out = {}
    for r in rows:
        hit = by_id.get(r["id"])
        if hit and _norm(hit.get("name")) == _norm(r["name"]):
            out[r["id"]] = (usable(hit["releaseDate"]), "ptcg.d", True)
            continue
        c = [x for x in names.get(_norm(r["name"])) or [] if r.get("total") and r["total"] in (x.get("total"), x.get("printed"))]
        if len(c) == 1:
            out[r["id"]] = (c[0]["day"], "ptcg.d", False)
    return out


TIER1 = {"mtg": (scryfall_dates,), "yugioh": (ygoprodeck_dates,), "lorcana": (lorcast_dates,), "pokemon": (pokemontcg_dates,)}


def proven_sets(conn, game, getjson, set_ids=None, memo=None, days=DEFAULT_DAYS):
    """What the sources prove about each set (or the ones named).  -> {set id: {"day", "source", "exact", "contested": bool, "note"}}  - "contested" sets carry no day."""
    rows = [r for r in _rows_of(conn) if set_ids is None or r["id"] in set_ids]
    if not getjson or not rows:
        return {}
    got1, got2 = {}, {}
    for src in TIER1.get(game, ()):
        try:
            for sid, hit in src(getjson, game, rows, memo).items():
                got1.setdefault(sid, []).append(hit)
        except (KeyError, TypeError, ValueError, AttributeError):
            continue                                                        # a list that answers oddly proves nothing today
    try:
        got2 = tcgplayer_dates(getjson, game, rows, memo)
    except (KeyError, TypeError, ValueError, AttributeError):
        got2 = {}
    out = {}
    cur = {r["id"]: usable(r["date"]) for r in rows}
    for r in rows:
        sid = r["id"]
        hits = got1.get(sid) or ([got2[sid]] if sid in got2 else [])
        if not hits:
            continue
        if any(gap(hits[0][0], h[0]) is None or gap(hits[0][0], h[0]) > days for h in hits[1:]):
            out[sid] = {"day": "", "source": "", "exact": False, "contested": True, "note": "the sources disagree with each other"}
            continue
        day, code, exact = hits[0]
        g = gap(day, cur[sid])
        if code != "tcgp.d" and g is not None and g > MATCH_GUARD:
            out[sid] = {"day": "", "source": code, "exact": exact, "contested": True, "note": f"{g} days from ours - probably not the same set"}
            continue
        out[sid] = {"day": day, "source": code, "exact": exact, "contested": False, "fill_only": code == "tcgp.d", "note": ""}
    return out


# ------------------------------------------------------------------------------------------------ the audit (read only)
def _toy_days(conn, set_ids=None):
    """{set id: earliest believable day among its toys' own days} (raw ext.Released / published); {} when the list holds none."""
    try:
        q = ("SELECT set_id, MIN(d) FROM (SELECT set_id, COALESCE(NULLIF(json_extract(raw,'$.ext.Released'),''), NULLIF(json_extract(raw,'$.published'),'')) AS d FROM cards WHERE json_valid(raw)) "
             "WHERE d GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' AND d>=? AND d<=? GROUP BY set_id")
        return {str(s): d for s, d in conn.execute(q, (MIN_DAY, limit_day())) if set_ids is None or str(s) in set_ids}
    except sqlite3.Error:
        return {}


def audit_game(conn, game, getjson=None, days=DEFAULT_DAYS, memo=None, today=None):
    """Counts only; nothing is written.  -> dict (see tools/audit_dates.py for the meaning of each key)."""
    rows = _rows_of(conn)
    kinds = {r["id"]: classify(r["date"], today) for r in rows}
    n = lambda k: sum(1 for v in kinds.values() if v == k)       # noqa: E731
    cards_by_set = dict(conn.execute("SELECT set_id, COUNT(*) FROM cards GROUP BY set_id").fetchall())
    out = {"game": game, "sets": len(rows), "sets_blank": n("blank"), "sets_mark": n("mark"), "sets_format": n("format"), "sets_bad": n("bad"), "sets_impossible": n("impossible"),
           "cards": sum(cards_by_set.values())}
    out["cards_undated"] = sum(c for sid, c in cards_by_set.items() if kinds.get(sid, "blank") in ("blank", "bad", "impossible"))           # (no set row = no date either)
    proof = proven_sets(conn, game, getjson, None, memo, days) if getjson else {}
    out["sets_checked"] = sum(1 for p in proof.values() if p["day"])
    day_of_set = {r["id"]: usable(r["date"]) for r in rows}
    bad = {sid: p for sid, p in proof.items() if p["day"] and day_of_set.get(sid) and not p.get("fill_only") and (gap(p["day"], day_of_set[sid]) or 0) > days}
    out["sets_vs_source"] = len(bad)
    out["sets_fillable"] = sum(1 for sid, p in proof.items() if p["day"] and not day_of_set.get(sid))
    out["sets_contested"] = sum(1 for p in proof.values() if p["contested"])
    out["cards_vs_source"] = sum(cards_by_set.get(sid, 0) for sid in bad)
    try:
        sealed = conn.execute("SELECT id, set_id, released FROM sealed_products").fetchall()
    except sqlite3.Error:
        sealed = []
    gd = group_days(getjson, game, memo) if getjson else {}
    s = {"sealed": len(sealed), "sealed_blank": 0, "sealed_bad": 0, "sealed_impossible": 0, "sealed_format": 0, "sealed_inheritable": 0, "sealed_vs_set": 0, "sealed_vs_group": 0}
    for pid, sid, rel in sealed:
        k = classify(rel, today)
        if k == "blank":
            s["sealed_blank"] += 1
        elif k in ("bad", "impossible", "format"):
            s["sealed_" + k] += 1
        own = usable(rel, today)
        if not own:
            if day_of_set.get(str(sid)) or gd.get(str(sid)):
                s["sealed_inheritable"] += 1
            continue
        g = gap(own, day_of_set.get(str(sid)))
        if g is not None and g > days:
            s["sealed_vs_set"] += 1
        g = gap(own, gd.get(str(sid)))
        if g is not None and g > days:
            s["sealed_vs_group"] += 1
    out.update(s)
    out["sealed_undated"] = s["sealed_blank"] + s["sealed_bad"] + s["sealed_impossible"]
    out["wrong"] = out["cards_vs_source"] + s["sealed_bad"] + s["sealed_impossible"] + s["sealed_format"] + \
        sum(cards_by_set.get(sid, 0) for sid, v in kinds.items() if v in ("bad", "impossible", "format"))
    out["missing"] = out["cards_undated"] + out["sealed_undated"]
    return out


# ------------------------------------------------------------------------------------------------ the fixer
def _src_meta(conn):
    try:
        row = conn.execute("SELECT value FROM meta WHERE key=?", (META_KEY,)).fetchone()
        d = json.loads(row[0]) if row and row[0] else {}
        return d if isinstance(d, dict) else {}
    except (sqlite3.Error, ValueError):
        return {}


def fix_game(conn, game, getjson=None, set_ids=None, days=DEFAULT_DAYS, memo=None, today=None, all_sealed=True, stamping=True):
    """Fixes the dates of every set (or the ones named) and of their sealed products (all_sealed: and every product with no date).  The caller commits; nothing is written outside `conn`.
    -> {"sets", "sets_filled", "sets_corrected", "sets_format", "sets_from_toys", "sets_contested", "sets_unknown", "sealed", "sealed_filled", "sealed_inherited",
        "sealed_unknown", "examples"}   (the set the day was taken from is stamped; an unknown date stays empty)"""
    day = today_iso()
    ids = {str(i) for i in set_ids} if set_ids is not None else None
    rows = [r for r in _rows_of(conn) if ids is None or r["id"] in ids]
    out = {"sets": len(rows), "sets_filled": 0, "sets_corrected": 0, "sets_format": 0, "sets_from_toys": 0, "sets_contested": 0, "sets_unknown": 0,
           "sealed": 0, "sealed_filled": 0, "sealed_inherited": 0, "sealed_unknown": 0, "examples": []}

    def note(msg):
        if len(out["examples"]) < 6:
            out["examples"].append(msg)
    proof = proven_sets(conn, game, getjson, ids, memo, days) if getjson else {}
    stamps = _src_meta(conn)
    toys = None
    now = {}
    for r in rows:
        sid, cur_raw = r["id"], r["date"]
        kind, cur = classify(cur_raw, today), usable(cur_raw, today)
        p = proof.get(sid) or {}
        if kind == "mark":
            now[sid] = ""
            continue                                                                                     # the toy-line mark stays
        new, src = "", ""
        if p.get("contested"):
            out["sets_contested"] += 1
        elif p.get("day") and (not cur or (not p.get("fill_only") and (gap(p["day"], cur) or 0) > days)):
            new, src = p["day"], p["source"]
        if not new and not cur:
            if toys is None:
                toys = _toy_days(conn)
            if toys.get(sid):
                new, src = toys[sid], "items"
        if new:
            conn.execute("UPDATE sets SET release_date=? WHERE id=?", (new, sid))
            stamps[sid] = [src, day]
            key = "sets_filled" if not cur else "sets_corrected"
            out[key] += 1
            out["sets_from_toys"] += 1 if src == "items" else 0
            note(f"{r['name']}: {cur_raw or 'none'} -> {new} ({src})")
            now[sid] = new
        elif cur and cur_raw != cur:                                                                     # a real day written another way: written plainly
            conn.execute("UPDATE sets SET release_date=? WHERE id=?", (cur, sid))
            out["sets_format"] += 1
            now[sid] = cur
        elif not cur:
            if cur_raw and cur_raw.strip():
                conn.execute("UPDATE sets SET release_date='' WHERE id=?", (sid,))                       # (an impossible / garbage day is unknown, not a date)
            out["sets_unknown"] += 1
            now[sid] = ""
        else:
            now[sid] = cur
    if out["sets_filled"] + out["sets_corrected"]:
        conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (META_KEY, json.dumps(stamps)))
    # ---- sealed products
    gd = group_days(getjson, game, memo) if getjson else {}
    set_day = {str(r[0]): usable(r[1]) for r in conn.execute("SELECT id, release_date FROM sets")}
    try:
        sealed = conn.execute("SELECT id, set_id, released FROM sealed_products").fetchall()
    except sqlite3.Error:
        sealed = []
    stamp = []
    for pid, sid, rel in sealed:
        sid = str(sid)
        if ids is not None and sid not in ids and not (all_sealed and not usable(rel)):
            continue
        out["sealed"] += 1
        own = usable(rel, today)
        grp = gd.get(sid, "")
        new, src = "", ""
        if not own and grp:
            new, src = grp, "tcgp.d"
        elif not own and set_day.get(sid):
            new, src = set_day[sid], "inherit"
        if new:
            conn.execute("UPDATE sealed_products SET released=? WHERE id=?", (new, pid))
            stamp.append((pid, "date", src, day))
            out["sealed_filled"] += 1
            out["sealed_inherited"] += 1 if src == "inherit" else 0
        elif own and rel != own:
            conn.execute("UPDATE sealed_products SET released=? WHERE id=?", (own, pid))
        elif not own:
            if (rel or "").strip():
                conn.execute("UPDATE sealed_products SET released='' WHERE id=?", (pid,))
            out["sealed_unknown"] += 1
    if stamp and stamping:
        provenance.record_many(conn, stamp)                                       # (makes the two tables when a list has none yet)
        conn.executemany("INSERT OR IGNORE INTO sources(code,name,url_tpl) VALUES(?,?,?)", [(k, v[0], v[1]) for k, v in provenance.SOURCES.items() if k in ("tcgp.d", "inherit")])
    return out


def fix_new(conn, game, set_ids, getjson=None, dry_run=False):
    """The add path (setfiling.file_new_sets): the new sets' dates and their products', plus any product still without a day.  A dry run writes nothing."""
    if dry_run:
        conn.execute("SAVEPOINT datefix_dry")
        try:
            return fix_game(conn, game, getjson, set_ids, stamping=False)                  # (making the stamp tables would commit and lose the savepoint; the rows are rolled back anyway)
        finally:
            conn.execute("ROLLBACK TO datefix_dry")
            conn.execute("RELEASE datefix_dry")
    return fix_game(conn, game, getjson, set_ids)
