"""The one canonical form of every query-API question (lane Q, docs/speed136_web_design.md 3.2).

Every route has a fixed list of parameters (PARAMS).  A question is canonical when its parameters are sorted by name, every value is in its normal form (words in lower case with single
spaces, numbers without trailing zeros, list values sorted and unique) and nothing equal to its default is given.  The client builds exactly that (the same rules as JS encodeURIComponent);
the server answers anything else with 308 to the canonical address, so a CDN keeps ONE copy per question.  A parameter that is not on the route's list is refused (400): there is no way to
send owned ids, counts or anything else from a collection (tests/test_query_api.py checks every list)."""
import hashlib
import re
from urllib.parse import quote, unquote

PAGE_SET = 250                    # cards per page of a set
PAGE_SEARCH = 60                  # cards per page of a search
MAX_PAGE = 400                    # (deeper than 24,000 cards of one search: narrow it instead)
ENC_SAFE = "-_.!~*'()"            # what JS encodeURIComponent leaves as it is

SORTS = ("default", "popular", "price", "priceasc", "name", "namez", "oldest", "numasc", "set", "rarity", "artist", "dex", "color")      # findfast.SORTS: every order the Cards page offers
FACET_KEY = re.compile(r"^[A-Za-z0-9_.:\- ]{1,40}$")


class CanonError(ValueError):
    """A question that cannot be answered as asked (400): unknown parameter, bad value."""


def _words(v):
    return " ".join(str(v).lower().split())


def _plain(v):
    return " ".join(str(v).split())


def _num(v):
    try:
        x = float(v)
    except ValueError:
        raise CanonError("not a number")
    if x != x or x in (float("inf"), float("-inf")) or abs(x) > 1e9:
        raise CanonError("not a number")
    s = ("%.2f" % x).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def _int(lo, hi):
    def f(v):
        if not re.fullmatch(r"-?\d{1,6}", str(v).strip()):
            raise CanonError("not a whole number")
        x = int(v)
        if not lo <= x <= hi:
            raise CanonError("out of range")
        return str(x)
    return f


def _enum(*allowed):
    def f(v):
        v = str(v).strip()
        if v not in allowed:
            raise CanonError("not one of " + ", ".join(allowed))
        return v
    return f


def _letter(v):
    from ..searchfold import fold
    v = str(v).strip()
    if v == "#":
        return "#"
    f = fold(v)[:1]
    if not f:
        raise CanonError("not a letter")
    return f


# name -> (normal form, default).  The engine argument each one stands for is in handlers.LIST_ARGS.
LIST = {
    "q": (_words, ""), "rarity": (_plain, ""), "type": (_plain, ""), "set": (_words, ""), "artist": (_words, ""),
    "pmin": (_num, ""), "pmax": (_num, ""), "ymin": (_int(1, 9999), ""), "ymax": (_int(1, 9999), ""), "priced": (_enum("yes", "no"), ""),
    "letter": (_letter, ""), "edition": (_enum("tcg", "pocket"), ""), "sort": (_enum(*SORTS), "default"), "p": (_int(0, MAX_PAGE), "0"),
}
PARAMS = {
    "manifest": {},
    "sets": {},
    "filters": {"set": (_plain, ""), "edition": (_enum("tcg", "pocket"), "")},
    "set": LIST,
    "search": LIST,
    "card": {},
    "facts": {},
    "match": {},
}
FACETS_ON = ("set", "search", "match")           # routes that also take f.<facet>=value (the game's own filters: kind, colour, attribute...; any of a facet's values, every facet)


def enc(v):
    return quote(str(v), safe=ENC_SAFE)


def parse_qs(qs):
    """[(name, value)] in the order given, %-decoded once ('+' is a plus, as encodeURIComponent writes a space %20)."""
    out = []
    for part in (qs or "").split("&"):
        if not part:
            continue
        k, _, v = part.partition("=")
        out.append((unquote(k), unquote(v)))
    return out


def canonical(route, pairs):
    """-> (args, canonical query string without '?').  args = {name: normal value} (only those not at their default) and "facets": {key: [values]}.  Raises CanonError."""
    spec = PARAMS[route]
    args, facets = {}, {}
    for k, v in pairs:
        if k.startswith("f.") and route in FACETS_ON:
            key = k[2:]
            if not FACET_KEY.match(key):
                raise CanonError(f"bad filter name {key!r}")
            val = _plain(v)
            if val:
                facets.setdefault(key, set()).add(val)
            continue
        if k not in spec:
            raise CanonError(f"unknown parameter {k!r}")
        if k in args:
            raise CanonError(f"{k!r} given twice")
        norm, default = spec[k]
        val = norm(v) if str(v).strip() != "" else ""
        if val != default and val != "":
            args[k] = val
    parts = sorted([(k, v) for k, v in args.items()] + [("f." + k, x) for k, vals in facets.items() for x in sorted(vals)])
    qs = "&".join(f"{enc(k)}={enc(v)}" for k, v in parts)
    args["facets"] = {k: sorted(v) for k, v in facets.items()}
    return args, qs


def seg(v):
    """One path segment (a set id, a card id) as the canonical address writes it."""
    return quote(str(v), safe="-_.!~*'()")


def etag(cv, pv, rev, canon_path):
    """The validator of an answer: the list, the price day, the handlers' answer version and a hash of the canonical question."""
    h = hashlib.sha256(f"{rev}|{canon_path}".encode("utf-8")).hexdigest()[:16]
    return f'"{cv}.{pv}.{h}"' if pv else f'"{cv}.{h}"'
