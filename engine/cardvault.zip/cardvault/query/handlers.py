"""The Card Data query API's answers (lane Q, docs/speed136_web_design.md 3.2): paged JSON from a game's query db (build.py), catalog only.

Routes (GET, under /q/v1/):
    manifest                                      {v, built, games: {g: {cv, pv, cards, built}}, search}                         no-cache + ETag
    <g>/<cv>/sets                                 every set: [id, name, serie, release, total, official, logo, cards]            immutable
    <g>/<cv>/filters?set=&edition=                the Cards page's filters and sorts (cards.filters, catalog part)              immutable
    <g>/<cv>.<pv>/set/<set id>?<list params>&p=   that set's cards, 250 a page (cards.list kind=set)                           immutable
    <g>/<cv>.<pv>/search?<list params>&p=         the game's list searched / filtered / sorted, 60 a page (cards.list), facets on page 0    immutable
    <g>/<cv>.<pv>/card/<id>                       one card's catalog facts (card.detail without copies, notes, photos, history)  immutable
    <g>/<cv>.<pv>/facts                           the WHOLE list's catalog fields, for the device to join with what is yours (facts.py)   immutable
    <g>/<cv>.<pv>/match?f.<facet>=<value>         the ids of every card of the game's own filters (the device narrows your own cards with them)   immutable
List params (canon.LIST): q rarity type set artist pmin pmax ymin ymax priced letter edition sort p, and f.<facet>=<value>.  NONE of them can carry anything from a collection: an owned
mark, a count or a wishlist heart is added by the page on the device.

The handlers are pure functions (conn, game, args) -> dict.  The WHERE of a list question is the engine's own SQL builder (Vault._query_cards_sql) - asked for its SQL text, not re-typed -
and its order is the place the engine's ORDER BY gave every card at build time, so the ids come back in the engine's order."""
import functools
import hashlib
import json
import os
import re
import sqlite3
import threading

from . import build, canon

REV = 2                               # the answers' version: part of every ETag (a change to what a handler answers for the same db bumps it).  2: rows carry msrp + one, card the panel extras
ROW_COLS = ["id", "name", "setId", "number", "rarity", "img", "usd", "kind", "variants", "tcg", "msrp", "one"]
_ROW_SQL = "SELECT id, name, set_id, local_id, rarity, image_base, price_usd, price_kind, variants, tcg_id, {one} FROM cards WHERE id IN (SELECT value FROM json_each(?))"
LIST_ARGS = {"q": "text", "rarity": "rarity", "type": "ctype", "set": "set_text", "artist": "artist", "pmin": "price_min", "pmax": "price_max", "ymin": "year_min", "ymax": "year_max",
             "priced": "priced", "letter": "letter", "edition": "edition"}           # query parameter -> the engine's cards.list / Vault.query_cards argument
IMMUTABLE = "public, max-age=31536000, immutable"
CV_RE = re.compile(r"^[0-9a-f]{10}$")
PV_RE = re.compile(r"^\d{8}$")


class Answer(Exception):
    """An error answer: status + message (400 bad question, 404 unknown list / set / card)."""

    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


# ---------------------------------------------------------------------------------------------------------------- the engine's SQL, asked for its text
class _Rec:
    """A connection that only writes down what it is asked (the engine's builder runs its execute() on it, nothing is read)."""

    def __init__(self):
        self.calls = []
        self.row_factory = None

    def execute(self, sql, args=()):
        self.calls.append((sql, list(args)))
        return self

    def cursor(self):
        return self

    def fetchone(self):
        return (0,)

    def fetchall(self):
        return []

    def __iter__(self):
        return iter(())


_tax_lock = threading.Lock()


@functools.lru_cache(maxsize=4096)
def _engine_sql(pokemon, items):
    """-> (count SQL, its args, page SQL, its args) of the engine's own builder for these filters, read from the slim table.  (One question's text is worked out once and kept.)"""
    from .. import findfast, taxonomy
    kw = dict(items)
    rec = _Rec()
    eng = build._Engine(rec, True, True)
    run = build.engine_sql()
    with _tax_lock:                                                       # (a Pokemon type filter reads the game's kind from taxonomy: set for this question only)
        was = taxonomy._state["pokemon"]
        taxonomy._state["pokemon"] = pokemon
        try:
            run(eng, ids_only="count", **kw)
            run(eng, ids_only="page", page=1, **kw)
        finally:
            taxonomy._state["pokemon"] = was
    (csql, cargs), (psql, pargs) = rec.calls[0], rec.calls[1]
    csql, psql = csql.replace(findfast.TABLE, "slim"), psql.replace(findfast.TABLE, "slim")
    if not csql.startswith("SELECT COUNT(*) FROM slim c ") or not psql.startswith("SELECT c.id FROM slim c ") or not psql.endswith(" LIMIT ?"):
        raise RuntimeError("the engine's search SQL changed shape: cardvault/query/handlers.py must follow it")
    return csql, tuple(cargs), psql[:-len(" LIMIT ?")], tuple(pargs[:-1])


_TRIGRAM = {"c.fold LIKE ?": "c.rid IN (SELECT rowid FROM slim_fts WHERE slim_fts.fold LIKE ?)",                # (build.py's trigram indexes: the same cards as the LIKE, both sides folded)
            "fold(c.illustrator) LIKE ?": "c.rid IN (SELECT rowid FROM slim_afts WHERE slim_afts.ifold LIKE ?)"}
_JOIN = " LEFT JOIN sets s ON s.id=c.set_id"
_USES_S = re.compile(r"(?<![\w.])s\.")
_SET_FOLD = re.compile(r"(?<![\w.])s\.fold LIKE \?")
_SET_WHERE = [                         # what the engine asks of a card's set, asked of the sets table once (a card whose set is missing matches neither way - LEFT JOIN gives NULL)
    ("CAST(substr(s.release_date,1,4) AS INTEGER) >= ?", "c.set_id IN (SELECT id FROM sets WHERE CAST(substr(release_date,1,4) AS INTEGER) >= ?)"),
    ("CAST(substr(s.release_date,1,4) AS INTEGER) BETWEEN 1 AND ?", "c.set_id IN (SELECT id FROM sets WHERE CAST(substr(release_date,1,4) AS INTEGER) BETWEEN 1 AND ?)"),
    ("(s.serie IS NULL OR s.serie NOT LIKE '%pocket%')", "c.set_id NOT IN (SELECT id FROM sets WHERE id IS NOT NULL AND serie LIKE '%pocket%')"),      # (no set row: NULL serie = not Pocket)
    ("s.serie LIKE '%pocket%'", "c.set_id IN (SELECT id FROM sets WHERE serie LIKE '%pocket%')"),
    ("(s.official=? OR s.total=?)", "c.set_id IN (SELECT id FROM sets WHERE official=? OR total=?)"),
]


def _fast(sql, args):
    """The same question, answered quicker - two rewrites that never change which cards match:
    a typed word of 3+ letters ('%bolt%') is looked up in a trigram index (slim_fts / slim_afts: the same cards as c.fold LIKE '%bolt%' - fold is lower case, and so is the word), what is asked
    of a card's set is asked of the sets table once, and the join to the sets is left out when nothing asks about the set (one set row per card: it never adds or drops a card)."""
    out, ai, i = [], 0, 0
    while True:
        j = sql.find("?", i)
        if j < 0:
            out.append(sql[i:])
            break
        piece = sql[i:j + 1]
        like = next((k for k in _TRIGRAM if piece.endswith(k)), None)
        if like:
            a = args[ai]
            w = a[1:-1] if isinstance(a, str) and len(a) >= 2 and a[0] == "%" and a[-1] == "%" else ""
            if len(w) >= 3 and "%" not in w and "_" not in w:
                piece = piece[:-len(like)] + _TRIGRAM[like]
        out.append(piece)
        ai += 1
        i = j + 1
    sql = "".join(out).replace("fold(c.illustrator)", "c.ifold")                           # (the same folded artist, worked out at build time)
    sql = _SET_FOLD.sub("c.set_id IN (SELECT id FROM sets WHERE fold LIKE ?)", sql)             # (the set's words: its one set row, looked up once for all cards)
    for old, new in _SET_WHERE:
        sql = sql.replace(old, new)
    head, joined, tail = sql.partition(_JOIN)
    if joined and not _USES_S.search(tail):
        sql = head + tail
    return sql, args


_RANK = "CASE WHEN c.fname=? OR c.nname=? THEN 0 WHEN c.fname LIKE ? OR c.nname LIKE ? THEN 1 ELSE 2 END"      # (db._rank_sql's plain form, on the slim table)
SPLIT_FROM = 2000                     # a ranked answer this big is read in two parts (_Q.ids)
_SCAN_COLS = {"rarity", "fold", "set_id", "rid"}          # the columns of the slim_scan index (build.py)


def _after(s):
    """The first text after every text that starts with `s` (binary order): 'abc' <= x < 'abd' is exactly "x starts with 'abc'"."""
    return s[:-1] + chr(ord(s[-1]) + 1)


def _with(sql, cond):
    """Add one more condition to a query of the engine's shape (before its ORDER BY, if any)."""
    head, sep, tail = sql.partition(" ORDER BY ")
    head += (" AND " if " WHERE " in head else " WHERE ") + cond
    return head + sep + tail


def _kw(args, set_id=None):
    kw = {"set_id": set_id} if set_id else {}
    for k, name in LIST_ARGS.items():
        if k in args:
            v = args[k]
            kw[name] = float(v) if k in ("pmin", "pmax") else int(v) if k in ("ymin", "ymax") else v
    return kw


def _facet_cond(conn, facets):
    """The game's own filters (cards.list facets): every chosen one must match, any of its values will do -> [(SQL condition, args)]."""
    from .. import cardtext, legality
    out = []
    if len(facets) > 8 or any(len(v) > 20 for v in facets.values()):
        raise Answer(400, "too many filters")
    for k, vals in sorted(facets.items()):
        marks = ",".join("?" * len(vals))
        # only a filter this list HAS, with values it has (card text: a few words): nothing else can ride along in a filter - no list of ids, no counts
        if k == cardtext.KEY:
            if len(vals) > 3 or any(len(v) > 60 for v in vals):
                raise Answer(400, "card text: a few words only")
        else:
            look = ("SELECT 1 FROM slim WHERE category=? LIMIT 1", None) if k == "category" else ("SELECT 1 FROM card_legality WHERE format=? LIMIT 1", None) if k == legality.FACET_KEY else \
                ("SELECT 1 FROM card_facets WHERE facet=? AND value=? LIMIT 1", k)
            for v in vals:
                try:
                    hit = conn.execute(look[0], (v,) if look[1] is None else (look[1], v)).fetchone()
                except sqlite3.Error:
                    hit = None
                if not hit:
                    raise Answer(400, f"this list has no filter {k!r} = {v!r}")
        if k == "category":
            out.append((f"c.category IN ({marks})", list(vals)))
        elif k == legality.FACET_KEY:
            out.append(("c.id IN (SELECT value FROM json_each(?))", [json.dumps(sorted(legality.card_ids(conn, vals)))]))
        elif k == cardtext.KEY:
            out.append(("c.id IN (SELECT value FROM json_each(?))", [json.dumps(sorted(cardtext.card_ids(conn, vals)))]))
        else:
            out.append((f"c.id IN (SELECT card_id FROM card_facets WHERE facet=? AND value IN ({marks}))", [k, *vals]))
    return out


class _Q:
    """One list question on one db: the engine's filters + the facet filters, in the order of one sort."""

    def __init__(self, conn, pokemon, kw, sort, facets):
        csql, cargs, psql, pargs = _engine_sql(pokemon, tuple(sorted(kw.items())))
        self.conn = conn
        conds = _facet_cond(conn, facets) if facets else []
        for cond, a in conds:
            csql = _with(csql, cond)
            psql = _with(psql, cond)
        fargs = [x for _c, a in conds for x in a]
        where_n = len(cargs)
        self.count_sql, self.count_args = csql, list(cargs) + fargs
        ranked = sort == "default" and not psql.endswith(" ORDER BY c.dpos")          # (the default order with words typed: names that ARE the words first, then names starting with them)
        self.split = None
        if ranked:
            self.page_sql, self.page_args = psql, list(pargs[:where_n]) + fargs + list(pargs[where_n:])
            rargs = list(pargs[where_n:])
            if _RANK in psql and len(rargs) == 4 and all(isinstance(x, str) and x and "%" not in x and "_" not in x for x in rargs[:2]):
                # rank < 2 is exactly "the name starts with the words" (both sides are folded: lower case), so a ranked page = those names in (rank, dpos) order, then every other card in dpos order
                pre = "((c.fname >= ? AND c.fname < ?) OR (c.nname >= ? AND c.nname < ?))"
                pargs2 = [rargs[0], _after(rargs[0]), rargs[1], _after(rargs[1])]
                base_sql, base_args = csql, list(cargs) + fargs
                a_sql = _with(base_sql, pre).replace("SELECT COUNT(*)", "SELECT c.id", 1) + psql[psql.rindex(" ORDER BY "):]
                self.split = (_fast(_with(base_sql, pre), base_args + pargs2),
                              _fast(a_sql, base_args + pargs2 + rargs),
                              _fast(_with(base_sql, "NOT " + pre).replace("SELECT COUNT(*)", "SELECT c.id", 1) + " ORDER BY c.dpos", base_args + pargs2))
        else:
            col = "dpos" if sort == "default" else "pos_" + sort
            self.page_sql, self.page_args = csql.replace("SELECT COUNT(*)", "SELECT c.id", 1) + f" ORDER BY c.{col}", list(self.count_args)
        self.count_sql, self.count_args = _fast(self.count_sql, self.count_args)
        self.page_sql, self.page_args = _fast(self.page_sql, self.page_args)
        self._rar = None

    def count(self):
        if self._rar is not None:
            return sum(n for _r, n in self._rar)
        return self.conn.execute(self.count_sql, self.count_args).fetchone()[0]

    def ids(self, limit, offset, total=None):
        """The ids of one page.  A ranked page of a big answer (a typed 'l': 87,000 of Magic's cards) is read in two parts (see __init__), so only the cards shown are put in order."""
        run = lambda sql, args, n, o: [r[0] for r in self.conn.execute(sql + " LIMIT ? OFFSET ?", args + [int(n), int(o)])]
        if self.split is None or total is None or total < SPLIT_FROM or limit < 0:
            return run(self.page_sql, self.page_args, limit, offset)
        (n_sql, n_args), (a_sql, a_args), (b_sql, b_args) = self.split
        if offset == 0:
            out = run(a_sql, a_args, limit, 0)
            na = len(out)                                                         # (a full first part: the second is not needed; a short one: that was all of it)
        else:
            na = self.conn.execute(n_sql, n_args).fetchone()[0]
            out = run(a_sql, a_args, limit, offset) if offset < na else []
        if len(out) < limit:
            out += run(b_sql, b_args, limit - len(out), max(0, offset - na))
        return out

    def rarities(self):
        """[[rarity, cards]] among the matching cards, most first (worked out with the count: one read for both)."""
        if self._rar is None:
            kept = None if " WHERE " in self.count_sql else self.conn.execute("SELECT v FROM answers WHERE k='rar'").fetchone()
            if kept:
                self._rar = [tuple(x) for x in json.loads(kept[0])]                     # (no filter at all: the whole list's, worked out at build time)
            else:
                covered = set(re.findall(r"(?<![\w.])c\.(\w+)", self.count_sql)) <= _SCAN_COLS      # (asks only what the narrow copy holds: read it in rarity order; else read the rows)
                sql = self.count_sql.replace("SELECT COUNT(*)", "SELECT c.rarity, COUNT(*)", 1) + (" GROUP BY c.rarity" if covered else " GROUP BY +c.rarity")
                self._rar = self.conn.execute(sql, self.count_args).fetchall()
        return sorted(([r, n] for r, n in self._rar if r), key=lambda x: (-x[1], x[0]))


# ---------------------------------------------------------------------------------------------------------------- one db
class Db:
    """A game's query db, opened read-only (immutable: it never changes once built)."""

    def __init__(self, path):
        self.path = path
        c = self._open()
        try:
            meta = dict(c.execute("SELECT key, value FROM meta"))
        finally:
            c.close()
        if str(meta.get("q_v")) != str(build.QUERY_V):
            raise ValueError(f"query db layout {meta.get('q_v')} (this code reads {build.QUERY_V})")
        self.meta = meta
        self.game, self.cv, self.pv = meta["q_game"], meta["q_cv"], meta["q_pv"]
        self.cards = int(meta.get("q_cards") or 0)
        from .. import games
        g = next((x for x in games.GAMES if x.id == self.game), None)
        if g is None:
            raise ValueError(f"unknown game {self.game}")
        self.g = g
        self.pokemon = bool(g.pokemon)
        self._local = threading.local()
        self._vocab = self._facts = None
        self._vlock, self._flock = threading.Lock(), threading.Lock()

    def _open(self):
        c = sqlite3.connect("file:" + self.path.replace("\\", "/") + "?mode=ro&immutable=1", uri=True, check_same_thread=False)
        try:
            c.execute("PRAGMA mmap_size=536870912")
        except sqlite3.Error:
            pass
        build._register(c)
        return c

    def conn(self):
        """This thread's connection (sqlite connections are not shared between threads)."""
        c = getattr(self._local, "c", None)
        if c is None:
            c = self._local.c = self._open()
        return c

    def kept(self, route, qs):
        """An answer worked out at build time (first_keys), or None."""
        r = self.conn().execute("SELECT v FROM answers WHERE k=?", (f"page|{route}|{qs}",)).fetchone()
        return r[0].encode("utf-8") if r else None

    def facts_bytes(self):
        """The facts file of this db (facts.py): made by build.py and kept in it (answers 'facts': Magic's is ~20 MB of JSON, 2.5 MB gz), read once; a db built before it had them
        makes them here, once (a few seconds - its own lock, so the other questions are not held up meanwhile)."""
        if self._facts is None:
            with self._flock:
                if self._facts is None:
                    r = self.conn().execute("SELECT v FROM answers WHERE k='facts'").fetchone()
                    if r:
                        self._facts = r[0].encode("utf-8")
                    else:
                        from . import facts as _facts
                        self._facts = _facts.make_bytes(self.conn(), self.game, self.cv, self.pv)
        return self._facts

    def vocab(self):
        """The name words for typo tolerance (cardvault/fuzzy.py), read once from the db's vocab table."""
        if self._vocab is None:
            from .. import fuzzy
            with self._vlock:
                if self._vocab is None:
                    self._vocab = fuzzy.Vocab(dict(self.conn().execute("SELECT w, n FROM vocab")))
        return self._vocab


# ---------------------------------------------------------------------------------------------------------------- the handlers: (db, args) -> dict
def _img(db, base):
    from ..db import picture_url
    if not base:
        return ""
    return picture_url(base, "low") if db.pokemon else base


def _variants(raw, rarity):
    from ..db import VARIANT_FLAGS, VARIANT_LABELS, clean_flags
    try:
        flags = clean_flags(json.loads(raw or "{}"), rarity)
    except (ValueError, TypeError):
        flags = {}
    return [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)] or ["Normal"]


def _row(db, r, retail):
    from ..db import fix_text
    cid, name, sid, num, rar, base, usd, kind, var, tcg, one = r
    return [cid, fix_text(name), sid, num, rar or "", _img(db, base), usd, kind or "", _variants(var, rar), tcg or "", retail.get(cid), bool(one)]


def list_ids(db, args, set_id=None):
    """[card id] of every card answering the question, in its order (the parity tests compare this with the engine's cards.list)."""
    return _list(db, args, set_id, 0, None)[0]


def _list(db, args, set_id, offset, limit, facets_too=False):
    """-> (ids of one page, total, query) (limit None = all).  With words typed and fewer than fuzzy.FEW cards found, the cards found with the typos corrected follow (Vault.query_cards fuzzy)."""
    from .. import fuzzy
    from ..db import alias_text
    conn = db.conn()
    sort = args.get("sort", "default")
    kw = _kw(args, set_id)
    facets = args.get("facets") or {}
    q = _Q(conn, db.pokemon, kw, sort, facets)
    if facets_too:
        q.rarities()
    total = q.count()
    text = kw.get("text", "")
    fixed = None
    if text.strip() and total < fuzzy.FEW:
        fixed = fuzzy.correct_text(db.vocab(), alias_text(text).strip())
    if not fixed:
        return q.ids(limit if limit is not None else -1, offset, total), total, q
    exact = q.ids(-1, 0)
    have = set(exact)
    both = exact + [i for i in _Q(conn, db.pokemon, {**kw, "text": fixed}, sort, facets).ids(-1, 0) if i not in have]
    return (both[offset:] if limit is None else both[offset:offset + limit]), len(both), q


def _rows(db, ids):
    """The page rows (ROW_COLS) of these cards, in this order."""
    from .. import msrp
    if not ids:
        return []
    conn = db.conn()
    one = "one_source" if any(r[1] == "one_source" for r in conn.execute("PRAGMA main.table_info(cards)")) else "0"      # (the tile's 'only one source so far'; an older list has no such column)
    got = {r[0]: r for r in conn.execute(_ROW_SQL.format(one=one), (json.dumps(ids),))}
    retail = msrp.lookup(conn, ids)                         # (the maker's retail price beside the market price, as the engine's tile shows it)
    return [_row(db, got[i], retail) for i in ids if i in got]


def set_page(db, args, set_id):
    conn = db.conn()
    s = conn.execute("SELECT id, name, serie, release_date, total, official FROM sets WHERE id=?", (set_id,)).fetchone()
    if not s:
        raise Answer(404, "no such set in this list")
    p = int(args.get("p", 0))
    ids, total, _q = _list(db, args, set_id, p * canon.PAGE_SET, canon.PAGE_SET)
    return {"game": db.game, "cv": db.cv, "pv": db.pv, "set": {"id": s[0], "name": s[1], "serie": s[2] or "", "release": s[3] or "", "total": s[4], "official": s[5]},
            "cols": ROW_COLS, "rows": _rows(db, ids), "total": total, "p": p, "size": canon.PAGE_SET, "next": p + 1 if (p + 1) * canon.PAGE_SET < total else None}


def search(db, args):
    p = int(args.get("p", 0))
    ids, total, q = _list(db, args, None, p * canon.PAGE_SEARCH, canon.PAGE_SEARCH, facets_too=p == 0)
    rows = _rows(db, ids)
    sids = sorted({r[2] for r in rows})
    names = dict(db.conn().execute(f"SELECT id, name FROM sets WHERE id IN ({','.join('?' * len(sids))})", sids)) if sids else {}
    out = {"game": db.game, "cv": db.cv, "pv": db.pv, "cols": ROW_COLS, "rows": rows, "sets": names, "total": total, "p": p, "size": canon.PAGE_SEARCH,
           "next": p + 1 if (p + 1) * canon.PAGE_SEARCH < total else None}
    if p == 0:
        out["facets"] = {"rarity": q.rarities()}
    return out


def sets(db, args):
    from .. import setartmap
    conn = db.conn()
    try:
        urls = json.loads((conn.execute("SELECT value FROM meta WHERE key='setimg_urls'").fetchone() or ["{}"])[0] or "{}")
    except (ValueError, sqlite3.Error):
        urls = {}
    n = dict(conn.execute("SELECT set_id, COUNT(*) FROM slim GROUP BY set_id"))
    rows = []
    for sid, name, serie, rel, total, official, logo in conn.execute("SELECT id, name, serie, release_date, total, official, logo FROM sets ORDER BY (release_date IS NULL OR release_date=''), release_date DESC, id"):
        url = (logo + ".webp") if logo else (urls.get(sid, "") or setartmap.url_for(sid, name))       # (as Service.logo_url gives the browser)
        rows.append([sid, name, serie or "", rel or "", total, official, url, n.get(sid, 0)])
    return {"game": db.game, "cv": db.cv, "cols": ["id", "name", "serie", "release", "total", "official", "logo", "cards"], "rows": rows}


class _FVault:
    """Enough of a Vault for the Cards page's sort list (webapi/cards._sort_choices) on a query db."""

    def __init__(self, conn):
        self.conn = conn

    def _has_pop(self):
        return any(r[1] == "popularity" for r in self.conn.execute("PRAGMA main.table_info(cards)"))


def filters_key(set_id, edition):
    return f"filters|{set_id or ''}|{edition or ''}"


def filters_for(conn, g, set_id, edition):
    """cards.filters (webapi/cards._filters) on a query db, without what needs the engine's card index: Pokemon eras are None here (the device adds them).
    The sorts that put YOUR cards first ('owned', 'unowned') are the default order with yours moved up: the page does that (localSorts)."""
    from .. import gamefacets, legality
    from ..webapi.cards import _filter_scope, _sort_choices
    scope = _filter_scope("set" if set_id else "all", set_id or None, edition)
    basics = gamefacets.basics(conn, g.id, scope)
    try:
        facets = gamefacets.filters(conn, g.id, scope)
    except Exception:  # noqa: BLE001 - as the engine: a list without them still has its other filters
        facets = []
    lg = legality.facet(conn, scope)
    if lg:
        facets = list(facets) + [lg]
    return {"facets": facets, "types": basics["types"], "rarities": basics["rarities"], "typeLabel": g.type_label,
            "eras": [] if (set_id or not g.pokemon) else None, "hasArtist": basics["hasArtist"], "hasDates": basics["hasDates"], "hasPrices": basics["hasPrices"],
            "sorts": _sort_choices(_FVault(conn), g, basics), "localSorts": ["owned", "unowned"], "voc": gamefacets.vocab(g.id)}


def filters(db, args):
    set_id, edition = args.get("set", ""), args.get("edition", "") or None
    if set_id and not db.conn().execute("SELECT 1 FROM sets WHERE id=?", (set_id,)).fetchone():
        raise Answer(404, "no such set in this list")
    kept = db.conn().execute("SELECT v FROM answers WHERE k=?", (filters_key(set_id, edition),)).fetchone()
    out = json.loads(kept[0]) if kept else filters_for(db.conn(), db.g, set_id, edition)
    return {"game": db.game, "cv": db.cv, **out}


def card(db, args, cid):
    """card.detail's catalog part (the same field names): facts, text blocks, printings, prices, sources, legality, shop links.  Copies, notes, photos, lists and price history come from the device."""
    import re as _re
    from .. import legality, msrp, provenance, pullrates, selllinks, shoplinks
    from ..db import fix_text
    from ..details.match import clean as textclean
    conn = db.conn()
    conn.row_factory = sqlite3.Row
    try:
        c = conn.execute("SELECT c.*, s.name AS set_name, s.official AS set_official FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id=?", (cid,)).fetchone()
    finally:
        conn.row_factory = None
    if not c:
        raise Answer(404, "no such card in this list")
    keys = c.keys()
    raw = {}
    try:
        raw = json.loads(c["raw"] or "{}")
    except (ValueError, TypeError):
        pass
    t = lambda s: fix_text(s) if s else ""
    pokemon = db.pokemon
    number = f"{c['local_id']}/{c['set_official']}" if (c["set_official"] and pokemon) else c["local_id"]
    facts = []
    if pokemon:
        for lab, key in (("Type", "types"), ("Stage", "stage"), ("Illustrator", "illustrator")):
            if c[key]:
                facts.append([lab, t(c[key])])
        if c["hp"]:
            facts.append(["HP", str(c["hp"])])
        if c["evolve_from"]:
            facts.append(["Evolves from", t(c["evolve_from"])])
        if c["dex"]:
            facts.append(["Pokédex", "#" + c["dex"].replace(",", ", #")])
        if _re.fullmatch(r"[A-Z]", str(raw.get("regulationMark") or "")):
            facts.append(["Regulation mark", raw["regulationMark"]])
        if isinstance(raw.get("ext"), dict) and not raw.get("attacks"):
            for k, val in raw["ext"].items():
                if k not in ("Number", "Rarity", "HP", "Stage", "Card Type", "Description") and val not in ("", None):
                    facts.append([k, t(textclean(str(val)))])
    else:
        ext = raw.get("ext", {})
        facts = [[k, t(textclean(str(ext[k]).replace(";", ", ")))] for k in ext if k not in ("Description", "Number") and ext[k] not in ("", None)]
        if c["illustrator"] and str(c["illustrator"]).strip().upper() != "N/A":
            facts.insert(0, ["Illustrator", t(c["illustrator"])])
    blocks = []
    for ab in raw.get("abilities") or []:
        blocks.append({"title": f"{t(ab.get('type', 'Ability'))}: {t(ab.get('name'))}", "text": t(ab.get("effect"))})
    for at in raw.get("attacks") or []:
        blocks.append({"title": f"{t(at.get('name'))} {at.get('damage', '')}".strip(), "cost": " ".join(at.get("cost") or []), "text": t(at.get("effect"))})
    if raw.get("effect"):
        blocks.append({"title": "", "text": t(raw["effect"])})
    extras = []
    for lab, key in (("Weakness", "weaknesses"), ("Resistance", "resistances")):
        if raw.get(key):
            extras.append([lab, ", ".join(f"{x.get('type')} {t(x.get('value', ''))}" for x in raw[key])])
    if raw.get("retreat") is not None:
        extras.append(["Retreat", str(raw["retreat"])])
    tcg = (c["tcg_id"] if "tcg_id" in keys else None) or ""
    kind = (c["price_kind"] if "price_kind" in keys else None) or ""
    from ..webapi.cards import _no_price_why
    why = "" if c["price_usd"] is not None else _no_price_why(type("G", (), {"game": db.g})(), c)
    from ..webapi.cards import panel_extras
    pics = {}

    def img(i, _sid):                                       # (a picture of another cover / release of the same item: from its own row, as the engine's img() gives it)
        if i not in pics:
            r = conn.execute("SELECT image_base FROM cards WHERE id=?", (i,)).fetchone()
            pics[i] = _img(db, r[0] if r else "")
        return pics[i]
    conn.row_factory = sqlite3.Row
    try:
        extras_panel = panel_extras(conn, db.game, cid, raw, c["set_id"], c["local_id"], img)
    finally:
        conn.row_factory = None
    return {"game": db.game, "cv": db.cv, "pv": db.pv,
            "id": cid, "name": t(c["name"]), "setId": c["set_id"], "set": c["set_name"] or c["set_id"], "number": number, "rarity": c["rarity"] or "",
            "img": _img(db, c["image_base"]), "imgHigh": _img_high(db, c["image_base"]), "imgNote": raw.get("image_note") or "", "tcg": tcg, "facts": facts, "blocks": blocks, "extras": extras,
            "description": t(c["description"]), "priceUsd": c["price_usd"], "priceKind": kind, "priceMain": c["price_usd"], "priceMainKind": kind, "priceEur": c["price_eur"],
            "priceUpdated": c["price_updated"], "noPriceWhy": why, "variants": _variants(c["variants"], c["rarity"]) + ["Other"],
            "sources": provenance.for_card(conn, cid), "legality": legality.for_card(conn, cid), "printRun": pullrates.print_run(db.game, c["set_id"], t(c["name"])),
            "msrp": msrp.lookup(conn, [cid]).get(cid), "one": bool(c["one_source"]) if "one_source" in keys else False, **extras_panel,
            "shop": shoplinks.for_item(t(c["name"]), c["set_name"] or "", number, tcg, raw), "sell": selllinks.for_item(db.game, t(c["name"]), c["set_name"] or "", number)}


def _img_high(db, base):
    from ..db import picture_url
    if not base:
        return ""
    return picture_url(base, "high") if db.pokemon else base


class BuildDb:
    """A db being built (build.py), seen as handlers see a Db."""

    def __init__(self, conn, g, cv, pv):
        from .. import fuzzy
        self._c, self.g, self.game, self.cv, self.pv, self.pokemon = conn, g, g.id, cv, pv, bool(g.pokemon)
        self._vocab = fuzzy.Vocab(dict(conn.execute("SELECT w, n FROM vocab")))

    def conn(self):
        return self._c

    def vocab(self):
        return self._vocab


FIRST_KEYS = "abcdefghijklmnopqrstuvwxyz0123456789"


def first_keys(db):
    """[(answers key, JSON)] of the first page of a search for each single letter / digit: the first key typed is the biggest answer (Magic: 'l' = 87,000 cards) and the most asked."""
    out = []
    for ch in FIRST_KEYS:
        args, qs = canon.canonical("search", [("q", ch)])
        out.append((f"page|search|{qs}", _json(search(db, args)).decode("utf-8")))
    return out


def facts(db, args):
    """The whole list's facts (facts.py) - the same file for everyone; the device joins it with what is yours.  (answer() sends Db.facts_bytes(), made once per db.)"""
    from . import facts as _facts
    return _facts.make(db.conn(), db.game, db.cv, db.pv)


def match(db, args):
    """The ids of every card of the game's own filters (f.<facet>=<value>; at least one), in the default order: the device narrows YOUR cards with them, on the device."""
    fs = args.get("facets") or {}
    if not fs:
        raise Answer(400, "choose a filter")
    return {"game": db.game, "cv": db.cv, "pv": db.pv, "ids": _Q(db.conn(), db.pokemon, {}, "default", fs).ids(-1, 0)}


HANDLERS = {"set": set_page, "search": search, "sets": sets, "filters": filters, "card": card, "facts": facts, "match": match}
# every argument a handler can be given (the parity test checks no owned ids / counts / collection argument can ever reach one)
ACCEPTS = {route: sorted(spec) + (["f.<facet>"] if route in canon.FACETS_ON else []) for route, spec in canon.PARAMS.items()}


# ---------------------------------------------------------------------------------------------------------------- the store of dbs and the HTTP answer
class Store:
    """The query dbs in one folder: <root>/<game>/<cv>.<pv>.db, and which is current per game (<root>/manifest.json when there, else the newest file).  refresh() looks again."""

    def __init__(self, root):
        self.root = root
        self.dbs, self.current, self._mbody = {}, {}, None
        self._lock = threading.Lock()
        self.refresh()

    def refresh(self):
        found, current = {}, {}
        try:
            games = sorted(os.listdir(self.root))
        except OSError:
            games = []
        for g in games:
            d = os.path.join(self.root, g)
            if not os.path.isdir(d):
                continue
            for f in sorted(os.listdir(d), key=lambda f: os.path.getmtime(os.path.join(d, f))):
                m = re.fullmatch(r"([0-9a-f]{10})\.(\d{8})\.db", f)
                if not m:
                    continue
                key = (g, m.group(1), m.group(2))
                db = self.dbs.get(key)
                if db is None:
                    try:
                        db = Db(os.path.join(d, f))
                    except (ValueError, KeyError, sqlite3.Error):
                        continue
                    if (db.game, db.cv, db.pv) != key:
                        continue
                found[key] = db
                current[g] = key                                   # (the newest file, unless the manifest names another)
        try:
            with open(os.path.join(self.root, "manifest.json"), encoding="utf-8") as f:
                for g, e in (json.load(f).get("games") or {}).items():
                    if (g, e.get("cv"), e.get("pv")) in found:
                        current[g] = (g, e["cv"], e["pv"])
        except (OSError, ValueError, AttributeError):
            pass
        with self._lock:
            self.dbs, self.current, self._mbody = found, current, None
        return self

    def get(self, game, cv, pv=None):
        """The db of (game, cv, pv); with pv None (the routes that do not depend on prices: sets, filters) the current one of that list, else any of that list."""
        dbs = self.dbs
        if pv is not None:
            return dbs.get((game, cv, pv))
        cur = self.current.get(game)
        if cur and cur[1] == cv:
            return dbs[cur]
        return next((db for (g, c, _p), db in sorted(dbs.items(), reverse=True) if g == game and c == cv), None)

    def manifest(self):
        games = {}
        for g, key in sorted(self.current.items()):
            db = self.dbs[key]
            games[g] = {"cv": db.cv, "pv": db.pv, "cards": db.cards, "built": db.meta.get("q_built", "")}
        return {"v": build.QUERY_V, "games": games, "search": None}


def _json(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _headers(cache, etag=None):
    h = [("Content-Type", "application/json; charset=utf-8"), ("Cache-Control", cache), ("Access-Control-Allow-Origin", "*"),
         ("Cross-Origin-Resource-Policy", "cross-origin"), ("X-Content-Type-Options", "nosniff")]
    if etag:
        h.append(("ETag", etag))
    return h


def _err(status, message):
    return status, _headers("no-store"), _json({"error": message})


def _matches(inm, etag):
    return bool(inm) and (inm.strip() == "*" or etag in [x.strip().removeprefix("W/") for x in inm.split(",")])


def answer(store, path, query="", if_none_match="", method="GET"):
    """One GET of the query API -> (status, [(header, value)], body bytes).  `path` is the URL path as sent (still %-encoded), starting with /q/v1/."""
    if method not in ("GET", "HEAD"):
        return _err(405, "GET only")
    if not path.startswith("/q/v1/"):
        return _err(404, "not found")
    rest = path[len("/q/v1/"):].rstrip("/")
    parts = rest.split("/")
    try:
        pairs = canon.parse_qs(query)
        if parts == ["manifest"]:
            canon.canonical("manifest", pairs)
            body = _json(store.manifest())
            tag = '"m.' + hashlib.sha256(body).hexdigest()[:16] + '"'
            if _matches(if_none_match, tag):
                return 304, _headers("no-cache", tag), b""
            return 200, _headers("no-cache", tag), body
        if len(parts) < 3:
            return _err(404, "not found")
        game, ver, route, ids = parts[0], parts[1], parts[2], parts[3:]
        if route not in HANDLERS:
            return _err(404, "not found")
        cv, _, pv = ver.partition(".")
        needs_pv = route in ("set", "search", "card", "facts", "match")
        if not CV_RE.match(cv) or (needs_pv and not PV_RE.match(pv)) or (not needs_pv and pv):
            return _err(404, "unknown list version (read /q/v1/manifest)")
        if (route in ("set", "card")) != (len(ids) == 1) or len(ids) > 1:
            return _err(404, "not found")
        ident = None
        if ids:
            from urllib.parse import unquote
            ident = unquote(ids[0])
            if not ident or len(ident) > 200:
                return _err(404, "not found")
        args, qs = canon.canonical(route, pairs)
        cpath = f"/q/v1/{game}/{ver}/{route}" + (f"/{canon.seg(ident)}" if ids else "")
        if cpath != path.rstrip("/") or qs != (query or ""):
            loc = cpath + (f"?{qs}" if qs else "")
            return 308, [("Location", loc), ("Cache-Control", IMMUTABLE), ("Access-Control-Allow-Origin", "*"), ("Content-Type", "application/json; charset=utf-8")], _json({"to": loc})
        db = store.get(game, cv, pv if needs_pv else None)
        if db is None:
            return _err(404, "unknown list version (read /q/v1/manifest)")
        tag = canon.etag(cv, pv, REV, cpath + "?" + qs)
        if _matches(if_none_match, tag):
            return 304, _headers(IMMUTABLE, tag), b""
        if route == "facts":
            return 200, _headers(IMMUTABLE, tag), db.facts_bytes()
        kept = db.kept(route, qs) if route == "search" and len(qs) <= 4 else None
        if kept is not None:
            return 200, _headers(IMMUTABLE, tag), kept
        fn = HANDLERS[route]
        out = fn(db, args, ident) if ids else fn(db, args)
        return 200, _headers(IMMUTABLE, tag), _json(out)
    except canon.CanonError as e:
        return _err(400, str(e))
    except Answer as e:
        return _err(e.status, e.message)


# ---------------------------------------------------------------------------------------------------------------- this computer's test server (tools/serve_web.py --prod)
_served = {"store": None, "root": None}


def handle(h, path=None):
    """Answer one GET of /q/v1/... on a BaseHTTPRequestHandler `h` from the query dbs in CEA_QUERY_DIR (<dir>/<game>/<cv>.<pv>.db, as build.build writes them): the hook
    tools/serve_web.py --prod calls, so the website's online reads (ui/src/online) can be tried on this computer.  Card Data itself answers through docs/skycloud/carddata_query.py."""
    from urllib.parse import urlparse
    method = getattr(h, "command", "GET")

    def send(status, headers, body):
        h.send_response(status)
        for k, v in headers:
            h.send_header(k, v)
        h.send_header("Content-Length", str(len(body)))
        h.end_headers()
        if method != "HEAD":
            h.wfile.write(body)
    if method == "OPTIONS":
        return send(204, [("Access-Control-Allow-Origin", "*"), ("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS"), ("Access-Control-Allow-Headers", "If-None-Match")], b"")
    root = os.environ.get("CEA_QUERY_DIR", "")
    if not root or not os.path.isdir(root):
        return send(*_err(503, "no query dbs here (set CEA_QUERY_DIR)"))
    if _served["root"] != root:
        _served["store"], _served["root"] = Store(root), root
    u = urlparse(h.path)
    status, headers, body = answer(_served["store"], u.path, u.query, h.headers.get("If-None-Match", "") or "", method)
    return send(status, list(headers) + [("Access-Control-Expose-Headers", "ETag")], body)
