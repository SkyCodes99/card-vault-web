"""Builds a game's query db from its published card list (lane Q, docs/speed136_web_design.md 3.2).

    query/<game>/<cv>.<pv>.db      cv = first 10 hex of the SHA-256 of the published <game>.db.gz (a new list = a new cv = new URLs)
                                   pv = the price day of the prices inside, YYYYMMDD (a new price day = a new pv = new URLs)

What is inside: the card list as published (minus the class cache, which only the engine uses), plus
  slim     the columns the filters read (findfast.WANTED), each card's folded name (fname / nname, for ranking exact names first)
           and its place in EVERY sort order the Cards page offers (dpos = the default order, pos_<sort> for the others).  The places are worked out here, once, by the engine's own ORDER BY
           (Vault._query_cards_sql) - so a filtered page is "the matching cards in pos order", which is exactly the engine's order, and a page of 60 never sorts the whole list.
  slim_fts / slim_afts  trigram indexes of the folded words / folded artist (a typed word of 3+ letters finds its cards without reading the list: the same cards as LIKE '%word%')
  answers  the whole list's filters (cards.filters), worked out once here; and 'facts' - the facts file the website downloads whole (facts.py, lane O2: /q/v1/<game>/<cv>.<pv>/facts)
  facts_groups  Pokemon: each card's eras and section heading from the engine's card index (into the facts file)
  vocab    the name words with how many names use each (typo tolerance, cardvault/fuzzy.py), so a server does not count them at start.
  meta     q_game, q_cv, q_pv, q_cards, q_built, q_v (this builder's version), plus the list's own meta.
Nothing from any collection is ever read or written here."""
import gzip
import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
import time

QUERY_V = 1                                      # this builder's layout: a handler that needs a new column bumps it (a db of an older layout is refused by handlers.Store)
DROP_TABLES = ("class_cache", "sealed_products", "barcodes")       # (the engine's baked card groups, sealed products, shop barcodes: no query reads them yet - a few MB of a db that is published)
DROP_INDEXES = ("cards_name", "cards_tcg", "cards_rarity", "cards_category", "cards_types", "cards_nofold", "cards_nodex", "cards_name_en", "cards_name_ja", "cards_ebay", "cards_custom")   # (the device's own look-ups; the queries read slim)


def list_version(path):
    """cv: the first 10 hex of the SHA-256 of the published list file (the .db.gz exactly as published)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:10]


def price_day(conn):
    """pv: the day of the prices in this list, YYYYMMDD ('00000000' for a list without prices)."""
    day = ""
    try:
        r = conn.execute("SELECT value FROM meta WHERE key='prices_updated'").fetchone()
        day = (r[0] if r else "") or ""
    except sqlite3.Error:
        pass
    if not day:
        try:
            day = conn.execute("SELECT MAX(price_updated) FROM cards").fetchone()[0] or ""
        except sqlite3.Error:
            day = ""
    digits = "".join(ch for ch in str(day)[:10] if ch.isdigit())
    return digits[:8] if len(digits) >= 8 else "00000000"


class _Engine:
    """Just enough of a Vault for the engine's own SQL builder (Vault._query_cards_sql) to run on a query db: the list is folded (cardvault/searchfold.py), nobody is signed in, nothing is owned."""

    def __init__(self, conn, has_era, has_pop):
        self.conn, self._era, self._pop = conn, has_era, has_pop

    def _fold_use(self):
        return True

    def _own_exists(self):
        return ("0", [])                         # (only 'owned' questions use it - never asked here)

    def _has_era(self):
        return self._era

    def _has_pop(self):
        return self._pop


def engine_sql():
    from ..db import Vault
    return Vault._query_cards_sql


def _columns(conn, table):
    return [r[1] for r in conn.execute(f"PRAGMA main.table_info({table})")]


def _register(conn):
    from .. import searchfold
    conn.create_function("fold", 1, searchfold.fold, deterministic=True)


def sorts():
    from .. import findfast
    return findfast.SORTS


def build(src, out_dir, game, cv=None, prices=None, gz=False, log=print):
    """Make out_dir/<game>/<cv>.<pv>.db (and .db.gz with gz=True) from `src` (the published <game>.db.gz, or a plain .db).  `prices` = a day's price file of Card Data
    ({"built", "items"}, /prices/<game>.json.gz) applied first, as the device's daily price update does (dailyprices.apply).  -> {game, cv, pv, cards, path, gz, bytes, gz_bytes, seconds}"""
    from .. import findfast, fuzzy, searchfold
    t0 = time.time()
    cv = cv or list_version(src)
    work = tempfile.mkdtemp(prefix="cv_qbuild_")
    try:
        gdir = os.path.join(work, "games", game)
        os.makedirs(gdir)
        db = os.path.join(gdir, "cards.db")
        if src.endswith(".gz"):
            with gzip.open(src) as a, open(db, "wb") as b:
                shutil.copyfileobj(a, b, 1 << 20)
        else:
            c0 = sqlite3.connect("file:" + src.replace("\\", "/") + "?mode=ro", uri=True)
            try:
                c0.execute("VACUUM INTO ?", (db,))
            finally:
                c0.close()
        if prices:
            from .. import dailyprices
            dailyprices.apply(gdir, prices)
        from ..db import Vault
        from .. import games
        from . import facts
        g = next((x for x in games.GAMES if x.id == game), None)
        if g is None:
            raise RuntimeError(f"unknown game {game}")
        v = Vault(work, game)                    # opened once as a device opens it: every fix-up made on opening a list (placeholder listing prices cleared, folded words, names ...) is made
        try:                                     # here too, so the answers are the device's (a scratch folder: its empty collection is thrown away with it)
            v.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            groups = facts.card_groups(v, g)     # (Pokemon: each card's eras and section heading, from the engine's card index - the facts file carries them, facts.py)
        finally:
            v.close()
        conn = sqlite3.connect(db)
        try:
            conn.execute("PRAGMA journal_mode=OFF")
            conn.execute("PRAGMA synchronous=OFF")
            _register(conn)
            for t in DROP_TABLES:
                conn.execute(f"DROP TABLE IF EXISTS {t}")
            for i in DROP_INDEXES:
                conn.execute(f"DROP INDEX IF EXISTS {i}")
            if not searchfold.complete(conn):
                searchfold.fill(conn)
            pv = price_day(conn)
            have = _columns(conn, "cards")
            cols = [c for c in findfast.WANTED if c in have]
            if "fold" not in cols:
                raise RuntimeError("the card list has no folded search words")
            nsql = fuzzy.norm_sql("f")
            conn.execute("DROP TABLE IF EXISTS slim")
            pos = ["dpos"] + [f"pos_{s}" for s in sorts() if s != "default"]
            types = {r[1]: r[2] for r in conn.execute("PRAGMA main.table_info(cards)")}
            ifold = "fold(illustrator)" if "illustrator" in cols else "NULL"          # (the artist filter's fold(c.illustrator), worked out once: handlers._fast reads it instead)
            conn.execute(f"CREATE TABLE slim(rid INTEGER PRIMARY KEY, {', '.join(c + ' ' + (types.get(c) or '') for c in cols)}, fname TEXT, nname TEXT, ifold TEXT, {', '.join(p + ' INTEGER' for p in pos)})")
            conn.execute(f"INSERT INTO slim({', '.join(cols)}, fname, nname, ifold) SELECT {', '.join(cols)}, f, {nsql}, {ifold} FROM (SELECT {', '.join(cols)}, fold(name) AS f FROM cards ORDER BY rowid)")
            conn.execute("CREATE UNIQUE INDEX slim_id ON slim(id)")
            conn.execute("CREATE INDEX slim_fname ON slim(fname)")                 # (names that start with the words typed: handlers._Q's first part of a ranked page)
            conn.execute("CREATE INDEX slim_nname ON slim(nname)")
            conn.execute("CREATE VIRTUAL TABLE slim_fts USING fts5(fold, content='slim', content_rowid='rid', tokenize='trigram', detail=none)")      # (a typed word of 3+ letters: its cards from the index, not from reading every card)
            conn.execute("INSERT INTO slim_fts(slim_fts) VALUES('rebuild')")
            conn.execute("CREATE VIRTUAL TABLE slim_afts USING fts5(ifold, content='slim', content_rowid='rid', tokenize='trigram', detail=none)")    # (the same for the artist filter)
            conn.execute("INSERT INTO slim_afts(slim_afts) VALUES('rebuild')")
            conn.execute(f"CREATE TEMP VIEW {findfast.TABLE.split('.')[-1]} AS SELECT * FROM main.slim")      # (the engine's SQL reads temp.cv_slim: here it is the slim table)
            eng = _Engine(conn, "era_hint" in have, "popularity" in have)
            run = engine_sql()
            for s in sorts():
                col = "dpos" if s == "default" else f"pos_{s}"
                ids = [r[0] for r in run(eng, sort=s, ids_only="order")]          # the engine's own ORDER BY for this sort (ending in c.id: one order, no ties)
                conn.executemany(f"UPDATE slim SET {col}=? WHERE id=?", ((i, cid) for i, cid in enumerate(ids)))
            conn.execute("DROP VIEW temp.cv_slim")
            for p in pos:
                conn.execute(f"CREATE INDEX slim_{p} ON slim({p})")
            conn.execute("CREATE INDEX slim_set ON slim(set_id, dpos)")
            conn.execute("CREATE INDEX slim_scan ON slim(rarity, fold, set_id)")         # (a short typed word reads every card: this narrow copy instead of the rows, rarities counted in order)
            counts = {}
            for col in ("name", "name_en"):
                if col in have:
                    fuzzy.count_words((r[0] for r in conn.execute(f"SELECT DISTINCT {col} FROM main.cards")), counts)
            conn.execute("DROP TABLE IF EXISTS vocab")
            conn.execute("CREATE TABLE vocab(w TEXT PRIMARY KEY, n INTEGER) WITHOUT ROWID")
            conn.executemany("INSERT INTO vocab VALUES(?,?)", counts.items())
            from . import handlers
            if groups:
                facts.save_groups(conn, groups)
            conn.execute("DROP TABLE IF EXISTS answers")
            conn.execute("CREATE TABLE answers(k TEXT PRIMARY KEY, v TEXT) WITHOUT ROWID")
            conn.execute("INSERT INTO answers VALUES('rar', ?)", (json.dumps(conn.execute("SELECT rarity, COUNT(*) FROM slim GROUP BY rarity").fetchall()),))      # (the whole list's rarities: a question with no filter at all)
            for ed in ((None, "tcg", "pocket") if g.pokemon else (None,)):
                conn.execute("INSERT INTO answers VALUES(?,?)", (handlers.filters_key("", ed), json.dumps(handlers.filters_for(conn, g, "", ed), ensure_ascii=False, separators=(",", ":"))))
            n = conn.execute("SELECT COUNT(*) FROM slim").fetchone()[0]
            conn.commit()
            conn.execute("ANALYZE")
            for k, v in handlers.first_keys(handlers.BuildDb(conn, g, cv, pv)):          # the first key typed ('l': 80% of Magic) - the slowest question there is - answered once, here
                conn.execute("INSERT OR REPLACE INTO answers VALUES(?,?)", (k, v))
            fbody = facts.make_bytes(conn, game, cv, pv)                                    # the facts file (facts.py), made once here: the server only reads it
            conn.execute("INSERT OR REPLACE INTO answers VALUES('facts', ?)", (fbody.decode("utf-8"),))
            fsize = {"facts_bytes": len(fbody), "facts_gz_bytes": len(gzip.compress(fbody, 6))}
            del fbody
            built = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            conn.executemany("INSERT OR REPLACE INTO meta VALUES(?,?)", [("q_game", game), ("q_cv", cv), ("q_pv", pv), ("q_cards", str(n)), ("q_built", built), ("q_v", str(QUERY_V))])
            conn.commit()
            dest_dir = os.path.join(out_dir, game)
            os.makedirs(dest_dir, exist_ok=True)
            out = os.path.join(dest_dir, f"{cv}.{pv}.db")
            part = out + ".part"
            if os.path.exists(part):
                os.remove(part)
            conn.execute("VACUUM INTO ?", (part,))
        finally:
            conn.close()
        os.replace(part, out)
        info = {"game": game, "cv": cv, "pv": pv, "cards": n, "built": built, "path": out, "bytes": os.path.getsize(out), "gz": "", "gz_bytes": 0, **fsize}
        if gz:
            with open(out, "rb") as a, open(out + ".gz.part", "wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=6, mtime=0) as b:
                shutil.copyfileobj(a, b, 1 << 20)
            os.replace(out + ".gz.part", out + ".gz")
            info["gz"], info["gz_bytes"] = out + ".gz", os.path.getsize(out + ".gz")
        info["seconds"] = round(time.time() - t0, 1)
        if log:
            log(f"  query db {game}: {n:,} cards, cv {cv}, pv {pv}, {info['bytes'] / 1048576:.1f} MB" + (f" ({info['gz_bytes'] / 1048576:.1f} MB gz)" if gz else "") + f", {info['seconds']} s"
                + f"; facts file {info['facts_gz_bytes'] / 1048576:.2f} MB gz")
        return info
    finally:
        shutil.rmtree(work, ignore_errors=True)


def manifest(entries, search=None):
    """The /q/v1 manifest: {"v", "built", "games": {game: {cv, pv, cards, built}}, "search": {...} or None} from build() results."""
    return {"v": QUERY_V, "built": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "games": {e["game"]: {"cv": e["cv"], "pv": e["pv"], "cards": e["cards"], "built": e["built"]} for e in entries}, "search": search}


def write_manifest(out_dir, entries, search=None):
    path = os.path.join(out_dir, "manifest.json")
    with open(path + ".part", "w", encoding="utf-8") as f:
        json.dump(manifest(entries, search), f, separators=(",", ":"))
    os.replace(path + ".part", path)
    return path
