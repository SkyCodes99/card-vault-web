"""Card Data query API (3.50.136 web speed, lane Q; docs/speed136_web_design.md section 3.2).

The website asks Card Data small questions ("this set's cards, page 2", "search 'bolt', sorted by price") instead of downloading a whole card list.  This package is the whole of it:

  build.py     one game's published card list -> an indexed SQLite query db (query/<game>/<cv>.<pv>.db): the list itself plus a slim table with every card's place in every sort order
  canon.py     the one canonical form of every question (sorted parameters, defaults dropped) -> immutable URLs and ETags; anything else is refused or redirected
  handlers.py  the answers, as paged JSON, from a read-only connection: pure functions (conn, args) -> dict; answer() turns a GET into (status, headers, body)

Catalog only.  No handler accepts owned ids, counts, portfolios, wishlists or anything else from a collection (tests/test_query_api.py checks every parameter list): the server never learns
what anyone owns.  The filters are the engine's own SQL builder (Vault._query_cards_sql) and the orders are the engine's own ORDER BY, worked out once at build time - so an answer here is the
same ids in the same order as the engine's cards.list on the device."""
