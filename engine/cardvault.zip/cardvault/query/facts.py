"""A game's card FACTS: one small file per list version and price day, the whole list's catalog fields the website needs to show what is YOURS (3.50.136 lane O2).

The website does not keep a game's whole card list on the device ("Keep for offline use" off, lane P).  Card Data's pages answer searches and set pages, but the whole-list views of your own
cards (owned, wishlist, spares, missing, the owned-first orders, sections, eras, 'Stored in') cannot be asked of a server without telling it what you own.  So the device downloads the WHOLE
facts file of the open game (the same file for everyone: /q/v1/<game>/<cv>.<pv>/facts, immutable) and joins it with the collection itself (cardvault/webapi/onlinefacts.py), with the
engine's own SQL (Vault._query_cards_sql) - nothing about anyone's collection ever leaves the device.

What is in it, per card (columns, in the list's default order): the columns the engine's filters and sorts read (findfast.WANTED; the folded search words only where they are not the
plain fold of name, number, illustrator and rarity - the device folds those itself with searchfold.words), the tile fields (picture, price kind, TCGplayer id, 'one source'), and for
Pokemon the card's eras and its section heading (the engine's card index, worked out here once: build.py).  Plus the sets, and the maker's retail prices (msrp) where the list has them."""
import json
import sqlite3

V = 1                                          # this file's layout (onlinefacts.py refuses another)
CARD_COLS = ("id", "set_id", "local_id", "sort_key", "name", "rarity", "types", "illustrator", "price_usd", "price_kind", "tcg_id", "dex", "era_hint", "category", "popularity",
             "color_key", "image_base", "one_source", "name_en")
SET_COLS = ("id", "name", "serie", "release_date", "official", "total", "fold")
MSRP_COLS = ("card_id", "amount", "currency", "source", "ref", "day")
GROUPS_TABLE = "facts_groups"                  # (build.py: card id -> its eras and section heading, Pokemon only - the engine's card index is not in the query db)


def card_groups(v, g):
    """{card id: (eras 'a,b', section heading)} from an open Vault's card index (Pokemon lists; other games file sections under the rarity and have no eras)."""
    if not g.pokemon:
        return {}
    from .. import taxonomy
    idx = v.card_index()
    eras = {}
    for grp in taxonomy.groups():
        if grp.parent == "era":
            for cid in v.group_ids(grp.id):
                eras.setdefault(cid, []).append(grp.id)
    return {c["id"]: (",".join(eras.get(c["id"], ())), taxonomy.card_rarity_label(c, c.get("groups"))) for c in idx}


def save_groups(conn, groups):
    conn.execute(f"DROP TABLE IF EXISTS {GROUPS_TABLE}")
    conn.execute(f"CREATE TABLE {GROUPS_TABLE}(id TEXT PRIMARY KEY, era TEXT, label TEXT) WITHOUT ROWID")
    conn.executemany(f"INSERT INTO {GROUPS_TABLE} VALUES(?,?,?)", ((k, e, lab) for k, (e, lab) in groups.items()))


def _cols(conn, table):
    try:
        return [r[1] for r in conn.execute(f"PRAGMA main.table_info({table})")]
    except sqlite3.Error:
        return []


def make(conn, game, cv, pv):
    """The facts of a query db (build.py's layout) -> {"v", "game", "cv", "pv", "n", "cols", "data": {col: [values]}, "sets": {cols, rows}, "msrp": {cols, rows}}.
    Columnar (one list per column): gzip finds far more alike neighbours (Magic: 2.7 MB instead of 4)."""
    from ..searchfold import words
    have = set(_cols(conn, "cards"))
    cols = [c for c in CARD_COLS if c in have]
    grp = GROUPS_TABLE in {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    sel = ", ".join(f"c.{c}" for c in cols) + ", c.fold" + (", g.era, g.label" if grp else "")
    order = "ORDER BY s.dpos" if "dpos" in _cols(conn, "slim") else "ORDER BY c.rowid"
    sql = f"SELECT {sel} FROM cards c " + ("JOIN slim s ON s.id=c.id " if order.startswith("ORDER BY s.") else "") + (f"LEFT JOIN {GROUPS_TABLE} g ON g.id=c.id " if grp else "") + order
    data = {c: [] for c in cols + ["foldx"] + (["era", "label"] if grp else [])}
    i = {c: n for n, c in enumerate(cols)}
    plain = [i.get(k) for k in ("name", "local_id", "illustrator", "rarity")]
    for r in conn.execute(sql):
        for n, c in enumerate(cols):
            data[c].append(r[n])
        fold = r[len(cols)]
        data["foldx"].append(None if fold == words(*(r[k] if k is not None else None for k in plain)) else fold)
        if grp:
            data["era"].append(r[len(cols) + 1] or "")
            data["label"].append(r[len(cols) + 2] or "")
    for c in list(data):                                     # (a column with nothing in it - no illustrators, no colours - is left out: the device fills it with NULLs)
        if c != "id" and all(x is None for x in data[c]):
            del data[c]
    scols = [c for c in SET_COLS if c in set(_cols(conn, "sets"))]
    sets = {"cols": scols, "rows": [list(r) for r in conn.execute(f"SELECT {', '.join(scols)} FROM sets ORDER BY rowid")]}
    msrp = {"cols": list(MSRP_COLS), "rows": []}
    if set(MSRP_COLS) <= set(_cols(conn, "msrp")):
        msrp["rows"] = [list(r) for r in conn.execute(f"SELECT {', '.join(MSRP_COLS)} FROM msrp")]
    return {"v": V, "game": game, "cv": cv, "pv": pv, "n": len(data["id"]), "cols": list(data), "present": cols, "data": data, "sets": sets, "msrp": msrp}


def make_bytes(conn, game, cv, pv):
    return json.dumps(make(conn, game, cv, pv), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
