"""eBay API License Agreement: an eBay asking price is shown for at most MAX_AGE_HOURS after it was read.  Used by the data refresh (cardvault/ebayprices.expire) AND by the app itself
(cardvault/db.Vault, on open and while open), so a card list that is not refreshed for a while (desktop, website, phone) never shows an older eBay price.  No imports beyond sqlite: it runs in Pyodide."""
import time

MAX_AGE_HOURS = 24


def expire(conn, now=None):
    """Take every eBay price older than MAX_AGE_HOURS off the item (it shows "No price" until a refresh reads it again).  The time is when the price was written (table ask_priced, to the minute),
    else the start of its price day.  The caller commits.  -> prices removed"""
    conn.execute("CREATE TABLE IF NOT EXISTS ask_priced(card_id TEXT PRIMARY KEY, at TEXT NOT NULL)")
    old = ("price_kind LIKE 'eBay%' AND COALESCE((SELECT at FROM ask_priced s WHERE s.card_id=cards.id), price_updated || ' 00:00', '') < strftime('%Y-%m-%d %H:%M', ?, ?)")
    args = (now or "now", f"-{MAX_AGE_HOURS} hours")
    if not conn.execute("SELECT 1 FROM cards WHERE " + old + " LIMIT 1", args).fetchone():
        return 0      # read first: an UPDATE that changes nothing still opens a write transaction and would hold the file locked until the next commit
    return conn.execute("UPDATE cards SET price_usd=NULL, price_kind=NULL, price_updated=NULL WHERE " + old, args).rowcount


CHECK_EVERY = 600     # seconds between checks while the app stays open


def due(last, clock=time.monotonic):
    """Is it time to check again (last = the clock reading of the previous check, None = never)?"""
    return last is None or clock() - last >= CHECK_EVERY
