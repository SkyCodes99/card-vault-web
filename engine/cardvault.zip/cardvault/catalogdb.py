"""The browser build can't spend hours fetching every card one by one, so it downloads a ready-made card list (one file per game, built from the
same sources) instead.  Pictures are never copied: they are shown straight from their web address."""
import gzip
import os
import sqlite3
import time
import urllib.parse

from . import sync

REPLACE_TRIES = 8                  # Windows says 'access denied' while anything (a virus scanner, a background job of ours) still has the old list open: wait a little before giving up
REPLACE_WAIT = 0.5


def _replace(src, dst):
    """os.replace that waits a moment when the file is in use, then lets the error through (the old list is kept)."""
    for attempt in range(REPLACE_TRIES):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if attempt + 1 == REPLACE_TRIES:
                raise
            time.sleep(REPLACE_WAIT)


def url_for(base, game_id, built=""):
    """`built` (the manifest's date for this list) makes a new list a new address: Card Data lets browsers keep a list a day, so without it a list published this morning could arrive tomorrow."""
    url = base.rstrip("/") + f"/{game_id}.db.gz"
    return url + "?b=" + urllib.parse.quote(built, safe="") if built else url


def manifest(base):
    """What the website has published: {"built": ..., "games": {game: {"cards": n, "built": ...}}} (None if it can't be read)."""
    d = sync._get(base.rstrip("/") + "/manifest.json", tries=1)
    return d if isinstance(d, dict) and "games" in d else None


def local_built(gdir):
    try:
        c = sqlite3.connect(os.path.join(gdir, "cards.db"))
        try:
            r = c.execute("SELECT value FROM meta WHERE key='catalog_built'").fetchone()
        finally:
            c.close()
        return r[0] if r else ""
    except sqlite3.Error:
        return ""


def install(gdir, base, game_id, emit, cancel, release=None, built=""):
    """Download <base>/<game>.db.gz and make it this game's card list (kept if anything looks wrong).  -> number of cards.
    `release(swap)`, when given, is what runs the file swap: it lets go of the open collection, calls swap() and opens the collection again, so nothing else can touch it halfway."""
    from .steps import run
    return run(install_steps(gdir, base, game_id, emit, cancel, release, built))


PRICE_BATCH = 5000                  # prices carried over from the old list per step (the browser's engine answers clicks between two)


def install_steps(gdir, base, game_id, emit, cancel, release=None, built=""):
    """install() as steps of a job: it yields between the download, the unpacking, the check and each batch of carried-over prices.  The browser's engine has no threads: in one piece a
    big list (Magic) held every page up for the whole of it; there each step runs at its own moment.  (The download itself is still one blocking request there: the page does not yet fetch binary files for the engine, and Card Data ignores Range requests.)"""
    emit("Downloading the card list…", 0, 0)
    yield                                                    # (the screen that asked gets its answer first: the download starts at the next free moment)
    data = sync._get(url_for(base, game_id, built), as_json=False)
    if not data:
        raise RuntimeError("The card list for this game isn't published yet.")
    if cancel.is_set():
        raise sync.Cancelled()
    emit("Unpacking…", 0, 0)
    yield
    raw = gzip.decompress(data)
    del data
    if not raw.startswith(b"SQLite format 3"):
        raise RuntimeError("The downloaded card list is damaged.")
    os.makedirs(gdir, exist_ok=True)
    tmp = os.path.join(gdir, "cards.db.part")
    with open(tmp, "wb") as f:
        f.write(raw)
    del raw
    yield
    try:
        conn = sqlite3.connect(tmp)
        try:
            n = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
            conn.execute("SELECT id FROM sets LIMIT 1").fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        os.remove(tmp)
        raise RuntimeError("The downloaded card list is damaged.")
    old = os.path.join(gdir, "cards.db")
    if os.path.exists(old):                  # prices the app fetched since the list was published are newer than the list's: keep them
        yield
        try:
            oc = sqlite3.connect(old)
            prices = oc.execute("SELECT id, price_usd, price_updated FROM cards WHERE price_updated IS NOT NULL AND price_usd IS NOT NULL").fetchall()
            oc.close()
        except sqlite3.Error:
            prices = []
        for at in range(0, len(prices), PRICE_BATCH):
            yield
            try:
                nc = sqlite3.connect(tmp)                      # (the new list's own file: nothing else has it open, so it is not kept open across a step)
                try:
                    nc.executemany("UPDATE cards SET price_usd=?, price_updated=? WHERE id=? AND (price_updated IS NULL OR price_updated < ?)", [(p, u, i, u) for i, p, u in prices[at:at + PRICE_BATCH]])
                    nc.commit()
                finally:
                    nc.close()
            except sqlite3.Error:
                break
        yield
    def swap():
        for suffix in ("-wal", "-shm"):
            try:
                os.remove(os.path.join(gdir, "cards.db" + suffix))
            except OSError:
                pass
        _replace(tmp, os.path.join(gdir, "cards.db"))
        for mark in ("prices_built.txt", "subtypes_built2.txt"):          # the new list has the prices / printings of the day IT was made: fetch today's again on top of it
            try:
                os.remove(os.path.join(gdir, mark))
            except OSError:
                pass
    if release:
        release(swap)                   # the open collection still has the old card list (and its journal files) open: the caller lets go of it, runs swap(), and opens it again - whatever happens
    else:
        swap()
    emit("Done", n, n)
    return n
