"""The browser build can't spend hours fetching every card one by one, so it downloads a ready-made card list (one file per game, built from the
same sources) instead.  Pictures are never copied: they are shown straight from their web address."""
import gzip
import os
import sqlite3
import time

from . import sync

REPLACE_TRIES = 8                  # Windows says 'access denied' while anything (a virus scanner, a background job of ours) still has the old list open: wait a little before giving up
REPLACE_WAIT = 0.5


def _replace(src, dst):
    """os.replace that waits a moment when the file is in use, then lets the error through (the old list is kept)."""
    for attempt in range(REPLACE_TRIES):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if attempt + 1 == REPLACE_TRIES:
                raise
            time.sleep(REPLACE_WAIT)


def url_for(base, game_id):
    return base.rstrip("/") + f"/{game_id}.db.gz"


def manifest(base):
    """What the website has published: {"built": ..., "games": {game: {"cards": n, "built": ...}}} (None if it can't be read)."""
    d = sync._get(base.rstrip("/") + "/manifest.json", tries=1)
    return d if isinstance(d, dict) and "games" in d else None


def local_built(gdir):
    try:
        c = sqlite3.connect(os.path.join(gdir, "cards.db"))
        try:
            r = c.execute("SELECT value FROM meta WHERE key='catalog_built'").fetchone()
        finally:
            c.close()
        return r[0] if r else ""
    except sqlite3.Error:
        return ""


def install(gdir, base, game_id, emit, cancel, release=None):
    """Download <base>/<game>.db.gz and make it this game's card list (kept if anything looks wrong).  -> number of cards.
    `release(swap)`, when given, is what runs the file swap: it lets go of the open collection, calls swap() and opens the collection again, so nothing else can touch it halfway."""
    emit("Downloading the card list…", 0, 0)
    data = sync._get(url_for(base, game_id), as_json=False)
    if not data:
        raise RuntimeError("The card list for this game isn't published yet.")
    if cancel.is_set():
        raise sync.Cancelled()
    emit("Unpacking…", 0, 0)
    raw = gzip.decompress(data)
    if not raw.startswith(b"SQLite format 3"):
        raise RuntimeError("The downloaded card list is damaged.")
    os.makedirs(gdir, exist_ok=True)
    tmp = os.path.join(gdir, "cards.db.part")
    with open(tmp, "wb") as f:
        f.write(raw)
    try:
        conn = sqlite3.connect(tmp)
        try:
            n = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
            conn.execute("SELECT id FROM sets LIMIT 1").fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        os.remove(tmp)
        raise RuntimeError("The downloaded card list is damaged.")
    old = os.path.join(gdir, "cards.db")
    if os.path.exists(old):                  # prices the app fetched since the list was published are newer than the list's: keep them
        try:
            oc = sqlite3.connect(old)
            prices = oc.execute("SELECT id, price_usd, price_updated FROM cards WHERE price_updated IS NOT NULL AND price_usd IS NOT NULL").fetchall()
            oc.close()
            nc = sqlite3.connect(tmp)
            nc.executemany("UPDATE cards SET price_usd=?, price_updated=? WHERE id=? AND (price_updated IS NULL OR price_updated < ?)", [(p, u, i, u) for i, p, u in prices])
            nc.commit()
            nc.close()
        except sqlite3.Error:
            pass
    def swap():
        for suffix in ("-wal", "-shm"):
            try:
                os.remove(os.path.join(gdir, "cards.db" + suffix))
            except OSError:
                pass
        _replace(tmp, os.path.join(gdir, "cards.db"))
        for mark in ("prices_built.txt", "subtypes_built2.txt"):          # the new list has the prices / printings of the day IT was made: fetch today's again on top of it
            try:
                os.remove(os.path.join(gdir, mark))
            except OSError:
                pass
    if release:
        release(swap)                   # the open collection still has the old card list (and its journal files) open: the caller lets go of it, runs swap(), and opens it again - whatever happens
    else:
        swap()
    emit("Done", n, n)
    return n
