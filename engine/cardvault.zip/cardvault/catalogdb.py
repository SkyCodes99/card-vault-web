"""The browser build can't spend hours fetching every card one by one, so it downloads a ready-made card list (one file per game, built from the
same sources) instead.  Pictures are never copied: they are shown straight from their web address."""
import gzip
import os
import sqlite3

from . import sync


def url_for(base, game_id):
    return base.rstrip("/") + f"/{game_id}.db.gz"


def install(gdir, base, game_id, emit, cancel, release=None):
    """Download <base>/<game>.db.gz and make it this game's card list (kept if anything looks wrong).  -> number of cards."""
    emit("Downloading the card list…", 0, 0)
    data = sync._get(url_for(base, game_id), as_json=False)
    if not data:
        raise RuntimeError("The card list for this game isn't published yet.")
    if cancel.is_set():
        raise sync.Cancelled()
    emit("Unpacking…", 0, 0)
    raw = gzip.decompress(data)
    if not raw.startswith(b"SQLite format 3"):
        raise RuntimeError("The downloaded card list is damaged.")
    os.makedirs(gdir, exist_ok=True)
    tmp = os.path.join(gdir, "cards.db.part")
    with open(tmp, "wb") as f:
        f.write(raw)
    try:
        conn = sqlite3.connect(tmp)
        try:
            n = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
            conn.execute("SELECT id FROM sets LIMIT 1").fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        os.remove(tmp)
        raise RuntimeError("The downloaded card list is damaged.")
    if release:
        release()                       # the open collection still has the old card list (and its journal files) open: let go of them first
    for suffix in ("-wal", "-shm"):
        try:
            os.remove(os.path.join(gdir, "cards.db" + suffix))
        except OSError:
            pass
    os.replace(tmp, os.path.join(gdir, "cards.db"))
    emit("Done", n, n)
    return n
