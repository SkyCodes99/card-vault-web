"""Which fandom a Funko Pop! belongs to, worked out from its name, for the Pops whose tags did not say.

The open Funko list (hobbyDB's, through kennymkchan/funko-pop-data) only knows a Pop's fandom when hobbyDB tagged it ('Pop! Marvel'); about 1,500 Pops have no such tag and used to be piled in one
'Other' fandom, although 'Stormtrooper (Blue)', 'Harley Quinn (Gown)' and 'Paul McCartney' are plainly Star Wars, DC and music.  The rules below name the fandoms the list already has (so a Pop lands next
to its tagged neighbours - Pokemon sits in Games, He-Man in Television, Indiana Jones in Disney, because that is where hobbyDB put theirs) and the characters, titles and words that belong to each.

Only words that mean ONE thing are listed (a Pop called 'Dash' or 'Storm' could be anybody's), and the rules run in order: a name two fandoms claim (a crossover) goes to the first.  A Pop that no
rule recognises stays in 'Other' - a wrong guess is worse than an honest 'don't know'.  Never put a '|' inside a group: the words are split on it.  `tools/audit_funko_fandoms.py` measures the rules
against the Pops that already carry a tag - run it after editing a word list."""
import re

OTHER = "Other"

# (the fandom's set name in the Funko list, the words that say a Pop belongs to it), most specific first.  Words are matched whole and case-insensitively.
_RULES = (
    ("Director", r"director: "),
    ("Funko", r"freddy funko|funko art dept|funko classic|funko original|funko hoodie|funko brand|funko hq|funko ratfink|fun token|funklub|pop! vinyl logo|pop female|popshield|display case|pop! protector|mr\. cupcake|"
              r"feddy funko|bone daddy|ratfink|funko tee|funk-?os"),
    ("WWE", r"hulk hogan|macho man|stone cold|the undertaker|undertaker|andre the giant|ultimate warrior|bret \"hit man\" hart|bret hart|ric flair|rey mysterio|roddy piper|wrestlemania|wwe|zack ryder|the rock vs|becky lynch|kurt angle|brock lesnar|randy orton|roman reigns|seth rollins|daniel bryan|triple h|shawn michaels|goldberg|mankind|big show|batista|chris jericho"),
    ("Star Wars", r"star wars|stormtroopers?|snowtroopers?|sandtroopers?|scarif|boba fett|darth|vader|r2-d2|bb-8|bb-9e|c-3po|c2-b5|chewbacca|mandalorian|yoda|grogu|jedi|sith|princess leia|han solo|luke skywalker|"
                  r"kylo ren|poe dameron|k-2so|cassian andor|jyn erso|ahsoka|obi-wan|anakin|padm[eé]|jabba|lando calrissian|bib fortuna|dengar|boushh|bossk|ig-88|greedo|tusken|ewok|wicket|death star|first order|"
                  r"rancor|sarlacc|porg|the child|tauntaun|admiral ackbar|emperor palpatine|rey and|nien nunb|mon mothma|clone trooper|general grievous|darth maul|count dooku|captain phasma|chewie|saw gerrera|cad bane|rogue one|force awakens|empire strikes back|return of the jedi|crispy yodas"),
    ("Marvel", r"marvel|spider-?man|iron man|iron patriot|tony stark|captain america|captain marvel|hulk|thanos|avengers|wolverine|deadpool|x-men|venom|black panther|black widow|hawkeye|ant-man|doctor strange|"
               r"loki|groot|rocket rac+oo?n|star-lord|gamora|drax|daredevil|punisher|invisible woman|mr\. fantastic|human torch|silver surfer|galactus|ultron|red guardian|infinity gauntlet|she-hulk|"
               r"nick fury|winter soldier|scarlet witch|shang-chi|moon knight|ms\. marvel|thor: |thor \(|\bthor\b|quicksilver|jean grey|cyclops|magneto|mystique|nightcrawler|rogue \(|(?<!queen's )gambit|juggernaut|sentinel|"
               r"fantastic four|guardians of the galaxy|wolverine's|the vision|stan lee|red goblin|green goblin|hobgoblin|lockjaw|civil war"),
    ("Heroes", r"batman|joker|harley quinn|catwoman|the penguin|riddler|poison ivy|batgirl|nightwing|superman|supergirl|wonder woman|aquaman|the flash|green lantern|cyborg|shazam|black adam|green arrow|"
               r"justice league|suicide squad|rick flag|captain boomerang|captain cold|black manta|owlman|killer croc|deadshot|beast boy|starfire|teen titans|swamp thing|john constantine|lex luthor|darkseid|"
               r"doomsday|brainiac|arkham|gotham|dc comics|dc super|dc bombshells|mera\b|martian manhunter|booster gold|blue beetle|hawkman|hawkgirl|zatanna|firestorm|plastic man|bizarro|man-bat|clayface|scarecrow \(batman|(?<!cad )bane|batmobile"),
    ("Disney", r"disney|pixar|mickey(?! mantle)|minnie|donald duck|daisy duck|goofy|scrooge mcduck|chip 'n|chip and dale|stitch|aladdin|jasmine|genie\b|jafar|cinderella|snow white|maleficent|ariel\b|ursula|mulan|pocahontas|"
               r"tiana|rapunzel|moana|elsa(?! mars)|olaf|simba|mufasa|timon|pumbaa|bambi|thumper|dumbo|peter pan|tinker ?bell|captain hook|mad hatter|cheshire cat|winnie the pooh|tigger|eeyore|piglet|cruella|"
               r"baloo|mowgli|kingdom hearts|steamboat willie|gravity falls|dipper pines|mabel pines|bill cipher|grunkle stan|woody(?! boyd)(?! woodpecker)|buzz lightyear|bo peep|lotso|forky|mike wazowski|sulley|lightning mcqueen|"
               r"mr\. incredible|elastigirl|frozone|jack skellington|oogie boogie|vanellope|wreck-it ralph|fix-it felix|frankenweenie|sparkysaurus|evil queen|miguel with|coco: |remy\b|wall-e|nemo\b|dory\b|"
               r"indiana jones|zootopia|judy hopps|alice kingsleigh|through the looking glass"),
    ("Harry Potter", r"harry potter|hermione|ron weasley|dumbledore|snape|hagrid|voldemort|draco malfoy|neville longbottom|luna lovegood|sirius black|dobby|hedwig|quidditch|hogwarts|gryffindor|slytherin|"
                     r"fantastic beasts|newt scamander|grindelwald|gringotts"),
    ("Game of Thrones", r"game of thrones|jon snow|daenerys|tyrion|cersei|jaime lannister|arya stark|sansa|night king|iron throne|lyanna mormont|drogon|jaqen|house of the dragon|lannister|targaryen|ned stark|white walker|rhaegal"),
    ("Games", r"five nights|freddy fazbear|golden freddy|blacklight freddy|foxy\b|chica\b|bonnie\b|springtrap|fnaf|overwatch|tracer\b|fortnite|minecraft|sonic|mega man|dig dug|pac-?man|donkey kong|"
              r"super mario|luigi|zelda|kirby|metroid|fallout|vault boy|assassin's creed|master chief|call of duty|borderlands|mass effect|garrus|silent hill|pyramid head|resident evil|"
              r"street fighter|chun-li|mortal kombat|sub-zero|tekken|final fantasy|cloud strife|sephiroth|league of legends|world of warcraft|starcraft|cyberpunk|geralt|god of war|kratos|"
              r"the last of us|bioshock|skyrim|dragonborn|duke nukem|crash bandicoot|spyro|rayman|sackboy|among us|roblox|animal crossing|splatoon|fall guys|apex legends|valorant|hollow knight|undertale|halo\b|spartan soldier|gears of war|gears pop|"
              r"pokemon|pok[eé]mon|pikachu|pichu|bulbasaur|charmander|squirtle|eevee|jigglypuff|snorlax|cuphead|mugman|king dice"),
    ("Animation", r"rick and morty|toxic morty|mr\. meeseeks|meeseeks|the simpsons|homer simpson|bart simpson|comic book guy|krusty|spongebob|patrick star|squidward|family guy|stewie|south park|cartman|"
                  r"scooby-doo|shaggy|looney tunes|woody woodpecker|bugs bunny|daffy duck|marvin the martian|tweety|sylvester(?! stallone)|wile e|road runner|porky pig|elmer fudd|foghorn|speedy gonzales|hanna-barbera|huckleberry hound|"
                  r"yogi bear|flintstone|gazoo|great grape ape|snagglepuss|pixie and dixie|pixie & dixie|jetsons|powerpuff|samurai jack|adventure time|steven universe|invader zim|zorak|space ghost|dragon ball|goku|"
                  r"vegeta|super saiyan|gohan|piccolo|frieza|naruto|sasuke|kakashi|kaguya|boruto|my hero academia|deku\b|todoroki|bakugo|all might|one piece|luffy|zoro\b|tony tony chopper|sailor moon|"
                  r"attack on titan|demon slayer|tanjiro|jujutsu|yu-gi-oh|bananya|chi chai|monchan|totoro|garfield|"
                  r"snoopy|charlie brown|tokidoki|sanrio|hello kitty|badtz-maru|keroppi|my melody|care bears|smurf|transformers|optimus prime|megatron|bumblebee|g\.i\. joe|destro|storm shadow|"
                  r"angry birds|ben 10|heatblast|my little pony|twilight sparkle|"
                  r"rainbow dash|pinkie pie|fluttershy|applejack|derpy|hey arnold|rugrats|ren & stimpy|ren and stimpy|dexter's laboratory|johnny bravo|bluey|peppa pig|paw patrol|dora the explorer|squanchy|space suit rick|birdperson|poopybutthole|pickle rick|evil morty|rick sanchez|summer smith|beth smith|jerry smith|zim & gir|bender\b|zoidberg|futurama|taz\b|tasmanian devil|crusader rabbit"),
    ("Television", r"stranger things|demogorgon|walking dead|rick grimes|daryl dixon|negan|michonne|doctor who|dalek|tardis|first doctor|tenth doctor|eleventh doctor|twelfth doctor|supernatural|castiel|"
                   r"sam winchester|dean winchester|buffy|big bang theory|sheldon cooper|leonard hofstadter|breaking bad|walter white|jesse pinkman|saul goodman|sons of anarchy|jax teller|outlander|jamie fraser|"
                   r"saved by the bell|jessie spano|zack morris|beth harmon|the boys|homelander|umbrella academy|squid game|ted lasso|power rangers|mighty morphin|zordon|red ranger|green ranger|blue ranger|"
                   r"pink ranger|yellow ranger|black ranger|white ranger|masters of the universe|he-man|skeletor|beast man|teenage mutant|michelangelo|donatello|shredder|april o'neil|"
                   r"muppets|kermit|miss piggy|fozzie|sesame street|elmo|big bird|cookie monster|oscar the grouch|mr\. rogers|"
                   r"bob ross|garbage pail kids|addams family|wednesday addams|gomez addams|munsters|sleestak|land of the lost|star trek|captain kirk|spock\b|jean-luc picard|klingon|the office|dwight schrute|"
                   r"michael scott|parks and rec|ron swanson|schitt's creek|david w/ noodles|alexis rose|moira rose|seinfeld|golden girls|dorothy zbornak|full house|fresh prince|will smith|gilmore girls|lorelai gilmore|rory gilmore|"
                   r"house of cards|dexter morgan|the sopranos|mad men|don draper|pam beesly|jim halpert|andy bernard|kevin malone|creed bratton|angela martin|stanley hudson|jughead|riverdale|ninjor"),
    ("Movies", r"lord of the rings|gandalf|frodo|aragorn|legolas|gimli|gollum|sauron|balrog|the hobbit|bilbo|smaug|thorin|miss peregrine|forrest gump|breakfast at tiffany|holly golightly|jason voorhees|"
               r"freddy krueger|michael myers|leatherface|chucky|pennywise|pinhead|jaws|xenomorph|predator|terminator|robocop|ghostbusters|slimer|stay puft|back to the future|marty mcfly|doc brown|delorean|"
               r"jurassic|velociraptor|e\.t\.|gremlins|gizmo|goonies|ferris bueller|home alone|ready player one|iron giant|godzilla|king kong|john wick|the matrix|mad max|furiosa|top gun|rocky balboa|"
               r"apollo creed|rambo|dark tower|gunslinger|jay and silent bob|dumb and dumber|lloyd christmas|big lebowski|princess bride|inigo montoya|dirty dancing|grease\b|edward scissorhands|"
               r"willy wonka|oompa|napoleon dynamite|twilight saga|edward cullen|hunger games|katniss|narnia|aslan|toothless|shrek|puss in boots|minions|kung fu panda|ice age|trolls|"
               r"frankenstein|bride of frankenstein|dracula|wolfman|creature from the black lagoon|invisible man|nosferatu|wizard of oz|dorothy gale|wicked witch|glinda|"
               r"saturday night live|beetlejuice|casper the friendly ghost"),
    ("Rocks", r"paul mccartney|ringo starr|john lennon|george harrison|the beatles|gerard way|black parade|misfits|gene simmons|paul stanley|ace frehley|peter criss|metallica|james hetfield|iron maiden|"
              r"slayer\b|megadeth|motorhead|lemmy|ozzy osbourne|black sabbath|ac/dc|angus young|guns n' roses|axl rose|nirvana|kurt cobain|foo fighters|dave grohl|green day|blink-182|my chemical romance|"
              r"fall out boy|panic! at the disco|twenty one pilots|paramore|freddie mercury|david bowie|ziggy stardust|michael jackson|madonna|lady gaga|elton john|johnny cash|elvis|bob marley|jimi hendrix|"
              r"janis joplin|jim morrison|pink floyd|led zeppelin|robert plant|rolling stones|mick jagger|ramones|the clash|sex pistols|motley crue|bon jovi|def leppard|van halen|deadmau5|marshmello|"
              r"daft punk|tupac|notorious b\.i\.g|snoop dogg|eminem|run-dmc|beastie boys|wu-tang|beyonc[eé]|taylor swift|bts\b|blackpink|kiss band|rock band|steve aoki"),
    ("NBA", r"larry bird|magic johnson|michael jordan|lebron|kobe bryant|shaquille|giannis|stephen curry|kevin durant|dirk nowitzki|kareem abdul|nba\b"),
    ("NFL", r"drew brees|tom brady|peyton manning|patrick mahomes|aaron rodgers|odell beckham|le'veon bell|saquon|nfl\b"),
    ("MLB", r"edgar martinez|babe ruth|derek jeter|mike trout|aaron judge|shohei|mlb\b|funko baseball"),
    ("Ad Icons", r"franken berry|count chocula|boo berry|tony the tiger|trix rabbit|lucky the leprechaun|cap'n crunch|kool-aid|pillsbury doughboy|mr\. peanut|chester cheetah|energizer bunny|jolly green giant|"
                 r"morton salt|michelin man|the noid|ronald mcdonald|hamburglar|grimace|colonel sanders|mr\. clean|snap, crackle|lucky charms"),
)


def _rule(words):
    """One fandom's words as a single pattern: each word starts and ends on a word edge ('thor' is not 'authority'), except a word that ends in a space or '(' ('Director: ', 'Rogue (') - the
    character after those is the first letter of the name itself."""
    alts = [alt if alt.endswith((" ", "\\(")) else alt + r"(?![a-z0-9])" for alt in words.split("|")]
    return re.compile(r"(?<![a-z0-9])(?:" + "|".join(alts) + ")", re.I)


# Words added on 2026-11-10 after reading the Pops still in 'Other' and checking each word against the Pops that carry a hobbyDB tag (the fandom those neighbours sit in is the one used here).
# `_SETS_FIRST` are fandoms hobbyDB keeps as their own set (Comics, Sanrio, Albums ...): they are tried before the big ones so a Pop lands next to its tagged neighbours.
_SETS_FIRST = (
    ("Comics", r"hellboy|abe sapien"),
    ("Sanrio", r"aggretsuko|chococat"),
    ("Albums", r"hybrid theory|tha carter|news of the world|back in black"),
    ("Books", r"cat in the hat|sam i am"),
    ("Hockey", r"gritty"),
    ("NASCAR", r"dale earnhardt"),
    ("Icons", r"evel knievel"),
    ("Wrestling", r"young bucks"),
)
_MORE = {
    "WWE": r"the new day",
    "Star Wars": r"chirrut imwe|fn-2187|death trooper|moff gideon|ig-11|tc-14|wampa|jawa|tie fighter pilot|x-wing pilot|rebel pilot|rebel alliance|endor|mud trooper|lando in space|luke, han, and leia|snap wexley|join the galactic empire|"
                 r"poe \(blaster|poe \(x-wing|^rey$|mark hamill",
    "Marvel": r"agent carter|crossbones|dark phoenix|ghost rider|yondu|vision|old man logan|red skull|molten man|miles morales|mjolnir|carol danvers|killmonger|vulture|rocket \(with|coulson|eitri|squirrel girl|grandmaster|ragnarok",
    "Heroes": r"deathstroke|katana|robin \(|^robin$|bombshells|captain atom",
    "Disney": r"toy story|jack-jack|baymax|lilo|belle \(|^belle$|lumiere|^abu$|^hercules|hades|jiminy cricket|tomorrowland|haunted mansion|nightmare before christmas|^sally$|snowman jack|jack \(pumpkin|splash mountain|"
              r"halloween donald|kingdom donald|brave little tailor|percy jackson|artemis fowl|baby pegasus|magic lamp|magic mirror",
    "Games": r"commander shepard|raiden \(|ryu \(|scorpion \(|illidan|amumu|peashooter|conehead zombie|swashbuckler zombie|marcus fenix|lolbit|^marionette$|^tali$|growlithe|pirate's cove|i survived 5 nights|^sora$|shadow heartless|"
             r"emerald freddy|shadow freddy|nightmare freddy|vegas freddy|fright night freddy|funtime freddy|freddy's frosty|freddy's funtime|freddy flyers|freddy snapback|^freddy \(|^freddy$",
    "Animation": r"izuku midoriya|eraserhead|tsuyu|mr\. compress|perfect cell|zen-oh|barnacle boy|mermaid ?man|^brak$|bird person|krombopulos|toxic rick|space suit morty|poopy butthole|rick & morty|c-137|^morty$|^rick$|fairy tail|junji ito|"
                 r"fry & leela|tommy and chuckie|dick dastardly|jabberjaw|hardy har har|lippy the lion|mean machine|speed racer|soundwave|danny phantom|bob's burgers|beefsquatch|bebop & rocksteady|negaduck",
    "Television": r"real monsters|ickis|^eleven \(|^eleven$|^dustin \(|^dustin$|^barb$|dolores|westworld|gus fring|howard wolowitz|chandler bing|kaylee frye|ultraman|trollhunters|aaarrrggghh|lion-o|mumm-ra|dragonzord|blanche devereaux|rose nylund|"
                  r"sophia petrillo|alex trebek|orko|elvira|ben \(hargreeves|prison mike|a-team|michael knight with kitt|the arrow|arrow \(|robin sparkles",
    "Movies": r"mary sanderson|winifred sanderson|sarah sanderson|hocus pocus|ramona flowers|scott pilgrim|bruce lee|samwise gamgee|witch king|fast and furious|dom toretto|james bond|clark griswold|harry dunne|ron burgundy|ty webb|fezzik|"
              r"louis tully|zuul|ecto-1|winston zeddemore|jillian holtzmann|matt hooper|great white shark|clever girl|t1000|t-1000|marty checking watch|coraline|agent j\b|alan parrish|eggsy|beetlejuice",
    "Game of Thrones": r"khal drogo|olenna tyrell",
    "NFL": r"joe montana|lawrence taylor|amari cooper",
    "Rocks": r"babymetal|yellow submarine",
}


def _merged():
    first = tuple(_SETS_FIRST)
    rules = list(_RULES[:2])                                # Director + Funko stay on top
    rules += list(first)
    rules += [(f, w + ("|" + _MORE[f] if f in _MORE else "")) for f, w in _RULES[2:]]
    return tuple(rules)


_COMPILED = tuple((fandom, _rule(words)) for fandom, words in _merged())


def fandom_of(name):
    """The fandom set a Pop of this name belongs to, or 'Other' when no rule recognises it."""
    text = (name or "").replace("&amp;", "&")
    for fandom, rule in _COMPILED:
        if rule.search(text):
            return fandom
    return OTHER


def reclassify(conn, put_set):
    """Move the Pops that sit in the 'Other' fandom to the fandom their name says (`put_set(fandom)` gives that fandom's set id, making the set when the list has none).  Run again any time: a Pop
    that no rule recognises stays where it is.  -> how many were moved."""
    moved = 0
    for cid, name in conn.execute("SELECT id, name FROM cards WHERE set_id='fd:other'").fetchall():
        fandom = fandom_of(name)
        if fandom != OTHER:
            conn.execute("UPDATE cards SET set_id=? WHERE id=?", (put_set(fandom), cid))
            moved += 1
    return moved


# ---------------------------------------------------------------------------------------------------- franchise (a finer fandom) + the facet value
# hobbyDB files Yu-Gi-Oh!, Pokemon, Dragon Ball ... under one wide genre ('Animation', 'Games'), so a person browsing "Yu-Gi-Oh!" found nothing.  `franchise_of` names the franchise when the name says so (words that
# mean ONE thing only; the same whole-word matching as above).  A Pop no rule recognises has no franchise: it keeps its genre.
_FRANCHISES = (
    ("Yu-Gi-Oh!", r"yu-gi-oh|yugi|seto kaiba|joey wheeler|dark magician|blue-eyes|exodia|summoned skull|xyz dragon|red-eyes"),
    ("Pokemon", r"pokemon|pok[eé]mon|pikachu|pichu|bulbasaur|charmander|charizard|squirtle|eevee|jigglypuff|snorlax|growlithe|mewtwo|togepi|meowth|psyduck|gengar"),
    ("Dragon Ball", r"dragon ?ball|goku|vegeta|super saiyan|gohan|piccolo|frieza|perfect cell|zen-oh|krillin|majin buu"),
    ("Naruto", r"naruto|sasuke|kakashi|sakura haruno|boruto|itachi"),
    ("My Hero Academia", r"my hero academia|izuku midoriya|deku\b|todoroki|bakugo|all might|eraserhead|tsuyu|mr\. compress"),
    ("One Piece", r"one piece|luffy|zoro\b|tony tony chopper"),
    ("Demon Slayer", r"demon slayer|tanjiro|nezuko|zenitsu|inosuke"),
    ("Sailor Moon", r"sailor moon|sailor v\b|sailor mercury|sailor mars|sailor jupiter|sailor venus|tuxedo mask"),
    ("Attack on Titan", r"attack on titan|eren yeager|levi ackerman|mikasa"),
    ("Fairy Tail", r"fairy tail"),
    ("Five Nights at Freddy's", r"five nights|fnaf|freddy fazbear|golden freddy|springtrap|lolbit|funtime freddy|nightmare freddy|shadow freddy|emerald freddy|vegas freddy|fright night freddy|^freddy \(|^freddy$|^marionette$|pirate's cove|i survived 5 nights|foxy\b"),
    ("Sonic the Hedgehog", r"sonic|silver the hedgehog|dr\. eggman|amy rose|shadow the hedgehog|^tails$|^knuckles$"),
    ("Mario", r"super mario|^mario\b|princess peach|bowser|yoshi\b"),
    ("Zelda", r"zelda"),
    ("Fortnite", r"fortnite|peely|cuddle team leader"),
    ("Minecraft", r"minecraft|enderman"),
    ("Street Fighter", r"street fighter|ryu \(|chun-li|ken masters|guile\b"),
    ("Mortal Kombat", r"mortal kombat|scorpion \(|sub-zero|raiden \(|liu kang"),
    ("Kingdom Hearts", r"kingdom hearts|^sora$|shadow heartless|kingdom donald"),
    ("Plants vs. Zombies", r"plants vs|peashooter|conehead zombie|swashbuckler zombie"),
    ("Rick and Morty", r"rick and morty|rick & morty|mr\. meeseeks|meeseeks|pickle rick|toxic rick|space suit (?:rick|morty)|evil morty|rick sanchez|birdperson|bird person|poopy ?butthole|krombopulos|c-137|squanchy|^morty$|^rick$"),
    ("Teenage Mutant Ninja Turtles", r"teenage mutant|michelangelo|donatello|shredder|april o'neil|bebop & rocksteady|turtle van"),
    ("Stranger Things", r"stranger things|demogorgon|^eleven \(|^eleven$|^dustin \(|^dustin$|^barb$"),
)
_FRANCHISES_COMPILED = tuple((name, _rule(words)) for name, words in _FRANCHISES)


def franchise_of(name, prefix=""):
    """The franchise a Pop's name says ('Dark Magician Girl' -> 'Yu-Gi-Oh!'), or '' when no rule is sure.  `prefix` = the franchise TCGplayer put before the name ('Inuyasha: ...'), kept in ext when the
    name was replaced by the hobbyDB one."""
    text = ((str(prefix) + ": " if prefix else "") + (name or "")).replace("&amp;", "&")
    for franchise, rule in _FRANCHISES_COMPILED:
        if rule.search(text):
            return franchise
    return ""


# hobbyDB tags some Pops by product line, not by fandom ('Funko Mystery Minis', 'Wacky Wobblers', 'Pocket Pop!', 'Dorbz', 'San Diego Comic-Con 2019' ...): those sets say what the figure IS, not what it is FROM.
_LINE_SET = re.compile(r"mystery mini|wacky wobbler|pocket pop|dorbz|hikari|prototype|mymoji|pint size|reaction|rides?$|soda|paka|plush|vynl|8-bit|shirt pack|pint pack|funko-shop|funko-s$|spastik|fantastik|comic-con|"
                       r"comic con|rock candy|art series|articulated|legion of|blind box|pez\b|funkovision|handy dandy|mopeez|peek-a-boo|loungefly|\bpins?\b|mystery box|tees?\b|keychain|deluxe|moments|^town$|^funkoverse|e3 \d{4}|"
                       r"con \d{4}|convention|exclusive|retro freddy|foodies|^funko$|^pop!? ", re.I)


def fandom_for(set_name, name):
    """The fandom to list a Pop under: its set when that set IS a fandom, else the fandom its name says, else Other (a product line such as 'Wacky Wobblers' is not a fandom: audit L6.11)."""
    if not set_name or set_name == OTHER or _LINE_SET.search(set_name):
        return fandom_of(name)
    return set_name
