"""The wishlist as a priced, ordered list: every card with its label (= its priority) and what it costs, grouped by label or by set.
Prices are the ones "Cost to complete" uses (completion.card_costs -> completion.card_price -> the person's price sources): an eBay asking price counts the way it does in every total and is
reported apart (`asked`), never hidden.  A card already owned is shown but costs nothing.  Used by the wishlist page, the friends' view and the public link, so the numbers always match."""
from . import completion, wishlabels

NONE_KEY = ""
SORTS = ("priority", "high", "low")
GROUPS = ("label", "set")


def tally(items):
    """The numbers of a group of wishlist items: count, owned, still to buy, what that costs (the unpriced are counted apart, never guessed), the part of it that is eBay asking prices."""
    todo = [i for i in items if not i["owned"]]
    priced = [i for i in todo if i["price"] is not None]
    return {"count": len(items), "owned": len(items) - len(todo), "todo": len(todo), "cost": round(sum(i["price"] for i in priced), 2), "unpriced": len(todo) - len(priced),
            "asked": round(sum(i["price"] for i in priced if i["ask"]), 2)}


def items_of(svc, v=None):
    """Every wishlist card of the open game: [{id, name, number, set, setId, rarity, tcg, price, ask, kind, exact, owned, label, rank}] in priority order (label order, then set / number)."""
    from .webapi.cards import img
    v = v or svc.vault
    ids = sorted(v.wishlist_ids())
    labels, assign = wishlabels.of_game(svc, v.game)
    order = {x["id"]: n for n, x in enumerate(labels)}
    light, cost = v.card_lights(ids), completion.card_costs(v, ids)
    out, pos = [], {}
    for cid in ids:
        c = light.get(cid)
        if not c:
            continue
        it = cost.get(cid) or {"price": None, "exact": True, "ask": "", "owned": False}
        lid = assign.get(cid) if assign.get(cid) in order else ""
        out.append({"id": cid, "name": c.get("name") or cid, "number": c.get("local_id") or "", "set": c.get("set_name") or "", "setId": c.get("set_id") or "", "rarity": c.get("rarity") or "",
                    "tcg": c.get("tcg_id") or "", "img": img(cid, c.get("set_id") or ""), "price": it["price"], "exact": it["exact"], "ask": bool(it["ask"]), "kind": it["ask"], "owned": it["owned"],
                    "label": lid, "rank": order.get(lid, len(order))})
        pos[cid] = c.get("sort_key") or 0
    out.sort(key=lambda i: (i["rank"], i["set"].lower(), pos[i["id"]], i["name"].lower()))
    return out


def _by_price(items, high):
    """Dearest first (high) or cheapest first; a card without a price is last either way."""
    return sorted(items, key=lambda i: (i["price"] is None, -(i["price"] or 0) if high else (i["price"] or 0), i["name"].lower()))


def arrange(items, sort):
    return _by_price(items, sort == "high") if sort in ("high", "low") else items


def view(svc, group="label", sort="priority"):
    """The whole wishlist page: the labels (priority order) with the cost to finish each, the overall total, and the groups of cards (by label or by set) in the chosen sort."""
    group, sort = group if group in GROUPS else "label", sort if sort in SORTS else "priority"
    items = items_of(svc)
    labels, _a = wishlabels.of_game(svc, svc.vault.game)
    mine = {x["id"]: [] for x in labels}
    free = []
    for i in items:
        (mine[i["label"]] if i["label"] else free).append(i)
    lab_rows = [{"id": x["id"], "name": x["name"], "rank": n, **tally(mine[x["id"]])} for n, x in enumerate(labels)]
    groups = []
    if group == "label":
        groups = [{"key": x["id"], "name": x["name"], **tally(mine[x["id"]]), "items": arrange(mine[x["id"]], sort)} for x in labels if mine[x["id"]]]
        if free:
            groups.append({"key": NONE_KEY, "name": "No label", **tally(free), "items": arrange(free, sort)})
    else:
        by_set = {}
        for i in items:
            by_set.setdefault(i["setId"], []).append(i)
        groups = [{"key": sid, "name": its[0]["set"] or "Other", **tally(its), "items": arrange(its, sort)} for sid, its in by_set.items()]
        if sort == "priority":
            groups.sort(key=lambda g: (min(i["rank"] for i in g["items"]), g["name"].lower()))
        else:
            groups.sort(key=lambda g: ((-g["cost"] if sort == "high" else g["cost"]), g["name"].lower()))
    return {"group": group, "sort": sort, "labels": lab_rows, "free": tally(free), "total": tally(items), "groups": groups}


def label_info(svc):
    """{card id: (label name, priority number from 1)} for the labelled cards of the open game (what a friend or a shared page shows next to a card)."""
    labels, assign = wishlabels.of_game(svc, svc.vault.game)
    at = {x["id"]: (x["name"], n + 1) for n, x in enumerate(labels)}
    return {c: at[lid] for c, lid in assign.items() if lid in at}
