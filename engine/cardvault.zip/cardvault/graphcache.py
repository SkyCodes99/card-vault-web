"""The home page value graph, kept ready.  Working a graph out walks every copy over every day (a big collection: a good part of a second, several in the browser), so the last answer is kept - in
memory and in a small file beside the game's card list - and used again as long as nothing it was built from has changed (the `stamp`).  An entry whose stamp no longer fits is still the last known
graph: it can be shown at once while the new one is worked out (see webapi/valuegraph.py).  Pure storage: nothing here knows what a portfolio or a price is."""
import json
import os
import time

FILE = "value_graph_cache.json"
KEEP = 40                                    # entries kept (the newest): a few portfolios x a few ranges per account
_MEM = {}                                    # file path -> {key: entry}


def _path(v):
    return os.path.join(v.gdir, FILE)


def _load(v):
    p = _path(v)
    if p not in _MEM:
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
            _MEM[p] = data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            _MEM[p] = {}
    return _MEM[p]


def get(v, key):
    """The saved entry {stamp, result, at} for this key, or None."""
    e = _load(v).get(key)
    return e if isinstance(e, dict) and "result" in e else None


def put(v, key, stamp, result):
    box = _load(v)
    box[key] = {"stamp": stamp, "result": result, "at": time.time()}
    for k in sorted(box, key=lambda k: box[k].get("at", 0))[:-KEEP]:
        del box[k]
    p = _path(v)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(box, f, separators=(",", ":"))
        os.replace(tmp, p)
    except OSError:                          # not being able to keep it only means working it out again next time
        pass


def forget(v):
    """Throw everything away (tests; a changed price source)."""
    _MEM.pop(_path(v), None)
    try:
        os.remove(_path(v))
    except OSError:
        pass
