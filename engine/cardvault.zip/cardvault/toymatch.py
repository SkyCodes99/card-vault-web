"""Which toy of a list is the one somebody else's list means?  Names are written differently everywhere ('Barista', 'Limited Edition Barista Chomp Vinyl Figure - ECCC exclusive'), so a pair is
accepted when all the words of one are in the other, or most of them are and the release dates are within three weeks.  Used by the collector's master-list import (tools/import_toy_masterlist.py) and
by the toys read back from the Internet Archive (shoparchive.py) to put a picture on a toy that only the master list knew."""
import datetime
import re

NOISE = {"chomp", "print", "1st", "2nd", "vinyl", "the", "edition", "s", "of"}                      # words that say nothing about WHICH toy it is
SHOP_NOISE = NOISE | {"limited", "figure", "figures", "exclusive", "resin", "licensed", "dumpster", "fire", "chomper"}          # ... and the extra ones a shop's long product title carries
CLOSE_DAYS = 21
GENERIC = {"mystery", "original", "set", "single", "blind", "bag", "chase", "figure", "limited", "exclusive", "edition", "plastic", "frozen", "culture", "7bap", "bucks", "pop", "empire", "temple", "stormy",
           "vault", "hot", "topic", "sdcc", "nycc", "c2e2", "eccc", "dcon", "con", "wonder", "designer", "kid", "robot"}          # a name made of these says nothing about WHICH toy (a shop or a convention is not a name)
COMMON = GENERIC | {"skeleton", "glow", "dark", "mini", "mega", "squishy", "metallic", "glitter", "gold", "silver", "purple", "blue", "red", "green", "orange", "pink", "yellow", "black", "white", "grey",
                    "gray", "brown", "classic", "bigfoot", "handmade", "robots", "hmbr", "by", "x"}          # colours, finishes and a maker's name: two toys can share them and still be two toys


def norm(name, noise=NOISE):
    """The words that identify a toy ('Watermellon Chomper ($25 sticker)' -> watermelon chomper 25 sticker)."""
    low = re.sub(r"\((?:[a-z]{3,9}\.?\s*)?\d{4}\)", " ", (name or "").lower()).replace("chompers", "chomper").replace("watermellon", "watermelon")          # '(Oct 2022)': which of two releases, not part of the name
    return [t for t in re.sub(r"[^a-z0-9 ]+", " ", low).split() if t not in noise]


def to_date(value):
    """A release date written as 'January 4, 2021', 'Jan 4, 2021', 'January 2021' or 2021-01-04 -> datetime.date, or None."""
    s = (value or "").strip()
    for fmt in ("%B %d, %Y", "%b %d, %Y", "%B %Y"):
        try:
            return datetime.datetime.strptime(s[:20], fmt).date()
        except ValueError:
            pass
    if s[:4].isdigit() and len(s) >= 10:
        try:
            return datetime.date.fromisoformat(s[:10])
        except ValueError:
            pass
    return None


def score(words, other_words):
    """How much of `words` is in `other_words` (a word also counts when one begins with the other: mech / mecha, magic / magical)."""
    other = set(other_words)
    hit = sum(1 for t in words if t in other or any(len(t) >= 4 and len(x) >= 4 and (x.startswith(t) or t.startswith(x)) for x in other))
    return hit / max(1, len(words))


def pair_up(wanted, existing, noise=NOISE, days=CLOSE_DAYS, either_way=False, undated_words=0, inside="either"):
    """Pair each of `wanted` ({"name", "date"}) with the entry of `existing` ((id, name, released)) it stands for, every entry used at most once, best pairs first.  `days` is how far apart the release
    dates may be; `either_way` also accepts a short name that is wholly inside a long one (a shop's 'Barista Chomp Vinyl Figure ECCC' for the master list's 'Barista').  A name of at least
    `undated_words` words (0 = never) that is wholly in the other counts without looking at the dates - a resale shop lists a toy years after it came out (an item can carry its own
    "undated_words" instead).  `inside="existing"` accepts only an entry of `existing` whose words are all in the wanted name (a shop's long title for a master-list entry): a master-list entry that
    says MORE than the shop ('Pumpkin Patch Mini' for a shop's 'Pumpkin') is another toy.  -> {index into wanted: id of existing}."""
    scored = []
    known = [(rid, norm(rname, noise), to_date(released)) for rid, rname, released in existing]          # (worked out once, not once per wanted toy)
    for i, it in enumerate(wanted):
        words = norm(it["name"], noise)
        loose = it.get("undated_words", undated_words)
        for rid, other, rd in known:
            close = bool(it.get("date") and rd and abs((rd - it["date"]).days) <= days)
            sc = (score(other, words) if inside == "existing" else max(score(words, other), score(other, words))) if either_way and words and other else score(words, other)
            distinctive = bool(loose) and min(len(words), len(other)) >= loose
            if (sc >= 0.99 and (close or not either_way or distinctive)) or (sc >= 0.5 and close):
                scored.append((sc + (0.4 if close else 0), i, rid))
    pairs, taken = {}, set()
    for sc, i, rid in sorted(scored, reverse=True):
        if i not in pairs and rid not in taken and sc >= 0.9:
            pairs[i] = rid
            taken.add(rid)
    return pairs
