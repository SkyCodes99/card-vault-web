"""Format legality per card (Collect Em All roadmap 'Format legality').

Only the source's own statement is ever stored - a game with no source shows nothing, and a card the source does not
cover gets no row:
    Pokemon (pokemon, pokemon_jp)  TCGdex card detail, field legal {standard, expanded}; kept in the card's raw record   source 'tdx'
    Magic (mtg)                    Scryfall bulk default_cards, field legalities                                        source 'scryfall'
    Yu-Gi-Oh! (yugioh)             YGOPRODeck cardinfo (misc=yes): misc_info tcg_date / ocg_date and banlist_info      source 'ygoprodeck'

Where it goes - one small table in the game's cards.db (the same shape as source_prices):
    card_legality(card_id, format, status, source, day)
    format = the label shown ('Standard', 'Modern', 'TCG', 'OCG' ...); status = legal | restricted | limited | semi-limited | banned.
    A format with no row is one the source does not list the card as legal in.
Refreshed by: sync.py (TCGdex card reads), tools/fetch_free_prices.py (Scryfall and YGOPRODeck, nightly), tools/daily_update.py (Pokemon, from the raw records)."""
import io
import json
import sqlite3

SCHEMA = [
    "CREATE TABLE IF NOT EXISTS card_legality(card_id TEXT NOT NULL, format TEXT NOT NULL, status TEXT NOT NULL, source TEXT NOT NULL, day TEXT, "
    "PRIMARY KEY(card_id, format)) WITHOUT ROWID",
    "CREATE INDEX IF NOT EXISTS card_legality_source ON card_legality(source)",
    "CREATE INDEX IF NOT EXISTS card_legality_format ON card_legality(format, status)",
]
MIN_ROWS = 1000                                        # a real Magic or Yu-Gi-Oh! file has tens of thousands of rows; fewer means a bad download and the old rows stay
FACET_KEY, FACET_LABEL = "legal", "Legal in"
GAME_SOURCE = {"pokemon": "tdx", "pokemon_jp": "tdx", "pokemon_tw": "tdx", "mtg": "scryfall", "yugioh": "ygoprodeck"}
SOURCE_NAMES = {"tdx": ("TCGdex", "https://tcgdex.dev"), "scryfall": ("Scryfall", "https://scryfall.com"), "ygoprodeck": ("YGOPRODeck", "https://ygoprodeck.com"),
                "lorc": ("Lorcast", "https://lorcast.com"), "fabc": ("The FaB Cube", "https://github.com/the-fab-cube/flesh-and-blood-cards")}      # (the last two: cardvault/details)
TDX_FORMATS = (("standard", "Standard"), ("expanded", "Expanded"))
SCRY_STATUSES = ("legal", "restricted", "banned")      # Scryfall's not_legal is no row
SCRY_LABELS = {"standard": "Standard", "pioneer": "Pioneer", "modern": "Modern", "legacy": "Legacy", "vintage": "Vintage", "pauper": "Pauper",
               "commander": "Commander", "brawl": "Brawl", "standardbrawl": "Standard Brawl", "historic": "Historic", "timeless": "Timeless",
               "alchemy": "Alchemy", "penny": "Penny Dreadful", "paupercommander": "Pauper Commander", "oathbreaker": "Oathbreaker",
               "duel": "Duel Commander", "premodern": "Premodern", "predh": "PreDH", "future": "Future", "gladiator": "Gladiator",
               "oldschool": "Old School", "competitivebrawl": "Competitive Brawl"}
YGO_BAN = {"Banned": "banned", "Limited": "limited", "Semi-Limited": "semi-limited"}      # YGOPRODeck's wording -> our status; any other wording is left out
YGO_FORMATS = (("TCG", "tcg_date", "ban_tcg"), ("OCG", "ocg_date", "ban_ocg"))


def ensure(conn):
    for s in SCHEMA:
        conn.execute(s)                                # (single statements: no implicit commit in the middle of a caller's work)


# ---------------------------------------------------------------------------------------------------------------- what each source says
def tdx_rows(card):
    """A TCGdex card detail -> [(format, status)].  Only a true flag is a row; false means not legal (no row)."""
    legal = (card or {}).get("legal")
    if not isinstance(legal, dict):
        return []
    return [(label, "legal") for key, label in TDX_FORMATS if legal.get(key) is True]


def scryfall_legal(legalities):
    """A Scryfall 'legalities' object -> [(format, status)] for legal, restricted and banned."""
    return [(SCRY_LABELS.get(key) or key.replace("_", " ").title(), st) for key, st in (legalities or {}).items() if st in SCRY_STATUSES]


def ygo_statuses(card):
    """A YGOPRODeck card (misc=yes) -> {format: status}.  A format with no release date is left out; a ban wording we do not know is left out."""
    misc = (card.get("misc_info") or [{}])[0] or {}
    ban = card.get("banlist_info") or {}
    out = {}
    for fmt, date_key, ban_key in YGO_FORMATS:
        if not misc.get(date_key):
            continue
        b = ban.get(ban_key)
        if not b:
            out[fmt] = "legal"
        elif b in YGO_BAN:
            out[fmt] = YGO_BAN[b]
    return out


def scryfall_rows(body, day):
    """Scryfall default_cards (jsonl, .gz or plain) -> iterator of (tcgplayer id, format, status, day).  An etched printing keeps its own id, so both are given."""
    from .freeprices import unzip
    for line in io.TextIOWrapper(io.BytesIO(unzip(body)), encoding="utf-8"):
        line = line.strip().rstrip(",")
        if not line.startswith("{"):
            continue
        try:
            c = json.loads(line)
        except ValueError:
            continue
        ids = {str(x) for x in (c.get("tcgplayer_id"), c.get("tcgplayer_etched_id")) if x}
        if not ids:
            continue
        for fmt, st in scryfall_legal(c.get("legalities")):
            for tid in ids:
                yield tid, fmt, st, day


# ---------------------------------------------------------------------------------------------------------------------------- writing
def store_card(conn, card_id, rows, source, day=""):
    """Replace one card's rows from one source.  rows: [(format, status)]."""
    ensure(conn)
    conn.execute("DELETE FROM card_legality WHERE card_id=? AND source=?", (str(card_id), source))
    conn.executemany("INSERT OR REPLACE INTO card_legality(card_id, format, status, source, day) VALUES(?,?,?,?,?)",
                     [(str(card_id), f, st, source, day) for f, st in rows])


def replace_source(conn, source, rows, min_rows=None):
    """rows: [(card_id, format, status, day)].  The source's old rows are replaced only when there are at least min_rows.  -> {rows, cards, written}."""
    ensure(conn)
    min_rows = MIN_ROWS if min_rows is None else min_rows          # (read now, not when this was defined: a test or a tool may change MIN_ROWS)
    out = {}
    for cid, fmt, st, day in rows:
        out[(str(cid), fmt)] = (st, day)
    res = {"source": source, "rows": len(out), "cards": len({k[0] for k in out}), "written": False}
    if len(out) < min_rows:
        return res
    with conn:
        conn.execute("DELETE FROM card_legality WHERE source=?", (source,))
        conn.executemany("INSERT OR REPLACE INTO card_legality(card_id, format, status, source, day) VALUES(?,?,?,?,?)",
                         [(k[0], k[1], v[0], source, v[1]) for k, v in out.items()])
    res["written"] = True
    return res


def from_raw(conn):
    """Pokemon: every card's legality from the TCGdex record kept in cards.raw (no network).  -> replace_source result."""
    rows = []
    for cid, raw in conn.execute("SELECT id, raw FROM cards WHERE raw IS NOT NULL AND raw != ''"):
        try:
            card = json.loads(raw)
        except (TypeError, ValueError):
            continue
        rows += [(cid, f, st, "") for f, st in tdx_rows(card)]
    return replace_source(conn, "tdx", rows, min_rows=0)


def scryfall_write(conn, body, day):
    """Magic: Scryfall's legalities for the cards in this list (matched by cards.tcg_id, as the free prices are)."""
    by_tcg = {}
    for cid, tid in conn.execute("SELECT id, tcg_id FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''"):
        by_tcg.setdefault(str(tid), []).append(cid)
    rows = [(cid, f, st, d) for tid, f, st, d in scryfall_rows(body, day) for cid in by_tcg.get(tid, ())]
    return replace_source(conn, "scryfall", rows)


def ygo_write(conn, cards, day):
    """Yu-Gi-Oh!: YGOPRODeck's cardinfo list (misc=yes) matched to our cards by card code (language letters dropped)."""
    from .freeprices_ygo import norm_code
    by_code = {}
    for c in cards or ():
        st = ygo_statuses(c)
        if not st:
            continue
        for s in c.get("card_sets") or ():
            code = norm_code((s.get("set_code") or "").strip())
            if code:
                by_code.setdefault(code, st)
    rows = []
    for cid, code in conn.execute("SELECT id, local_id FROM cards WHERE local_id IS NOT NULL AND local_id != ''"):
        st = by_code.get(norm_code(code))
        if st:
            rows += [(cid, f, s, day) for f, s in st.items()]
    return replace_source(conn, "ygoprodeck", rows)


# ---------------------------------------------------------------------------------------------------------------------------- reading
def for_card(conn, card_id):
    """What the item detail shows: [{format, status, source, sourceName, url, day}] (empty when the list has none)."""
    try:
        out = []
        for fmt, st, src, day in conn.execute("SELECT format, status, source, day FROM card_legality WHERE card_id=? ORDER BY source, format", (str(card_id),)):
            name, url = SOURCE_NAMES.get(src, (src, ""))
            out.append({"format": fmt, "status": st, "source": src, "sourceName": name, "url": url, "day": day or ""})
        return out
    except sqlite3.Error:
        return []


def facet(conn, scope=None):
    """The 'Legal in' filter for the card list's sidebar: {key, label, values:[{v, n}]} (cards legal or restricted in each format), or None.  scope: see gamefacets.card_in."""
    from .gamefacets import card_in
    w, a = card_in(scope)
    try:
        vals = [{"v": r[0], "n": r[1]} for r in conn.execute(
            f"SELECT format, COUNT(*) FROM card_legality WHERE status != 'banned'{w} GROUP BY format ORDER BY COUNT(*) DESC, format", a)]
    except sqlite3.Error:
        return None
    return {"key": FACET_KEY, "label": FACET_LABEL, "values": vals} if vals else None


def card_ids(conn, formats):
    """Cards legal (or restricted) in ANY of these formats - the card list's 'Legal in' filter."""
    marks = ",".join("?" * len(formats))
    return {r[0] for r in conn.execute(f"SELECT DISTINCT card_id FROM card_legality WHERE format IN ({marks}) AND status != 'banned'", list(formats))}
