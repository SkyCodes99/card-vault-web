"""What's new feed (roadmap "What's new feed"): one short entry per day, written from data only - no hand-written articles, no AI writing.

After each daily update, tools/daily_update.py calls write_day(): the day's entry (new sets / products per game with counts, releases in the next 14 days, Shop restocks from the
weekly check) is saved as <daily log folder>/feed/<day>.json. It is built from the update report, the release calendar (cardvault/releasecal.py) and the stored Shop stock results.
The price movers belong to the owner's own saved price history, so they are worked out when the owner opens the feed (cardvault/marketmovers.py, once a day, kept in the account
setting "whatsnew_movers"). eBay prices are never used. Prices are sent as numbers; the screen formats them with money().
Read-only on the catalogs."""
import datetime
import json
import os
import re
import sqlite3

from . import dailylog, games, marketmovers, releasecal

KEY = "whatsnew_movers"
AHEAD_DAYS = 14
KEEP_DAYS = 30
TOP_MOVES = 3                    # rises and drops kept per game
EXAMPLES = 3                     # names listed in a sentence
_DAY = re.compile(r"^\d{4}-\d{2}-\d{2}\.json$")


def feed_dir():
    return os.path.join(dailylog.log_dir(), "feed")


# ----------------------------------------------------------------------------------------------- the day's entry (pure parts)
def sets_of(db):
    """{set id: name} of a game's card list (empty when there is none)."""
    if not os.path.exists(db):
        return {}
    c = sqlite3.connect(db)
    try:
        return {r[0]: r[1] for r in c.execute("SELECT id, name FROM sets")}
    except sqlite3.Error:
        return {}
    finally:
        c.close()


def new_names(before, after):
    """Names of the entries in `after` ({id: name}) that were not in `before`, sorted."""
    return sorted(str(after[i]) for i in after if i not in before and after[i])


def upcoming(items, today, days=AHEAD_DAYS):
    """Items (releasecal.game_items) with a real day inside today .. today+days -> short dicts, soonest first. A month-only or missing date is left out (it is not 'in 14 days')."""
    end = today + datetime.timedelta(days=days)
    out = []
    for it in items:
        if it.get("precision") != "day" or not it.get("date"):
            continue
        d = datetime.date.fromisoformat(it["date"])
        if today <= d <= end:
            out.append({"game": it["game"], "name": it["name"], "kind": it["kind"], "date": it["date"]})
    out.sort(key=lambda r: (r["date"], r["name"].lower()))
    return out


def restocks(before, after):
    """before / after = {url: 'in'|'out'} of the Shop stock results -> [{host, count}] of links in stock now that were out of stock or unknown before."""
    from urllib.parse import urlsplit
    per = {}
    for url, st in after.items():
        if st == "in" and before.get(url) != "in":
            h = urlsplit(url).netloc.lower().removeprefix("www.")
            if h:
                per[h] = per.get(h, 0) + 1
    return [{"host": h, "count": n} for h, n in sorted(per.items(), key=lambda kv: (-kv[1], kv[0]))]


def stock_states(store):
    return {u: r.get("stock") for u, r in ((store or {}).get("stock") or {}).items() if isinstance(r, dict)}


def make_entry(day, report, releases=(), restock_rows=()):
    """The day's entry from the daily update report ({"games": {id: {newCards, newSealed, newSetNames, ...}}}) -> a plain dict."""
    g_out = {}
    for gid, v in (report.get("games") or {}).items():
        if not isinstance(v, dict) or "error" in v:
            continue
        names = v.get("newSetNames") or []
        cards, sealed = int(v.get("newCards") or 0), int(v.get("newSealed") or 0)
        if names or cards or sealed:
            g_out[gid] = {"new_sets": len(names), "set_names": names[:EXAMPLES], "new_cards": cards, "new_sealed": sealed}
    return {"day": day, "games": g_out, "releases": list(releases), "restocks": list(restock_rows)}


def _plural(n, one, many=None):
    return f"{n} {one if n == 1 else (many or one + 's')}"


def _gname(gid):
    try:
        return games.game_by_id(gid).name
    except Exception:  # noqa: BLE001
        return gid


def new_sentence(gid, g):
    """'Pokemon: 2 new sets (A, B), 40 new cards and 3 new sealed products added.'"""
    parts = []
    if g.get("new_sets"):
        s = _plural(g["new_sets"], "new set")
        if g.get("set_names"):
            s += f" ({', '.join(g['set_names'])}{', and more' if g['new_sets'] > len(g['set_names']) else ''})"
        parts.append(s)
    if g.get("new_cards"):
        parts.append(_plural(g["new_cards"], "new card"))
    if g.get("new_sealed"):
        parts.append(_plural(g["new_sealed"], "new sealed product"))
    if not parts:
        return ""
    return f"{_gname(gid)}: {parts[0] if len(parts) == 1 else ', '.join(parts[:-1]) + ' and ' + parts[-1]} added."


def release_sentence(r):
    d = datetime.date.fromisoformat(r["date"])
    return f"{r['name']} ({_gname(r['game'])}) comes out {d:%b} {d.day}."


def restock_sentence(r):
    return f"{_plural(r['count'], 'item')} back in stock at {r['host']}."


def lines(entry, keep=None):
    """The entry as [{type, game, text}] in reading order (new, releases, restocks). `keep` = game ids to show (None = all games); restocks have no game and always stay."""
    ok = lambda gid: keep is None or gid in keep  # noqa: E731
    out = []
    for gid, g in entry.get("games", {}).items():
        t = new_sentence(gid, g) if ok(gid) else ""
        if t:
            out.append({"type": "new", "game": gid, "text": t})
    for r in entry.get("releases", []):
        if ok(r["game"]):
            out.append({"type": "release", "game": r["game"], "text": release_sentence(r)})
    for r in entry.get("restocks", []):
        out.append({"type": "restock", "game": "", "text": restock_sentence(r)})
    return out


# ----------------------------------------------------------------------------------------------- write / read the day files
def write_day(day, report, data_dir, store_before=None, store_after=None, today=None, folder=None):
    """Called by the daily update after the report is final. Saves feed/<day>.json (and tidies this feed's own day files older than KEEP_DAYS) -> the path."""
    today = today or datetime.date.fromisoformat(day)
    items = []
    for g in games.GAMES:
        try:
            items += releasecal.game_items(data_dir, g.id)
        except Exception:  # noqa: BLE001 - one list that cannot be read adds nothing today
            continue
    entry = make_entry(day, report, upcoming(items, today), restocks(stock_states(store_before), stock_states(store_after)))
    folder = folder or feed_dir()
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"{day}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entry, f, indent=1, ensure_ascii=False)
    for fn in sorted(x for x in os.listdir(folder) if _DAY.match(x))[:-KEEP_DAYS]:
        try:
            os.remove(os.path.join(folder, fn))
        except OSError:
            pass
    return path


def read_days(days=KEEP_DAYS, folder=None):
    """The last `days` entries, newest first."""
    folder = folder or feed_dir()
    files = sorted((f for f in (os.listdir(folder) if os.path.isdir(folder) else []) if _DAY.match(f)), reverse=True)[:max(1, int(days))]
    out = []
    for fn in files:
        try:
            with open(os.path.join(folder, fn), encoding="utf-8") as f:
                e = json.load(f)
        except (OSError, ValueError):
            continue
        if isinstance(e, dict):
            e["day"] = fn[:10]
            out.append(e)
    return out


# ----------------------------------------------------------------------------------------------- the owner's movers
def pick_movers(windows, n=TOP_MOVES):
    """marketmovers' {"1": {...}, "7": {...}} -> {"days": 1|7, "rises": [...], "drops": [...]}: yesterday's moves, else the 7-day ones (None when nothing compared)."""
    for w in ("1", "7"):
        win = (windows or {}).get(w) or {}
        if win.get("rises") or win.get("drops"):
            keep = lambda r: {k: r[k] for k in ("card_id", "game_name", "name", "old", "new", "pct")}  # noqa: E731
            return {"days": int(w), "rises": [keep(r) for r in win["rises"][:n]], "drops": [keep(r) for r in win["drops"][:n]]}
    return None


def _load(svc):
    try:
        d = json.loads(svc.pget(KEY) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def movers_today(svc, today=None):
    """Make sure today's movers for this owner are saved (per game, once a day) -> the saved {day: {game: {...}}}."""
    today = today or datetime.date.today()
    key = today.isoformat()
    saved = _load(svc)
    if saved.get(key):                                     # (a day with nothing found is looked at again: prices may arrive later today)
        return saved
    v = svc.vault
    day = {}
    for gid in marketmovers.owned_by_game(v):
        m = pick_movers(marketmovers.movers(v, gid, today=today)["windows"])
        if m:
            day[gid] = m
    if not day:
        return saved
    saved[key] = day
    for k in sorted(saved)[:-KEEP_DAYS]:
        saved.pop(k)
    try:
        svc.pset(KEY, json.dumps(saved))
    except Exception:  # noqa: BLE001 - not saved this time; shown anyway
        pass
    return saved


def feed(svc, show_all=False, days=KEEP_DAYS, today=None, folder=None):
    """-> {"days": [{day, lines, movers}], "mine": [game ids], "all": bool}, newest day first. Only the owner's games unless show_all."""
    today = today or datetime.date.today()
    mine = releasecal.collected_games(svc.vault)
    keep = None if show_all else set(mine)
    saved = movers_today(svc, today)
    entries = read_days(days, folder)
    if today.isoformat() not in {e["day"] for e in entries} and saved.get(today.isoformat()):
        entries.insert(0, {"day": today.isoformat(), "games": {}, "releases": [], "restocks": []})     # no update yet today, but the owner's movers are known
    out = []
    for e in entries:
        mv = []
        for gid, d in (saved.get(e["day"]) or {}).items():
            if keep is None or gid in keep:
                mv += [dict(m, game=gid, kind="rise", span=d["days"]) for m in d["rises"]] + [dict(m, game=gid, kind="drop", span=d["days"]) for m in d["drops"]]
        ln = lines(e, keep)
        if ln or mv:
            out.append({"day": e["day"], "lines": ln, "movers": mv})
    return {"days": out, "mine": mine, "all": bool(show_all)}
