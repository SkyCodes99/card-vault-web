"""Is a deck legal?  Pokémon: Standard and Expanded (60 cards, at most 4 of a card by name except basic Energy, one ACE SPEC, one Radiant Pokémon, a Basic Pokémon, regulation marks, the banned
list).  One Piece: 1 Leader + 50 cards, at most 4 of a card number, every colour shared with the Leader, the banned cards and banned pairs, and the block rotation (deckrules_opblock.py).
Yu-Gi-Oh! (deckrules_ygo.py) and Magic (deckrules_mtg.py) have their own small modules.  The lists our card data doesn't carry live in cardvault/data/deck_rules.json with the day they were
checked and their source; every answer says which list it was checked against.  Also the deck's stats (sections, colours, cost curve)."""
import functools
import os

from . import deckcards, deckleg, deckrules_mtg, deckrules_opblock, deckrules_ua, deckrules_ygo, deckzones
from .deckmsg import Msg, coded
from .pkgdata import open_text

RULES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "deck_rules.json")
POKEMON_SIZE, ONEPIECE_SIZE, MAX_COPIES = 60, 50, 4


@functools.lru_cache(maxsize=1)
def rules():
    import json
    try:
        with open_text(RULES_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def formats(game):
    """[(key, label)] the deck can be checked for."""
    if game == "pokemon":
        return [("standard", "Standard"), ("expanded", "Expanded")]
    if game == "onepiece":
        return [("standard", "Standard"), ("extra", "Extra")]
    if game == "unionarena":
        return [("standard", "Constructed")]
    return deckrules_ygo.formats(rules()) if game == "yugioh" else deckrules_mtg.formats(rules()) if game == "mtg" else []


def sizes(game, fmt=""):
    """(least, most) cards the deck's main list has; most None = no upper limit."""
    if game == "pokemon":
        return POKEMON_SIZE, POKEMON_SIZE
    if game == "onepiece":
        return ONEPIECE_SIZE, ONEPIECE_SIZE
    if game == "yugioh":
        return deckrules_ygo.size_range(rules())
    if game == "unionarena":
        return deckrules_ua.size(rules())
    return deckrules_mtg.size_text(rules(), fmt or "standard") if game == "mtg" else (0, None)


def main_count(game, deck, info):
    """How many cards count toward the deck's size (the Leader and DON!! of One Piece, Yu-Gi-Oh!'s Extra and Side Deck and Magic's sideboard don't; a Magic commander does)."""
    z = deckzones.split(deck)
    if game == "yugioh":
        return deckrules_ygo.counts(z, info)[0]
    if game == "mtg":
        return sum(z[deckzones.MAIN].values()) + sum(z[deckzones.CMD].values())
    return sum(n for cid, n in deckzones.flat(deck).items() if (info.get(cid) or {}).get("section") not in deckcards.NOT_IN_SIZE)


def _plural(n, word):
    return f"{n} {word}{'' if n == 1 else 's'}"


# ------------------------------------------------------------------------------------------------ Pokémon
def _banned_pokemon(info, banned):
    for b in banned:
        if deckcards.norm_name(b["name"]) != deckcards.norm_name(info["name"]):
            continue
        prints = b.get("prints")
        if not prints:
            return True
        num = info["number"].lstrip("0").lower()
        if any(deckcards.norm_name(s) in deckcards.norm_name(info["set_name"]) and n.lstrip("0").lower() == num for s, n in prints):
            return True
    return False


def _pokemon_mark_ok(info, fmt, rule, legal_keys):
    if deckcards.is_basic_energy(info):
        return True
    if info.get("mark") and info["mark"] in rule.get("marks", ()):
        return True
    if fmt == "expanded" and (info.get("legal") or {}).get("expanded") is True:
        return True                                                     # (the card list's own statement)
    if fmt == "expanded" and not info.get("mark") and info.get("serie") in rule.get("series", ()):
        return True
    return info["key"] in legal_keys                                    # an older print counts when a print with the same name is legal


def legal_keys(v, fmt):
    """The play keys (names) that have at least one print legal in this format - the 'reprint' rule.  Read once per card list (kept until the list changes size)."""
    stamp = (id(v.conn), v.game, fmt, v.conn.execute("SELECT COUNT(*), MAX(rowid) FROM cards").fetchone()[:])
    if _KEYS.get(fmt, (None,))[0] == stamp:
        return _KEYS[fmt][1]
    keys = _legal_keys(v, fmt)
    _KEYS[fmt] = (stamp, keys)
    return keys


_KEYS = {}


def _legal_keys(v, fmt):
    rule = rules().get("pokemon", {}).get(fmt, {})
    marks = set(rule.get("marks", ()))
    series = set(rule.get("series", ()))
    keys = set()
    for name, raw_mark, serie in v.conn.execute(
            "SELECT c.name, json_extract(c.raw, '$.regulationMark'), s.serie FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.raw IS NOT NULL AND c.raw != '' AND json_valid(c.raw)"):
        if (raw_mark or "").upper() in marks or (fmt == "expanded" and serie in series):
            keys.add(deckcards.play_key("pokemon", name, ""))
    return keys


def _pokemon(deck, info, fmt, keys):
    data = rules().get("pokemon", {})
    rule = data.get(fmt, {})
    probs, ace_names = [], {deckcards.norm_name(n) for n in data.get("ace_spec_names", ())}
    total = sum(deck.values())
    if total != POKEMON_SIZE:
        probs.append(Msg("pkSize", size=POKEMON_SIZE, n=total))
    by_key, ace, radiant, basics = {}, 0, 0, 0
    for cid, n in deck.items():
        c = info.get(cid)
        if not c:
            probs.append(Msg("gone"))
            continue
        if not deckcards.is_basic_energy(c):
            by_key.setdefault(c["key"], [c["name"], 0])[1] += n
        if "ace spec" in c["rarity"].lower() or c["key"] in ace_names:
            ace += n
        if c["name"].lower().startswith("radiant "):
            radiant += n
        if c["section"] == "Pokémon" and c.get("stage", "").lower() == "basic":
            basics += n
        if not _pokemon_mark_ok(c, fmt, rule, keys):
            probs.append(Msg("pkMark", name=c["name"], set=c["set_name"], fmt=fmt.title(), mark=c["mark"]) if c.get("mark") else Msg("pkNotAllowed", name=c["name"], set=c["set_name"], fmt=fmt.title()))
        if _banned_pokemon(c, rule.get("banned", ())):
            probs.append(Msg("banned", name=c["name"], fmt=fmt.title()))
    for name, n in by_key.values():
        if n > MAX_COPIES:
            probs.append(Msg("copies", max=MAX_COPIES, name=name, n=n))
    if ace > 1:
        probs.append(Msg("pkAce", n=ace))
    if radiant > 1:
        probs.append(Msg("pkRadiant", n=radiant))
    if deck and not basics and any(c.get("stage") for c in info.values()):
        probs.append(Msg("pkBasic"))
    return probs, {"dated": data.get("checked", ""), "source": rule.get("source", ""), "note": rule.get("note", "")}


# ------------------------------------------------------------------------------------------------ One Piece
def _onepiece(deck, info, fmt="standard"):
    data = rules().get("onepiece", {})
    probs, notes = [], []
    leaders = [(cid, n) for cid, n in deck.items() if (info.get(cid) or {}).get("section") == "Leader"]
    main = {cid: n for cid, n in deck.items() if (info.get(cid) or {}).get("section") not in ("Leader", "DON!!")}
    total = sum(main.values())
    lead_n = sum(n for _, n in leaders)
    if lead_n != 1:
        probs.append(Msg("opLeaderN", n=lead_n) if lead_n else Msg("opLeader"))
    if total != ONEPIECE_SIZE:
        probs.append(Msg("opSize", size=ONEPIECE_SIZE, n=total))
    if any((info.get(cid) or {}).get("section") == "DON!!" for cid in deck):
        notes.append("DON!! cards go in the separate DON!! deck (10 cards); they don't count toward the 50.")
    lead_colors = set(info[leaders[0][0]]["colors"]) if len(leaders) == 1 else set()
    by_key, numbers = {}, set()
    for cid, n in main.items():
        c = info.get(cid)
        if not c:
            probs.append(Msg("gone"))
            continue
        by_key.setdefault(c["key"], [c["name"], 0])[1] += n
        numbers.add(c["key"])
        if lead_colors and c["colors"] and not lead_colors & set(c["colors"]):
            probs.append(Msg("opColour", name=c["name"], colors="/".join(c["colors"]), lead="/".join(sorted(lead_colors))))
    for cid, _ in leaders:
        numbers.add(info[cid]["key"])
    for name, n in by_key.values():
        if n > MAX_COPIES:
            probs.append(Msg("copies", max=MAX_COPIES, name=name, n=n))
    names = {c["key"]: c["name"] for c in info.values()}
    for code in data.get("banned", ()):
        if code in numbers:
            probs.append(Msg("opBanned", name=names.get(code, code), code=code))
    for a, b in data.get("banned_pairs", ()):
        if a in numbers and b in numbers:
            probs.append(Msg("opPair", a=names.get(a, a), ac=a, b=names.get(b, b), bc=b))
    bl = data.get("blocks") or {}
    bp, bn = deckrules_opblock.check(numbers, names, fmt, bl)
    probs += bp
    notes += bn
    return probs, {"dated": data.get("checked", ""), "source": data.get("source", ""), "source2": bl.get("source", ""), "note": " ".join([data.get("note", "")] + notes).strip()}


def check(v, deck, info, fmt=None):
    """-> [{format, label, ok, problems, dated, source, note}] for every format of the game (or just fmt)."""
    out = []
    zoned, flat = deckzones.split(deck), deckzones.flat(deck)
    rows = deckleg.rows_for(v, info) if v.game in ("yugioh", "mtg") else None
    for key, label in formats(v.game):
        if fmt and key != fmt:
            continue
        if v.game == "pokemon":
            probs, meta = _pokemon(flat, info, key, legal_keys(v, key))
        elif v.game == "yugioh":
            probs, meta = deckrules_ygo.check(v, zoned, info, key, rules(), rows)
        elif v.game == "mtg":
            probs, meta = deckrules_mtg.check(v, zoned, info, key, rules(), rows)
        elif v.game == "unionarena":
            probs, meta = deckrules_ua.check(flat, info, rules())
        else:
            probs, meta = _onepiece(flat, info, key)
        seen = []
        for p in probs:                                                   # (the same sentence once)
            if p not in seen:
                seen.append(p)
        out.append({"format": key, "label": label, "ok": not seen, "problems": seen, "codes": coded(seen), **meta})
    return out
