"""'All sealed from <set>': one live checklist preset per set that has sealed products (roadmap "Sealed checklist per set", 2026-11-11).

The preset stores only the rule {"sealed": {"setIds": [...], "all": true}} - never a copy of the products.  The checklist reads the sealed list each time it is opened
(webapi/listsealed._members), so a product added to the set later shows up on its own.  Loose cards and code cards stay out; boxes, packs, tins, bundles and cases count."""
import re

LOOSE = ("Code card", "Loose card / energy")
PREFIX = "All sealed from "


def _fold(s):
    return re.sub(r"[^a-z0-9]+", " ", str(s or "").lower()).strip()


def sets_with_sealed(conn):
    """[{id, ids, name, n, released}] - one entry per set name that has sealed products (a set listed under two ids is one entry), newest first."""
    try:
        rows = conn.execute("SELECT set_id, set_name, released FROM sealed_products WHERE COALESCE(set_id,'')<>'' AND COALESCE(set_name,'')<>'' "
                            "AND COALESCE(kind,'') NOT IN (?,?)", LOOSE).fetchall()
    except Exception:  # noqa: BLE001 - a game with no sealed list
        return []
    by = {}
    for sid, name, rel in rows:
        e = by.setdefault(_fold(name), {"id": str(sid), "ids": [], "name": name, "n": 0, "released": ""})
        if str(sid) not in e["ids"]:
            e["ids"].append(str(sid))
        e["n"] += 1
        e["released"] = max(e["released"], str(rel or ""))
    out = sorted(by.values(), key=lambda e: e["name"])
    return sorted(out, key=lambda e: e["released"], reverse=True)                      # (newest first; a set with no date last)


def preset_for(e):
    return {"group": "All sealed from a set", "name": PREFIX + e["name"], "mode": "cards", "per_variant": False,
            "rules": {"include": [], "exclude": [], "sealed": {"setIds": list(e["ids"]), "all": True}}}


def presets(conn):
    return [preset_for(e) for e in sets_with_sealed(conn)]


def ids_for_card_set(conn, set_id, set_name=""):
    """The sealed set ids that belong to a card set (same id, or the same name once accents and punctuation are ignored); [] when it has no sealed products."""
    want = {_fold(set_name)} if set_name else set()
    out = []
    for e in sets_with_sealed(conn):
        if str(set_id) in e["ids"] or _fold(e["name"]) in want:
            out.extend(i for i in e["ids"] if i not in out)
    return out


def entry_for_ids(conn, ids):
    ids = {str(i) for i in ids}
    return next((e for e in sets_with_sealed(conn) if ids & set(e["ids"])), None)
