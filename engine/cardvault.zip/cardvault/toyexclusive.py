"""Who a toy is exclusive to, written one way.

Shops, conventions and collectors say it in many ways ('SDCC', 'San Diego Comic-Con', 'Comic Con exclusive', '7BAP', '7 Bucks A Pop Exclusive'), and the 'Exclusive to' filter would list each of them
as a different thing.  This turns what a title, a tag or a master list says into one name per shop or show, and leaves out what is not a who: 'Mystery', 'Blind box', 'Lottery', 'Prototype' and
'Artist proof' say how a toy was sold or what it is (the product-type and availability filters carry those), and a bare 'Exclusive' says nothing once the shop or show is known."""
import re

_KNOWN = (
    (r"7\s*bucks\s*a\s*pop|7\s*bap|7bucksapop", "7 Bucks A Pop"),
    (r"plastic\s*empire", "Plastic Empire"),
    (r"toy\s*temple", "Toy Temple"),
    (r"stormy\s*vault", "Stormy Vault"),
    (r"hot\s*topic", "Hot Topic"),
    (r"kid\s*robot", "Kidrobot"),
    (r"rotofugi", "Rotofugi"),
    (r"japan\s*la", "JapanLA"),
    (r"hobby\s*db", "hobbyDB"),
    (r"creature\s*club", "Creature Club"),
    (r"kickstarter", "Kickstarter"),
    (r"\bfye\b", "FYE"),
    (r"mondo\s*con", "MondoCon"),
    (r"lucasfilm", "Lucasfilm employees"),
    (r"sdcc|san\s*diego", "San Diego Comic-Con"),
    (r"nycc|new\s*york\s*comic", "New York Comic Con"),
    (r"c2e2", "C2E2"),
    (r"eccc|emerald\s*city", "Emerald City Comic Con"),
    (r"wonder\s*con", "WonderCon"),
    (r"\bd-?con\b|designer\s*con", "Designer Con"),
)
NOT_A_WHO = {"mystery", "blind box", "blind bag", "lottery", "prototype", "artist proof", "early access", "not exclusive", "none"}          # how it was sold, or what it is
GENERAL = {"exclusive", "convention exclusive", "convention", "online", "online exclusive", "retailer exclusive"}                      # says 'exclusive' and nothing more


def canonical(label):
    """One name for a shop or show ('NYCC' -> 'New York Comic Con'); '' for what is not a who."""
    text = re.sub(r"\s+", " ", str(label or "")).strip()
    low = text.lower()
    if not low or low in NOT_A_WHO:
        return ""
    for pattern, name in _KNOWN:
        if re.search(pattern, low):
            return name
    return text


def labels(values):
    """The 'Exclusive to' names of a toy, from everything that said anything about it: each once, in order; a general 'Exclusive' only when no shop or show is known."""
    out = []
    for v in values:
        c = canonical(v)
        if c and c not in out:
            out.append(c)
    return [x for x in out if x.lower() not in GENERAL] or out


def split(text):
    """The names in an 'Exclusive to' line as a list ('NYCC, Exclusive' -> ['NYCC', 'Exclusive'])."""
    return [x.strip() for x in str(text or "").split(",") if x.strip() and x.strip().lower() != "not exclusive"]
