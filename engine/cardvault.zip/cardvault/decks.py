"""Decks: the owner's deck lists (Pokemon, One Piece, Yu-Gi-Oh!, Magic and Union Arena).  A deck is ONE row in u.decks: its name, the format it is built for and the cards in it as JSON {card_id: copies}.
It syncs through the cloud snapshot like the binders ("decks", latest change wins, cloud/snapshot.py), and every change is ONE undo through rowundo (webapi/deckapi.py).
ensure() is the migration: safe to run any number of times (CREATE IF NOT EXISTS, then any column a newer version added)."""
import json

from . import deckzones, rowundo
from .db import new_uuid, now_iso

GAMES = ("pokemon", "onepiece", "yugioh", "mtg", "unionarena")   # the games the deck builder knows the rules of
NOT_READY = "Decks are ready for Pokémon, One Piece, Yu-Gi-Oh!, Magic and Union Arena so far."
MAX_COPIES_STORED = 60                              # one card can't sensibly be in a deck more often than this (basic Energy is the most)
MAX_NAME = 80
rowundo.TABLES.setdefault("decks", "uuid")

SCHEMA = ("CREATE TABLE IF NOT EXISTS u.decks(uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, name TEXT, fmt TEXT, cards TEXT, notes TEXT, created_at TEXT, updated_at TEXT, "
          "deleted INTEGER DEFAULT 0)",
          "CREATE INDEX IF NOT EXISTS u.decks_user ON decks(user_id, game)")
COLS = ("name", "fmt", "cards", "notes", "created_at", "updated_at", "deleted")      # what travels in a snapshot (owner and game are known to the receiving device)
_ADDED = (("fmt", "TEXT"), ("notes", "TEXT"), ("created_at", "TEXT"))             # columns a later version may need to add to an older table


class DeckError(ValueError):
    pass


def ensure(v):
    for sql in SCHEMA:
        v.conn.execute(sql)
    have = {r[1] for r in v.conn.execute("PRAGMA u.table_info(decks)")}
    for col, ddl in _ADDED:
        if col not in have:
            v.conn.execute(f"ALTER TABLE u.decks ADD COLUMN {col} {ddl}")


def _name(x):
    s = " ".join(str(x or "").split())[:MAX_NAME]
    if not s:
        raise DeckError("Type a name for the deck.")
    return s


def parse_cards(text):
    """The stored JSON -> {card_id: copies} (bad or empty text is an empty deck)."""
    try:
        d = json.loads(text or "{}")
    except ValueError:
        return {}
    return {str(k): int(n) for k, n in d.items() if isinstance(n, (int, float)) and int(n) > 0} if isinstance(d, dict) else {}


def _row(v, uuid):
    r = v.conn.execute("SELECT * FROM u.decks WHERE uuid=? AND user_id=? AND deleted=0", (uuid, v.user_id)).fetchone()
    if not r:
        raise DeckError("That deck isn't here any more.")
    return r


def get(v, uuid):
    r = _row(v, uuid)
    return {"id": r["uuid"], "name": r["name"], "fmt": r["fmt"] or "", "notes": r["notes"] or "", "cards": parse_cards(r["cards"]), "updated": r["updated_at"] or ""}


def all_decks(v):
    rows = v.conn.execute("SELECT * FROM u.decks WHERE user_id=? AND game=? AND deleted=0 ORDER BY name COLLATE NOCASE", (v.user_id, v.game)).fetchall()
    return [{"id": r["uuid"], "name": r["name"], "fmt": r["fmt"] or "", "cards": parse_cards(r["cards"]), "updated": r["updated_at"] or ""} for r in rows]


def create(v, name, fmt="", cards=None):
    if v.game not in GAMES:
        raise DeckError(NOT_READY)
    uid, ts = new_uuid(), now_iso()
    clean = {str(k): min(MAX_COPIES_STORED, int(n)) for k, n in (cards or {}).items() if int(n) > 0}
    v.conn.execute("INSERT INTO u.decks(uuid,user_id,game,name,fmt,cards,notes,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,0)",
                   (uid, v.user_id, v.game, _name(name), fmt or "", json.dumps(clean, sort_keys=True), "", ts, ts))
    return uid


def rename(v, uuid, name):
    _row(v, uuid)
    v.conn.execute("UPDATE u.decks SET name=?, updated_at=? WHERE uuid=?", (_name(name), now_iso(), uuid))


def set_format(v, uuid, fmt):
    _row(v, uuid)
    v.conn.execute("UPDATE u.decks SET fmt=?, updated_at=? WHERE uuid=?", (str(fmt or "")[:20], now_iso(), uuid))


def duplicate(v, uuid):
    r = _row(v, uuid)
    return create(v, f"{r['name']} (copy)"[:MAX_NAME], r["fmt"] or "", parse_cards(r["cards"]))


def remove(v, uuid):
    _row(v, uuid)
    v.conn.execute("UPDATE u.decks SET deleted=1, updated_at=? WHERE uuid=?", (now_iso(), uuid))


def set_cards(v, uuid, cards):
    _row(v, uuid)
    clean = {str(k): min(MAX_COPIES_STORED, int(n)) for k, n in cards.items() if int(n) > 0}
    v.conn.execute("UPDATE u.decks SET cards=?, updated_at=? WHERE uuid=?", (json.dumps(clean, sort_keys=True), now_iso(), uuid))


def change_count(v, uuid, card_id, delta=None, count=None, zone=deckzones.MAIN):
    """+1 / -1 (delta) or an exact number (count) of a card in one zone (main / side / cmd).  -> the new number of copies."""
    if not v.card_basic(card_id):
        raise DeckError("That card isn't in this game's card list.")
    if not deckzones.valid(v.game, zone):
        raise DeckError("This game's decks don't have that part.")
    cards = parse_cards(_row(v, uuid)["cards"])
    k = deckzones.key(zone, card_id)
    n = int(count) if count is not None else cards.get(k, 0) + int(delta or 0)
    n = max(0, min(MAX_COPIES_STORED, n))
    if n:
        cards[k] = n
    else:
        cards.pop(k, None)
    set_cards(v, uuid, cards)
    return n


def move(v, uuid, card_id, src, dst, n=1):
    """Moves up to n copies of a card from one zone to another (one change).  -> how many moved."""
    if not (deckzones.valid(v.game, src) and deckzones.valid(v.game, dst)) or src == dst:
        raise DeckError("This game's decks don't have that part.")
    cards = parse_cards(_row(v, uuid)["cards"])
    a, b = deckzones.key(src, card_id), deckzones.key(dst, card_id)
    k = max(0, min(int(n), cards.get(a, 0), MAX_COPIES_STORED - cards.get(b, 0)))          # (never more than the target part can hold: the rest stays where it was)
    if not k:
        return 0
    left = cards.get(a, 0) - k
    if left > 0:
        cards[a] = left
    else:
        cards.pop(a, None)
    cards[b] = cards.get(b, 0) + k
    set_cards(v, uuid, cards)
    return k
