"""Union Arena deck rules (the official Tournament Rules Manual 2.4 and the official restricted-cards page, both in cardvault/data/deck_rules.json "unionarena"): 50 cards besides
3 Action Point cards, all from one source material (series), at most 4 cards with the same card number, and the restricted cards (2 or 1 copy).  No side deck.
The limit of 4 cards per trigger type isn't checked (our card list has no trigger field to count)."""
from . import deckcards_tcg
from .deckmsg import Msg


def size(rules):
    n = (rules.get("unionarena") or {}).get("deck", 50)
    return n, n


def check(flat, info, rules):
    data = rules.get("unionarena") or {}
    probs, names, count, ap, series = [], {}, {}, 0, set()
    main = 0
    for cid, n in flat.items():
        c = info.get(cid)
        if not c:
            probs.append(Msg("gone"))
            continue
        if c["section"] == "Action Points":
            ap += n
            continue
        main += n
        count[c["key"]] = count.get(c["key"], 0) + n
        names[c["key"]] = deckcards_tcg.strip_tail(c["name"])
        if c.get("series"):
            series.add(c["series"])
    want, want_ap = data.get("deck", 50), data.get("ap", 3)
    if main != want:
        probs.append(Msg("uaSize", size=want, n=main))
    if ap != want_ap:
        probs.append(Msg("uaAp", size=want_ap, n=ap))
    if len(series) > 1:
        probs.append(Msg("uaSeries", list=", ".join(sorted(series))))
    restricted = data.get("restricted") or {}
    for key, n in count.items():
        limit = restricted.get(key, data.get("copies", 4))
        if n > limit:
            code = ("uaCopy1" if limit == 1 else "uaCopies") + ("R" if key in restricted else "")
            probs.append(Msg(code, max=limit, name=names[key], n=n))
    note = data.get("note", "")
    return probs, {"dated": data.get("checked", ""), "source": data.get("source", ""), "source2": data.get("manualSource", ""), "note": note}
