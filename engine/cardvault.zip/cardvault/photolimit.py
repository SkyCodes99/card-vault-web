"""How many photos of your own can live in your account: 100 free, 10,000 for a paid member (owner decision 2026-11-11, docs/membership_storage.md).
Counted in photos, not bytes.  Nothing is ever removed: reaching the limit only stops NEW photos from being added; viewing, downloading and deleting always work.
The account server is the authority (skycloud_server.py counts the photos it stores and refuses a new one past the limit); this module is the same rule on the device so
the message appears the moment you try to add, and the count shows in Settings."""
FREE_LIMIT = 100
PAID_LIMIT = 10000
PREF = "photo_limit"                      # the limit the account server last reported for this account (a paid member sees 10,000 here once memberships exist)
MARKER = "photo limit"                    # the server's error text for a refused photo


def limit_for(svc=None):
    """THE ONE PLACE on the device that decides the limit.  Membership tiers do not exist yet, so this is the free limit for everyone, unless the account server reported a different one
    (the server's answer wins: when it starts reporting 10,000 for paid members, nothing here needs to change)."""
    try:
        v = int(svc.pget(PREF)) if svc is not None else 0
    except (TypeError, ValueError):
        v = 0
    return v if v in (FREE_LIMIT, PAID_LIMIT) else FREE_LIMIT


def count(conn):
    """Photos of yours kept on this device (the sync stores exactly these in your account)."""
    return conn.execute("SELECT COUNT(*) FROM u.lot_photos WHERE data IS NOT NULL").fetchone()[0]


def full_message(used, limit):
    return (f"You've used {used:,} of your {limit:,} photos, so no more can be added. None of your photos were removed - "
            "delete some you no longer need, and then you can add new ones.")


def note(used, limit):
    """A gentle note at 90% (and the full message at the limit), or ''."""
    if used >= limit:
        return full_message(used, limit)
    if used >= 0.9 * limit:
        return f"You've used {used:,} of your {limit:,} photos - nearly full."
    return ""


def signed_in(svc):
    return bool(svc.pget("cloud_token") and svc.pget("cloud_dek"))


def check_can_add(svc, extra=1):
    """Raise ApiError (friendly) when a signed-in account is at its photo limit.  A device with no account stores nothing with us, so it is never held back here
    (the sync stops at the limit later, without removing anything)."""
    if svc is None or not signed_in(svc):
        return
    used, limit = count(svc.vault.conn), limit_for(svc)
    if used + extra > limit:
        from .webapi.registry import ApiError
        raise ApiError(full_message(used, limit))
