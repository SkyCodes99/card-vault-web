"""The last tidy-up of the Abominable Toys list (game id 'chomps'), run by collectibles.ShopifyToyProvider after every refresh so the nightly rebuild keeps the fixes.

Owner's standing rule: every item needs a TRUE photo of that exact item and exact facts (name, series, release, retail price).  What cannot be confirmed is never guessed: it is written to the
entry's raw ext 'Review' note (the same note NeeDoh and the consoles use) and the entry stays listed.  Idempotent: a second run changes nothing.  Pure text rules + one pass over the open connection.

  NAME_FIXES      a name that is plain wrong (a typo of a place), by entry id.
  Review reasons  no photo of its own / no confirmed release day / no retail price from the maker (a reseller's or an eBay asking price is not one) / the same shop page as another entry (so it
                  may be one release listed twice).
Frozen Culture figures ('fc:' ids) are skipped: they share their pack's photo by design and have their own series rules (frozenculture.py)."""
import json
import re

NAME_FIXES = {"sheet:phillipines-2023-10-12": "Philippines"}

# The maker (and its own retailer, Handmade by Robots, for the Chomps it sells itself) are the sources of a retail price.
NAME_FIXES_RUN = {}                                                          # (names made unique during this run)
MAKER_IDS = ("shp:", "rtl:handmadebyrobots:", "sheet:hmbr-")
_DAY = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _listing(text):
    return re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).strip()


def review_reasons(cid, name, image, price, price_kind, released, listed_same=()):
    """Why this entry cannot be called fully confirmed ([] when it can)."""
    if cid.startswith("fc:"):
        return []
    why = []
    if not image:
        why.append("No photo of this exact item found")
    if not _DAY.match(str(released or "")):
        why.append("Release date not confirmed")
    if price is None or price <= 0:
        why.append("Retail price not confirmed")
    elif not cid.startswith(MAKER_IDS) or (price_kind or "retail price") != "retail price":
        why.append("Price is not the maker's retail price")
    if listed_same:
        why.append("Same shop listing as " + ", ".join(sorted(listed_same)) + " (check it is a release of its own)")
    return why


def apply(conn, game_id="chomps"):
    """-> {'renamed', 'reviewed', 'confirmed'} for the entries of the list."""
    NAME_FIXES_RUN.clear()
    out = {"renamed": 0, "reviewed": 0, "confirmed": 0}
    rows = conn.execute("SELECT id, name, image_base, price_usd, price_kind, raw FROM cards").fetchall()
    same = {}
    for cid, name, _img, _p, _k, raw in rows:
        try:
            ext = (json.loads(raw or "{}").get("ext") or {})
        except ValueError:
            continue
        key = _listing(ext.get("Listed as"))
        if key and not cid.startswith("fc:"):
            same.setdefault(key, []).append((cid, name))
    seen = {}
    for cid, name, set_id, raw in conn.execute("SELECT id, name, set_id, raw FROM cards ORDER BY sort_key, id").fetchall():
        seen.setdefault((set_id, name.lower()), []).append((cid, name, raw))
    for group in seen.values():                                            # one name twice in a line (two releases): the later ones say their year, as the shop entries already do
        for cid, name, raw in group[1:]:
            year = ((json.loads(raw or "{}").get("ext") or {}).get("Released") or "")[:4]
            if year.isdigit() and not name.endswith(f"({year})"):
                NAME_FIXES_RUN[cid] = f"{name} ({year})"
    for cid, name, img, price, kind, raw in rows:
        try:
            doc = json.loads(raw or "{}")
        except ValueError:
            continue
        ext = doc.get("ext") if isinstance(doc.get("ext"), dict) else {}
        key = _listing(ext.get("Listed as"))
        twins = {n for i, n in same.get(key, []) if i != cid} if key else set()
        why = review_reasons(cid, name, img, price, kind, ext.get("Released"), twins)
        want = dict(ext)
        want.pop("Review", None)
        if why:
            want["Review"] = "; ".join(why)
            out["reviewed"] += 1
        elif not cid.startswith("fc:"):
            out["confirmed"] += 1
        new_name = NAME_FIXES.get(cid) or NAME_FIXES_RUN.get(cid)
        if new_name and new_name != name:
            conn.execute("UPDATE cards SET name=? WHERE id=?", (new_name, cid))
            out["renamed"] += 1
        if want != ext:
            doc["ext"] = want
            conn.execute("UPDATE cards SET raw=? WHERE id=?", (json.dumps(doc, ensure_ascii=False), cid))
    return out
