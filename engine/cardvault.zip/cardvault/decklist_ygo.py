"""Yu-Gi-Oh! decklists: the .ydk file every simulator and deck site shares, and plain "3 Dark Magician" text.
    .ydk   "#main", "#extra" and "!side" sections, one card passcode per line, a card repeated once per copy (the passcodes come from cardvault/ygopasscode.py)
    text   "3 Card name" or "3x Card name" lines; "Main Deck", "Extra Deck" and "Side Deck" lines start that part
A pasted card goes where its type puts it (Extra Deck monsters in the Extra Deck); only the Side Deck needs saying."""
import re

from . import decklookup, deckzones, ygopasscode

_PASSCODE = re.compile(r"^\d{4,10}$")
_LINE = re.compile(r"^\s*[*•-]?\s*(\d{1,2})\s*[xX×]?\s+(.+?)\s*$")
_HEAD = re.compile(r"^\s*(main|extra|side)(\s*deck)?\s*[:：]?\s*\d*\s*$", re.I)


def export(deck, info, v):
    """-> .ydk text.  A card whose passcode isn't in the list yet is named in a '#' comment line at the end."""
    zoned = deckzones.split(deck)
    keys = {c["key"] for cid in deck for c in [info.get(deckzones.zone_of(cid)[1])] if c}
    codes = ygopasscode.for_keys(v.conn, keys)
    main, extra, side, missing = [], [], [], []
    for z, out in ((deckzones.MAIN, main), (deckzones.SIDE, side)):
        for cid, n in sorted(zoned[z].items(), key=lambda x: (info.get(x[0]) or {}).get("name", "")):
            c = info.get(cid)
            if not c:
                continue
            code = codes.get(c["key"])
            if not code:
                missing.append(f"{n}x {c['name']}")
                continue
            (extra if z == deckzones.MAIN and c["section"] == "Extra Deck" else out).extend([code] * n)
    lines = ["#created by Collect Em All", "#main"] + main + ["#extra"] + extra + ["!side"] + side
    if missing:
        lines += ["#no passcode in the card list yet (the daily update adds them): " + ", ".join(missing)]
    return "\n".join(lines) + "\n"


def parse(v, text):
    """-> {cards: {key: copies}, unmatched: [line], lines: card lines read}.  Keys carry the zone (deckzones)."""
    cards, unmatched, count = {}, [], 0
    lines = [ln.strip() for ln in (text or "").splitlines() if ln.strip()]
    codes = ygopasscode.keys_for(v.conn, [ln for ln in lines if _PASSCODE.match(ln)])
    zone = deckzones.MAIN
    for ln in lines:
        low = ln.lower()
        if low in ("#main", "#extra") or low.startswith("#created"):
            zone = deckzones.MAIN
            continue
        if low == "!side":
            zone = deckzones.SIDE
            continue
        if ln.startswith("#"):
            continue
        h = _HEAD.match(ln)
        if h:
            zone = deckzones.SIDE if h.group(1).lower() == "side" else deckzones.MAIN
            continue
        if _PASSCODE.match(ln):
            n, name, label = 1, (codes.get(ln) or ("", ""))[1], ln + (f" ({codes[ln][1]})" if ln in codes else "")
        else:
            m = _LINE.match(ln)
            if not m:
                continue
            n, name, label = int(m.group(1)), m.group(2), ln
        count += 1
        cid = decklookup.by_name(v, name) if name else None
        if cid:
            k = deckzones.key(zone, cid)
            cards[k] = cards.get(k, 0) + n
        else:
            unmatched.append(label)
    return {"cards": cards, "unmatched": unmatched, "lines": count}
