"""Step-by-step jobs: a generator that yields after each short step (see webapi/scheduler.py steps(), which the browser build uses to do one step per quiet moment).

A step can also yield an Await (a network request, a pause): the generator gets its answer back from the yield.  run() below answers it on the spot (the desktop: the job has a thread
of its own).  The browser build hands it to the page instead (webapi/jobs.py + ui/src/engine/worker.js): the page does the request asynchronously and the engine keeps answering
clicks meanwhile - a sync used to freeze every screen for the seconds an upload of the whole collection took."""


class Await:
    """Something a step waits for outside the engine.  now() does it right here (blocking) -> the answer the generator gets back."""

    def now(self):
        raise NotImplementedError


class Pause(Await):
    """Wait a moment before the next step (a retry after a busy server) - without holding up the browser's engine."""

    def __init__(self, seconds):
        self.seconds = seconds

    def now(self):
        import time
        time.sleep(self.seconds)


def run(steps):
    """Do every step of a step-by-step job at once -> what it returns.  An Await is answered on the spot (its error is raised inside the generator, where it is handled)."""
    send, err = None, None
    while True:
        try:
            item = steps.throw(err) if err is not None else steps.send(send)
        except StopIteration as done:
            return done.value
        send, err = None, None
        if isinstance(item, Await):
            try:
                send = item.now()
            except Exception as e:  # noqa: BLE001 - goes back into the generator
                err = e
