"""Step-by-step jobs: a generator that yields after each short step (see webapi/scheduler.py steps(), which the browser build uses to do one step per quiet moment).

A step can also yield an Await (a network request, a pause): the generator gets its answer back from the yield.  run() below answers it on the spot (the desktop: the job has a thread
of its own).  The browser build hands it to the page instead (webapi/jobs.py + ui/src/engine/worker.js): the page does the request asynchronously and the engine keeps answering
clicks meanwhile - a sync used to freeze every screen for the seconds an upload of the whole collection took."""


class Await:
    """Something a step waits for outside the engine.  now() does it right here (blocking) -> the answer the generator gets back."""

    def now(self):
        raise NotImplementedError


class Pause(Await):
    """Wait a moment before the next step (a retry after a busy server) - without holding up the browser's engine."""

    def __init__(self, seconds):
        self.seconds = seconds

    def now(self):
        import time
        time.sleep(self.seconds)


def run(steps):
    """Do every step of a step-by-step job at once -> what it returns.  An Await is answered on the spot (its error is raised inside the generator, where it is handled)."""
    send, err = None, None
    while True:
        try:
            item = steps.throw(err) if err is not None else steps.send(send)
        except StopIteration as done:
            return done.value
        send, err = None, None
        if isinstance(item, Await):
            try:
                from .webapi import deferred
                hit, send = deferred.answer(item)                  # (the browser: a call being run so that the page sends its requests - webapi/deferred.py)
                if not hit:
                    send = item.now()
            except Exception as e:  # noqa: BLE001 - goes back into the generator
                err = e


class Retry(RuntimeError):
    """A download that may work if asked again a moment later (a busy server, a dropped connection)."""


class Download(Await):
    """A file from the web (a card list, a day's prices, a trend file, a month of the price archive, the search index), as a step of a job -> its bytes, or None when there is none.
    The browser build hands it to the page (ui/src/engine/worker.js), which downloads it asynchronously and hands the bytes back: asked from inside the engine, a 15 MB card list held
    every page up for the whole download (the engine has one thread).  `lenient`: any answer but 200 is "none" (else: 404 is none, a busy server is tried again, anything else fails)."""
    method, payload, body, binary = "GET", None, None, True

    def __init__(self, url, timeout=300, lenient=False):
        self.url, self.timeout, self.lenient = url, timeout, lenient

    def headers(self):
        return {}

    def now(self):
        from . import sync
        try:
            return sync._get(self.url, as_json=False, tries=1)
        except RuntimeError as e:
            raise Retry(str(e)) from e

    def answer(self, status, data, error=""):
        """What the page's fetch() came back with -> the bytes / None, or Retry / RuntimeError."""
        if error:
            raise Retry(f"Could not reach {self.url}: {error}")
        status = int(status or 0)
        if status == 200:
            return data.encode("utf-8") if isinstance(data, str) else bytes(data or b"")
        if self.lenient or status == 404:
            return None
        if status == 429 or status >= 500:
            raise Retry(f"Could not reach {self.url}: HTTP {status}")
        raise RuntimeError(f"Could not reach {self.url}: HTTP {status}")


import threading as _threading

_here = _threading.local()


class awaits_out:
    """The desktop's background chores in steps (webapi/scheduler.py steps): each step runs on the engine's one thread, so a download inside a step held every click up for as long as it took
    (the day's prices: two files per game, 40 games).  Inside this block a download is yielded as a step instead, and the chore's own thread fetches it while the engine keeps answering."""

    def __enter__(self):
        self.was = getattr(_here, "on", False)
        _here.on = True
        return self

    def __exit__(self, *exc):
        _here.on = self.was
        return False


def handed_out():
    """Is there a page to hand downloads to (the browser build; a test can play the page: webapi/jobs.HAND_OUT), or a desktop chore that fetches them on its own thread (awaits_out)?"""
    import sys
    if getattr(_here, "on", False):
        return True
    jobs = sys.modules.get("cardvault.webapi.jobs")
    return bool(jobs is not None and jobs.HAND_OUT)


def download(url, tries=5, lenient=False, get=None):
    """The bytes at url (None when there is none), as steps: `data = yield from download(url)`.  Where there is no page to hand it to (the desktop) it is fetched right here exactly as
    before, without a step (get(url), by default sync._get); in the browser the job waits - without holding the engine up - while the page downloads it."""
    if not handed_out():
        if get is not None:
            return get(url)
        from . import sync
        return sync._get(url, as_json=False, tries=tries)
    last = None
    for attempt in range(tries):
        try:
            return (yield Download(url, lenient=lenient))
        except Retry as e:
            last = e
            if attempt + 1 < tries:
                yield Pause(1.5 * (attempt + 1))
    raise RuntimeError(f"{last}")
