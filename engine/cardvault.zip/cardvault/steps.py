"""Step-by-step jobs: a generator that yields after each short step (see webapi/scheduler.py steps(), which the browser build uses to do one step per quiet moment)."""


def run(steps):
    """Do every step of a step-by-step job at once -> what it returns."""
    while True:
        try:
            next(steps)
        except StopIteration as done:
            return done.value
