"""How a designer-toy shop's product becomes an entry of a toy list: which products are toys at all (not a patch, a mug or a bag of coffee), what the toy is called, and which line of the list it belongs to.

The rules for the Abominable Toys list (Chomps, Chompers, Frozen Culture ...) and for 100% Soft (Dumpster Fires ...) live here; collectibles.ShopifyToyProvider applies them to what a shop's product feed says,
and tools/import_toy_masterlist.py to what a collector's master list says.  Pure functions of a product's title, tags and type: no network, no database."""
import re


def html_unescape(s):
    import html as _h
    return _h.unescape(s or "")


def _clean_title(t):
    """The toy's own name: pre-order notes and the like are not part of it."""
    t = re.sub(r"\s*[-–]?\s*(pre-?order|preorder)\b.*$", "", t or "", flags=re.I)
    t = re.sub(r"\s*[-–]?\s*DAMAGED CARTON\s*$", "", t, flags=re.I)
    t = re.sub(r"\s*[-–|(]?\s*\(?sold out\)?\s*$", "", t, flags=re.I)                    # 'Dumpster Fire Vinyl Figure - SOLD OUT' (an old page saved when the toy had just run out)
    return re.sub(r"\s+", " ", t).strip()


_PROOF = re.compile(r"\b(art(?:ist)? proofs?|prototypes?|protos?|proof)\b", re.I)
_NAME_NOISE = re.compile(r"\b(limited|edition|vinyl|figures?|resin|officially licensed|licensed|exclusive|soft|chomp|chomper|dumpster fire|collector'?s)\b", re.I)
_EXCL_TAIL = re.compile(r"\b(NYCC|SDCC|C2E2|DCon|Dcon|HMBR|Creature Club)\b(?:\s+Exclusive)?", re.I)


def short_name(title, game):
    """'Limited Silver Skeleton Edition Chomp Vinyl Figure' -> 'Silver Skeleton'; 'Dumpster Fire - Donut Green Vinyl Figure' -> 'Donut Green'.  What kind of toy it is stays in its group (Chomps, Chompers, Plush ...)."""
    t = html_unescape(title or "")
    if re.search(r'I\s*"?Chomp"?\s*NY', t, re.I):
        return "I Chomp NY"
    if re.search(r"chomp and chomper", t, re.I):
        return "Chomp & Chomper (Plush)" if re.search(r"plush", t, re.I) else "Chomp & Chomper"
    by = re.search(r"\s+[Bb]y\s+[A-Z][^()\[\]]*$", t)
    if by and not re.search(r"handmade$", t[:by.start()], re.I):                         # '... By Jaide Sen Su' is the designer, shown in the details ('Handmade by Robots' is a maker's name, part of the toy's)
        t = t[:by.start()]
    t = re.sub(r"\b(chomp|chomper)\s+x\s+", r"\1 ", t, flags=re.I)                      # 'Chomp X Elfie': a collaboration, the toy is the Elfie
    t = re.sub(r"\bFrozen Culture\b", " ", t, flags=re.I)
    t = _EXCL_TAIL.sub(" ", t)
    squishy = bool(re.search(r"\bsquishy\b", t, re.I))
    mini = bool(re.search(r"\bmini\b", t, re.I))
    plush = bool(re.search(r"\bplush\b", t, re.I))
    if game == "dumpsterfires":
        t = re.sub(r"\bDumpster Fire\b", " ", t, flags=re.I)
    t = _NAME_NOISE.sub(" ", t)
    t = re.sub(r"\b(squishy|mini|plush|single|single figure|set|bundle)\b", " ", t, flags=re.I)
    t = re.sub(r"\s+[-–|:]+\s+", " - ", t)
    t = re.sub(r"\s+", " ", t).strip(" -–|:,&")
    t = re.sub(r"^(?:-\s*)+|(?:\s*-)+$", "", t).strip()
    if not t:
        t = "Original"
    if t.isupper() and len(t) > 3:
        t = t.title()                                                                  # a shop that writes its titles in capitals
    suffix = " (Squishy)" if squishy else " (Mini)" if mini else ""
    if plush and "plush" not in t.lower():
        suffix = suffix or " (Plush)"
    return (t + suffix).strip()


_ACC = re.compile(r"\b(patch|tote|apron|hat|beanie|socks?|grip|protectors?|popshield|auctions?|prints?|posters?|lottery|membership(?! box)|trading cards?|full case|case of|shirt|tee|t-shirt|hoodie|mug|tankard|stickers?|pins?|lanyard|luggage|"
                  r"ornament|night light|snow globe|string lights|journal|coloring book|puzzle|deck|ashtray|crochet|pattern|digital|keychain|badge reel|gift card|magnet|flashlight|post ?card|coin|comic|pre-?orders?|damaged carton)\b", re.I)
_COFFEE = re.compile(r"\bchomp coffee\b|\bcoffee (?:pack|bag|cup)\b|\b\d+ ?oz\b|\broast\b", re.I)
_NOT_TOY = re.compile(_ACC.pattern + "|" + _COFFEE.pattern, re.I)                  # what a purge of older entries removes from the Abominable Toys list
_NOT_TOY_SOFT = _ACC                                                              # 100% Soft has real toys with 'coffee' in the name (Coffee Rat), so only the accessory words apply


def _core(title):
    """The toy itself: 'Classic Edition Chomp Vinyl Figure with Sticker' is a figure (the sticker is a free extra), not a sticker."""
    t = _clean_title(title or "")
    t = re.sub(r"\s+(?:with|w/|and)\s+(?:a\s+)?(?:free\s+)?(?:gold\s+)?(?:sticker|pin)s?\b.*$", "", t, flags=re.I)
    t = re.sub(r"\s+bundle\s+with\s+free\b.*$", " bundle", t, flags=re.I)
    return t


_TOY_WORDS = ("figure", "plush", "squishy", "blind bag", "blind box", "gumdrop", "mini chomp", "chomp", "chomper", "mystery box", "resin", "vinyl", "bundle", "set of", "toy", "frozen culture", "membership box")


def _chomp_keep(p):
    t = _core(p.get("title") or "")
    if _ACC.search(t) or _COFFEE.search(t) or p.get("product_type") in ("Apparel", "Print", "Sticker", "Luggage Tag", "Enamel Pin", "Mug", "Gift Card"):
        return False
    low = t.lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    return bool(tags & {"figure", "plush", "squishy"}) or any(w in low for w in _TOY_WORDS)


# Not official releases, so never in a list (the daily rebuild would add them back otherwise): fan customs sold by other shops, and bundles that are not the maker's toy.
NOT_OFFICIAL = {
    "shp:limited-edition-marshall-chomp-bundle-by-mardeluna",          # a Mardeluna bundle, not an Abominable Toys collaboration
    "shp:original-and-limited-gold-edition-bundle",                     # shop bundles of figures already in the list (collector feedback 2026-11-05)
    "shp:limited-edition-gold-silver-skeleton-chomp-vinyl-figure-bundle",
    "shp:figure-1",                                                     # "Gumball": a shop listing, not a release of its own (same feedback)
}

_LICENSED = ("godzilla", "mothra", "rodan", "bob ross", "zoltar", "care bears", "madballs")                    # characters of other makers
_PARTNERS = ("handmade by robots", "hmbr", "elfie", "sket one", "dave perillo", "nicky davis", "mupatoy", "mardeluna")          # artists and studios the toy was made with


def _text(p):
    """Everything a product says about itself, in lowercase: its title, another shop's own title, and (for an entry read back from a list) its name."""
    return " ".join(str(p.get(k) or "") for k in ("title", "_shop_title", "name")).lower()


def _chomp_line(p):
    """The line of the Abominable Toys list a product belongs to: what kind of toy it is first (plush, blind bag, mini, MEGA, squishy, Chomper), then who it was made with."""
    t = _text(p)
    tags = {x.lower() for x in (p.get("tags") or [])}
    if _PROOF.search(t):
        return "Art proofs & prototypes"
    if "plush" in t:
        return "Plush"
    if "creature club" in t and "membership box" in t:
        return "Creature Club limited"                              # the yearly box (a figure, a pin and more): it is a Creature Club item before it is a Chomper
    if "frozen culture" in t:
        return "Frozen Culture"
    if "blind" in t or "mystery" in t or "blind box" in tags or "blind bag" in tags:
        return "Blind boxes"
    if "swomp" in t or "swomp" in tags:
        return "Swomp"
    if "hope" in t and "turtle" in t:
        return "Hope Turtle"
    if re.search(r"\bmini\b", t):
        return "Mini Chomps"
    if re.search(r"\bmega\b", t):
        return "MEGA Chomps"
    if "squishy" in t:
        return "Squishies"
    if "chomper" in t or "chomper" in tags:
        return "Chompers"
    if "licensed" in tags or any(w in t for w in _LICENSED):
        return "Collaborations & licensed"
    if "creature club" in tags or "creature club" in t:
        return "Creature Club limited"
    if "collaboration" in tags or any(w in t for w in _PARTNERS):
        return "Collaborations & licensed"
    if "chomp" in t or "chomp" in tags:
        return "Chomps"
    return "Misc"                                                    # whatever fits no line above


def _df_keep(p):
    t = _core(p.get("title") or "")
    if _NOT_TOY_SOFT.search(t) or p.get("product_type") in ("Enamel Pin", "Shirts", "Stickers", "Print", "Patch", "Keychain", "AirPods Case", "Board Game", "Journal", "Card Deck", "Coloring Book"):
        return False
    low = t.lower()
    tags = {x.lower() for x in (p.get("tags") or [])}
    return p.get("product_type") in ("Toys", "Plush Toy", "Blind Box") or "vinyl figure" in tags or any(w in low for w in ("figure", "plush", "squishy", "ceramic", "mystery box", "blind"))


def _df_line(p):
    t = _text(p)
    tags = {x.lower() for x in (p.get("tags") or [])}
    if _PROOF.search(t):
        return "Art proofs & prototypes"
    if p.get("product_type") == "Plush Toy" or "plush" in t:
        return "Plush"
    if "squishy" in t or "ceramic" in t:
        return "Squishy & ceramic"
    if "melted" in t:
        return "Melted (artist editions)"
    if "ice cream" in t:
        return "Dumpster Ice Cream"
    if "blind" in t or "mystery box" in t or p.get("product_type") == "Blind Box" or "blind box" in tags:
        return "Blind boxes"
    if "megamoji" in t or "megamoji" in tags:
        return "MEGAMOJI busts"
    if "kaiju kitties" in tags or "kaiju kitt" in t or "screaming boomu" in t:
        return "Kaiju Kitties"
    if "bad vibes" in tags or "bad vibes" in t:
        return "Bad Vibes"
    if "trash fire friends" in tags or "lil meltdown" in t or "pizza rat" in t and "dumpster" not in t or "trash panda" in t and "dumpster" not in t:
        return "Trash Fire Friends"
    if any(w in t for w in ("marvel", "deadpool", "venom", "ghost rider", "x-men", "avengers", "pusheen", "care bears", "galactus", "infinity gauntlet")) or "marvel" in tags:
        return "Collaborations"
    if "dumpster" in t or "dumpster fire" in tags:
        return "Dumpster Fires"
    return "Misc"                                                    # whatever fits no line above
