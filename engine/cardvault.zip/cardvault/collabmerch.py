"""Retail collaborations and store exclusives, for the Accessories list (game id 'accessories'), owner 2026-11-14:
    Pokémon x Target (2026, with the launch-day Bulbasaur / Charmander / Squirtle pin-back buttons), Pokémon x Polaroid (2026), Costco Panini FIFA World Cup 2026 sticker boxes.

Same pattern as worldsmerch.py: read from collabmerch_data.json (written by tools/harvest_collabmerch.py), no network at refresh, AccessoriesProvider.fetch_catalog calls add() after
the TCGplayer rows.  Each line is one set; the Rarity column holds the kind (General merchandise / Giveaway / Sealed sticker box) and the Types column the brand (Pokémon, FIFA World Cup).
A picture is shown only when tools/verify_photos.py --only collabmerch passed that exact URL (or the owner said yes on the review list); everything without a confirmed picture or with an
unconfirmed fact carries the 'Review' note, so it waits on the review list instead of showing a stand-in.
A photo from a non-commercial-only host (Bulbapedia / Bulbagarden Archives, ncsource.py) is never shown, even when the photo check passed it (owner quiz 2026-11-15 q11 "find another source")."""
import json
import os
import re

from . import ncsource, photoverify

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "collabmerch_data.json")
SERIE = "Retail collaborations & exclusives"
KINDS = ("General merchandise", "Giveaway", "Sealed sticker box")
SET_PREFIX = "rcx-"
KEY = "cm:"
SPORTS_LINES = frozenset({"costco-wc2026"})          # owner quiz 2026-11-15 q12/q13: these lines are in the Sports list (cardvault/sports.py), not Accessories, and carry no price


def _unpriced(it):
    """The entry with every price taken off (q13 "no price on them"): the price fields, any fact that states an amount, and the word 'price' in its review note."""
    extra = {k: v for k, v in (it.get("extra") or {}).items() if not re.search(r"[$€£]\s?\d|\d\s?(?:USD|EUR|GBP|CA\$)|\bprice\b", str(v), re.I)}
    review = [re.sub(r"(?i)\bprice and ", "", r) for r in (it.get("review") or [])]
    return {**it, "price": "", "price_source": "", "extra": extra, "review": review}
HELD_NC = "photo held: its source (Bulbagarden Archives) allows only non-commercial use; waiting for a photo from another source"


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def shown(it, gate):
    if not it["image"]:
        return "", (it.get("extra") or {}).get("Why no picture") or "no confirmed true photo"
    if ncsource.non_commercial(it["image"]):                                    # a Bulbagarden Archives photo (CC BY-NC-SA) is held, whatever the photo check said (owner quiz 2026-11-15 q11)
        return "", HELD_NC
    ok, why = gate.ok(KEY + it["id"], it["image"])
    return (it["image"], "") if ok else ("", "photo check failed: " + why)


def card_ext(it, line, img, nope):
    ext = {"Collaboration": line["name"], "Retailer": it["retailer"], "Released": it["released"], "Item kind": it["kind"], "Product type": it["type"], "SKU": it.get("sku", ""),
           "Source": it["source"], "Photo source": it["photo_source"] if img else "", "Photo credit": it["credit"] if img else ""}
    ext.update({k: v for k, v in (it.get("extra") or {}).items() if k != "Why no picture"})
    if it.get("price"):
        ext["Retail price"] = it["price"]
        ext["Retail price source"] = it["price_source"]
    why = list(it.get("review") or [])
    if not img:
        why.insert(0, nope)
    if why:
        ext["Review"] = "; ".join(why)
    return {k: v for k, v in ext.items() if v}


def add(conn, day, sports=False):
    """Writes the collaboration sets and their entries into an accessories cards.db (idempotent).  -> number of entries.
    sports=True writes only the SPORTS_LINES entries, unpriced (the Sports list's cards.db); the accessories build leaves them out and takes out an older build's copy of them
    (what you had on them follows to Sports: cardvault/gamemoves.py).  Pictures keep the accessories photo check, where their verdicts and review answers live."""
    data = load()
    lines = {l["id"]: l for l in data["lines"]}
    per = {}
    gate = photoverify.Gate("accessories")
    moved = [(KEY + it["id"],) for it in data["items"] if (it["line"] in SPORTS_LINES) != sports]
    conn.executemany("DELETE FROM cards WHERE id=?", moved)
    data["items"] = [(_unpriced(it) if sports else it) for it in data["items"] if (it["line"] in SPORTS_LINES) == sports]
    conn.execute("DELETE FROM sets WHERE id LIKE ? AND id NOT IN (SELECT DISTINCT set_id FROM cards)", (SET_PREFIX + "%",))
    for it in data["items"]:
        line = lines[it["line"]]
        n = per[line["id"]] = per.get(line["id"], 0) + 1
        img, nope = shown(it, gate)
        raw = {"source": "collabmerch", "url": it["source"], "ext": card_ext(it, line, img, nope)}
        conn.execute(
            "INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)",
            (KEY + it["id"], SET_PREFIX + line["id"], "", 100000 + n, it["name"], img, it["type"], it["kind"], line["brand"],
             "%s - %s, %s (%s)." % (it["name"], it["kind"].lower(), line["short"], it["retailer"]), json.dumps({"normal": True}), json.dumps(raw, ensure_ascii=False)))
    for l in data["lines"]:
        if l["id"] in per:
            conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)",
                         (SET_PREFIX + l["id"], l["name"], SERIE, l["start"], per[l["id"]], per[l["id"]]))
    return len(data["items"])
