"""What it costs to open a card list, kept so it is paid once.

Opening a game means working out which groups every card belongs to (rarity, card type, colour, trait ... - 20 seconds for the 105,000 Magic cards) and, for Pokémon, which Pokédex number a promo card
without one belongs to.  Both are facts about the card list, so they are saved together in one small file beside it (games/<game>/class_cache.json.gz) and read back the next time.  A saved answer is used
only while it still fits: the same card list, the same rules (taxonomy.VERSION, gamefacets.VERSION) and the same corrections by the person - all of that is in the key.
"""
import gzip
import hashlib
import json
import os
import sqlite3

from . import gamefacets, taxonomy

FILE = "class_cache.json.gz"
LEGACY_KEYS = ("class_cache", "dex_infer")                 # where an earlier version kept the same answers (in the person's own settings): removed once the file is written


class Saved:
    """A saved answer that still fits: `groups` {card id: frozenset of group ids} and `dex` {card id: Pokédex numbers} found for cards that had none."""

    def __init__(self, groups, dex):
        self.groups, self.dex = groups, dex


def _key(vault, tags, thr):
    from .games import game_by_id
    n, art, size = vault.conn.execute(
        "SELECT COUNT(*), COALESCE(SUM(art_score), 0), COALESCE(SUM(length(coalesce(name, '')) + length(coalesce(rarity, '')) + length(coalesce(category, '')) + length(coalesce(types, ''))), 0) FROM cards").fetchone()
    facets = 0
    if not game_by_id(vault.game).pokemon:                    # (only the other games' groups are made from the filter table)
        try:
            facets = vault.conn.execute("SELECT COUNT(*) FROM card_facets").fetchone()[0]
        except sqlite3.Error:
            pass
    text = f"{taxonomy.VERSION}|{gamefacets.VERSION}|{n}|{round(art, 3)}|{size}|{facets}|{thr}|{json.dumps(tags, sort_keys=True)}"
    return hashlib.sha1(text.encode()).hexdigest()


def load(vault, tags, thr):
    """-> Saved, or None when there is nothing saved or it no longer fits."""
    try:
        with gzip.open(os.path.join(vault.gdir, FILE), "rt", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("key") != _key(vault, tags, thr):
            return None
        vocab = data["vocab"]
        return Saved({cid: frozenset(vocab[i] for i in ids) for cid, ids in data["cards"].items()}, data.get("dex") or {})
    except (OSError, ValueError, KeyError, sqlite3.Error):
        return None


def _pack(index):
    """The groups of every card as small numbers: ({vocabulary of group ids}, {card id: [positions in it]})."""
    vocab, position, cards = [], {}, {}
    for card in index:
        ids = []
        for group in card["groups"]:
            if group not in position:
                position[group] = len(vocab)
                vocab.append(group)
            ids.append(position[group])
        cards[card["id"]] = ids
    return vocab, cards


def save(vault, index, tags, thr, dex):
    """Keep what was just worked out (never a reason to fail: without the file the next opening just works it out again)."""
    vocab, cards = _pack(index)
    path = os.path.join(vault.gdir, FILE)
    try:
        with gzip.open(path + ".part", "wt", encoding="utf-8", compresslevel=3) as f:
            json.dump({"key": _key(vault, tags, thr), "vocab": vocab, "cards": cards, "dex": dex}, f, separators=(",", ":"))
        os.replace(path + ".part", path)
        _forget_legacy(vault)
    except (OSError, sqlite3.Error):
        pass


def _forget_legacy(vault):
    marks = ",".join("?" * len(LEGACY_KEYS))
    vault.conn.execute(f"DELETE FROM u.settings WHERE user_id=? AND game=? AND key IN ({marks})", (vault.user_id, vault.game, *LEGACY_KEYS))
    vault._commit()
