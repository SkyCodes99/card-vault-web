"""What it costs to open a card list, kept so it is paid once - and, for a published list, paid before it is published.

Opening a game means working out which groups every card belongs to (rarity, card type, colour, trait ... - seconds for the 105,000 Magic cards, and in the browser nothing else can happen
meanwhile) and, for Pokémon, which Pokédex number a promo card without one belongs to.  Both are facts about the card list, so they are saved together in one small file beside it
(games/<game>/class_cache.json.gz) and read back the next time.  A saved answer is used only while it still fits: the same card list, the same rules (taxonomy.VERSION, gamefacets.VERSION) and the
same art threshold - all of that is in the key.

A person's own corrections to single cards are NOT in the key: a correction changes the groups of ITS card only, so those few cards are worked out again each time and everything else is read back.
(Editing one tag no longer makes the whole list start over.)

The same answer also travels INSIDE a published card list (the class_cache table, see bake): whoever downloads the list gets it ready-made and never has to work it out.
"""
import gzip
import hashlib
import json
import os
import sqlite3

from . import gamefacets, taxonomy

FILE = "class_cache.json.gz"
TABLE = "class_cache"                                      # in a published card list: one row, the same bytes the file holds
LEGACY_KEYS = ("class_cache", "dex_infer")                 # where an earlier version kept the same answers (in the person's own settings): removed once the file is written


class Saved:
    """A saved answer that still fits: `groups` {card id: frozenset of group ids} and `dex` {card id: Pokédex numbers} found for cards that had none."""

    def __init__(self, groups, dex):
        self.groups, self.dex = groups, dex


def _key(vault, thr):
    from .games import game_by_id
    n, art, size = vault.conn.execute(
        "SELECT COUNT(*), COALESCE(SUM(art_score), 0), COALESCE(SUM(length(coalesce(name, '')) + length(coalesce(rarity, '')) + length(coalesce(category, '')) + length(coalesce(types, ''))), 0) FROM cards").fetchone()
    facets = 0
    if not game_by_id(vault.game).pokemon:                    # (only the other games' groups are made from the filter table)
        try:
            facets = vault.conn.execute("SELECT COUNT(*) FROM card_facets").fetchone()[0]
        except sqlite3.Error:
            pass
    text = f"{taxonomy.VERSION}|{gamefacets.VERSION}|{n}|{round(art, 3)}|{size}|{facets}|{thr}"
    return hashlib.sha1(text.encode()).hexdigest()


def _depends_on_corrections(vault, tags):
    """The cards whose groups a person's corrections can change: Pokémon cards only (the other games' groups come from the card list's own filter table, whatever anyone corrects)."""
    from .games import game_by_id
    return tags if game_by_id(vault.game).pokemon else {}


def _decode(payload):
    try:
        return json.loads(gzip.decompress(payload).decode("utf-8"))
    except (OSError, ValueError, EOFError):
        return None


def _from_file(vault):
    try:
        with open(os.path.join(vault.gdir, FILE), "rb") as f:
            return _decode(f.read())
    except OSError:
        return None


def _from_list(vault, key):
    """The answer that came inside the card list (None when the list has none, or it was made for other rules)."""
    try:
        if (vault.conn.execute("SELECT value FROM meta WHERE key='class_key'").fetchone() or (None,))[0] != key:
            return None
        row = vault.conn.execute(f"SELECT payload FROM {TABLE}").fetchone()
    except sqlite3.Error:
        return None
    return _decode(bytes(row[0])) if row else None


def load(vault, tags, thr):
    """-> Saved, or None when there is nothing saved that fits.  Cards the person has corrected are left out of it (their groups are worked out again by the caller)."""
    key = _key(vault, thr)
    data = _from_file(vault)
    if not data or data.get("key") != key:
        data = _from_list(vault, key)                      # (the list's own copy, made when it was published - only looked at when the file beside it does not fit)
    if not data or data.get("key") != key:
        return None
    try:
        vocab = data["vocab"]
        skip = _depends_on_corrections(vault, tags)
        sets = {}                                                          # (a hundred thousand cards share only a few thousand different combinations of groups)
        groups = {}
        for cid, ids in data["cards"].items():
            if cid in skip:
                continue
            combo = tuple(ids)
            if combo not in sets:
                sets[combo] = frozenset(map(vocab.__getitem__, combo))
            groups[cid] = sets[combo]
        return Saved(groups, data.get("dex") or {})
    except (KeyError, IndexError, TypeError):
        return None


def _pack(index, skip):
    """The groups of every card as small numbers: ({vocabulary of group ids}, {card id: [positions in it]}).  Cards in `skip` are left out."""
    vocab, position, cards = [], {}, {}
    for card in index:
        if card["id"] in skip:
            continue
        ids = []
        for group in card["groups"]:
            if group not in position:
                position[group] = len(vocab)
                vocab.append(group)
            ids.append(position[group])
        cards[card["id"]] = ids
    return vocab, cards


def _payload(vault, index, tags, thr, dex):
    vocab, cards = _pack(index, _depends_on_corrections(vault, tags))
    text = json.dumps({"key": _key(vault, thr), "vocab": vocab, "cards": cards, "dex": dex}, separators=(",", ":"))          # (json.dump to a file writes it piece by piece in Python: six times slower than this)
    return gzip.compress(text.encode("utf-8"), compresslevel=3)


def save(vault, index, tags, thr, dex):
    """Keep what was just worked out (never a reason to fail: without the file the next opening just works it out again)."""
    path = os.path.join(vault.gdir, FILE)
    try:
        with open(path + ".part", "wb") as f:
            f.write(_payload(vault, index, tags, thr, dex))
        os.replace(path + ".part", path)
        _forget_legacy(vault)
    except (OSError, sqlite3.Error):
        pass


def bake(vault):
    """(when a card list is published) Work the groups out once and keep them inside the list, so that nobody who downloads it has to.  Run on the list as it will be published; -> bytes stored."""
    vault.invalidate_index()
    vault.card_index()                                    # works them out and saves the file beside the list
    with open(os.path.join(vault.gdir, FILE), "rb") as f:
        payload = f.read()
    key = _key(vault, vault.art_threshold())
    vault.conn.execute(f"CREATE TABLE IF NOT EXISTS {TABLE}(payload BLOB)")
    vault.conn.execute(f"DELETE FROM {TABLE}")
    vault.conn.execute(f"INSERT INTO {TABLE} VALUES(?)", (payload,))
    vault.conn.execute("INSERT OR REPLACE INTO meta VALUES('class_key', ?)", (key,))
    vault.conn.commit()
    return len(payload)


def _forget_legacy(vault):
    marks = ",".join("?" * len(LEGACY_KEYS))
    vault.conn.execute(f"DELETE FROM u.settings WHERE user_id=? AND game=? AND key IN ({marks})", (vault.user_id, vault.game, *LEGACY_KEYS))
    vault._commit()
