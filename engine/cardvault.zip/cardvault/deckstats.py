"""A deck's stats for the builder screen: how many cards of each kind, the colour / energy split and the cost curve (One Piece cost, Magic mana value), all counted in copies, and the
hand size and deck size the draw-odds box starts from.  A row may carry an "id" (Yu-Gi-Oh! / Magic piles) the screen turns into the player's language."""
from . import deckcards, deckrules, deckrules_ygo, deckzones


def _order(d, ids=None):
    return [{"k": k, "n": d[k], **({"id": ids[k]} if ids and k in ids else {})} for k in sorted(d, key=lambda k: -d[k])]


def _curve(d):
    return [{"k": k, "n": d[k]} for k in sorted(d, key=lambda k: (k == "?", int(k.rstrip("+")) if k != "?" else 99))]


def _bucket(cost, top):
    return "?" if cost is None else str(min(cost, top)) + ("+" if cost >= top else "")


def stats(game, deck, info):
    zoned, flat = deckzones.split(deck), deckzones.flat(deck)
    if game in ("yugioh", "mtg"):
        return _tcg(game, deck, zoned, info)
    secs = {s: 0 for s in deckcards.sections(game)}
    colors, energy, curve = {}, {}, {}
    for cid, n in flat.items():
        c = info.get(cid)
        if not c:
            continue
        secs[c["section"]] = secs.get(c["section"], 0) + n
        if game == "pokemon" and c["section"] == "Energy":
            word = c["name"].replace("Basic ", "").replace(" Energy", "").strip() or "Energy"
            energy[word] = energy.get(word, 0) + n
        elif game in ("pokemon", "onepiece") and c["section"] != "DON!!":
            for col in c["colors"] or ["None"]:
                colors[col] = colors.get(col, 0) + n
        if game == "onepiece" and c["section"] not in ("Leader", "DON!!"):
            k = _bucket(c.get("cost"), 10)
            curve[k] = curve.get(k, 0) + n
    out = {"sections": [{"k": k, "n": n} for k, n in secs.items() if n or k != "Other"], "colors": _order(colors), "energy": _order(energy)}
    if game == "onepiece":
        out["curve"] = _curve(curve)
    out["handSize"] = 5 if game == "onepiece" else 7
    lo, hi = deckrules.sizes(game)
    out["deckSize"] = hi or lo
    return out


def _tcg(game, deck, zoned, info):
    labels = dict(deckcards.groups(game))
    secs, colors, curve = {}, {}, {}
    for z in (deckzones.MAIN, deckzones.CMD, deckzones.SIDE):
        for cid, n in zoned[z].items():
            c = info.get(cid)
            if not c:
                continue
            g = deckcards.group_id(game, c, z)
            secs[g] = secs.get(g, 0) + n
            if game == "mtg" and z != deckzones.SIDE and c["section"] != "Lands":
                for col in c["colors"] or ["Colorless"]:
                    colors[col] = colors.get(col, 0) + n
                k = _bucket(c.get("cost"), 7)
                curve[k] = curve.get(k, 0) + n
    out = {"sections": [{"k": labels[g], "n": secs[g], "id": g} for g, _ in deckcards.groups(game) if secs.get(g)], "colors": _order(colors), "energy": []}
    if game == "mtg":
        out["curve"] = _curve(curve)
    library = deckrules_ygo.counts(zoned, info)[0] if game == "yugioh" else sum(zoned[deckzones.MAIN].values())
    out["handSize"] = 5 if game == "yugioh" else 7
    out["deckSize"] = library or (40 if game == "yugioh" else 60)
    return out
