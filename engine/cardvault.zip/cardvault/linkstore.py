"""The stored results of the weekly Shop / Where-to-sell check (cardvault/weeklylinks.py), kept in ONE small file `weekly_links.json` in the data folder:
{"last_run": iso-time, "backoff": {host: until-iso}, "robots": {host: {"at", "text", "status"}}, "stock": {url: {"stock": "in"|"out", "checked": "YYYY-MM-DD"}},
 "offers": {"game|name|set|site": {"usd", "checked"}}}.  Readers (shoplinks / selllinks) only look things up here; only weeklylinks writes."""
import datetime
import json
import os

PATH = None                                   # tests point this at a temporary file
_cache = {"key": None, "data": None}


def path():
    if PATH:
        return PATH
    try:
        from .paths import release_data_dir
        return os.path.join(release_data_dir(), "weekly_links.json")
    except (SystemExit, Exception):           # no real data folder (a test's temporary folder): nothing stored
        return ""


def load(p=None):
    p = p or path()
    try:
        st = os.stat(p)
        key = (p, st.st_mtime_ns, st.st_size)
        if _cache["key"] != key:
            _cache.update(key=key, data=json.load(open(p, encoding="utf-8")))
        return _cache["data"] if isinstance(_cache["data"], dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def save(data, p=None):
    p = p or path()
    if not p:
        return
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    json.dump(data, open(tmp, "w", encoding="utf-8"))
    os.replace(tmp, p)
    _cache["key"] = None


def stock_for(url):
    r = (load().get("stock") or {}).get(url)
    return (r.get("stock"), r.get("checked")) if isinstance(r, dict) and r.get("stock") in ("in", "out") else (None, None)


def offer_key(game, name, set_name, site):
    return "|".join(str(x or "").strip().lower() for x in (game, name, set_name, site))


def offer_for(game, name, set_name, site):
    r = (load().get("offers") or {}).get(offer_key(game, name, set_name, site))
    return r if isinstance(r, dict) else {}


def pretty(day):
    """'2026-11-10' -> 'Nov 10' (what the drawer shows)."""
    try:
        d = datetime.date.fromisoformat(str(day)[:10])
        return f"{d:%b} {d.day}"
    except ValueError:
        return ""
