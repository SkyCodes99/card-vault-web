"""Can I build this deck from what I own?  For every card of a deck: how many copies you own in ALL your portfolios (any print of the same card counts - Pokémon by name, One Piece by
card number), how many are missing and what the missing ones cost at today's prices (the cheapest print with a price; a Pokémon card keeps its own print's price when it has one)."""
import re

from . import deckcards, pricepick


def owned_by_key(v):
    """{play key: copies} across every portfolio of this game (not just the ones being looked at)."""
    out = {}
    q = ("SELECT c.name, c.local_id, SUM(l.qty) AS n FROM u.lots l JOIN cards c ON c.id=l.card_id "
         "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY l.card_id")
    for r in v.conn.execute(q, (v.user_id, v.game)):
        k = deckcards.play_key(v.game, r["name"], r["local_id"])
        out[k] = out.get(k, 0) + (r["n"] or 0)
    return out


def _cheapest(v, game, keys, names):
    """{play key: cheapest current price among its prints}.  names: the card names in the deck (Pokémon prints are found by name)."""
    best = {}
    if not keys:
        return best
    if game == "onepiece":
        args = sorted(keys)
        rows = v.conn.execute(f"SELECT id, local_id AS k, price_usd FROM cards WHERE UPPER(local_id) IN ({','.join('?' * len(args))})", args).fetchall()
    else:
        args = sorted({x for n in names for x in (n, re.sub(r"^basic\s+", "", n, flags=re.I), "Basic " + re.sub(r"^basic\s+", "", n, flags=re.I))})
        rows = v.conn.execute(f"SELECT id, name, local_id, price_usd FROM cards WHERE name COLLATE NOCASE IN ({','.join('?' * len(args))})", args).fetchall()
    for r in rows:
        k = deckcards.play_key(game, "", r["k"]) if game == "onepiece" else deckcards.play_key(game, r["name"], r["local_id"])
        if k not in keys:
            continue
        p = pricepick.price_for(v, r["id"], r["price_usd"])
        if p is not None and (k not in best or p < best[k]):
            best[k] = p
    return best


def check(v, deck, info):
    """-> {rows: [{id, name, need, have, missing, price, cost}], need, have, missing, cost}."""
    owned = owned_by_key(v)
    need_by_key = {}
    for cid, n in deck.items():
        c = info.get(cid)
        if c:
            need_by_key[c["key"]] = need_by_key.get(c["key"], 0) + n
    cheap = _cheapest(v, v.game, set(need_by_key), [c["name"] for c in info.values()])
    left = dict(owned)                                                     # copies not yet given to an earlier line of the same card
    rows, cost_total = [], 0.0
    for cid, n in sorted(deck.items(), key=lambda x: (info.get(x[0]) or {}).get("name", "")):
        c = info.get(cid)
        if not c:
            continue
        have = min(n, left.get(c["key"], 0))
        left[c["key"]] = left.get(c["key"], 0) - have
        miss = n - have
        own_price = pricepick.price_for(v, cid, c.get("price"))
        price = own_price if (v.game == "pokemon" and c["section"] == "Pokémon" and own_price is not None) else cheap.get(c["key"], own_price)
        cost = None if (price is None or not miss) else round(price * miss, 2)
        cost_total += cost or 0
        rows.append({"id": cid, "name": c["name"], "section": c["section"], "need": n, "have": have, "owned": owned.get(c["key"], 0), "missing": miss, "price": price, "cost": cost})
    rows.sort(key=lambda r: (r["missing"] == 0, -(r["cost"] or 0), r["name"]))
    return {"rows": rows, "need": sum(r["need"] for r in rows), "have": sum(r["have"] for r in rows), "missing": sum(r["missing"] for r in rows),
            "cost": round(cost_total, 2), "noPrice": sum(1 for r in rows if r["missing"] and r["price"] is None)}
