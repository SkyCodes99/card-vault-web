"""Curated answers: cardvault/data/set_logo_aliases.json  {"<game>": {"<set id or exact set name>": "<logo address>" | "scryfall:<code>"}}.  Whatever a person (or a reviewed search) has confirmed is THE
logo of that exact set lives here, so one finding is never looked up twice and the daily job re-applies it after a rebuild.  "scryfall:<icon>" is shorthand for that set's icon on Scryfall: <icon> is the FILE name in the set's icon_svg_uri
(svgs.scryfall.io/sets/<icon>.svg), which is often not the set code - promo sets share star / dci / mtga; a guessed name 404s and the browser blocks it (ERR_BLOCKED_BY_ORB)."""
import json
import os
from .. import pkgdata

FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "set_logo_aliases.json")


def load(path=None):
    try:
        with pkgdata.open_text(path or FILE) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def find(reader, rows, game=None, review=None, path=None):
    mine = load(path).get(game) or {}
    out = {}
    for r in rows:
        v = mine.get(str(r["id"])) or mine.get(r["name"] or "")
        if isinstance(v, str) and v.startswith("scryfall:"):
            v = f"https://svgs.scryfall.io/sets/{v[9:].lower()}.svg"
        if v:
            out[r["id"]] = v
    return out
