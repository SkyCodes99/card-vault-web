"""Shared helpers for sources that are MediaWiki wikis with a public api.php that robots.txt allows (Yugipedia).  Everything goes through the polite reader (robots.txt, rate limit, cache): a
wiki whose api.php robots.txt disallows (Bulbapedia, MTG Wiki) or that answers 403 (Fandom) just returns nothing and is skipped.
  pages(reader, api, titles)       -> {asked title: (page title, wikitext)}  (redirects followed, 50 titles per call, missing pages left out)
  infobox_field(text, field)       -> the value of `| field = ...` in the first {{Infobox ...}} (or '' )
  file_urls(reader, api, names)    -> {file name: direct address} (imageinfo, 50 per call)"""
import re
from urllib.parse import urlencode

BATCH = 50


def _call(reader, api, **params):
    params["format"] = "json"
    params["formatversion"] = 2
    return reader.json(api + "?" + urlencode(params)) or {}


def pages(reader, api, titles):
    out = {}
    titles = list(dict.fromkeys(t for t in titles if t))
    for i in range(0, len(titles), BATCH):
        chunk = titles[i:i + BATCH]
        q = (_call(reader, api, action="query", titles="|".join(chunk), redirects=1, prop="revisions", rvprop="content", rvslots="main").get("query")) or {}
        # map asked title -> final page title through normalized + redirects
        fwd = {t: t for t in chunk}
        for n in q.get("normalized") or []:
            for k, v in list(fwd.items()):
                if v == n["from"]:
                    fwd[k] = n["to"]
        for n in q.get("redirects") or []:
            for k, v in list(fwd.items()):
                if v == n["from"]:
                    fwd[k] = n["to"]
        got = {}
        for p in q.get("pages") or []:
            revs = p.get("revisions") or []
            if revs and not p.get("missing"):
                got[p["title"]] = revs[0].get("slots", {}).get("main", {}).get("content", "")
        for asked, final in fwd.items():
            if final in got:
                out[asked] = (final, got[final])
    return out


def infobox_field(text, field):
    m = re.search(r"\{\{\s*Infobox[^|{}]*\|", text or "", re.I)
    if not m:
        return ""
    block = (text or "")[m.start():m.start() + 6000]
    f = re.search(r"\n\s*\|\s*" + re.escape(field) + r"\s*=\s*([^\n|]*)", block, re.I)
    return f.group(1).strip() if f else ""


def file_urls(reader, api, names):
    out = {}
    names = list(dict.fromkeys(n for n in names if n))
    for i in range(0, len(names), BATCH):
        chunk = names[i:i + BATCH]
        q = (_call(reader, api, action="query", titles="|".join("File:" + n for n in chunk), prop="imageinfo", iiprop="url").get("query")) or {}
        back = {}
        for n in chunk:
            back["File:" + n.replace("_", " ")] = n
        for n in q.get("normalized") or []:
            if n["from"].startswith("File:"):
                back[n["to"]] = n["from"][5:]
        for p in q.get("pages") or []:
            info = p.get("imageinfo") or []
            if info and info[0].get("url"):
                out[back.get(p["title"], p["title"][5:])] = info[0]["url"]
    return out
