"""Magic: sets TCGplayer lists under a product-line prefix ("Art Series: Bloomburrow", "Promo Pack: Kaldheim", "Mythic Edition: War of the Spark", "Planechase: ...", "Archenemy: ...") are not in
Scryfall's own list by that name, but Scryfall files them under their parent expansion and gives them the parent's set icon (Bloomburrow Art Series and Bloomburrow Promos both use blb.svg).  So:
strip the prefix, find the ONE Scryfall set (expansion / core / masters / commander ...) with the remaining name, check its year is within one of the set's, take its icon.
Also an exact-name pass over ALL Scryfall sets (tokens, promos, memorabilia, boxes) with the same year guard."""
import re

from ..setfiling import _norm

URL = "https://api.scryfall.com/sets"
PREFIX = re.compile(r"^(art series|promo pack|mythic edition|planechase|archenemy)\s*:\s*", re.I)
PARENT_TYPES = {"core", "expansion", "masters", "draft_innovation", "commander", "starter", "funny", "eternal", "planechase", "archenemy", "box", "spellbook", "treasure_chest"}


def _year(s):
    s = (s or "")[:4]
    return int(s) if s.isdigit() else None


def _candidates(rest):
    """'Universes Beyond: Doctor Who' -> ['Universes Beyond: Doctor Who', 'Doctor Who'] (drop leading segments one by one, never the last)."""
    parts = [p.strip() for p in rest.split(":") if p.strip()]
    return [": ".join(parts[i:]) for i in range(len(parts))]


def find(reader, rows, game=None, review=None):
    data = (reader.json(URL) or {}).get("data") or []
    by_name = {}
    for x in data:
        if x.get("icon_svg_uri"):
            by_name.setdefault(_norm(x.get("name")), []).append(x)
    out = {}
    for r in rows:
        name = r["name"] or ""
        m = PREFIX.match(name)
        tries = _candidates(name[m.end():]) if m else [name]
        y = _year(r.get("date"))
        for t in tries:
            cands = by_name.get(_norm(t)) or []
            if m:
                cands = [c for c in cands if (c.get("set_type") or "") in PARENT_TYPES]
                if not cands:                                 # 'Strixhaven' -> 'Strixhaven: School of Mages' (the one expansion whose name continues after a colon)
                    key = _norm(t) + " "
                    cands = [c for n, v in by_name.items() if n.startswith(key) for c in v if c.get("set_type") in ("core", "expansion") and ":" in (c.get("name") or "")]
            if y is not None:
                cands = [c for c in cands if _year(c.get("released_at")) is None or abs(_year(c["released_at"]) - y) <= 1]
            if len(cands) == 1:
                out[r["id"]] = cands[0]["icon_svg_uri"]
                break
            if len(cands) > 1 and review is not None:
                review.append({"game": game, "id": r["id"], "name": name, "why": "several Scryfall sets share this name", "candidates": [c["code"] for c in cands]})
                break
    return out
