"""Scrydex (scrydex.com; robots.txt allows everything for '*', images.scrydex.com too): one expansion-list page per game carries every set's own LOGO (images.scrydex.com/<game>/<CODE>-logo/logo),
its code, English name and release day.  Used for Gundam, Lorcana, One Piece, Riftbound, Pokemon (and the Japanese list for pokemon_jp, codes end `_ja`), Magic as a last resort.
Taken only when the logo is CERTAINLY that exact set's:
  (a) the code agrees (our set id for Pokemon; the code in front of our name for "OP-01: Romance Dawn" / "Starter Deck 11: ...") AND the name agrees after folding OR the release days are within 45 days;
  (b) the folded name is the same AND the release days are within 45 days (or one side has no day AND the name is unique);  a name unique on both sides is also taken within 120 days (TCGplayer lists
      some sets weeks off the official day);  "X: Y" where Y is the whole of Scrydex's name and the days are within 3;
  (c) a Release Event / Pre-Release / Anniversary Tournament / Super Pre-Release collection of a set shares that set's logo (the parent must be found by (a) or (b));
  (d) pokemon_jp only: the release day is unique on both sides (no other Scrydex list entry and no other of our unmatched sets that day; a pair released together is never guessed) AND the card count on the Scrydex set page is at least our
      count and at most 1.8 times it (secret rares).
Anything else that matches only in part goes to the review list.  Every picked logo is read once through the polite reader and must load as a real picture (at least 40 px).
Pictures are hot-linked, never copied; credit Scrydex."""
import html
import re
from datetime import date

from ..setfiling import _norm

BASE = "https://scrydex.com/"
LISTS = {"gundam": "gundam/expansions", "lorcana": "lorcana/expansions", "onepiece": "onepiece/expansions", "riftbound": "riftbound/expansions",
         "pokemon": "pokemon/expansions", "pokemon_jp": "pokemon/jp/expansions", "mtg": "magicthegathering/expansions"}
JA = {"pokemon_jp": "_ja"}
DAYS = 45
DAYS_UNIQUE = 120
MIN_SIDE = 40
_ENTRY = re.compile(r'<a [^>]*data-name="([^"]*)"[^>]*href="(/[^"]+)"[^>]*>.*?<img[^>]+src="([^"]+)"[^>]*/?>.*?<span>([^<]*)</span>(?:<span>([^<]*)</span>)?', re.S)
_CODE = re.compile(r"^\s*([A-Za-z]{1,5}-?\d{1,3}[A-Za-z]?)\s*[:\-]\s*(.+)$")
_STARTER = re.compile(r"^\s*Starter Deck\s*(\d{1,2})\s*[:\-]\s*(.+)$", re.I)
_SUB = re.compile(r"\s*(\(Super Pre-Release Edition\)|:\s*(?:\d+\w*\s+)?Anniversary Tournament Cards|\bPre-Release Cards|\bRelease Event Cards)\s*$", re.I)
_COUNT = re.compile(r"([\d,]+)\s+cards\s*•\s*Released")


def parse(page):
    """-> [{"code","name","day","logo","href"}] from an expansion-list page."""
    out = []
    for name, href, logo, _title, day in _ENTRY.findall(page or ""):
        d = (day or "").replace("/", "-")
        out.append({"code": href.rsplit("/", 1)[-1], "name": html.unescape(name), "day": d if re.match(r"\d{4}-\d\d-\d\d$", d) else "", "logo": logo, "href": href})
    return out


def _fold(s):
    s = _norm(html.unescape(s or "").replace("&", " and "))
    return re.sub(r"^the ", "", s)


def _split(name):
    """'OP-01: Romance Dawn' -> ('OP01', 'Romance Dawn'); a name with no code in front -> ('', name)."""
    m = _STARTER.match(name or "")
    if m:
        return "ST" + m.group(1).zfill(2), m.group(2)
    m = _CODE.match(name or "")
    return (m.group(1).replace("-", "").upper(), m.group(2)) if m else ("", name or "")


def _gap(a, b):
    try:
        return abs((date.fromisoformat(a[:10]) - date.fromisoformat(b[:10])).days)
    except ValueError:
        return None


def _near(row, e, limit):
    g = _gap(row.get("date") or "", e["day"])
    return g is not None and g <= limit


def match(row, entries, game, _parent=False, rows=None):
    """-> (entry, "") when certain, (None, why) for a doubtful candidate, (None, "") for nothing."""
    ja = JA.get(game, "")
    code, bare = _split(row["name"])
    key = _fold(bare)
    by_code = [e for e in entries if e["code"].lower() == (str(row["id"]) + ja).lower()] if game.startswith("pokemon") else []
    if not by_code and code:
        by_code = [e for e in entries if e["code"].replace("-", "").upper() == code]
    if len(by_code) == 1:
        e = by_code[0]
        twins = [x["code"] for x in entries if ja and x["day"] and x["day"] == e["day"] and x["code"] != e["code"]]
        if twins and not _twins_agree(row, entries, game, rows):         # two Japanese sets out the same day (Sword / Shield, Red Flash / Blue Shock): the names are Japanese, so only the codes tell them apart
            return None, f"{e['code']} shares its release day with {', '.join(twins)} and not every set of ours that day has the code of one of them (our XY8a / XY8b against Scrydex's xy8b / xy8r): which one is ours cannot be told"
        if _fold(e["name"]) == key or _near(row, e, DAYS) or _parent:
            return e, ""
        if _SUB.search(bare or "") and not _parent:
            return match(dict(row, name=_SUB.sub("", row["name"]).strip(" :-")), entries, game, _parent=True)
        return None, f"code {e['code']} agrees but the name ({e['name']}) and the day do not"
    names = [e for e in entries if _fold(e["name"]) == key] if key else []
    if not names and ":" in (bare or ""):
        tail = _fold(bare.rsplit(":", 1)[1])
        names = [e for e in entries if _fold(e["name"]) == tail and _near(row, e, 3)] if tail else []
    if not names:
        sub = _SUB.search(bare or "")
        if sub and not _parent:
            return match(dict(row, name=_SUB.sub("", row["name"]).strip(" :-")), entries, game, _parent=True)
        return None, ""
    near = [e for e in names if _near(row, e, DAYS)]
    if len(near) == 1:
        return near[0], ""
    if len(names) == 1 and (not row.get("date") or not names[0]["day"]):
        return names[0], ""
    if len(names) == 1 and _near(row, names[0], DAYS_UNIQUE) and sum(1 for e in entries if _fold(e["name"]) == _fold(names[0]["name"])) == 1:
        return names[0], ""
    if _parent and len(names) == 1:
        return names[0], ""
    return None, f"name matches Scrydex's {names[0]['code']} ({names[0]['name']}, {names[0]['day'] or 'no day'}) but the release day does not agree"


def _twins_agree(row, entries, game, rows):
    """True when every set of ours out the same day has a code that is the code of one Scrydex entry that day (so the two lists number the pair the same way)."""
    if not rows:
        return False
    day = (row.get("date") or "")[:10]
    codes = {x["code"].lower() for x in entries if x["day"] == day}
    mine = [x for x in rows if (x.get("date") or "")[:10] == day]
    return bool(day) and all((str(x["id"]) + JA.get(game, "")).lower() in codes for x in mine)


def _count(reader, e):
    b = reader.bytes(BASE.rstrip("/") + e["href"], max_age=30 * 24 * 3600)
    m = _COUNT.search(re.sub(r"<[^>]+>", " ", b.decode("utf-8", "replace"))) if b else None
    return int(m.group(1).replace(",", "")) if m else None


def _by_day(reader, rows, entries, claimed, game, review):
    """(d): a day only one Scrydex entry and one of our still-unmatched sets have, with a believable card count.  -> {set id: entry}"""
    out = {}
    free = [e for e in entries if e["code"] not in claimed]
    for r in rows:
        day = (r.get("date") or "")[:10]
        if not day:
            continue
        theirs = [e for e in free if e["day"] == day] if sum(1 for e in entries if e["day"] == day) == 1 else []
        ours = [x for x in rows if (x.get("date") or "")[:10] == day]
        if len(theirs) != 1 or len(ours) != 1 or not r.get("total"):
            continue
        n = _count(reader, theirs[0])
        if n and r["total"] <= n <= r["total"] * 1.8:
            out[r["id"]] = theirs[0]
        elif review is not None:
            review.append({"game": game, "id": r["id"], "name": r["name"], "why": f"Scrydex: only {theirs[0]['code']} ({theirs[0]['name']}) shares this release day but its card count ({n}) is not close to ours ({r['total']})"})
    return out


def find(reader, rows, game=None, review=None):
    path = LISTS.get(game)
    if not path:
        return {}
    raw = reader.bytes(BASE + path, max_age=12 * 3600)
    entries = parse(raw.decode("utf-8", "replace")) if raw else []
    if not entries:
        return {}
    from .. import gates
    picks, left = {}, []
    for r in rows:
        e, why = match(r, entries, game, rows=rows)
        if e is not None:
            picks[r["id"]] = e
            continue
        left.append(r)
        if why and review is not None:
            review.append({"game": game, "id": r["id"], "name": r["name"], "why": "Scrydex: " + why})
    if game == "pokemon_jp" and left:
        picks.update(_by_day(reader, left, entries, {e["code"] for e in picks.values()}, game, review))
    out = {}
    for sid, e in picks.items():
        b = reader.bytes(e["logo"])
        d = gates._dims(b or b"")
        if d and min(d) >= MIN_SIDE:
            out[sid] = e["logo"]
        elif review is not None:
            review.append({"game": game, "id": sid, "name": next(x["name"] for x in rows if x["id"] == sid), "why": "Scrydex lists this set but its logo picture does not load or is tiny", "file": e["logo"]})
    return out
