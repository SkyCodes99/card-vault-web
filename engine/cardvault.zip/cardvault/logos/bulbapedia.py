def find(reader, rows, game=None, review=None):
    return {}
