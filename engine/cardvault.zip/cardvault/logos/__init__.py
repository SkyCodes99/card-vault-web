"""Wider logo search (owner 2026-11-10 "expand your search ... the whole internet is out there").  One small module per source; each is
    find(reader, rows, game=None, review=None) -> {set id: logo address}
where `reader` is the shared polite reader (picturecheck.Reader: robots.txt, rate limit, cache; a refusal / 403 / captcha just returns nothing - a blocked site is skipped, never worked around)
and `rows` are {"id","name","date","total",...} sets that still have no real logo.  An adapter only answers when the logo is CERTAINLY that exact set's; a doubtful candidate is appended to the
`review` list it is given and is never applied.
Registry: SOURCES[game] = (module, ...).  setfiling.fill_logos runs them after its own public lists, so the daily job keeps finding more; tools/widen_set_logos.py runs them on demand."""
from . import aliases, scrydex, scryfall_alias, yugipedia

SOURCES = {
    "mtg": (aliases, scryfall_alias, scrydex),
    "yugioh": (aliases, yugipedia),
    "pokemon": (aliases, scrydex),
    "pokemon_jp": (aliases, scrydex),
    "gundam": (aliases, scrydex),
    "lorcana": (aliases, scrydex),
    "onepiece": (aliases, scrydex),
    "riftbound": (aliases, scrydex),
}


def sources_for(game):
    return SOURCES.get(game) or (aliases,)


def find(game, rows, reader, review=None):
    """-> {set id: address} from every source for the game (the first source that answers a set wins); a source that raises is skipped."""
    out = {}
    for mod in sources_for(game):
        todo = [r for r in rows if r["id"] not in out]
        if not todo:
            break
        try:
            got = mod.find(reader, todo, game=game, review=review)
        except Exception:                                  # a source that answers oddly fills nothing today
            continue
        out.update({k: v for k, v in (got or {}).items() if v})
    return out
