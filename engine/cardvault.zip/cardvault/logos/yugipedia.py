"""Yu-Gi-Oh!: Yugipedia (yugipedia.com, MediaWiki; robots.txt allows everything for '*').  Each set has a page whose "Infobox set" names the set (en_name) and its cover picture (image =).
Taken only when  (a) the page's English name or title is the set's name after folding case / punctuation / possessives  AND  (b) the picture is the English / worldwide cover, never a Japanese /
Korean / Chinese one (file names end -EN, -NA, -EU, -AE, -OC or carry no language code)  AND  (c) the page is not a Japanese-only set (an `ocg` page with no `na_release_date`).
A page that matches the name but fails (b) or (c) goes to the review list.  The picture address is the file's direct address on ms.yugipedia.com (imageinfo)."""
import re

from . import mediawiki
from ..setfiling import _norm

API = "https://yugipedia.com/api.php"
OK_LANG = {"EN", "NA", "EU", "AE", "OC", "AU"}
NOT_A_COVER = re.compile(r"video.?game|manga|anime|poster|sleeve|playmat|token|wallpaper|new.?logo|tcg.?logo|wordmark|%21_tcg", re.I)     # (the game's own logo is no set logo)
_LANG = re.compile(r"(?:-|_|[a-z])([A-Z]{2})\d?\.(?:png|jpg|jpeg|webp|gif)$")                     # ...-DeckEN.png, ...-BoosterJP.png, ...-DeckNA.png


def fold(s):
    s = re.sub(r"[‘’']s\b", "", s or "")                 # possessives: HERO's Strike == HERO Strike
    return _norm(s)


def english_cover(filename):
    """True for a worldwide / English cover picture (language code EN / NA / EU / AE / OC or none)."""
    m = _LANG.search(filename or "")
    return not m or m.group(1).upper() in OK_LANG


NUMS = {"1": "One", "2": "Two", "3": "Three", "4": "Four", "5": "Five", "6": "Six", "7": "Seven", "8": "Eight", "9": "Nine", "10": "Ten"}


def variants(name):
    """The titles Yugipedia may give the TCG set called `name` on TCGplayer, most likely first.  Only deterministic renames: '(TCG)' for a name shared with an OCG set, 'X Structure Deck', 'Duelist Pack: X',
    'Astral Pack Two'.  Never a guess about another set."""
    n = (name or "").strip()
    out = [n, n + " (TCG)", n + " (TCG-EN)"]
    m = re.match(r"^(Structure Deck|Starter Deck|Speed Duel Starter Decks?|Duelist Pack|Premium Pack|Champion Pack|Astral Pack|Hobby League)\s*(\d+)?\s*:?\s*(.*)$", n)
    if m:
        kind, num, rest = m.groups()
        if kind in ("Structure Deck", "Starter Deck") and rest:
            out += [f"{rest} {kind}", f"{rest} {kind} (TCG)"]
        if kind == "Duelist Pack" and rest:
            out += [f"Duelist Pack: {rest}"]
        if kind == "Astral Pack" and num in NUMS:
            out += [f"Astral Pack {NUMS[num]}"]
    return list(dict.fromkeys(out))


def _page_ok(r, title, text):
    names = {fold(v) for v in variants(r["name"])}
    en = mediawiki.infobox_field(text, "en_name")
    return fold(title) in names or (en and fold(en) in names) or re.sub(r"\s*\(.*?\)\s*$", "", title) != title and fold(re.sub(r"\s*\(.*?\)\s*$", "", title)) in names


def find(reader, rows, game=None, review=None):
    asked = {}
    for r in rows:
        for v in variants(r["name"]):
            asked.setdefault(v, []).append(r)
    got = mediawiki.pages(reader, API, list(asked))
    picks, files = {}, []
    for r in rows:
        for v in variants(r["name"]):
            hit = got.get(v)
            if not hit or "disambig" in hit[1][:3000].lower() and "{{infobox" not in hit[1].lower():
                continue
            title, text = hit
            img = mediawiki.infobox_field(text, "image").replace("_", " ")
            if not img or NOT_A_COVER.search(img) or not _page_ok(r, title, text):
                continue
            explicit = _LANG.search(img)
            ja_only = bool(re.search(r"\|\s*(ja|jp)_release_date", text or "")) and not re.search(r"\|\s*(na|eu|oc|au|en)_release_date\s*=\s*\S", text or "")
            if (explicit and not english_cover(img)) or (not explicit and ja_only):
                if review is not None:
                    review.append({"game": game, "id": r["id"], "name": r["name"], "why": "Yugipedia page found but its picture is not clearly the English cover", "page": title, "file": img})
                break
            picks[r["id"]] = img
            files.append(img)
            break
    urls = mediawiki.file_urls(reader, API, files)
    return {sid: urls[f] for sid, f in picks.items() if f in urls}
