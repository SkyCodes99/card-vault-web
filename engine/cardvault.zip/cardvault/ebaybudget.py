"""One shared eBay search budget for every run of the day (the daily update's one eBay step, or a manual run), and the rotation that decides which items get searched.

Budget: eBay's Analytics API (getRateLimits) tells us the real daily Browse quota; it is read once a day, cached, and falls back to 5,000.  We spend 95% of it.  The ledger lives in the data
folder (ebay_budget.json, never in the repo) and is shared by every run: a run asks `grant(n)` for searches before it starts and `settle()` with what it really used.  eBay's day is UTC.
Rotation: `plan()` gives (1) owned/wishlisted items and fast-moving prices first, at most once a day each and at most a third of the run, then (2) a round-robin cursor over everything else,
so a full cycle covers every item.  Owned/wishlist lists are per-account (in the cloud), so the caller passes `priority` ids only when it has them; otherwise that tier is empty.
Keys are never read, stored or printed here - the caller passes an object that can fetch (see fetch_quota)."""
import json
import os
import time

SHARE, FALLBACK = 0.95, 5000
LIMITS_URL = "https://api.ebay.com/developer/analytics/v1_beta/rate_limit/?api_context=buy&api_name=browse"


def utc_day(now=None):
    return time.strftime("%Y-%m-%d", time.gmtime(now))


def _path(data):
    return os.path.join(data, "ebay_budget.json")


def _load(data):
    try:
        with open(_path(data), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _locked(data, fn):
    """Run fn(state) -> result under a short-lived lock file so two runs never overwrite each other's count; the state is saved afterwards."""
    lock, end = _path(data) + ".lock", time.time() + 30
    while True:
        try:
            os.close(os.open(lock, os.O_CREAT | os.O_EXCL))
            break
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock) > 60:      # a crashed run's stale lock
                    os.unlink(lock)
                    continue
            except OSError:
                pass
            if time.time() > end:
                raise RuntimeError("eBay budget ledger is busy")
            time.sleep(0.05)
    try:
        st = _load(data)
        out = fn(st)
        tmp = _path(data) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f)
        os.replace(tmp, _path(data))
        return out
    finally:
        try:
            os.unlink(lock)
        except OSError:
            pass


def parse_limit(j):
    """(limit, remaining) from a getRateLimits answer, or (None, None)."""
    try:
        for rl in j.get("rateLimits") or []:
            for res in rl.get("resources") or []:
                for rate in res.get("rates") or []:
                    if rate.get("limit"):
                        return int(rate["limit"]), (int(rate["remaining"]) if rate.get("remaining") is not None else None)
    except (TypeError, ValueError, AttributeError):
        pass
    return None, None


def fetch_quota(eb, http):
    """Ask eBay for the real quota with the app's own token (`eb` is ebayprices.Ebay, `http` the requests module).  Returns (limit, remaining) or (None, None)."""
    try:
        eb._auth()
        r = http.get(LIMITS_URL, headers={"Authorization": "Bearer " + eb.token}, timeout=30)
        return parse_limit(r.json()) if r.status_code == 200 else (None, None)
    except Exception:  # noqa: BLE001 - the fallback covers it
        return None, None


def _today(st, day, fetch):
    """Make sure the state is for `day` (reset the count, read the quota once)."""
    if st.get("day") != day:
        limit, remaining = fetch() if fetch else (None, None)
        st.update(day=day, quota=limit or st.get("quota") or FALLBACK, used=0)
        if limit and remaining is not None:
            st["used"] = max(0, limit - remaining)            # searches made by anything else today count too
    return st


def allowed(st):
    return int(st["quota"] * SHARE)


def grant(data, want, fetch=None, day=None):
    """Reserve up to `want` searches from today's shared budget; returns how many you may make (0 when the 95% is spent)."""
    day = day or utc_day()

    def go(st):
        _today(st, day, fetch)
        n = max(0, min(int(want), allowed(st) - st["used"]))
        st["used"] += n
        return n
    return _locked(data, go)


def settle(data, granted, used, day=None):
    """Give back the part of a grant the run did not use (it stopped early)."""
    day = day or utc_day()

    def go(st):
        if st.get("day") == day:
            st["used"] = max(0, st["used"] - max(0, granted - used))
    _locked(data, go)


def remaining(data, day=None):
    st = _load(data)
    return max(0, allowed(st) - st["used"]) if st.get("day") == (day or utc_day()) else None


def fast_movers(conn, day, pct=0.10, keep=500):
    """Ids whose latest asking-price move (table ask_history, last 14 days) is at least `pct`, biggest move first."""
    try:
        rows = conn.execute("SELECT card_id, day, usd FROM ask_history WHERE day >= date(?, '-14 day') ORDER BY card_id, day", (day,)).fetchall()
    except Exception:  # noqa: BLE001 - no history yet
        return []
    last, best = {}, {}
    for cid, _d, usd in rows:
        if cid in last and last[cid] > 0:
            best[cid] = abs(usd - last[cid]) / last[cid]       # the latest move per item
        last[cid] = usd
    return [c for m, c in sorted(((m, c) for c, m in best.items() if m >= pct), reverse=True)[:keep]]


def plan(data, items, n, day=None, priority=(), movers=()):
    """Pick up to n item ids. `items` = {id: last_checked ('' or 'YYYY-MM-DD HH:MM')}.  Tier 1 (priority, then movers) is limited to a third of n and to items not yet checked today;
    the rest is the round-robin: ids in sorted order starting after the saved cursor, wrapping, so every item is reached in turn.  The cursor is saved here."""
    day = day or time.strftime("%Y-%m-%d")
    out, seen = [], set()
    cap = n // 3
    for tier in (priority, movers):
        for cid in sorted((c for c in tier if c in items and (items[c] or "")[:10] < day), key=lambda c: items[c] or ""):
            if len(out) >= cap:
                break
            if cid not in seen:
                out.append(cid)
                seen.add(cid)
    order = sorted(items)

    def go(st):
        cur = st.get("cursor")
        start = next((i for i, c in enumerate(order) if cur is None or c > cur), 0)
        last = cur
        for cid in order[start:] + order[:start]:
            if len(out) >= n:
                break
            last = cid
            if cid not in seen:
                out.append(cid)
                seen.add(cid)
        st["cursor"] = last
    if order and n > 0:
        _locked(data, go)
    return out
