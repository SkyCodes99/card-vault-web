"""Who counts as a premium member on this device: THE ONE PLACE for that decision.
Today that means "on the owner's Exempt list" (Dev Tools > Exempt).  The account server owns the list and enforces it (skycloud_server.py, docs/server_requests.md);
the device only remembers what the server last said about THIS signed-in account, so the app can show the right limits and messages at once.
Safe fallback: when the server does not say (offline before any answer, an older server, signed out) nobody is exempt."""
PREF = "premium_exempt"          # True when the account server last said this account is on the Exempt list; cleared at sign-out
SERVER_KEY = "exempt"            # the field the server's /v1/usage (and /v1/me) answer carries


def signed_in(svc):
    return svc is not None and bool(svc.pget("cloud_token") and svc.pget("cloud_dek"))


def is_exempt(svc):
    return signed_in(svc) and svc.pget(PREF) is True


def is_premium(svc):
    """Premium features are on for an exempt account (a paid membership or Patreon pledge will join this check later)."""
    return is_exempt(svc)


def remember(svc, server_answer):
    """Keep the server's word about this account.  An answer without the field (older server) means 'not exempt'.  No answer at all: leave what is stored."""
    if svc is None or not isinstance(server_answer, dict):
        return
    svc.pset(PREF, True if server_answer.get(SERVER_KEY) is True else None)
