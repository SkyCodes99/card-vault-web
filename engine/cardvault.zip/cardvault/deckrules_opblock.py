"""One Piece block rotation.  Every card number belongs to a block (booster packs 1-4 = Block 1, 5-8 = Block 2 ...); Standard Regulation allows the blocks of its dated window, Extra Regulation
allows every block.  Cards listed as Block X (super parallels and the same numbers) stay legal, and a few older numbers were moved to a later block (the "override" lists).
All of it is data in cardvault/data/deck_rules.json ("onepiece" -> "blocks", with its official source links and the day it was written); the card list itself has no block marks."""
import datetime
import re

from .deckmsg import Msg

_OP = re.compile(r"^OP(\d{2})-")


def today():
    return datetime.date.today().isoformat()


def block_of(code, bl):
    """-> int block, 'X' (always legal) or None (this card number's block is not known)."""
    code = str(code).upper()
    for blk, codes in (bl.get("override") or {}).items():
        if code in codes:
            return int(blk)
    if code in (bl.get("always") or ()):
        return "X"
    m = _OP.match(code)
    if m:
        return (int(m.group(1)) - 1) // bl.get("perBlock", 4) + 1
    return (bl.get("sets") or {}).get(code.split("-")[0])


def window(bl, day):
    """The Standard window that holds this day -> dict, or None."""
    return next((w for w in bl.get("standard", ()) if w["from"] <= day <= w["to"]), None)


def check(numbers, names, fmt, bl, day=None):
    """numbers: card numbers in the deck; names: {number: card name}.  -> (problems, notes)."""
    if not bl:
        return [], ["Block rotation isn't checked: no block list is stored."]
    day = day or today()
    probs, notes = [], []
    if fmt == "extra":
        return probs, ["Extra Regulation allows every block, so no block is checked."]
    w = window(bl, day)
    if not w:
        return probs, [f"The stored Standard block windows don't cover {day}, so blocks aren't checked. The list needs an update."]
    allowed, unknown = set(w["blocks"]), set()
    for code in sorted(numbers):
        b = block_of(code, bl)
        if b is None:
            unknown.add(code.split("-")[0])
        elif b != "X" and b not in allowed:
            probs.append(Msg("opBlock", name=names.get(code, code), code=code, block=b, lo=min(allowed), hi=max(allowed), **{"from": w["from"], "to": w["to"]}))
    if unknown:
        notes.append("Block not known for cards from " + ", ".join(sorted(unknown)) + " (not checked).")
    return probs, notes
