"""Bring a collection in from another tracker's CSV export (TCGplayer, Collectr, Pokellector, or any spreadsheet with similar columns).

Columns are recognised by name; each row is matched to a card by set + number (best), then by name + number, then by a name that only one
card has.  Rows that can't be matched safely are written to a list instead of guessing."""
import csv
import re

from . import sealedclass
from .db import CONDITIONS, GRADERS

SYN = {
    "name": ("product name", "name", "card name", "card", "pokemon", "product"),
    "set": ("set name", "set", "expansion", "edition name", "set_name"),
    "number": ("card number", "number", "no", "no.", "#", "collector number", "card #", "card no", "local id", "card_number"),
    "qty": ("quantity", "qty", "count", "total quantity", "owned", "amount"),
    "condition": ("condition", "card condition", "cond"),
    "paid": ("average cost paid", "price paid", "purchase price", "cost", "paid", "price each", "purchase_price", "cost paid"),
    "variant": ("printing", "variance", "variant", "finish", "foil"),
    "grade": ("grade", "grading", "grade value"),
    "company": ("grading company", "grader", "grade company", "company"),
    "language": ("language", "lang"),
    "notes": ("notes", "note", "comments"),
    "card_id": ("card_id", "id"),
    "portfolio": ("portfolio name", "portfolio", "binder", "collection name"),
    "purchased": ("date added", "date purchased", "purchase date", "purchased", "date acquired"),
    "watch": ("watchlist", "wishlist", "on watchlist"),
}

COND_MAP = {"nm": "Near Mint", "near mint": "Near Mint", "mint": "Near Mint", "lp": "Lightly Played", "lightly played": "Lightly Played",
            "excellent": "Lightly Played", "mp": "Moderately Played", "moderately played": "Moderately Played", "good": "Moderately Played",
            "hp": "Heavily Played", "heavily played": "Heavily Played", "poor": "Heavily Played", "dmg": "Damaged", "damaged": "Damaged"}


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower().replace("é", "e")).strip()


def norm_number(s):
    s = (s or "").strip().split("/")[0].strip()
    return str(int(s)) if s.isdigit() else s.lower()


def detect_format(headers):
    h = {norm(x) for x in headers}
    if {"portfolio name", "product name"} & h and "average cost paid" in h:
        return "Collectr"
    if "product name" in h and ("set name" in h or "printing" in h):
        return "TCGplayer"
    if "set" in h and "number" in h and "name" in h:
        return "Pokellector / generic list"
    return "Generic CSV"


def map_columns(headers):
    out = {}
    lowered = {norm(x): x for x in headers}
    for field, names in SYN.items():
        for n in names:
            if norm(n) in lowered:
                out[field] = lowered[norm(n)]
                break
    return out


class Matcher:
    def __init__(self, vault):
        self.ids = set()
        self.by_set_num, self.by_name_num, self.by_name = {}, {}, {}
        sets = {r["id"]: norm(r["name"]) for r in vault.sets()}
        for r in vault.conn.execute("SELECT id, set_id, local_id, name FROM cards"):
            self.ids.add(r["id"])
            num, nm = norm_number(str(r["local_id"])), norm(r["name"])
            self.by_set_num.setdefault((sets.get(r["set_id"], ""), num), []).append(r["id"])
            self.by_name_num.setdefault((nm, num), []).append(r["id"])
            self.by_name.setdefault(nm, []).append(r["id"])

    def find(self, name, set_name, number, card_id=""):
        if card_id and card_id in self.ids:
            return card_id, ""
        n, s, num = norm(re.sub(r"\s*[\(\[].*?[\)\]]\s*", " ", name or "")), norm(set_name), norm_number(number)
        if s and num:
            hits = self.by_set_num.get((s, num), [])
            if len(hits) == 1:
                return hits[0], ""
            # names of the same set differ slightly between trackers: accept a set whose name contains the other
            alt = [i for (sn, nu), ids in self.by_set_num.items() if nu == num and sn and (s in sn or sn in s) for i in ids]
            if len(alt) == 1:
                return alt[0], ""
            if n:
                both = [i for i in alt + hits if i in self.by_name_num.get((n, num), [])]
                if len(set(both)) == 1:
                    return both[0], ""
        if n and num:
            hits = self.by_name_num.get((n, num), [])
            if len(hits) == 1:
                return hits[0], ""
            if hits:
                return None, "several cards share that name and number - set name needed"
        if n:
            hits = self.by_name.get(n, [])
            if len(hits) == 1:
                return hits[0], ""
            if hits:
                return None, f"{len(hits)} cards have that name"
        return None, "no matching card"


def _to_float(x):
    try:
        return float(re.sub(r"[^0-9.\-]", "", str(x))) if str(x).strip() not in ("", "None") else None
    except ValueError:
        return None


def read_rows(path, vault):
    """Parse the file -> {'format', 'rows': [{...fields, 'card_id'}], 'unmatched': [(row_text, reason)], 'columns': map}"""
    with open(path, newline="", encoding="utf-8-sig") as f:
        text = f.read()
    # some exports start with a title line before the header
    lines = text.splitlines()
    start = next((i for i, ln in enumerate(lines[:6]) if map_columns(next(csv.reader([ln]), [])).get("name") or
                  map_columns(next(csv.reader([ln]), [])).get("card_id")), 0)
    rdr = csv.DictReader(lines[start:])
    cols = map_columns(rdr.fieldnames or [])
    fmt = detect_format(rdr.fieldnames or [])
    m = Matcher(vault)
    rows, bad, sealed = [], [], []
    for raw in rdr:
        g = lambda k: (raw.get(cols[k]) or "").strip() if k in cols else ""
        if not any(raw.values()):
            continue
        cid, why = m.find(g("name"), g("set"), g("number"), g("card_id"))
        label = f"{g('name') or g('card_id')} | {g('set')} | {g('number')}"
        watch = norm(g("watch")) in ("true", "yes", "1", "y")
        qty = int(_to_float(g("qty")) or 0) if g("qty") else 1
        if not cid:
            # a sealed product (booster box, tin, bundle...) has no card number: it goes to Sealed products instead of the unmatched list
            if g("name") and not g("number") and sealedclass.kind_of(g("name"), vault.game) not in ("Loose card / energy", "Code card", "Oversize / promo card"):
                if qty > 0:
                    sealed.append({"name": g("name"), "qty": qty, "paid": _to_float(g("paid")), "purchased": g("purchased")[:10], "portfolio": g("portfolio"), "notes": g("notes")})
                    continue
            bad.append((label, why))
            continue
        if qty <= 0 and not watch:
            qty = 1
        grade_txt, company = g("grade"), g("company")
        graded = False
        if grade_txt and norm(grade_txt) not in ("ungraded", "raw", "none", "na", "n a"):
            parts = grade_txt.split()
            if parts and parts[0].upper() in GRADERS:
                company, grade_txt = parts[0].upper(), " ".join(parts[1:])
            graded = bool(company or grade_txt)
            if graded and not company:
                company = "Other"
        cond = COND_MAP.get(norm(g("condition")), g("condition") if g("condition") in CONDITIONS else "Near Mint")
        rows.append({"card_id": cid, "qty": max(qty, 1), "condition": cond, "graded": graded, "company": company if graded else "",
                     "grade": grade_txt if graded else "", "paid": _to_float(g("paid")), "variant": g("variant"), "language": g("language") or "English",
                     "notes": g("notes"), "label": label, "portfolio": g("portfolio"), "purchased": g("purchased")[:10], "wish": watch and qty <= 0})
    return {"format": fmt, "rows": rows, "unmatched": bad, "columns": cols, "sealed": sealed}


def import_rows(vault, rows, label="Imported from another tracker", sealed=()):
    """Add the matched rows to the collection as ONE undoable action.  Returns (copies added, action)."""
    n = 0
    with vault.action(f"{label} ({len(rows) + len(sealed)} rows)") as act:
        for r in sealed:
            from .db import new_uuid, now_iso, today
            pf = vault._pf_by_name(r["portfolio"]) if r["portfolio"] and norm(r["portfolio"]) != "main" else None
            vault.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                               (new_uuid(), vault.user_id, vault.game, "", r["name"], r["qty"], r["paid"], r["purchased"] or today(), "", r["notes"], vault.target_pf if pf is None else pf, now_iso()))
            n += r["qty"]
        for r in rows:
            if r.get("wish"):
                if r["card_id"] not in vault.wishlist_ids():
                    vault.toggle_wishlist(r["card_id"])
                continue
            variant = r["variant"]
            if not variant or norm(variant) in ("normal", "non foil", "nonfoil", "unlimited"):
                variant = vault.default_variant(r["card_id"]) if not variant else "Normal"
            elif norm(variant) in ("foil", "holofoil", "holo"):
                variant = "Holo"
            elif "reverse" in norm(variant):
                variant = "Reverse Holo"
            pf = vault._pf_by_name(r["portfolio"]) if r.get("portfolio") and norm(r["portfolio"]) != "main" else None
            vault.add_lot(r["card_id"], variant, "Graded" if r["graded"] else r["condition"], r["qty"], r["graded"], r["company"], r["grade"],
                          r["paid"], r["notes"], r["language"], purchased=r.get("purchased") or "", portfolio=pf)
            n += r["qty"]
        vault.record_price_history([r["card_id"] for r in rows if not r.get("wish")])
    return n, act
