"""Free daily prices for Magic: The Gathering (roadmap 1.2), shown NEXT TO the TCGplayer and eBay prices, never over them.

Two free bulk sources, read through the shared polite Fetcher (cardvault/sources):
    Scryfall  bulk "default_cards" (jsonl.gz): usd / usd_foil / usd_etched / eur / eur_foil / eur_etched / tix per card, found by its TCGplayer product id.
    MTGJSON   AllPricesToday + TcgplayerSkus (both .gz): retail prices from Card Kingdom, Cardmarket, Manapool and Cardhoarder; the card's
              MTGJSON uuid is turned into its TCGplayer product id with TcgplayerSkus.  (MTGJSON's TCGplayer column repeats what we already have, so it is skipped.)

Where it goes - one small table in the game's cards.db; cards.price_usd / price_kind / price_updated (TCGplayer, eBay) are never touched:
    source_prices(card_id, source, vendor, finish, currency, price, day)   source = 'scryfall' | 'mtgjson'; vendor = who the number is from (tcgplayer, cardmarket, mtgo,
    cardkingdom, manapool, cardhoarder); finish = normal | foil | etched | tix; day = the day the number is from.
Provenance: the row itself carries source + day, and its link is the source's template (provenance.SOURCES 'scry' / 'mtgj').  Nothing is written to the
provenance table's single 'price' row, because that row describes cards.price_usd (TCGplayer / eBay).
Cards are matched by cards.tcg_id (= the TCGplayer product id for Magic).  A source with no usable rows leaves the old rows alone."""
import gzip
import io
import json
import sqlite3
import zlib

from . import provenance

SCHEMA = """
CREATE TABLE IF NOT EXISTS source_prices(
    card_id TEXT NOT NULL, source TEXT NOT NULL, vendor TEXT NOT NULL, finish TEXT NOT NULL, currency TEXT, price REAL, day TEXT,
    PRIMARY KEY(card_id, source, vendor, finish)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS source_prices_source ON source_prices(source);
"""
SOURCE_CODE = {"scryfall": "scry", "mtgjson": "mtgj"}
SCRYFALL_FIELDS = (                                  # card["prices"] key -> (vendor, finish, currency)
    ("usd", "tcgplayer", "normal", "USD"), ("usd_foil", "tcgplayer", "foil", "USD"), ("usd_etched", "tcgplayer", "etched", "USD"),
    ("eur", "cardmarket", "normal", "EUR"), ("eur_foil", "cardmarket", "foil", "EUR"), ("eur_etched", "cardmarket", "etched", "EUR"),
    ("tix", "mtgo", "tix", "TIX"),
)
MTGJSON_VENDORS = ("cardkingdom", "cardmarket", "manapool", "cardhoarder")        # (tcgplayer is what we already read directly)
WS = " " + chr(13) + chr(10) + chr(9)                     # JSON white space
MIN_ROWS = 1000                                      # a real file has tens of thousands; fewer means a bad download and the old rows stay


def ensure(conn):
    conn.executescript(SCHEMA)
    provenance.ensure(conn)


GZ_MAGIC = bytes([0x1F, 0x8B])


def is_gz(body):
    return body[:2] == GZ_MAGIC


def unzip(body):
    """Bytes of a .gz file (or already-plain bytes) -> plain bytes."""
    return gzip.decompress(body) if is_gz(body) else body


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f >= 0 else None


# ---------------------------------------------------------------------------------------------------------------------------- Scryfall
def scryfall_rows(body, day):
    """jsonl(.gz) of Scryfall cards -> iterator of (tcg_id, vendor, finish, currency, price, day).  An etched card keeps its own TCGplayer id."""
    for line in io.TextIOWrapper(io.BytesIO(unzip(body)), encoding="utf-8"):
        line = line.strip().rstrip(",")
        if not line.startswith("{"):
            continue
        try:
            c = json.loads(line)
        except ValueError:
            continue
        tid, etched_id, prices = c.get("tcgplayer_id"), c.get("tcgplayer_etched_id"), c.get("prices") or {}
        for key, vendor, finish, cur in SCRYFALL_FIELDS:
            p = _num(prices.get(key))
            if p is None:
                continue
            owner = etched_id if finish == "etched" and etched_id else tid
            if owner:
                yield str(owner), vendor, finish, cur, p, day


# ---------------------------------------------------------------------------------------------------------------------------- MTGJSON
def iter_data(body):
    """Stream the items of {"meta": ..., "data": {key: value, ...}} (a .gz of any size) without holding the whole parsed file: yields (key, value)."""
    dec = zlib.decompressobj(31) if is_gz(body) else None
    raw, jd = io.BytesIO(body), json.JSONDecoder()
    st = {"text": "", "pending": b"", "eof": False}

    def more():
        chunk = raw.read(1 << 20)
        if not chunk:
            st["eof"] = True
            return False
        buf = st["pending"] + (dec.decompress(chunk) if dec else chunk)
        try:
            st["text"] += buf.decode("utf-8")
            st["pending"] = b""
        except UnicodeDecodeError as e:                      # a multi-byte character split across two chunks
            st["text"] += buf[:e.start].decode("utf-8", "replace")
            st["pending"] = buf[e.start:]
        return True

    def skip(pos, chars=WS):
        """First position at or after pos that is not one of chars, reading on as needed (len(text) at the end of the file)."""
        while True:
            t = st["text"]
            while pos < len(t) and t[pos] in chars:
                pos += 1
            if pos < len(t) or not more():
                return pos

    while '"data":' not in st["text"]:
        if not more():
            return
    pos = skip(st["text"].index('"data":') + 7)
    if pos >= len(st["text"]) or st["text"][pos] != "{":
        return
    pos += 1
    while True:
        pos = skip(pos, WS + ",")
        text = st["text"]
        if pos >= len(text) or text[pos] == "}":
            return
        try:
            key, end = jd.raw_decode(text, pos)
            end = skip(end)
            text = st["text"]
            if end >= len(text) or text[end] != ":":
                raise ValueError("need more")
            vstart = skip(end + 1)
            text = st["text"]
            val, vend = jd.raw_decode(text, vstart)
            if vend >= len(text) and not st["eof"]:         # a bare number may continue in the next chunk
                raise ValueError("need more")
        except ValueError:
            if not more():
                return
            continue
        yield key, val
        pos = vend
        if pos > (4 << 20):                                  # keep the working text small
            st["text"], pos = st["text"][pos:], 0


def mtgjson_prices(body):
    """AllPricesToday -> {uuid: [(vendor, finish, currency, price, day), ...]} (retail only, the newest day of each series)."""
    out = {}
    for uuid, v in iter_data(body):
        rows = []
        for vendor in MTGJSON_VENDORS:
            for plat in ("paper", "mtgo"):
                blk = ((v or {}).get(plat) or {}).get(vendor)
                if not blk:
                    continue
                for finish, series in (blk.get("retail") or {}).items():
                    if not series:
                        continue
                    day = max(series)
                    p = _num(series[day])
                    if p is not None:
                        rows.append((vendor, finish, blk.get("currency") or "USD", p, day))
        if rows:
            out[uuid] = rows
    return out


def mtgjson_product_ids(body):
    """TcgplayerSkus -> {uuid: tcgplayer product id} (the first SKU's product; all SKUs of one card share it)."""
    out = {}
    for uuid, skus in iter_data(body):
        for s in skus or ():
            pid = s.get("productId")
            if pid:
                out[uuid] = str(pid)
                break
    return out


def mtgjson_rows(prices_body, skus_body):
    """-> (iterator of (tcg_id, vendor, finish, currency, price, day), stats {uuids, matched})."""
    prices, ids = mtgjson_prices(prices_body), mtgjson_product_ids(skus_body)
    stats = {"entries": len(prices), "with_tcg_id": sum(1 for u in prices if u in ids)}

    def gen():
        for uuid, rows in prices.items():
            tid = ids.get(uuid)
            if tid:
                for vendor, finish, cur, p, day in rows:
                    yield tid, vendor, finish, cur, p, day
    return gen(), stats


# ---------------------------------------------------------------------------------------------------------------------------- writing
def write(conn, source, rows, game_cards=None):
    """Store rows (tcg_id, vendor, finish, currency, price, day) for cards in this list, as `source`.  Returns
    {rows, cards, entries, entries_matched}.  The old rows of this source are replaced only when the new file gave at least MIN_ROWS usable rows."""
    ensure(conn)
    by_tcg = {}
    for cid, tid in conn.execute("SELECT id, tcg_id FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''"):
        by_tcg.setdefault(str(tid), cid)
    total = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
    out, seen_ids, matched_ids = {}, set(), set()
    for tid, vendor, finish, cur, price, day in rows:
        seen_ids.add(tid)
        cid = by_tcg.get(tid)
        if cid is None:
            continue
        matched_ids.add(tid)
        out.setdefault((cid, source, vendor, finish), (cur, price, day))
    cards = {k[0] for k in out}
    res = {"source": source, "rows": len(out), "cards": len(cards), "cards_total": total, "entries": len(seen_ids), "entries_matched": len(matched_ids),
           "written": False}
    if len(out) < MIN_ROWS:
        return res
    with conn:
        conn.execute("DELETE FROM source_prices WHERE source=?", (source,))
        conn.executemany("INSERT INTO source_prices(card_id,source,vendor,finish,currency,price,day) VALUES(?,?,?,?,?,?,?)",
                         [(k[0], k[1], k[2], k[3], v[0], v[1], v[2]) for k, v in out.items()])
    res["written"] = True
    return res


def for_card(conn, card_id):
    """What an item detail would list next to TCGplayer / eBay: [{source, vendor, finish, currency, price, day}] (empty when the table is not there yet)."""
    try:
        return [dict(zip(("source", "vendor", "finish", "currency", "price", "day"), r)) for r in conn.execute(
            "SELECT source, vendor, finish, currency, price, day FROM source_prices WHERE card_id=? ORDER BY source, vendor, finish", (str(card_id),))]
    except sqlite3.Error:
        return []
