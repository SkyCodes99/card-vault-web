"""Hot Wheels: the sidebar filters, read from each car's stated facts (raw ext written by cardvault/hotwheels.py).  Pure text rules, used by cardvault/gamefacets.py.

A filter value is always a word the source states: the colour family is the plain colour word inside the stated colour ("Metalflake dark blue" -> Blue), the paint finish the finish word
("Spectraflame"), the wheel type the wheel name in the stated wheels ("Real Rider wheels with ..." -> Real Riders).  A car whose words name none of them has no value in that filter."""
import re

_FAMILIES = (("Red", r"red|maroon|burgundy|crimson"), ("Blue", r"blue|navy|aqua|teal|turquoise"), ("Yellow", r"yellow"), ("Green", r"green|lime|olive|antifreeze|mint"), ("Black", r"black"),
             ("White", r"white|ivory|cream"), ("Silver", r"silver|chrome|zamac|unpainted"), ("Gold", r"gold|golden|champagne"), ("Orange", r"orange"), ("Purple", r"purple|violet|plum|lavender|magenta|aubergine"),
             ("Pink", r"pink|rose|salmon"), ("Gray", r"gr[ae]y|gunmetal|charcoal|primer"), ("Brown", r"brown|tan|beige|bronze|copper"))
_FINISHES = (("Spectraflame", r"spectraflame"), ("Metalflake", r"metalflake"), ("Metallic", r"metallic"), ("Pearl", r"pearl"), ("Satin", r"satin"), ("Matte", r"\bmatte\b|\bflat\b"), ("Chrome", r"chrome"),
             ("ZAMAC (unpainted)", r"zamac|unpainted"), ("Enamel", r"enamel"), ("Gloss", r"gloss"), ("Translucent", r"translucent|\bclear\b"))
# Wheel names as the source pages write them, most telling first: "Real Rider wheels with 5-spoke rims" is a Real Rider, "Open-Hole 5-Spoke" is not a plain 5-spoke.
_WHEELS = (("Real Riders", r"\breal riders?\b"), ("Neo-Classics Redline", r"neo-classics?"), ("Redline (bearing)", r"^bearing$"), ("Redline (capped)", r"^capped$"), ("Redline (through-hole)", r"^through-hole$"),
           ("Redline", r"\bredline\b"), ("AeroDisc", r"aerodisc"), ("Open-hole 5-spoke (OH5)", r"open-hole 5-spoke|\boh-?5\b"), ("Trapezoid 5-spoke (TRAP5)", r"trapezoid 5-spoke|\btrap-?5\b"),
           ("PR5", r"\bpr-?5\b"), ("RA6", r"\bra-?6\b"), ("J5", r"\bj-?5\b"), ("MC5", r"\bmc-?5\b"), ("Y5", r"\by-?5\b"), ("BAJA5", r"\bbaja-?5\b"), ("Off-road", r"off-road"),
           ("Deep-dish 8-spoke", r"deep dish 8-spoke"), ("Lipped 4-spoke (L4)", r"lipped 4-spoke|\bl ?4(?:-spoke)?\b"), ("3-spoke", r"\b3-spoke\b"), ("5-spoke (5SP)", r"\b5-spoke\b|\b5sp\b"),
           ("10-spoke (10SP)", r"\b10-spoke\b|\b10sp\b"), ("Cafe Racer", r"caf[eé] racer"), ("Retro Slot", r"retro slot"), ("Lace", r"\blace\b"), ("Sawblade", r"sawblades?"), ("Ultra Hots", r"ultra hots?"))


def _first(table, text):
    """The first name of the table whose words are in the text (the table is ordered most telling first)."""
    low = str(text or "").lower().strip()
    return next(([name] for name, rx in table if re.search(rx, low)), [])


def colour_family(e, c):
    """The LAST plain colour word of the stated body colour ('Spectraflame dark blue' -> Blue; 'red' -> Red)."""
    low = str(e.get("Colour") or "").lower()
    hits = [(m.start(), name) for name, rx in _FAMILIES for m in re.finditer(r"\b(?:%s)\b" % rx, low)]
    return [max(hits)[1]] if hits else []


def wheel_type(e, c):
    """A Redline page states the type itself ('Bearing, Capped': both were made); the other pages name the wheel inside their wheels sentence."""
    if e.get("Wheel type"):
        return [name for part in str(e["Wheel type"]).split(",") for name in _first(_WHEELS, part)]
    return _first(_WHEELS, e.get("Wheels"))


def _one(key):
    return lambda e, c: [str(e[key]).strip()] if e.get(key) else []


def _each(key):
    return lambda e, c: [x.strip() for x in str(e.get(key) or "").split(",") if x.strip()]


FACETS = [("line", "Line (Treasure Hunt, Red Line Club ...)", _one("Line")), ("year", "Year", _one("Year")), ("casting", "Casting (the base model)", _one("Casting")),
          ("designer", "Designer", _each("Designer")), ("series", "Series", _one("Series")), ("case", "Case letter", _each("Case")), ("colour", "Colour", colour_family),
          ("finish", "Paint finish", lambda e, c: _first(_FINISHES, e.get("Colour"))), ("wheel", "Wheel type", wheel_type),
          ("base", "Base (metal or plastic)", lambda e, c: [str(e["Base"]).capitalize()] if e.get("Base") else []), ("country", "Country made", _each("Made in"))]
