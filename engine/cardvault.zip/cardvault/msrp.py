"""Retail price (MSRP) of products - roadmap "Retail price (MSRP), clearly labelled".

NOT a market price: it is what the maker or its shop asked at launch.  It lives in its own table, so no total, Site price or cost to complete ever reads it:
    msrp(card_id PK, amount, currency, source, ref, day)     one row per product that has a plainly stated retail price (Funko, toys, consoles, sealed boxes - never single cards)
The price is read only where the catalog already holds a value a maker's shop, a retailer's product page or a wiki stated plainly (price_kind 'retail price...', or a 'Retail price' fact in the
entry's own details).  Anything doubtful (a sale / clearance tag, a price that does not parse) is NOT stored: it goes to the review file docs/picture_previews/msrp_review_<game>.json.

    python -I -m cardvault.msrp [game ...] [--apply]        dry run by default; --apply snapshots the game first (safetynet) and then writes.  The daily job can call run(data_dir, games, apply=True)."""
import datetime
import json
import os
import re
import sqlite3
import sys

SCHEMA = "CREATE TABLE IF NOT EXISTS msrp(card_id TEXT PRIMARY KEY, amount REAL NOT NULL, currency TEXT NOT NULL, source TEXT, ref TEXT, day TEXT)"
SYMBOL = {"USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥"}
_DOUBT = re.compile(r"sale|clearance|discount|outlet|used|resale|preorder-price", re.I)
_YEN = re.compile(r"^\s*([\d,]+)\s*(?:円|yen|JPY)", re.I)
_USD = re.compile(r"^\s*(?:US)?\$\s*([\d,]+(?:\.\d{1,2})?)\s*(?:USD)?\s*$|^\s*([\d,]+(?:\.\d{1,2})?)\s*USD\s*$", re.I)


def parse_text(txt):
    """'1980円' -> (1980.0, 'JPY'); '$24.99' -> (24.99, 'USD'); anything else -> None (doubtful: left for review)."""
    m = _YEN.match(txt or "")
    if m:
        return float(m.group(1).replace(",", "")), "JPY"
    m = _USD.match(txt or "")
    if m:
        return float((m.group(1) or m.group(2)).replace(",", "")), "USD"
    return None


def ensure(conn):
    conn.execute(SCHEMA)


def lookup(conn, ids):
    """{card_id: {"amount", "currency", "source", "ref", "day"}} for the ids that have a retail price (the list's table may not exist yet: then {})."""
    ids = [str(i) for i in ids]
    out = {}
    try:
        for i in range(0, len(ids), 500):
            part = ids[i:i + 500]
            for r in conn.execute(f"SELECT card_id, amount, currency, source, ref, day FROM msrp WHERE card_id IN ({','.join('?' * len(part))})", part):
                out[r[0]] = {"amount": r[1], "currency": r[2], "source": r[3] or "", "ref": r[4] or "", "day": r[5] or ""}
    except sqlite3.Error:
        return {}
    return out


def harvest(conn):
    """-> (found [(id, amount, currency, source, ref)], review [{id, name, why, text}]) from what the catalog already states."""
    found, review = [], []
    for cid, name, usd, kind, raw in conn.execute("SELECT id, name, price_usd, price_kind, raw FROM cards WHERE price_kind LIKE 'retail price%' OR raw LIKE '%Retail price%'"):
        try:
            r = json.loads(raw) if raw else {}
        except ValueError:
            r = {}
        ext = r.get("ext") or {}
        ref = r.get("url") or ext.get("Shop page") or ext.get("Wiki page") or ""
        shop = ("wiki" if "wiki" in ref else "shop") if ref else ("wiki" if ext.get("Retail price") else "shop")
        got, text = None, ""
        if kind and kind.startswith("retail price") and usd is not None:
            got, text = (float(usd), "USD"), f"{usd} ({kind})"
        elif ext.get("Retail price"):
            text = str(ext["Retail price"])
            got = parse_text(text)
        if not got or got[0] <= 0:
            review.append({"id": cid, "name": name, "why": "price text not understood", "text": text})
        elif any(_DOUBT.search(str(t)) for t in (r.get("tags") or [])):
            review.append({"id": cid, "name": name, "why": "sale / clearance tag: the price may not be the launch price", "text": text})
        else:
            found.append((cid, got[0], got[1], shop, ref))
    return found, review


def run(data_dir, games, apply=False, out=print):
    """Read every named game; with apply=True snapshot it first and store.  -> {game: {"before", "after", "review"}}."""
    from . import safetynet
    from .db import game_dir
    result = {}
    for g in games:
        path = os.path.join(game_dir(data_dir, g), "cards.db")
        if not os.path.exists(path):
            continue
        conn = sqlite3.connect(path)
        try:
            try:
                before = conn.execute("SELECT COUNT(*) FROM msrp").fetchone()[0]
            except sqlite3.Error:
                before = 0
            found, review = harvest(conn)
            if apply and found:
                safetynet.snapshot(data_dir, g)
                ensure(conn)
                day = datetime.date.today().isoformat()
                conn.executemany("INSERT OR REPLACE INTO msrp(card_id, amount, currency, source, ref, day) VALUES(?,?,?,?,?,?)", [(c, a, cur, s, ref, day) for c, a, cur, s, ref in found])
                conn.commit()
                after = conn.execute("SELECT COUNT(*) FROM msrp").fetchone()[0]
            else:
                after = before
            if review:
                d = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs", "picture_previews")
                if apply:
                    os.makedirs(d, exist_ok=True)
                    with open(os.path.join(d, f"msrp_review_{g}.json"), "w", encoding="utf-8") as f:
                        json.dump(review, f, ensure_ascii=False, indent=1)
            result[g] = {"before": before, "after": after, "would_store": len(found), "review": len(review)}
            out(f"{g}: before {before}, after {after}, found {len(found)}, review {len(review)}")
        finally:
            conn.close()
    return result


if __name__ == "__main__":
    from .paths import release_data_dir
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    games = args or ["accessories", "beyblade", "chomps", "dumpsterfires", "youtooz"]
    run(release_data_dir(), games, apply="--apply" in sys.argv)
