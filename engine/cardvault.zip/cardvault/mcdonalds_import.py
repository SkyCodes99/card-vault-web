"""McDonald's Happy Meal toys: reads the Wikipedia article text (plain extract, CC BY-SA 4.0) of 'Teenie Beanies' into promotions and toys.  Pure text rules, no network (tools/import_mcdonalds.py fetches).
A toy's name, group and country are only what the article lists / states; the number in a set is the number the article states ("included 12 Beanies", "The set includes 8 styles"), never a count of what was parsed."""
import html
import re

COUNTRIES = {"United Kingdom", "Ireland", "United States", "Canada", "Mexico", "Germany"}
_HEAD = re.compile(r"^==\s*([^=].*?)\s*==\s*$")
_TOTAL = re.compile(r"(?:included|includes|produced in all|there were)\s+(\d+)|(\d+)\s+different|(?:set includes|consisted of)\s+(\d+)", re.I)


_WORDS = {"eight": 8, "ten": 10, "twelve": 12, "sixteen": 16}


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def _is_item(line):
    return bool(re.search(r" the |\(", line)) and not line.endswith(":") and len(line) < 80 and ". " not in line


def parse_sections(text):
    """[(heading, prose, [(group, raw toy line)])] for each '== X ==' section that lists toys."""
    out, cur, group = [], None, ""
    for line in text.splitlines():
        h = _HEAD.match(line)
        if h:
            cur, group = [h.group(1), [], []], ""
            out.append(cur)
            continue
        s = line.strip().replace("U.S.A. ", "USA ")
        if cur is None or not s or line.startswith("="):
            continue
        if len(s) < 45 and ". " not in s and not s.endswith(".") and (s.endswith(":") or not _is_item(s)):
            group = s.rstrip(":").strip()
        elif _is_item(s):
            cur[2].append((group, s))
        else:
            cur[1].append(s)
    return [(h, " ".join(p), t) for h, p, t in out if t]


def toy_of(raw):
    """'Britannia (United Kingdom)' -> ('Britannia', country, ''); 'Boomer the Dog (original Beanie Babies)' -> name + note; the article's own words."""
    m = re.match(r"^(.*?)\s*\((.*)\)?\s*$", raw)
    if not m:
        return raw.rstrip(")").strip(), "", ""
    name, inner = m.group(1).strip(), m.group(2).rstrip(")").strip()
    return (name, inner, "") if inner in COUNTRIES else (name, "", inner)


def promotion_of(heading, prose):
    """(name, year, stated total or 0) from a section heading + its prose."""
    y = re.search(r"\b(?:19|20)\d{2}\b", heading)
    year = y.group(0) if y else ""
    if heading.startswith("Teenie Boos"):
        name = "Teenie Beanie Boos " + year
    elif heading.startswith("Teeny Tys"):
        name = "Teeny Tys " + year
    else:
        name = "Teenie Beanies " + year
    t = _TOTAL.search(prose)
    w = re.search(r"the (twelve|ten|sixteen|eight) that came out", prose)
    total = int(next(g for g in t.groups() if g)) if t else _WORDS[w.group(1)] if w else 0
    return name, year, total



# ------------------------------------------------------------------------------------------------ the Pokemon TCG McDonald's promo cards (TCGplayer's product records via tcgcsv.com, read by tools/import_mcdonalds.py)
# The SAME cards are in the Pokemon list (its TCGdex sets "McDonald's Collection <year>", see cardvault/setimages.py): each one here names that set and number ('pokemon_link') so the two can
# be linked; nothing of the Pokemon list is read or changed.  TCGdex itself is not read here: its robots.txt disallows every path (checked 2026-11-14).
_SUFFIX = re.compile(r"\s+-\s+\d+/\d+\s*$")
BRAND_PTCG = "Pokémon Trading Card Game"
POKEMON_LIST_YEARS = ("2011", "2012", "2014", "2015", "2016", "2017", "2018", "2019", "2021", "2022", "2023", "2024")      # the years the Pokemon list has a "McDonald's Collection" set
# Owner quiz 2026-11-15: the 2021 25th Anniversary cards are "2 separate items" - holo and non-holo.  TCGplayer keeps ONE product per card there and states the printings in its price records
# (subTypeName "Normal" / "Holofoil", tcgcsv.com .../<group>/prices), so each card that states both becomes two items.  The non-holo one KEEPS the card's old id: the old item offered only the
# "Normal" printing (TCGplayer's word for non-holo), so copies recorded on it are non-holo copies.  The holo one is "<old id>-holo"; a copy on the old id whose printing says Holo belongs there and
# moves (cardvault/db.py _apply_variant_moves, from the list's meta 'variant_moves').  The one product picture shows one card for both printings, so it is shown on neither ("No picture yet").
SPLIT_PRINTINGS = {"pokemon-tcg-mcdonalds-2021"}
PRINTINGS = (("Normal", "Non-Holo", "", {"normal": True}, "Normal"), ("Holofoil", "Holo", "-holo", {"holo": True}, "Holo"))      # (TCGplayer subtype, printing shown, id tail, variants, Pokemon list variant)
SHARED_PICTURE = "TCGplayer has one product picture for both printings (Holo and Non-Holo); a picture two items share is not shown"


def tcg_number(product):
    """('5', '12') from the product's stated card number '005/012', else None."""
    v = next((str(e.get("value") or "") for e in product.get("extendedData", []) if e.get("name") == "Number"), "")
    m = re.match(r"^0*(\d+)\s*/\s*0*(\d+)$", v.strip())
    return (m.group(1), m.group(2)) if m else None


def tcg_name(product):
    """'Alomomola - 5/12' -> 'Alomomola' (TCGplayer adds the number to some names)."""
    return _SUFFIX.sub("", html.unescape(product.get("name") or "")).strip()


def pokemon_promotion(group, day):
    """One promotion record from a TCGplayer group: the year in its name, else the year TCGplayer published it."""
    y = re.search(r"\b(?:19|20)\d{2}\b", group.get("name", "")) or re.search(r"\b(?:19|20)\d{2}\b", group.get("publishedOn") or "")
    year = y.group(0) if y else ""
    return {"id": "pokemon-tcg-mcdonalds-" + year, "name": "Pokémon TCG: " + html.unescape(group["name"]), "year": year, "country": "", "brand": BRAND_PTCG, "total": 0,
            "source": "tcgplayer-mc", "url": "https://tcgcsv.com/tcgplayer/3/%s/products" % group["groupId"], "read": day, "tcg_group": group["groupId"],
            "pokemon_set": ("McDonald's Collection " + year) if year in POKEMON_LIST_YEARS else ""}


def pokemon_cards(group, products, day, printings=None):
    """-> (promotion, [toy]) for one McDonald's promo set.  A card is a product with a stated number 'n/total'; sealed packs (no number) are not items.  The name and number are what
    TCGplayer states.  A picture is only proposed here ('candidate'): the importer checks its bytes before it is kept.  The set size is the number printed on the cards (the '/12'), and only
    when every card states the same one and no number is listed twice.  printings: {productId: [TCGplayer price subtypes]} - read only for SPLIT_PRINTINGS (above)."""
    promo = pokemon_promotion(group, day)
    toys, totals = [], set()
    for p in products:
        num = tcg_number(p)
        if not num:
            continue
        n, total = num
        totals.add(int(total))
        name, review = tcg_name(p), []
        toy = {"id": "%s-%s-%s" % (promo["id"], n, slug(name)), "promotion": promo["id"], "number": n, "name": name, "group": "", "country": "", "note": "",
               "source": "tcgplayer-mc", "url": p.get("url") or promo["url"], "read": day, "tcg_id": str(p["productId"])}
        if promo["pokemon_set"]:
            toy["pokemon_link"] = "%s, card %s" % (promo["pokemon_set"], n)
        if p.get("imageUrl") and p.get("imageCount", 1):
            toy["candidate"] = p["imageUrl"]
        else:
            review.append("TCGplayer's record has no picture")
        if review:
            toy["review"] = review
        subs = set((printings or {}).get(p["productId"]) or ())
        if promo["id"] in SPLIT_PRINTINGS and {"Normal", "Holofoil"} <= subs:
            toys += split_printings(toy, promo, group)
        else:
            toys.append(toy)
    nums = [t["number"] for t in toys if t.get("printing", "Non-Holo") == "Non-Holo"]
    if len(totals) == 1 and len(nums) == len(set(nums)) and len(nums) <= min(totals):
        promo["total"] = totals.pop()
    toys.sort(key=lambda t: (int(t["number"]), t.get("printing", "") != "Non-Holo"))
    return promo, toys


def split_printings(toy, promo, group):
    """One card stated in both printings -> [Non-Holo (the old id), Holo (old id + '-holo')], each with its printing as a stated fact and its own Pokemon list link."""
    out = []
    for _sub, shown, tail, variants, pk_variant in PRINTINGS:
        t = dict(toy, id=toy["id"] + tail, name="%s (%s)" % (toy["name"], shown), printing=shown, variants=variants,
                 printing_url="https://tcgcsv.com/tcgplayer/3/%s/prices" % group["groupId"])
        t.pop("candidate", None)
        t["review"] = list(toy.get("review", [])) or [SHARED_PICTURE]
        if t.get("pokemon_link"):
            t["pokemon_link"] = "%s, %s" % (toy["pokemon_link"], pk_variant)
        if tail:
            t["moves_from"] = {"id": toy["id"], "variant": pk_variant}
        out.append(t)
    return out
