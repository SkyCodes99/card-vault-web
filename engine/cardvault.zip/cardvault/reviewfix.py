"""What the review list does with the owner's answers, per kind of item (see reviewlist.register), and the feeds that put a checker's unsure results on the list.
tcgsync_variant: TCGplayer lists a product whose printed number is already taken in that set under another spelling.  Yes = it is a new, different card: it is added now.  No = the same card: left out."""
import os
import sqlite3

from . import dedupe, gates, photoverify, picturecheck, reviewlist, safetynet  # noqa: F401  (dedupe, gates, photoverify, picturecheck and safetynet register what a yes to a held card, picture or big daily change does)
from .db import game_dir
from .paths import release_data_dir

VARIANT = "tcgsync_variant"
SOURCE = "TCGplayer catalogue via tcgcsv.com"


def queue_unsure_variants(game, entries):
    """tcgsync's unsure variants (rep["variants"] entries with "unsure": True) go on the review list instead of being dropped.  -> how many entries were handed over"""
    n = 0
    for e in entries:
        if not e.get("unsure"):
            continue
        place = f'"{e.get("name")}" (#{e.get("number")}) in {e.get("set")}'
        why = (f"but our list already has a card of that name at another number ({e['twin']})" if e.get("twin") and e["twin"] != "several" else
               "but our list already has more than one card of that name" if e.get("twin") else "but a card with that number is already in our list under another spelling")
        reviewlist.add_item(VARIANT, game, e["productId"], f"TCGplayer lists {place}, {why}. Is it a new, different card?",
                            before={k: e.get(k) for k in ("name", "number", "set", "groupId")}, source=SOURCE)
        n += 1
    return n


def _add_variant(item, ans, value, ctx):
    if ans != "yes":
        return "left out: it is the same card"
    from . import tcgsync
    ctx = ctx or {}
    b = item["before"] or {}
    db = os.path.join(game_dir(ctx.get("data_dir") or release_data_dir(), item["game"]), "cards.db")
    conn = sqlite3.connect(db, timeout=60)
    try:
        rep = {"newSets": [], "newSealed": [], "linked": [], "changedCards": [], "changedSealed": [], "marks": {},
               "newCards": [{"groupId": b.get("groupId"), "set": b.get("set"), "productId": int(item["item_id"]), "name": b.get("name"), "number": b.get("number"), "rarity": ""}]}
        out = tcgsync.apply_report(item["game"], conn, rep, fetch=ctx.get("fetch") or tcgsync.fetch_get, add_missing_cards=True)
    finally:
        conn.close()
    return f'added to the card list ({out["cardsAdded"]} card)' if out["cardsAdded"] else "nothing to add: it is already in the card list"


reviewlist.register(VARIANT, apply=_add_variant)
