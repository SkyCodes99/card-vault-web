"""The owner's corrections (rarity, printing, categories) are published ONCE to Card Data (/corrections/cards.json) so every app applies the same fixes on top of the catalog.

File format (keyed by the card's TCGplayer product id = cards.tcg_id, which is the same in every app):
  {"v": 1, "built": "2026-10-16T03:30:00Z",
   "games": {"pokemon": {"284251": {"tags": {"art": "yes", "altart": "no", "r_ir": "yes"},      # same tags as the Dev tools: art / altart / any category id: "yes" adds, "no" removes
                                    "rarity": "Special Illustration Rare",                      # reserved: shown rarity override
                                    "printing": "Cosmos Holo",                                   # reserved: printing label (Cosmos Holo, stamped, Prize Pack ...)
                                    "note": "free text"}}}}
This app downloads the file (about once a day) into its cache and applies the `tags` on top of the catalog; a person's own local edits still win on their own device."""
import json
import os

from . import sync

NAME = "corrections.json"


def path(data_dir):
    return os.path.join(data_dir, NAME)


def load(data_dir):
    try:
        with open(path(data_dir), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def refresh(data_dir, base):
    """Fetch /corrections/cards.json if it is newer than the cached copy.  -> True when a newer one was stored."""
    d = sync._get(base.rstrip("/") + "/cards.json", tries=1)
    if not isinstance(d, dict) or not isinstance(d.get("games"), dict):
        return False
    cur = load(data_dir)
    if str(d.get("built") or "") <= str(cur.get("built") or ""):
        return False
    tmp = path(data_dir) + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, path(data_dir))
    return True


def tags_for(data_dir, game, by_tcg):
    """{card id: {tag: value}} for the cards of this game that have a published correction.  by_tcg = {tcg_id: card id}."""
    games = load(data_dir).get("games") or {}
    out = {}
    for tcg, rec in (games.get(game) or {}).items():
        cid = by_tcg.get(str(tcg))
        if cid and isinstance(rec, dict) and isinstance(rec.get("tags"), dict):
            out[cid] = {k: v for k, v in rec["tags"].items() if v in ("yes", "no")}
    return out



SEALED_NAME = "sealed_corrections.json"


def load_sealed(data_dir):
    """The owner's published corrections for sealed products: {"games": {game: {productId: {"kind", "serie", "hidden"}}}}."""
    try:
        with open(os.path.join(data_dir, SEALED_NAME), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


SEALED_MISS = "sealed_corrections.miss"          # when the last look found no sealed.json (it is only published once the owner corrects a sealed product)
MISS_WAIT = 12 * 3600


def refresh_sealed(data_dir, base, force=False, now=None, host_up=False):
    """Fetch /corrections/sealed.json if it is newer than the cached copy.  -> True when a newer one was stored.
    A missing file (a real 404) is asked again only after MISS_WAIT, not at every check and page load.  Being offline, a timeout or a server error is NOT 'missing': it is
    asked again at the next check.  In the browser the 404 arrives as a network error (it carries no CORS header, so the browser hides it); there a failure counts as
    'missing' only when host_up says the same Card Data server just answered (cards.json).  force: ask anyway (publishing)."""
    import time
    from .runtime import IN_BROWSER
    miss = os.path.join(data_dir, SEALED_MISS)
    now = time.time() if now is None else now
    if not force:
        try:
            with open(miss, encoding="utf-8") as f:
                if 0 <= now - float(f.read().strip() or 0) < MISS_WAIT:          # (a note from the 'future' - the clock was put back - is not fresh)
                    return False
        except (OSError, ValueError):
            pass
    missing = False
    try:
        d = sync._get(base.rstrip("/") + "/sealed.json", tries=1)
        missing = d is None                                                      # sync._get: None = 404
    except Exception:  # noqa: BLE001 - not reachable: quietly 'no corrections' now, asked again at the next check
        d, missing = None, bool(IN_BROWSER and host_up)
    if not isinstance(d, dict) or not isinstance(d.get("games"), dict):
        if missing:
            try:
                with open(miss, "w", encoding="utf-8") as f:
                    f.write(str(now))
            except OSError:
                pass
        return False
    if os.path.exists(miss):
        try:
            os.remove(miss)
        except OSError:
            pass
    cur = load_sealed(data_dir)
    if str(d.get("built") or "") <= str(cur.get("built") or ""):
        return False
    tmp = os.path.join(data_dir, SEALED_NAME) + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, os.path.join(data_dir, SEALED_NAME))
    return True


def sealed_for(data_dir, game):
    """{product id: {"kind", "serie", "hidden"}} published for this game."""
    return {str(k): v for k, v in ((load_sealed(data_dir).get("games") or {}).get(game) or {}).items() if isinstance(v, dict)}
