"""The owner's corrections (rarity, printing, categories) are published ONCE to Card Data (/corrections/cards.json) so every app applies the same fixes on top of the catalog.

File format (keyed by the card's TCGplayer product id = cards.tcg_id, which is the same in every app):
  {"v": 1, "built": "2026-10-16T03:30:00Z",
   "games": {"pokemon": {"284251": {"tags": {"art": "yes", "altart": "no", "r_ir": "yes"},      # same tags as the Dev tools: art / altart / any category id: "yes" adds, "no" removes
                                    "rarity": "Special Illustration Rare",                      # reserved: shown rarity override
                                    "printing": "Cosmos Holo",                                   # reserved: printing label (Cosmos Holo, stamped, Prize Pack ...)
                                    "note": "free text"}}}}
This app downloads the file (about once a day) into its cache and applies the `tags` on top of the catalog; a person's own local edits still win on their own device."""
import json
import os

from . import sync

NAME = "corrections.json"


def path(data_dir):
    return os.path.join(data_dir, NAME)


def load(data_dir):
    try:
        with open(path(data_dir), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def refresh(data_dir, base):
    """Fetch /corrections/cards.json if it is newer than the cached copy.  -> True when a newer one was stored."""
    d = sync._get(base.rstrip("/") + "/cards.json", tries=1)
    if not isinstance(d, dict) or not isinstance(d.get("games"), dict):
        return False
    cur = load(data_dir)
    if str(d.get("built") or "") <= str(cur.get("built") or ""):
        return False
    tmp = path(data_dir) + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, path(data_dir))
    return True


def tags_for(data_dir, game, by_tcg):
    """{card id: {tag: value}} for the cards of this game that have a published correction.  by_tcg = {tcg_id: card id}."""
    games = load(data_dir).get("games") or {}
    out = {}
    for tcg, rec in (games.get(game) or {}).items():
        cid = by_tcg.get(str(tcg))
        if cid and isinstance(rec, dict) and isinstance(rec.get("tags"), dict):
            out[cid] = {k: v for k, v in rec["tags"].items() if v in ("yes", "no")}
    return out
