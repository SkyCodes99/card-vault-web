"""Pull rates per set and print runs (Collect Em All roadmap 'Print runs and pull rates').

Data lives in cardvault/data/pullrates_<game>.json.  Every row carries its source url and the date checked; a community or sampled figure is
labelled "estimate (n packs opened)", a publisher's own statement is "official".  A row with no url or no checked date is never shown, and nothing
is guessed: a set with no row shows nothing.  Print runs (numbered / serial cards, limited products with a stated count) are matched by game + set id
+ card name and need the same source fields."""
import json
import os
import re

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
GAME_FILES = {"pokemon": "pullrates_pokemon.json", "mtg": "pullrates_mtg.json", "lorcana": "pullrates_lorcana.json"}
KINDS = ("official", "estimate")
_cache = {}


def _norm(s):
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def valid(row):
    """A row is shown only with a rate, a http(s) source url, a checked date and a known kind (an estimate must name its sample)."""
    if not isinstance(row, dict) or not row.get("rate") or not str(row.get("url") or "").startswith("http") or not row.get("checked"):
        return False
    if row.get("kind") not in KINDS:
        return False
    return row["kind"] == "official" or bool(row.get("sample"))


def load(game):
    if game not in _cache:
        try:
            with open(os.path.join(DATA, GAME_FILES[game]), encoding="utf-8") as f:
                _cache[game] = json.load(f)
        except (KeyError, OSError, ValueError):
            _cache[game] = {"sets": [], "print_runs": []}
    return _cache[game]


def _public(r):
    return {k: r[k] for k in ("rarity", "rate", "label", "sample", "source", "url", "checked", "ci", "per_pack_pct", "method") if k in r}


def for_set(game, set_id, set_name=""):
    """The valid pull-rate rows of one set ([] when none): matched on the game's set id, else on the set's name."""
    for s in load(game).get("sets", []):
        if set_id in s.get("set_ids", []) or (set_name and _norm(set_name) == _norm(s.get("set_name"))):
            return [_public(r) for r in s.get("rows", []) if valid(r)]
    return []


def print_run(game, set_id, name):
    """{'text', 'source', 'url', 'checked'} for a card or product whose print run a source states, else None."""
    for p in load(game).get("print_runs", []):
        if p.get("set_id") == set_id and _norm(p.get("name")) == _norm(name) and p.get("text") and str(p.get("url") or "").startswith("http") and p.get("checked"):
            return {k: p.get(k, "") for k in ("text", "source", "url", "checked")}
    return None
