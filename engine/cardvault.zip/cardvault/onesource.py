"""'ONLY ONE SOURCE SO FAR': which items of a card list only one source describes (owner, quiz 14 Q1, 2026-11-13: "try to find a 2nd source, but they can be displayed on the site with a
disclaimer"; quiz 13: "two or more sources to solidify the existence of items, but pricing only needs one solid source").

The daily accuracy check (cardvault/accuracy, rule 'sources') knows it; this module keeps it inside the list itself, so it is published with the list and every device reads it from there:
  cards.one_source / sealed_products.one_source    1 = only one source states the item so far, 0 = two or more do, NULL = never checked (no claim either way)
A second source arriving later makes the next daily run write 0.  A price is never touched by this: one solid source is enough for a price."""
import sqlite3

TABLES = ("cards", "sealed_products")
COLUMN = "one_source"


def ensure(conn):
    """Add the column to a list that does not have it yet (idempotent; an older list keeps opening)."""
    for table in TABLES:
        cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        if cols and COLUMN not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {COLUMN} INTEGER")


def write(conn, table, checked, flagged):
    """Save one run's answer: every checked item gets 1 (in `flagged`) or 0.  Only rows that change are written.  -> how many rows changed"""
    if table not in TABLES:
        raise ValueError(table)
    ensure(conn)
    rows = [(1 if i in flagged else 0, str(i)) for i in checked]
    before = conn.total_changes
    conn.executemany(f"UPDATE {table} SET {COLUMN}=?1 WHERE id=?2 AND {COLUMN} IS NOT ?1", rows)
    conn.commit()
    return conn.total_changes - before


def ids(conn, table, among=None):
    """The ids of the items flagged 'only one source so far' (just those of `among` when given); an older list without the column gives none."""
    try:
        if among is None:
            return {str(r[0]) for r in conn.execute(f"SELECT id FROM {table} WHERE {COLUMN}=1")}
        among, out = [str(i) for i in among], set()
        for a in range(0, len(among), 800):
            part = among[a:a + 800]
            out.update(str(r[0]) for r in conn.execute(f"SELECT id FROM {table} WHERE {COLUMN}=1 AND id IN ({','.join('?' * len(part))})", part))
        return out
    except sqlite3.Error:
        return set()


def counts(conn):
    """{table: [flagged, checked]} of one list (for reports)."""
    out = {}
    for table in TABLES:
        try:
            out[table] = list(conn.execute(f"SELECT COALESCE(SUM({COLUMN}=1),0), COUNT({COLUMN}) FROM {table}").fetchone())
        except sqlite3.Error:
            pass
    return out
