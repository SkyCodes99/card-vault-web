"""Magic deck rules: Standard, Pioneer and Modern (at least 60 cards, sideboard of up to 15, at most 4 copies of a card by name) and Commander (exactly 100 cards with the commander,
singleton, every card inside the commander's colour identity, no sideboard).  Basic lands, and the few cards whose text lifts the limit, are exempt from the copy limit.
Legality is Scryfall's own statement per card (its legalities field), read with the daily update into the card list (legality.py, cardvault/deckleg.py): never fetched here.
The sizes and limits are in cardvault/data/deck_rules.json ("mtg")."""
from . import deckcards, deckcards_tcg, deckleg, deckzones
from .deckmsg import Msg

def _nm(c):
    return deckcards_tcg.strip_tail(c["name"])


_NAMES = {"W": "White", "U": "Blue", "B": "Black", "R": "Red", "G": "Green"}


def formats(rules):
    return [(k, f.get("label", k.title())) for k, f in ((rules.get("mtg") or {}).get("formats") or {}).items()]


def size_text(rules, fmt):
    f = ((rules.get("mtg") or {}).get("formats") or {}).get(fmt) or {}
    return (f["size"], f["size"]) if f.get("size") else (f.get("min", 60), None)


def _ident(letters):
    return "/".join(_NAMES[c] for c in "WUBRG" if c in letters) or "colourless"


def _limit(c, cfg, data, any_number, special):
    if c.get("basic") or c["key"] in any_number:
        return None
    return special.get(c["key"], cfg.get("copies", 4))


def check(v, zoned, info, fmt, rules, rows):
    data = rules.get("mtg") or {}
    cfg = (data.get("formats") or {}).get(fmt) or {}
    label = cfg.get("label", fmt.title())
    commander = fmt == "commander"
    probs, notes = [], []
    main, side, cmd = (sum(zoned[z].values()) for z in (deckzones.MAIN, deckzones.SIDE, deckzones.CMD))
    if commander:
        if main + cmd != cfg.get("size", 100):
            probs.append(Msg("mtgCmdSize", size=cfg.get("size", 100), n=main + cmd))
        if not cmd:
            probs.append(Msg("mtgChooseCmd"))
        elif cmd > cfg.get("commanders", 2):
            probs.append(Msg("mtgCmdMax", max=cfg.get("commanders", 2), n=cmd))
        if side:
            probs.append(Msg("mtgCmdSide", n=side))
    else:
        if main < cfg.get("min", 60):
            probs.append(Msg("mtgMin", fmt=label, min=cfg.get("min", 60), n=main))
        if side > cfg.get("side", 15):
            probs.append(Msg("mtgSide", max=cfg.get("side", 15), n=side))
        if cmd:
            probs.append(Msg("mtgCmdOnly", n=cmd))
    any_number = {deckcards.norm_name(n) for n in data.get("anyNumber", ())}
    special = {deckcards.norm_name(n): m for n, m in (data.get("maxCopies") or {}).items()}
    total, card = {}, {}
    for z in (deckzones.MAIN, deckzones.SIDE, deckzones.CMD):
        for cid, n in zoned[z].items():
            c = info.get(cid)
            if not c:
                probs.append(Msg("gone"))
                continue
            total[c["key"]] = total.get(c["key"], 0) + n
            card[c["key"]] = c
    unknown, no_ident = 0, 0
    cmd_ident, ident_known = set(), True
    for cid in zoned[deckzones.CMD]:
        c = info.get(cid)
        if c and c.get("identity") is not None:
            cmd_ident |= set(c["identity"])
        elif c:
            ident_known = False
    lm = deckleg.meta(v, "scryfall")
    for key, n in total.items():
        c = card[key]
        st = deckleg.status(rows, key, label) if lm["has"] else None
        lim = _limit(c, cfg, data, any_number, special)
        if st == "banned":
            probs.append(Msg("banned", name=_nm(c), fmt=label))
        elif st == "not legal":
            probs.append(Msg("mtgNotLegal", name=_nm(c), fmt=label))
        elif st is None:
            unknown += 1
        elif st == "restricted":
            lim = min(lim or 1, 1)
        if lim is not None and n > lim:
            probs.append(Msg("mtgCopy1", name=_nm(c), fmt=label, n=n) if lim == 1 else Msg("mtgCopies", max=lim, name=_nm(c), fmt=label, n=n))
    if commander and cmd and ident_known:
        for key, c in card.items():
            if key in {info[i]["key"] for i in zoned[deckzones.CMD] if i in info}:
                continue
            if c.get("identity") is None:
                no_ident += 1
            elif not set(c["identity"]) <= cmd_ident:
                probs.append(Msg("mtgIdent", name=_nm(c), ident=_ident(set(c["identity"])), cmd=_ident(cmd_ident)))
    if commander:
        for cid in zoned[deckzones.CMD]:
            c = info.get(cid)
            if c and not (c.get("legendary") and c.get("creature")):
                notes.append(f"{_nm(c)} isn't a Legendary Creature: it can only lead the deck if its own text says it can be your commander (not checked).")
        if cmd > 1:
            notes.append("Two commanders need Partner or a similar ability (not checked).")
        if cmd and not ident_known or no_ident:
            notes.append("Some cards have no colour facts yet, so their colour identity wasn't checked.")
    if not lm["has"]:
        notes.append("Scryfall's legality list hasn't been read into this card list yet (the daily update does it), so only sizes and copies are checked.")
    elif unknown:
        notes.append(f"{unknown} card{'' if unknown == 1 else 's'} not in the legality list, so not checked against it.")
    return probs, {"dated": lm["dated"] or data.get("checked", ""), "source": data.get("source") or lm["url"], "note": " ".join([data.get("note", "")] + notes).strip()}
