"""Find & Add without waiting (roadmap "Zero-wait speed pass", 2026-11-10).

Every new search word, filter or sort used to be a fresh SQL query over the whole card list: SQLite reads the full cards table (Magic: 132 MB, 107,000 cards, with long text columns) and
sorts it - 0.25-1 s per keystroke on a PC, 2-3x that in the browser.  Two things make it quick:

  1. a SLIM copy of the columns that filters look at, in memory (temp.cv_slim, ~14 MB for Magic): a filter reads it in a fraction of the time;
  2. a filtered list is cut out of the WHOLE order of that sort, which is worked out once per card list and kept (Vault.query_cards' cache) - "sorting where the data already is".
     The filters themselves are still the one SQL builder (Vault._query_cards_sql with ids_only), so the two ways can never disagree.

warm_steps() does both ahead of need, one short step per quiet moment (webapi/scheduler.find_warm): right after the card index, and again when the card list changed (the day's prices).
Until it is done, the plain SQL answers as before."""
import sqlite3

from . import gcsettle

TABLE = "temp.cv_slim"
WANTED = ("id", "set_id", "local_id", "sort_key", "name", "rarity", "types", "illustrator", "price_usd", "dex", "era_hint", "fold", "category", "popularity", "color_key")
SORTS = ("popular", "default", "price", "name", "oldest", "priceasc", "namez", "numasc", "set", "rarity", "artist", "dex", "color")      # every order Find & Add offers ('owned' first = 'default' with yours moved up)
STEP = 25000                                                       # cards copied per step (Magic: 5 steps of ~50 ms)


def ready(v):
    """True when the slim copy belongs to the card list as it is now (a price refresh or a new list makes a new one)."""
    fp = v.catalog_fp()
    return fp is not None and v.__dict__.get("_slim_fp") == fp


def build_steps(v):
    """Make the slim copy, a slice of the card list per step.  Nothing uses it until the last step is done."""
    fp = v.catalog_fp()
    if fp is None or v.__dict__.get("_slim_fp") == fp:
        return
    v._slim_fp = None
    have = {r[1] for r in v.conn.execute("PRAGMA main.table_info(cards)")}
    cols = [c for c in WANTED if c in have]
    if "fold" not in cols:
        return                                                     # (a list without folded words is searched the old way)
    # (fold() is registered once when the connection opens: db.open_cards_conn)
    v.conn.execute(f"DROP TABLE IF EXISTS {TABLE}")
    from .fuzzy import norm_sql
    v.conn.execute(f"CREATE TEMP TABLE cv_slim AS SELECT {', '.join(cols)}, fold(name) AS fname, fold(name) AS nname, NULL AS dpos FROM main.cards WHERE 0")      # (nname: the name made like fuzzy.norm() - 'blue-eyes' = 'blue eyes' - for ranking; dpos: positions_steps)
    top = v.conn.execute("SELECT MAX(rowid) FROM main.cards").fetchone()[0] or 0
    for lo in range(0, top, STEP):
        v.conn.execute(f"INSERT INTO {TABLE} SELECT {', '.join(cols)}, f, {norm_sql('f')}, NULL FROM (SELECT {', '.join(cols)}, fold(name) AS f FROM main.cards WHERE rowid>? AND rowid<=?)", (lo, lo + STEP))
        v.conn.commit()          # never yield inside a transaction: the INSERT opened one, and held across a pause it kept a stale snapshot of the collection - a sync writing it meanwhile made
        yield                    # the next save on this connection fail with "database is locked" (SQLITE_BUSY_SNAPSHOT: no busy timeout cures it).  (Only a temp table is written here.)
    if v.catalog_fp() == fp:                                       # (the list changed meanwhile: the copy is not used, the next look makes it again)
        v._slim_fp = fp


def positions_ready(v):
    """True when the slim copy carries every card's place in the whole default order (dpos) for the card list as it is now - Vault.query_page then answers from SQL alone."""
    fp = v.catalog_fp()
    return ready(v) and v.__dict__.get("_dpos_fp") == fp


def positions_steps(v, chunk=10000):
    """The slim copy's dpos column = the card's place in the kept whole default order, and an index on its ids, a slice per step (2026-11-13: a typed 'l' matches 87,000 of Magic's cards;
    with the places in SQL only the 60 shown are read - Vault.query_page)."""
    fp = v.catalog_fp()
    if not ready(v) or v.__dict__.get("_dpos_fp") == fp:
        return
    v._dpos_fp = None
    v.conn.execute(f"CREATE INDEX IF NOT EXISTS {TABLE}_id ON cv_slim(id)")
    v.conn.commit()
    yield
    whole = v.query_cards(sort="default")                          # (kept by now: a dictionary look-up)
    for lo in range(0, len(whole), chunk):
        v.conn.executemany(f"UPDATE {TABLE} SET dpos=? WHERE id=?", ((lo + i, r[0]) for i, r in enumerate(whole[lo:lo + chunk])))
        v.conn.commit()                                            # (never yield inside a transaction - see build_steps)
        yield
    if v.catalog_fp() == fp and ready(v):
        v._dpos_fp = fp


def warm_steps(v):
    """After the card index: the slim copy, then the whole order of every sort (one sort per step), so the first search, filter or sort of the session answers at once."""
    try:
        yield from build_steps(v)
    except sqlite3.Error:
        return
    try:
        yield from v.fuzzy_vocab_steps()                           # the name words typo tolerance looks at (cardvault/fuzzy.py), in short steps, here instead of at the first typo
    except sqlite3.Error:
        pass
    for sort in SORTS:
        if sort == "color" and not v.conn.execute("SELECT 1 FROM main.cards WHERE color_key IS NOT NULL AND color_key != '' LIMIT 1").fetchone():
            continue
        if sort == "popular" and not v._has_pop():
            continue
        if sort == "dex" and not v.conn.execute("SELECT 1 FROM main.cards WHERE dex IS NOT NULL AND dex != '' LIMIT 1").fetchone():
            continue
        full = not (v.__dict__.get("_qcache") or {}).get("by_id")
        try:
            v._pre_order = (v.catalog_fp(), sort, v.whole_cursor(sort, full=full), full)   # step 1: SQLite sorts ...
        except sqlite3.Error:
            return
        yield
        v.query_cards(sort=sort)                                   # step 2: ... and the rows are read and kept (query cache; a second ask is a dictionary look-up)
        v._pre_order = None
        yield
    try:
        yield from positions_steps(v)
    except sqlite3.Error:
        pass
    gcsettle.settle()                                              # (the kept orders: out of the collector's way too - cardvault/gcsettle.py)
