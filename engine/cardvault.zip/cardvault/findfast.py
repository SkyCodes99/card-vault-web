"""Find & Add without waiting (roadmap "Zero-wait speed pass", 2026-11-10).

Every new search word, filter or sort used to be a fresh SQL query over the whole card list: SQLite reads the full cards table (Magic: 132 MB, 107,000 cards, with long text columns) and
sorts it - 0.25-1 s per keystroke on a PC, 2-3x that in the browser.  Two things make it quick:

  1. a SLIM copy of the columns that filters look at, in memory (temp.cv_slim, ~14 MB for Magic): a filter reads it in a fraction of the time;
  2. a filtered list is cut out of the WHOLE order of that sort, which is worked out once per card list and kept (Vault.query_cards' cache) - "sorting where the data already is".
     The filters themselves are still the one SQL builder (Vault._query_cards_sql with ids_only), so the two ways can never disagree.

warm_steps() does both ahead of need, one short step per quiet moment (webapi/scheduler.find_warm): right after the card index, and again when the card list changed (the day's prices).
Until it is done, the plain SQL answers as before."""
import sqlite3

TABLE = "temp.cv_slim"
WANTED = ("id", "set_id", "local_id", "sort_key", "name", "rarity", "types", "illustrator", "price_usd", "dex", "era_hint", "fold", "category")
SORTS = ("default", "price", "name", "oldest", "priceasc", "namez", "numasc", "set", "rarity", "artist", "dex")      # every order Find & Add offers ('owned' first = 'default' with yours moved up)
STEP = 25000                                                       # cards copied per step (Magic: 5 steps of ~50 ms)


def ready(v):
    """True when the slim copy belongs to the card list as it is now (a price refresh or a new list makes a new one)."""
    fp = v.catalog_fp()
    return fp is not None and v.__dict__.get("_slim_fp") == fp


def build_steps(v):
    """Make the slim copy, a slice of the card list per step.  Nothing uses it until the last step is done."""
    fp = v.catalog_fp()
    if fp is None or v.__dict__.get("_slim_fp") == fp:
        return
    v._slim_fp = None
    have = {r[1] for r in v.conn.execute("PRAGMA main.table_info(cards)")}
    cols = [c for c in WANTED if c in have]
    if "fold" not in cols:
        return                                                     # (a list without folded words is searched the old way)
    from .searchfold import fold
    v.conn.create_function("fold", 1, fold, deterministic=True)
    v.conn.execute(f"DROP TABLE IF EXISTS {TABLE}")
    from .fuzzy import norm_sql
    v.conn.execute(f"CREATE TEMP TABLE cv_slim AS SELECT {', '.join(cols)}, fold(name) AS fname, fold(name) AS nname FROM main.cards WHERE 0")      # (nname: the name made like fuzzy.norm() - 'blue-eyes' = 'blue eyes' - for ranking)
    top = v.conn.execute("SELECT MAX(rowid) FROM main.cards").fetchone()[0] or 0
    for lo in range(0, top, STEP):
        v.conn.execute(f"INSERT INTO {TABLE} SELECT {', '.join(cols)}, f, {norm_sql('f')} FROM (SELECT {', '.join(cols)}, fold(name) AS f FROM main.cards WHERE rowid>? AND rowid<=?)", (lo, lo + STEP))
        yield
    if v.catalog_fp() == fp:                                       # (the list changed meanwhile: the copy is not used, the next look makes it again)
        v._slim_fp = fp


def warm_steps(v):
    """After the card index: the slim copy, then the whole order of every sort (one sort per step), so the first search, filter or sort of the session answers at once."""
    try:
        yield from build_steps(v)
    except sqlite3.Error:
        return
    try:
        yield from v.fuzzy_vocab_steps()                           # the name words typo tolerance looks at (cardvault/fuzzy.py), in short steps, here instead of at the first typo
    except sqlite3.Error:
        pass
    for sort in SORTS:
        if sort == "dex" and not v.conn.execute("SELECT 1 FROM main.cards WHERE dex IS NOT NULL AND dex != '' LIMIT 1").fetchone():
            continue
        full = not (v.__dict__.get("_qcache") or {}).get("by_id")
        try:
            v._pre_order = (v.catalog_fp(), sort, v.whole_cursor(sort, full=full), full)   # step 1: SQLite sorts ...
        except sqlite3.Error:
            return
        yield
        v.query_cards(sort=sort)                                   # step 2: ... and the rows are read and kept (query cache; a second ask is a dictionary look-up)
        v._pre_order = None
        yield
