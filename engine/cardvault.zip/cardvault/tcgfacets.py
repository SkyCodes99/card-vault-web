"""The filters of the card games added from TCGplayer on 2026-10-29 (Digimon, Flesh and Blood, Star Wars: Unlimited, Cardfight!! Vanguard, Dragon Ball Super Fusion World ...), written from what each
game's cards actually carry (`python tools/census_ext.py <game>` lists the fields).  The colour / class / element / nation of a card is already its `types` column (cardvault/tcggames.py says which
field), and its kind its `category`: these are the OTHER things a collector looks for - level, cost, trait, power.  gamefacets.py puts them next to the older games' filters.

Each entry is (key, label, extractor(ext, card) -> [values]); `values('Field')`, `count('Field')` and `ranged('Field', step, top)` (cardvault/facetvalues.py) read one field of the card's own data."""
import re

from .facetvalues import count, ranged, split, values

# the games whose card-type field can name several kinds at once ('Item;Regalia', 'Regalia;Item', 'Digimon/Option'): the same pair always reads the same
JOINED_KINDS = frozenset({"shadowverse", "grandarchive", "alphaclash", "cookierun", "digimon", "wixoss", "exodus"})

_VG_TRIGGERS = ("Critical", "Draw", "Heal", "Stand", "Front", "Over")                  # (the shop also writes 'Heal Trigger', 'Draw +10000' ...: the trigger is the first word)
_UVS_ZONES = {"h": "High", "high": "High", "m": "Mid", "mid": "Mid", "l": "Low", "low": "Low"}


def _vg_trigger(e, c):
    text = str(e.get("Trigger") or "").lower()
    return [t for t in _VG_TRIGGERS if t.lower() in text][:1]


def _vg_skill(e, c):
    return [re.sub(r"!+$", "", s).strip() for s in split(e.get("Skill Icon"), r"[;,]") if s.strip().lower() not in ("none", "0", "-")]


def _uvs_zone(e, c):
    """Universus writes a zone as 'H', 'high' or 'High': one word for each."""
    found = [_UVS_ZONES[z.lower()] for k in ("BlockZone", "AttackZone") for z in split(e.get(k)) if z.lower() in _UVS_ZONES]
    return list(dict.fromkeys(found))


def _holo_tags(e, c):
    return [t.lstrip("# ") for t in split(e.get("Tags"), r"[;]") if t.lstrip("# ")]


FACETS = {
    "dbsfw": [("trait", "Character trait", values("Character Traits")), ("cost", "Energy cost", count("Cost")), ("power", "Power", ranged("Power", 5000, 6)), ("combo", "Combo power", ranged("Combo Power", 5000, 2))],
    "swu": [("trait", "Trait", values("Traits")), ("cost", "Cost", count("Cost")), ("arena", "Arena", values("Arena Type")), ("power", "Power", count("Power")), ("hp", "HP", count("HP"))],
    "digimon": [("level", "Level", count("LevelLv")), ("form", "Form (Rookie, Champion, Mega ...)", values("DigimonForm", seps=r"[;/]")), ("attribute", "Attribute (Vaccine, Data, Virus ...)", values("DigimonAttribute", seps=r"[;/]")),
                ("dtype", "Digimon type", values("DigimonType", seps=r"[;/]")), ("cost", "Play cost", count("PlayCost")), ("dp", "DP", ranged("DigimonPowerDP", 2000, 7))],
    "fab": [("talent", "Talent", values("Talent")), ("subtype", "Subtype (Attack, Aura, Head ...)", values("CardSubType")), ("pitch", "Pitch", count("Pitch Value")), ("cost", "Cost", count("Cost")),
            ("defense", "Defense", count("Defense Value")), ("power", "Power", count("Power"))],
    "vanguard": [("grade", "Grade", count("Grade")), ("clan", "Clan", values("Clan")), ("race", "Race", values("Race", seps=r"[;/,]")), ("skill", "Skill icon (Boost, Intercept ...)", _vg_skill), ("trigger", "Trigger", _vg_trigger),
                 ("power", "Power", ranged("Power", 5000, 4)), ("shield", "Shield", ranged("Shield", 5000, 3))],
    "fow": [("race", "Race", values("Race", seps=r"[;/]")), ("cost", "Total cost", count("TotalCost")), ("atk", "ATK", ranged("Atk", 500, 5)), ("def", "DEF", ranged("Def", 500, 5))],
    "shadowverse": [("cost", "Cost", count("Cost")), ("trait", "Trait", values("Trait")), ("atk", "Attack", count("Attack")), ("def", "Defense", count("Defense"))],
    "grandarchive": [("class", "Class", values("Class")), ("subtype", "Subtype", values("CardSubtype")), ("reserve", "Reserve cost", count("Reserve Cost")), ("memory", "Memory cost", count("MemoryCost")),
                     ("speed", "Speed", values("Speed")), ("level", "Level", count("Level"))],
    "wixoss": [("level", "Level", count("Level")), ("lrig", "LRIG type / class", values("LRIGTypeClass", seps=";")), ("power", "Power", ranged("Power", 3000, 5)), ("team", "Team", values("TeamName")),
               ("timing", "Timing", values("Timing"))],
    "hololive": [("bloom", "Bloom level", values("BloomLevel")), ("hp", "HP", ranged("HP", 50, 6)), ("tag", "Tag", _holo_tags), ("support", "Support card kind", values("Subtype")), ("baton", "Baton pass cost", count("Baton Pass"))],
    "finalfantasy": [("cost", "Cost", count("Cost")), ("title", "Final Fantasy title (VII, XIV ...)", values("Category")), ("job", "Job", values("Job")), ("power", "Power", ranged("Power", 2000, 5))],
    "battlespirits": [("cost", "Cost", count("Cost")), ("spirit", "Spirit type", values("Spirit Type", seps=r"[;/]")), ("symbols", "Symbols", count("Symbols"))],
    "metazoo": [("tribe", "Tribe", values("Tribe")), ("trait", "Trait", values("Traits")), ("strong", "Strong against", values("StrongAgainst")), ("lp", "LP", ranged("LP", 20, 5)),
                ("cost", "Total aura cost", count("Total Aura Cost")), ("spellbook", "Spellbook limit", count("SpellbookLimit"))],
    "universus": [("difficulty", "Difficulty", count("Difficulty")), ("speed", "Attack speed", count("AttackSpeed")), ("damage", "Attack damage", count("AttackDamage")), ("zone", "Zone (high / mid / low)", _uvs_zone),
                  ("hand", "Hand size", count("HandSize"))],
    "sorcery": [("type", "Card type (Minion, Magic, Artifact ...)", values("CardType")), ("subtype", "Subtype", values("Card Subtype")), ("cost", "Mana cost", count("Cost")), ("power", "Power", count("Power Rating")),
                ("defense", "Defense", count("Defense Power"))],
    "cookierun": [("level", "Level", count("Level")), ("hp", "HP", count("HP")), ("keyword", "Keyword", values("Keyword"))],
    "godzilla": [("rank", "Rank", values("Rank")), ("trait", "Trait", values("Traits")), ("film", "Film", values("Source", seps=";")), ("invade", "Invade", count("Invade"))],
    "alphaclash": [("planet", "Planet", values("Planet Name")), ("affiliation", "Affiliation", values("Affiliation")), ("subtype", "Subtype", values("CardSubtype")), ("attack", "Attack", count("Attack")),
                   ("defense", "Defense", count("Defense"))],
    "elestrals": [("subclass", "Subclass", values("Subclass")), ("rune", "Rune type", values("RuneType")), ("attack", "Attack", count("Attack")), ("defense", "Defense", count("Defense"))],
    "akora": [("subtype", "Subtype", values("Subtype")), ("stage", "Stage", count("Stage")), ("relic", "Relic requirement", count("RelicRequirement"))],
    "kryptik": [("finish", "Printing (Base, Box Topper, coloured Kryptik)", values("Printing")), ("soul", "Soul colour", values("SoulBox")), ("attack", "Attack", count("Attack")), ("defense", "Defense", count("Defense"))],
    "transformers": [("subtype", "Subtype", values("SubType", seps=r"\s+-\s+|[;,]|//")), ("stars", "Stars", count("Stars")), ("health", "Health", count("Health"))],
    "swdestiny": [("affiliation", "Affiliation (Hero / Villain)", values("Affiliation")), ("unique", "Unique", values("Uniqueness")), ("cost", "Cost", count("Cost")), ("health", "Health", count("Health"))],
    "gateruler": [("attribute", "Attribute", values("Attribute")), ("level", "Level", count("Level")), ("atk", "ATK", count("ATK")), ("hp", "HP", count("HP")), ("icon", "Reminder icon", values("Reminder Icon"))],
    # the smaller games (World of Warcraft and Buddyfight carry nothing but a rarity and a text: no filters beyond the common ones)
    "dicemasters": [("affiliation", "Affiliation", values("Affiliation", "Affiliation 2")), ("cost", "Cost", count("Cost")), ("dice", "Most dice", count("MaxDice"))],
    "dragoborne": [("nation", "Nation", values("Nation")), ("subtype", "Subtype", values("CardSubType")), ("cost", "Cost", count("Cost")), ("atk", "ATK", count("ATK")), ("edr", "EDR", count("EDR"))],
    "metax": [("character", "Character type", values("CharacterType")), ("mp", "MP points", values("MPPoints"))],
    "zwo": [("attribute", "Attribute", values("Attribute")), ("cost", "Summoning cost", count("SummoningCost")), ("power", "Power", count("Power"))],
    "casterchronicles": [("deck", "Deck", values("Deck")), ("race", "Race / trait", values("RaceandTrait", seps=r"[;/]")), ("cost", "Cost", count("Cost")), ("atk", "ATK", ranged("ATK", 1000, 5))],
    "exodus": [("creature", "Creature type", values("CreatureType", seps=r"[;/]"))],
    "lightseekers": [("family", "Family", values("Family")), ("second", "Second order", values("SecondaryOrder"))],
    "munchkin": [("subtype", "Subtype", values("Subtype")), ("gold", "Gold cost", count("GoldCost")), ("power", "Power", count("Power"))],
    "aoschampions": [("tag", "Tag", values("Tag1", "Tag2")), ("unique", "Unique", values("Uniqueness"))],
    "bakugantcg": [("cost", "Energy cost", count("EnergyCost")), ("power", "B-Power", ranged("BPower", 100, 8)), ("damage", "Damage rating", count("DamageRating"))],
    "chronoclash": [("cost", "Cost", count("Cost")), ("strength", "Strength", count("Strength"))],
    "argentsaga": [("subtype", "Subtype", values("Subtype")), ("shard", "Shard cost", count("ShardCost")), ("power", "Power", ranged("Power", 500, 6))],
    "cyberpunk": [("tag", "Tag", values("Tags")), ("cost", "Cost", count("Cost")), ("ram", "RAM", values("RAM")), ("power", "Power", count("Power"))],
}
