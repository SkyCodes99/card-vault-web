"""Display currency.  Everything is stored in US dollars; amounts are converted only when shown (and converted back when typed).

Rates come from the European Central Bank's daily reference rates (cardvault/ecbrates.py, run by the daily job and published to Card Data as
fx.json).  The apps read that file with fetch_fx() and keep it in settings (cfg["fx"]) - the last good rates stay when a download fails.
A rate typed by hand in Settings (cfg["currency_rates"], units per US dollar) overrides the ECB rate for that currency.
If the chosen currency has no rate at all, prices show in US dollars and info()["note"] says so.
"""
import datetime

import requests

# code: (symbol, decimals).  The ECB's currency list (its daily reference rates), plus the euro itself.  Yen, won, krona, forint and rupiah show whole units.
CURRENCIES = {
    "USD": ("$", 2), "EUR": ("€", 2), "GBP": ("£", 2), "JPY": ("¥", 0), "CAD": ("CA$", 2), "AUD": ("A$", 2), "NZD": ("NZ$", 2),
    "CHF": ("CHF ", 2), "SEK": ("kr ", 2), "NOK": ("kr ", 2), "DKK": ("kr ", 2), "ISK": ("kr ", 0), "PLN": ("zł ", 2), "CZK": ("Kč ", 2),
    "HUF": ("Ft ", 0), "RON": ("lei ", 2), "BGN": ("лв ", 2), "TRY": ("₺", 2), "BRL": ("R$", 2), "CNY": ("CN¥", 2), "HKD": ("HK$", 2),
    "IDR": ("Rp ", 0), "ILS": ("₪", 2), "INR": ("₹", 2), "KRW": ("₩", 0), "MXN": ("MX$", 2), "MYR": ("RM ", 2), "PHP": ("₱", 2),
    "SGD": ("S$", 2), "THB": ("฿", 2), "ZAR": ("R ", 2),
}
FX_URL = "https://sky-carddata-tnnwxj.azurewebsites.net/catalog/fx.json"       # published by publish_carddata.py from the daily job

_state = {"chosen": "USD", "shown": "USD", "rates": {"USD": 1.0}, "date": None, "by_hand": set(), "note": ""}


def _fx_rates(fx):
    """{"eur": {code: units per 1 euro}} -> {code: units per 1 US dollar} (empty when there is no usable USD rate)."""
    eur = (fx or {}).get("eur") or {}
    usd = eur.get("USD")
    if not isinstance(usd, (int, float)) or usd <= 0:
        return {}
    out = {"USD": 1.0, "EUR": 1.0 / usd}
    for c, v in eur.items():
        if c in CURRENCIES and isinstance(v, (int, float)) and v > 0:
            out[c] = v / usd
    return out


def configure(cfg):
    fx = cfg.get("fx") if isinstance(cfg.get("fx"), dict) else {}
    rates = _fx_rates(fx)
    date = fx.get("date") if rates else None
    by_hand = set()
    for k, v in (cfg.get("currency_rates") or {}).items():           # typed by hand: units per US dollar
        if k in CURRENCIES and k != "USD" and isinstance(v, (int, float)) and v > 0:
            rates[k] = float(v)
            by_hand.add(k)
    rates.setdefault("USD", 1.0)
    chosen = cfg.get("currency", "USD")
    chosen = chosen if chosen in CURRENCIES else "USD"
    shown, note = chosen, ""
    if chosen not in rates:
        shown, note = "USD", f"No {chosen} rate yet, so prices show in US dollars. Update the rates in Settings."
    _state.update(chosen=chosen, shown=shown, rates=rates, date=date, by_hand=by_hand, note=note)


def code():
    """The currency the person chose (what the Settings list shows)."""
    return _state["chosen"]


def shown():
    """The currency prices are actually shown in (the chosen one, or USD when its rate is missing)."""
    return _state["shown"]


def symbol():
    return CURRENCIES[_state["shown"]][0]


def rate():
    return _state["rates"][_state["shown"]]


def convert(usd):
    return None if usd is None else usd * rate()


def to_usd(amount):
    return None if amount is None else amount / rate()


def decimals():
    return CURRENCIES[_state["shown"]][1]


def tip(usd):
    """Hover text for a converted price: 'Converted from $X at the ECB rate of <date>'; None when no conversion happens."""
    if usd is None or _state["shown"] == "USD":
        return None
    src = "at a rate you typed in Settings" if _state["shown"] in _state["by_hand"] else f"at the ECB rate of {_state['date'] or 'an earlier day'}"
    return f"Converted from ${usd:,.2f} {src}"


def info():
    """What the apps need to show prices: the chosen code, the code shown, symbol, rate, decimals, the ECB date and any note."""
    s = _state
    if s["shown"] == "USD":
        src = "US dollars"
    elif s["shown"] in s["by_hand"]:
        src = "by hand"
    else:
        src = "ECB" if s["date"] else "none"
    return {"code": s["chosen"], "shown": s["shown"], "symbol": symbol().strip(), "rate": rate(), "decimals": decimals(),
            "date": s["date"], "source": src, "note": s["note"], "fallback": bool(s["note"])}


def fmt(usd, compact=False):
    if usd is None:
        return "–"
    v, s = usd * rate(), symbol()
    if compact and abs(v) >= 1000:
        return f"{s}{v / 1000:,.1f}k" if abs(v) < 1_000_000 else f"{s}{v / 1_000_000:,.2f}M"
    return f"{s}{v:,.{decimals()}f}" if abs(v) < 1000 else f"{s}{v:,.0f}"


def fetch_fx(timeout=15):
    """The newest ECB rates from Card Data (fx.json) -> {"date", "eur", "fetched"}.  Raises on any problem: the caller keeps the rates it has."""
    r = requests.get(FX_URL, timeout=timeout, headers={"User-Agent": "CollectEmAll/2 (currency)"})
    r.raise_for_status()
    doc = r.json()
    datetime.date.fromisoformat(str(doc.get("date", "")))
    eur = {k: float(v) for k, v in (doc.get("eur") or {}).items() if k in CURRENCIES and float(v) > 0}
    if "USD" not in eur:
        raise ValueError("no USD rate in the file")
    return {"date": doc["date"], "eur": eur, "fetched": datetime.date.today().isoformat()}


def usd_from(amount, code):
    """An amount in another currency -> US dollars at the current rate (None when the currency or the rate is unknown)."""
    r = _state["rates"].get(code)
    return None if amount is None or not r else amount / r
