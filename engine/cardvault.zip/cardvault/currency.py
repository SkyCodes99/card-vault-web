"""Display currency.  Everything is stored in US dollars; amounts are converted only when shown (and converted back when typed).

Rates are entered by hand or refreshed on request from the European Central Bank's published rates (the only online step, and only when
you press the button)."""
import requests

CURRENCIES = {
    "USD": ("$", 1.0), "EUR": ("€", 0.92), "GBP": ("£", 0.79), "CAD": ("CA$", 1.36), "AUD": ("A$", 1.52),
    "JPY": ("¥", 150.0), "MXN": ("MX$", 18.0), "CHF": ("CHF ", 0.88), "SEK": ("kr ", 10.5), "NZD": ("NZ$", 1.65),
}

_state = {"code": "USD", "rates": {k: v[1] for k, v in CURRENCIES.items()}}


def configure(cfg):
    code = cfg.get("currency", "USD")
    _state["code"] = code if code in CURRENCIES else "USD"
    for k, v in (cfg.get("currency_rates") or {}).items():
        if k in CURRENCIES and isinstance(v, (int, float)) and v > 0:
            _state["rates"][k] = float(v)


def code():
    return _state["code"]


def symbol():
    return CURRENCIES[_state["code"]][0]


def rate():
    return _state["rates"][_state["code"]]


def convert(usd):
    return None if usd is None else usd * rate()


def to_usd(amount):
    return None if amount is None else amount / rate()


def decimals():
    return 0 if _state["code"] == "JPY" else 2


def fmt(usd, compact=False):
    if usd is None:
        return "–"
    v, s = usd * rate(), symbol()
    if compact and abs(v) >= 1000:
        return f"{s}{v / 1000:,.1f}k" if abs(v) < 1_000_000 else f"{s}{v / 1_000_000:,.2f}M"
    return f"{s}{v:,.{decimals()}f}" if abs(v) < 1000 else f"{s}{v:,.0f}"


def fetch_rates(timeout=15):
    """Latest rates from the ECB via frankfurter.app -> {code: units per 1 USD}.  Raises on network problems."""
    others = ",".join(c for c in CURRENCIES if c != "USD")
    r = requests.get("https://api.frankfurter.app/latest", params={"from": "USD", "to": others}, timeout=timeout,
                     headers={"User-Agent": "CollectEmAll/2 (currency)"})
    r.raise_for_status()
    out = {"USD": 1.0}
    out.update({k: float(v) for k, v in r.json().get("rates", {}).items() if k in CURRENCIES})
    return out
