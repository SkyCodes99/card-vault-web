"""Where in a deck a card sits.  A deck is stored as {card_id: copies}; a card in the side deck / sideboard / commander slot is stored under a prefixed key ("s:<id>", "c:<id>"), so the stored
shape (and the cloud snapshot) did not have to change.  Yu-Gi-Oh!'s Extra Deck needs no zone: the card's own type puts it there (deckcards.describe, section "Extra Deck")."""

MAIN, SIDE, CMD = "main", "side", "cmd"
_PREFIX = {SIDE: "s:", CMD: "c:"}
ZONES = {"yugioh": (MAIN, SIDE), "mtg": (MAIN, SIDE, CMD)}          # the other games have just the one list


def zones_for(game):
    return ZONES.get(game, (MAIN,))


def key(zone, card_id):
    return _PREFIX.get(zone, "") + str(card_id)


def zone_of(k):
    for z, p in _PREFIX.items():
        if str(k).startswith(p):
            return z, str(k)[len(p):]
    return MAIN, str(k)


def split(cards):
    """{key: n} -> {zone: {card_id: n}} (every zone present)."""
    out = {MAIN: {}, SIDE: {}, CMD: {}}
    for k, n in cards.items():
        z, cid = zone_of(k)
        out[z][cid] = out[z].get(cid, 0) + n
    return out


def flat(cards):
    """{key: n} -> {card_id: n} adding the zones together (what the owned-cards check and the card lookups need)."""
    out = {}
    for k, n in cards.items():
        cid = zone_of(k)[1]
        out[cid] = out.get(cid, 0) + n
    return out


def valid(game, zone):
    return zone in zones_for(game)
