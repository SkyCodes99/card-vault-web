"""Finding the card of the open game a pasted deck line means: by name (several prints fit, so the base print, the newest, one with a price is picked)."""

SELECT = "SELECT c.id, c.name, c.local_id, c.price_usd, s.release_date FROM cards c LEFT JOIN sets s ON s.id=c.set_id "


def pick(rows):
    """Several prints fit: the base print (no '(...)' in the name), the newest, one with a price."""
    rows = list(rows)
    rows.sort(key=lambda r: ("(" in (r["name"] or ""), r["price_usd"] is None, -(int((r["release_date"] or "0")[:4] or 0)), r["price_usd"] or 0))
    return rows[0]["id"] if rows else None


def _number_matches(rows, number):
    n = str(number or "").split("/")[0].strip().lstrip("0").lower()
    return [r for r in rows if n and str(r["local_id"] or "").split("/")[0].strip().lstrip("0").lower() == n]


def by_name(v, name, number=""):
    """The card id for a card name (any letter case; a printing's '(...)' label, or the other face of a two-faced card, may follow it) -> id or None.  number prefers the print with that collector number."""
    name = " ".join((name or "").split())
    if not name:
        return None
    rows = v.conn.execute(SELECT + "WHERE c.name=? COLLATE NOCASE OR c.name_en=? COLLATE NOCASE", (name, name)).fetchall()          # name_en: an English list pasted while names are shown in another language
    if not rows:
        like = name.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        rows = v.conn.execute(SELECT + "WHERE c.name LIKE ? ESCAPE '\\' OR c.name LIKE ? ESCAPE '\\' OR c.name_en LIKE ? ESCAPE '\\' OR c.name_en LIKE ? ESCAPE '\\'",
                              (like + " (%", like + " // %") * 2).fetchall()
    if not rows:
        return None
    return pick(_number_matches(rows, number) or rows)
