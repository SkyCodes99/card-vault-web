"""The collection value graph, worked out in two ways (owner, 2026-11-12):

  full      "Full price history": everything you own NOW (today's quantities), valued on each past day at the price KNOWN for it that day, as far back as prices exist
            (your own saved daily prices, the archive's filled-in days among them; before a card's first saved price, Card Data's per-set history from sethistory.py when its
            file is here).  Between two known prices the last one carries on.  Before an item's first known price nothing is made up: it is left out of those days and
            counted in 'coverage' (owner, 2026-11-15: "it should go based on the pricing known for items with some disclaimers").  Items with no price history at all
            (custom items, no price source) are left out of every past day (coverage.noHistory); today's point is still today's prices for everything.
  purchase  "Since purchase": only copies with a purchase date, each counted from that date at that day's price.  Copies with no date are left out (counted in 'undated').

Fast on big collections: only the day-to-day price CHANGES are added up (each multiplied by the copies held), read card by card in slices of days, so nothing walks
every copy over every day.  Python only adds, per group of copies, what it held on the day it entered the graph, plus the few cards priced from a per-set file and
the sealed products.  Today's point is always today's prices (the same number as the totals on screen)."""
import bisect
import datetime

from . import pricepick

MODES = ("full", "purchase")


def _clamp(s, today_s):
    s = (s or "")[:10]
    try:
        datetime.date.fromisoformat(s)
    except ValueError:
        return None
    return min(s, today_s)                                                  # an 'added' stamp is UTC: in the evening it can read as tomorrow


def _contrib(hist, groups, days, start_s, lim_s, delta, backfill=True):
    """Add one key's value to `delta` (per sample day: the change in value on that sample).  hist = [(day, usd)] sorted; groups = [(since, qty)].
    Before the first price: backfill=True the first price is used (Since purchase); False (Full price history) the key enters on its first known day, not before.
    Changes after `lim_s` are left out (today's point is set apart)."""
    hd = [h[0] for h in hist]
    for since, q in groups:
        e = max(since, start_s)
        if e > days[-1]:
            continue
        i0 = bisect.bisect_left(days, e)
        j = bisect.bisect_right(hd, e) - 1
        if j >= 0 or backfill:
            delta[i0] += q * (hist[j][1] if j >= 0 else hist[0][1])
        elif hd[0] <= lim_s:
            delta[bisect.bisect_left(days, hd[0])] += q * hist[0][1]
            j = 0
        else:
            continue                                                        # (its first known price is today's: only today's point counts it)
        for k in range(max(j + 1, 1), len(hist)):
            t = hd[k]
            if t > lim_s:
                break
            if hist[k][1] != hist[k - 1][1]:
                delta[bisect.bisect_left(days, t)] += q * (hist[k][1] - hist[k - 1][1])


def _market(svc, v, need):
    """Card Data's per-set history for cards {card_id: (set_id, first own day or None)} -> {card_id: [(day, usd)] before that first own day}."""
    if svc is None or not need:
        return {}
    from . import sethistory
    by_set = {}
    for cid, (sid, first) in need.items():
        if sid:
            by_set.setdefault(sid, {})[cid] = first
    sethistory.warm(svc, v.game, list(by_set))
    out = {}
    for sid, cards in by_set.items():
        pts = sethistory.points_for(svc, v.game, sid, list(cards))
        for cid, first in cards.items():
            s = [p for p in pts.get(cid, ()) if first is None or p[0] < first]
            if s:
                out[cid] = s
    return out


CHUNK_ROWS = 12000                                                          # saved prices read per step (about a tenth of a second): see series_steps


def series(v, range_key="all", start=None, end=None, max_points=240, mode="full", svc=None):
    """The whole series at once (for a screen that must have it now)."""
    gen = series_steps(v, range_key, start, end, max_points, mode, svc, rows=0)
    while True:
        try:
            next(gen)
        except StopIteration as e:
            return e.value


def series_steps(v, range_key="all", start=None, end=None, max_points=240, mode="full", svc=None, rows=CHUNK_ROWS):
    """The same series in short steps: a generator that yields after each slice of the price changes (a few cards' saved prices) and returns the series.  A long price history
    is seconds of work on a big collection; in steps, a click that comes in meanwhile is answered between two of them (webapi/graphwarm.py).  Each step reads everything it
    needs before it yields: nothing is left open on the connection across a pause.  rows=0: all the days in one go (quickest in total, for a screen that waits for it)."""
    from .tools import RANGE_DAYS
    mode = mode if mode in MODES else "full"
    today = datetime.date.today()
    today_s = today.isoformat()
    end_d = min(datetime.date.fromisoformat(end), today) if end else today
    full = mode == "full"
    since_sql = "''" if full else "MIN(substr(purchased,1,10), ?)"
    dated = "" if full else "AND TRIM(COALESCE(purchased,''))!='' "
    held_sql = (f"SELECT card_id, {since_sql} AS since, SUM(qty) AS q, SUM(qty*COALESCE(purchase_price,0)) AS paid FROM lots_s "
                f"WHERE user_id=? AND game=? AND deleted=0 AND qty>0 {dated}GROUP BY card_id, since")
    hargs = ([] if full else [today_s]) + [v.user_id, v.game]
    # ---- what is counted (cards), and the facts about their dates
    lots = v.conn.execute("SELECT card_id, qty, purchased, added FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)).fetchall()
    undated = [r for r in lots if not (r["purchased"] or "").strip()]
    defaulted = {"copies": sum(r["qty"] for r in undated), "stacks": len(undated), "total": sum(r["qty"] for r in lots)}
    starts = [d for d in (_clamp(r["purchased"] or r["added"], today_s) for r in lots) if d]
    dated_starts = [d for d in (_clamp(r["purchased"], today_s) for r in lots) if d]
    # ---- sealed products in the same portfolios (priced from their own saved history, key 'sealed:<name letters>')
    sealed, sealed_now, undated_sealed, sealed_all = [], {}, 0, []
    try:
        from .tcgcsv import norm_name
        scope = list(v.scope or [])
        for r in v.conn.execute("SELECT name, qty, paid, purchased, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)).fetchall():
            if scope and r["pf"] not in scope:
                continue
            key = "sealed:" + norm_name(r["name"])
            if key not in sealed_now:
                p = v.conn.execute("SELECT price_usd FROM sealed_products WHERE norm=? AND price_usd IS NOT NULL ORDER BY price_updated DESC LIMIT 1", (norm_name(r["name"]),)).fetchone()
                sealed_now[key] = p[0] if p else None
            sealed_all.append((key, r["qty"]))
            since = _clamp(r["purchased"], today_s)
            if since is None:
                undated_sealed += r["qty"]
            else:
                starts.append(since)
                dated_starts.append(since)
            if full:
                since = ""
            if since is not None:
                sealed.append((key, since, r["qty"], (r["paid"] or 0) * r["qty"]))
    except Exception:  # noqa: BLE001 - a game with no sealed list
        pass
    base = {"defaulted": defaulted, "mode": mode, "undated": {"copies": defaulted["copies"] + undated_sealed, "sealed": undated_sealed}}
    # ---- per group of copies: when it enters, the copies, what was paid, the card's first own price and day, its set (one query; each lookup is an index seek)
    groups = v.conn.execute(
        f"WITH g AS ({held_sql}) SELECT g.card_id, g.since, g.q, g.paid, c.set_id, "
        "(SELECT MIN(day) FROM u.price_history h WHERE h.game=? AND h.card_id=g.card_id AND h.usd IS NOT NULL) AS f, "
        "(SELECT usd FROM u.price_history h WHERE h.game=? AND h.card_id=g.card_id AND h.usd IS NOT NULL ORDER BY day LIMIT 1) AS fp "
        "FROM g LEFT JOIN cards c ON c.id=g.card_id", (*hargs, v.game, v.game)).fetchall()
    if not groups and not sealed:
        return {"points": [], "realFrom": None, "firstBuy": min(starts) if starts else None, **base}
    if rows:
        yield                                                                 # (in steps: the groups, today's prices and the set history, the slices, the entry values)
    first_buy = min(starts) if starts else today_s
    now_price = {r[0]: r[1] for r in v.conn.execute(f"SELECT c.id, {pricepick.sql(v)} FROM cards c WHERE c.id IN (SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0)", (v.user_id, v.game))}
    now_price.update(sealed_now)
    sealed_hist = {}
    keys = sorted({s[0] for s in sealed})
    for i in range(0, len(keys), 500):
        part = keys[i:i + 500]
        for k, day, usd in v.conn.execute(f"SELECT card_id, day, usd FROM u.price_history WHERE game=? AND card_id IN ({','.join('?' * len(part))}) AND usd IS NOT NULL ORDER BY day", (v.game, *part)):
            sealed_hist.setdefault(k, []).append((day, usd))
    own_first = [r["f"] for r in groups if r["f"]] + [h[0][0] for h in sealed_hist.values()]
    # ---- the days on the graph
    if start:
        start_d = datetime.date.fromisoformat(start)
    elif range_key in RANGE_DAYS:
        start_d = end_d - datetime.timedelta(days=RANGE_DAYS[range_key])
    else:
        start_d = None
    # cards priced from Card Data's per-set history: only those whose own saved prices begin after the graph does (or never)
    probe = start_d.isoformat() if start_d else "0000"
    market = _market(svc, v, {r["card_id"]: (r["set_id"], r["f"]) for r in groups if not r["f"] or r["f"] > probe})
    if rows:
        yield
    real_from = min(own_first + [m[0][0] for m in market.values()], default=None)
    if start_d is None:                                                       # 'all': back as far as prices go (full) / the first purchase (since purchase)
        first = (real_from or first_buy) if full else min(dated_starts, default=first_buy)
        start_d = datetime.date.fromisoformat(min(first, end_d.isoformat()))
    elif not full and (range_key == "all" or start):
        start_d = max(start_d, datetime.date.fromisoformat(min(dated_starts, default=first_buy)))
    span = max((end_d - start_d).days, 1)
    step = max(1, -(-span // max_points))
    days, d = [], start_d
    while d < end_d:
        days.append(d.isoformat())
        d += datetime.timedelta(days=step)
    days.append(end_d.isoformat())
    start_s = days[0]
    lim_s = min(days[-1], (today - datetime.timedelta(days=1)).isoformat())   # changes up to here; today's point is today's prices
    n = len(days)
    dv, di, kd = [0.0] * n, [0.0] * n, [0] * n                                # kd (Full price history): items whose first price is known on that sample
    # ---- 1. every price change of your own saved prices, times the copies held before that day.  The prices are read as they are (card, day, price), a few cards per step (CHUNK_ROWS
    # saved prices) over all the graph's days, each change against the card's price before it - its first one against its price on the graph's first day.  (It used to be SQLite's LAG()
    # window over slices of days: every slice looked each card up again and a year of a big collection took seconds of steps - owner, 2026-11-14: "it should be within 2 seconds".)
    held = {}
    for r in groups:
        held.setdefault(r["card_id"], []).append((r["since"], r["q"]))
    cur = v.conn.cursor()
    cur.row_factory = None                                                    # (plain tuples: a big collection reads a lot of prices)
    last = dict(cur.execute(
        f"WITH g AS ({held_sql}) SELECT c.card_id, (SELECT usd FROM u.price_history h WHERE h.game=? AND h.card_id=c.card_id AND h.usd IS NOT NULL AND h.day<=? ORDER BY day DESC LIMIT 1) "
        "FROM (SELECT DISTINCT card_id FROM g) c", (*hargs, v.game, start_s)).fetchall())
    span = max(1, (datetime.date.fromisoformat(lim_s) - datetime.date.fromisoformat(start_s)).days)
    per = min(500, max(1, rows // span)) if rows else 500                    # cards per step (at most 500 in one question)
    if rows:
        yield                                                                 # (what is counted and the days on the graph are a step of their own)
    cids = sorted(held) if start_s < lim_s else []
    for i in range(0, len(cids), per):
        part = cids[i:i + per]
        for cid, day, usd in cur.execute(
                f"SELECT card_id, day, usd FROM u.price_history WHERE game=? AND card_id IN ({','.join('?' * len(part))}) AND usd IS NOT NULL AND day>? AND day<=? ORDER BY card_id, day",
                (v.game, *part, start_s, lim_s)).fetchall():                  # (only the days on the graph are read)
            p0 = last.get(cid)
            last[cid] = usd
            if p0 is None or usd == p0:                                       # (a card's very first saved price is not a change: its value enters in part 2)
                continue
            gs = held[cid]
            q = gs[0][1] if len(gs) == 1 and gs[0][0] < day else sum(n for since, n in gs if since < day)
            if q:
                dv[bisect.bisect_left(days, day)] += q * (usd - p0)
        if rows:
            yield
    # ---- 2. what each group was worth on the day it entered the graph (own prices: one more index seek each), Card Data's set history, cards with no history
    entry, known_from = {}, {}                                               # known_from (Full price history): item -> its first known day (None: no price history)
    if groups:
        got = v.conn.execute(
            f"WITH g AS ({held_sql}) SELECT g.card_id, g.since, "
            "(SELECT usd FROM u.price_history h WHERE h.game=? AND h.card_id=g.card_id AND h.usd IS NOT NULL AND h.day<=MAX(g.since, ?) ORDER BY day DESC LIMIT 1) FROM g", (*hargs, v.game, start_s))
        entry = {(r[0], r[1]): r[2] for r in got}
        if rows:
            yield
    for r in groups:
        cid, since, q = r["card_id"], r["since"], r["q"]
        e = max(since, start_s)
        if e > days[-1]:
            continue
        i0 = bisect.bisect_left(days, e)
        di[i0] += r["paid"]
        m = market.get(cid)
        if m and (not r["f"] or e < r["f"]):                                  # the set file's prices until the card's own saved prices begin (then the jump to the first one;
            h = m + ([(r["f"], r["fp"])] if r["f"] else [])                   # the own changes after that are in the sum above)
            _contrib(h, [(since, q)], days, start_s, lim_s, dv, backfill=not full)
            known_from[cid] = h[0][0]
        elif r["f"]:
            p0 = entry.get((cid, since))
            known_from[cid] = r["f"]
            if p0 is not None or not full:
                dv[i0] += q * (p0 if p0 is not None else r["fp"])
            elif r["f"] <= lim_s:                                             # Full price history: no price made up before its first known one - it enters on that day
                dv[bisect.bisect_left(days, r["f"])] += q * r["fp"]
        elif full:
            known_from.setdefault(cid, None)                                  # no price history at all: left out of the past days (today's point has today's price)
        else:
            dv[i0] += q * (now_price.get(cid) or 0)                          # (Since purchase) no saved price at all: today's price throughout
    for key, since, q, paid in sealed:
        e = max(since, start_s)
        if e > days[-1]:
            continue
        di[bisect.bisect_left(days, e)] += paid
        h = sealed_hist.get(key)
        if h:
            _contrib(h, [(since, q)], days, start_s, lim_s, dv, backfill=not full)
            known_from[key] = h[0][0]
        elif full:
            known_from.setdefault(key, None)
        else:
            dv[bisect.bisect_left(days, e)] += q * (now_price.get(key) or 0)
    # ---- add up
    items = 0                                                                 # (Full price history) items with a known price on some past day of the graph
    for f in known_from.values():
        if f and f <= lim_s:
            kd[bisect.bisect_left(days, f)] += 1
            items += 1
    pts, val, inv, kn = [], 0.0, 0.0, 0
    for i, ds in enumerate(days):
        val += dv[i]
        inv += di[i]
        if full:
            kn += kd[i]
            pts.append({"day": ds, "value": round(val, 2), "invested": round(inv, 2), "real": kn >= items, "known": kn})
        else:
            pts.append({"day": ds, "value": round(val, 2), "invested": round(inv, 2), "real": bool(real_from and ds >= real_from)})
    if days[-1] == today_s:                                                  # today = today's prices for everything counted
        pts[-1]["value"] = round(sum(r["q"] * (now_price.get(r["card_id"]) or 0) for r in groups if r["since"] <= today_s)
                                 + sum(q * (now_price.get(k) or 0) for k, s, q, _ in sealed if s <= today_s), 2)
        if full:
            pts[-1].update(real=True, known=items)
    while full and len(pts) > 1 and not pts[0]["known"]:                     # the days before any item's price is known: nothing to draw (no price is made up)
        pts.pop(0)
    while len(pts) > 1 and pts[0]["value"] == 0 and pts[0]["invested"] == 0 and range_key != "all":
        pts.pop(0)
    total = round(sum(r["qty"] * (now_price.get(r["card_id"]) or 0) for r in lots) + sum(q * (now_price.get(k) or 0) for k, q in sealed_all), 2)          # everything shown, dated or not
    out = {"points": pts, "realFrom": real_from, "firstBuy": first_buy, "total": total, **base}
    if full:
        out["coverage"] = coverage(v, pts, items, len(known_from) - items)  # (no history: none at all, or only today's price)
        out["realFrom"] = out["coverage"]["fullFrom"] or (pts[0]["day"] if pts else None)         # (the chart shades the stretch before it: not every item's price known yet)
    return out


def coverage(v, pts, items, no_history):
    """What the Full price history graph's notes say (components/DateNote.jsx): items = items with a known price on some day; fullFrom = the first day every one of them
    has one (None when that is the graph's first day); before it at most `known` of them did; noHistory = items with no price history at all, left out of the past days;
    prices = the price choice today's point uses when it is not the saved daily (market) price, else None."""
    full_from = next((p["day"] for p in pts if p["real"]), None)
    before = [p["known"] for p in pts if p["day"] < (full_from or "9999")]
    prices = None if pricepick.is_default(v) else pricepick.label(v)
    return {"items": items, "fullFrom": full_from if before else None, "known": max(before) if before else items, "noHistory": no_history, "prices": prices}
