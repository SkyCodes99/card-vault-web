"""Duplicate cards (roadmap 2.8): a TCGplayer-only copy of a card the source already lists, filed under the WRONG number (30th Classic Collection 2026-11: Charizard as #4, Lugia as #149 - the
numbers of the original prints - next to the real 001-030), so the number-keyed twin merges never met it.

Strict rule for merging by itself (tcgsync.name_twin): same set, same name, exactly one such source card and it has no TCGplayer link yet, the copy's number outside the set's official total or
held by a card of another name, and the set over its official total.  The copy is folded into the real card (tcgsync._fold_into: link, price, and an id redirect so everyone's copies, wishlist
and checklist ticks move to it).  Anything that only half meets the rule waits on the owner's review list (kind 'duplicate_card').

    python -m cardvault.dedupe --data <data dir> [--apply pokemon,...] [--review] [--report out.json]
without --apply nothing is written (the full check over every set of every game)."""
import argparse
import glob
import json
import os
import sqlite3
import sys
import time

from . import provenance, reviewlist, tcgsync

KIND = "duplicate_card"
SOURCE = "duplicate-card check (roadmap 2.8)"
_COLS = "id, local_id, name, tcg_id, price_usd, price_kind, price_updated, set_id, image_base"


def _is_copy(cid, set_id):
    return str(cid).isdigit() and not str(set_id).isdigit()                  # a TCGplayer product id inside a source set


def scan(conn):
    """Read-only.  -> one entry per set that is over its official total (the checker rule: a set's card count matches its official total): {set, name, count, total, over, merge: [(copy row, keep id)], review: [...]}"""
    by_set = {}
    for r in conn.execute(f"SELECT {_COLS} FROM cards"):
        by_set.setdefault(r[7], []).append(r)
    out = []
    for sid, sname, total, official in conn.execute("SELECT id, name, total, official FROM sets").fetchall():
        rows = by_set.get(sid, [])
        top = max(total or 0, official or 0)
        over = bool(top) and len(rows) > top
        if not over:
            continue                                                          # count matches the official total: no duplicate to look for (Funko-style lists share names on purpose)
        reals = [(r[0], r[1], r[2], r[3]) for r in rows if not _is_copy(r[0], sid)]
        keys, nums = set(), {}
        for x in reals:
            keys.update(tcgsync._twin_keys(x[2], x[1]))
            nums.setdefault(tcgsync._numkey(x[1]), []).append(x)
        taken, merge, review = set(), [], []
        for r in sorted((r for r in rows if _is_copy(r[0], sid)), key=lambda r: r[0]):
            if not keys.intersection(tcgsync._twin_keys(r[2], r[1])):
                continue                                                      # no card of that name in the set: nothing to compare
            num = tcgsync._numkey(r[1])
            same_num = nums.get(num, [])
            if any(tcgsync._spelling(x[2], x[1]) == tcgsync._spelling(r[2], r[1]) for x in same_num):
                continue                                                      # a number twin: merge_number_twins' case
            keep, why = tcgsync.name_twin(r[2], r[1], reals, taken)
            if not keep and why != "several":
                continue
            wrong = bool(same_num) or (num.isdigit() and bool(top) and int(num) > top)
            if keep and wrong:
                taken.add(keep)
                merge.append((r, keep))
            else:
                review.append({"copy": r[0], "name": r[2], "number": r[1], "keep": keep or "",
                               "why": "more than one card of that name" if not keep else "its number fits the set"})
        out.append({"set": sid, "name": sname, "count": len(rows), "total": top, "over": over, "merge": merge, "review": review})
    alt = alternates(conn)
    if alt:
        out.append({"set": "", "name": "two sets", "count": 0, "total": 0, "over": False, "merge": [], "review": alt})
    return out


def alternates(conn):
    """An alternate-art card ('28a') the source lists in two sets - its own set and an alternates set such as Yellow A Alternate (xya) - is one card twice (g1-28a / xya-28a, 2026-11).
    Never merged by itself (both are the source's own cards): the owner decides; the proposal keeps the alternates set's card, as the Jolteon-EX fold did.  -> review entries"""
    seen, out = {}, []
    for cid, sid, lid, name in conn.execute("SELECT id, set_id, local_id, name FROM cards WHERE local_id GLOB '[0-9]*[a-z]' AND NOT local_id GLOB '*/*'"):
        if not _is_copy(cid, sid):
            seen.setdefault((tcgsync._numkey(lid), tcgsync._spelling(name, lid)), []).append((cid, sid, lid, name))
    names = {r[0]: (r[1] or "") for r in conn.execute("SELECT id, name FROM sets")}
    for group in seen.values():
        if len({g[1] for g in group}) != 2 or len(group) != 2:
            continue
        a, b = sorted(group, key=lambda g: "alternate" not in names.get(g[1], "").lower())       # the alternates set's card first
        if "alternate" in names.get(a[1], "").lower():
            out.append({"copy": b[0], "name": b[3], "number": b[2], "keep": a[0], "why": f"the same card is also in {names.get(a[1], a[1])}"})
    return out


def _redirects(conn):
    return json.loads((conn.execute("SELECT value FROM meta WHERE key='id_redirects'").fetchone() or ["{}"])[0] or "{}")


def fold(conn, red, row, keep):
    """One copy into its real card; the real card also takes the copy's picture when it has none.  -> the new redirects"""
    red = tcgsync._fold_into(conn, red, row[:7], keep)
    if row[8] and conn.execute("UPDATE cards SET image_base=? WHERE id=? AND (image_base IS NULL OR image_base='')", (row[8], keep)).rowcount:
        provenance.record_image(conn, keep, row[8])
    return red


def merge(conn, found):
    """Folds every certain pair scan() found.  -> cards merged"""
    pairs = [p for s in found for p in s["merge"]]
    if not pairs:
        return 0
    red = _redirects(conn)
    for row, keep in pairs:
        red = fold(conn, red, row, keep)
    conn.execute("INSERT OR REPLACE INTO meta VALUES('id_redirects', ?)", (json.dumps(red, ensure_ascii=False, sort_keys=True),))
    conn.commit()
    return len(pairs)


def queue_review(game, found):
    """The half-certain copies go on the owner's review list (never twice; a settled one stays settled).  -> how many were handed over"""
    n = 0
    for s in found:
        for x in s["review"]:
            target = f' as "{x["keep"]}"' if x["keep"] else ""
            q = (f'"{x["name"]}" (#{x["number"]}) {x["copy"]} looks like the same card as {x["keep"]} ({x["why"]}). ' if not s["set"] else
                 f'"{x["name"]}" (#{x["number"]}) in {s["name"]} looks like a TCGplayer copy of a card already in that set{target} ({x["why"]}). ')
            reviewlist.add_item(KIND, game, x["copy"], q + "Merge it into that card?", before={**x, "set": s["set"], "setName": s["name"]}, source=SOURCE)
            n += 1
    return n


def merge_name_twins(conn, game=None, review=False):
    """The daily step: folds the certain copies; with review=True the rest go on the review list.  -> cards merged"""
    found = scan(conn)
    if review and game:
        queue_review(game, found)
    return merge(conn, found)


def _settle(item, ans, value, ctx):
    """Owner's answer: yes = fold the copy into the named card (or the card id he typed), no = it is a different card and stays."""
    if ans == "no":
        return "kept as a separate card"
    from .db import game_dir
    from .paths import release_data_dir
    b = item["before"] or {}
    keep = (value or b.get("keep") or "").strip()
    if not keep:
        return "nothing merged: type the id of the card to keep"
    conn = sqlite3.connect(os.path.join(game_dir((ctx or {}).get("data_dir") or release_data_dir(), item["game"]), "cards.db"), timeout=60)
    try:
        row = conn.execute(f"SELECT {_COLS} FROM cards WHERE id=?", (item["item_id"],)).fetchone()
        if not row or not conn.execute("SELECT 1 FROM cards WHERE id=?", (keep,)).fetchone():
            return "nothing to merge: one of the two cards is gone"
        if item["game"] == "funko":
            from . import funkovariants                                           # a hobbyDB Funko row folds INTO the TCGplayer row (it keeps the price and number)
            red = funkovariants.fold(conn, _redirects(conn), item["item_id"], keep)
        else:
            red = fold(conn, _redirects(conn), row, keep)
        conn.execute("INSERT OR REPLACE INTO meta VALUES('id_redirects', ?)", (json.dumps(red, ensure_ascii=False, sort_keys=True),))
        conn.commit()
    finally:
        conn.close()
    return f"merged into {keep}; owners of the copy moved to it"


reviewlist.register(KIND, apply=_settle)


def full_check(data_dir, apply=(), review=False, log=print):
    """Every set of every game.  Read-only except the games in apply (merged) and, with review, the review list.  -> {game: {...counts, sets: [...]}}"""
    report = {}
    for path in sorted(glob.glob(os.path.join(data_dir, "games", "*", "cards.db"))):
        game = os.path.basename(os.path.dirname(path))
        conn = sqlite3.connect(path, timeout=60) if game in apply else sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            found = scan(conn)
            merged = merge(conn, found) if game in apply else 0
            queued = queue_review(game, found) if review else 0
        finally:
            conn.close()
        over = [s for s in found if s["over"]]
        report[game] = {"setsOver": len(over), "canMerge": sum(len(s["merge"]) for s in found), "merged": merged, "review": sum(len(s["review"]) for s in found), "queued": queued,
                        "sets": [{**{k: s[k] for k in ("set", "name", "count", "total", "over", "review")}, "merge": [{"copy": r[0], "name": r[2], "number": r[1], "keep": k} for r, k in s["merge"]]}
                                 for s in found]}
        if over or found:
            log(f"{game}: {len(over)} sets over their total, {report[game]['canMerge']} certain copies ({merged} merged), {report[game]['review']} for review")
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data", required=True)
    ap.add_argument("--apply", default="", help="games to merge in, comma-separated")
    ap.add_argument("--review", action="store_true", help="put the uncertain copies on the review list")
    ap.add_argument("--report", default="")
    a = ap.parse_args(argv)
    t = time.time()
    rep = full_check(a.data, apply=[g for g in a.apply.split(",") if g], review=a.review)
    if a.report:
        with open(a.report, "w", encoding="utf-8") as f:
            json.dump(rep, f, ensure_ascii=False, indent=1)
    tot = {k: sum(g[k] for g in rep.values()) for k in ("setsOver", "canMerge", "merged", "review", "queued")}
    print(f"all games: {tot} in {time.time() - t:.1f}s")


if __name__ == "__main__":
    sys.exit(main())
