"""Pack arts of a sleeved booster pack: which of a set's pack arts (Roaring Moon, Iron Valiant, ...) you have, and how many of each.

The product itself does not change: one picture, one quantity.  Opening it shows each art of the set with a count; the counts of one purchase line (a row of u.sealed) never add up to more
than that line's quantity.  The arts ship as data (data/pack_arts_pokemon.json, made by tools/fetch_pack_arts.py): names only.  The art names are facts (which Pokemon each pack shows), read
from Bulbapedia's set pages; no Bulbapedia text or picture is shipped or shown (CC BY-NC-SA, non-commercial: owner quiz 2026-11-15 q4 "Find another source"), so there is no Bulbapedia credit.
An art shows "No picture yet" until a photo list fills its "img" (+ "credit", "src") with tools/apply_pack_art_photos.py; picture() refuses a non-commercial host even then (ncsource.py).

Products TCGplayer sells once per art ("XY - Fates Collide Sleeved Booster Pack [Zygarde]") are folded into one pack with arts (owner quiz 2026-11-15 q5 "Yes"): the merged item's arts name
the product each one replaces ("from").  fold_split() moves every purchase line of such a product onto the merged one (same line, same quantity) and counts its packs as that art; it runs
when a collection opens and after a sync, so a line an older version (or an import) still makes under the old name follows on the next start.

Stored per purchase line in u.sealed_arts (its own table, so nothing about the purchase row itself changes); each (line, art) count is one record with its own updated_at, so the account sync merges
them newest-wins like everything else (cloud/snapshot.py, kind 'pack_arts').  A count put back to 0 stays as a row with n=0 - that is how "removed" travels to the other devices."""
import json
import os
import re

from . import ncsource, pkgdata

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "pack_arts_pokemon.json")
SCHEMA = ("CREATE TABLE IF NOT EXISTS u.sealed_arts(sealed_uuid TEXT NOT NULL, art TEXT NOT NULL, user_id TEXT, game TEXT, n INTEGER NOT NULL DEFAULT 0, updated_at TEXT, "
          "PRIMARY KEY(sealed_uuid, art))",
          "CREATE INDEX IF NOT EXISTS u.sealed_arts_user ON sealed_arts(user_id, game)")
MAX_N = 9999
_DATA = {}


def norm_name(s):
    """The same letters-and-digits key as tcgcsv.norm_name (kept here: the account sync imports this module early, before the card lists can be)."""
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def ensure(v):
    """The table (idempotent: safe on every start)."""
    for sql in SCHEMA:
        v.conn.execute(sql)


def _load(path=None):
    path = path or DATA_FILE
    if path not in _DATA:
        try:
            with pkgdata.open_text(path) as f:                                    # (the website imports the package from cardvault.zip: a plain open() fails there)
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        _DATA[path] = d if isinstance(d, dict) else {}
    return _DATA[path]


def picture(a):
    """An art's picture address when it may be shown, else '' ("No picture yet")."""
    return ncsource.picture(a.get("img"))


def for_ui(e):
    """The arts of one item as the window shows them: id, name, picture (or ''), the picture's credit."""
    out = []
    for a in e["arts"]:
        img = picture(a)
        out.append({"id": a["id"], "name": a["name"], "img": img, "credit": (a.get("credit") or "") if img else ""})
    return out


def for_name(name, game="pokemon", path=None):
    """The pack arts of one product (found by its name, letters and digits only), or None when it has none on record."""
    if game != "pokemon":
        return None
    e = (_load(path).get("items") or {}).get(norm_name(name))
    return e if e and len(e.get("arts") or ()) >= 2 else None


def counts(v, uuids):
    """{purchase line uuid: {art id: n}} (only counts above 0)."""
    out = {u: {} for u in uuids}
    uuids = list(uuids)
    for i in range(0, len(uuids), 500):
        part = uuids[i:i + 500]
        for su, art, n in v.conn.execute(f"SELECT sealed_uuid, art, n FROM u.sealed_arts WHERE user_id=? AND sealed_uuid IN ({','.join('?' * len(part))}) AND n>0", (v.user_id, *part)):
            out.setdefault(su, {})[art] = n
    return out


def _merges(path=None):
    """{letters-and-digits name of a product sold once per art: (merged item, art id)}."""
    out = {}
    for e in (_load(path).get("items") or {}).values():
        for a in e.get("arts") or ():
            if a.get("from"):
                out[norm_name(a["from"])] = (e, a["id"])
    return out


_UP = ("INSERT INTO u.sealed_arts(sealed_uuid, art, user_id, game, n, updated_at) VALUES(?,?,?,?,?,?) "
       "ON CONFLICT(sealed_uuid, art) DO UPDATE SET n=excluded.n, updated_at=excluded.updated_at")


def fold_split(v, now, path=None):
    """Move every purchase line of a product sold once per art onto its merged pack (any user of this file): the line keeps its uuid, quantity, price and date, takes the merged
    name, and its packs are counted as that art (2 of "[Zygarde]" -> 2 packs on the merged product, art zygarde = 2).  Both changes carry a fresh updated_at, so the sync sends them on.
    Idempotent (a moved line no longer has the old name).  -> number of lines moved."""
    try:
        rows = v.conn.execute("SELECT uuid, user_id, game, name, qty, upc FROM u.sealed WHERE deleted=0 AND game='pokemon' AND name LIKE '%sleeved%[%'").fetchall()
    except Exception:  # noqa: BLE001 - a collection from before sealed products
        return 0
    m = _merges(path) if rows else {}
    moved = 0
    for uuid, user, game, name, qty, upc in rows:
        hit = m.get(norm_name(name))
        if not hit:
            continue
        e, art = hit
        v.conn.execute("UPDATE u.sealed SET name=?, updated_at=? WHERE uuid=?", (e["name"], now, uuid))
        if (qty or 0) > 0:
            v.conn.execute(_UP, (uuid, art, user, game, min(MAX_N, int(qty)), now))
        if upc:
            v.conn.execute("UPDATE u.upc_names SET name=? WHERE upc=?", (e["name"], upc))
        moved += 1
    return moved


def fold_catalog(rows, path=None):
    """The sealed list (webapi/sealedcat rows) with the products sold once per art shown as their one merged pack: the tile of the newest-priced one, renamed."""
    m = _merges(path)
    if not m or not any(r.get("norm") in m for r in rows):
        return rows
    out, merged = [], {}
    for r in rows:
        hit = m.get(r.get("norm"))
        if not hit:
            out.append(r)
            continue
        e = hit[0]
        k = norm_name(e["name"])
        cur = merged.get(k)
        if cur is None:
            cur = merged[k] = dict(r, name=e["name"], norm=k)
            out.append(cur)
        elif r.get("price") is not None and (cur.get("price") is None or (r.get("priceDay") or "") > (cur.get("priceDay") or "")):
            cur.update({x: r[x] for x in ("id", "img", "price", "priceKind", "priceDay") if x in r})
    return out


class TooMany(ValueError):
    """The counts would add up to more than the purchase line's quantity."""


def set_count(v, sealed_uuid, art, n, now, path=None):
    """Set how many of one art a purchase line holds.  Raises KeyError (no such line / art) or TooMany.  Lowering is always allowed (a line can hold fewer packs than before, after opening some)."""
    row = v.conn.execute("SELECT name, qty, game FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (sealed_uuid, v.user_id)).fetchone()
    if not row:
        raise KeyError("line")
    e = for_name(row["name"], row["game"] or v.game, path)
    if not e or art not in {a["id"] for a in e["arts"]}:
        raise KeyError("art")
    n = max(0, min(MAX_N, int(n)))
    have = counts(v, [sealed_uuid]).get(sealed_uuid, {})
    old = have.get(art, 0)
    if n == old:
        return have
    others = sum(x for k, x in have.items() if k != art)
    if n > old and others + n > (row["qty"] or 0):
        raise TooMany(row["qty"] or 0)
    v.conn.execute("INSERT INTO u.sealed_arts(sealed_uuid, art, user_id, game, n, updated_at) VALUES(?,?,?,?,?,?) "
                   "ON CONFLICT(sealed_uuid, art) DO UPDATE SET n=excluded.n, updated_at=excluded.updated_at", (sealed_uuid, art, v.user_id, row["game"] or v.game, n, now))
    have = dict(have)
    if n:
        have[art] = n
    else:
        have.pop(art, None)
    return have


def split_line(v, old_uuid, new_uuid, keep_qty, new_qty, now):
    """A purchase line was split (buys.sealed_split): `keep_qty` packs stay on the old line, `new_qty` went to the new one.  The old line keeps its counts up to keep_qty; what is
    over moves to the new line (never more than new_qty), so neither line says it holds more arts than packs."""
    have = counts(v, [old_uuid]).get(old_uuid, {})
    if sum(have.values()) <= keep_qty:
        return
    room_old, room_new, game = keep_qty, new_qty, v.game
    up = "INSERT INTO u.sealed_arts(sealed_uuid, art, user_id, game, n, updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(sealed_uuid, art) DO UPDATE SET n=excluded.n, updated_at=excluded.updated_at"
    for art, n in sorted(have.items()):
        stay = min(n, room_old); room_old -= stay
        move = min(n - stay, room_new); room_new -= move
        if stay != n:
            v.conn.execute(up, (old_uuid, art, v.user_id, game, stay, now))          # (a 0 is kept as a row: that is how the lower count reaches other devices)
        if move:
            v.conn.execute(up, (new_uuid, art, v.user_id, game, move, now))


# ------------------------------------------------------------------------------------------------ account sync (cloud/snapshot.py)
def export_rows(v):
    """Every count of this game as sync records (sorted the way merge() gives them)."""
    try:
        rows = v.conn.execute("SELECT sealed_uuid, art, n, updated_at FROM u.sealed_arts WHERE user_id=? AND game=? ORDER BY sealed_uuid, art", (v.user_id, v.game)).fetchall()
    except Exception:  # noqa: BLE001 - a collection from before this existed
        return []
    return [{"sealed": a, "art": b, "n": n or 0, "updated_at": ts or ""} for a, b, n, ts in rows]


def key(r):
    return f"{r['sealed']}|{r['art']}"


def apply_rows(v, rows):
    """Write merged records in: a record whose updated_at differs from ours replaces ours.  -> how many changed."""
    if not rows:
        return 0
    ensure(v)
    have = {f"{a}|{b}": ts or "" for a, b, ts in v.conn.execute("SELECT sealed_uuid, art, updated_at FROM u.sealed_arts WHERE user_id=? AND game=?", (v.user_id, v.game))}
    changed = 0
    for r in rows:
        if not r.get("sealed") or not r.get("art"):
            continue
        if have.get(key(r)) == (r.get("updated_at") or ""):
            continue
        v.conn.execute("INSERT OR REPLACE INTO u.sealed_arts(sealed_uuid, art, user_id, game, n, updated_at) VALUES(?,?,?,?,?,?)",
                       (r["sealed"], r["art"], v.user_id, v.game, max(0, min(MAX_N, int(r.get("n") or 0))), r.get("updated_at") or ""))
        changed += 1
    return changed
