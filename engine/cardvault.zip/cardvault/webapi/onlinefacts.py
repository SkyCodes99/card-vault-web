"""The website's whole-list views of YOUR cards when a game's card list is not kept on this device (3.50.136 lane O2; "Keep for offline use" off, lane P).

Card Data's pages (ui/src/online) answer searches and set pages, but the owned / wishlist / spares / missing views of the whole list, the owned-first orders, sections, eras, 'Stored in'
and a search word that is a storage place all need the whole list joined with the collection - which no server may see.  So the page downloads the open game's FACTS file once
(cardvault/query/facts.py: /q/v1/<game>/<cv>.<pv>/facts, the same for everyone, kept on the device) and hands it to this engine in chunks (online.factsLoad).  The engine puts it in a small
in-memory SQLite db beside the collection and answers cards.list there with ITS OWN code: the filters and orders are Vault._query_cards_sql / query_cards run on that db (the same SQL the
engine runs on a whole list), what is yours comes from the collection (cards.mine_rows).  Nothing about the collection is ever sent anywhere.

The safety net: on the website, a question that needs a list this device does not have (and that the facts cannot answer) never answers an empty list - it answers "warming" (the page's
"Getting your cards ready…" and its retries) while the list is downloaded in the background (gamesapi.ensure_job)."""
import json
import sqlite3
from operator import itemgetter

from .. import checklists, fuzzy, runtime, searchfold, taxonomy
from ..db import Vault, edition_of, fix_text, picture_url
from ..query import facts as qfacts
from .registry import ApiError, api
from . import cards, gamesapi

COLS = qfacts.CARD_COLS + ("fold", "era", "label")


class Facts:
    """One game's facts, in memory: cards (the engine's column names), sets, msrp, and per question a copy of YOUR copies' rows (lots_s) and wishlist, so the engine's own SQL runs as is."""

    def __init__(self, key, game, n, present, sets, msrp):
        self.key, self.game, self.n, self.present = key, game, int(n), set(present or ())
        self.loaded, self.ready, self._vocab, self._names = 0, False, None, None
        c = self.conn = sqlite3.connect(":memory:", check_same_thread=False)
        c.create_function("fold", 1, searchfold.fold, deterministic=True)            # (the engine's SQL folds the illustrator and the name: build._register)
        c.execute("ATTACH ':memory:' AS u")
        c.execute(f"CREATE TABLE cards(rid INTEGER PRIMARY KEY, {', '.join(COLS)})")
        scols = list(sets.get("cols") or [])
        if "id" not in scols:
            raise ApiError("those facts have no sets")
        c.execute(f"CREATE TABLE sets({', '.join(dict.fromkeys(scols + list(qfacts.SET_COLS)))})")
        c.executemany(f"INSERT INTO sets({', '.join(scols)}) VALUES({', '.join('?' * len(scols))})", sets.get("rows") or [])
        mc = list(msrp.get("cols") or qfacts.MSRP_COLS)
        c.execute(f"CREATE TABLE msrp({', '.join(mc)})")
        c.executemany(f"INSERT INTO msrp VALUES({', '.join('?' * len(mc))})", msrp.get("rows") or [])
        c.execute("CREATE TEMP TABLE lots_s(card_id TEXT, user_id, game TEXT, deleted INTEGER, qty INTEGER, location TEXT)")
        c.execute("CREATE TABLE u.wishlist(user_id, game TEXT, card_id TEXT)")

    def add(self, start, data):
        """One chunk: {column: [values]} of the cards from `start` on (in the file's order)."""
        if int(start) != self.loaded:
            raise ApiError("facts out of order", code="facts")
        cols = [k for k in data if k in COLS or k == "foldx"]
        n = len(data.get("id") or [])
        if any(len(data[k]) != n for k in cols):
            raise ApiError("facts chunk is not even", code="facts")
        get = lambda k, i: data[k][i] if k in data else None
        rows = []
        for i in range(n):
            fold = get("foldx", i)
            if fold is None:                                                         # (most cards: their words are the plain fold of these - facts.make left them out)
                fold = searchfold.words(get("name", i), get("local_id", i), get("illustrator", i), get("rarity", i))
            rows.append(tuple(get(k, i) for k in qfacts.CARD_COLS) + (fold, get("era", i) or "", get("label", i) or ""))
        self.conn.executemany(f"INSERT INTO cards({', '.join(COLS)}) VALUES({', '.join('?' * len(COLS))})", rows)
        self.loaded += n
        if self.loaded >= self.n:
            self.conn.execute("CREATE UNIQUE INDEX cards_id ON cards(id)")
            self.conn.execute("CREATE INDEX cards_set ON cards(set_id)")
            self.conn.commit()
            self.ready = True

    # ---- what the engine's list code asks of a card list
    def names(self):
        if self._names is None:
            self._names = {r[0]: r[1] for r in self.conn.execute("SELECT id, name FROM sets")}
        return self._names

    def vocab(self):
        """The name words for typo tolerance (Vault.fuzzy_vocab: the names and English names of the list)."""
        if self._vocab is None:
            counts = {}
            for col in ("name", "name_en"):
                if col in self.present or col == "name":
                    fuzzy.count_words((r[0] for r in self.conn.execute(f"SELECT DISTINCT {col} FROM cards")), counts)
            self._vocab = fuzzy.Vocab(counts)
        return self._vocab

    def era_ids(self, era, edition=None):
        sql = "SELECT c.id, s.serie FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE instr(',' || c.era || ',', ?) > 0"
        return {cid for cid, serie in self.conn.execute(sql, (f",{era},",)) if not edition or edition_of(serie) == edition}

    def set_ids(self, set_id):
        return [r[0] for r in self.conn.execute("SELECT id FROM cards WHERE set_id=? ORDER BY rid", (set_id,))]

    def view(self, v):
        """The engine's list code on these facts, with YOUR copies and wishlist as they are now (copied in: a few thousand rows at most)."""
        c = self.conn
        c.execute("DELETE FROM temp.lots_s")
        c.executemany("INSERT INTO temp.lots_s VALUES(?,?,?,?,?,?)", v.conn.execute("SELECT card_id, user_id, game, deleted, qty, location FROM lots_s WHERE user_id=? AND game=?",
                                                                                     (v.user_id, v.game)).fetchall())
        c.execute("DELETE FROM u.wishlist")
        c.executemany("INSERT INTO u.wishlist VALUES(?,?,?)", ((v.user_id, v.game, cid) for cid in v.wishlist_ids()))
        return _View(self, v)

    def rows(self, svc, v, shown, names):
        """cards._rows on the facts: the list part of each row (pictures from Card Data's addresses, as its pages give them), then what is yours (cards.mine_rows)."""
        from .. import comicskeys, msrp, onesource
        ids = [r[0] for r in shown]
        got = {}
        for i in range(0, len(ids), 500):
            part = ids[i:i + 500]
            for r in self.conn.execute(f"SELECT c.id, c.price_usd, c.tcg_id, c.price_kind, c.rarity, c.image_base, s.serie FROM cards c LEFT JOIN sets s ON s.id=c.set_id "
                                       f"WHERE c.id IN ({','.join('?' * len(part))})", part):
                got[r[0]] = r
        retail = msrp.lookup(self.conn, ids)
        one = onesource.ids(self.conn, "cards", ids)
        pokemon = svc.game.pokemon
        out = []
        for cid, name, set_id, local_id in shown:
            _i, usd, tcg, kind, rar, base, serie = got.get(cid) or (cid, None, "", "", "", "", "")
            img = (picture_url(base, "low") if pokemon else base) if base else ""
            out.append({"id": cid, "name": fix_text(name), "setId": set_id, "set": names.get(set_id, set_id), "number": local_id, "price": usd, "tcg": tcg or "", "priceKind": kind or "",
                        "digital": "pocket" in (serie or "").lower(), "rarity": rar or "", "img": img, "msrp": retail.get(cid), "one": cid in one,
                        **({"key": True} if rar == comicskeys.KEY else {})})
        return cards.mine_rows(svc, v, out)


class _View:
    """Enough of a Vault for its own query_cards to run on the facts db (Vault._query_cards_sql reads conn, user_id, game and these few answers)."""
    query_cards = Vault.query_cards
    _query_cards_exact = Vault._query_cards_exact
    _query_cards_sql = Vault._query_cards_sql
    _own_exists = Vault._own_exists

    def __init__(self, f, v):
        self.conn, self.user_id, self.game, self._f, self._v = f.conn, v.user_id, v.game, f, v

    def catalog_fp(self):
        return None                                        # (nothing kept between questions: the facts db is small and every question is asked of it afresh)

    def _fold_use(self):
        return True

    def _has_era(self):
        return "era_hint" in self._f.present

    def _has_pop(self):
        return "popularity" in self._f.present

    def owned_map(self):
        return self._v.owned_map()

    def wishlist_ids(self):
        return self._v.wishlist_ids()

    def fuzzy_vocab(self):
        return self._f.vocab()


def held(svc):
    """The open game's facts when they are all here (None: not loaded, still loading, or another game's)."""
    f = svc.__dict__.get("_online_facts")
    return f if f is not None and f.ready and f.game == svc.game.id else None


@api("online.factsState", quiet=True)
def facts_state(svc):
    f = svc.__dict__.get("_online_facts")
    if f is None or f.game != svc.game.id:
        return {"key": "", "have": 0}
    return {"key": f.key if f.ready else "", "loading": f.key, "have": f.loaded}


@api("online.factsLoad", quiet=True)
def facts_load(svc, key, start, data, n=0, present=None, sets=None, msrp=None):
    """One chunk of the open game's facts file (the page sends it in parts of a few thousand cards, so the engine answers clicks in between).  start=0 begins it (with the sets)."""
    if not str(key).startswith(svc.game.id + "|"):
        raise ApiError("those facts are another game's", code="facts")
    f = svc.__dict__.get("_online_facts")
    if int(start) == 0:
        f = svc._online_facts = Facts(key, svc.game.id, n, present, sets or {}, msrp or {})
    elif f is None or f.key != key:
        raise ApiError("facts out of order", code="facts")
    f.add(start, data or {})
    return {"have": f.loaded, "ready": f.ready}


def _rank(pokemon):
    return taxonomy.label_rank if pokemon else taxonomy.rarity_rank


def facts_list(svc, f, kind="all", val=None, edition=None, text="", show="all", ctype="", rarity="", sort="default", split=False, limit=1500, era="",
               price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None, priced="", letter="", place="", facets=None, facet_ids=None, _t=None):
    """cards.list (cardvault/webapi/cards.cards_list, the same steps in the same order) on the facts: kind 'all' or 'set'.  The game's own filters (facets) come as `facet_ids`: the cards
    Card Data says match them (/q/v1/.../match - a catalog question only).  tests/test_online_parity.py compares every answer with cards.list on the whole list."""
    show = "wishlist" if show == "wish" else show
    if kind not in ("all", "set") or (kind == "set" and not val):
        raise ApiError("not a list the facts answer", code="facts")
    if isinstance(facets, dict) and any(vals for vals in facets.values()) and facet_ids is None:
        raise ApiError("the game's own filters need Card Data's answer", code="facts")
    v = svc.vault
    fv = f.view(v)
    qkw = dict(set_id=val if kind == "set" else None, show=show, ctype=ctype or None, rarity=rarity or None, sort=sort, only_ids=None, edition=edition,
               price_min=None if price_min in (None, "") else price_min, price_max=None if price_max in (None, "") else price_max,
               set_text=set_text or "", artist=artist or "", year_min=year_min, year_max=year_max, priced=priced or "", letter=letter or "")
    words = (text or "").strip()
    at_place = cards._place_ids(v, words) if words and not place else set()
    raw = fv.query_cards(text=words, fuzzy=True, **qkw)
    if at_place:
        in_place = at_place - {r[0] for r in raw}
        if in_place:
            raw = list(raw) + [r for r in fv.query_cards(text="", only_ids=sorted(in_place), **{k: x for k, x in qkw.items() if k != "only_ids"}) if r[0] in in_place]
    if place:
        keep = cards._place_ids(v, place.strip())
        raw = [r for r in raw if r[0] in keep]
    if era:
        in_era = f.era_ids(era)
        raw = [r for r in raw if r[0] in in_era]
    if facet_ids is not None:
        keep = set(facet_ids)
        raw = [r for r in raw if r[0] in keep]
    names = f.names()
    left_n, excl = 0, set()
    if kind == "set":
        excl = v.excluded_cards(val)
        left_n = len(excl)
        raw = [r for r in raw if (r[0] in excl) == (show == "left")]
    pos = {c for c, q in svc.owned.items() if q > 0}
    n_all, n_owned = len(raw), sum(map(pos.__contains__, map(itemgetter(0), raw)))
    rows = f.rows(svc, v, raw if split else raw[:max(0, int(limit))], names)
    out = {"rows": rows, "total": n_all, "owned": n_owned, "sections": None, "leftOut": left_n}
    if split:
        if len(rows) > cards.MAX_SECTION_CARDS:
            out["splitRefused"] = True
        else:
            pokemon = svc.game.pokemon
            labels = dict(f.conn.execute("SELECT id, label FROM cards WHERE id IN (SELECT value FROM json_each(?))", (json.dumps([r["id"] for r in rows]),))) if pokemon else {}
            by = {}
            for r in rows:
                lab = (labels.get(r["id"]) or r["rarity"] or "Unlabelled") if pokemon else (r["rarity"] or "Unlabelled")
                by.setdefault(lab, []).append(r["id"])
            rank = _rank(pokemon)
            out["sections"] = [{"title": t, "ids": by[t]} for t in sorted(by, key=lambda x: (rank(x), x))]
    if kind == "set":
        prog = checklists.progress_for_cards(v, [i for i in f.set_ids(val) if i not in excl])
        out["progress"] = {"owned": prog.owned, "total": prog.total, "pct": prog.pct}
        out["title"] = names.get(val, val)
    return out


@api("online.factsList", quiet=True)
def online_facts_list(svc, **args):
    """cards.list from the facts (the page asks it when Card Data's pages cannot answer a question exactly - see ui/src/online/routes.js)."""
    f = held(svc)
    if f is None:
        raise ApiError("the facts are not here yet", code="facts")
    return facts_list(svc, f, **args)


def eras(f, edition=None):
    """cards.filters' eras (cards._pokemon_eras) from the facts: the eras in order, each with how many cards it has."""
    return [{"id": grp.id, "label": grp.label, "n": n} for grp in taxonomy.groups() if grp.parent == "era" and (n := len(f.era_ids(grp.id, edition)))]


@api("online.factsEras", quiet=True)
def online_facts_eras(svc, edition=None):
    f = held(svc)
    if f is None:
        raise ApiError("the facts are not here yet", code="facts")
    return eras(f, edition) if svc.game.pokemon else []


# ---------------------------------------------------------------------------------------------------------------- the safety net
def list_missing(svc):
    """True on the website when the open game's card list is not on this device: read from Card Data (offline switch off), or still downloading (switch on) - either way an engine
    list question would find no cards, and must not answer as if the person had none."""
    if not runtime.IN_BROWSER or getattr(svc.game, "own", False):
        return False
    try:
        return not svc.vault.conn.execute("SELECT 1 FROM cards LIMIT 1").fetchone()
    except sqlite3.Error:
        return True


def not_here(svc):
    """A question that needs the open game's whole list, which is not on this device: never an empty answer.  The list starts downloading in the background (or goes on downloading)
    and the question answers "warming" - the page shows "Getting your cards ready…" and asks again until it is in (ui/src/engine/client.js).  A list that cannot be had says why."""
    gamesapi.ensure_job(svc, svc.game.id, then_open=True)
    raise ApiError("Getting your cards ready…", code="warming")


def guard_list(svc, args):
    """cards.list on the website for a game whose list is not here: from the facts when they are all here and can answer it, else not_here.  -> the answer, or None (the list is here)."""
    if not list_missing(svc):
        return None
    f = held(svc)
    kind = args.get("kind", "all")
    fs = args.get("facets")
    if f is not None and kind in ("all", "set") and (kind == "all" or args.get("val")) and not (isinstance(fs, dict) and any(fs.values())):
        return facts_list(svc, f, **args)
    not_here(svc)
