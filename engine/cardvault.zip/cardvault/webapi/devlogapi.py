"""Dev Tools (owner only - every dev.* method is refused for other accounts by the engine): the Daily update log and the one Review list."""
from .. import dailylog, reviewfix, reviewlist, runtime  # noqa: F401  (reviewfix registers what each kind of review item does when answered)
from .registry import ApiError, api

DESKTOP_ONLY = "The daily log and the review list live on the PC that runs the daily update - open Dev Tools in the desktop app there."


@api("dev.daily.log", quiet=True)
def daily_log(svc, game="", kind="", days=30, limit=500):
    """What the daily runs added or changed, newest first, filtered by game and kind -> {events, total, games, kinds, days}"""
    if runtime.IN_BROWSER:                       # (the website has no access to that PC's folders: say so, never an empty log)
        return {"events": [], "total": 0, "games": [], "kinds": [], "days": days, "desktopOnly": DESKTOP_ONLY}
    return dailylog.read(game, kind, days, limit)


def _view(it):
    return {k: it[k] for k in ("id", "kind", "game", "item_id", "question", "before", "after", "source", "status", "tries", "rejected", "answer", "final", "applied", "created", "answered")}


@api("dev.review.list", quiet=True)
def review_list(svc, status="", game="", kind=""):
    """Everything on the review list that still waits (or one status), newest first -> {items, counts, games, kinds}"""
    if runtime.IN_BROWSER:                       # (not 'All caught up': the list simply isn't reachable from here)
        return {"items": [], "counts": {}, "games": [], "kinds": [], "desktopOnly": DESKTOP_ONLY}
    rows = reviewlist.items(status, game, kind)
    every = reviewlist.items("", "", "")
    return {"items": [_view(r) for r in rows], "counts": reviewlist.counts(), "games": sorted({r["game"] for r in every}), "kinds": sorted({r["kind"] for r in every})}


@api("dev.review.answer")
def review_answer(svc, id, yes=None, value=None):
    """Your answer to one item: yes / no, or the right value when it asks for one.  It is applied right away -> the item as it is now."""
    if runtime.IN_BROWSER:
        raise ApiError(DESKTOP_ONLY, code="review")
    try:
        return _view(reviewlist.answer(id, yes=yes, value=value))
    except reviewlist.ReviewError as e:
        raise ApiError(str(e), code="review")
