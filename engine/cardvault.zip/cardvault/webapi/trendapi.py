"""Sale Data: choose which prices to show (Standard / Sale Data / Both), and keep the saved-price trend files fresh."""
from .. import games, trend
from ..db import game_dir
from .registry import api

MODES = ("standard", "sale", "both")


def mode(svc):
    m = svc.cfg.get("price_mode")
    return m if m in MODES else "standard"


def primary(svc):
    return "sale" if svc.cfg.get("price_primary") == "sale" else "standard"


def refresh(svc):
    """Fetch newer trend files for the installed games (once a day is plenty; a missing file just means 'no trend yet').  The game you are looking at comes first.  In the browser one game is done per
    call (a trend file is several MB, and its engine cannot do anything else meanwhile): True means there may be more, and the scheduler comes back for them at the next quiet moment."""
    if svc.session is None:
        return False
    from . import gamesapi
    from .. import carddata
    from ..runtime import INLINE
    base, m = carddata.first_manifest(svc, "trend", trend.manifest)
    if not m:
        return False
    here = svc.vault.game if svc.vault is not None else ""
    todo = [gid for gid, entry in sorted(m["games"].items(), key=lambda kv: kv[0] != here)
            if gamesapi.has_catalog(svc, gid) and (trend.local_built(game_dir(svc.cfg["data_dir"], gid)) or "") < (entry.get("built") or m.get("built") or "~")]
    for i, gid in enumerate(todo):
        try:
            trend.install(game_dir(svc.cfg["data_dir"], gid), base, gid)
        except Exception:  # noqa: BLE001 - try again at the next check
            continue
        svc._trend = None
        if INLINE:
            return i + 1 < len(todo)
    return False


def refresh_corrections(svc):
    """Fetch the owner's published corrections (Card Data /corrections/cards.json) into the cache; the open game is re-read when they changed."""
    from .. import carddata, corrections
    for b in carddata.bases(svc, "corrections"):
        try:
            changed = corrections.refresh(svc.cfg["data_dir"], b)
            try:
                if corrections.refresh_sealed(svc.cfg["data_dir"], b):          # the owner's corrections to sealed products (type, series, hidden)
                    changed = True
                    if svc.vault is not None:
                        svc.vault._sealed_stamp = getattr(svc.vault, "_sealed_stamp", 0) + 1
            except Exception:  # noqa: BLE001
                pass
            if changed:
                if svc.vault is not None:
                    svc.vault.invalidate_index()
                svc.bump("changed")
            return
        except Exception:  # noqa: BLE001
            continue


@api("trend.status", quiet=True)
def status(svc):
    t = trend.for_vault(svc)
    return {"mode": mode(svc), "primary": primary(svc), "days": t.days, "built": t.built, "products": len(t.rows)}


def attach(svc, rows, key="id", into="sale"):
    """Add the recent price and trend to list rows when Sale Data is switched on (rows are dicts with an id)."""
    if mode(svc) == "standard":
        return rows
    t = trend.for_vault(svc)
    for r in rows:
        i = t.info(r[key])
        if i:
            r[into], r[into + "Trend"] = i["recent"], i["trend"]
    return rows
