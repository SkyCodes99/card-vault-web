"""Sale Data: choose which prices to show (Standard / Sale Data / Both), and keep the saved-price trend files fresh."""
from .. import games, trend
from ..db import game_dir
from .registry import api

MODES = ("standard", "sale", "both")


def mode(svc):
    m = svc.cfg.get("price_mode")
    return m if m in MODES else "standard"


def primary(svc):
    return "sale" if svc.cfg.get("price_primary") == "sale" else "standard"


def refresh(svc):
    """Fetch newer trend files for every installed game (once a day is plenty; a missing file just means 'no trend yet')."""
    if svc.session is None:
        return
    from . import gamesapi
    base = trend.base_for(gamesapi.catalog_base(svc))
    m = trend.manifest(base)
    if not m:
        return
    for gid, entry in m["games"].items():
        if not gamesapi.has_catalog(svc, gid):
            continue
        gdir = game_dir(svc.cfg["data_dir"], gid)
        if (trend.local_built(gdir) or "") >= (entry.get("built") or m.get("built") or "~"):
            continue
        try:
            trend.install(gdir, base, gid)
        except Exception:  # noqa: BLE001 - try again at the next check
            continue
        svc._trend = None


@api("trend.status", quiet=True)
def status(svc):
    t = trend.for_vault(svc)
    return {"mode": mode(svc), "primary": primary(svc), "days": t.days, "built": t.built, "products": len(t.rows)}


def attach(svc, rows, key="id", into="sale"):
    """Add the recent price and trend to list rows when Sale Data is switched on (rows are dicts with an id)."""
    if mode(svc) == "standard":
        return rows
    t = trend.for_vault(svc)
    for r in rows:
        i = t.info(r[key])
        if i:
            r[into], r[into + "Trend"] = i["recent"], i["trend"]
    return rows
