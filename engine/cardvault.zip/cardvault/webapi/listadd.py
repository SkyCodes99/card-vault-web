"""Adding things to a checklist one by one: the "Add to checklist" picker (search results, item pages, a selection) and the search box inside a checklist.
The search is the Find & Add search itself (cards.list -> Vault.query_cards, the findfast path); nothing here searches on its own."""
from .cards import cards_list, with_undo
from .registry import api
from .service import ApiError

NEW_RULES = {"include": [], "exclude": []}             # a list started from the picker holds only what was added by hand until the person adds rules


def _members(v, cl_id):
    return set(v.checklist_members(cl_id))


@api("lists.choices")
def lists_choices(svc, ids=None):
    """The checklists of the open game for the picker: -> [{id, name, mode, has, n}]  (has = how many of `ids` are already on it)."""
    v = svc.vault
    ids = list(dict.fromkeys(ids or []))
    out = []
    for cl in v.checklists():
        out.append({"id": cl["id"], "name": cl["name"], "mode": cl["mode"], "n": len(ids), "has": len(_members(v, cl["id"]).intersection(ids)) if ids else 0})
    return out


@api("lists.addCards", mutates=True)
def lists_add_cards(svc, ids, checklist=None, name="", remove=False):
    """Put cards on a checklist (an existing one, or a new one called `name`); remove=True takes them off again.  A card is never added twice."""
    v = svc.vault
    ids = [i for i in dict.fromkeys(ids or []) if v.card_basic(i)]
    if not ids:
        raise ApiError("Nothing to add.")
    name = (name or "").strip()
    if checklist is None and not name:
        raise ApiError("Pick a checklist or give the new one a name.")
    out = {}

    def run():
        cid = checklist
        with v.action(f"{'Took' if remove else 'Added'} {len(ids)} item{'s' if len(ids) != 1 else ''} {'off' if remove else 'to'} a checklist"):
            if cid is None:
                cid = v.create_checklist(name, "cards", False, dict(NEW_RULES))
            if not v.checklist(cid) or v.checklist(cid)["deleted"]:
                raise ApiError("checklist not found")
            have = _members(v, cid)
            manual = v.checklist_manual(cid)
            changed = 0
            for i in ids:
                if remove:
                    if i in manual["manual"]:
                        v.set_checklist_card(cid, i, None)
                        changed += 1
                    elif i in have:
                        v.set_checklist_card(cid, i, "excluded")
                        changed += 1
                elif i not in have:
                    v.set_checklist_card(cid, i, "manual")
                    changed += 1
            out.update(id=cid, name=(v.checklist(cid)["name"]), changed=changed, already=len(ids) - changed if not remove else 0)
        return out
    return with_undo(svc, run)


@api("lists.find", quiet=True)
def lists_find(svc, id, text="", limit=24):
    """The search box inside a checklist: Find & Add's search of the open game, each result marked when it is already on this checklist."""
    text = (text or "").strip()
    if len(text) < 2:
        return {"rows": [], "total": 0}
    if not svc.vault.checklist(id):
        raise ApiError("checklist not found")
    r = cards_list(svc, text=text, limit=max(1, min(int(limit), 60)))
    on = _members(svc.vault, id)
    return {"rows": [{**x, "onList": x["id"] in on} for x in r["rows"]], "total": r["total"]}
