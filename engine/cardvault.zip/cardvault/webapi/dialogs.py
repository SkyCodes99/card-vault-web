"""Native file pickers.  The desktop window registers a handler (svc.dialog_host); in a plain browser or in tests files go to the Downloads folder."""
import os

from .. import runtime
from .registry import api


def downloads():
    if runtime.IN_BROWSER:                 # the page offers anything saved here as a download
        os.makedirs("/downloads", exist_ok=True)
        return "/downloads"
    p = os.path.join(os.path.expanduser("~"), "Downloads")
    return p if os.path.isdir(p) else os.path.expanduser("~")


@api("dialog.save")
def save(svc, name, kind="pdf"):
    host = getattr(svc, "dialog_host", None)
    if host:
        return {"path": svc.grant(host("save", name=name, kind=kind))}
    return {"path": svc.grant(os.path.join(downloads(), name))}


@api("dialog.open")
def open_file(svc, kind="csv"):
    host = getattr(svc, "dialog_host", None)
    return {"path": svc.grant(host("open", kind=kind)) if host else ""}


@api("dialog.folder")
def pick_folder(svc, title="Choose a folder"):
    host = getattr(svc, "dialog_host", None)
    return {"path": svc.grant(host("folder", title=title)) if host else ""}
