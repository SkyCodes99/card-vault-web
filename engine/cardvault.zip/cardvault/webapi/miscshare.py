"""List one of your own items for everyone under Misc (after the owner's review).  Protocol and what the account server must offer: docs/skycloud_request_own_items.md.

OFF by default: nothing is listed unless you press "List under Misc" on that one item, and an edit is NOT sent until you list it again.  What is sent: the item's name, set, series, number, category, labels
and its pictures (up to 4, each 2 MB at most, cover first) - never your estimate, price paid, notes, location or how many you own.  The server adds your USERNAME as the author (never an email) and keeps
the listing PENDING: nothing is public until the app's owner approves it (it lands on the owner's Review list, kind "misc_listing" - cardvault/miscreview.py).  You can withdraw it any time.
Others: Report and Hide are the same ones used everywhere else (safety.report / safety.hide kind "listing").
When the account server does not know this yet (or nobody is signed in) `misc.status` says available:false and the screens show nothing about sharing."""
import base64
import json
import time

from .. import customitems, custompics
from ..cloud import skycloud as sc
from .accountapi import account
from .registry import ApiError, api

PREF = "misc_share"                         # {item uuid: {"id": listing id, "status": pending | approved | rejected | hidden}} - kept with this account's settings
CAP_FOR = 600                               # seconds a "the server supports it" answer is trusted


def _state(svc):
    try:
        d = json.loads(svc.pget(PREF) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _put(svc, d):
    svc.pset(PREF, json.dumps(d))


def _call(svc, method, path, body=None):
    a = account(svc)
    if a is None:
        raise ApiError("Sign in to your account first (Settings > Account) - listing an item goes through it.", code="no_account")
    try:
        return a.call(method, path, body, timeout=60)
    except sc.CloudError as e:
        if e.status == 404:
            svc._misc_cap = (time.time(), False)
            raise ApiError("Sharing under Misc isn't switched on yet.")
        raise ApiError(str(e))


def available(svc):
    """True when this device has an account AND the account server supports Misc listings (asked at most every CAP_FOR seconds; never raises)."""
    if account(svc) is None:
        return False
    at, ok = getattr(svc, "_misc_cap", (0, False))
    if time.time() - at < CAP_FOR:
        return ok
    ok = False
    try:
        ok = bool((account(svc).call("GET", "/v1/misc/status", None, timeout=15) or {}).get("enabled"))
    except Exception:  # noqa: BLE001 - an older server (404), offline, anything: sharing stays hidden
        ok = False
    svc._misc_cap = (time.time(), ok)
    return ok


@api("misc.status", quiet=True)
def status(svc):
    """{available, listed: {item uuid: {id, status}}} - what the item form needs to show (or hide) the sharing choice."""
    ok = available(svc)
    return {"available": ok, "listed": _state(svc) if ok else {}}


def _payload(v, uuid):
    r = customitems._item(v, uuid)
    pics = custompics.read(v, uuid, r["pic"])
    return {"item": uuid, "name": r["name"], "set_name": r["set_name"] or "", "series": r["series"] or "", "number": r["number"] or "", "category": r["category"] or "",
            "labels": [x for x in (r["labels"] or "").split(",") if x],
            "pictures": ["data:image/jpeg;base64," + base64.b64encode(b).decode() for _, b in pics if len(b) <= custompics.MAX_BYTES][:custompics.MAX_PICTURES]}


@api("misc.share", mutates=False)
def share(svc, uuid):
    """List this item under Misc for everyone - it waits for review first.  Listing it again sends the item as it is now (and goes back to review).  -> {id, status}"""
    if not available(svc):
        raise ApiError("Sharing under Misc isn't available yet.")
    try:
        body = _payload(svc.vault, uuid)
    except customitems.CustomError as e:
        raise ApiError(str(e))
    cur = _state(svc).get(uuid)
    out = _call(svc, "PUT", "/v1/misc/listings/" + cur["id"], body) if cur and cur.get("id") else _call(svc, "POST", "/v1/misc/listings", body)
    d = _state(svc)
    d[uuid] = {"id": str(out.get("id") or (cur or {}).get("id") or ""), "status": str(out.get("status") or "pending")}
    _put(svc, d)
    return d[uuid]


def withdraw_quiet(svc, uuid):
    """Take the item's listing down (used when you stop sharing or delete the item).  Never raises: a listing the server could not remove is retried the next time you press Withdraw."""
    d = _state(svc)
    cur = d.get(uuid)
    if not cur:
        return False
    try:
        if cur.get("id"):
            _call(svc, "DELETE", "/v1/misc/listings/" + cur["id"])
    except ApiError:
        return False
    d.pop(uuid, None)
    _put(svc, d)
    return True


@api("misc.withdraw", mutates=False)
def withdraw(svc, uuid):
    if not withdraw_quiet(svc, uuid):
        if uuid in _state(svc):
            raise ApiError("That listing couldn't be taken down just now - try again in a moment.")
    return {"ok": True}


@api("misc.refresh", quiet=True)
def refresh(svc):
    """Ask the server how each of my listings stands (pending / approved / rejected / hidden) -> {listed}."""
    if not available(svc):
        return {"listed": {}}
    mine = {x.get("id"): x for x in (_call(svc, "GET", "/v1/misc/listings?mine=1").get("listings") or [])}
    d = _state(svc)
    for u, cur in list(d.items()):
        x = mine.get(cur.get("id"))
        if x is None:
            d.pop(u)                                           # (gone on the server: removed by the owner or by me on another device)
        else:
            cur["status"] = str(x.get("status") or cur.get("status"))
    _put(svc, d)
    return {"listed": d}


@api("misc.browse", quiet=True)
def browse(svc, q="", cursor=""):
    """Approved listings from other players (newest first) -> {available, listings: [{id, username, name, set_name, number, category, labels, thumb}], next}.  Hidden ones are left out."""
    if not available(svc):
        return {"available": False, "listings": [], "next": ""}
    from urllib.parse import quote
    from .safety import hidden_set, is_hidden
    out = _call(svc, "GET", f"/v1/misc/listings?q={quote(str(q or '')[:60])}&cursor={quote(str(cursor or '')[:80])}")
    hid = hidden_set(svc)
    rows = [x for x in (out.get("listings") or []) if not is_hidden(hid, "listing", x.get("username"), x.get("id"))]
    return {"available": True, "listings": rows, "next": str(out.get("next") or "")}
