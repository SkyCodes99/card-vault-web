"""Card pictures on this PC: how much room they take, and keeping them to a small cache.
Pictures that aren't stored here are fetched once from their web address when a card is shown (Service.fetch_image), so the folder is only ever a cache."""
import os

from ..db import game_dir
from .registry import api
from .service import ApiError

_fetched = [0]


def _pictures(data_dir):
    """-> [(path, size, last_used)] for every stored card picture of every game (not the small set logos)."""
    out = []
    root = os.path.join(data_dir, "games")
    if not os.path.isdir(root):
        return out
    for game in os.listdir(root):
        for q in ("low", "high"):
            base = os.path.join(root, game, "images", q)
            for dp, _dirs, files in os.walk(base):
                for f in files:
                    p = os.path.join(dp, f)
                    try:
                        st = os.stat(p)
                    except OSError:
                        continue
                    out.append((p, st.st_size, max(st.st_atime, st.st_mtime), game))
    return out


def trim_to(svc, keep_bytes):
    """Delete the least recently used pictures until at most keep_bytes remain.  Only ever called with the user's say-so (a confirmed request or a cache size they set)."""
    files = _pictures(svc.cfg["data_dir"])
    total = sum(f[1] for f in files)
    freed = removed = 0
    for p, size, _t, _g in sorted(files, key=lambda f: f[2]):
        if total - freed <= keep_bytes:
            break
        try:
            os.remove(p)
        except OSError:
            continue
        svc._exists.pop(p, None)
        freed += size
        removed += 1
    return {"removed": removed, "freedMb": round(freed / 1048576, 1), "leftMb": round((total - freed) / 1048576, 1)}


def after_fetch(svc):
    """Keeps the cache under the size the user chose (off unless they set one)."""
    cap = svc.cfg.get("image_cache_mb") or 0
    _fetched[0] += 1
    if cap and _fetched[0] % 50 == 0:
        trim_to(svc, int(cap) * 1048576)


@api("storage.status")
def status(svc):
    files = _pictures(svc.cfg["data_dir"])
    per = {}
    for _p, size, _t, game in files:
        per[game] = per.get(game, 0) + size
    return {"pictures": len(files), "picturesMb": round(sum(f[1] for f in files) / 1048576, 1), "perGameMb": {g: round(b / 1048576, 1) for g, b in per.items()},
            "cacheMb": svc.cfg.get("image_cache_mb") or 0, "onDemand": svc.cfg.get("on_demand_images") is not False}


@api("photos.usage")
def photos_usage(svc):
    """Settings > storage: 'Photos: N of LIMIT'.  The number is what your account holds (the account server counts it and says the limit); without an account, the photos on this device and the free limit."""
    from .. import photolimit
    used, limit, source = photolimit.count(svc.vault.conn), photolimit.limit_for(svc), "device"
    if photolimit.signed_in(svc):
        try:
            from .accountapi import account
            u = account(svc).call("GET", "/v1/usage", timeout=8)
            if "photos" in u and "photo_limit" in u:
                used, limit, source = int(u["photos"]), int(u["photo_limit"]), "account"
                svc.pset(photolimit.PREF, limit)                 # (the add-time check and the sync use the limit the server reported)
        except Exception:  # noqa: BLE001 - offline or an older server: the device's own count
            pass
    return {"used": used, "limit": limit, "source": source, "full": used >= limit, "note": photolimit.note(used, limit)}


@api("storage.trim")
def trim(svc, keepMb=0, confirm=False):
    if not confirm:
        raise ApiError("Say yes to confirm - this removes saved pictures from this PC (they download again when needed).")
    return trim_to(svc, max(0, int(keepMb)) * 1048576)


# ------------------------------------------------------------------------------------------------ where your data lives
def _tree_size(path):
    total = 0
    for dp, _d, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    return total


@api("storage.folder")
def folder_info(svc):
    from .. import runtime
    d = svc.cfg["data_dir"]
    return {"path": d, "mb": round(_tree_size(d) / 1048576, 1) if os.path.isdir(d) else 0, "canMove": not runtime.IN_BROWSER}


@api("storage.moveTo")
def move_to(svc, path):
    """Copy everything (card lists, pictures, your protected collection, backups) to a new folder, then use that folder from the next start.
    The old folder is NOT deleted: it stays as a copy until you remove it yourself."""
    import shutil
    import sqlite3
    from .. import runtime
    if runtime.IN_BROWSER:
        raise ApiError("The website keeps its data inside the browser, so there is no folder to move.")
    svc.need_grant(path)
    src, dst = os.path.abspath(svc.cfg["data_dir"]), os.path.abspath(path)
    if os.path.normcase(src) == os.path.normcase(dst):
        raise ApiError("That is the folder the app already uses.")
    if os.path.normcase(dst).startswith(os.path.normcase(src) + os.sep) or os.path.normcase(src).startswith(os.path.normcase(dst) + os.sep):
        raise ApiError("Pick a folder that is not inside the current one (and does not contain it).")
    if os.path.isdir(dst) and os.listdir(dst):
        raise ApiError("Pick an empty folder (or a new one) so nothing gets mixed up.")
    need = _tree_size(src)
    try:
        os.makedirs(dst, exist_ok=True)
        free = shutil.disk_usage(dst).free
    except OSError as e:
        raise ApiError(f"That folder can't be used: {e.strerror or e}")
    if free < need * 1.1 + 50 * 1048576:
        raise ApiError(f"Not enough room there: {need / 1073741824:.1f} GB needed, {free / 1073741824:.1f} GB free.")

    if svc.vault is not None:
        svc.vault.backup_now("before-move", svc.pget("backup_dir"))          # a safety copy first (on this thread: the database belongs to it)

    def run(emit, cancel):
        files = [(dp, f) for dp, _d, fs in os.walk(src) for f in fs]
        for i, (dp, f) in enumerate(files):
            if cancel.is_set():
                raise RuntimeError("Cancelled - nothing was changed.")
            rel = os.path.relpath(os.path.join(dp, f), src)
            target = os.path.join(dst, rel)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            s = os.path.join(dp, f)
            if f.lower().endswith((".db", ".sqlite")) and not f.lower().endswith("-wal"):
                try:                                              # a database that may be open: the safe online copy
                    a, b = sqlite3.connect(s), sqlite3.connect(target)
                    try:
                        a.backup(b)
                    finally:
                        b.close()
                        a.close()
                    continue
                except sqlite3.Error:
                    pass
            if f.endswith(("-wal", "-shm")):
                continue
            shutil.copy2(s, target)
            if i % 25 == 0:
                emit("Copying your data…", i, len(files))
        svc.cfg["data_dir"] = dst
        svc.save()
        svc.audit("data_folder_moved", "")
        return {"moved": True, "to": dst, "keptOld": src}
    return {"job": svc.jobs.start("move-data", "Moving your data to the new folder", run).id}
