"""Card pictures on this PC: how much room they take, and keeping them to a small cache.
Pictures that aren't stored here are fetched once from their web address when a card is shown (Service.fetch_image), so the folder is only ever a cache."""
import os

from ..db import game_dir
from .registry import api
from .service import ApiError

_fetched = [0]


def _pictures(data_dir):
    """-> [(path, size, last_used)] for every stored card picture of every game (not the small set logos)."""
    out = []
    root = os.path.join(data_dir, "games")
    if not os.path.isdir(root):
        return out
    for game in os.listdir(root):
        for q in ("low", "high"):
            base = os.path.join(root, game, "images", q)
            for dp, _dirs, files in os.walk(base):
                for f in files:
                    p = os.path.join(dp, f)
                    try:
                        st = os.stat(p)
                    except OSError:
                        continue
                    out.append((p, st.st_size, max(st.st_atime, st.st_mtime), game))
    return out


def trim_to(svc, keep_bytes):
    """Delete the least recently used pictures until at most keep_bytes remain.  Only ever called with the user's say-so (a confirmed request or a cache size they set)."""
    files = _pictures(svc.cfg["data_dir"])
    total = sum(f[1] for f in files)
    freed = removed = 0
    for p, size, _t, _g in sorted(files, key=lambda f: f[2]):
        if total - freed <= keep_bytes:
            break
        try:
            os.remove(p)
        except OSError:
            continue
        svc._exists.pop(p, None)
        freed += size
        removed += 1
    return {"removed": removed, "freedMb": round(freed / 1048576, 1), "leftMb": round((total - freed) / 1048576, 1)}


def after_fetch(svc):
    """Keeps the cache under the size the user chose (off unless they set one)."""
    cap = svc.cfg.get("image_cache_mb") or 0
    _fetched[0] += 1
    if cap and _fetched[0] % 50 == 0:
        trim_to(svc, int(cap) * 1048576)


@api("storage.status")
def status(svc):
    files = _pictures(svc.cfg["data_dir"])
    per = {}
    for _p, size, _t, game in files:
        per[game] = per.get(game, 0) + size
    return {"pictures": len(files), "picturesMb": round(sum(f[1] for f in files) / 1048576, 1), "perGameMb": {g: round(b / 1048576, 1) for g, b in per.items()},
            "cacheMb": svc.cfg.get("image_cache_mb") or 0, "onDemand": svc.cfg.get("on_demand_images") is not False}


@api("storage.trim")
def trim(svc, keepMb=0, confirm=False):
    if not confirm:
        raise ApiError("Say yes to confirm - this removes saved pictures from this PC (they download again when needed).")
    return trim_to(svc, max(0, int(keepMb)) * 1048576)
