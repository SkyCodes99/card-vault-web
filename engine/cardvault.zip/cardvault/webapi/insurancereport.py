"""Insurance report: a PDF of the cards I own - picture, condition, grade, quantity, location, price paid and current value - for insurance or records.
Cover (my username, never an email; date; item count; total value in my currency with the rate date), a summary by game, then one row per copy group, with page numbers.
Options: which games (all by default), a minimum value per item (in my currency, default 0) and whether my OWN photos replace the catalog pictures (default off).
Pictures: my disk copy of the catalog picture first, else one short download (cached in report_pics); every picture has a short time limit and the whole fetch a budget, so a slow
or missing one becomes a placeholder box and never stalls the report.  Built entirely on this device: nothing is uploaded, and only this person's own rows are used.
Library: fpdf2 (pure Python, already in requirements-desktop.txt)."""
import datetime
import hashlib
import io
import os
from concurrent.futures import ThreadPoolExecutor, wait

from .registry import api, ApiError
from . import mydata
from .. import currency, pricepick
from ..db import game_dir, image_file, picture_url

PIC_TIMEOUT = (3, 4)            # connect, read - seconds, for one picture
PIC_BUDGET = 45                 # seconds for all downloads together
PIC_MAX = 3_000_000             # bytes; bigger answers are skipped
ROW_H = 22


def _txt(s):
    """Text the built-in PDF fonts can draw (Latin-1); anything else becomes '?'."""
    return str(s if s is not None else "").encode("latin-1", "replace").decode("latin-1")


def _thumb(raw):
    """Image bytes (any format Pillow reads) -> small JPEG bytes, or None."""
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(raw))
        im.thumbnail((160, 224))
        if im.mode != "RGB":
            im = im.convert("RGB")
        out = io.BytesIO()
        im.save(out, "JPEG", quality=80)
        return out.getvalue()
    except Exception:  # noqa: BLE001 - a bad picture is a placeholder, not an error
        return None


def _catalog_pic(cache_dir, pic):
    """Small JPEG bytes of the catalog picture: local file, cached copy, or one quick download.  None when there is none."""
    cid, sid, base, gdir = pic["card_id"], pic["set_id"], pic["image_base"], pic["gdir"]
    for q in ("low", "high"):
        p = image_file(gdir, q, cid, sid) if sid else ""
        if p and os.path.isfile(p):
            try:
                with open(p, "rb") as f:
                    return _thumb(f.read())
            except OSError:
                pass
    url = picture_url(base, "low")
    if not url:
        return None
    cp = os.path.join(cache_dir, hashlib.sha1(url.encode()).hexdigest() + ".jpg")
    if os.path.isfile(cp):
        with open(cp, "rb") as f:
            return f.read()
    try:
        import requests
        r = requests.get(url, timeout=PIC_TIMEOUT, stream=True, headers={"User-Agent": "CollectEmAll-report"})
        if r.status_code != 200:
            return None
        raw = r.raw.read(PIC_MAX + 1, decode_content=True)
        if len(raw) > PIC_MAX:
            return None
    except Exception:  # noqa: BLE001
        return None
    jpg = _thumb(raw)
    if jpg:
        try:
            with open(cp, "wb") as f:
                f.write(jpg)
        except OSError:
            pass
    return jpg


def fetch_pictures(items, cache_dir, budget=PIC_BUDGET):
    """{item index: JPEG bytes} for the items that have a picture, within the time budget; the rest are simply missing (placeholder)."""
    os.makedirs(cache_dir, exist_ok=True)
    out = {}
    pool = ThreadPoolExecutor(max_workers=6)
    futs = {}
    for i, it in enumerate(items):
        if it.get("photo"):
            out[i] = it["photo"]
        elif it.get("pic"):
            futs[pool.submit(_catalog_pic, cache_dir, it["pic"])] = i
    done, _ = wait(list(futs), timeout=budget)
    for f in done:
        try:
            if f.result():
                out[futs[f]] = f.result()
        except Exception:  # noqa: BLE001
            pass
    pool.shutdown(wait=False, cancel_futures=True)
    return out


def collect(svc, games=None, min_value=0.0, own_photos=False):
    """The report's data: (items, {game: {lines, copies, value (usd)}}).  Only this person's rows."""
    v = svc.vault
    v._commit()
    min_usd = currency.to_usd(float(min_value or 0)) or 0.0
    items = []
    for gid in mydata._games(v.conn, v.user_id):
        if games and gid not in games:
            continue
        g = v if gid == v.game else mydata._other_game(v, gid)
        try:
            gdir = game_dir(v.data_dir, gid)
            try:
                picked = pricepick.prices(g)
            except Exception:  # noqa: BLE001
                picked = None
            try:
                rows = g.conn.execute(
                    "SELECT l.*, c.name, c.local_id, c.price_usd AS usd, c.price_updated AS pdate, c.image_base, c.set_id AS cset, s.name AS set_name FROM u.lots l "
                    "LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 ORDER BY s.name, c.sort_key, l.id",
                    (v.user_id, gid)).fetchall()
            except Exception:  # noqa: BLE001 - an older or missing card list: names only
                rows = g.conn.execute(
                    "SELECT l.*, c.name, c.local_id, c.price_usd AS usd, NULL AS pdate, NULL AS image_base, c.set_id AS cset, s.name AS set_name FROM u.lots l "
                    "LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 ORDER BY l.id",
                    (v.user_id, gid)).fetchall()
            for r in rows:
                now = pricepick.copy_price(g, r["card_id"], r["graded"], r["grade_company"], r["grade"], picked.get(r["card_id"]) if picked is not None else r["usd"])
                if min_usd > 0 and (now is None or now < min_usd):
                    continue
                photo = None
                if own_photos and r["uuid"]:
                    p = v.conn.execute("SELECT data FROM u.lot_photos WHERE lot_uuid=? ORDER BY (side='front') DESC, id LIMIT 1", (r["uuid"],)).fetchone()
                    photo = _thumb(p[0]) if p and p[0] else None
                if own_photos and photo is None and str(r["card_id"]).startswith("custom:"):          # an item of your own: its own picture
                    p = v.conn.execute("SELECT data FROM u.lot_photos WHERE lot_uuid=? ORDER BY id DESC LIMIT 1", (str(r["card_id"])[7:],)).fetchone()
                    photo = _thumb(p[0]) if p and p[0] else None
                items.append({"game": gid, "name": r["name"] or r["card_id"], "set": r["set_name"] or "", "number": r["local_id"] or "", "variant": r["variant"] or "",
                              "condition": r["condition"] or "", "graded": bool(r["graded"]), "company": r["grade_company"] or "", "grade": r["grade"] or "", "cert": r["cert"] or "",
                              "qty": int(r["qty"]), "location": r["location"] or "", "paid": r["purchase_price"], "value": now, "estimate": str(r["card_id"]).startswith("custom:"), "pdate": r["pdate"] or "", "photo": photo,
                              "pic": None if photo or not r["image_base"] else {"card_id": r["card_id"], "set_id": r["cset"], "image_base": r["image_base"], "gdir": gdir}})
        finally:
            if g is not v:
                g.conn.close()
    summary = {}
    for it in items:
        s = summary.setdefault(it["game"], {"lines": 0, "copies": 0, "value": 0.0})
        s["lines"] += 1
        s["copies"] += it["qty"]
        s["value"] += (it["value"] or 0) * it["qty"]
    return items, summary


def money(usd):
    """An amount in my currency as plain text ('EUR 12.50'): the PDF's built-in fonts have no currency symbols."""
    if usd is None:
        return "-"
    return f"{currency.shown()} {usd * currency.rate():,.{currency.decimals()}f}"


def _cell(pdf, x, y, w, text):
    """Up to five short lines of text inside one row, each cut to fit the column."""
    pdf.set_xy(x, y + 1)
    for ln in _txt(text).split("\n")[:5]:
        while pdf.get_string_width(ln) > w - 1 and len(ln) > 1:
            ln = ln[:-1]
        pdf.set_x(x)
        pdf.cell(w, 3.8, ln, new_x="LMARGIN", new_y="NEXT")


def build_pdf(path, owner, items, summary, pictures=None, when=None):
    """Write the PDF.  Returns {"pages": n, "total": total usd}."""
    from fpdf import FPDF
    pictures = pictures or {}
    when = when or datetime.date.today().isoformat()
    total = sum(s["value"] for s in summary.values())
    copies = sum(s["copies"] for s in summary.values())
    fx = currency.info()

    class Doc(FPDF):
        def footer(self):
            self.set_y(-12)
            self.set_font("Helvetica", "", 8)
            self.set_text_color(120)
            self.cell(150, 6, f"Collect Em All insurance report - {_txt(owner)} - {when}", align="L")
            self.cell(40, 6, f"Page {self.page_no()} of {{nb}}", align="R")
            self.set_text_color(0)

    pdf = Doc("P", "mm", "A4")
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(False)
    pdf.set_title("Collection insurance report")
    pdf.set_author(_txt(owner))
    pdf.add_page()
    pdf.set_y(60)
    pdf.set_font("Helvetica", "B", 26)
    pdf.cell(0, 14, "Collection insurance report", new_x="LMARGIN", new_y="NEXT", align="C")
    pdf.set_font("Helvetica", "", 13)
    for label, val in (("Owner", owner), ("Date", when), ("Items", f"{len(items)} lines, {copies} copies"), ("Total value", money(total))):
        pdf.cell(0, 9, _txt(f"{label}: {val}"), new_x="LMARGIN", new_y="NEXT", align="C")
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(90)
    if fx["shown"] == "USD":
        note = "Values are in US dollars."
    elif fx["source"] == "by hand":
        note = f"Converted from US dollars to {fx['shown']} at a rate typed in by the owner (1 USD = {fx['rate']:.4f} {fx['shown']})."
    else:
        note = f"Converted from US dollars to {fx['shown']} at the exchange rate of {fx['date'] or 'an earlier day'} (1 USD = {fx['rate']:.4f} {fx['shown']})."
    pdf.multi_cell(0, 5, _txt(note + " Values are market prices on the price date shown for each item; they are estimates, not appraisals."), align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(0)
    pdf.ln(10)
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Summary by game", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "B", 10)
    for w, h in ((70, "Game"), (30, "Lines"), (30, "Copies"), (50, "Value")):
        pdf.cell(w, 7, h, border="B", align="L" if h == "Game" else "R")
    pdf.ln()
    pdf.set_font("Helvetica", "", 10)
    for gid in sorted(summary):
        s = summary[gid]
        pdf.cell(70, 7, _txt(gid))
        pdf.cell(30, 7, str(s["lines"]), align="R")
        pdf.cell(30, 7, str(s["copies"]), align="R")
        pdf.cell(50, 7, money(s["value"]), align="R", new_x="LMARGIN", new_y="NEXT")

    def head():
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 8)
        pdf.set_fill_color(235)
        pdf.set_xy(10, 10)
        for w, h in ((16, "Picture"), (52, "Item"), (30, "Condition / grade"), (10, "Qty"), (26, "Location"), (22, "Paid"), (34, "Value (price date)")):
            pdf.cell(w, 6, h, border=1, fill=True)
        pdf.ln(6)

    head()
    last = None
    for i, it in enumerate(items):
        if it["game"] != last:
            last = it["game"]
            if pdf.get_y() + ROW_H + 6 > 282:
                head()
            pdf.set_x(10)
            pdf.set_font("Helvetica", "B", 9)
            pdf.cell(190, 6, _txt(f"Game: {last}"), new_x="LMARGIN", new_y="NEXT")
        if pdf.get_y() + ROW_H > 282:
            head()
        y = pdf.get_y()
        jpg = pictures.get(i)
        drawn = False
        if jpg:
            try:
                pdf.image(io.BytesIO(jpg), x=11, y=y + 1, w=14, h=ROW_H - 2, keep_aspect_ratio=True)
                drawn = True
            except Exception:  # noqa: BLE001
                drawn = False
        if not drawn:
            pdf.set_draw_color(180)
            pdf.rect(11, y + 1, 14, ROW_H - 2)
            pdf.set_draw_color(0)
            pdf.set_font("Helvetica", "", 6)
            pdf.set_xy(11, y + ROW_H / 2 - 2)
            pdf.cell(14, 4, "no picture", align="C")
        grade = (f"{it['company']} {it['grade']}".strip() + (f" cert {it['cert']}" if it["cert"] else "")) if it["graded"] else ""
        cond = it["condition"] + (("\nGraded: " + grade) if grade else "")
        title = it["name"] + (f" ({it['variant']})" if it["variant"] else "")
        sub = (it["set"] + (f" #{it['number']}" if it["number"] else "")).strip()
        each = it["value"]
        valtxt = "-" if each is None else money(each * it["qty"]) + (f"\n({it['qty']} x {money(each)})" if it["qty"] > 1 else "")
        if each is not None and it.get("estimate"):
            valtxt += "\nyour estimate"                                      # (the owner's own figure for an item in no catalog: never passed off as a market price)
        elif each is not None and it["pdate"]:
            valtxt += f"\n{str(it['pdate'])[:10]}"
        paid = "-" if it["paid"] is None else money(it["paid"]) + (" ea" if it["qty"] > 1 else "")
        pdf.set_font("Helvetica", "", 8)
        for x, w, t in ((26, 52, title + "\n" + sub), (78, 30, cond), (108, 10, str(it["qty"])), (118, 26, it["location"]), (144, 22, paid), (166, 34, valtxt)):
            _cell(pdf, x, y, w, t)
        pdf.set_draw_color(220)
        pdf.line(10, y + ROW_H, 200, y + ROW_H)
        pdf.set_draw_color(0)
        pdf.set_y(y + ROW_H)
    pdf.output(path)
    return {"pages": pdf.page_no(), "total": total}


def make_report(svc, path, games=None, min_value=0.0, own_photos=False):
    items, summary = collect(svc, games, min_value, own_photos)
    pics = fetch_pictures(items, os.path.join(svc.vault.data_dir, "report_pics"))
    owner = getattr(svc.session, "name", None) or "Collector"
    res = build_pdf(path, owner, items, summary, pics)
    return {"lines": len(items), "copies": sum(s["copies"] for s in summary.values()), "pages": res["pages"], "total": res["total"], "pictures": len(pics)}


@api("data.insuranceGames")
def insurance_games(svc):
    """The games I own something in, for the report's game choice."""
    return {"games": mydata._games(svc.vault.conn, svc.vault.user_id), "currency": currency.shown()}


@api("data.exportInsuranceReport")
def export_insurance(svc, path, games=None, minValue=0, ownPhotos=False):
    """The insurance report as a PDF at `path` (the file picker's choice).  games: list or empty for all; minValue in my currency; ownPhotos off by default."""
    svc.need_grant(path)
    try:
        mv = max(0.0, float(minValue or 0))
    except (TypeError, ValueError):
        raise ApiError("The minimum value must be a number.")
    r = make_report(svc, path, [str(g) for g in games] if games else None, mv, bool(ownPhotos))
    svc.audit("export", "insurance report (PDF" + (", own photos" if ownPhotos else "") + ")")
    return r
