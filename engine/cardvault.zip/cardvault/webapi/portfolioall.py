"""Portfolios across every game: one portfolio can hold Pokemon cards, Magic cards and sealed products at once.  This is the 'all games' picture of them (the rest of the app looks at one game at a time)."""
import os
import sqlite3

from .. import games
from ..db import game_dir
from ..tcgcsv import norm_name
from .portfolios import MAIN, _state
from .registry import api


_KNOWN = {}                     # card list file -> (its stamp, {card id: usd}): the prices read so far, kept while the file is unchanged (every change to your collection asked them all again)


def _stamp(path):
    """The card list file's size and time, and its write-ahead log's size: any change to the list shows here."""
    out = []
    for p in (path, path + "-wal"):
        try:
            st = os.stat(p)
            out.append((st.st_size, st.st_mtime_ns))
        except OSError:
            out.append(None)
    return tuple(out)


def _prices(svc, gid, ids):
    """{card id: usd} for these cards from that game's card list (empty when the list isn't on this device)."""
    path = os.path.join(game_dir(svc.cfg["data_dir"], gid), "cards.db")
    out = {}
    if not ids or not os.path.exists(path):
        return out
    stamp = _stamp(path)
    hit = _KNOWN.get(path)
    known = hit[1] if hit and hit[0] == stamp else {}
    missing = [cid for cid in ids if cid not in known]
    if missing:
        try:
            c = sqlite3.connect(path)
            for i in range(0, len(missing), 500):
                chunk = missing[i:i + 500]
                for cid, usd in c.execute(f"SELECT id, price_usd FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                    known[cid] = usd
            c.close()
        except sqlite3.Error:
            return {cid: known[cid] for cid in ids if cid in known}
        _KNOWN[path] = (stamp, known)
    return {cid: known[cid] for cid in ids if cid in known}


def _sealed_prices(svc, gid, names):
    path = os.path.join(game_dir(svc.cfg["data_dir"], gid), "cards.db")
    out = {}
    if not names or not os.path.exists(path):
        return out
    try:
        c = sqlite3.connect(path)
        for n in names:
            r = c.execute("SELECT price_usd FROM sealed_products WHERE norm=? AND price_usd IS NOT NULL ORDER BY price_updated DESC LIMIT 1", (norm_name(n),)).fetchone()
            if r:
                out[n] = r[0]
        c.close()
    except sqlite3.Error:
        pass
    return out


@api("portfolio.allGames", quiet=True)
def all_games(svc):
    """Every portfolio with what it holds in each game (cards and sealed), valued from each game's own price list."""
    v = svc.vault
    names = {g.id: g.name for g in games.GAMES}
    cards = {}                                                              # (portfolio, game) -> {copies, value}
    gids = [r[0] for r in v.conn.execute("SELECT DISTINCT game FROM u.lots WHERE user_id=? AND deleted=0 AND qty>0 UNION SELECT DISTINCT game FROM u.sealed WHERE user_id=? AND deleted=0", (v.user_id, v.user_id))]
    cell = lambda pf, gid: cards.setdefault((pf or MAIN, gid), {"copies": 0, "value": 0.0, "sealed": 0, "sealedValue": 0.0, "unpriced": 0})
    for gid in gids:
        lots = v.conn.execute("SELECT COALESCE(portfolio,'') AS pf, card_id, SUM(qty) AS q FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY COALESCE(portfolio,''), card_id", (v.user_id, gid)).fetchall()
        price = _prices(svc, gid, {r["card_id"] for r in lots})
        for r in lots:
            c = cell(r["pf"], gid)
            c["copies"] += r["q"]
            usd = price.get(r["card_id"])
            if usd is None:
                c["unpriced"] += r["q"]
            else:
                c["value"] += usd * r["q"]
        seal = v.conn.execute("SELECT COALESCE(portfolio,'') AS pf, name, SUM(qty) AS q FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 GROUP BY COALESCE(portfolio,''), name", (v.user_id, gid)).fetchall()
        sp = _sealed_prices(svc, gid, {r["name"] for r in seal})
        for r in seal:
            c = cell(r["pf"], gid)
            c["sealed"] += r["q"] or 0
            c["sealedValue"] += (sp.get(r["name"]) or 0) * (r["q"] or 0)
    st = _state(svc)
    rows, total = [], {"copies": 0, "value": 0.0, "sealed": 0, "sealedValue": 0.0}
    for p in st["portfolios"]:
        by = {gid: {k: (round(x, 2) if isinstance(x, float) else x) for k, x in cards[(p["id"], gid)].items()} for gid in gids if (p["id"], gid) in cards}
        mine = {k: sum(b[k] for b in by.values()) for k in ("copies", "value", "sealed", "sealedValue")}
        for k in total:
            total[k] += mine[k]
        rows.append({"id": p["id"], "name": p["name"], "color": p["color"], "depth": p["depth"], "parent": p["parent"], "byGame": by, **{k: round(x, 2) if isinstance(x, float) else x for k, x in mine.items()}})
    used = [g for g in gids if any((r["id"], g) in cards for r in rows)]
    return {"games": [{"id": g, "name": names.get(g, g), "here": os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g), "cards.db"))} for g in used],
            "portfolios": rows, "total": {k: round(x, 2) if isinstance(x, float) else x for k, x in total.items()}, "open": v.game}


@api("games.shelf", quiet=True)
def games_shelf(svc):
    """The phone Home's shelf: every game on this device with what you own in it (different cards, sealed products) and what that is worth - the open game first."""
    v = svc.vault
    here = {}
    for g in games.GAMES:
        if g.available and os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g.id), "cards.db")):
            here[g.id] = g
    out = []
    for gid, g in here.items():
        lots = v.conn.execute("SELECT card_id, SUM(qty) AS q FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY card_id", (v.user_id, gid)).fetchall()
        price = _prices(svc, gid, {r["card_id"] for r in lots})
        value = sum((price.get(r["card_id"]) or 0) * r["q"] for r in lots)
        seal = v.conn.execute("SELECT name, SUM(qty) AS q FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY name", (v.user_id, gid)).fetchall()
        sp = _sealed_prices(svc, gid, [r["name"] for r in seal])
        value += sum((sp.get(r["name"]) or 0) * r["q"] for r in seal)
        out.append({"id": gid, "name": g.name, "cards": sum(r["q"] for r in lots), "unique": len(lots), "sealed": sum(r["q"] for r in seal), "value": round(value, 2), "open": gid == v.game})
    out.sort(key=lambda x: (not x["open"], -x["value"], x["name"]))
    return {"games": out}
