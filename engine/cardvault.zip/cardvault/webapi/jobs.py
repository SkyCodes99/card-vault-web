"""Background work (downloads, price updates, art scoring, sync): each job runs in its own thread and reports progress to the screens.
A job whose work is a generator (it yields between pieces) runs a piece per tick in the browser build, which has no threads (see Jobs.step)."""
import inspect
import threading
import time

from ..runtime import INLINE
from . import perf

from .registry import ApiError, api


class Job:
    def __init__(self, jid, kind, title):
        self.id, self.kind, self.title = jid, kind, title
        self.state = "running"            # running | done | failed | stopped
        self.text, self.done, self.total = "Starting…", 0, 0
        self.result, self.error = None, ""
        self.cancel = threading.Event()
        self.started = time.time()
        self._last = 0.0
        self.busy = 0.0                   # seconds of actual work (in the browser a job in pieces also spends time waiting between them)
        self.pieces = None                # the browser build: what is left of a job that goes in pieces
        self.on_done = None

    def public(self):
        return {"id": self.id, "kind": self.kind, "title": self.title, "state": self.state, "text": self.text, "done": self.done, "total": self.total,
                "result": self.result, "error": self.error}


class Jobs:
    def __init__(self, svc):
        self.svc, self.items, self._n = svc, {}, 0
        self.lock = threading.Lock()

    def running(self, kind=None):
        return [j for j in self.items.values() if j.state == "running" and (kind is None or j.kind == kind)]

    def start(self, kind, title, fn, on_done=None, exclusive=True):
        """fn(emit, cancel) -> result.  emit(text, done, total) reports progress.  on_done(job) runs on the worker thread afterwards."""
        with self.lock:
            if exclusive and self.running(kind):
                raise ApiError("That is already running.")
            self._n += 1
            job = Job(self._n, kind, title)
            self.items[job.id] = job
        svc = self.svc

        def emit(text, done=0, total=0):
            job.text, job.done, job.total = text, done, total
            now = time.time()
            if now - job._last > 0.15:
                job._last = now
                svc.bump("job", job=job.public())

        def run():
            t0 = time.perf_counter()
            try:
                with perf.timed("job", f"{kind}: {title}"):
                    out = fn(emit, job.cancel)
                    if inspect.isgenerator(out):
                        if INLINE:
                            job.pieces = out
                            return                                 # the first piece runs now (below), the rest at the next ticks
                        out = _all(out)
            except Exception as e:  # noqa: BLE001 - network problems etc.
                job.busy = time.perf_counter() - t0
                self._end(job, error=e)
                return
            job.busy = time.perf_counter() - t0
            self._end(job, result=out)

        job.on_done = on_done
        svc.bump("job", job=job.public())
        if INLINE:
            run()                       # no threads here: the job finishes before the call returns (progress still streams to the screens) - or, one in pieces, its first piece does
            if job.pieces is not None:
                self._piece(job)
        else:
            threading.Thread(target=run, name=f"job-{kind}", daemon=True).start()
        return job

    def step(self):
        """The browser build: the next piece of every job that goes in pieces - called once per tick, so a click waits for one piece at most, never for a whole sync.  -> whether one ran."""
        waiting = [j for j in self.items.values() if j.state == "running" and j.pieces is not None]
        for job in waiting:
            self._piece(job)
        return bool(waiting)

    def finish(self, job):
        """Every piece still left of a job, now (for the rare caller that must have it done before it carries on)."""
        while job.pieces is not None:
            self._piece(job)

    def _piece(self, job):
        from ..sync import Cancelled
        t0 = time.perf_counter()
        try:
            with perf.timed("piece", f"{job.kind}: {job.title}"):
                if job.cancel.is_set() or not getattr(self.svc, "unlocked", True):
                    job.pieces.close()                                     # (its own clean-up runs: files it opened are closed)
                    raise Cancelled()
                next(job.pieces)
        except StopIteration as done:
            job.busy += time.perf_counter() - t0
            self._end(job, result=done.value)
        except Exception as e:  # noqa: BLE001
            job.busy += time.perf_counter() - t0
            self._end(job, error=e)
        else:
            job.busy += time.perf_counter() - t0

    def _end(self, job, result=None, error=None):
        from ..sync import Cancelled
        svc = self.svc
        job.pieces = None
        if error is None:
            job.result, job.state = result, "done"
        elif isinstance(error, Cancelled):
            job.state, job.error = "stopped", "Stopped. Everything already downloaded is kept."
        else:
            job.state, job.error = ("stopped", "Stopped.") if job.cancel.is_set() else ("failed", f"{error}")
        if job.on_done:
            try:
                svc.run(lambda s: job.on_done(job))
            except Exception:  # noqa: BLE001
                pass
        svc.bump("job", job=job.public())
        if job.state == "done" and job.kind != "sync":          # a finished sync must NOT count as a new change: that made every sync trigger the next one, forever ("Saving to your account..." that never ends)
            svc.bump("changed")


def _all(pieces):
    """Every piece of a job at once (the desktop: it has a thread of its own)."""
    from ..steps import run
    return run(pieces)


@api("jobs.list")
def jobs_list(svc):
    return [j.public() for j in sorted(svc.jobs.items.values(), key=lambda j: -j.id)][:12]


@api("jobs.cancel")
def jobs_cancel(svc, id):
    j = svc.jobs.items.get(id)
    if j:
        j.cancel.set()
        j.text = "Stopping…"
    return {"ok": True}
