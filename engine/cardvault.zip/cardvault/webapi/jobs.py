"""Background work (downloads, price updates, art scoring, sync): each job runs in its own thread and reports progress to the screens."""
import threading
import time

from ..runtime import INLINE

from .registry import ApiError, api


class Job:
    def __init__(self, jid, kind, title):
        self.id, self.kind, self.title = jid, kind, title
        self.state = "running"            # running | done | failed | stopped
        self.text, self.done, self.total = "Starting…", 0, 0
        self.result, self.error = None, ""
        self.cancel = threading.Event()
        self.started = time.time()
        self._last = 0.0

    def public(self):
        return {"id": self.id, "kind": self.kind, "title": self.title, "state": self.state, "text": self.text, "done": self.done, "total": self.total,
                "result": self.result, "error": self.error}


class Jobs:
    def __init__(self, svc):
        self.svc, self.items, self._n = svc, {}, 0
        self.lock = threading.Lock()

    def running(self, kind=None):
        return [j for j in self.items.values() if j.state == "running" and (kind is None or j.kind == kind)]

    def start(self, kind, title, fn, on_done=None, exclusive=True):
        """fn(emit, cancel) -> result.  emit(text, done, total) reports progress.  on_done(job) runs on the worker thread afterwards."""
        with self.lock:
            if exclusive and self.running(kind):
                raise ApiError("That is already running.")
            self._n += 1
            job = Job(self._n, kind, title)
            self.items[job.id] = job
        svc = self.svc

        def emit(text, done=0, total=0):
            job.text, job.done, job.total = text, done, total
            now = time.time()
            if now - job._last > 0.15:
                job._last = now
                svc.bump("job", job=job.public())

        def run():
            from ..sync import Cancelled
            try:
                job.result = fn(emit, job.cancel)
                job.state = "done"
            except Cancelled:
                job.state, job.error = "stopped", "Stopped. Everything already downloaded is kept."
            except Exception as e:  # noqa: BLE001 - network problems etc.
                job.state, job.error = ("stopped", "Stopped.") if job.cancel.is_set() else ("failed", f"{e}")
            if on_done:
                try:
                    svc.run(lambda s: on_done(job))
                except Exception:  # noqa: BLE001
                    pass
            svc.bump("job", job=job.public())
            if job.state == "done" and kind != "sync":          # a finished sync must NOT count as a new change: that made every sync trigger the next one, forever ("Saving to your account..." that never ends)
                svc.bump("changed")

        svc.bump("job", job=job.public())
        if INLINE:
            run()                       # no threads here: the job finishes before the call returns (progress still streams to the screens)
        else:
            threading.Thread(target=run, name=f"job-{kind}", daemon=True).start()
        return job


@api("jobs.list")
def jobs_list(svc):
    return [j.public() for j in sorted(svc.jobs.items.values(), key=lambda j: -j.id)][:12]


@api("jobs.cancel")
def jobs_cancel(svc, id):
    j = svc.jobs.items.get(id)
    if j:
        j.cancel.set()
        j.text = "Stopping…"
    return {"ok": True}
