"""Price alerts: tell me when a card (a wishlist card, say) or a sealed product goes below / above a price, or when finishing a set costs less than a price (a set goal:
type "set", key = the set id, always "below"; the cost is the "$X to finish" of the set boxes, at the set's own Standard / Master / Extra goal).  Kept as one account setting, so they
follow you to every device; they are checked when you look and after the daily prices (cardvault/pricewatch.py), so nothing is sent anywhere."""
import json

from .. import sealedprice
from ..db import new_uuid
from .registry import ApiError, api

KEY = "price_alerts"


def _all(svc):
    try:
        got = json.loads(svc.pget(KEY) or "[]")
    except ValueError:
        got = []
    return [a for a in got if isinstance(a, dict) and a.get("id")]


TYPES = ("card", "sealed", "set")


def finish_costs(svc):
    """{set id: cost to finish} from the one table the set boxes read (setgoalsapi.sets_costs, kept per change); None while the card index is still being worked out."""
    from ..db import IndexNotReady
    from .setgoalsapi import sets_costs
    try:
        return {sid: r["cost"] for sid, r in sets_costs(svc).items()}
    except IndexNotReady:
        return None


def set_cost(table, set_id):
    """What finishing this set costs now (0 = nothing left to buy), None when it is not known yet."""
    return None if table is None else table.get(set_id, 0.0)


def _price(svc, a, table):
    v = svc.vault
    if a["type"] == "set":
        return set_cost(table, a["key"])
    if a["type"] == "card":
        c = v.card_basic(a["key"])
        return None if not c else c.get("price_usd")
    p = sealedprice.price_for(v, a["key"])
    return p["price"] if p else None


def _row(svc, a, table):
    now = _price(svc, a, table)
    hit = now is not None and ((a["dir"] == "below" and now <= a["price"]) or (a["dir"] == "above" and now >= a["price"]))
    return {**a, "now": now, "hit": bool(hit)}


@api("alerts.list")
def alerts_list(svc):
    mine = [a for a in _all(svc) if a.get("game") == svc.vault.game]
    return listing(svc, mine, finish_costs(svc) if any(a["type"] == "set" for a in mine) else None)


def listing(svc, mine, table):
    """The alerts of the open game with their price now; `table` = {set id: cost to finish} (None: not known yet - a set goal then shows no price)."""
    rows = [_row(svc, a, table) for a in mine]
    rows.sort(key=lambda r: (not r["hit"], r["name"].lower()))
    return {"rows": rows, "hits": sum(1 for r in rows if r["hit"])}


@api("alerts.save", mutates=True)
def alerts_save(svc, type, key, name, dir, price, id=None):
    if type not in TYPES or dir not in ("below", "above") or (type == "set" and dir != "below"):
        raise ApiError("Choose a card, sealed product or set, and 'below' or 'above'.")
    if type == "set" and not svc.vault.conn.execute("SELECT 1 FROM sets WHERE id=?", (key,)).fetchone():
        raise ApiError("Pick a set.")
    try:
        price = round(float(price), 2)
    except (TypeError, ValueError):
        raise ApiError("Type the price to watch for.")
    if price <= 0:
        raise ApiError("Type a price above zero.")
    if not str(key or "").strip():
        raise ApiError("Pick what to watch.")
    keep = [a for a in _all(svc) if a["id"] != id and not (a.get("game") == svc.vault.game and a["type"] == type and a["key"] == key and a["dir"] == dir)]
    keep.append({"id": id or new_uuid(), "game": svc.vault.game, "type": type, "key": key, "name": str(name or key)[:120], "dir": dir, "price": price})
    from .undoext import undoable
    return undoable(svc, f"Set an alert for {str(name or key)[:60]}", lambda: svc.pset(KEY, json.dumps(keep[-300:])), keys=[KEY])


@api("alerts.delete", mutates=True)
def alerts_delete(svc, id):
    from .undoext import undoable
    a = next((x for x in _all(svc) if x["id"] == id), None)
    return undoable(svc, f"Deleted the price alert for {a['name']}" if a else "Deleted a price alert", lambda: svc.pset(KEY, json.dumps([x for x in _all(svc) if x["id"] != id])), keys=[KEY])


@api("alerts.watchWishlist", mutates=True)
def watch_wishlist(svc, percent=10):
    """One press: every wishlist card without an alert gets 'tell me when it is `percent`% cheaper than now'."""
    v = svc.vault
    pct = max(1, min(90, int(percent)))
    have = {a["key"] for a in _all(svc) if a.get("game") == v.game and a["type"] == "card" and a["dir"] == "below"}
    keep, added = _all(svc), 0
    wish = v.wishlist_ids()
    lights = v.card_lights(wish)
    for cid in wish:
        c = lights.get(cid)
        if cid in have or not c or not c.get("price_usd"):
            continue
        keep.append({"id": new_uuid(), "game": v.game, "type": "card", "key": cid, "name": c.get("name", cid), "dir": "below", "price": round(c["price_usd"] * (100 - pct) / 100, 2)})
        added += 1
    svc.pset(KEY, json.dumps(keep[-300:]))
    return {"added": added}
