"""Price alerts: tell me when a card (a wishlist card, say) or a sealed product goes below / above a price.  Kept as one account setting, so they follow you to every device;
they are checked when you look (the prices refresh on their own), so nothing is sent anywhere."""
import json

from .. import sealedprice
from ..db import new_uuid
from .registry import ApiError, api

KEY = "price_alerts"


def _all(svc):
    try:
        got = json.loads(svc.pget(KEY) or "[]")
    except ValueError:
        got = []
    return [a for a in got if isinstance(a, dict) and a.get("id")]


def _price(svc, a):
    v = svc.vault
    if a["type"] == "card":
        c = v.card_basic(a["key"])
        return None if not c else c.get("price_usd")
    p = sealedprice.price_for(v, a["key"])
    return p["price"] if p else None


def _row(svc, a):
    now = _price(svc, a)
    hit = now is not None and ((a["dir"] == "below" and now <= a["price"]) or (a["dir"] == "above" and now >= a["price"]))
    return {**a, "now": now, "hit": bool(hit)}


@api("alerts.list")
def alerts_list(svc):
    v = svc.vault
    rows = [_row(svc, a) for a in _all(svc) if a.get("game") == v.game]
    rows.sort(key=lambda r: (not r["hit"], r["name"].lower()))
    return {"rows": rows, "hits": sum(1 for r in rows if r["hit"])}


@api("alerts.save", mutates=True)
def alerts_save(svc, type, key, name, dir, price, id=None):
    if type not in ("card", "sealed") or dir not in ("below", "above"):
        raise ApiError("Choose a card or sealed product, and 'below' or 'above'.")
    try:
        price = round(float(price), 2)
    except (TypeError, ValueError):
        raise ApiError("Type the price to watch for.")
    if price <= 0:
        raise ApiError("Type a price above zero.")
    if not str(key or "").strip():
        raise ApiError("Pick what to watch.")
    keep = [a for a in _all(svc) if a["id"] != id and not (a.get("game") == svc.vault.game and a["type"] == type and a["key"] == key and a["dir"] == dir)]
    keep.append({"id": id or new_uuid(), "game": svc.vault.game, "type": type, "key": key, "name": str(name or key)[:120], "dir": dir, "price": price})
    svc.pset(KEY, json.dumps(keep[-300:]))
    return {"ok": True}


@api("alerts.delete", mutates=True)
def alerts_delete(svc, id):
    from .undoext import undoable
    a = next((x for x in _all(svc) if x["id"] == id), None)
    return undoable(svc, f"Deleted the price alert for {a['name']}" if a else "Deleted a price alert", lambda: svc.pset(KEY, json.dumps([x for x in _all(svc) if x["id"] != id])), keys=[KEY])


@api("alerts.watchWishlist", mutates=True)
def watch_wishlist(svc, percent=10):
    """One press: every wishlist card without an alert gets 'tell me when it is `percent`% cheaper than now'."""
    v = svc.vault
    pct = max(1, min(90, int(percent)))
    have = {a["key"] for a in _all(svc) if a.get("game") == v.game and a["type"] == "card" and a["dir"] == "below"}
    keep, added = _all(svc), 0
    wish = v.wishlist_ids()
    lights = v.card_lights(wish)
    for cid in wish:
        c = lights.get(cid)
        if cid in have or not c or not c.get("price_usd"):
            continue
        keep.append({"id": new_uuid(), "game": v.game, "type": "card", "key": cid, "name": c.get("name", cid), "dir": "below", "price": round(c["price_usd"] * (100 - pct) / 100, 2)})
        added += 1
    svc.pset(KEY, json.dumps(keep[-300:]))
    return {"added": added}
