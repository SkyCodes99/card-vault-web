class ApiError(Exception):
    """A problem to show the user.  `code` lets screens react (e.g. 'locked'); `extra` is sent along (e.g. retry_after)."""

    def __init__(self, message="", code=None, **extra):
        super().__init__(message)
        self.code, self.extra = code, extra


METHODS = {}
PUBLIC = set()          # callable while the app is locked (the sign-in screen's own calls)
QUIET = set()           # background polling that must not count as 'you are using the app' (keeps auto-lock honest)


def api(name, mutates=False, public=False, quiet=False):
    """Register a method: fn(svc, **args) -> JSON-able.  `mutates` bumps the data revision so open screens refresh."""
    def deco(fn):
        METHODS[name] = (fn, mutates)
        if public:
            PUBLIC.add(name)
        if quiet:
            QUIET.add(name)
        return fn
    return deco
