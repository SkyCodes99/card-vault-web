"""Portfolios: separate collections, an overall view, and groups of portfolios viewed together."""
import json

from .. import tools
from .registry import api
from .service import ApiError

MAIN = "main"


def _db_id(pid):
    return "" if pid in (MAIN, None) else pid


def _api_id(pid):
    return pid or MAIN


def main_name(svc):
    return svc.pget("main_portfolio_name") or "Main"


def load_scope(svc):
    """Put the remembered view (which portfolios are shown) onto the open collection."""
    raw = svc.pget("pf_scope")
    try:
        ids = json.loads(raw) if isinstance(raw, str) else (raw or [])
    except ValueError:
        ids = []
    known = {""} | {p["uuid"] for p in svc.vault.portfolios()}
    ids = [i for i in ids if i in known]
    svc.vault.set_scope(ids)
    t = svc.pget("pf_target")
    if t is not None and (t in known) and (not ids or t in ids):
        svc.vault.target_pf = t


def _state(svc):
    v = svc.vault
    stats = v.portfolio_stats()
    rows = [{"id": MAIN, "name": main_name(svc), "color": "#4a7cff", "main": True, **stats.get("", {"copies": 0, "unique": 0, "value": 0, "spent": 0})}]
    for p in v.portfolios():
        rows.append({"id": p["uuid"], "name": p["name"], "color": p["color"] or "#8a4fd1", "main": False,
                     **stats.get(p["uuid"], {"copies": 0, "unique": 0, "value": 0, "spent": 0})})
    scope = [_api_id(i) for i in (v.scope or [])]
    return {"portfolios": rows, "scope": scope, "all": not scope, "target": _api_id(v.target_pf)}


@api("portfolio.list", quiet=True)
def pf_list(svc):
    return _state(svc)


@api("portfolio.create", mutates=True)
def pf_create(svc, name, color=""):
    name = (name or "").strip()
    if not name:
        raise ApiError("Give the portfolio a name.")
    pid = svc.vault.create_portfolio(name, color)
    return {"id": pid, **_state(svc)}


@api("portfolio.update", mutates=True)
def pf_update(svc, id, name=None, color=None):
    if id == MAIN:
        if name:
            svc.pset("main_portfolio_name", name.strip())
    else:
        svc.vault.update_portfolio(id, name, color)
    return _state(svc)


@api("portfolio.delete", mutates=True)
def pf_delete(svc, id, move_to=MAIN):
    if id == MAIN:
        raise ApiError("The main portfolio can't be deleted.")
    svc.vault.delete_portfolio(id, _db_id(move_to))
    ids = [i for i in (svc.vault.scope or []) if i != id]
    set_scope(svc, ids)
    return _state(svc)


def set_scope(svc, ids):
    svc.vault.set_scope(ids)
    svc.pset("pf_scope", json.dumps(list(ids)))
    svc.pset("pf_target", svc.vault.target_pf)
    svc.reload_state()


@api("portfolio.setScope", mutates=False)
def pf_set_scope(svc, ids):
    """ids = [] (or 'all') shows everything; one id shows that portfolio; several show them together."""
    ids = [] if ids in ("all", None) else [_db_id(i) for i in ids]
    set_scope(svc, ids)
    svc.bump("changed")
    return _state(svc)


@api("portfolio.setTarget")
def pf_set_target(svc, id):
    svc.vault.target_pf = _db_id(id)
    svc.pset("pf_target", svc.vault.target_pf)
    return _state(svc)


@api("portfolio.history")
def pf_history(svc, range="all", start=None, end=None):
    return tools.portfolio_series(svc.vault, range, start or None, end or None)
