"""Portfolios: separate collections, an overall view, groups of portfolios viewed together, and portfolios arranged in categories.

A portfolio can sit inside another one (a category with sub-portfolios), can be tied to checklists (so it shows what those lists are worth), and can be a
"checklists portfolio" that is simply every checklist put together.  How a portfolio is arranged is kept as a small JSON note (`meta`) on its row:
  {"parent": "<portfolio id or 'main'>", "lists": [checklist ids], "allLists": true/false, "prices": true/false}"""
import json

from .. import tools
from .registry import api
from .service import ApiError

MAIN = "main"


def _db_id(pid):
    return "" if pid in (MAIN, None) else pid


def _api_id(pid):
    return pid or MAIN


def main_name(svc):
    return svc.pget("main_portfolio_name") or "My collection"


def meta_of(row):
    try:
        m = json.loads(row.get("meta") or "{}")
    except (ValueError, TypeError):
        m = {}
    return m if isinstance(m, dict) else {}


def load_scope(svc):
    """Put the remembered view (which portfolios are shown) onto the open collection."""
    raw = svc.pget("pf_scope")
    try:
        ids = json.loads(raw) if isinstance(raw, str) else (raw or [])
    except ValueError:
        ids = []
    known = {""} | {p["uuid"] for p in svc.vault.portfolios()}
    ids = [i for i in ids if i in known]
    svc.vault.set_scope(ids)
    t = svc.pget("pf_target")
    if t is not None and (t in known) and (not ids or t in ids):
        svc.vault.target_pf = t


def children_map(svc):
    """{parent api id: [child api ids]} for every portfolio that sits inside another."""
    out = {}
    for p in svc.vault.portfolios():
        par = meta_of(p).get("parent")
        if par:
            out.setdefault(par, []).append(p["uuid"])
    return out


def with_descendants(svc, ids):
    """The given portfolio ids (api form) plus everything inside them."""
    kids = children_map(svc)
    out, todo = [], list(ids)
    while todo:
        i = todo.pop(0)
        if i in out:
            continue
        out.append(i)
        todo.extend(kids.get(i, []))
    return out


def _state(svc):
    v = svc.vault
    stats = v.portfolio_stats()
    blank = {"copies": 0, "unique": 0, "value": 0, "spent": 0}
    raw = v.portfolios()
    by = {p["uuid"]: p for p in raw}
    try:
        main_order = int(svc.pget("main_order", -1))
    except (TypeError, ValueError):
        main_order = -1
    rows = {MAIN: {"id": MAIN, "name": main_name(svc), "color": svc.pget("main_color") or "#4a7cff", "icon": svc.pget("main_icon") or "", "order": main_order, "main": True, "parent": "", "lists": [], "allLists": False, "prices": True, **stats.get("", blank)}}
    for n, p in enumerate(raw):
        m = meta_of(p)
        par = m.get("parent") or ""
        if par and par != MAIN and par not in by:
            par = ""                                                    # its category was deleted somewhere else
        rows[p["uuid"]] = {"id": p["uuid"], "name": p["name"], "color": p["color"] or "#8a4fd1", "icon": m.get("icon") or "", "order": m.get("order", 1000 + n), "main": False, "parent": par,
                           "lists": m.get("lists") or [], "allLists": bool(m.get("allLists")), "prices": m.get("prices", True), **stats.get(p["uuid"], blank)}
    kids = {}
    for r in rows.values():
        if r["parent"]:
            kids.setdefault(r["parent"], []).append(r["id"])
    for k in kids:
        kids[k].sort(key=lambda i: rows[i]["order"])                     # the order the person arranged them in
    names = {c["id"]: c["name"] for c in v.checklists()}
    for r in rows.values():                                              # the checklists that look at this portfolio (shown under it in the tree)
        ids = list(names) if r["allLists"] else [i for i in r["lists"] if i in names]
        r["checklists"] = [{"id": i, "name": names[i]} for i in ids]
    order = []

    def walk(i, depth):
        rows[i]["depth"] = depth
        order.append(i)
        for k in kids.get(i, []):
            walk(k, depth + 1)
    for i in sorted((i for i in rows if not rows[i]["parent"]), key=lambda i: rows[i]["order"]):
        walk(i, 0)
    for i in rows:                                                       # a portfolio inside a loop (should not happen) still shows up
        if i not in order:
            walk(i, 0)
    for r in rows.values():                                              # a category's totals include everything inside it
        sub = [rows[x] for x in with_descendants(svc, [r["id"]]) if x in rows]
        r["kids"] = len(kids.get(r["id"], []))
        r["total"] = {k: sum(s[k] for s in sub) for k in ("copies", "unique", "value", "spent")}
    scope = [_api_id(i) for i in (v.scope or [])]
    return {"portfolios": [rows[i] for i in order], "scope": scope, "all": not scope, "target": _api_id(v.target_pf), "mainNamed": bool(svc.pget("main_named")) or bool(raw) or bool((stats.get("") or blank)["copies"]) or _has_sealed(svc)}


def _has_sealed(svc):
    v = svc.vault
    try:
        return bool(v.conn.execute("SELECT 1 FROM u.sealed WHERE user_id=? AND deleted=0 LIMIT 1", (v.user_id,)).fetchone())
    except Exception:  # noqa: BLE001
        return False


def _clean(m):
    """Drop empty settings (but keep a position of 0, which is a real value)."""
    return {k: v for k, v in m.items() if not (v is None or v is False or v == "" or v == [])}


def _meta_from(svc, base, parent, lists, all_lists, prices, me, icon=None, order=None):
    m = dict(base)
    if icon is not None:
        m["icon"] = (icon or "")[:4]
    if order is not None:
        m["order"] = int(order)
    if parent is not None:
        if parent and parent == me:
            raise ApiError("A portfolio can't be inside itself.")
        if parent and me and parent in with_descendants(svc, [me]):
            raise ApiError("That would put a portfolio inside one of its own sub-portfolios.")
        m["parent"] = parent
    if lists is not None:
        m["lists"] = [int(x) if str(x).isdigit() else x for x in lists]
    if all_lists is not None:
        m["allLists"] = bool(all_lists)
    if prices is not None:
        m["prices"] = bool(prices)
    if m.get("prices", True):
        m.pop("prices", None)                                           # showing prices is the normal state; only "hide" is remembered
    return _clean(m)


@api("portfolio.list", quiet=True)
def pf_list(svc):
    return _state(svc)


@api("portfolio.create", mutates=True)
def pf_create(svc, name, color="", parent=None, lists=None, allLists=None, icon=None):
    name = (name or "").strip()
    if not name:
        raise ApiError("Give the portfolio a name.")
    meta = _meta_from(svc, {}, parent, lists, allLists, None, "", icon)
    pid = svc.vault.create_portfolio(name, color, meta or None)
    return {"id": pid, **_state(svc)}


@api("portfolio.update", mutates=True)
def pf_update(svc, id, name=None, color=None, parent=None, lists=None, allLists=None, prices=None, icon=None):
    if id == MAIN:
        if name:
            svc.pset("main_portfolio_name", name.strip())
        if color:
            svc.pset("main_color", color)
        if icon is not None:
            svc.pset("main_icon", (icon or "")[:4])
    else:
        row = next((p for p in svc.vault.portfolios() if p["uuid"] == id), None)
        if not row:
            raise ApiError("portfolio not found")
        meta = _meta_from(svc, meta_of(row), parent, lists, allLists, prices, id, icon)
        svc.vault.update_portfolio(id, name, color, meta)
    return _state(svc)


@api("portfolio.move", mutates=True)
def pf_move(svc, id, parent="", index=0):
    """Put a portfolio at a place in the tree: inside `parent` ('' = top level) at position `index` among its siblings.  Everything inside it comes along."""
    st = _state(svc)
    rows = {r["id"]: r for r in st["portfolios"]}
    if id not in rows:
        raise ApiError("portfolio not found")
    parent = parent or ""
    if parent and parent not in rows:
        raise ApiError("that portfolio does not exist")
    if parent == id or (parent and parent in with_descendants(svc, [id])):
        raise ApiError("A portfolio can't go inside itself or inside one of its own sub-portfolios.")
    sibs = [r["id"] for r in st["portfolios"] if r["parent"] == parent and r["id"] != id]
    sibs.insert(max(0, min(int(index), len(sibs))), id)
    for pos, pid in enumerate(sibs):
        if pid == MAIN:
            svc.pset("main_order", pos)
            continue
        row = next((p for p in svc.vault.portfolios() if p["uuid"] == pid), None)
        if row:
            m = dict(meta_of(row))
            m["order"] = pos
            if pid == id:
                m["parent"] = parent
            svc.vault.update_portfolio(pid, None, None, _clean(m))
    if id == MAIN and parent:
        raise ApiError("The first portfolio stays at the top level.")
    return _state(svc)


@api("portfolio.delete", mutates=True)
def pf_delete(svc, id, move_to=MAIN):
    if id == MAIN:
        raise ApiError("The main portfolio can't be deleted.")
    row = next((p for p in svc.vault.portfolios() if p["uuid"] == id), None)
    up = meta_of(row).get("parent", "") if row else ""
    for k in children_map(svc).get(id, []):                              # sub-portfolios move up one level
        kr = next(p for p in svc.vault.portfolios() if p["uuid"] == k)
        m = meta_of(kr)
        if up:
            m["parent"] = up
        else:
            m.pop("parent", None)
        svc.vault.update_portfolio(k, None, None, m)
    svc.vault.delete_portfolio(id, _db_id(move_to))
    ids = [i for i in (svc.vault.scope or []) if i != id]
    set_scope(svc, ids)
    return _state(svc)


def set_scope(svc, ids):
    svc.vault.set_scope(ids)
    svc.pset("pf_scope", json.dumps(list(ids)))
    svc.pset("pf_target", svc.vault.target_pf)
    svc.reload_state()


@api("portfolio.setScope", mutates=False)
def pf_set_scope(svc, ids, expand=False):
    """ids = [] (or 'all') shows everything; otherwise exactly these portfolios are shown (expand=True also adds everything inside each one - 'this category and what is in it')."""
    if ids in ("all", None) or not ids:
        ids = []
    else:
        wanted = [_api_id(_db_id(i)) for i in ids]
        if expand:
            wanted = with_descendants(svc, wanted)
        ids = [_db_id(i) for i in dict.fromkeys(wanted)]
    set_scope(svc, ids)
    svc.bump("changed")
    return _state(svc)


@api("portfolio.nameFirst", mutates=True)
def pf_name_first(svc, name):
    """Your first portfolio is a real portfolio like any other: the person names it (it used to be an unnamed 'Main')."""
    name = (name or "").strip()[:40]
    if not name:
        raise ApiError("Give your first portfolio a name.")
    svc.pset("main_portfolio_name", name)
    svc.pset("main_named", "1")
    return _state(svc)


@api("portfolio.setTarget")
def pf_set_target(svc, id):
    svc.vault.target_pf = _db_id(id)
    svc.pset("pf_target", svc.vault.target_pf)
    return _state(svc)


@api("portfolio.history")
def pf_history(svc, range="all", start=None, end=None):
    return tools.portfolio_series(svc.vault, range, start or None, end or None)


@api("home.summary", quiet=True)
def home_summary(svc):
    """The Home screen of the phone layout: value, what changed lately, and the lists and sets you are closest to finishing (the same numbers a home-screen widget would show)."""
    from .. import checklists
    v = svc.vault
    st = v.stats()
    rows = tools.profit_loss(v)
    pt = tools.profit_totals(rows)
    lists = []
    for cl in v.checklists():
        pr = checklists.progress_for_checklist(v, cl)
        if pr.total:
            lists.append({"id": cl["id"], "name": cl["name"], "owned": pr.owned, "total": pr.total, "pct": pr.pct})
    lists.sort(key=lambda l: (0 if l["owned"] >= l["total"] else 1, -l["pct"]))
    sets = []
    for srow, owned, total, _pct in checklists.all_set_progress(v):
        if 0 < owned < total:
            sets.append({"id": srow["id"], "name": srow["name"], "owned": owned, "total": total})
    sets.sort(key=lambda s: -s["owned"] / s["total"])
    recent = []
    for r in v.conn.execute("SELECT card_id, qty, location, updated_at FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY updated_at DESC LIMIT 5", (v.user_id, v.game)):
        c = v.card_light(r["card_id"])
        if c:
            recent.append({"id": r["card_id"], "name": c["name"], "set": c.get("set_name") or "", "qty": r["qty"], "location": r["location"] or "", "value": (c.get("price_usd") or 0) * r["qty"]})
    return {"ready": True, "value": st["value"], "copies": st["copies"], "unique": st["unique"], "paid": pt["paid"], "gain": pt["gain"], "tracked": pt["tracked"],
            "lists": lists[:4], "sets": sets[:4], "recent": recent, "loading": False}
