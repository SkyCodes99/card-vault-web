"""Portfolios: separate collections, an overall view, groups of portfolios viewed together, and portfolios arranged in categories.

A portfolio can sit inside another one (a category with sub-portfolios), can be tied to checklists (so it shows what those lists are worth), and can be a
"checklists portfolio" that is simply every checklist put together.  How a portfolio is arranged is kept as a small JSON note (`meta`) on its row:
  {"parent": "<portfolio id or 'main'>", "lists": [checklist ids], "allLists": true/false, "prices": true/false}"""
import json

from .. import tools
from .registry import api
from .service import ApiError

MAIN = "main"


def _db_id(pid):
    return "" if pid in (MAIN, None) else pid


def _api_id(pid):
    return pid or MAIN


def main_name(svc):
    return svc.pget("main_portfolio_name") or "Main"


def meta_of(row):
    try:
        m = json.loads(row.get("meta") or "{}")
    except (ValueError, TypeError):
        m = {}
    return m if isinstance(m, dict) else {}


def load_scope(svc):
    """Put the remembered view (which portfolios are shown) onto the open collection."""
    raw = svc.pget("pf_scope")
    try:
        ids = json.loads(raw) if isinstance(raw, str) else (raw or [])
    except ValueError:
        ids = []
    known = {""} | {p["uuid"] for p in svc.vault.portfolios()}
    ids = [i for i in ids if i in known]
    svc.vault.set_scope(ids)
    t = svc.pget("pf_target")
    if t is not None and (t in known) and (not ids or t in ids):
        svc.vault.target_pf = t


def children_map(svc):
    """{parent api id: [child api ids]} for every portfolio that sits inside another."""
    out = {}
    for p in svc.vault.portfolios():
        par = meta_of(p).get("parent")
        if par:
            out.setdefault(par, []).append(p["uuid"])
    return out


def with_descendants(svc, ids):
    """The given portfolio ids (api form) plus everything inside them."""
    kids = children_map(svc)
    out, todo = [], list(ids)
    while todo:
        i = todo.pop(0)
        if i in out:
            continue
        out.append(i)
        todo.extend(kids.get(i, []))
    return out


def _state(svc):
    v = svc.vault
    stats = v.portfolio_stats()
    blank = {"copies": 0, "unique": 0, "value": 0, "spent": 0}
    raw = v.portfolios()
    by = {p["uuid"]: p for p in raw}
    rows = {MAIN: {"id": MAIN, "name": main_name(svc), "color": "#4a7cff", "main": True, "parent": "", "lists": [], "allLists": False, "prices": True, **stats.get("", blank)}}
    for p in raw:
        m = meta_of(p)
        par = m.get("parent") or ""
        if par and par != MAIN and par not in by:
            par = ""                                                    # its category was deleted somewhere else
        rows[p["uuid"]] = {"id": p["uuid"], "name": p["name"], "color": p["color"] or "#8a4fd1", "main": False, "parent": par, "lists": m.get("lists") or [],
                           "allLists": bool(m.get("allLists")), "prices": m.get("prices", True), **stats.get(p["uuid"], blank)}
    kids = {}
    for r in rows.values():
        if r["parent"]:
            kids.setdefault(r["parent"], []).append(r["id"])
    order = []

    def walk(i, depth):
        rows[i]["depth"] = depth
        order.append(i)
        for k in kids.get(i, []):
            walk(k, depth + 1)
    walk(MAIN, 0)
    for i in rows:
        if i not in order and not rows[i]["parent"]:
            walk(i, 0)
    for i in rows:                                                       # a portfolio inside a loop (should not happen) still shows up
        if i not in order:
            walk(i, 0)
    for r in rows.values():                                              # a category's totals include everything inside it
        sub = [rows[x] for x in with_descendants(svc, [r["id"]]) if x in rows]
        r["kids"] = len(kids.get(r["id"], []))
        r["total"] = {k: sum(s[k] for s in sub) for k in ("copies", "unique", "value", "spent")}
    scope = [_api_id(i) for i in (v.scope or [])]
    return {"portfolios": [rows[i] for i in order], "scope": scope, "all": not scope, "target": _api_id(v.target_pf)}


def _meta_from(svc, base, parent, lists, all_lists, prices, me):
    m = dict(base)
    if parent is not None:
        if parent and parent == me:
            raise ApiError("A portfolio can't be inside itself.")
        if parent and me and parent in with_descendants(svc, [me]):
            raise ApiError("That would put a portfolio inside one of its own sub-portfolios.")
        m["parent"] = parent
    if lists is not None:
        m["lists"] = [int(x) if str(x).isdigit() else x for x in lists]
    if all_lists is not None:
        m["allLists"] = bool(all_lists)
    if prices is not None:
        m["prices"] = bool(prices)
    if m.get("prices", True):
        m.pop("prices", None)                                           # showing prices is the normal state; only "hide" is remembered
    return {k: v for k, v in m.items() if v not in ("", [], None, False)}


@api("portfolio.list", quiet=True)
def pf_list(svc):
    return _state(svc)


@api("portfolio.create", mutates=True)
def pf_create(svc, name, color="", parent=None, lists=None, allLists=None):
    name = (name or "").strip()
    if not name:
        raise ApiError("Give the portfolio a name.")
    meta = _meta_from(svc, {}, parent, lists, allLists, None, "")
    pid = svc.vault.create_portfolio(name, color, meta or None)
    return {"id": pid, **_state(svc)}


@api("portfolio.update", mutates=True)
def pf_update(svc, id, name=None, color=None, parent=None, lists=None, allLists=None, prices=None):
    if id == MAIN:
        if name:
            svc.pset("main_portfolio_name", name.strip())
    else:
        row = next((p for p in svc.vault.portfolios() if p["uuid"] == id), None)
        if not row:
            raise ApiError("portfolio not found")
        meta = _meta_from(svc, meta_of(row), parent, lists, allLists, prices, id)
        svc.vault.update_portfolio(id, name, color, meta)
    return _state(svc)


@api("portfolio.delete", mutates=True)
def pf_delete(svc, id, move_to=MAIN):
    if id == MAIN:
        raise ApiError("The main portfolio can't be deleted.")
    row = next((p for p in svc.vault.portfolios() if p["uuid"] == id), None)
    up = meta_of(row).get("parent", "") if row else ""
    for k in children_map(svc).get(id, []):                              # sub-portfolios move up one level
        kr = next(p for p in svc.vault.portfolios() if p["uuid"] == k)
        m = meta_of(kr)
        if up:
            m["parent"] = up
        else:
            m.pop("parent", None)
        svc.vault.update_portfolio(k, None, None, m)
    svc.vault.delete_portfolio(id, _db_id(move_to))
    ids = [i for i in (svc.vault.scope or []) if i != id]
    set_scope(svc, ids)
    return _state(svc)


def set_scope(svc, ids):
    svc.vault.set_scope(ids)
    svc.pset("pf_scope", json.dumps(list(ids)))
    svc.pset("pf_target", svc.vault.target_pf)
    svc.reload_state()


@api("portfolio.setScope", mutates=False)
def pf_set_scope(svc, ids):
    """ids = [] (or 'all') shows everything; one id shows that portfolio (and anything inside it); several show them together."""
    if ids in ("all", None) or not ids:
        ids = []
    else:
        ids = [_db_id(i) for i in with_descendants(svc, [_api_id(_db_id(i)) for i in ids])]
    set_scope(svc, ids)
    svc.bump("changed")
    return _state(svc)


@api("portfolio.setTarget")
def pf_set_target(svc, id):
    svc.vault.target_pf = _db_id(id)
    svc.pset("pf_target", svc.vault.target_pf)
    return _state(svc)


@api("portfolio.history")
def pf_history(svc, range="all", start=None, end=None):
    return tools.portfolio_series(svc.vault, range, start or None, end or None)
