"""Portfolios: separate collections, an overall view, groups of portfolios viewed together, and portfolios arranged in categories.

A portfolio can sit inside another one (a category with sub-portfolios), can be tied to checklists (so it shows what those lists are worth), and can be a
"checklists portfolio" that is simply every checklist put together.  How a portfolio is arranged is kept as a small JSON note (`meta`) on its row:
  {"parent": "<portfolio id or 'main'>", "lists": [checklist ids], "allLists": true/false, "prices": true/false}"""
import json
import time

from .. import tools
from ..db import now_iso
from .registry import api
from .service import ApiError

MAIN = "main"


def _db_id(pid):
    return "" if pid in (MAIN, None) else pid


def _api_id(pid):
    return pid or MAIN


def main_name(svc):
    return svc.pget("main_portfolio_name") or "My collection"


def meta_of(row):
    try:
        m = json.loads(row.get("meta") or "{}")
    except (ValueError, TypeError):
        m = {}
    return m if isinstance(m, dict) else {}


def load_scope(svc):
    """Put the remembered view (which portfolios are shown) onto the open collection."""
    raw = svc.pget("pf_scope")
    try:
        ids = json.loads(raw) if isinstance(raw, str) else (raw or [])
    except ValueError:
        ids = []
    known = {""} | {p["uuid"] for p in svc.vault.portfolios()}
    ids = [i for i in ids if i in known]
    svc.vault.set_scope(ids)
    t = svc.pget("pf_target")
    if t is not None and (t in known) and (not ids or t in ids):
        svc.vault.target_pf = t
    _not_a_category(svc)


def children_map(svc):
    """{parent api id: [child api ids]} for every portfolio that sits inside another."""
    out = {}
    for p in svc.vault.portfolios():
        par = meta_of(p).get("parent")
        if par:
            out.setdefault(par, []).append(p["uuid"])
    return out


def with_descendants(svc, ids):
    """The given portfolio ids (api form) plus everything inside them."""
    kids = children_map(svc)
    out, todo = [], list(ids)
    while todo:
        i = todo.pop(0)
        if i in out:
            continue
        out.append(i)
        todo.extend(kids.get(i, []))
    return out


def _stats_all_games(svc):
    """{portfolio id: {copies, unique, value, spent, sealed}} counted over EVERY game (a portfolio holds Pokemon, Magic, Funko ... together), each card valued from its own game's price list."""
    from .portfolioall import _prices, _sealed_prices
    v = svc.vault
    out = {}
    cell = lambda pf: out.setdefault(pf or "", {"copies": 0, "unique": 0, "value": 0.0, "spent": 0.0, "sealed": 0})
    gids = [r[0] for r in v.conn.execute("SELECT DISTINCT game FROM u.lots WHERE user_id=? AND deleted=0 AND qty>0 UNION SELECT DISTINCT game FROM u.sealed WHERE user_id=? AND deleted=0 AND qty>0", (v.user_id, v.user_id))]
    for gid in gids:
        rows = v.conn.execute("SELECT COALESCE(portfolio,'') AS pf, card_id, SUM(qty) AS q, SUM(CASE WHEN purchase_price IS NOT NULL THEN qty*purchase_price ELSE 0 END) AS paid FROM u.lots "
                              "WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY COALESCE(portfolio,''), card_id", (v.user_id, gid)).fetchall()
        price = _prices(svc, gid, {r["card_id"] for r in rows}) if gid != v.game else None
        for r in rows:
            c = cell(r["pf"])
            c["copies"] += r["q"] or 0
            c["unique"] += 1
            c["spent"] += r["paid"] or 0
            usd = price.get(r["card_id"]) if price is not None else (v.card_light(r["card_id"]) or {}).get("price_usd")
            c["value"] += (usd or 0) * (r["q"] or 0)
        seal = v.conn.execute("SELECT COALESCE(portfolio,'') AS pf, name, SUM(qty) AS q, SUM(CASE WHEN paid IS NOT NULL THEN paid*qty ELSE 0 END) AS paid FROM u.sealed "
                              "WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY COALESCE(portfolio,''), name", (v.user_id, gid)).fetchall()
        if gid == v.game:
            from .. import sealedprice
            sp = {r["name"]: ((sealedprice.price_for(v, r["name"]) or {}).get("price")) for r in seal}
        else:
            sp = _sealed_prices(svc, gid, {r["name"] for r in seal})
        for r in seal:
            c = cell(r["pf"])
            c["sealed"] += r["q"] or 0
            c["spent"] += r["paid"] or 0
            c["value"] += (sp.get(r["name"]) or 0) * (r["q"] or 0)
    return out


def _stats(svc):
    """The per-portfolio counts and values - the slow part of the list.  Counted over every game together, whichever game is open.  They only change when your collection (or a price list) does, so they are
    kept until then (a change of view reuses them)."""
    v = svc.vault
    stamp = (svc.last_change, v.user_id, id(v), int(time.time() // 300))
    hit = getattr(v, "_pf_stats", None)
    if hit and hit[0] == stamp:
        return hit[1]
    try:
        out = _stats_all_games(svc)
    except Exception:  # noqa: BLE001 - never lose the list over a damaged price file: fall back to the open game
        out = v.portfolio_stats()
    v._pf_stats = (stamp, out)
    return out


def _state(svc):
    v = svc.vault
    stats = _stats(svc)
    blank = {"copies": 0, "unique": 0, "value": 0, "spent": 0, "sealed": 0}
    raw = v.portfolios()
    by = {p["uuid"]: p for p in raw}
    try:
        main_order = int(svc.pget("main_order", -1))
    except (TypeError, ValueError):
        main_order = -1
    rows = {MAIN: {"id": MAIN, "name": main_name(svc), "color": svc.pget("main_color") or "#4a7cff", "icon": svc.pget("main_icon") or "", "accepts": "", "order": main_order, "main": True, "parent": "", "lists": [], "allLists": False, "prices": True, **stats.get("", blank)}}
    for n, p in enumerate(raw):
        m = meta_of(p)
        par = m.get("parent") or ""
        if par and par != MAIN and par not in by:
            par = ""                                                    # its category was deleted somewhere else
        rows[p["uuid"]] = {"id": p["uuid"], "name": p["name"], "color": p["color"] or "#8a4fd1", "icon": m.get("icon") or "", "accepts": m.get("accepts") or "", "order": m.get("order", 1000 + n), "main": False, "parent": par,
                           "lists": m.get("lists") or [], "allLists": bool(m.get("allLists")), "prices": m.get("prices", True), **stats.get(p["uuid"], blank)}
    kids = {}
    for r in rows.values():
        if r["parent"]:
            kids.setdefault(r["parent"], []).append(r["id"])
    for k in kids:
        kids[k].sort(key=lambda i: rows[i]["order"])                     # the order the person arranged them in
    names = {c["id"]: c["name"] for c in v.checklists()}
    for r in rows.values():                                              # the checklists that look at this portfolio (shown under it in the tree)
        ids = list(names) if r["allLists"] else [i for i in r["lists"] if i in names]
        r["checklists"] = [{"id": i, "name": names[i]} for i in ids]
    order = []

    def walk(i, depth):
        rows[i]["depth"] = depth
        order.append(i)
        for k in kids.get(i, []):
            walk(k, depth + 1)
    for i in sorted((i for i in rows if not rows[i]["parent"]), key=lambda i: rows[i]["order"]):
        walk(i, 0)
    for i in rows:                                                       # a portfolio inside a loop (should not happen) still shows up
        if i not in order:
            walk(i, 0)
    def inside(i):                                                       # (built from the one list of children above - not re-read from the database for every row)
        out, todo = [], [i]
        while todo:
            j = todo.pop()
            if j not in out:
                out.append(j)
                todo.extend(kids.get(j, []))
        return out
    for r in rows.values():                                              # a category's totals include everything inside it
        sub = [rows[x] for x in inside(r["id"]) if x in rows]
        r["kids"] = len(kids.get(r["id"], []))
        r["total"] = {k: sum(s.get(k, 0) for s in sub) for k in ("copies", "unique", "value", "spent", "sealed")}
        r["total"]["items"] = r["total"]["copies"] + r["total"]["sealed"]                 # cards + sealed products: what 'items' means on every portfolio screen
    for r in rows.values():
        r.setdefault("sealed", 0)
        r["items"] = r["copies"] + r["sealed"]
    scope = [_api_id(i) for i in (v.scope or [])]
    return {"portfolios": [rows[i] for i in order], "scope": scope, "all": not scope, "target": _api_id(v.target_pf), "mainNamed": bool(svc.pget("main_named")) or bool(raw) or bool((stats.get("") or blank)["copies"]) or _has_sealed(svc)}


def _has_sealed(svc):
    v = svc.vault
    try:
        return bool(v.conn.execute("SELECT 1 FROM u.sealed WHERE user_id=? AND deleted=0 LIMIT 1", (v.user_id,)).fetchone())
    except Exception:  # noqa: BLE001
        return False


def _clean(m):
    """Drop empty settings (but keep a position of 0, which is a real value)."""
    return {k: v for k, v in m.items() if not (v is None or v is False or v == "" or v == [])}


def _meta_from(svc, base, parent, lists, all_lists, prices, me, icon=None, order=None, accepts=None):
    m = dict(base)
    if accepts is not None:
        m["accepts"] = accepts if accepts in ("cards", "sealed", "none") else ""
    if icon is not None:
        m["icon"] = (icon or "")[:4]
    if order is not None:
        m["order"] = int(order)
    if parent is not None:
        if parent and parent == me:
            raise ApiError("A portfolio can't be inside itself.")
        if parent and me and parent in with_descendants(svc, [me]):
            raise ApiError("That would put a portfolio inside one of its own sub-portfolios.")
        m["parent"] = parent
    if lists is not None:
        m["lists"] = [int(x) if str(x).isdigit() else x for x in lists]
    if all_lists is not None:
        m["allLists"] = bool(all_lists)
    if prices is not None:
        m["prices"] = bool(prices)
    if m.get("prices", True):
        m.pop("prices", None)                                           # showing prices is the normal state; only "hide" is remembered
    return _clean(m)


@api("portfolio.list", quiet=True)
def pf_list(svc):
    return _state(svc)


def _check_category_place(svc, meta):
    """Portfolios sit under categories and sub-portfolios under portfolios; a category itself only sits at the top or inside another category."""
    par = (meta or {}).get("parent")
    if (meta or {}).get("accepts") == "none" and par and par != MAIN:
        prow = next((p for p in svc.vault.portfolios() if p["uuid"] == par), None)
        if prow and meta_of(prow).get("accepts") != "none":
            raise ApiError("A category can only sit at the top level or inside another category.")


@api("portfolio.create", mutates=True)
def pf_create(svc, name, color="", parent=None, lists=None, allLists=None, icon=None, accepts=None):
    name = (name or "").strip()
    if not name:
        raise ApiError("Give the portfolio a name.")
    meta = _meta_from(svc, {}, parent, lists, allLists, None, "", icon, None, accepts)
    _check_category_place(svc, meta)
    pid = svc.vault.create_portfolio(name, color, meta or None)
    return {"id": pid, **_state(svc)}


@api("portfolio.update", mutates=True)
def pf_update(svc, id, name=None, color=None, parent=None, lists=None, allLists=None, prices=None, icon=None, accepts=None):
    if id == MAIN:
        if name:
            svc.pset("main_portfolio_name", name.strip())
        if color:
            svc.pset("main_color", color)
        if icon is not None:
            svc.pset("main_icon", (icon or "")[:4])
    else:
        row = next((p for p in svc.vault.portfolios() if p["uuid"] == id), None)
        if not row:
            raise ApiError("portfolio not found")
        if accepts == "none" and meta_of(row).get("accepts") != "none":
            raise ApiError("Use 'Make it a category' - it moves anything inside it first.")
        meta = _meta_from(svc, meta_of(row), parent, lists, allLists, prices, id, icon, None, accepts)
        _check_category_place(svc, meta)
        svc.vault.update_portfolio(id, name, color, meta)
    return _state(svc)


@api("portfolio.move", mutates=True)
def pf_move(svc, id, parent="", index=0):
    """Put a portfolio at a place in the tree: inside `parent` ('' = top level) at position `index` among its siblings.  Everything inside it comes along."""
    st = _state(svc)
    rows = {r["id"]: r for r in st["portfolios"]}
    if id not in rows:
        raise ApiError("portfolio not found")
    parent = parent or ""
    if parent and parent not in rows:
        raise ApiError("that portfolio does not exist")
    if parent == id or (parent and parent in with_descendants(svc, [id])):
        raise ApiError("A portfolio can't go inside itself or inside one of its own sub-portfolios.")
    if rows[id].get("accepts") == "none" and parent and rows[parent].get("accepts") != "none":
        raise ApiError("A category can only sit at the top level or inside another category - portfolios sit under categories, and sub-portfolios under portfolios.")
    sibs = [r["id"] for r in st["portfolios"] if r["parent"] == parent and r["id"] != id]
    sibs.insert(max(0, min(int(index), len(sibs))), id)
    for pos, pid in enumerate(sibs):
        if pid == MAIN:
            svc.pset("main_order", pos)
            continue
        row = next((p for p in svc.vault.portfolios() if p["uuid"] == pid), None)
        if row:
            m = dict(meta_of(row))
            m["order"] = pos
            if pid == id:
                m["parent"] = parent
            svc.vault.update_portfolio(pid, None, None, _clean(m))
    if id == MAIN and parent:
        raise ApiError("The first portfolio stays at the top level.")
    return _state(svc)


def _own_items(svc, id):
    """(card stacks, sealed rows) held directly in this portfolio (not what is inside its sub-portfolios)."""
    v = svc.vault
    pid = _db_id(id)
    c = v.conn.execute("SELECT COUNT(*), COALESCE(SUM(qty),0) FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND COALESCE(portfolio,'')=?", (v.user_id, v.game, pid)).fetchone()
    s = v.conn.execute("SELECT COUNT(*), COALESCE(SUM(qty),0) FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND COALESCE(portfolio,'')=?", (v.user_id, v.game, pid)).fetchone()
    return {"cards": int(c[1]), "cardStacks": int(c[0]), "sealed": int(s[1]), "sealedRows": int(s[0])}


@api("portfolio.itemCount", quiet=True)
def pf_item_count(svc, id):
    """What a portfolio holds itself: a category can only be made from a portfolio that holds nothing."""
    return _own_items(svc, id)


@api("portfolio.convert", mutates=True)
def pf_convert(svc, id, to, moveTo=None, moveSealedTo=None):
    """Turn a portfolio into a CATEGORY (a folder that holds portfolios and never any items) or back into a normal PORTFOLIO.
    To become a category it must be empty: pass moveTo = the portfolio its cards and sealed products should go to, and they are moved first."""
    from ..db import now_iso
    if id == MAIN:
        raise ApiError("The main portfolio holds your everyday items, so it can't become a category.")
    st = _state(svc)
    rows = {r["id"]: r for r in st["portfolios"]}
    if id not in rows:
        raise ApiError("portfolio not found")
    v = svc.vault
    row = next(p for p in v.portfolios() if p["uuid"] == id)
    if to == "portfolio":
        if rows[id].get("accepts") != "none":
            return st
        par = rows[id]["parent"]
        meta = _meta_from(svc, meta_of(row), None, None, None, None, id, None, None, "")
        v.update_portfolio(id, None, None, meta)
        return _state(svc)
    if to != "category":
        raise ApiError("Choose Category or Portfolio.")
    if rows[id].get("accepts") == "none":
        return st
    par = rows[id]["parent"]
    if par and rows[par].get("accepts") != "none":
        raise ApiError("A category can only sit at the top level or inside another category. Move this portfolio out of its parent first.")
    n = _own_items(svc, id)
    if n["cards"] or n["sealed"]:
        if (n["cards"] and not moveTo) or (n["sealed"] and not (moveSealedTo or moveTo)):
            raise ApiError(f"This portfolio still holds {n['cards']} card(s) and {n['sealed']} sealed product(s). A category can't hold items - choose where to move them first.")
        dest_c, dest_s = moveTo or moveSealedTo, moveSealedTo or moveTo
        for d in (dest_c, dest_s):
            if d == id or d not in rows or rows[d].get("accepts") == "none":
                raise ApiError("Choose a portfolio (not a category) to move the items into.")
        if n["cards"]:
            v.check_accepts(_db_id(dest_c), "cards")
        if n["sealed"]:
            v.check_accepts(_db_id(dest_s), "sealed")
        ts = now_iso()
        with v.action(f"Moved {n['cards'] + n['sealed']} item(s) out of '{rows[id]['name']}' to make it a category"):
            v.conn.execute("UPDATE u.lots SET portfolio=?, placed=1, updated_at=? WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(portfolio,'')=?", (_db_id(dest_c), ts, v.user_id, v.game, id))
            v.conn.execute("UPDATE u.sealed SET portfolio=?, updated_at=? WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(portfolio,'')=?", (_db_id(dest_s), ts, v.user_id, v.game, id))
            v.commit()
    meta = _meta_from(svc, meta_of(row), None, None, None, None, id, None, None, "none")
    v.update_portfolio(id, None, None, meta)
    svc.reload_state()
    return _state(svc)


@api("portfolio.delete", mutates=True)
def pf_delete(svc, id, move_to=MAIN, move_sealed_to=None, confirm=None):
    """Delete a portfolio or category.  Nothing you own is deleted: its cards go to `move_to`, its sealed products to `move_sealed_to` (default the same place), and the portfolios inside it move up
    one level.  `confirm` is the name typed to confirm (the screen asks for it; it must match when given)."""
    if id == MAIN:
        raise ApiError("The main portfolio can't be deleted.")
    row = next((p for p in svc.vault.portfolios() if p["uuid"] == id), None)
    if row is None:
        raise ApiError("portfolio not found")
    if confirm is not None and str(confirm).strip().lower() != str(row["name"]).strip().lower():
        raise ApiError("The name you typed doesn't match, so nothing was deleted.")
    v0 = svc.vault
    n = _own_items(svc, id)
    dest_c, dest_s = move_to or MAIN, move_sealed_to or move_to or MAIN
    inside = {id}
    for _ in range(12):                                                    # it can't be emptied into itself or into something inside it
        inside |= {k for kids in [children_map(svc).get(i, []) for i in list(inside)] for k in kids}
    for d in (dest_c, dest_s):
        if d in inside:
            raise ApiError("Choose a portfolio that isn't inside the one being deleted.")
        if d != MAIN and v0.accepts_of(_db_id(d)) == "none":
            raise ApiError("A category can't hold items - choose a portfolio.")
    if n["cards"]:
        v0.check_accepts(_db_id(dest_c), "cards")
    if n["sealed"]:
        v0.check_accepts(_db_id(dest_s), "sealed")
    up = meta_of(row).get("parent", "") if row else ""
    for k in children_map(svc).get(id, []):                              # sub-portfolios move up one level
        kr = next(p for p in svc.vault.portfolios() if p["uuid"] == k)
        m = meta_of(kr)
        if up:
            m["parent"] = up
        else:
            m.pop("parent", None)
        svc.vault.update_portfolio(k, None, None, m)
    ts = now_iso()
    svc.vault.conn.execute("UPDATE u.sealed SET portfolio=?, updated_at=? WHERE user_id=? AND portfolio=?", (_db_id(dest_s), ts, svc.vault.user_id, id))     # (the delete below moves the cards)
    svc.vault.delete_portfolio(id, _db_id(dest_c))
    ids = [i for i in (svc.vault.scope or []) if i != id]
    set_scope(svc, ids)
    return _state(svc)


def _not_a_category(svc):
    """New copies go to `target_pf`: it must be somewhere that can hold them - never a category (a folder for portfolios)."""
    v = svc.vault
    if v.target_pf and v.accepts_of(v.target_pf) == "none":
        inside = [i for i in (v.scope or []) if i and v.accepts_of(i) != "none"]
        v.target_pf = inside[0] if inside else ""


def set_scope(svc, ids):
    svc.vault.set_scope(ids)
    _not_a_category(svc)
    svc.pset("pf_scope", json.dumps(list(ids)))
    svc.pset("pf_target", svc.vault.target_pf)
    svc.reload_state()


@api("portfolio.setScope", mutates=False)
def pf_set_scope(svc, ids, expand=False):
    """ids = [] (or 'all') shows everything; otherwise exactly these portfolios are shown (expand=True also adds everything inside each one - 'this category and what is in it')."""
    if ids in ("all", None) or not ids:
        ids = []
    else:
        wanted = [_api_id(_db_id(i)) for i in ids]
        if expand:
            wanted = with_descendants(svc, wanted)
        ids = [_db_id(i) for i in dict.fromkeys(wanted)]
    set_scope(svc, ids)
    svc.bump("changed", data=False)                                       # only the view changed - nothing to back up or sync
    return _state(svc)


@api("portfolio.nameFirst", mutates=True)
def pf_name_first(svc, name):
    """Your first portfolio is a real portfolio like any other: the person names it (it used to be an unnamed 'Main')."""
    name = (name or "").strip()[:40]
    if not name:
        raise ApiError("Give your first portfolio a name.")
    svc.pset("main_portfolio_name", name)
    svc.pset("main_named", "1")
    return _state(svc)


@api("portfolio.setTarget")
def pf_set_target(svc, id):
    if _db_id(id) and svc.vault.accepts_of(_db_id(id)) == "none":
        raise ApiError("A category is a folder - it can't hold items. Choose a portfolio inside it for new cards and sealed products.")
    svc.vault.target_pf = _db_id(id)
    svc.pset("pf_target", svc.vault.target_pf)
    return _state(svc)


@api("portfolio.history")
def pf_history(svc, range="all", start=None, end=None):
    return tools.portfolio_series(svc.vault, range, start or None, end or None)


@api("home.summary", quiet=True)
def home_summary(svc):
    """The Home screen of the phone layout: value, what changed lately, and the lists and sets you are closest to finishing (the same numbers a home-screen widget would show)."""
    from .. import checklists
    v = svc.vault
    st = v.stats()
    st = {**st, "value": st["value"] + v.sealed_in_view()["value"]}          # sealed products count towards the total
    rows = tools.profit_loss(v)
    pt = tools.profit_totals(rows)
    lists = []
    for cl in v.checklists():
        pr = checklists.progress_for_checklist(v, cl)
        if pr.total:
            lists.append({"id": cl["id"], "name": cl["name"], "owned": pr.owned, "total": pr.total, "pct": pr.pct})
    lists.sort(key=lambda l: (0 if l["owned"] >= l["total"] else 1, -l["pct"]))
    sets = []
    for srow, owned, total, _pct in checklists.all_set_progress(v):
        if 0 < owned < total:
            sets.append({"id": srow["id"], "name": srow["name"], "owned": owned, "total": total})
    sets.sort(key=lambda s: -s["owned"] / s["total"])
    recent = []
    for r in v.conn.execute("SELECT card_id, qty, location, updated_at FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY updated_at DESC LIMIT 5", (v.user_id, v.game)):
        c = v.card_light(r["card_id"])
        if c:
            recent.append({"id": r["card_id"], "name": c["name"], "set": c.get("set_name") or "", "qty": r["qty"], "location": r["location"] or "", "value": (c.get("price_usd") or 0) * r["qty"]})
    from .cards import img
    sealed = v.sealed_in_view()
    top = [{"id": r["id"], "name": r["name"], "set": r["set_name"] or "", "qty": r["qty"], "price": r["price_usd"], "value": r["value"], "img": img(r["id"], r["set_id"] or "")} for r in v.top_cards(10)]
    top_sealed = []
    try:
        from .. import sealedprice
        scope = list(v.scope or [])
        held = {}
        for r in v.conn.execute("SELECT name, SUM(qty) AS q, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY name, COALESCE(portfolio,'')", (v.user_id, v.game)):
            if scope and r["pf"] not in scope:
                continue
            held[r["name"]] = held.get(r["name"], 0) + (r["q"] or 0)
        for nm, q in held.items():
            pr = sealedprice.price_for(v, nm)
            usd = (pr or {}).get("price")
            if usd:
                top_sealed.append({"name": nm, "qty": q, "price": usd, "value": round(usd * q, 2), "img": sealedprice.image_for(v, nm)})
        top_sealed.sort(key=lambda t: -t["value"])
        top_sealed = top_sealed[:10]
    except Exception:  # noqa: BLE001 - a game with no sealed list
        top_sealed = []
    return {"ready": True, "topSealed": top_sealed, "value": st["value"], "copies": st["copies"], "unique": st["unique"], "paid": pt["paid"], "gain": pt["gain"], "tracked": pt["tracked"],
            "sealedCopies": sealed["copies"], "sealedValue": round(sealed["value"], 2), "top": top, "owner": svc.pget("cloud_username") or "", "game": svc.game.name,
            "lists": lists[:60], "sets": sets[:6], "recent": recent, "loading": False}
