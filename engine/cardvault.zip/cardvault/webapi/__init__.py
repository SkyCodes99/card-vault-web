"""The data interface behind the React screens: named methods that take / return plain JSON.

Every method runs on ONE worker thread (the one that owns the SQLite connections), so screens can call them from any thread."""
import queue
import threading
import traceback

from .registry import METHODS, api  # noqa: F401
from .service import Service  # noqa: F401
from . import accountapi, authapi, cards, cloudapi, dialogs, gamesapi, jobs, lists, money, organize, extras, portfolios, scanner, settings, sharedev, showcase, storage, search, sealedcat, trendapi, backupfile, avatarapi, scannerlearn, dailyapi  # noqa: F401  (importing registers their methods)
