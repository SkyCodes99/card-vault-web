"""The data interface behind the React screens: named methods that take / return plain JSON.

Every method runs on ONE worker thread (the one that owns the SQLite connections), so screens can call them from any thread."""

from .registry import METHODS, api  # noqa: F401
from .service import Service  # noqa: F401
from . import accountapi, authapi, browse, cards, cloudapi, dialogs, gamesapi, jobs, lists, money, organize, extras, portfolios, scanner, scanweb, scanmem, feedbackapi, listsource, setkinds_api, devsealed, settings, sharedev, showcase, storage, search, searchfacets, sealedcat, trendapi, sethistapi, backupfile, avatarapi, scannerlearn, dailyapi, setanalytics, listanalytics, portfolioanalytics, tcgsyncapi, selfcheck, placement, portfolioall, devgames, listsealed, tradesealed, tradeany, fillhints, sharing, complete, resetimport, inventory, buys, alerts, goals, planner, sharepages, tradematch, tradefinder, friends, friendcircles, races, friendtrade, insights, notify, sealedpromo, searchindex, perf, devlogapi, mydata, safety, setgoalsapi, valuegraph, wishlistapi, reportapi, listadd, syncreview, lotsbulk, hereapi, topmovers, collectionexport, packopen, gradingapi, pricewatch, releasecal, insurancereport, missingprice, whatsnewapi, soldapi, customapi, shareimage, listimportapi, miscshare, sharelock, barcodeapi, photoapi, startpage, homeapi, deckapi, exemptapi, weeklyapi, changesapi, popapi, marketindexapi, pricedetailapi  # noqa: F401  (importing registers their methods)
from . import packartsapi  # noqa: F401,E402  (pack arts of sleeved packs; on its own line so it merges cleanly)
from . import onlineapi  # noqa: F401,E402  (the website's online reads: what is yours, added to Card Data's rows; own line so it merges cleanly)
from . import onlinefacts  # noqa: F401,E402  (the website's whole-list views of your cards from Card Data's facts file, lane O2; own line so it merges cleanly)
