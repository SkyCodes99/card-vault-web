"""The data interface behind the React screens: named methods that take / return plain JSON.

Every method runs on ONE worker thread (the one that owns the SQLite connections), so screens can call them from any thread."""

from .registry import METHODS, api  # noqa: F401
from .service import Service  # noqa: F401
from . import accountapi, authapi, browse, cards, cloudapi, dialogs, gamesapi, jobs, lists, money, organize, extras, portfolios, scanner, scanweb, scanmem, feedbackapi, listsource, setkinds_api, devsealed, settings, sharedev, showcase, storage, search, searchfacets, sealedcat, trendapi, backupfile, avatarapi, scannerlearn, dailyapi, setanalytics, listanalytics, portfolioanalytics, tcgsyncapi, selfcheck, placement, portfolioall, devgames, listsealed, tradesealed, tradeany, fillhints, sharing, complete, resetimport, inventory, buys, alerts, goals, planner, sharepages, tradematch, tradefinder, friends, friendcircles, friendtrade, insights, notify, sealedpromo, searchindex, perf, devlogapi, mydata, safety, setgoalsapi, valuegraph, wishlistapi, listadd, syncreview, lotsbulk, hereapi, topmovers, collectionexport, packopen, gradingapi, pricewatch, releasecal, insurancereport, missingprice, whatsnewapi, soldapi, customapi, shareimage  # noqa: F401  (importing registers their methods)
