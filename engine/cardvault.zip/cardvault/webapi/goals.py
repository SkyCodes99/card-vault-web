"""Collection goals: finish a set, reach a total value, or own a number of different cards - with progress and a rough 'at this pace' date worked out from how you added recently.
Kept as one account setting, so goals follow you to every device."""
import datetime
import json

from ..db import new_uuid
from .registry import ApiError, api

KEY = "collection_goals"
TYPES = ("set", "value", "cards", "name", "dex")
DONE = "goal_done"                      # goals that were completed (and celebrated): {goal id: day}


def _all(svc):
    try:
        got = json.loads(svc.pget(KEY) or "[]")
    except ValueError:
        got = []
    return [g for g in got if isinstance(g, dict) and g.get("id")]


def _recent_pace(v, days=45):
    """(different cards added per day, value added per day) over the last `days` days, from what you actually added (each purchase's date)."""
    since = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
    n = v.conn.execute("SELECT COUNT(DISTINCT card_id) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(NULLIF(purchased,''), substr(added,1,10))>=?",
                       (v.user_id, v.game, since)).fetchone()[0]
    snaps = [s for s in v.snapshots() if s["day"] >= since and s.get("total_usd") is not None]
    vpd = 0.0
    if len(snaps) >= 2:
        span = (datetime.date.fromisoformat(snaps[-1]["day"]) - datetime.date.fromisoformat(snaps[0]["day"])).days
        vpd = (snaps[-1]["total_usd"] - snaps[0]["total_usd"]) / max(1, span)
    return n / days, vpd


def _eta(left, per_day):
    if left <= 0:
        return {"done": True}
    if per_day <= 0:
        return {"done": False, "days": None}
    days = int(left / per_day) + 1
    return {"done": False, "days": days, "date": (datetime.date.today() + datetime.timedelta(days=days)).isoformat()}


def _dex_range(key):
    try:
        a, b = (int(x) for x in str(key).replace(" ", "").split("-", 1))
        return min(a, b), max(a, b)
    except (ValueError, TypeError):
        return 1, 1


def _theme_progress(v, g):
    """(owned, total) for 'own every <name>' (different cards whose name contains the text) and 'every Pokémon in a Pokédex range' (different Pokémon, e.g. the original 151)."""
    owned = set(v.owned_map().keys())
    if g["type"] == "name":
        ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE name LIKE ?", ("%" + str(g["key"]).replace("%", "").replace("_", "") + "%",))]
        return sum(1 for i in ids if i in owned), len(ids)
    a, b = _dex_range(g["key"])
    have, total = set(), set()
    for cid, dex in v.conn.execute("SELECT id, dex FROM cards WHERE dex IS NOT NULL AND dex<>''"):
        try:
            n = int(str(dex).split(",")[0])
        except ValueError:
            continue
        if a <= n <= b:
            total.add(n)
            if cid in owned:
                have.add(n)
    return len(have), b - a + 1


def _done(svc):
    try:
        return json.loads(svc.pget(DONE) or "{}")
    except ValueError:
        return {}


@api("goals.list")
def goals_list(svc):
    v = svc.vault
    st = v.stats()
    owned_set = v.owned_by_set()
    sets = {s["id"]: s for s in v.sets()}
    cards_pd, value_pd = _recent_pace(v)
    out = []
    for g in _all(svc):
        if g.get("game") != v.game:
            continue
        if g["type"] == "set":
            s = sets.get(g["key"])
            if not s:
                continue
            have, total = owned_set.get(s["id"], 0), s["n"] or 0
            row = {"have": have, "total": total, "label": f"{have} of {total} cards", "pct": round(100 * have / total, 1) if total else 0, **_eta(total - have, cards_pd)}
        elif g["type"] in ("name", "dex"):
            have, total = _theme_progress(v, g)
            row = {"have": have, "total": total, "label": f"{have} of {total} cards" if g["type"] == "name" else f"{have} of {total} Pokémon", "pct": round(100 * have / total, 1) if total else 0,
                   **_eta(total - have, cards_pd)}
        elif g["type"] == "value":
            row = {"have": round(st["value"], 2), "total": g["target"], "label": None, "pct": round(100 * st["value"] / g["target"], 1) if g["target"] else 0,
                   **_eta(g["target"] - st["value"], value_pd), "money": True}
        else:
            row = {"have": st["unique"], "total": g["target"], "label": f"{st['unique']} of {g['target']} different cards",
                   "pct": round(100 * st["unique"] / g["target"], 1) if g["target"] else 0, **_eta(g["target"] - st["unique"], cards_pd)}
        row["pct"] = min(100.0, row["pct"])
        out.append({**g, **row})
    done = _done(svc)
    fresh = [g for g in out if g["pct"] >= 100 and g["id"] not in done]                    # finished since last time: celebrate once, and keep the badge
    if fresh:
        done.update({g["id"]: datetime.date.today().isoformat() for g in fresh})
        svc.pset(DONE, json.dumps(done))
    for g in out:
        g["doneOn"] = done.get(g["id"], "")
    return {"rows": out, "celebrate": [{"id": g["id"], "name": g["name"]} for g in fresh]}


@api("goals.options")
def goals_options(svc):
    return {"sets": [{"id": s["id"], "name": s["name"], "n": s["n"] or 0} for s in svc.vault.sets() if (s["n"] or 0) > 0]}


@api("goals.save", mutates=True)
def goals_save(svc, type, key="", target=0, name="", id=None):
    if type not in TYPES:
        raise ApiError("Choose what kind of goal.")
    if type == "set" and not key:
        raise ApiError("Pick a set.")
    if type == "name" and len(str(key).strip()) < 2:
        raise ApiError("Type the name to collect, like Charizard.")
    if type == "dex":
        a, b = _dex_range(key)
        if not (1 <= a <= b <= 1100):
            raise ApiError("Type a Pokédex range like 1-151.")
        key = f"{a}-{b}"
    if type in ("value", "cards"):
        try:
            target = float(target)
        except (TypeError, ValueError):
            raise ApiError("Type a number for the goal.")
        if target <= 0:
            raise ApiError("The goal has to be above zero.")
        target = int(target) if type == "cards" else round(target, 2)
    label = name or (next((s["name"] for s in svc.vault.sets() if s["id"] == key), key) if type == "set" else
                     f"every {str(key).strip()}" if type == "name" else f"Pokédex {key}" if type == "dex" else "")
    keep = [g for g in _all(svc) if g["id"] != id]
    keep.append({"id": id or new_uuid(), "game": svc.vault.game, "type": type, "key": str(key).strip() if type in ("set", "name", "dex") else "", "target": target if type in ("value", "cards") else 0,
                 "name": label or ("Reach a total value" if type == "value" else "Own different cards")})
    svc.pset(KEY, json.dumps(keep[-60:]))
    return {"ok": True}


@api("goals.delete", mutates=True)
def goals_delete(svc, id):
    from .undoext import undoable
    g = next((x for x in _all(svc) if x["id"] == id), None)
    return undoable(svc, f"Deleted goal '{g['name']}'" if g else "Deleted a goal", lambda: svc.pset(KEY, json.dumps([x for x in _all(svc) if x["id"] != id])), keys=[KEY])


# ---- badges: ones earned by finishing your own goals, and milestones worked out from your collection (nothing is stored for those)
MILESTONES = [("cards", 100, "100 different cards", "🥉"), ("cards", 500, "500 different cards", "🥈"), ("cards", 1000, "1,000 different cards", "🥇"), ("cards", 5000, "5,000 different cards", "🏆"),
              ("value", 100, "$100 collection", "💵"), ("value", 1000, "$1,000 collection", "💰"), ("value", 10000, "$10,000 collection", "💎"),
              ("sets", 1, "First set completed", "🎯"), ("sets", 5, "5 sets completed", "🌟"), ("graded", 1, "First graded card", "🔒"), ("graded", 10, "10 graded cards", "🛡️")]


@api("goals.badges")
def goals_badges(svc):
    v = svc.vault
    st = v.stats()
    sets_done = sum(1 for s in v.sets() if (s["n"] or 0) > 0 and v.owned_by_set().get(s["id"], 0) >= (s["n"] or 0))
    graded = v.conn.execute("SELECT COALESCE(SUM(qty),0) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND graded=1", (v.user_id, v.game)).fetchone()[0]
    have = {"cards": st["unique"], "value": st["value"], "sets": sets_done, "graded": graded}
    mile = [{"id": f"{k}{n}", "name": name, "icon": icon, "earned": have[k] >= n, "detail": f"{min(have[k], n):,.0f} of {n:,}" if k != "value" else f"${min(have[k], n):,.0f} of ${n:,}"} for k, n, name, icon in MILESTONES]
    goals = {g["id"]: g for g in _all(svc)}
    mine = [{"id": "goal" + gid, "name": goals[gid]["name"], "icon": "🎉", "earned": True, "detail": f"Goal completed {day}"} for gid, day in _done(svc).items() if gid in goals and goals[gid].get("game") == v.game]
    return {"milestones": mile, "goals": mine, "earned": sum(1 for m in mile if m["earned"]) + len(mine)}
