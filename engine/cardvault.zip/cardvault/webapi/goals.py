"""Collection goals: finish a set, reach a total value, or own a number of different cards - with progress and a rough 'at this pace' date worked out from how you added recently.
Kept as one account setting, so goals follow you to every device."""
import datetime
import json

from ..db import new_uuid
from .registry import ApiError, api

KEY = "collection_goals"
TYPES = ("set", "value", "cards")


def _all(svc):
    try:
        got = json.loads(svc.pget(KEY) or "[]")
    except ValueError:
        got = []
    return [g for g in got if isinstance(g, dict) and g.get("id")]


def _recent_pace(v, days=45):
    """(different cards added per day, value added per day) over the last `days` days, from what you actually added (each purchase's date)."""
    since = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
    n = v.conn.execute("SELECT COUNT(DISTINCT card_id) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(NULLIF(purchased,''), substr(added,1,10))>=?",
                       (v.user_id, v.game, since)).fetchone()[0]
    snaps = [s for s in v.snapshots() if s["day"] >= since and s.get("total_usd") is not None]
    vpd = 0.0
    if len(snaps) >= 2:
        span = (datetime.date.fromisoformat(snaps[-1]["day"]) - datetime.date.fromisoformat(snaps[0]["day"])).days
        vpd = (snaps[-1]["total_usd"] - snaps[0]["total_usd"]) / max(1, span)
    return n / days, vpd


def _eta(left, per_day):
    if left <= 0:
        return {"done": True}
    if per_day <= 0:
        return {"done": False, "days": None}
    days = int(left / per_day) + 1
    return {"done": False, "days": days, "date": (datetime.date.today() + datetime.timedelta(days=days)).isoformat()}


@api("goals.list")
def goals_list(svc):
    v = svc.vault
    st = v.stats()
    owned_set = v.owned_by_set()
    sets = {s["id"]: s for s in v.sets()}
    cards_pd, value_pd = _recent_pace(v)
    out = []
    for g in _all(svc):
        if g.get("game") != v.game:
            continue
        if g["type"] == "set":
            s = sets.get(g["key"])
            if not s:
                continue
            have, total = owned_set.get(s["id"], 0), s["n"] or 0
            row = {"have": have, "total": total, "label": f"{have} of {total} cards", "pct": round(100 * have / total, 1) if total else 0, **_eta(total - have, cards_pd)}
        elif g["type"] == "value":
            row = {"have": round(st["value"], 2), "total": g["target"], "label": None, "pct": round(100 * st["value"] / g["target"], 1) if g["target"] else 0,
                   **_eta(g["target"] - st["value"], value_pd), "money": True}
        else:
            row = {"have": st["unique"], "total": g["target"], "label": f"{st['unique']} of {g['target']} different cards",
                   "pct": round(100 * st["unique"] / g["target"], 1) if g["target"] else 0, **_eta(g["target"] - st["unique"], cards_pd)}
        row["pct"] = min(100.0, row["pct"])
        out.append({**g, **row})
    return {"rows": out}


@api("goals.options")
def goals_options(svc):
    return {"sets": [{"id": s["id"], "name": s["name"], "n": s["n"] or 0} for s in svc.vault.sets() if (s["n"] or 0) > 0]}


@api("goals.save", mutates=True)
def goals_save(svc, type, key="", target=0, name="", id=None):
    if type not in TYPES:
        raise ApiError("Choose what kind of goal.")
    if type == "set" and not key:
        raise ApiError("Pick a set.")
    if type in ("value", "cards"):
        try:
            target = float(target)
        except (TypeError, ValueError):
            raise ApiError("Type a number for the goal.")
        if target <= 0:
            raise ApiError("The goal has to be above zero.")
        target = int(target) if type == "cards" else round(target, 2)
    label = name or (next((s["name"] for s in svc.vault.sets() if s["id"] == key), key) if type == "set" else "")
    keep = [g for g in _all(svc) if g["id"] != id]
    keep.append({"id": id or new_uuid(), "game": svc.vault.game, "type": type, "key": key if type == "set" else "", "target": target if type != "set" else 0,
                 "name": label or ("Reach a total value" if type == "value" else "Own different cards")})
    svc.pset(KEY, json.dumps(keep[-60:]))
    return {"ok": True}


@api("goals.delete", mutates=True)
def goals_delete(svc, id):
    svc.pset(KEY, json.dumps([g for g in _all(svc) if g["id"] != id]))
    return {"ok": True}
