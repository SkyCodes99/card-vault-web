"""Checklist analytics: what a checklist (or several together) is worth, built from the cards the person actually picked for it.

A checklist slot is one card the person wants.  For a slot they own, the value is the owned card's price; for one they still need, it is the card they picked for
that slot, or the cheapest option when they have not picked one - so "cost to finish" is what finishing the list the cheapest honest way would cost."""
import datetime
import statistics

from .. import checklists, pricepick
from .cards import img
from .registry import api
from .service import ApiError
from .setanalytics import BUCKETS
from .lists import progress_of


def _row(svc, cid, owned, qty):
    c = svc.vault.card_light(cid)
    if not c:
        return None
    usd, kind = pricepick.shown(svc.vault, cid, c.get("price_usd"), c.get("price_kind"))         # the price Settings > Price sources picks (Standard: as before)
    return {"id": cid, "name": c["name"], "number": c["local_id"], "set": c.get("set_name") or "", "rarity": c.get("rarity") or "", "price": usd,
            "priceKind": kind, "qty": qty, "img": img(cid, c["set_id"]), "tcg": c.get("tcg_id") or "", "owned": owned}


def slot_rows(svc, progress):
    """One row per slot of a checklist: the card that counts for it, and whether it is owned."""
    v, out = svc.vault, []
    for t in progress.tiles:
        if t.card_id is None:
            continue
        price = lambda cid: pricepick.price_for(v, cid, (v.card_light(cid) or {}).get("price_usd"))
        if t.owned:
            have = [c for c in (t.owned_cards or [t.card_id])]
            cid = max(have, key=lambda c: price(c) or 0)                   # the owned copy that counts is the most valuable one
        elif t.candidates:
            priced = [c for c in t.candidates if price(c) is not None]
            cid = t.card_id if price(t.card_id) is not None else (min(priced, key=price) if priced else t.card_id)
        else:
            cid = t.card_id
        r = _row(svc, cid, bool(t.owned), t.qty)
        if r:
            r["slot"] = t.label
            out.append(r)
    return out


def _change(hist):
    change = {}
    if hist:
        latest = hist[-1]
        for label, d in (("day", 1), ("week", 7), ("month", 30)):
            cut = (datetime.date.fromisoformat(latest["day"]) - datetime.timedelta(days=d)).isoformat()
            older = [h for h in hist if h["day"] <= cut]
            if older and older[-1]["total"]:
                change[label] = {"from": older[-1]["day"], "usd": round(latest["total"] - older[-1]["total"], 2), "pct": round((latest["total"] / older[-1]["total"] - 1) * 100, 2)}
    return change


def _remember(v, key, total, owned, priced, n):
    day = datetime.date.today().isoformat()
    v.conn.execute("INSERT OR REPLACE INTO u.set_value_history VALUES(?,?,?,?,?,?,?)", (v.game, key, day, total, owned, priced, n))
    v._commit()
    return v.set_value_history(key)


def summarise(svc, rows, key=None):
    """The same numbers the set and series pages show, for any list of slot rows."""
    v = svc.vault
    priced = [r for r in rows if r["price"] is not None]
    total = sum(r["price"] for r in priced)
    mine = [r for r in rows if r["owned"]]
    owned_value = sum(r["price"] or 0 for r in mine)                    # a slot is filled by one card, however many copies you hold
    miss = [r for r in rows if not r["owned"]]
    miss_value = sum(r["price"] or 0 for r in miss)
    by = {}
    for r in rows:
        g = by.setdefault(r["rarity"] or "Unlabelled", {"rarity": r["rarity"] or "Unlabelled", "n": 0, "value": 0.0, "owned": 0, "ownedValue": 0.0, "unpriced": 0, "missing": 0, "missingValue": 0.0})
        g["n"] += 1
        g["value"] += r["price"] or 0
        g["unpriced"] += 1 if r["price"] is None else 0
        if r["owned"]:
            g["owned"] += 1
            g["ownedValue"] += r["price"] or 0
        else:
            g["missing"] += 1
            g["missingValue"] += r["price"] or 0
    prices = [r["price"] for r in priced]
    clean = lambda r: {k: r[k] for k in ("id", "name", "number", "set", "rarity", "price", "priceKind", "qty", "img", "tcg")}
    hist = _remember(v, key, round(total, 2), round(owned_value, 2), len(priced), len(rows)) if key and rows else []
    return {"cards": len(rows), "owned": len(mine), "leftOut": 0, "pct": round(100.0 * len(mine) / len(rows), 1) if rows else 0, "priced": len(priced), "unpriced": len(rows) - len(priced),
            "totalValue": round(total, 2), "ownedValue": round(owned_value, 2), "missingValue": round(miss_value, 2), "missingCount": len(miss),
            "avg": round(total / len(prices), 2) if prices else None, "median": round(statistics.median(prices), 2) if prices else None,
            "top": [clean(r) for r in sorted(priced, key=lambda r: -r["price"])[:10]], "topShare": round(100 * sum(r["price"] for r in sorted(priced, key=lambda r: -r["price"])[:10]) / total, 1) if total else 0,
            "chase": [clean(r) for r in sorted((r for r in miss if r["price"] is not None), key=lambda r: -r["price"])[:6]],
            "cheap": [clean(r) for r in sorted((r for r in miss if r["price"] is not None), key=lambda r: r["price"])[:12]],
            "rarities": [{**g, "value": round(g["value"], 2), "ownedValue": round(g["ownedValue"], 2), "missingValue": round(g["missingValue"], 2)} for g in sorted(by.values(), key=lambda g: -g["value"])][:25],
            "buckets": [{"label": lab, "n": sum(1 for p in prices if lo <= p < hi)} for lab, lo, hi in BUCKETS], "history": hist, "change": _change(hist)}


@api("lists.analytics")
def list_analytics(svc, id):
    cl, p = progress_of(svc, id)
    rows = slot_rows(svc, p)
    return {"id": id, "name": cl["name"], "mode": cl["mode"], "slots": p.total, **summarise(svc, rows, f"list:{id}")}


def combined_rows(svc, ids):
    """Every slot of several checklists together; a card that is on more than one list counts once."""
    seen, out = set(), []
    for i in ids:
        try:
            cl, p = progress_of(svc, i)
        except ApiError:
            continue
        for r in slot_rows(svc, p):
            if r["id"] in seen:
                continue
            seen.add(r["id"])
            out.append(r)
    return out


@api("lists.combinedAnalytics")
def lists_combined(svc, ids=None):
    """All of the chosen checklists as one (ids empty = every checklist)."""
    v = svc.vault
    ids = list(ids or [c["id"] for c in v.checklists()])
    rows = combined_rows(svc, ids)
    names = [c["name"] for c in v.checklists() if c["id"] in ids]
    key = "lists:" + ",".join(sorted(str(i) for i in ids))[:150]
    return {"name": f"{len(ids)} checklists together", "lists": names, **summarise(svc, rows, key)}
