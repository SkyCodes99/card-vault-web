"""A trade can mix ANY items: cards of the open game, cards of another game, toys, figures, plushies, accessories (each of those is a 'game' of its own in the app).

Each side of a trade is a list of items {card_id, game, qty, ...}; an item without a game belongs to the game that is open.  What is traded in the OTHER games is applied there (each its own undoable step), the
part in the open game and the trade log entry are saved in the open game as before, and the log keeps `parts` so the whole trade can be reverted later from any of its games."""
import contextlib
import os
import sqlite3

from .. import games, tools
from ..db import game_dir, picture_url
from .registry import api
from .service import ApiError

SEP = "|"                                              # an item of another game is named 'game|card id' on the screen (its card id alone could be a card of the open game)


def key_of(game, cid, home):
    return cid if not game or game == home else f"{game}{SEP}{cid}"


def split_key(k, home):
    k = str(k)
    if SEP in k:
        g, _, c = k.partition(SEP)
        if any(x.id == g for x in games.GAMES):
            return g, c
    return home, k


def _name(game_id):
    return next((g.name for g in games.GAMES if g.id == game_id), game_id)


def _path(svc, game_id):
    return os.path.join(game_dir(svc.cfg["data_dir"], game_id), "cards.db")


def row_of(svc, game_id, cid):
    """The trade picker's row for one item of any game, read straight from that game's card list (the open game is not switched)."""
    v = svc.vault
    if game_id == v.game:
        from .money import card_row
        return {**card_row(svc, cid), "game": game_id, "gameName": _name(game_id), "cid": cid}
    p = _path(svc, game_id)
    if not os.path.exists(p):
        return None
    try:
        c = sqlite3.connect("file:" + p.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
        c.row_factory = sqlite3.Row
        try:
            r = c.execute("SELECT c.id, c.name, c.local_id, c.image_base, c.price_usd, s.name AS sname FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id=?", (cid,)).fetchone()
        finally:
            c.close()
    except sqlite3.Error:
        return None
    if not r:
        return None
    from .search import _owned
    pic = (picture_url(r["image_base"], "low") if game_id.startswith("pokemon") else r["image_base"]) if r["image_base"] else ""
    return {"id": key_of(game_id, cid, v.game), "cid": cid, "game": game_id, "gameName": _name(game_id), "name": r["name"], "set": r["sname"] or "", "number": r["local_id"],
            "price": r["price_usd"], "img": pic, "qty": _owned(svc, game_id, [cid]).get(cid, 0)}


@api("trade.games", quiet=True)
def trade_games(svc):
    """The games a trade can take items from: every one with a card list on this device (the open game first)."""
    from .search import _games
    v = svc.vault
    have = _games(svc)
    out = [{"id": gid, "name": name, "family": getattr(games.game_by_id(gid), "family", "")} for gid, name, _p in have]
    out.sort(key=lambda g: (g["id"] != v.game, g["family"] == "collectibles", g["name"]))
    return out if len(out) > 1 else []


@api("trade.searchAny", quiet=True)
def trade_search_any(svc, text="", game="", owned_only=False):
    """Cards / items of any game (game = '' for all of them) for the trade picker."""
    from .search import search_query
    v = svc.vault
    text = (text or "").strip()
    if not text and not owned_only:
        return []
    r = search_query(svc, q=text, games=[game] if game else None, owned="yes" if owned_only else "", kinds=["cards"], limit=60)
    out = []
    for x in r.get("results", []):
        if x.get("type") == "sealed":
            continue
        out.append({"id": key_of(x["game"], x["id"], v.game), "cid": x["id"], "game": x["game"], "gameName": x.get("gameName") or _name(x["game"]), "name": x["name"], "set": x.get("set", ""),
                    "number": x.get("number", ""), "price": x.get("price"), "img": x.get("img", ""), "qty": x.get("owned", 0) or 0, "installed": x.get("installed", True)})
        if len(out) >= 60:
            break
    return out


@contextlib.contextmanager
def in_game(svc, game_id):
    """Work in another game for a moment, then come back to the one that was open."""
    home = svc.vault.game
    if game_id == home:
        yield
        return
    from . import gamesapi
    if not gamesapi.has_catalog(svc, game_id):
        raise ApiError(f"The {_name(game_id)} list isn't on this device yet - open that game once (Game menu) so it can be fetched, then trade.")
    svc.open_game(game_id)
    try:
        yield
    finally:
        svc.open_game(home)


def by_game(items, home):
    out = {}
    for i in items or []:
        out.setdefault(i.get("game") or home, []).append(i)
    return out


def is_cross(svc, give, get):
    home = svc.vault.game
    return any((i.get("game") or home) != home for i in [*(give or []), *(get or [])])


def home_items(svc, items):
    home = svc.vault.game
    return [i for i in items or [] if (i.get("game") or home) == home]


def apply_foreign(svc, give, get, lenient):
    """Everything in the trade that belongs to OTHER games: checked first (nothing is changed if you lack a card), then applied one game at a time.  -> ['game:action id', ...] for the undo."""
    home = svc.vault.game
    gives, gets = by_game(give, home), by_game(get, home)
    others = [g for g in dict.fromkeys([*gives, *gets]) if g != home]
    if not others:
        return []
    if not lenient:
        for g in others:
            if g in gives:
                with in_game(svc, g):
                    owned = svc.vault.owned_map()
                    short = [i.get("name") or i["card_id"] for i in gives[g] if owned.get(i["card_id"], 0) < i["qty"]]
                if short:
                    raise ApiError(f"You don't own enough copies of: {', '.join(short[:6])} ({_name(g)}).")
    parts = []
    for g in others:
        with in_game(svc, g):
            try:
                act = tools.apply_trade(svc.vault, gives.get(g, []), gets.get(g, []), f"Trade ({_name(g)}): {sum(i['qty'] for i in gives.get(g, []))} out, {sum(i['qty'] for i in gets.get(g, []))} in", None, lenient=bool(lenient))
            except ValueError as e:
                raise ApiError(str(e))
            if act.id:
                parts.append(f"{g}:{act.id}")
    return parts


def undo_token(home, home_act, parts):
    """One 'Undo' for a trade that touched several games: 'x:' + game:action id pairs."""
    if not parts:
        return home_act
    return "x:" + ";".join(([f"{home}:{home_act}"] if home_act else []) + parts)


def undo_multi(svc, token):
    n = 0
    home = svc.vault.game
    for pair in str(token)[2:].split(";"):
        g, _, aid = pair.rpartition(":")
        if not g or not aid.isdigit():
            continue
        with in_game(svc, g):
            n += svc.vault.undo_action(int(aid))
    svc.reload_state()
    return {"ok": True, "reversed": n, "game": home}


def revert_foreign(svc, give, get):
    """Reverse the other games' share of a logged trade: what was received there goes back out, what was given comes back."""
    import datetime
    home = svc.vault.game
    gives, gets = by_game(give, home), by_game(get, home)
    others = [g for g in dict.fromkeys([*gives, *gets]) if g != home]
    for g in others:                                                     # check first: nothing changes if a received card is gone
        if g in gets:
            with in_game(svc, g):
                owned = svc.vault.owned_map()
                short = [i.get("name") or i["card_id"] for i in gets[g] if owned.get(i["card_id"], 0) < i["qty"]]
            if short:
                raise ApiError("Can't revert: you no longer have all the cards you received (" + ", ".join(short[:5]) + f" in {_name(g)}). Put them back first, or just delete the log entry.")
    for g in others:
        with in_game(svc, g):
            v = svc.vault
            with v.action("Reverted trade (" + _name(g) + ")"):
                for i in gets.get(g, []):
                    left = i["qty"]
                    for lot in sorted(v.lots_for(i["card_id"]), key=lambda l: (l["source"] or "") != "Trade"):
                        take = min(left, lot["qty"])
                        if take:
                            v.change_lot_qty(lot["id"], -take)
                            left -= take
                        if not left:
                            break
                for i in gives.get(g, []):
                    v.add_lot(i["card_id"], v.default_variant(i["card_id"]), "Near Mint", i["qty"], price=i.get("unit"), purchased=datetime.date.today().isoformat(), source="Trade reverted")
                v.record_price_history([i["card_id"] for i in gives.get(g, [])])
