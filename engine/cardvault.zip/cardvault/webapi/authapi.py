"""Sign-in, accounts and security settings."""
import os

from .. import runtime
from ..security import crypto
from ..security.profiles import AuthError
from .registry import ApiError, api


def _err(e):
    return ApiError(str(e), code=e.code, retry_after=getattr(e, "retry_after", 0))


def state(svc):
    if svc.unlocked:
        return "unlocked"
    return "locked" if svc.auth.has_profiles() else "setup"


@api("auth.status", public=True, quiet=True)
def status(svc):
    cur = None
    if svc.session is not None:
        cur = {"id": svc.session.pid, "name": svc.session.name}
    return {"state": state(svc), "profiles": svc.auth.profiles(), "current": cur, "legacy": svc.auth.legacy_collection() and not svc.auth.has_profiles(),
            "theme": svc.cfg.get("theme", "system"), "themePack": svc.cfg.get("theme_pack", "classic"), "insecure": svc.insecure,
            "autolockMinutes": svc.pget("autolock_minutes", 15) if svc.unlocked else 15}


@api("auth.create", public=True)
def create(svc, name, password, adopt=False):
    if svc.session is not None:
        raise ApiError("Sign out first to create another account.")
    try:
        extra = [svc.cfg.get("backup_dir")]
        sess, recovery = svc.auth.create(name, password, adopt_legacy=bool(adopt), extra_dirs=extra)
    except AuthError as e:
        raise _err(e)
    adopted = getattr(sess, "adopted", None)
    svc.start_session(sess)
    return {"ok": True, "recoveryKey": recovery, "adopted": adopted}


@api("auth.login", public=True)
def login(svc, id, password):
    if svc.session is not None:
        raise ApiError("Already signed in.")
    try:
        sess = svc.auth.unlock(id, password)
    except AuthError as e:
        raise _err(e)
    except crypto.CryptoError as e:
        raise ApiError(f"Your data could not be opened: {e}", code="damaged")
    svc.start_session(sess)
    return {"ok": True}


@api("auth.deviceKey")
def device_key(svc):
    """For 'Stay signed in': the key this device may keep (the browser wraps it with a key that never leaves it).  Only while signed in."""
    if svc.session is None:
        raise ApiError("Sign in first.", code="locked")
    key = svc.auth.device_key(svc.session)
    svc.pset("autolock_minutes", 0)                   # staying signed in means the app is not locked under you
    svc.audit("stay_signed_in_on")
    return {"id": svc.session.pid, "key": crypto.b64(key)}


@api("auth.forgetDevice")
def forget_device(svc):
    """'Sign out of this device': the kept key is deleted by the caller; the automatic lock comes back."""
    if svc.session is not None:
        svc.pset("autolock_minutes", 15)
        svc.audit("stay_signed_in_off")
    return {"ok": True}


@api("auth.stayStatus", public=True, quiet=True)
def stay_status(svc):
    """The Windows app's 'Stay signed in' (the website keeps its own in the browser)."""
    from ..security import devicekey
    on = bool(svc.session is not None and os.path.exists(devicekey.path_for(svc.cfg["data_dir"], svc.session.pid)))
    return {"supported": devicekey.supported() and not runtime.IN_BROWSER, "on": on}


@api("auth.stay")
def stay(svc, on):
    """Turn 'Stay signed in' on or off for this Windows app."""
    from ..security import devicekey
    if not devicekey.supported() or runtime.IN_BROWSER or svc.session is None:
        raise ApiError("Stay signed in isn't available here.")
    path = devicekey.path_for(svc.cfg["data_dir"], svc.session.pid)
    if on:
        key = svc.auth.device_key(svc.session)
        tmp = path + ".part"
        with open(tmp, "wb") as f:
            f.write(devicekey.protect(key))
        os.replace(tmp, path)
        svc.pset("autolock_minutes", 0)
        svc.audit("stay_signed_in_on")
    else:
        try:
            os.remove(path)
        except OSError:
            pass
        svc.pset("autolock_minutes", 15)
        svc.audit("stay_signed_in_off")
    return {"on": bool(on)}


@api("auth.resume", public=True)
def resume(svc, id, key):
    """Sign in again with the key a device kept (no password)."""
    if svc.session is not None:
        raise ApiError("Already signed in.")
    try:
        sess = svc.auth.resume(id, crypto.unb64(key))
    except AuthError as e:
        raise _err(e)
    svc.start_session(sess)
    return {"ok": True}


@api("auth.recover", public=True)
def recover(svc, id, recoveryKey, newPassword):
    if svc.session is not None:
        raise ApiError("Already signed in.")
    try:
        sess, key = svc.auth.recover(id, recoveryKey, newPassword)
    except AuthError as e:
        raise _err(e)
    svc.start_session(sess)
    return {"ok": True, "recoveryKey": key}


@api("auth.logout")
def logout(svc):
    from ..security import devicekey
    if svc.session is not None:                       # pressing Lock / Sign out ends "Stay signed in" on this device
        try:
            os.remove(devicekey.path_for(svc.cfg["data_dir"], svc.session.pid))
        except OSError:
            pass
    svc.lock("signed out")
    return {"ok": True}


@api("auth.changePassword")
def change_password(svc, old, new):
    try:
        svc.session.change_password(old, new)
    except AuthError as e:
        raise _err(e)
    return {"ok": True}


@api("auth.newRecoveryKey")
def new_recovery(svc, password):
    try:
        return {"recoveryKey": svc.session.new_recovery_key(password)}
    except AuthError as e:
        raise _err(e)


@api("auth.setAutolock", mutates=False)
def set_autolock(svc, minutes):
    minutes = max(0, min(int(minutes), 24 * 60))
    svc.pset("autolock_minutes", minutes)
    return {"ok": True, "minutes": minutes}


@api("auth.deleteProfile", public=True)
def delete_profile(svc, id, password):
    mine = svc.session is not None and svc.session.pid == id
    try:
        svc.auth.verify_password(id, password, count=True)
    except AuthError as e:
        raise _err(e)
    if mine:
        svc.lock("account deleted")
    try:
        svc.auth.delete(id, password)
    except AuthError as e:
        raise _err(e)
    return {"ok": True}


@api("auth.log")
def security_log(svc):
    return svc.session.security_log()[:100]


@api("auth.checkPassword", public=True, quiet=True)
def check_password(svc, password, name=""):
    return {"problems": crypto.check_password(password, name)}


@api("auth.ping")
def ping(svc):
    """The screens call this while you are really using the app, so the auto-lock only fires when nothing is happening."""
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ optional: reset by emailed code
from ..security import emailreset  # noqa: E402

_PENDING = {}          # in memory only: {key: {"pending": id, "email": ..}}


def _service(svc, rec=None):
    return (rec or {}).get("service") or svc.cfg.get("service_url") or ""


def _wrap_err(e):
    return ApiError(str(e), code=getattr(e, "code", None))


@api("auth.emailStatus")
def email_status(svc):
    info = svc.auth.email_reset_info(svc.session.pid)
    return {"enabled": info["enabled"], "emailHint": emailreset.mask(info["email"]), "service": info["service"] or svc.cfg.get("service_url", ""),
            "configured": bool(svc.cfg.get("service_url") or info["service"])}


@api("auth.setService")
def set_service(svc, url):
    try:
        svc.cfg["service_url"] = emailreset.check_url(url) if url else ""
    except emailreset.ResetError as e:
        raise _wrap_err(e)
    svc.save()
    return {"ok": True}


@api("auth.emailEnrollStart")
def email_enroll_start(svc, email):
    url = _service(svc)
    if not url:
        raise ApiError("Enter the account service address first.", code="no_service")
    try:
        r = emailreset.post(url, "/v1/enroll/start", {"email": email})
    except emailreset.ResetError as e:
        raise _wrap_err(e)
    _PENDING[svc.session.pid] = {"pending": r["pending"], "email": email.strip().lower(), "service": emailreset.check_url(url)}
    return {"sent": True, "emailHint": emailreset.mask(email.strip().lower())}


@api("auth.emailEnrollConfirm")
def email_enroll_confirm(svc, code):
    p = _PENDING.get(svc.session.pid)
    if not p:
        raise ApiError("Ask for a code first.", code="no_pending")
    escrow, secret = crypto.random_bytes(32), crypto.random_bytes(32)
    try:
        r = emailreset.post(p["service"], "/v1/enroll/confirm", {"pending": p["pending"], "email": p["email"], "code": code,
                                                                  "escrow_key": emailreset.b64(escrow), "account_secret": emailreset.b64(secret)})
    except emailreset.ResetError as e:
        raise _wrap_err(e)
    svc.session.set("email_secret", emailreset.b64(secret))
    svc.auth.enable_email_reset(svc.session, p["email"], p["service"], r["account"], escrow)
    _PENDING.pop(svc.session.pid, None)
    return {"ok": True, "emailHint": emailreset.mask(p["email"])}


@api("auth.emailDisable")
def email_disable(svc, password):
    try:
        svc.auth.verify_password(svc.session.pid, password, count=True)
    except AuthError as e:
        raise _err(e)
    info = svc.auth.email_reset_info(svc.session.pid)
    try:
        if info["enabled"] and info["account"]:
            emailreset.post(info["service"], "/v1/disable", {"account": info["account"], "account_secret": svc.session.get("email_secret") or ""})
    except emailreset.ResetError:
        pass                                    # offline: still turn it off here; the service copy is useless without the local half
    svc.auth.disable_email_reset(svc.session)
    return {"ok": True}


@api("auth.emailResetStart", public=True)
def email_reset_start(svc, id):
    info = svc.auth.email_reset_info(id)
    if not info["enabled"]:
        raise ApiError("Email reset isn't turned on for this account. Use your recovery key instead.", code="no_email_reset")
    try:
        r = emailreset.post(info["service"], "/v1/reset/start", {"email": info["email"]})
    except emailreset.ResetError as e:
        raise _wrap_err(e)
    _PENDING["reset:" + id] = {"pending": r["pending"], "email": info["email"], "service": info["service"]}
    return {"sent": True, "emailHint": emailreset.mask(info["email"])}


@api("auth.emailResetFinish", public=True)
def email_reset_finish(svc, id, code, newPassword):
    if svc.session is not None:
        raise ApiError("Already signed in.")
    p = _PENDING.get("reset:" + id)
    if not p:
        raise ApiError("Ask for a code first.", code="no_pending")
    try:
        r = emailreset.post(p["service"], "/v1/reset/verify", {"pending": p["pending"], "email": p["email"], "code": code})
        sess, key = svc.auth.reset_with_escrow(id, emailreset.unb64(r["escrow_key"]), newPassword)
    except emailreset.ResetError as e:
        raise _wrap_err(e)
    except AuthError as e:
        raise _err(e)
    _PENDING.pop("reset:" + id, None)
    svc.start_session(sess)
    return {"ok": True, "recoveryKey": key}
