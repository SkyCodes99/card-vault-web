"""PICK UP WHERE YOU LEFT OFF: one small synced record per account - "where I was" (page, game, that game's filters, the item open) - so another device can offer to carry on there.

- Written by the screens through the outbox (ui/src/here.js, debounced, only when it changes); stored once per account (u.settings, game '*', key 'here') and sent with the
  snapshot of the game it is in (cloud/snapshot.py, cloud/syncmarks.py).  The newest record wins everywhere: an old one - a change replayed late from the outbox, or another
  device's older copy - never replaces a newer one.
- Only what is needed to go there: no token, email, password or anything typed that looks like one (a filter text that does is simply left out).
- Saving it is not a change to the collection: open screens are not refreshed (mutates="quiet"), but the sync sends it a moment later.
"""
import datetime
import json
import re
import time

from ..cloud import engine
from .registry import api

PAGES = ("cards", "sealed", "search", "inventory", "lists", "wishlist", "value", "trade", "organize", "friends", "share", "showcase", "scanner", "games")
KINDS = ("website", "desktop", "phone", "tablet")
EMAIL = re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+")
SECRET = re.compile(r"token|secret|password|passwd|bearer|apikey|api_key|sync ?key|recovery", re.I)
MAX_TEXT, MAX_FILTERS = 200, 4000


def _text(v, n=MAX_TEXT):
    return v if isinstance(v, str) and len(v) <= n and not EMAIL.search(v) and not SECRET.search(v) else ""


def _value(v, depth=0):
    """A filter value: short text, a number, true/false, or a short list / map of those.  Anything else (or text that looks like an email or a secret) is dropped (None)."""
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v if v == v and abs(v) < 1e12 else None
    if isinstance(v, str):
        return v if _text(v) == v else None
    if depth >= 3:
        return None
    if isinstance(v, list):
        out = [x for x in (_value(x, depth + 1) for x in v[:50]) if x is not None]
        return out
    if isinstance(v, dict):
        out = {}
        for k, x in list(v.items())[:40]:
            if isinstance(k, str) and len(k) <= 60 and not SECRET.search(k) and not EMAIL.search(k):
                y = _value(x, depth + 1)
                if y is not None:
                    out[k] = y
        return out
    return None


def clean(route="", game="", gameName="", filters=None, item=None, kind=""):  # noqa: N803 - the page's names
    """The record's fields, checked (the page sends them; nothing else is kept)."""
    f = _value(filters if isinstance(filters, dict) else {}) or {}
    if len(json.dumps(f)) > MAX_FILTERS:
        f = {}
    it = item if (isinstance(item, str) and 0 < len(item) <= 80 and _text(item) == item) or (isinstance(item, int) and not isinstance(item, bool)) else None
    return {"route": route if route in PAGES else "cards", "game": _text(game, 60), "gameName": _text(gameName, 80), "filters": f, "item": it,
            "kind": kind if kind in KINDS else "website"}


def _stamp(ms):
    return datetime.datetime.fromtimestamp(ms / 1000, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


@api("here.get")
def here_get(svc):
    """-> {here: the account's newest "where I was" (or null), me: this device's id (so the page can tell its own record from another device's)}."""
    h = svc.vault.here_get() if svc.vault is not None else {}
    return {"here": h or None, "me": engine.device_id(svc.cfg)}


@api("here.set", mutates="quiet")
def here_set(svc, route="", game="", gameName="", filters=None, item=None, kind="", at=0):  # noqa: N803
    """Remember where this device is.  `at`: when the page noted it (ms) - a change sent late (offline, replayed) keeps its own time, so it never wins over a newer record."""
    now = time.time() * 1000
    try:
        at = float(at or 0)
    except (TypeError, ValueError):
        at = 0
    at = min(at, now + 60000) if at > 0 else now                         # (a clock a little ahead is fine; far ahead is not believed)
    rec = {**clean(route, game, gameName, filters, item, kind), "device": engine.device_id(svc.cfg), "updated_at": _stamp(at)}
    cur = svc.vault.here_get()
    if cur and (cur.get("updated_at") or "") >= rec["updated_at"]:
        return {"ok": True, "kept": "newer"}                             # a newer record is already here (from this device or another): the old one is not kept
    same = cur and {k: v for k, v in cur.items() if k != "updated_at"} == {k: v for k, v in rec.items() if k != "updated_at"}
    if same:
        return {"ok": True, "kept": "same"}                              # nothing moved: nothing to send
    svc.vault.here_set(rec)
    if svc.last_change <= getattr(svc, "_synced_upto", 0.0):             # let the sync send it (like a change, but no screen needs to refresh for it)
        svc._unsent_since = time.time()
    svc.last_change = time.time()
    return {"ok": True}
