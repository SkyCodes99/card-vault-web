"""Video games (physical), for the item panel: the SAME game on other platforms and the OTHER games of its series.  Read from the list itself (raw `game`, `series` written by cardvault/videogames.py); no other list has either."""
import json
import re

SERIES_SHOWN = 24


def _raw(row):
    try:
        return json.loads(row["raw"] or "{}")
    except ValueError:
        return {}


def _when(raw):
    ext = raw.get("ext") or {}
    m = re.search(r"\d{4}", str(ext.get("Release date") or ext.get("First released (the game, platform not stated)") or ""))
    return m.group() if m else "9999"


def versions_of(conn, card_id, raw, img):
    """[{id, name, platform, img, here}] of every release of the game the item is one of (itself included), in platform order; [] when it has only one release.  `img(id, set_id)` gives a picture address."""
    game = raw.get("game")
    if not game:
        return []
    rows = conn.execute("SELECT c.id, c.name, c.set_id, c.raw, s.name AS set_name FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE json_extract(c.raw,'$.game')=? ORDER BY s.name, c.id", (game,)).fetchall()
    if len(rows) < 2:
        return []
    return [{"id": r["id"], "name": r["name"], "platform": r["set_name"] or "", "img": img(r["id"], r["set_id"]), "here": r["id"] == card_id} for r in rows]


def series_of(conn, card_id, raw, img):
    """{names, total, games: [{id, name, platform, img, year}]}: the other games of the item's series (one entry per game, on the item's own platform when it has one there), oldest first; None when it has no series."""
    series = raw.get("series") or []
    game = raw.get("game")
    if not series or not game:
        return None
    mark = ",".join("?" * len(series))
    rows = conn.execute("SELECT DISTINCT c.id, c.name, c.set_id, c.raw, s.name AS set_name FROM cards c LEFT JOIN sets s ON s.id=c.set_id, json_each(c.raw,'$.series') j "
                        "WHERE j.value IN (%s) ORDER BY c.id" % mark, series).fetchall()
    here = raw.get("platform")
    best = {}
    for r in rows:
        rr = _raw(r)
        g = rr.get("game")
        if not g or g == game:
            continue
        if g not in best or (rr.get("platform") == here and _raw(best[g]).get("platform") != here):
            best[g] = r
    ordered = sorted(best.values(), key=lambda r: (_when(_raw(r)), r["name"].casefold()))
    if not ordered:
        return None
    return {"names": str((raw.get("ext") or {}).get("Series") or ""), "total": len(ordered), "games": [{"id": r["id"], "name": r["name"], "platform": r["set_name"] or "", "img": img(r["id"], r["set_id"]), "year": _when(_raw(r)) if _when(_raw(r)) != "9999" else ""}
                                             for r in ordered[:SERIES_SHOWN]]}
