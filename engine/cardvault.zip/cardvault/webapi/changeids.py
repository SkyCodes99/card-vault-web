"""Every change a screen sends carries its own id ('_op'), made on the device the moment the change was made (see ui/src/outbox.js).

The page keeps each change in its outbox until it is safely saved, and sends it again after a lost answer, a closed tab or a restart.  So the engine remembers the ids it has
already applied (with the answer it gave) and answers a repeat with that same answer instead of doing it twice: a card is never added twice by a retry.
The ids live in the person's own collection file, next to the change itself, so "applied" and "remembered" are saved together."""
import json
import time

KEEP_SEC = 60 * 86400                 # long after any outbox would have given up
_SQL = "CREATE TABLE IF NOT EXISTS u.applied_ops(op TEXT PRIMARY KEY, method TEXT, at REAL, result TEXT)"
_since_prune = [0]


def take(args):
    """-> (args without the id, the id or None)."""
    if not args or "_op" not in args:
        return args, None
    args = dict(args)
    op = str(args.pop("_op") or "")[:64]
    return args, op or None


def _conn(svc):
    v = getattr(svc, "vault", None)
    conn = getattr(v, "conn", None)
    if conn is None:
        return None
    conn.execute(_SQL)                # (a no-op once the table is there)
    return conn


def wrap(fn, op, name):
    """fn(svc, **args) that runs at most once per id.  It runs where fn runs (the worker thread that owns the connection)."""
    def once(svc, **args):
        try:
            conn = _conn(svc)
        except Exception:  # noqa: BLE001 - no collection open (a guest, a locked app): nothing to remember against
            conn = None
        if conn is not None:
            r = conn.execute("SELECT result FROM u.applied_ops WHERE op=?", (op,)).fetchone()
            if r is not None:
                try:
                    return json.loads(r[0]) if r[0] else {"ok": True, "replayed": True}
                except ValueError:
                    return {"ok": True, "replayed": True}
        val = fn(svc, **args)
        if conn is not None:
            try:
                text = json.dumps(val, default=str)
            except (TypeError, ValueError):
                text = ""
            conn.execute("INSERT OR REPLACE INTO u.applied_ops VALUES(?,?,?,?)", (op, name, time.time(), text if len(text) <= 8000 else ""))
            _since_prune[0] += 1
            if _since_prune[0] >= 200:
                _since_prune[0] = 0
                conn.execute("DELETE FROM u.applied_ops WHERE at<?", (time.time() - KEEP_SEC,))
            conn.commit()
        return val
    return once
