"""Owner tools: check this game's card list against TCGplayer (tcgcsv.com), apply what it finds, and keep the picture-link sources.  Desktop app + owner account only -
the card lists are published from the owner's computer; everybody else receives them through Card Data."""
import json
import os
import sqlite3

from .. import db, runtime, tcgsync
from .registry import ApiError, api

LAST = {}                                  # game id -> the last result (kept in memory; the report file on disk is the durable copy)
SAMPLE = 60                                # how many lines of each list the screen receives


def _require(svc):
    if runtime.IN_BROWSER:
        raise ApiError("The card-list tools run in the desktop app on the owner's computer.")
    if not svc.pget("cloud_admin"):
        raise ApiError("These tools are for the owner's account.")


def sources_path(svc):
    return os.path.join(svc.cfg["data_dir"], "tcgsync", "image_sources.json")


def load_sources(svc):
    p = sources_path(svc)
    if not os.path.exists(p):
        return {}
    try:
        return json.load(open(p, encoding="utf-8"))
    except ValueError:
        return {}


def _open(svc, game):
    path = os.path.join(db.game_dir(svc.cfg["data_dir"], game), "cards.db")
    conn = sqlite3.connect(path)
    cols = {r[1] for r in conn.execute("PRAGMA table_info(cards)")}
    for col in ("price_kind", "tcg_id"):
        if col not in cols:
            conn.execute(f"ALTER TABLE cards ADD COLUMN {col} TEXT")
    return conn


def _trim(rep):
    out = {k: v for k, v in rep.items() if k not in ("marks",)}
    counts = {k: len(rep[k]) for k in ("newSets", "newCards", "changedCards", "newSealed", "changedSealed", "linked", "variants")}
    for k in counts:
        out[k] = rep[k][:SAMPLE]
    out["counts"] = counts
    return out


@api("tcgsync.start")
def start(svc, apply=False, deep=False, addNewSets=False, addMissingCards=False, images=True):
    """Check the open game against TCGplayer (and, with apply, write what was found and the picture links).  Runs as a background job."""
    _require(svc)
    game = svc.game.id
    if game not in tcgsync.CATS:
        raise ApiError("This game isn't on TCGplayer's list.")

    def run(emit, cancel):
        conn = _open(svc, game)
        try:
            emit("Reading TCGplayer's list of sets…", 0, 0)
            rep = tcgsync.check_game(game, conn, fetch=tcgsync.fetch_get, deep=deep, progress=lambda d, t: emit("Comparing sets…", d, t))
            result = {"game": game, "report": _trim(rep), "applied": None, "images": None, "wrote": bool(apply)}
            if apply and not rep["errors"]:
                emit("Writing the changes…", 0, 0)
                result["applied"] = tcgsync.apply_report(game, conn, rep, fetch=tcgsync.fetch_get, add_new_sets=addNewSets, add_missing_cards=addMissingCards)
            cfg = load_sources(svc) if images else {}
            if cfg and not tcgsync.validate_sources(cfg):
                plan = tcgsync.plan_images(game, conn, cfg)
                result["images"] = {"planned": len(plan), "applied": 0, "rejected": []}
                if apply and plan:
                    emit("Checking and applying picture links…", 0, len(plan))
                    res = tcgsync.apply_images(conn, plan)
                    result["images"].update(applied=res["applied"], rejected=res["rejected"][:20])
            return result
        finally:
            conn.close()

    def done(job):
        if job.state == "done":
            LAST[game] = job.result
            if job.result.get("wrote"):
                v = svc.vault
                v.invalidate_index()
                v._img_bases = None
                v._sealed_stamp = getattr(v, "_sealed_stamp", 0) + 1
                svc.reload_state()
    j = svc.jobs.start("tcgsync", "Checking TCGplayer's list", run, on_done=done)
    return {"job": j.id}


@api("tcgsync.last", quiet=True)
def last(svc):
    _require(svc)
    game = svc.game.id
    return {"game": game, "result": LAST.get(game), "lastRun": (svc.vault.meta("tcgsync_last") if hasattr(svc.vault, "meta") else None), "onTcg": game in tcgsync.CATS}


@api("tcgsync.sources")
def sources(svc):
    _require(svc)
    p = sources_path(svc)
    text = open(p, encoding="utf-8").read() if os.path.exists(p) else '{\n  "version": 1,\n  "sources": [],\n  "overrides": {}\n}\n'
    return {"text": text, "path": p, "help": tcgsync.IMAGE_SOURCES}


@api("tcgsync.saveSources")
def save_sources(svc, text):
    _require(svc)
    try:
        cfg = json.loads(text)
    except ValueError as e:
        raise ApiError(f"That isn't valid JSON: {e}")
    problems = tcgsync.validate_sources(cfg)
    if problems:
        return {"saved": False, "problems": problems}
    p = sources_path(svc)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8").write(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")
    return {"saved": True, "problems": []}
