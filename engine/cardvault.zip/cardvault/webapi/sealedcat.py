"""The sealed-products list: browse every box, pack and bundle TCGplayer sells for the chosen game, with its price."""
import re

from .registry import api
from ..tcgcsv import norm_name


@api("sealed.catalog")
def catalog(svc, q="", set_id="", limit=60, offset=0):
    v = svc.vault
    where, args = [], []
    for w in norm_name(q).split():
        where.append("norm LIKE ?")
        args.append(f"%{w}%")
    if set_id:
        where.append("set_id=?")
        args.append(set_id)
    cond = ("WHERE " + " AND ".join(where)) if where else ""
    try:
        total = v.conn.execute(f"SELECT COUNT(*) FROM sealed_products {cond}", args).fetchone()[0]
        rows = v.conn.execute(f"SELECT id,set_id,set_name,name,image_base,price_usd,price_kind FROM sealed_products {cond} "
                              "ORDER BY (price_usd IS NULL), set_name DESC, name LIMIT ? OFFSET ?", args + [int(limit), int(offset)]).fetchall()
        sets = [{"id": r[0], "name": r[1]} for r in v.conn.execute("SELECT set_id, set_name FROM sealed_products GROUP BY set_id ORDER BY set_name")]
    except Exception:  # noqa: BLE001 - this game has no sealed list yet
        return {"total": 0, "items": [], "sets": [], "available": False}
    return {"available": True, "total": total, "sets": sets,
            "items": [{"id": r[0], "setId": r[1], "set": r[2] or "", "name": r[3], "img": (r[4] or "").replace("_200w", "_400w"), "price": r[5], "priceKind": r[6] or ""} for r in rows]}


def price_for(v, name):
    """The list price for a product the person typed in by name (matched on letters and digits), or None."""
    try:
        r = v.conn.execute("SELECT price_usd, price_kind FROM sealed_products WHERE norm=? AND price_usd IS NOT NULL ORDER BY price_updated DESC LIMIT 1", (norm_name(name),)).fetchone()
    except Exception:  # noqa: BLE001
        return None
    return {"price": r[0], "kind": r[1] or ""} if r else None
