"""The sealed-products list: browse every box, pack, tin and blister TCGplayer sells for the chosen game, by series and by product type, with its price."""
from .. import sealedclass
from ..tcgcsv import norm_name
from .registry import api

# kinds that are not really "sealed products" are hidden unless you ask for them
LOOSE_KINDS = {"Code card", "Loose card / energy"}
HIDDEN_BY_DEFAULT = LOOSE_KINDS | {sealedclass.CASE_KIND}          # code cards, loose cards, and cases / displays: out of the way until asked for
_ERA_ORDER = [label for _, label in reversed(sealedclass.ERAS)] + ["Promos & specials", "POP Series", "Trainer Kits", "World Championship Decks", "McDonald's", sealedclass.MISC]


def _all(svc):
    """Every sealed product of the open game, with its kind and series (read from the card list; worked out here for older lists that don't have them yet).  Cached per card list."""
    v = svc.vault
    key = (v.game, getattr(v, "_sealed_stamp", 0))
    c = getattr(v, "_sealed_cache", None)
    if c and c[0] == key:
        return c[1]
    try:
        raw = v.conn.execute("SELECT id,set_id,set_name,name,norm,image_base,price_usd,price_kind,released,kind,serie,multi FROM sealed_products").fetchall()
        sets = {r[0]: (r[1] or "") for r in v.conn.execute("SELECT id, serie FROM sets")}
        set_names = {r[0]: (r[1] or "") for r in v.conn.execute("SELECT name, release_date FROM sets") if r[0] and len(r[0]) >= 6}
    except Exception:  # noqa: BLE001 - this game has no sealed list yet
        return None
    out = []
    for r in raw:
        kind = r["kind"] or sealedclass.kind_of(r["name"], v.game)
        serie = r["serie"]
        if not serie:
            serie = sealedclass.serie_of(v.game, r["set_name"], r["released"] or "", r["name"], set_names if v.game == "pokemon" else None)
        out.append({"id": r["id"], "setId": r["set_id"], "set": r["set_name"] or "", "name": r["name"], "norm": r["norm"] or "", "img": (r["image_base"] or "").replace("_200w", "_400w"),
                    "price": r["price_usd"], "priceKind": r["price_kind"] or "", "kind": kind, "serie": serie or "Other products",
                    "multi": bool(r["multi"]) if r["multi"] is not None else (sealedclass.is_multi(r["name"]))})
    v._sealed_cache = (key, out)
    return out


def _series_order(game, names, counts):
    if game == "pokemon":
        return sorted(names, key=lambda n: _ERA_ORDER.index(n) if n in _ERA_ORDER else 99)
    return sorted(names, key=lambda n: -counts[n])


@api("sealed.catalog")
def catalog(svc, q="", set_id="", limit=60, offset=0, group="", kinds=None, loose=False, multi=False):
    """Browse the sealed list.  group = a series (an era for Pokemon); kinds = product types to show (none chosen = every real product); loose = also show code cards and loose single cards; multi = also show cases, displays and other multi-item products (hidden by default so single items are easy to see)."""
    rows = _all(svc)
    if rows is None:
        return {"total": 0, "items": [], "sets": [], "groups": [], "kinds": [], "available": False}
    words = norm_name(q).split()
    base = [r for r in rows if all(w in r["norm"] for w in words)] if words else rows
    if set_id:
        base = [r for r in base if r["setId"] == set_id]
    # facets: the series counts ignore the series choice itself, the type counts ignore the type choice
    kinds = [k for k in (kinds or []) if k in sealedclass.KINDS]
    shown = set(kinds) | (LOOSE_KINDS if loose else set()) | ({sealedclass.CASE_KIND} if multi else set())
    visible = lambda r: r["kind"] not in HIDDEN_BY_DEFAULT or r["kind"] in shown
    kind_ok = lambda r: (r["kind"] in kinds) if kinds else visible(r)
    group_ok = lambda r: (not group) or r["serie"] == group
    gcount, kcount = {}, {}
    for r in base:
        if kind_ok(r):
            gcount[r["serie"]] = gcount.get(r["serie"], 0) + 1
        if group_ok(r) and (visible(r) or r["kind"] in kinds):
            kcount[r["kind"]] = kcount.get(r["kind"], 0) + 1
    hits = [r for r in base if kind_ok(r) and group_ok(r)]
    hits.sort(key=lambda r: (r["price"] is None, r["set"] != "" and 0, r["set"], r["name"]))
    game = svc.vault.game
    from .listsealed import _owned
    have = _owned(svc)                                                   # how many of each the portfolios being looked at hold (for the + / - on the tiles)
    return {"available": True, "total": len(hits),
            "sets": [{"id": sid, "name": nm} for sid, nm in sorted({(r["setId"], r["set"]) for r in rows}, key=lambda t: t[1])],
            "groups": [{"id": n, "name": n, "n": gcount[n]} for n in _series_order(game, list(gcount), gcount)] if len(gcount) > 1 or group else [],
            "kinds": [{"id": k, "name": k, "n": kcount[k], "hidden": k in HIDDEN_BY_DEFAULT} for k in sealedclass.KINDS if k in kcount],
            "items": [{**{x: r[x] for x in ("id", "setId", "set", "name", "img", "price", "priceKind", "kind", "serie", "multi")}, "have": have.get(r["norm"] or "", 0)} for r in hits[int(offset):int(offset) + int(limit)]]}


def price_for(v, name):
    """The list price for a product the person typed in by name (matched on letters and digits), or None."""
    from .. import sealedprice
    return sealedprice.price_for(v, name)                 # accents, brackets and word order don't stop a product from being priced
