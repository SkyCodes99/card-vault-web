"""The sealed-products list: browse every box, pack and bundle TCGplayer sells for the chosen game, with its price."""
import re

from .registry import api
from ..tcgcsv import norm_name


# Pokémon sealed products are grouped by era (by the date the set came out), the other games keep everything in one list.
_ERAS = [("2003-06-01", "e_wotc"), ("2007-05-01", "e_ex"), ("2011-04-01", "e_dp"), ("2014-01-01", "e_bw"), ("2017-01-01", "e_xy"),
         ("2020-02-01", "e_sm"), ("2023-03-01", "e_swsh"), ("2025-09-01", "e_sv"), ("9999", "e_mega")]


def _era_of(released):
    if not released:
        return "e_misc"
    return next(k for cut, k in _ERAS if released < cut)


@api("sealed.catalog")
def catalog(svc, q="", set_id="", limit=60, offset=0, group=""):
    v = svc.vault
    where, args = [], []
    if group and v.game.startswith("pokemon") and v.game == "pokemon":
        rel = {r[0]: r[1] for r in v.conn.execute("SELECT DISTINCT set_id, released FROM sealed_products")}
        ids = [s for s, d in rel.items() if _era_of(d) == group]
        where.append("set_id IN (" + ",".join("?" * len(ids)) + ")" if ids else "0")
        args += ids
    for w in norm_name(q).split():
        where.append("norm LIKE ?")
        args.append(f"%{w}%")
    if set_id:
        where.append("set_id=?")
        args.append(set_id)
    cond = ("WHERE " + " AND ".join(where)) if where else ""
    try:
        total = v.conn.execute(f"SELECT COUNT(*) FROM sealed_products {cond}", args).fetchone()[0]
        rows = v.conn.execute(f"SELECT id,set_id,set_name,name,image_base,price_usd,price_kind FROM sealed_products {cond} "
                              "ORDER BY (price_usd IS NULL), set_name DESC, name LIMIT ? OFFSET ?", args + [int(limit), int(offset)]).fetchall()
        sets = [{"id": r[0], "name": r[1]} for r in v.conn.execute("SELECT set_id, set_name FROM sealed_products GROUP BY set_id ORDER BY set_name")]
    except Exception:  # noqa: BLE001 - this game has no sealed list yet
        return {"total": 0, "items": [], "sets": [], "available": False}
    groups = []
    if v.game == "pokemon":
        from .. import taxonomy
        counts = {}
        for sid, n, d in v.conn.execute("SELECT set_id, COUNT(*), MAX(released) FROM sealed_products GROUP BY set_id"):
            k = _era_of(d)
            counts[k] = counts.get(k, 0) + n
        order = [k for _, k in reversed(_ERAS)] + ["e_misc"]                      # newest era first
        groups = [{"id": k, "name": taxonomy.LABEL.get(k, k), "n": counts[k]} for k in order if k in counts]
    return {"available": True, "total": total, "sets": sets, "groups": groups,
            "items": [{"id": r[0], "setId": r[1], "set": r[2] or "", "name": r[3], "img": (r[4] or "").replace("_200w", "_400w"), "price": r[5], "priceKind": r[6] or ""} for r in rows]}


def price_for(v, name):
    """The list price for a product the person typed in by name (matched on letters and digits), or None."""
    try:
        r = v.conn.execute("SELECT price_usd, price_kind FROM sealed_products WHERE norm=? AND price_usd IS NOT NULL ORDER BY price_updated DESC LIMIT 1", (norm_name(name),)).fetchone()
    except Exception:  # noqa: BLE001
        return None
    return {"price": r[0], "kind": r[1] or ""} if r else None
