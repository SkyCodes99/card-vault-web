"""Dev Tools > Sealed: look at every sealed product of the open game, change a product's TYPE (Booster box, Elite trainer box, Tin ...) by hand, or hide something that is not
really a product.  Your choices are kept with your account (a setting per game) and Find & Add's Browse uses them at once.  Nothing in the shared card list is changed."""
import json

from .. import sealedclass
from . import sealedcat
from .registry import api
from .service import ApiError


def load_fixes(svc):
    raw = svc.pget(f"sealed_fixes:{svc.vault.game}")
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        v = None
    return v if isinstance(v, dict) else {}


def _save(svc, fx):
    svc.pset(f"sealed_fixes:{svc.vault.game}", json.dumps(fx))
    svc.vault._sealed_stamp = getattr(svc.vault, "_sealed_stamp", 0) + 1            # the cached list is rebuilt with the new choices


def rows(svc, fixed=True):
    """Every sealed product with the person's choices applied (kind changed, hidden flag).  fixed=False = exactly as the card list has them."""
    base = sealedcat._all(svc)
    if base is None:
        return None
    if not fixed:
        return base
    fx = load_fixes(svc)
    if not fx:
        return base
    out = []
    for r in base:
        f = fx.get(r["id"])
        if not f:
            out.append(r)
            continue
        n = dict(r)
        if f.get("kind") in sealedclass.KINDS:
            n["autoKind"], n["kind"], n["fixed"] = r["kind"], f["kind"], True
        if f.get("hidden"):
            n["hidden"], n["fixed"] = True, True
        out.append(n)
    return out


@api("devsealed.state", quiet=True)
def state(svc):
    r = rows(svc)
    if r is None:
        return {"available": False}
    fx = load_fixes(svc)
    kinds = {}
    for x in r:
        kinds[x["kind"]] = kinds.get(x["kind"], 0) + 1
    return {"available": True, "total": len(r), "fixes": len(fx), "hidden": sum(1 for x in r if x.get("hidden")), "kinds": [{"id": k, "n": kinds[k]} for k in sealedclass.KINDS if k in kinds],
            "allKinds": list(sealedclass.KINDS), "sets": [{"id": sid, "name": nm} for sid, nm in sorted({(x["setId"], x["set"]) for x in r}, key=lambda t: t[1])]}


@api("devsealed.list", quiet=True)
def list_(svc, kind="", q="", set_id="", show="all", limit=60, offset=0):
    from ..tcgcsv import norm_name
    r = rows(svc)
    if r is None:
        return {"total": 0, "items": []}
    words = norm_name(q).split()
    hits = [x for x in r if (not kind or x["kind"] == kind) and (not set_id or x["setId"] == set_id) and all(w in x["norm"] for w in words)
            and (show == "all" or (show == "fixed" and x.get("fixed")) or (show == "hidden" and x.get("hidden")))]
    hits.sort(key=lambda x: (x["set"], x["name"]))
    keep = ("id", "setId", "set", "name", "img", "price", "kind", "serie", "autoKind", "fixed", "hidden")
    return {"total": len(hits), "items": [{k: x.get(k) for k in keep} for x in hits[int(offset):int(offset) + int(limit)]]}


@api("devsealed.fix", mutates=True)
def fix(svc, id, kind=None, hidden=None):
    """kind = a product type (or '' to go back to the automatic one); hidden = True / False."""
    if kind not in (None, "") and kind not in sealedclass.KINDS:
        raise ApiError("Unknown product type.")
    fx = load_fixes(svc)
    cur = dict(fx.get(str(id)) or {})
    if kind is not None:
        (cur.__setitem__("kind", kind) if kind else cur.pop("kind", None))
    if hidden is not None:
        (cur.__setitem__("hidden", True) if hidden else cur.pop("hidden", None))
    if cur:
        fx[str(id)] = cur
    else:
        fx.pop(str(id), None)
    _save(svc, fx)
    return state(svc)


@api("devsealed.clear", mutates=True)
def clear(svc):
    _save(svc, {})
    return state(svc)
