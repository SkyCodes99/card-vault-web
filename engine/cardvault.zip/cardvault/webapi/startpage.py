"""The page the app opens on after signing in (Settings > Look & reading > Start page).  One account setting, so it follows the account to every device:
  "home"  Home, the collection at a glance (pages/home/) - what a NEW account starts on
  "last"  where I left off last time (the app's old behaviour, kept for everyone who used the app before Home came back)
  or one page: "cards" (Find & Add), "inventory" (Portfolios), "lists" (Checklists), "value" (Analytics)
The first time an account is opened after Home came back, `settle` picks the start page ONCE (idempotent: a start page that is set is never changed here):
an account the synced record already has a pick for takes that pick; an account that already holds (or held) something keeps "last" and gets a
one-time tip that Home exists; a brand-new one starts on Home."""
from .registry import ApiError, api

KEY, TIP = "start_page", "home_tip"
PAGES = ("home", "last", "cards", "inventory", "lists", "value")


def _synced_pick(svc):
    """The start page another device already chose (the synced record of the account's choices), else ''."""
    try:
        got = ((svc.vault.look_get() or {}).get("profile") or {}).get(KEY)
    except Exception:  # noqa: BLE001 - locked / not ready: nothing synced to read
        return ""
    return got if got in PAGES else ""


def _used_before(svc):
    """Did this account exist before Home came back?  Anything it holds (any game, deleted or not) or any saved day of its value says yes."""
    v = svc.vault
    return any(v.conn.execute(q, (v.user_id,)).fetchone() for q in ("SELECT 1 FROM u.lots WHERE user_id=? LIMIT 1", "SELECT 1 FROM u.sealed WHERE user_id=? LIMIT 1",
                                                                      "SELECT 1 FROM u.snapshots WHERE user_id=? AND total_usd>0 LIMIT 1"))


def settle(svc):
    """The migration: decide the start page once.  -> {"page", "tip"} (tip = show the one-time 'Home is here' note)."""
    if svc.vault is None:
        return {"page": "last", "tip": False}
    page = svc.pget(KEY)
    if page not in PAGES:
        page = _synced_pick(svc)
        if not page:
            old = _used_before(svc)
            page = "last" if old else "home"
            if old:
                svc.pset(TIP, "1")
        svc.pset(KEY, page)
    return {"page": page, "tip": svc.pget(TIP) == "1"}


@api("start.set", mutates=True)
def start_set(svc, page):
    if page not in PAGES:
        raise ApiError("Pick a start page.")
    svc.pset(KEY, page)
    svc.pset(TIP, None)                                   # (choosing one answers the tip)
    return {"ok": True, "page": page}


@api("start.tipSeen", mutates=True)
def tip_seen(svc):
    svc.pset(TIP, None)
    return {"ok": True}
