"""Do checklists count in the totals?

OFF (the normal state): checklists are only a picture.  Every card you own sits in a real portfolio, and a checklist just shows how far along you are.
ON: a card you tick on a checklist can be held by the checklist itself (it lands in the built-in "In checklists" bucket, id "@lists") and counts in the totals
like any portfolio.  Switching either way never deletes anything: cards only move between portfolios, and the last move can be undone."""
import json

from .. import checklists
from ..db import now_iso
from .registry import api
from .service import ApiError

HELD = "@lists"
MAIN = "main"


def is_on(svc):
    return str(svc.pget("lists_count", "0")) in ("1", "True", "true")


def _pf_names(svc):
    names = {"": svc.pget("main_portfolio_name") or "Main", HELD: "In checklists"}
    for p in svc.vault.portfolios():
        names[p["uuid"]] = p["name"]
    return names


def _members(svc):
    """{card id: [checklist names]} - every card that sits on at least one checklist."""
    v = svc.vault
    out = {}
    for cl in v.checklists():
        try:
            for cid in checklists.members(v, cl):
                out.setdefault(cid, []).append(cl["name"])
        except Exception:  # noqa: BLE001 - a broken list must not block the rest
            continue
    return out


def _lots(svc, portfolios):
    v = svc.vault
    marks = ",".join("?" * len(portfolios))
    return v.conn.execute(
        f"SELECT l.uuid, l.card_id, l.qty, COALESCE(l.portfolio,'') AS pf, c.name, c.local_id, s.name AS set_name FROM u.lots l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
        f"WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 AND COALESCE(l.portfolio,'') IN ({marks}) ORDER BY s.name, c.local_id", [v.user_id, v.game, *portfolios]).fetchall()


def _undo_note(svc):
    try:
        raw = svc.pget("lists_undo")
        return json.loads(raw) if isinstance(raw, str) and raw else None
    except ValueError:
        return None


@api("lists.weight.status", quiet=True)
def status(svc):
    held = _lots(svc, [HELD])
    u = _undo_note(svc)
    return {"on": is_on(svc), "heldCopies": sum(l["qty"] for l in held), "heldCards": len({l["card_id"] for l in held}),
            "undo": ({"label": u["label"], "n": len(u["lots"]), "at": u["at"]} if u and u.get("game") == svc.vault.game else None)}


@api("lists.weight.review", quiet=True)
def review(svc, direction="on"):
    """The cards to go through.  direction 'off' = the cards the checklists hold now (each needs a real portfolio); 'on' = the cards in portfolios that are on a checklist
    (each may stay put or be handed to the checklists); 'review' = same as 'on' (for the first look at where checklist cards live)."""
    mem = _members(svc)
    names = _pf_names(svc)
    if direction == "off":
        rows = _lots(svc, [HELD])
    else:
        rows = [l for l in _lots(svc, [p for p in names if p != HELD]) if l["card_id"] in mem]
    pfs = [{"id": (k or MAIN), "name": n} for k, n in names.items() if k != HELD]
    items = [{"lot": l["uuid"], "card": l["card_id"], "name": l["name"], "number": l["local_id"], "set": l["set_name"] or "", "qty": l["qty"], "portfolio": l["pf"] or MAIN,
              "lists": mem.get(l["card_id"], [])[:3]} for l in rows[:4000]]
    return {"direction": direction, "items": items, "total": len(rows), "portfolios": pfs}


def _apply(svc, moves, label, setting=None):
    v = svc.vault
    prev, now = [], now_iso()
    for m in moves:
        lot, to = m.get("lot"), m.get("portfolio")
        if not lot or to is None:
            continue
        to = "" if to == MAIN else to
        r = v.conn.execute("SELECT COALESCE(portfolio,'') FROM u.lots WHERE uuid=? AND user_id=?", (lot, v.user_id)).fetchone()
        if not r or r[0] == to:
            continue
        prev.append({"lot": lot, "portfolio": r[0]})
        v.conn.execute("UPDATE u.lots SET portfolio=?, updated_at=? WHERE uuid=? AND user_id=?", (to, now, lot, v.user_id))
    note = {"label": label, "lots": prev, "was": is_on(svc), "game": v.game, "at": now}
    if setting is not None:
        svc.pset("lists_count", "1" if setting else "0")
    svc.pset("lists_undo", json.dumps(note))
    v._commit()
    return len(prev)


@api("lists.weight.set", mutates=True)
def set_weight(svc, on, moves=None):
    """Switch it on or off.  Turning it off needs every card the checklists hold to be given a portfolio (moves = [{lot, portfolio}]); nothing is ever deleted."""
    on = bool(on)
    moves = moves or []
    if not on:
        covered = {m.get("lot") for m in moves if m.get("portfolio") not in (None, "", HELD)}
        loose = [l for l in _lots(svc, [HELD]) if l["uuid"] not in covered]
        if loose:
            raise ApiError(f"{len(loose)} cards are held by checklists - choose a portfolio for each one first.")
    n = _apply(svc, moves, "Checklists now count in the totals" if on else "Checklists no longer count in the totals", setting=on)
    return {"on": on, "moved": n}


@api("lists.weight.assign", mutates=True)
def assign(svc, moves):
    """Move cards between portfolios / the checklists without changing the on/off choice (the review screens)."""
    n = _apply(svc, moves or [], "Moved checklist cards")
    return {"moved": n}


@api("lists.weight.undo", mutates=True)
def undo(svc):
    v = svc.vault
    u = _undo_note(svc)
    if not u or u.get("game") != v.game:
        raise ApiError("There is nothing to undo.")
    now = now_iso()
    for m in u["lots"]:
        v.conn.execute("UPDATE u.lots SET portfolio=?, updated_at=? WHERE uuid=? AND user_id=?", (m["portfolio"], now, m["lot"], v.user_id))
    svc.pset("lists_count", "1" if u.get("was") else "0")
    svc.pset("lists_undo", None)
    v._commit()
    return {"on": bool(u.get("was")), "restored": len(u["lots"])}
