"""'This could fill a spot in a checklist': when something is added to a portfolio that a checklist does not count from, the checklist cannot see it - so the person is told which checklist spots it
would fill and asked whether to let that checklist count the portfolio.  Nothing changes unless they say yes.

Used by the calls that add things (lot.add, qty.adjust, own.toggle, sealed.save, sealed.adjust): each answer carries `fillHints` - [{id, name, icon, slots: [...], more, portfolio: {id, name}}] - when there is
something to ask.  `lists.hintAccept` lets a checklist count the portfolio; `lists.hintOff` stops asking about a checklist (kept on this device)."""
import functools
import json

from .. import checklists
from ..tcgcsv import norm_name
from .listsource import source_of, source_scope
from .portfolios import MAIN, _api_id, with_descendants
from .registry import ApiError, api

NAMES = {"lot.add", "qty.adjust", "own.toggle", "sealed.save", "sealed.adjust"}
OFF_KEY = "_clhint_off"                                         # device-only: checklists the person asked not to be asked about again


def _off(svc):
    try:
        d = json.loads(svc.pget(OFF_KEY) or "[]")
    except ValueError:
        d = []
    return {str(x) for x in d} if isinstance(d, list) else set()


def _pf_name(svc, pf):
    if pf in ("", None, MAIN):
        from .portfolios import main_name
        return main_name(svc)
    r = next((p for p in svc.vault.portfolios() if p["uuid"] == pf), None)
    return r["name"] if r else "that portfolio"


def hints(svc, card_id=None, product=None, portfolio=""):
    """Checklists (of the open game) that would get a spot filled if `portfolio` counted for them."""
    v = svc.vault
    api_pf = _api_id(portfolio or "")
    out, off = [], _off(svc)
    for cl in v.checklists():
        if str(cl["id"]) in off:
            continue
        src = source_of(cl)
        if src["mode"] != "pick":
            continue                                             # 'everything' already counts it; 'follows the view' has no fixed portfolios to add to
        if api_pf in with_descendants(svc, src["ids"]):
            continue
        slots = []
        try:
            with source_scope(svc, cl):
                if card_id:
                    pr = checklists.progress_for_checklist(v, cl)
                    for t in pr.tiles:
                        if t.owned:
                            continue
                        cands = [c if isinstance(c, str) else (c[0] if c else "") for c in (t.candidates or [])]
                        if t.card_id == card_id or card_id in cands:
                            slots.append(t.label or (v.card_basic(card_id) or {}).get("name", card_id))
                if product:
                    from .listsealed import _members, _owned
                    rules = (checklists._load_rules(cl) or {}).get("sealed") or {}
                    if rules:
                        have = _owned(svc)
                        key = norm_name(product)
                        for r in _members(svc, rules):
                            if (r["norm"] or norm_name(r["name"])) == key and not have.get(key, 0):
                                slots.append(r["name"])
        except Exception:  # noqa: BLE001 - one checklist that cannot be read never stops the add
            continue
        if slots:
            out.append({"id": cl["id"], "name": cl["name"], "icon": (checklists._load_rules(cl) or {}).get("icon", ""), "slots": list(dict.fromkeys(slots))[:3], "more": max(0, len(set(slots)) - 3),
                        "portfolio": {"id": api_pf, "name": _pf_name(svc, portfolio)}})
    return out


def _latest_card_pf(svc, cid):
    v = svc.vault
    r = v.conn.execute("SELECT COALESCE(portfolio,'') FROM u.lots WHERE user_id=? AND game=? AND card_id=? AND deleted=0 AND qty>0 ORDER BY updated_at DESC, id DESC LIMIT 1", (v.user_id, v.game, cid)).fetchone()
    return r[0] if r else None


def _latest_sealed(svc, name=None, uuid=None):
    v = svc.vault
    if uuid:
        r = v.conn.execute("SELECT name, COALESCE(portfolio,'') FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0 AND qty>0", (uuid, v.user_id)).fetchone()
    else:
        r = v.conn.execute("SELECT name, COALESCE(portfolio,'') FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND lower(name)=lower(?) ORDER BY updated_at DESC LIMIT 1", (v.user_id, v.game, name or "")).fetchone()
    return (r[0], r[1]) if r else (None, None)


def wrap(fn, name):
    """The same call, plus `fillHints` in its answer when what it added could fill a checklist spot that the checklist cannot count yet."""
    @functools.wraps(fn)
    def inner(svc, *a, **kw):
        res = fn(svc, *a, **kw)
        if not isinstance(res, dict):
            return res
        try:
            if name in ("lot.add", "qty.adjust", "own.toggle"):
                if name == "qty.adjust" and (kw.get("delta") or 0) <= 0:
                    return res
                if name == "own.toggle" and not str((res.get("undo") or {}).get("label", "")).startswith("Marked"):
                    return res
                cid = kw.get("id")
                pf = _latest_card_pf(svc, cid)
                h = hints(svc, card_id=cid, portfolio=pf) if pf is not None else []
            elif name == "sealed.save" or (name == "sealed.adjust" and (kw.get("delta") or 0) > 0):
                prod, pf = _latest_sealed(svc, name=kw.get("name"), uuid=kw.get("id") if name == "sealed.adjust" else (res.get("id") or kw.get("id")))
                h = hints(svc, product=prod, portfolio=pf) if prod else []
            else:
                h = []
            if h:
                res = {**res, "fillHints": h}
        except Exception:  # noqa: BLE001 - never turn an add into a failure
            pass
        return res
    return inner


@api("lists.hintAccept", mutates=True)
def hint_accept(svc, id, portfolio):
    """Let checklist `id` count what is in `portfolio` too (and everything inside it)."""
    from .listsource import lists_set_source
    cl = svc.vault.checklist(id)
    if not cl:
        raise ApiError("checklist not found")
    src = source_of(cl)
    if src["mode"] != "pick":
        return src
    ids = list(dict.fromkeys([*src["ids"], str(portfolio or MAIN)]))
    return lists_set_source(svc, id, "pick", ids)


@api("lists.hintOff", mutates=False)
def hint_off(svc, id):
    d = _off(svc) | {str(id)}
    svc.pset(OFF_KEY, json.dumps(sorted(d)))
    return {"ok": True}
