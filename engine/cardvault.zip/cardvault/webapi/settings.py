"""App info and settings."""
import datetime
import os
import re
import time

from .. import currency, games, runtime
from ..db import game_dir
from ..version import APP_NAME, CHANGELOG, VERSION
from .registry import api
from .service import ApiError

SAFE_KEYS = {"price_mode", "price_primary", "theme", "theme_pack", "currency", "dim_missing", "edition", "image_quality", "auto_prices", "price_interval_hours", "auto_updates", "owner_name", "zoom", "image_cache_mb", "on_demand_images", "accent", "density", "round", "look_separate"}
LOOK_KEYS = ("theme", "theme_pack", "accent", "density", "round")      # these follow the account to every device unless this device is set to keep its own
DENSITY, ROUND = ("compact", "normal", "roomy"), ("sharp", "normal", "round")


def effective_look(svc):
    """(this device keeps its own look?, the look to show).  Unless the device keeps its own, the account's synced look wins; it is mirrored into the device copy so the sign-in screen matches."""
    sep = bool(svc.cfg.get("look_separate"))
    look = {}
    if not sep and svc.vault is not None:
        try:
            look = svc.vault.look_get()
        except Exception:  # noqa: BLE001 - locked / not ready
            look = {}
        changed = False
        for k in LOOK_KEYS:
            if k in look and svc.cfg.get(k) != look[k]:
                svc.cfg[k] = look[k]
                changed = True
        if changed:
            svc.save()
    return sep, look


@api("app.info")
def info(svc):
    v, g = svc.vault, svc.game
    separate = effective_look(svc)[0]          # first: this mirrors the account's look into the settings read below
    avail = []
    for gm in games.GAMES:
        if gm.available:
            avail.append({"id": gm.id, "name": gm.name, "family": gm.family})
    return {"name": APP_NAME, "version": VERSION, "game": {"id": g.id, "name": g.name, "pokemon": g.pokemon, "family": g.family, "typeLabel": g.type_label},
            "guest": bool(svc.guest), "games": avail, "cards": v.card_count(), "dataDir": svc.cfg["data_dir"], "settings": {**{k: svc.cfg.get(k) for k in SAFE_KEYS}, "look_separate": separate, "jp_names": svc.pget("jp_names", "english")},
            "currency": {"code": currency.code(), "symbol": currency.symbol().strip(), "rate": currency.rate(), "decimals": currency.decimals(),
                         "all": [{"code": c, "symbol": s.strip()} for c, (s, _r) in currency.CURRENCIES.items()]},
            "caps": {"desktop": True, "sync": True, "updates": True, "files": True, "download": True, "web": runtime.IN_BROWSER}, "rev": svc.rev, "changelog": CHANGELOG[:3]}


def _stamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


@api("settings.set", mutates=True)
def set_setting(svc, key, value):
    if key not in SAFE_KEYS:
        raise ApiError("unknown setting")
    if key == "accent" and value and not re.fullmatch(r"#[0-9a-fA-F]{6}", str(value)):
        raise ApiError("accent must be a colour like #2a6df0")
    if key == "density" and value not in DENSITY or key == "round" and value not in ROUND:
        raise ApiError("unknown option")
    if key == "price_mode" and value not in ("standard", "sale", "both") or key == "price_primary" and value not in ("standard", "sale"):
        raise ApiError("unknown option")
    if key == "look_separate":
        value = bool(value)
        if not value and svc.vault is not None and not svc.vault.look_get():          # going back to the shared look: share this device's current one
            svc.vault.look_set({**{k: svc.cfg.get(k) or "" for k in LOOK_KEYS}, "updated_at": _stamp()})
    elif key in LOOK_KEYS and not svc.cfg.get("look_separate") and svc.vault is not None:
        look = svc.vault.look_get()
        look.update({k: svc.cfg.get(k) or "" for k in LOOK_KEYS if k not in look})
        look[key] = value
        look["updated_at"] = _stamp()
        svc.vault.look_set(look)
    svc.cfg[key] = value
    if key == "currency":
        currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


@api("currency.setRate", mutates=True)
def currency_rate(svc, code, rate):
    svc.cfg.setdefault("currency_rates", {})[code] = float(rate)
    svc.cfg["currency_rates_updated"] = "by hand"
    currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


@api("currency.fetch", mutates=True)
def currency_fetch(svc):
    try:
        rates = currency.fetch_rates()
    except Exception as e:  # noqa: BLE001
        raise ApiError(f"Could not download rates: {e}")
    svc.cfg["currency_rates"] = rates
    svc.cfg["currency_rates_updated"] = datetime.date.today().isoformat()
    currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


@api("settings.jpNames", mutates=True)
def set_jp_names(svc, mode):
    """Japanese card list: 'english' (English names where there is one, the Japanese name stays searchable) or 'japanese'."""
    mode = "japanese" if mode == "japanese" else "english"
    svc.pset("jp_names", mode)
    if svc.apply_names() and svc.vault is not None:
        svc.vault.invalidate_index()
        svc.vault._sealed_stamp = getattr(svc.vault, "_sealed_stamp", 0) + 1
    return {"mode": mode}


@api("game.switch", mutates=True)
def game_switch(svc, id):
    from . import gamesapi
    if id != svc.vault.game and not gamesapi.has_catalog(svc, id):         # not on this device yet: fetch its card list, then switch
        return {"ok": True, "job": gamesapi.ensure_job(svc, id, then_open=True)}
    svc.open_game(id)
    svc.save()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ choices that follow the account
# Beyond the look, these are things a person chose: currency, units, budget, portfolio name, showcase page, reminders.  They ride in the same synced
# record as the look (newest edit wins), so a new device starts out with them.  Device-only things (auto-lock, folders, view state) are not here.
PREF_CFG = ("price_mode", "price_primary", "currency", "edition", "dim_missing", "zoom", "owner_name", "auto_prices", "price_interval_hours")
PREF_GAME = ("monthly_budget_usd", "variant_hunting", "art_threshold", "art_threshold_learned_at")        # saved per game
PREF_PROFILE = ("avatar", "main_portfolio_name", "showcase", "variant_reminders", "share_out", "share_in", "friends", "list_order", "sealed_promos", "friend_privacy", "friend_favs", "ftrade_applied",
                "main_icon", "main_color", "main_order", "scanner_min_conf", "scanner_confirm_below")
PREF_PER_GAME = ("hidden_kinds", "kind_overrides", "sealed_fixes")          # kept under 'name:game' (the Extras switches, your own sealed-product changes)


# What stays on ONE device: the sign-in itself (tokens, keys), folders on this computer, how soon this device locks, and what this device is looking at right now.
# Everything else a person chooses follows the account to every device.
DEVICE_ONLY = ("cloud_", "sync_", "github_token", "backup_dir", "autolock_minutes", "preview_channel", "scanner_learn_sent", "placement_undo", "pf_target", "pf_scope", "scanmem", "_")


def _is_profile_pref(k):
    return bool(k) and not k.startswith(DEVICE_ONLY)


def _per_game_keys():
    from .. import games
    return [f"{p}:{g.id}" for p in PREF_PER_GAME for g in games.GAMES]


def prefs_collect(svc):
    v = svc.vault
    out = {"cfg": {k: svc.cfg.get(k) for k in PREF_CFG if svc.cfg.get(k) is not None},
           "profile": {k: svc.pget(k) for k in dict.fromkeys((*PREF_PROFILE, *_per_game_keys(), *(svc.session.keys() if svc.session is not None else ()))) if _is_profile_pref(k) and svc.pget(k) is not None}}
    out["game"] = {v.game: {k: v.get_setting(k) for k in PREF_GAME if v.get_setting(k) is not None}}
    return out


def _view(stored):
    return {"cfg": stored.get("cfg") or {}, "profile": stored.get("profile") or {}, "game": stored.get("game") or {}}


def prefs_adopt(svc):
    """Apply the account's saved choices on this device (the newest edit anywhere wins).  Called after sign-in, a sync, and switching game."""
    v = svc.vault
    if v is None:
        return
    try:
        stored = v.look_get()
    except Exception:  # noqa: BLE001
        return
    have = _view(stored)
    changed = False
    for k, val in have["cfg"].items():
        if k in PREF_CFG and svc.cfg.get(k) != val:
            svc.cfg[k] = val
            changed = True
    for k, val in have["profile"].items():
        if _is_profile_pref(k) and svc.pget(k) != val:
            svc.pset(k, val)
    for k, val in (have["game"].get(v.game) or {}).items():
        if k in PREF_GAME and v.get_setting(k) != str(val):
            v.set_setting(k, val)
    if changed:
        from .. import currency
        currency.configure(svc.cfg)
        svc.save()
    svc._prefs_ready = True


def prefs_touch(svc):
    """If a choice was changed on this device, store it in the synced record (and let the sync send it)."""
    if not getattr(svc, "_prefs_ready", False) or svc.vault is None or svc.session is None:
        return
    stored = svc.vault.look_get()
    cur = prefs_collect(svc)
    have = _view(stored)
    merged = {"cfg": {**have["cfg"], **cur["cfg"]}, "profile": {**have["profile"], **cur["profile"]},
              "game": {**have["game"], svc.vault.game: {**(have["game"].get(svc.vault.game) or {}), **cur["game"][svc.vault.game]}}}
    if merged == have:
        return
    svc.vault.look_set({**stored, **merged, "updated_at": _stamp()})
    svc.last_change = time.time()
