"""App info and settings."""
import datetime
import logging
import re
import time

from .. import currency, gamefacets, games, runtime, shelves
from ..db import search_aliases
from ..version import APP_NAME, CHANGELOG, VERSION
from . import startpage
from .registry import api
from .service import ApiError

log = logging.getLogger("cardvault.errors")

SAFE_KEYS = {"price_mode", "price_primary", "theme", "theme_pack", "currency", "dim_missing", "edition", "image_quality", "auto_prices", "price_interval_hours", "auto_updates", "owner_name", "zoom", "image_cache_mb", "on_demand_images", "accent", "density", "round", "look_separate", "show_pocket", "show_proofs"}
LOOK_KEYS = ("theme", "theme_pack", "accent", "density", "round")      # these follow the account to every device unless this device is set to keep its own
DENSITY, ROUND = ("compact", "normal", "roomy"), ("sharp", "normal", "round")


def effective_look(svc):
    """(this device keeps its own look?, the look to show).  Unless the device keeps its own, the account's synced look wins; it is mirrored into the device copy so the sign-in screen matches."""
    sep = bool(svc.cfg.get("look_separate"))
    look = {}
    if not sep and svc.vault is not None:
        try:
            look = svc.vault.look_get()
        except Exception:  # noqa: BLE001 - locked / not ready
            look = {}
        changed = False
        for k in LOOK_KEYS:
            if k in look and svc.cfg.get(k) != look[k]:
                svc.cfg[k] = look[k]
                changed = True
        if changed:
            svc.save()
    return sep, look


def cards_by_edition(svc):
    """Pokémon's card list holds two collections: the physical card game and the digital TCG Pocket.  Every screen counts the one you are looking at (the Game menu), so the count at the
    bottom of the window must too - it said 31,104 (both) while Series analytics said 28,624 (Physical TCG).  -> {"tcg": n, "pocket": n}, or None for a game with one collection."""
    v, g = svc.vault, svc.game
    if not g.pokemon or g.id in games.ONE_COLLECTION:
        return None
    fp = v.catalog_fp()
    kept = v.__dict__.get("_cards_by_ed")
    if fp is not None and kept and kept[0] == fp:
        return kept[1]
    from ..db import edition_of
    out = {}
    for serie, n in v.conn.execute("SELECT s.serie, COUNT(*) FROM cards c JOIN sets s ON s.id=c.set_id GROUP BY s.serie"):
        e = edition_of(serie)
        out[e] = out.get(e, 0) + n
    v._cards_by_ed = (fp, out)
    return out


@api("app.info")
def info(svc):
    v, g = svc.vault, svc.game
    separate = effective_look(svc)[0]          # first: this mirrors the account's look into the settings read below
    avail = []
    for gm in games.GAMES:
        if gm.available and (not gm.own or gm.id == g.id or __import__("cardvault.webapi.gamesapi", fromlist=["x"]).has_catalog(svc, gm.id)):          # ("Other" is listed once it holds an item of yours)
            sh, co = shelves.place_of(gm.id)
            avail.append({"id": gm.id, "name": gm.name, "family": gm.family, "shelf": sh, "company": co})          # (where it sits in the menus: cardvault/shelves.py)
    soon = [{"id": gm.id, "name": gm.name, "family": gm.family} for gm in games.GAMES if gm.coming_soon and not gm.available]          # announced lists: in the menus with a 'Coming soon' pill, never opened
    return {"name": APP_NAME, "version": VERSION, "soon": soon, "game": {"id": g.id, "name": g.name, "pokemon": g.pokemon, "family": g.family, "oneCollection": g.id in games.ONE_COLLECTION, "typeLabel": g.type_label, **gamefacets.vocab(g.id)},
            "guest": bool(svc.guest), "games": avail, "shelves": shelves.tree([x["id"] for x in avail + soon]), "fandoms": shelves.fandom_list(), "searchAliases": search_aliases(), "cards": v.card_count(), "cardsByEdition": cards_by_edition(svc), "dataDir": svc.cfg["data_dir"], "settings": {**{k: svc.cfg.get(k) for k in SAFE_KEYS}, "look_separate": separate},
            "start": startpage.settle(svc),                                          # the page to open on after signing in, and the one-time 'Home is here' tip (startpage.py)
            "tourSeen": (svc.pget(startpage.TOUR) or "") if svc.session is not None else "",          # the version the guided tour was last finished/skipped at (Tour.jsx)
            "currency": {**currency.info(), "all": [{"code": c, "symbol": s.strip()} for c, (s, _r) in currency.CURRENCIES.items()]},
            "caps": {"desktop": True, "sync": True, "updates": True, "files": True, "download": True, "web": runtime.IN_BROWSER}, "rev": svc.rev, "changelog": CHANGELOG[:3]}


def _stamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


@api("settings.set", mutates=True)
def set_setting(svc, key, value):
    if key not in SAFE_KEYS:
        raise ApiError("unknown setting")
    if key == "accent" and value and not re.fullmatch(r"#[0-9a-fA-F]{6}", str(value)):
        raise ApiError("accent must be a colour like #2a6df0")
    if key == "density" and value not in DENSITY or key == "round" and value not in ROUND:
        raise ApiError("unknown option")
    if key == "price_mode" and value not in ("standard", "sale", "both") or key == "price_primary" and value not in ("standard", "sale"):
        raise ApiError("unknown option")
    if key == "look_separate":
        value = bool(value)
        if not value and svc.vault is not None and not svc.vault.look_get():          # going back to the shared look: share this device's current one
            svc.vault.look_set({**{k: svc.cfg.get(k) or "" for k in LOOK_KEYS}, "updated_at": _stamp()})
    elif key in LOOK_KEYS and not svc.cfg.get("look_separate") and svc.vault is not None:
        look = svc.vault.look_get()
        look.update({k: svc.cfg.get(k) or "" for k in LOOK_KEYS if k not in look})
        look[key] = value
        look["updated_at"] = _stamp()
        svc.vault.look_set(look)
    svc.cfg[key] = value
    if key == "currency":
        currency.configure(svc.cfg)
        if currency.info().get("note"):                                    # a currency with no rate yet: get today's rates now instead of showing dollars until 'Update rates'
            try:
                refresh_fx(svc, force=True)
            except Exception:  # noqa: BLE001 - offline: the note stays and the button still works
                pass
    svc.save()
    if key == "show_proofs" and svc.vault is not None:                    # the open toy list shows / hides its art proofs and prototypes at once
        svc.open_game(svc.vault.game)
        svc.vault.invalidate_index()
    return {"ok": True}


@api("currency.setRate", mutates=True)
def currency_rate(svc, code, rate):
    svc.cfg.setdefault("currency_rates", {})[code] = float(rate)
    currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


def refresh_fx(svc, force=False):
    """Download the day's exchange rates (Card Data fx.json) at most once a day - force: now (the Update rates button).  The last good rates stay when it fails.
    -> True when new rates were stored.  Called by the scheduler, by the button and when a currency with no rate yet is picked."""
    have = svc.cfg.get("fx") if isinstance(svc.cfg.get("fx"), dict) else {}
    if not force and not svc.cfg.get("auto_prices", True):                # automatic price downloads turned off: only the button (or a new currency) fetches
        return False
    if not force and (have.get("fetched") == datetime.date.today().isoformat() or time.time() - getattr(svc, "_fx_tried", 0) < 3600):
        return False                                                       # (and after a failed try, not again for an hour: offline costs one quick failure, not one every few minutes)
    svc._fx_tried = time.time()
    fx = currency.fetch_fx()
    svc.cfg["fx"] = fx
    currency.configure(svc.cfg)
    svc.save()
    return True


@api("currency.fetch", mutates=True)
def currency_fetch(svc):
    try:
        refresh_fx(svc, force=True)
    except Exception as e:  # noqa: BLE001
        log.warning("currency.fetch failed: %s", e)                    # the detail (it holds the web address) goes to the log, not the page
        raise ApiError("Couldn't download exchange rates - check your connection")
    return {"ok": True}


@api("prices.sources")
def price_sources(svc):
    """The price sources this game offers, which ones you trust and which price every total uses (see cardvault/pricepick.py)."""
    from .. import pricepick
    v = svc.vault
    return {"offered": pricepick.offered(v), **pricepick.setting(v), "label": pricepick.label(v), "eurRate": currency.usd_from(1.0, "EUR")}


@api("prices.setSources", mutates=True)
def price_sources_set(svc, use="main", trust=None):
    from .. import pricepick
    s = pricepick.save(svc.vault, use, trust if trust is not None else [o["key"] for o in pricepick.offered(svc.vault)])
    return {"ok": True, **s, "label": pricepick.label(svc.vault)}


@api("prices.type")
def price_type(svc):
    """Which kind of price totals use (Market / Lowest / Middle / Recent sales) and which kinds this game can show (see cardvault/pricetype.py)."""
    from .. import pricepick, pricetype
    v = svc.vault
    kind = pricetype.chosen(v)
    have = pricetype.available(v, len(pricepick.offered(v)))
    return {"type": kind, "types": [{"key": k, "name": pricetype.NAMES[k], "note": pricetype.NOTES[k]} for k in pricetype.IDS if k in have or k == kind], "label": pricepick.label(v)}


@api("prices.setType", mutates=True)
def price_type_set(svc, kind="market"):
    from .. import pricepick, pricetype
    kind = pricetype.save(svc.vault, kind)
    return {"ok": True, "type": kind, "label": pricepick.label(svc.vault)}


@api("settings.cardLang", mutates=True)
def set_card_lang(svc, lang="en"):
    """The app's language, so card names show in it (cardvault/names.py): the official name in that language where the list has one, else English.  Kept on this device; called when the app starts and when the language changes."""
    from .. import names
    lang = names.clean(lang)
    if svc.cfg.get("card_lang") != lang:
        svc.cfg["card_lang"] = lang
        svc.save()
    changed = svc.apply_names() if svc.vault is not None else False
    if changed:
        svc.vault.invalidate_index()
        svc.vault._sealed_stamp = getattr(svc.vault, "_sealed_stamp", 0) + 1
    return {"lang": lang, "changed": bool(changed)}


@api("game.switch", mutates=True)
def game_switch(svc, id):
    from . import gamesapi
    if games.is_coming_soon(id):
        raise ApiError("That list is coming soon.")
    own = games.game_by_id(id).own and games.game_by_id(id).id == id       # "Other (my own items)" has no card list to fetch: it opens empty (Import a list goes there for 'Misc.' rows)
    online = not own and runtime.IN_BROWSER and not gamesapi.offline_on(svc, id)      # the website, "Keep for offline use" off: the list stays on Card Data (ui/src/online reads it), nothing to fetch
    if not own and not online and not gamesapi.has_catalog(svc, id):         # not on this device yet: fetch its card list, then switch (also the open game's own list, when its download failed: Try again on the install panel)
        return {"ok": True, "job": gamesapi.ensure_job(svc, id, then_open=True)}
    svc.open_game(id)
    svc.save()
    svc._more_catalogs = True                                            # the game you just opened is checked for a newer card list at the next tick
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ choices that follow the account
# Beyond the look, these are things a person chose: currency, units, budget, portfolio name, showcase page, reminders.  They ride in the same synced
# record as the look (newest edit wins), so a new device starts out with them.  Device-only things (auto-lock, folders, view state) are not here.
PREF_CFG = ("show_proofs", "show_pocket", "price_mode", "price_primary", "currency", "edition", "dim_missing", "zoom", "owner_name", "auto_prices", "price_interval_hours")
PREF_GAME = ("monthly_budget_usd", "variant_hunting", "art_threshold", "art_threshold_learned_at", "price_pick", "price_type")        # saved per game
PREF_PROFILE = ("avatar", "main_portfolio_name", "showcase", "variant_reminders", "share_out", "share_in", "friends", "list_order", "sealed_promos", "friend_privacy", "profile_card", "friend_favs", "ftrade_applied",
                "main_icon", "main_color", "main_order", "scanner_min_conf", "scanner_confirm_below", "weekly_email")
PREF_PER_GAME = ("hidden_kinds", "kind_overrides", "sealed_fixes")          # kept under 'name:game' (the Extras switches, your own sealed-product changes)


# What stays on ONE device: the sign-in itself (tokens, keys), folders on this computer, how soon this device locks, and what this device is looking at right now.
# Everything else a person chooses follows the account to every device.
DEVICE_ONLY = ("cloud_", "sync_", "github_token", "backup_dir", "autolock_minutes", "preview_channel", "scanner_learn_sent", "placement_undo", "pf_target", "pf_scope", "scanmem", "premium_", "weekly_sent", "_")


def _is_profile_pref(k):
    return bool(k) and not k.startswith(DEVICE_ONLY)


def _per_game_keys():
    from .. import games
    return [f"{p}:{g.id}" for p in PREF_PER_GAME for g in games.GAMES]


def prefs_collect(svc):
    v = svc.vault
    out = {"cfg": {k: svc.cfg.get(k) for k in PREF_CFG if svc.cfg.get(k) is not None},
           "profile": {k: svc.pget(k) for k in dict.fromkeys((*PREF_PROFILE, *_per_game_keys(), *(svc.session.keys() if svc.session is not None else ()))) if _is_profile_pref(k) and svc.pget(k) is not None}}
    out["game"] = {v.game: {k: v.get_setting(k) for k in PREF_GAME if v.get_setting(k) is not None}}
    return out


def _view(stored):
    return {"cfg": stored.get("cfg") or {}, "profile": stored.get("profile") or {}, "game": stored.get("game") or {}}


def prefs_adopt(svc):
    """Apply the account's saved choices on this device (the newest edit anywhere wins).  Called after sign-in, a sync, and switching game."""
    v = svc.vault
    if v is None:
        return
    try:
        stored = v.look_get()
    except Exception:  # noqa: BLE001
        return
    have = _view(stored)
    changed = False
    for k, val in have["cfg"].items():
        if k in PREF_CFG and svc.cfg.get(k) != val:
            svc.cfg[k] = val
            changed = True
    for k, val in have["profile"].items():
        if _is_profile_pref(k) and svc.pget(k) != val:
            svc.pset(k, val)
    for k, val in (have["game"].get(v.game) or {}).items():
        if k in PREF_GAME and v.get_setting(k) != str(val):
            v.set_setting(k, val)
    if changed:
        from .. import currency
        currency.configure(svc.cfg)
        svc.save()
    svc._prefs_ready = True


def prefs_touch(svc):
    """If a choice was changed on this device, store it in the synced record (and let the sync send it)."""
    if not getattr(svc, "_prefs_ready", False) or svc.vault is None or svc.session is None:
        return
    stored = svc.vault.look_get()
    cur = prefs_collect(svc)
    have = _view(stored)
    merged = {"cfg": {**have["cfg"], **cur["cfg"]}, "profile": {**have["profile"], **cur["profile"]},
              "game": {**have["game"], svc.vault.game: {**(have["game"].get(svc.vault.game) or {}), **cur["game"][svc.vault.game]}}}
    if merged == have:
        return
    svc.vault.look_set({**stored, **merged, "updated_at": _stamp()})
    svc.last_change = time.time()
