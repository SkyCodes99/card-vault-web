"""App info and settings."""
import datetime
import os

from .. import currency, games, runtime
from ..db import game_dir
from ..version import APP_NAME, CHANGELOG, VERSION
from .registry import api
from .service import ApiError

SAFE_KEYS = {"theme", "theme_pack", "currency", "dim_missing", "edition", "image_quality", "auto_prices", "price_interval_hours", "auto_updates", "owner_name", "zoom", "image_cache_mb", "on_demand_images"}


@api("app.info")
def info(svc):
    v, g = svc.vault, svc.game
    avail = []
    for gm in games.GAMES:
        if gm.available and (gm.id == v.game or os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], gm.id), "cards.db"))):
            avail.append({"id": gm.id, "name": gm.name})
    return {"name": APP_NAME, "version": VERSION, "game": {"id": g.id, "name": g.name, "pokemon": g.pokemon, "family": g.family, "typeLabel": g.type_label},
            "games": avail, "cards": v.card_count(), "dataDir": svc.cfg["data_dir"], "settings": {k: svc.cfg.get(k) for k in SAFE_KEYS},
            "currency": {"code": currency.code(), "symbol": currency.symbol().strip(), "rate": currency.rate(), "decimals": currency.decimals(),
                         "all": [{"code": c, "symbol": s.strip()} for c, (s, _r) in currency.CURRENCIES.items()]},
            "caps": {"desktop": True, "sync": True, "updates": True, "files": True, "download": True, "web": runtime.IN_BROWSER}, "rev": svc.rev, "changelog": CHANGELOG[:3]}


@api("settings.set", mutates=True)
def set_setting(svc, key, value):
    if key not in SAFE_KEYS:
        raise ApiError("unknown setting")
    svc.cfg[key] = value
    if key == "currency":
        currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


@api("currency.setRate", mutates=True)
def currency_rate(svc, code, rate):
    svc.cfg.setdefault("currency_rates", {})[code] = float(rate)
    svc.cfg["currency_rates_updated"] = "by hand"
    currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


@api("currency.fetch", mutates=True)
def currency_fetch(svc):
    try:
        rates = currency.fetch_rates()
    except Exception as e:  # noqa: BLE001
        raise ApiError(f"Could not download rates: {e}")
    svc.cfg["currency_rates"] = rates
    svc.cfg["currency_rates_updated"] = datetime.date.today().isoformat()
    currency.configure(svc.cfg)
    svc.save()
    return {"ok": True}


@api("game.switch", mutates=True)
def game_switch(svc, id):
    svc.open_game(id)
    svc.save()
    return {"ok": True}
