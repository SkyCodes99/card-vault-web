"""Plain-word error replies: what the page is allowed to show when a call fails.

A failure reply is {"error": <plain sentence>, "code": <short kind>}.  The raw detail (exception text, paths,
tokens, emails) is written to the local log only, never to the page.  The same rule lives in
ui/src/friendlyError.js; keep the two patterns in step.
"""
import logging
import re

from .registry import ApiError

log = logging.getLogger("cardvault.errors")

FALLBACK = "Something went wrong. Try again; if it keeps happening, send feedback from the menu."
BAD_REQUEST = "Something in that request didn't look right. Try again."
TOO_LARGE = "That's too big to send. Try a smaller picture or fewer items."
FORBIDDEN = "This page can't be used from here. Reload the app and try again."
NOT_JSON = "That didn't arrive in a form the app understands. Try again."

# Anything matching this is raw technical text, not a sentence for a person.
RAW = re.compile(
    r"traceback|stack trace|file \"|\bline \d+|[a-z]:\|\\|/(home|users|tmp|var|app|src|opt|etc|data|mnt)/"
    r"|\.(py|jsx?|mjs|json|db|sqlite|log|exe)\b|https?://|\S+@\S+\.\S+|bearer|token|secret|api[ _-]?key|password\s*="
    r"|\berror\s*\d{3}\b|\bundefined\b|\bnull\b|\bnan\b|\bexception\b|\w+(error|exception)\b|error:|\[object|[{}]|<[a-z/!]"
    r"|[a-z0-9_-]{32,}",
    re.I,
)


def looks_plain(msg):
    """True when the text is a sentence a person can read (no code, paths, keys, emails or raw exception text)."""
    return isinstance(msg, str) and 0 < len(msg.strip()) <= 400 and not RAW.search(msg)


def plain_or_fallback(msg, fallback=FALLBACK):
    return msg.strip() if looks_plain(msg) else fallback


def reply(e):
    """(status, body) for an exception raised by a call.  Logs the detail; the body holds only plain words."""
    if isinstance(e, ApiError):
        code = e.code or ""
        msg = str(e)
        if looks_plain(msg):
            return (401 if code == "locked" else 400), {"error": msg.strip(), "code": code, **e.extra}
        log.warning("call failed (%s): %s", code or "no code", msg)
        return 400, {"error": FALLBACK, "code": code or "internal", **e.extra}
    if isinstance(e, TypeError):
        log.warning("bad arguments: %s", e)
        return 400, {"error": BAD_REQUEST, "code": "bad_request"}
    log.exception("call crashed")
    return 500, {"error": FALLBACK, "code": "internal"}
