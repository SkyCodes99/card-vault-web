"""Help the scanner learn (OFF unless you turn it on).  When you correct a card in the scanner, the straightened picture of THAT CARD (never your whole photo)
and the right card number can be sent to the account server, kept at most 30 days, used once to improve the scanner, then deleted.
No name, email or account is attached to what the trainer sees.  Turning it off deletes what is waiting, here and on the server."""
import base64

from .. import runtime
from . import accountapi, scanner
from .registry import ApiError, api

BATCH = 50


def _scanner(path, method="GET", body=None, timeout=20):
    import requests
    if scanner.STATE["status"] != "running":
        return None
    r = requests.request(method, scanner.STATE["url"] + path, json=body, headers={"X-PIN": scanner.STATE["pin"]}, timeout=timeout)
    return r.json() if r.status_code == 200 else None


def enabled(svc):
    return bool(svc.pget("scanner_learn"))


@api("learn.status", quiet=True)
def status(svc):
    st = {"enabled": enabled(svc), "available": not runtime.IN_BROWSER, "retentionDays": 30, "signedIn": accountapi.account(svc) is not None,
          "scannerRunning": scanner.STATE["status"] == "running", "pending": 0, "sent": int(svc.pget("scanner_learn_sent", 0) or 0), "note": ""}
    try:
        c = _scanner("/api/contrib/status") if st["enabled"] else None
        if c:
            st["pending"] = int(c.get("pending", 0))
    except Exception:  # noqa: BLE001 - the scanner is busy or stopping
        pass
    a = accountapi.account(svc) if st["enabled"] else None
    if a is not None:
        try:
            st["stored"] = int(a.call("GET", "/v1/contrib/status", timeout=6).get("stored", 0))          # how many of your pictures are waiting on the server right now
        except Exception:  # noqa: BLE001
            pass
    if st["enabled"] and not st["signedIn"]:
        st["note"] = "Sign in to your account so the pictures can be sent."
    return st


@api("learn.set")
def set_enabled(svc, on):
    """The only switch.  Off: whatever is waiting on this PC and on the server is deleted."""
    if runtime.IN_BROWSER:
        raise ApiError("This is part of the desktop app's scanner.")
    on = bool(on)
    svc.pset("scanner_learn", True if on else None)
    try:
        _scanner("/api/contrib/enable", "POST", {"on": on})                 # off also wipes the scanner's own waiting pictures
    except Exception:  # noqa: BLE001 - not running right now: it starts with the right setting next time
        pass
    if not on:
        a = accountapi.account(svc)
        if a is not None:
            try:
                a.call("POST", "/v1/contrib/clear", {})                      # delete what is waiting on the server
            except Exception:  # noqa: BLE001 - the server removes it itself after 30 days
                pass
    svc.audit("scanner_learn", "on" if on else "off")
    return status(svc)


def upload_batch(svc):
    """Called every few minutes: pull a batch from the scanner, send it, and only then tell the scanner to delete its copy."""
    if not enabled(svc) or scanner.STATE["status"] != "running":
        return 0
    a = accountapi.account(svc)
    if a is None:
        return 0
    got = _scanner(f"/api/contrib/pull?n={BATCH}")
    items = (got or {}).get("items") or []
    if not items:
        return 0
    try:
        res = a.call("POST", "/v1/contrib/upload", {"items": [{"id": i["id"], "card_id": i["card_id"], "game": i.get("game", ""), "kind": i.get("kind", ""), "ts": i.get("ts", 0),
                                                         "jpg_b64": i["jpg_b64"], **({"variant": str(i["variant"])[:40]} if i.get("variant") else {})} for i in items]}, timeout=60)      # variant = the printing the person confirmed (optional; older rows have none)
    except Exception:  # noqa: BLE001 - not ready yet / offline: they stay on this PC (and expire by themselves after 30 days)
        return 0
    res = res if isinstance(res, dict) else {}
    accepted = int(res.get("accepted", len(items)))
    if accepted == 0 and int(res.get("over_quota", 0)) > 0:
        return 0                                       # the person's limit is reached: keep the pictures here (they expire on their own after 30 days)
    _scanner("/api/contrib/ack", "POST", {"ids": [i["id"] for i in items]})          # delivered (any the server refused as invalid are dropped, not resent forever)
    svc.pset("scanner_learn_sent", int(svc.pget("scanner_learn_sent", 0) or 0) + accepted)
    return accepted
