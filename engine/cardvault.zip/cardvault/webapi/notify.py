"""Notifications for the bell in the top bar.  Two lookups, both read-only:
  notify.local   - things worked out on this device: price alerts that fired, wishlist cards that look cheap, goals reached, sets nearly done, milestone badges earned
  notify.friends - things from friends (needs the account and the network): requests, trade proposals and answers, trades waiting for you to update your collection
The screen keeps what has been read; the ids below are stable so the same thing is never announced twice."""
from .registry import ApiError, api


@api("notify.local", quiet=True)
def local(svc):
    items = []
    v = svc.vault
    game = svc.game.name.replace(" (English)", "")
    try:
        from .alerts import alerts_list
        for r in alerts_list(svc)["rows"]:
            if r["hit"]:
                items.append({"id": f"alert:{r['id']}:{r['now']}", "kind": "price", "icon": "🔔", "title": f"Price alert: {r['name']}", "text": f"Now ${r['now']:.2f} - you wanted it {r['dir']} ${r['price']:.2f}",
                              "go": {"page": "value", "store": {"valueTab": "insights"}}, **({"card": r["key"]} if r["type"] == "card" else {})})
    except Exception:  # noqa: BLE001 - one lookup failing must not hide the others
        pass
    try:
        from .planner import wanted
        for r in [x for x in wanted(svc)["rows"] if x["flag"] == "good"][:5]:
            items.append({"id": f"cheap:{r['id']}", "kind": "price", "icon": "♥", "title": f"Wishlist: {r['name']} looks cheap", "text": f"{r['why']} · ${r['price']:.2f}" if r["price"] is not None else r["why"],
                          "go": {"page": "value", "store": {"valueTab": "plan", "planView": "wanted"}}, "card": r["id"]})
    except Exception:  # noqa: BLE001
        pass
    try:
        from .goals import goals_list
        for g in goals_list(svc)["rows"]:
            if g["pct"] >= 100:
                items.append({"id": f"goal:{g['id']}", "kind": "goal", "icon": "🏆", "title": "Goal reached", "text": g.get("name") or g.get("label") or "One of your goals is complete", "go": {"page": "value", "store": {"valueTab": "insights"}}})
    except Exception:  # noqa: BLE001
        pass
    try:
        from .insights import _set_progress
        for sid, nm, h, n in sorted(_set_progress(v), key=lambda x: x[3] - x[2]):
            if n >= 20 and 0.9 <= h / n < 1:
                items.append({"id": f"near:{sid}:{n - h}", "kind": "items", "icon": "◔", "title": f"{nm}: {n - h} to go", "text": f"{h} of {n} cards in {game}", "go": {"page": "lists"}})
            if len([i for i in items if i["kind"] == "items"]) >= 3:
                break
    except Exception:  # noqa: BLE001
        pass
    badges = []
    try:
        from .insights import badges_for
        badges = [{"id": b["id"], "title": b["title"], "icon": b["icon"]} for b in badges_for(svc) if b["done"]]
    except Exception:  # noqa: BLE001
        pass
    return {"items": items, "badges": badges}


@api("notify.friends")
def friends(svc):
    from . import friends as fr
    from .friendtrade import listing
    from .perf import timed
    items = []
    with timed("part", "notify.friends: friends"):
        fl = fr.friends_list(svc)
    for r in fl["requests"]:
        items.append({"id": f"req:{r['username']}", "kind": "friend", "icon": "👋", "title": f"{r['username']} wants to be friends", "text": "Tap to accept or decline", "go": {"page": "friends"}})
    import time
    for f in fl["friends"]:                                                  # somebody who said yes to your request (or you accepted) in the last three days
        if f.get("partial") or (f.get("since") and time.time() - f["since"] < 3 * 86400):
            items.append({"id": f"fnew:{f['username']}", "kind": "friend", "icon": "🤝", "title": f"{f['nick'] or f['username']} is now your friend", "text": "Open their profile, race a set or propose a trade", "go": {"page": "friends"}})
    try:
        with timed("part", "notify.friends: trades"):
            lst = listing(svc)
    except ApiError:
        lst = {"incoming": [], "outgoing": []}
    for p in lst["incoming"]:
        if p["status"] == "open":
            items.append({"id": f"prop:{p['id']}", "kind": "friend", "icon": "⇄", "title": f"Trade proposal from {p['nick']}", "text": f"You give {sum(c['qty'] for c in p['get'])} · you get {sum(c['qty'] for c in p['give'])}", "go": {"page": "friends", "store": {"friendsTab": "trades"}}})
        elif p["status"] == "accepted" and not p["applied"]:
            items.append({"id": f"upd:{p['id']}", "kind": "friend", "icon": "✔", "title": f"Trade with {p['nick']} accepted", "text": "Update your collection when you've swapped", "go": {"page": "friends", "store": {"friendsTab": "trades"}}})
    for p in lst["outgoing"]:
        if p["status"] in ("accepted", "declined", "countered"):
            word = {"accepted": "accepted", "declined": "declined", "countered": "answered with a counter-offer"}[p["status"]]
            items.append({"id": f"reply:{p['id']}:{p['status']}", "kind": "friend", "icon": "⇄" if p["status"] != "declined" else "✖", "title": f"{p['nick']} {word} your proposal",
                          "text": "Update your collection when you've swapped" if p["status"] == "accepted" and not p["applied"] else "", "go": {"page": "friends", "store": {"friendsTab": "trades"}}})
    try:                                                                       # a friend has spare cards from my wishlist, or wants cards I could give (their trade list is shared with me)
        from .tradematch import lists_matches
        with timed("part", "notify.friends: matches"):
            matches = lists_matches(svc)["friends"][:8]
        for m in matches:
            g, t = len(m["get"]), len(m["give"])
            if g or t:
                items.append({"id": f"match:{m['id']}:{g}:{t}", "kind": "friend", "icon": "🎯", "title": f"{m['friend']} can trade with you",
                              "text": (f"They have {g} card{'s' if g != 1 else ''} from your wishlist" if g else "") + (" · " if g and t else "") + (f"you have {t} they want" if t else ""),
                              "go": {"page": "trade"}})
    except ApiError:
        pass
    return {"items": items}
