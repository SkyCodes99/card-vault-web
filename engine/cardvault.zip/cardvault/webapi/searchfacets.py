"""What the all-games search panel offers for the games the person picked.

ONE game: that game's own filters (card kind, attribute, trait, cost ... see gamefacets) plus the types, rarities, artists, dates and prices it has.
SEVERAL games (or all of them): only what they ALL have - the same filter under the same name - so no filter is offered that some of the chosen games could not answer.
"""
import os
import sqlite3

from .. import gamefacets, games as games_mod, raritytiers
from .registry import api
from .search import _games

MEMO_SIZE = 12
ONE_MEMO_SIZE = 40


def _stamp(path):
    """When a list's file last changed (None if it cannot be read): an answer worked out from it holds until then."""
    try:
        return os.path.getmtime(path)
    except OSError:
        return None


# ---------------------------------------------------------------------------------------------------------------- one game
def _read_game(path, game):
    try:
        conn = sqlite3.connect(path, timeout=30)
        try:
            return gamefacets.filters(conn, game), gamefacets.basics(conn, game)
        finally:
            conn.close()
    except sqlite3.Error:
        return None


def one_game(svc, game):
    """(filters, basics) of a game that is on this device, or None: its filters in the order they are shown, and the types / rarities / artists / dates / prices it offers.
    Counting the values of every filter takes a moment on a big list (Magic: most of a second), so each list is read once until its file changes."""
    path = next((p for gid, _name, p in _games(svc) if gid == game), None)
    if not path:
        return None
    memo = svc.__dict__.setdefault("_sf_one", {})
    stamp = _stamp(path)
    if stamp is not None and (game, stamp) in memo:
        return memo[(game, stamp)]
    got = _read_game(path, game)
    if got is not None:
        if len(memo) >= ONE_MEMO_SIZE:
            memo.clear()
        memo[(game, _stamp(path))] = got                      # (reading may have added the filter tables to the file: its time is taken after)
    return got


def _single(svc, game):
    got = one_game(svc, game)
    if got is None:
        return {"defs": [], "game": game, "installed": any(gid == game for gid, _n, _p in _games(svc))}
    defs, basics = got
    return {"defs": defs, "game": game, "installed": True, "typeLabel": games_mod.game_by_id(game).type_label, "voc": gamefacets.vocab(game), **basics}            # (the same options and words the Cards page of this game offers)


# ---------------------------------------------------------------------------------------------------------------- several games
def _added(a, b):
    return {v: a.get(v, 0) + b.get(v, 0) for v in set(a) | set(b)}


def _ranked(key, counts):
    """The values of one filter, most common first (the ordinary printing last)."""
    rows = sorted(({"v": v, "n": n} for v, n in counts.items()), key=lambda x: (-x["n"], x["v"]))
    return [x for x in rows if x["v"] != "Regular"] + [x for x in rows if x["v"] == "Regular"] if key == "printing" else rows


def _merged_filters(per):
    """The filters every game in `per` has under the same key and label, with the values of all of them (counts added up)."""
    shared = None                                            # {(key, label): {value: how many cards}}
    for defs, _basics in per.values():
        mine = {(d["key"], d["label"]): {x["v"]: x["n"] for x in d["values"]} for d in defs}
        shared = mine if shared is None else {k: _added(shared[k], mine[k]) for k in shared if k in mine}
    out = []
    for (key, label), counts in (shared or {}).items():
        values = _ranked(key, counts)
        if len(values) > 1 or key == "printing":
            out.append({"key": key, "label": label, "values": values[:gamefacets.VALUE_LIMIT]})
    return out


def _shared_types(per):
    """(what they call their types, the types) when every one of the games calls its types the same thing ('Color'); otherwise ('Type', [])."""
    labels = {games_mod.game_by_id(g).type_label for g in per}
    if len(labels) != 1:
        return "Type", []
    return labels.pop(), sorted({t for _defs, basics in per.values() for t in gamefacets.type_names(basics["types"])})


def _shared_answer(per, names, away):
    label, types = _shared_types(per) if per else ("Type", [])
    return {"defs": _merged_filters(per), "shared": True, "games": list(per), "away": away, "types": types, "typeLabel": label, "rarities": [], "tiers": raritytiers.TIERS,
            "hasPrices": any(b["hasPrices"] for _d, b in per.values()), "hasDates": any(b["hasDates"] for _d, b in per.values()), "hasArtist": any(b["hasArtist"] for _d, b in per.values()),
            "artistGames": [names[g] for g, (_d, b) in per.items() if b["hasArtist"]]}


def _memo_key(installed, chosen, away):
    """The same answer holds until one of those lists changes (opening every list is slow with many games)."""
    stamps = tuple(_stamp(installed[g][1]) for g in sorted(chosen))
    return None if None in stamps else (tuple(sorted(chosen)), stamps, tuple(away))


def shared(svc, ids):
    """The filters that work for EVERY game in `ids` (none = all).  Games that are not on this device cannot be filtered this way - their lists have no filter tables here - and are named in `away`."""
    installed = {gid: (name, path) for gid, name, path in _games(svc)}
    wanted = ids or [g.id for g in games_mod.GAMES if g.available]
    chosen = [g for g in wanted if g in installed]
    away = [g.name for g in games_mod.GAMES if g.available and not g.own and g.id in wanted and g.id not in installed]
    memo, key = svc.__dict__.setdefault("_sf_memo", {}), _memo_key(installed, chosen, away)
    if key is not None and key in memo:
        return memo[key]
    per = {gid: got for gid in chosen if (got := one_game(svc, gid))}
    answer = _shared_answer(per, {gid: name for gid, (name, _p) in installed.items()}, away)
    if key is not None:
        if len(memo) > MEMO_SIZE:
            memo.clear()
        memo[key] = answer
    return answer


# ---------------------------------------------------------------------------------------------------------------- the API
@api("search.facets", quiet=True)
def search_facets(svc, game="", games=None):
    """One game: its own filters (card type, attribute, trait, cost, special printing...) with how many cards have each value, worked out once per list.  Several games, or none = all: only what they all share."""
    ids = [g for g in (games or []) if isinstance(g, str)] or ([game] if game else [])
    return _single(svc, ids[0]) if len(ids) == 1 else shared(svc, ids)
