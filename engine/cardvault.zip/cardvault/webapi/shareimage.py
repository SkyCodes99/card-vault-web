"""Save a share picture (PNG drawn in the page) to the file the person picked with dialog.save.  Nothing is uploaded anywhere."""
import base64

from .registry import api

MAX_BYTES = 12 * 1024 * 1024


@api("share.saveImage")
def save_image(svc, path, data):
    svc.need_grant(path)
    raw = base64.b64decode(data.split(",", 1)[-1])
    if not raw.startswith(b"\x89PNG") or len(raw) > MAX_BYTES:
        raise ValueError("That is not a picture this app made.")
    with open(path, "wb") as f:
        f.write(raw)
    return {"path": path, "bytes": len(raw)}
