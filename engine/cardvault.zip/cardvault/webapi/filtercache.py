"""The Cards page's filters (types, rarities, the game's own facets, eras, sort orders) - and other things worked out from the card list alone (kept()) - kept in a small file beside the card
list, so opening a game does not work them out again every session (Magic: most of a second, more in the browser).  They come from the card list alone; the file is used only while the list is the same one - same build, same price day, same versions, same
number of cards (all in its meta table) - and this code's VERSION is the same."""
import hashlib
import json
import os
import sqlite3

from .. import gamefacets

FILE = "filters_cache.json"
VERSION = 1


def _key(v):
    try:
        meta = v.conn.execute("SELECT key, value FROM meta ORDER BY key").fetchall()
        n, top = v.conn.execute("SELECT COUNT(*), MAX(rowid) FROM cards").fetchone()
    except sqlite3.Error:
        return None
    text = json.dumps([VERSION, gamefacets.VERSION, v.game, n, top, [list(r) for r in meta]], default=str)
    return hashlib.sha1(text.encode()).hexdigest()


def _file(name):
    return FILE if name == "filters" else f"{name}_cache.json"


def load(v, name="filters"):
    """The saved filters (or other thing), or None when there are none that fit this card list."""
    key = _key(v)
    if key is None:
        return None
    try:
        with open(os.path.join(v.gdir, _file(name)), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    return data.get("filters") if isinstance(data, dict) and data.get("key") == key else None


def save(v, filters, name="filters"):
    """Keep them (never a reason to fail: without the file they are just worked out again)."""
    key = _key(v)
    if key is None:
        return
    path = os.path.join(v.gdir, _file(name))
    try:
        with open(path + ".part", "w", encoding="utf-8") as f:
            json.dump({"key": key, "filters": filters}, f, separators=(",", ":"))
        os.replace(path + ".part", path)
    except OSError:
        pass


def kept(v, name, make):
    """make() - something worked out from the card list alone, as plain JSON - once per card list: in memory while the list's file is unchanged (catalog_fp), and in a file beside it
    between sessions."""
    fp = v.catalog_fp()
    memo = v.__dict__.setdefault("_kept", {})
    hit = memo.get(name)
    if fp is not None and hit is not None and hit[0] == fp:
        return hit[1]
    val = load(v, name)
    if val is None:
        val = make()
        save(v, val, name)
    if fp is not None:
        memo[name] = (fp, val)
    return val
