"""'Complete it' buttons: mark everything still missing from a checklist or a master set as owned in one click - for people who already have all of it.
Every card goes into ONE portfolio that is named in the confirmation (and can be changed there), because portfolios are what checklists read ownership from."""
from .cards import master, with_undo
from .lists import NO_CARD, _from_checklist, progress_of
from .portfolios import MAIN, main_name
from .registry import api
from .service import ApiError


def pf_name(svc, pid):
    """Display name of a portfolio id ('' or 'main' = the main one)."""
    if pid in ("", MAIN, None):
        return main_name(svc)
    for p in svc.vault.portfolios():
        if p["uuid"] == pid:
            return p["name"]
    return main_name(svc)


def _todo(svc, kind, id):
    """-> [(card_id, variant or None)] still missing."""
    if kind == "list":
        _cl, p = progress_of(svc, int(id))
        out = []
        for t in p.tiles:
            if t.owned or t.label == NO_CARD or (t.key and not t.candidates):          # (slot lists - Pokédex, rarity - give the card to tick in `candidates`)
                continue
            cid = (t.card_id if t.card_id in t.candidates else t.candidates[0]) if t.candidates else t.card_id
            if cid:
                out.append((cid, t.variant if _cl["per_variant"] else None))
        return out
    if kind == "master":
        return [(r["id"], r["variant"]) for r in master(svc, id, show="missing")["rows"]]
    raise ApiError("Unknown kind")


@api("complete.options")
def options(svc, kind, id):
    v = svc.vault
    todo = _todo(svc, kind, id)
    target = v.target_pf if v.target_pf is not None else ""
    return {"missing": len(todo), "portfolio": {"id": target or MAIN, "name": pf_name(svc, target)},
            "portfolios": [{"id": MAIN, "name": main_name(svc)}] + [{"id": p["uuid"], "name": p["name"]} for p in v.portfolios()]}


@api("complete.run", mutates=True)
def run(svc, kind, id, portfolio=None):
    v = svc.vault
    todo = _todo(svc, kind, id)
    if not todo:
        return {"count": 0, "portfolio": pf_name(svc, v.target_pf)}
    pid = (portfolio if portfolio is not None else (v.target_pf or MAIN))
    pid = "" if pid == MAIN else pid
    if pid and not any(p["uuid"] == pid for p in v.portfolios()):
        raise ApiError("That portfolio doesn't exist.")
    name = pf_name(svc, pid)
    saved = v.target_pf
    v.target_pf = pid
    ids = list(dict.fromkeys(c for c, _ in todo))

    def go():
        with v.action(f"Completed {len(todo)} card{'s' if len(todo) != 1 else ''} in {name}"):
            for cid, var in todo:
                v.set_variant_owned(cid, var, True) if var else v.set_owned(cid, True)
            v.record_price_history(ids)
        return {"count": len(todo), "portfolio": name}
    try:
        return with_undo(svc, go)
    finally:
        v.target_pf = saved
