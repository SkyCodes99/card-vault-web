"""Trade matching with friends.  You publish TWO short lists to a private, end-to-end encrypted share that only the friends you invite can open: the cards you WANT (your wishlist) and the cards you
have AVAILABLE TO TRADE (your spares, or everything in one portfolio you pick).  Never whole portfolios, never what you paid.  When a friend does the same, this finds the overlap both ways
("you have 4 cards on Sam's wishlist, Sam has 2 on yours") and suggests a fairly priced trade.  It reuses the account sharing (keys, invites, accept) - the server only ever sees ciphertext."""
import base64
import json

from .. import tools
from ..cloud import sharing as sh
from .registry import ApiError, api
from .sharing import _acct, _call, _gk, _inn, _out, pull


def _haves(svc, source):
    """[(card id, qty)] you are willing to trade: your spares (copies beyond the first of each card), or every card in one portfolio."""
    v = svc.vault
    if source and source != "extras":
        saved = v.scope
        v.set_scope([("" if source == "main" else source)])
        try:
            rows = v.conn.execute("SELECT card_id, SUM(qty) AS q FROM lots_s WHERE user_id=? AND game=? AND deleted=0 GROUP BY card_id", (v.user_id, v.game)).fetchall()
        finally:
            v.set_scope(saved)
        return [(r["card_id"], r["q"]) for r in rows if r["q"]]
    return [(r["card_id"], r["extra"]) for r in tools.duplicates(v, 1)]


def rows_for(svc, entry):
    """What goes into the trade share: the info line, one row per wanted card, one per available card."""
    v = svc.vault

    wish, held = sorted(v.wishlist_ids()), _haves(svc, (entry.get("opts") or {}).get("haves"))
    lights = v.card_lights(wish + [cid for cid, _ in held])

    def card(cid, **more):
        c = lights.get(cid) or {}
        return {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": c.get("price_usd"), **more}
    wants = [("wants", cid, card(cid)) for cid in wish if cid in lights]
    haves = [("haves", cid, card(cid, qty=q)) for cid, q in held if cid in lights]
    info = ("meta", "info", {"title": entry["title"], "kind": "trade", "game": svc.game.name, "gameId": getattr(svc.game, "id", ""), "from": svc.pget("cloud_username"),
                             "wants": len(wants), "haves": len(haves)})
    return [info] + wants + haves


def _mine(svc):
    """My own trade share (id, entry) on this device, or (None, None)."""
    for gid, e in _out(svc).items():
        if e.get("kind") == "trade" and e.get("game") == svc.game.id:
            return gid, e
    return None, None


@api("trade.lists.status", quiet=True)
def lists_status(svc):
    gid, e = _mine(svc)
    return {"id": gid, "haves": (e or {}).get("opts", {}).get("haves", "extras") if e else "extras", "wants": len(svc.vault.wishlist_ids()), "spares": len(_haves(svc, "extras")),
            "title": (e or {}).get("title", "")}


@api("trade.lists.publish", mutates=True)
def lists_publish(svc, haves="extras"):
    """Publish (or refresh) your wants + available-to-trade lists.  The first time this makes the private share; invite friends to it from Share > With people."""
    a = _acct(svc)
    gid, e = _mine(svc)
    if haves != "extras" and not any(p["uuid"] == haves for p in svc.vault.portfolios()) and haves != "main":
        raise ApiError("That portfolio doesn't exist.")

    def go():
        nonlocal gid, e
        if not e:
            sh.ensure_keypair(a)
            key, gid = sh.new_group_key(), sh.new_id()
            title = f"Trade lists - {svc.game.name}"
            a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": title, "from": svc.pget("cloud_username"), "kind": "trade", "gameId": svc.game.id}, "group/name"),
                                          "label_blob": sh.seal_json(key, {"label": "owner"}, "group/label")})
            e = {"key": base64.b64encode(key).decode(), "title": title, "portfolios": [], "showValue": False, "kind": "trade", "game": svc.game.id}
        e["opts"] = {"haves": haves}
        o = _out(svc)
        o[gid] = e
        svc.pset("share_out", json.dumps(o))
        rows = rows_for(svc, e)
        have = sh.pull_rows(a, gid, _gk(e))
        mine = {(c, i) for c, i, _ in rows}
        gone = [(c, i, None) for (c, i) in have if (c, i) not in mine and c in ("wants", "haves")]
        sh.push_rows(a, gid, _gk(e), rows + gone)
        return {"id": gid, "wants": sum(1 for r in rows if r[0] == "wants"), "haves": sum(1 for r in rows if r[0] == "haves")}
    return _call(go)


def _fair_trade(give, get):
    """A suggested trade from the two overlap lists: fill the lighter side one card at a time (most valuable first) until the two totals are as close as they can get.
    Cards with no price count as $0 and are flagged, never guessed."""
    give, get = sorted(give, key=lambda c: -(c["usd"] or 0)), sorted(get, key=lambda c: -(c["usd"] or 0))
    g, r, gt, rt = [], [], 0.0, 0.0
    gi, ri = 0, 0
    while gi < len(give) or ri < len(get):
        if (gt <= rt and gi < len(give)) or ri >= len(get):
            c = give[gi]; gi += 1
            if abs((gt + (c["usd"] or 0)) - rt) <= abs(gt - rt) + max(1.0, 0.1 * max(gt, rt)) or not g:
                g.append(c); gt += c["usd"] or 0
        else:
            c = get[ri]; ri += 1
            if abs((rt + (c["usd"] or 0)) - gt) <= abs(rt - gt) + max(1.0, 0.1 * max(gt, rt)) or not r:
                r.append(c); rt += c["usd"] or 0
    return {"give": g, "get": r, "giveTotal": round(gt, 2), "getTotal": round(rt, 2), "diff": round(gt - rt, 2),
            "fair": abs(gt - rt) <= max(1.0, 0.1 * max(gt, rt)), "noPrice": sum(1 for c in g + r if c["usd"] is None)}


@api("trade.lists.matches")
def lists_matches(svc):
    """For each friend who shared their trade lists with you: what you can give them (your available cards that are on their wishlist), what they can give you, and a suggested trade."""
    a = _acct(svc)
    v = svc.vault
    my_wants = set(v.wishlist_ids())
    mine = {cid: q for cid, q in _haves(svc, (_mine(svc)[1] or {}).get("opts", {}).get("haves", "extras"))}
    out = []

    def go():
        for gid, e in _inn(svc).items():
            if e.get("kind") != "trade":
                continue
            rows = pull(svc, a, gid, _gk(e))
            info = rows.get(("meta", "info")) or {}
            if info.get("gameId") and info["gameId"] != svc.game.id:
                continue
            their_wants = {i: d for (c, i), d in rows.items() if c == "wants"}
            their_haves = {i: d for (c, i), d in rows.items() if c == "haves"}
            give = [{**their_wants[i], "qty": mine[i]} for i in their_wants if i in mine]                            # I have it, they want it
            get = [{**their_haves[i]} for i in their_haves if i in my_wants]                                         # they have it, I want it
            out.append({"id": gid, "friend": e.get("from") or info.get("from") or "a friend", "give": give, "get": get, "theirWants": len(their_wants), "theirHaves": len(their_haves),
                        "suggest": _fair_trade(give, get) if (give or get) else None})
    _call(go)
    out.sort(key=lambda x: -(len(x["give"]) + len(x["get"])))
    return {"friends": out, "mine": {"wants": len(my_wants), "haves": len(mine)}}
