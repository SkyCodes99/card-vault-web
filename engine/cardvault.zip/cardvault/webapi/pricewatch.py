"""Price alerts that run after the daily prices (cardvault/pricewatch.py): Settings > Price alerts, the price for a wishlist label, and the alerts that have fired (they also show in the bell)."""
from .. import pricewatch as pw
from .. import wishlabels
from .registry import ApiError, api


@api("pricewatch.get", quiet=True)
def get(svc):
    """-> {on, pct, days, min, labels: [{id, name, price}] (priority order, price None = none set), inbox: [alert, ...newest first]}"""
    cfg = pw.load(svc)
    labs = wishlabels.of_game(svc, svc.vault.game)[0] if svc.vault else []
    return {"on": cfg["on"], "pct": cfg["pct"], "days": cfg["days"], "min": cfg["min"], "defaults": pw.DEFAULTS,
            "labels": [{"id": x["id"], "name": x["name"], "price": cfg["labels"].get(x["id"])} for x in labs], "inbox": cfg["inbox"]}


@api("pricewatch.set", mutates=True)
def set_rule(svc, on=None, pct=None, days=None, min=None):
    """Turn the default 'owned card moved a lot' rule on / off and tune it (pct %, over 1 or 7 days, ignoring cards under `min` dollars)."""
    cfg = pw.load(svc)
    try:
        if pct is not None and not (1 <= float(pct) <= 1000):
            raise ValueError
        if min is not None and float(min) < 0:
            raise ValueError
    except (TypeError, ValueError):
        raise ApiError("Type a percent between 1 and 1000, and a price of zero or more.")
    new = pw.normalize({**cfg, **{k: v for k, v in (("on", on), ("pct", pct), ("days", days), ("min", min)) if v is not None}})
    pw.save(svc, {**cfg, **{k: new[k] for k in ("on", "pct", "days", "min")}})
    return {"ok": True}


@api("pricewatch.label", mutates=True)
def set_label(svc, label, price=None):
    """Tell me when a wishlist card with this label is at or below `price` (USD; None / 0 takes the price off)."""
    if label not in {x["id"] for x in wishlabels.of_game(svc, svc.vault.game)[0]}:
        raise ApiError("That label is gone - pick another.")
    cfg = pw.load(svc)
    try:
        p = round(float(price), 2) if price not in (None, "") else 0
    except (TypeError, ValueError):
        raise ApiError("Type the price to watch for.")
    if p > 0:
        cfg["labels"][label] = p
    else:
        cfg["labels"].pop(label, None)
    pw.save(svc, cfg)
    return {"ok": True}


@api("pricewatch.check", mutates=True)
def check_now(svc):
    """Run the rules now (they also run by themselves after the daily prices)."""
    return {"added": pw.check(svc)}


@api("pricewatch.clear", mutates=True)
def clear(svc):
    """Empty the list of alerts that have fired (the rules stay as they are).  Undoable."""
    from .undoext import undoable
    cfg = pw.load(svc)
    cfg["inbox"] = []
    return undoable(svc, "Cleared the fired price alerts", lambda: pw.save(svc, cfg), keys=[pw.KEY])
