"""The website's online reads (3.50.136 web speed, lane O; docs/speed136_web_design.md 3.3): when a game's card list is NOT kept on this device ("Keep for offline use" off),
the page asks Card Data's query API for the catalog part of a list or a card (ui/src/online/) and these methods add what is YOURS, here on the device.

Nothing here goes anywhere: the page hands the engine the catalog rows it got from Card Data, the engine adds copies, wishlist, conditions, the picked price, what your copies are worth,
what you left out of a set - the same code the engine's own cards.list / card.detail use (cards.mine_rows, cards.mine_detail), so the two answers cannot drift apart.  Owned ids and every
other collection fact stay in this engine; the page never puts them in a Card Data address (tests/online_router.mjs checks every address it builds)."""
from .. import carddata, checklists, runtime
from .registry import api
from . import cards, gamesapi

MAX_ROWS = 5000                       # (the biggest set page answer the page hands over at once: a set is all of its pages)


def _query_base(svc):
    """Card Data's query API: the same host the card lists come from (cfg carddata_url: Card Data, or this computer's test server), at /q/v1."""
    from urllib.parse import urlparse
    u = urlparse((svc.cfg.get("carddata_url") or carddata.BASE).strip())
    return f"{u.scheme}://{u.netloc}/q/v1" if u.scheme in ("http", "https") and u.netloc else f"{carddata.BASE}/q/v1"


@api("online.state", quiet=True)
def state(svc):
    """Which way the page reads the open game's catalog: online (Card Data) unless its list is kept on this device.  The desktop app always has every list (offline: True)."""
    g = svc.game
    return {"game": g.id, "offline": gamesapi.offline_on(svc, g.id), "web": runtime.IN_BROWSER, "base": _query_base(svc), "pokemon": bool(g.pokemon)}


def _show(v, ids, show, sort):
    """cards.list's show / owned-first filters (as Vault.query_cards applies them on top of its order) on a list of ids."""
    if show in ("owned", "missing"):
        have = v.owned_map()
        ids = [i for i in ids if (i in have) == (show == "owned")]
    elif show == "wishlist":
        want = v.wishlist_ids()
        ids = [i for i in ids if i in want]
    elif show == "spares":
        two = {r[0] for r in v.conn.execute("SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 GROUP BY card_id HAVING SUM(qty)>=2", (v.user_id, v.game))}
        ids = [i for i in ids if i in two]
    if sort in ("owned", "unowned"):
        have = v.owned_map()
        mine, rest = [i for i in ids if i in have], [i for i in ids if i not in have]
        ids = mine + rest if sort == "owned" else rest + mine
    return ids


@api("online.list", quiet=True)
def online_list(svc, rows, ids=None, show="all", sort="default", set_id=None, set_ids=None, limit=1500, text="", total=None, whole=False):
    """cards.list from Card Data rows: `rows` = the catalog rows of the cards answering (dicts, the engine's row fields without yours), `ids` = their order (all of them for a set,
    the pages read so far for the whole list), `set_ids` = every card of the set (its progress), `total` = how many answer in all (the whole list: Card Data counted them),
    `whole` = the whole list with nothing typed or chosen (its owned count is every card you own).  -> cards.list's answer.  {"engine": True} = this question needs the engine's
    own list (a search word that is also a storage place: cards.list adds the cards kept there)."""
    v = svc.vault
    words = (text or "").strip()
    if words and cards._place_ids(v, words):
        return {"engine": True}
    by = {r["id"]: r for r in rows[:MAX_ROWS] if isinstance(r, dict) and isinstance(r.get("id"), str)}
    order = [i for i in (ids if ids is not None else list(by)) if i in by]
    left_n, excl = 0, set()
    if set_id:                                          # cards the person left out of this set: out of the list, the totals and the progress ("Left out" shows them)
        excl = v.excluded_cards(set_id)
        left_n = len(excl)
        order = [i for i in order if (i in excl) == (show == "left")]
    order = _show(v, order, show, sort)
    pos = {c for c, q in svc.owned.items() if q > 0}
    out = {"rows": cards.mine_rows(svc, v, [dict(by[i]) for i in order[:max(0, int(limit))]]), "total": len(order), "owned": sum(1 for i in order if i in pos),
           "sections": None, "leftOut": left_n}
    if not set_id and total is not None and int(total) > len(order):
        out["total"] = int(total)
        if whole:
            out["owned"] = len(pos)
        else:
            out["ownedPartial"] = True                 # (owned among the cards read so far: the rest of a very big answer is not read just to count yours)
    if set_id:
        prog = checklists.progress_for_cards(v, [i for i in (set_ids or order) if i not in excl])
        out["progress"] = {"owned": prog.owned, "total": prog.total, "pct": prog.pct}
    return out


@api("online.card", quiet=True)
def online_card(svc, card):
    """card.detail from Card Data's card answer (its catalog part) + what is yours (cards.mine_detail)."""
    if not isinstance(card, dict) or not isinstance(card.get("id"), str):
        from .registry import ApiError
        raise ApiError("card not found")
    out = {k: x for k, x in card.items() if k not in ("game", "cv", "pv")}
    mine = cards.mine_detail(svc, card["id"], card.get("name") or "", card.get("setId"), card.get("priceMain"), card.get("priceMainKind") or "", card.get("tcg") or "", card.get("category") or "")
    out.update(mine)
    if mine["priceUsd"] is not None:
        out["noPriceWhy"] = ""
    out.setdefault("key", "")                          # (a comic's key-issue note, the cover list of a comic and a video game's versions come with the list: kept on this device only)
    out.setdefault("covers", [])
    out.setdefault("versions", [])
    out.setdefault("seriesGames", None)
    return out
