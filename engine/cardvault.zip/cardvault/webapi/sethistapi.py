"""card.setHistory: the market price history of a card you do not track (no saved history of its own), from Card Data's per-set file (cardvault/sethistory.py).
The card panel asks for it after it has opened; a file still on its way answers {"pending": true} and the panel asks again a moment later."""
from .. import pricestats, sethistory
from .registry import ApiError, api


def merged(own, market):
    """Card Data's points with your own saved prices over them (yours win on the same day).  Both are [{"day", "usd"}]."""
    by = {p["day"]: p["usd"] for p in market}
    by.update({p["day"]: p["usd"] for p in own if p.get("usd") is not None})
    return [{"day": d, "usd": by[d]} for d in sorted(by)]


@api("card.setHistory", quiet=True)
def set_history(svc, id, get=None):
    v = svc.vault
    c = v.card(id)
    if not c:
        raise ApiError("card not found")
    own = [{"day": d, "usd": usd} for d, usd, _ in v.price_history(id) if usd is not None]
    if len(own) >= 2 or not c["set_id"]:
        return {"history": [], "stats": None, "pending": False}
    market, pending = sethistory.for_card(svc, v.game, c["set_id"], id, get=get)
    hist = merged(own, market) if market else []
    kind = c["price_kind"] if "price_kind" in c.keys() else ""
    return {"history": hist, "stats": pricestats.stats(hist, kind) if hist else None, "pending": pending}
