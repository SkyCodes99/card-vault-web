"""Friends.  Add a collector by username; they accept; from then on you each see the other's small PROFILE (what you both agreed to share) and everything else that works between friends
(trade lists, matches) flows to them without more inviting.

How it works, with no new server part: your profile is one private, end-to-end encrypted share (kind "friend") that only your friends can open.  Adding a friend = inviting them to it.
When they accept they invite you to theirs - two shares make one friendship.  A friend request therefore is just an offer; the server only ever holds ciphertext.

What a profile holds is your choice (Friends > Privacy): the counts of cards for each game you have visited, the total value (off by default), and up to 12 favourite cards.
Never portfolios, never what you paid.  Honest limits: a profile refreshes when you open Friends; a removed friend keeps what they already downloaded."""
import base64
import json
import time

from ..cloud import sharing as sh
from .registry import ApiError, api
from .sharing import _acct, _call, _gk, _inn, _label, _out

PRIVACY = {"stats": True, "value": False, "favs": True, "tradelists": True}
MAX_FAVS = 12


def _book(svc):
    try:
        d = json.loads(svc.pget("friends") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _save(svc, d):
    svc.pset("friends", json.dumps(d))


def _privacy(svc):
    try:
        p = json.loads(svc.pget("friend_privacy") or "{}")
    except ValueError:
        p = {}
    return {**PRIVACY, **(p if isinstance(p, dict) else {})}


def _favs(svc):
    try:
        d = json.loads(svc.pget("friend_favs") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}                                # {gameId: [card ids]}


def _norm(name):
    return (name or "").strip().lstrip("@").lower()


def _mine(svc):
    for gid, e in _out(svc).items():
        if e.get("kind") == "friend":
            return gid, e
    return None, None


def rows_for(svc, entry):
    """The profile rows for the CURRENT game; other games' rows already in the share are left alone."""
    v, priv = svc.vault, _privacy(svc)
    gid = svc.game.id
    rows = []
    if priv["stats"]:
        s = v.conn.execute("SELECT COUNT(DISTINCT l.card_id) AS u, COALESCE(SUM(l.qty),0) AS n, COALESCE(SUM(l.qty*c.price_usd),0) AS usd FROM lots_s l JOIN cards c ON c.id=l.card_id "
                           "WHERE l.user_id=? AND l.game=? AND l.deleted=0", (v.user_id, v.game)).fetchone()
        rows.append(("stats", gid, {"game": svc.game.name, "gameId": gid, "unique": s["u"], "cards": s["n"], "usd": round(s["usd"], 2) if priv["value"] else None}))
    if priv["favs"]:
        chosen = _favs(svc).get(gid)
        if chosen is None:                                                  # nothing picked yet: the most valuable cards you own
            chosen = [r["id"] for r in v.top_cards(6)]
        for i, cid in enumerate(chosen[:MAX_FAVS]):
            c = v.card_light(cid)
            if c:
                rows.append(("favs", f"{gid}:{cid}", {"id": cid, "gameId": gid, "game": svc.game.name, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""),
                                                      "usd": c.get("price_usd") if priv["value"] else None, "pos": i}))
    info = ("meta", "info", {"title": "Friend profile", "kind": "friend", "from": svc.pget("cloud_username"), "at": time.time()})
    return [info] + rows


def _publish_profile(svc, a):
    """Make the profile share if it isn't there yet, then refresh this game's rows (and drop this game's rows that are switched off)."""
    gid, e = _mine(svc)
    if not e:
        sh.ensure_keypair(a)
        key, gid = sh.new_group_key(), sh.new_id()
        title = "Friend profile"
        a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": title, "from": svc.pget("cloud_username"), "kind": "friend"}, "group/name"),
                                      "label_blob": sh.seal_json(key, {"label": "owner"}, "group/label")})
        e = {"key": base64.b64encode(key).decode(), "title": title, "portfolios": [], "showValue": False, "kind": "friend"}
        o = _out(svc)
        o[gid] = e
        svc.pset("share_out", json.dumps(o))
    key = _gk(e)
    rows = rows_for(svc, e)
    have = sh.pull_rows(a, gid, key)
    mine = {(c, i) for c, i, _ in rows}
    me = svc.game.id
    gone = [(c, i, None) for (c, i) in have if (c, i) not in mine and ((c == "stats" and i == me) or (c == "favs" and i.startswith(me + ":")))]
    sh.push_rows(a, gid, key, rows + gone)
    return gid, e


def _invite(svc, a, gid, entry, name):
    """Invite `name` to one of MY shares; 'they already have it' is fine."""
    from .sharing import invite
    try:
        invite(svc, gid, name)
    except ApiError as ex:
        if "already have" not in str(ex):
            raise


def _incoming(a, svc):
    """Offers addressed to me, with their kind: [{id, from, kind, title}]."""
    from .sharing import offers
    return offers(svc)


def _sync(svc, a):
    """The friendship housekeeping, safe to run again and again:
    - a friend request from someone I already asked = they said yes -> accept it
    - a friend request I accepted by hand -> invite them back so the friendship is two-way
    - trade-list offers from a mutual friend -> accept; and my own trade lists go to every mutual friend."""
    from .sharing import accept
    book = _book(svc)
    gid, entry = _publish_profile(svc, a)
    offs = _incoming(a, svc)
    changed = False
    for o in offs:
        u = _norm(o["from"])
        f = book.get(u)
        if f and f.get("blocked"):
            continue
        if o.get("kind") == "friend" and f and f.get("out") and not f.get("in"):
            r = accept(svc, o["id"])
            f["in"], f["since"] = r["id"], time.time()
            changed = True
        elif o.get("kind") == "trade" and f and f.get("out") and f.get("in"):
            accept(svc, o["id"])
    for u, f in list(book.items()):
        if f.get("in") and not f.get("out") and not f.get("blocked"):      # I accepted their request: ask them back
            _invite(svc, a, gid, entry, u)
            f["out"], f["since"] = True, f.get("since") or time.time()
            changed = True
        if f.get("in") and f.get("out") and not f.get("blocked") and _privacy(svc)["tradelists"]:
            for tgid, te in _out(svc).items():
                if te.get("kind") == "trade" and tgid not in f.setdefault("trade", []):
                    try:
                        _invite(svc, a, tgid, te, u)
                        f["trade"].append(tgid)
                        changed = True
                    except ApiError:
                        pass
    if changed:
        _save(svc, book)
    return book, offs


def _row(u, f, now_in):
    if f.get("blocked"):
        state = "blocked"
    elif f.get("in") and f.get("out"):
        state = "friends"
    elif f.get("out"):
        state = "waiting"                                                  # I asked; they haven't answered yet
    else:
        state = "request" if now_in else "other"
    return {"username": u, "nick": f.get("nick", ""), "state": state, "since": f.get("since")}


@api("friends.list")
def friends_list(svc, _t=None):
    """Everything the Friends screen shows: my friends, requests waiting for me, requests I sent."""
    a = _acct(svc)
    out = {"friends": [], "requests": [], "sent": [], "blocked": [], "privacy": _privacy(svc), "me": svc.pget("cloud_username") or ""}

    def go():
        book, offs = _sync(svc, a)
        reqs = {}
        for o in offs:
            u = _norm(o["from"])
            if o.get("kind") == "friend" and not (book.get(u) or {}).get("blocked"):
                reqs[u] = o["id"]
        for u, f in sorted(book.items()):
            r = _row(u, f, u in reqs)
            if r["state"] == "friends":
                out["friends"].append(r)
            elif r["state"] == "waiting":
                out["sent"].append(r)
            elif r["state"] == "blocked":
                out["blocked"].append(r)
        for u, oid in reqs.items():
            if not (book.get(u) or {}).get("in"):
                out["requests"].append({"username": u, "offer": oid})
    _call(go)
    return out


@api("friends.add", mutates=True)
def friends_add(svc, username):
    a = _acct(svc)
    u = _norm(username)
    if not u:
        raise ApiError("Type their username.")
    if u == _norm(svc.pget("cloud_username")):
        raise ApiError("That's you!")
    book = _book(svc)
    if (book.get(u) or {}).get("blocked"):
        raise ApiError("You blocked them - unblock them first.")

    def go():
        gid, entry = _publish_profile(svc, a)
        _invite(svc, a, gid, entry, u)
        f = book.setdefault(u, {})
        f["out"] = True
        _save(svc, book)
        for o in _incoming(a, svc):                                         # they had already asked me: this is a yes
            if _norm(o["from"]) == u and o.get("kind") == "friend" and not f.get("in"):
                from .sharing import accept
                f["in"], f["since"] = accept(svc, o["id"])["id"], time.time()
                _save(svc, book)
        return {"state": "friends" if f.get("in") else "waiting"}
    return _call(go)


@api("friends.accept", mutates=True)
def friends_accept(svc, offer, username):
    a = _acct(svc)
    u = _norm(username)

    def go():
        from .sharing import accept
        r = accept(svc, offer)
        book = _book(svc)
        f = book.setdefault(u, {})
        f["in"], f["since"] = r["id"], time.time()
        _save(svc, book)
        _sync(svc, a)
        return True
    return _call(go)


@api("friends.decline", mutates=True)
def friends_decline(svc, offer, block=False, username=""):
    from .sharing import decline
    decline(svc, offer)
    if block and username:
        book = _book(svc)
        book.setdefault(_norm(username), {})["blocked"] = True
        _save(svc, book)
    return True


@api("friends.remove", mutates=True)
def friends_remove(svc, username, block=False):
    """Stop being friends: they lose my profile, I leave theirs, my trade lists stop going to them."""
    a = _acct(svc)
    u = _norm(username)
    book = _book(svc)
    f = book.get(u)
    if f is None:
        raise ApiError("They aren't on your list.")

    def go():
        gid, entry = _mine(svc)
        mine_groups = [g for g in [gid] + list(f.get("trade", [])) if g]
        for g in mine_groups:
            e = _out(svc).get(g)
            try:
                for m in a.call("GET", f"/v1/groups/{g}/members").get("members", []):
                    if e and _norm(_label(e, m)) == u:
                        a.call("DELETE", f"/v1/groups/{g}/members/{m['id']}")
                for x in a.call("GET", f"/v1/groups/{g}/offers").get("offers", []):
                    if _norm(x["username"]) == u:
                        a.call("DELETE", f"/v1/groups/{g}/offers/{x['id']}")
            except Exception:  # noqa: BLE001 - the share may be gone already
                pass
        from .sharing import leave
        i = _inn(svc)
        for g, e in list(i.items()):
            if _norm(e.get("from")) == u and e.get("kind") in ("friend", "trade"):
                try:
                    leave(svc, g)
                except ApiError:
                    pass
    _call(go)
    if block:
        book[u] = {"blocked": True}
    else:
        book.pop(u, None)
    _save(svc, book)
    return True


@api("friends.unblock", mutates=True)
def friends_unblock(svc, username):
    book = _book(svc)
    book.pop(_norm(username), None)
    _save(svc, book)
    return True


@api("friends.nick", mutates=True)
def friends_nick(svc, username, nick=""):
    book = _book(svc)
    f = book.get(_norm(username))
    if not f:
        raise ApiError("They aren't on your list.")
    f["nick"] = (nick or "").strip()[:40]
    _save(svc, book)
    return True


@api("friends.privacy.set", mutates=True)
def privacy_set(svc, **kw):
    p = _privacy(svc)
    for k in PRIVACY:
        if k in kw:
            p[k] = bool(kw[k])
    svc.pset("friend_privacy", json.dumps(p))
    a = _acct(svc)
    _call(lambda: _publish_profile(svc, a))
    return p


@api("friends.favs.get", quiet=True)
def favs_get(svc):
    """My favourite cards for the current game (what friends see), plus the cards I could pick from."""
    v = svc.vault
    chosen = _favs(svc).get(svc.game.id)
    auto = chosen is None
    if auto:
        chosen = [r["id"] for r in v.top_cards(6)]
    from .cards import img
    cards = []
    for cid in chosen:
        c = v.card_light(cid)
        if c:
            r = v.conn.execute("SELECT set_id FROM cards WHERE id=?", (cid,)).fetchone()
            cards.append({"id": cid, "name": c.get("name"), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "pic": img(cid, r["set_id"]) if r else ""})
    return {"auto": auto, "cards": cards, "max": MAX_FAVS}


@api("friends.favs.set", mutates=True)
def favs_set(svc, ids):
    ids = [i for i in dict.fromkeys(ids or []) if svc.vault.card_light(i)][:MAX_FAVS]
    d = _favs(svc)
    d[svc.game.id] = ids
    svc.pset("friend_favs", json.dumps(d))
    a = _acct(svc)
    _call(lambda: _publish_profile(svc, a))
    return len(ids)


@api("friends.profile", quiet=True)
def profile(svc, username):
    """A friend's profile + how our collections line up (trade matches for the current game)."""
    a = _acct(svc)
    u = _norm(username)
    g = next((g for g, e in _inn(svc).items() if e.get("kind") == "friend" and _norm(e.get("from")) == u), None)
    if not g:
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    e = _inn(svc)[g]
    from .cards import img
    conn = svc.vault.conn

    def go():
        rows = sh.pull_rows(a, g, _gk(e))
        stats = [d for (c, _), d in rows.items() if c == "stats"]
        favs = sorted((d for (c, _), d in rows.items() if c == "favs"), key=lambda d: (d.get("game") or "", d.get("pos", 0)))
        for d in favs:
            r = conn.execute("SELECT set_id FROM cards WHERE id=?", (d["id"],)).fetchone() if d.get("gameId") == svc.game.id else None
            d["pic"] = img(d["id"], r["set_id"]) if r else ""
        return {"username": u, "nick": (_book(svc).get(u) or {}).get("nick", ""), "stats": sorted(stats, key=lambda s: -(s.get("cards") or 0)), "favs": favs,
                "since": (_book(svc).get(u) or {}).get("since")}
    out = _call(go)
    try:
        from .tradematch import lists_matches
        m = lists_matches(svc)
        out["match"] = next((x for x in m["friends"] if _norm(x["friend"]) == u), None)
    except ApiError:
        out["match"] = None
    return out
