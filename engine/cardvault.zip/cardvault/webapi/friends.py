"""Friends.  Add a collector by username; they accept; from then on you each see the other's small PROFILE (what you both agreed to share) and everything else that works between friends
(trade lists, matches) flows to them without more inviting.

How it works, with no new server part: your profile is one private, end-to-end encrypted share (kind "friend") that only your friends can open.  Adding a friend = inviting them to it.
When they accept they invite you to theirs - two shares make one friendship.  A friend request therefore is just an offer; the server only ever holds ciphertext.

What a profile holds is your choice (Friends > Privacy): the counts of cards for each game you have visited, the total value (off by default), and up to 12 favourite cards.
Never portfolios, never what you paid.  Honest limits: a profile refreshes when you open Friends; a removed friend keeps what they already downloaded."""
import base64
import json
import re
import time

from .. import wishlist
from ..cloud import sharing as sh
from .registry import ApiError, api
from .sharing import _acct, _call, _gk, _inn, _label, _out, pull

PRIVACY = {"stats": True, "value": False, "favs": True, "tradelists": True, "badges": True, "activity": False, "sets": False,
           "collection": False, "wishlist": False, "portfolios": False, "sealed": False, "paid": False, "full": False, "presence": True, "card": True, "best_paid": False}
BEST_TITLE = "Best friends profile"                                  # the second profile share, opened only by the friends I made BEST friends: it always carries everything (see _privacy_best)
FULL_ON = ("stats", "value", "favs", "tradelists", "badges", "activity", "sets", "collection", "wishlist", "portfolios", "sealed")   # what "Full view" switches on ("paid" stays its own choice)
MAX_COLL = 8000                                                      # cards shown to a friend per game (a huge collection is cut here)
MAX_FAVS = 12


def _other_game_pics(svc, gid, ids):
    """{card id: (picture address, today's price)} for cards of a game that is NOT the one open, read straight from that game's card list on this device (read-only; nothing when it isn't
    downloaded here)."""
    import sqlite3
    from ..db import picture_url
    from .tradeany import reader
    out, ids = {}, list(ids)
    with reader(svc, gid) as conn:
        if conn is None or not ids:
            return out
        try:
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                for r in conn.execute(f"SELECT id, image_base, price_usd FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                    out[r[0]] = ((picture_url(r[1], "low") if gid.startswith("pokemon") else r[1]) if r[1] else "", r[2])
        except sqlite3.Error:
            pass
    return out


def _add_pics(svc, items):
    """Give each card of a friend's list its picture: the open game's cards the usual way, every other game's from that game's own card list, and failing that the picture address the
    friend's app sent along (newer versions send it with the favourites).  The price becomes today's price from my own card list when it has the card (the friend's copy can be days old)."""
    from .cards import img
    conn, cur = svc.vault.conn, svc.game.id
    others = {}
    for d in items:
        if d.get("gameId") != cur:
            others.setdefault(d.get("gameId") or "", set()).add(d["id"])
    found = {gid: _other_game_pics(svc, gid, ids) for gid, ids in others.items() if gid}
    for d in items:
        sent = d.get("pic") if isinstance(d.get("pic"), str) and d["pic"].startswith("https://") else ""
        if d.get("gameId") == cur:
            r = conn.execute("SELECT set_id, price_usd FROM cards WHERE id=?", (d["id"],)).fetchone()
            d["pic"] = (img(d["id"], r["set_id"]) if r else "") or sent
            usd = r["price_usd"] if r else None
        else:
            pic, usd = found.get(d.get("gameId") or "", {}).get(d["id"]) or ("", None)
            d["pic"] = pic or sent
        if usd is not None:
            d["usd"] = round(usd, 2)


def _book(svc):
    try:
        d = json.loads(svc.pget("friends") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _save(svc, d):
    svc.pset("friends", json.dumps(d))


def _privacy_raw(svc):
    """The choices as saved (what each switch was set to), without "Full view" applied on top."""
    try:
        p = json.loads(svc.pget("friend_privacy") or "{}")
    except ValueError:
        p = {}
    return {**PRIVACY, **(p if isinstance(p, dict) else {})}


def _privacy(svc):
    p = _privacy_raw(svc)
    if p.get("full"):                                                # the ultimate switch: everything a friend can be shown, except what you paid unless you also chose that
        p.update({k: True for k in FULL_ON})
    return p


def _privacy_best(svc):
    """What a BEST friend sees: everything a friend can be shown (every portfolio, values, whole collection, wishlist, sealed, set progress, activity ...).  What I paid stays its own choice (best_paid)."""
    raw = _privacy_raw(svc)
    p = {**raw, **{k: True for k in FULL_ON}, "presence": True, "card": True, "full": True}
    p["paid"] = bool(raw.get("best_paid"))
    return p


BANNERS = ("blue", "purple", "green", "orange", "pink", "teal", "gold", "dark")


def _card_prefs(svc):
    try:
        d = json.loads(svc.pget("profile_card") or "{}")
    except ValueError:
        d = {}
    d = d if isinstance(d, dict) else {}
    return {"bio": str(d.get("bio") or "")[:160], "tagline": str(d.get("tagline") or "")[:40], "banner": d.get("banner") if d.get("banner") in BANNERS else "blue",
            "favGame": str(d.get("favGame") or "")[:40]}


def _card_row(svc):
    """What friends see on my profile card: picture, banner colour, a line about me.  Empty when "Picture and about me" is switched off."""
    if not _privacy(svc).get("card", True):
        return {"avatar": "", "bio": "", "tagline": "", "banner": "blue", "favGame": ""}
    return {**_card_prefs(svc), "avatar": svc.pget("avatar") or ""}


@api("profile.card.get", quiet=True)
def card_get(svc):
    return {**_card_prefs(svc), "avatar": svc.pget("avatar") or "", "banners": list(BANNERS), "shared": bool(_privacy(svc).get("card", True))}


@api("profile.card.set", mutates=True)
def card_set(svc, bio=None, tagline=None, banner=None, favGame=None):
    d = _card_prefs(svc)
    if bio is not None:
        d["bio"] = str(bio).strip()[:160]
    if tagline is not None:
        d["tagline"] = str(tagline).strip()[:40]
    if banner is not None:
        if banner not in BANNERS:
            raise ApiError("Pick one of the banner colours.")
        d["banner"] = banner
    if favGame is not None:
        d["favGame"] = str(favGame).strip()[:40]
    svc.pset("profile_card", json.dumps(d))
    svc._prof_at = 0                                                  # republish my profile at the next look so friends see it soon
    return card_get(svc)


def _favs(svc):
    try:
        d = json.loads(svc.pget("friend_favs") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}                                # {gameId: [card ids]}


def _norm(name):
    return (name or "").strip().lstrip("@").lower()


def _mine(svc, tier=""):
    """My friend profile share: the ordinary one (tier "") or the best-friends one (tier "best")."""
    for gid, e in _out(svc).items():
        if e.get("kind") == "friend" and (e.get("tier") or "") == tier:
            return gid, e
    return None, None


def _share_ids(svc):
    """The portfolios friends may see (database ids; '' is the main one).  Empty = all of them."""
    raw = _privacy_raw(svc).get("pf_share")
    if not isinstance(raw, list):
        return []
    from .portfolios import _db_id
    return [_db_id(i) for i in raw]


def rows_for(svc, entry, tier=""):
    """The profile rows for the CURRENT game; other games' rows already in the share are left alone.  What is shown comes from the portfolios chosen under "Which portfolios" - never from
    whatever happens to be on screen at that moment.  tier "best": everything, from every portfolio."""
    v = svc.vault
    saved, tp, share = list(v.scope or []), v.target_pf, ([] if tier == "best" else _share_ids(svc))
    v.set_scope(share)
    try:
        return _rows_for(svc, entry, share, tier)
    finally:
        v.set_scope(saved)
        v.target_pf = tp


def _rows_for(svc, entry, share=(), tier=""):
    v, priv = svc.vault, (_privacy_best(svc) if tier == "best" else _privacy(svc))
    gid = svc.game.id
    rows = []
    if priv["stats"]:
        s = v.conn.execute("SELECT COUNT(DISTINCT l.card_id) AS u, COALESCE(SUM(l.qty),0) AS n, COALESCE(SUM(l.qty*c.price_usd),0) AS usd FROM lots_s l JOIN cards c ON c.id=l.card_id "
                           "WHERE l.user_id=? AND l.game=? AND l.deleted=0", (v.user_id, v.game)).fetchone()
        rows.append(("stats", gid, {"game": svc.game.name, "gameId": gid, "unique": s["u"], "cards": s["n"], "usd": round(s["usd"], 2) if priv["value"] else None}))
    if priv["favs"]:
        chosen = _favs(svc).get(gid)
        if chosen is None:                                                  # nothing picked yet: the most valuable cards you own
            chosen = [r["id"] for r in v.top_cards(6)]
        lights = v.card_lights(chosen[:MAX_FAVS])
        for i, cid in enumerate(chosen[:MAX_FAVS]):
            c = lights.get(cid)
            if c:
                rows.append(("favs", f"{gid}:{cid}", {"id": cid, "gameId": gid, "game": svc.game.name, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""),
                                                      "usd": c.get("price_usd") if priv["value"] else None, "pos": i, "pic": svc.remote_image(cid, "low")}))   # (the card list's public picture address, so a friend sees it even without this game on their device)
    if priv["badges"]:
        from .insights import badges_for
        done = [b["id"] for b in badges_for(svc) if b["done"]]
        rows.append(("badges", gid, {"game": svc.game.name, "gameId": gid, "done": done}))
    if priv["activity"]:                                                    # one line per day I added cards, for the last 30 days (names only, never prices or what I paid)
        for r in v.conn.execute("SELECT substr(l.added,1,10) AS day, SUM(l.qty) AS n, GROUP_CONCAT(DISTINCT c.name) AS names FROM lots_s l JOIN cards c ON c.id=l.card_id "
                                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.added IS NOT NULL AND substr(l.added,1,10) >= date('now','-30 day') GROUP BY day ORDER BY day DESC LIMIT 20", (v.user_id, v.game)):
            names = (r["names"] or "").split(",")[:3]
            rows.append(("activity", f"{gid}:{r['day']}", {"day": r["day"], "n": r["n"], "names": names, "game": svc.game.name, "gameId": gid}))
    if priv["sets"]:                                                        # progress per set (and which cards of unfinished sets I have) so a friend can race me
        from .insights import _set_progress
        owned = {}
        for r in v.conn.execute("SELECT DISTINCT c.set_id AS sid, c.id AS cid FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0", (v.user_id, v.game)):
            owned.setdefault(r["sid"], []).append(r["cid"])
        for sid, nm, h, n in _set_progress(v)[:400]:
            rows.append(("setprog", f"{gid}:{sid}", {"gameId": gid, "id": sid, "name": nm, "have": h, "total": n, "ids": owned.get(sid, []) if (h < n and n <= 400) else None}))
    if priv["collection"]:                                                 # every card I own (name, set, number, how many) - and what I paid only if that is switched on
        paid = {r["card_id"]: r["p"] for r in v.conn.execute("SELECT card_id, SUM(purchase_price * qty) AS p FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND purchase_price IS NOT NULL GROUP BY card_id", (v.user_id, v.game))} if priv["paid"] else {}
        held = v.conn.execute("SELECT l.card_id AS id, SUM(l.qty) AS q FROM lots_s l WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY l.card_id LIMIT ?", (v.user_id, v.game, MAX_COLL)).fetchall()
        lights = v.card_lights([r["id"] for r in held])
        for r in held:
            c = lights.get(r["id"])
            if c:
                d = {"id": r["id"], "name": c.get("name", r["id"]), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "rarity": c.get("rarity") or "", "qty": r["q"], "gameId": gid, "game": svc.game.name,
                     "usd": c.get("price_usd") if priv["value"] else None}
                if priv["paid"] and r["id"] in paid:
                    d["paid"] = round(paid[r["id"]], 2)
                rows.append(("coll", f"{gid}:{r['id']}", d))
    if priv["wishlist"]:
        wish = sorted(v.wishlist_ids())[:MAX_COLL]
        lights, tags = v.card_lights(wish), wishlist.label_info(svc)               # (the label names and their order: usernames only, no notes, nothing I paid)
        for cid in wish:
            c = lights.get(cid)
            if c:
                rows.append(("wish", f"{gid}:{cid}", {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": c.get("price_usd") if priv["value"] else None, "gameId": gid, "game": svc.game.name,
                                                      **({"label": tags[cid][0], "rank": tags[cid][1]} if cid in tags else {})}))
    if priv["portfolios"]:
        from .portfolios import MAIN, main_name
        names = {MAIN: main_name(svc)}
        names.update({p_["uuid"]: p_["name"] for p_ in v.portfolios()})
        for r in v.conn.execute("SELECT COALESCE(l.portfolio,'') AS pf, COUNT(DISTINCT l.card_id) AS u, SUM(l.qty) AS n, SUM(l.qty*c.price_usd) AS usd FROM lots_s l JOIN cards c ON c.id=l.card_id "
                                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY pf", (v.user_id, v.game)):
            rows.append(("pf", f"{gid}:{r['pf'] or 'main'}", {"name": names.get(r["pf"], "Other"), "unique": r["u"], "cards": r["n"], "usd": round(r["usd"] or 0, 2) if priv["value"] else None, "gameId": gid, "game": svc.game.name}))
    if priv["sealed"]:
        try:
            ph = ",".join("?" * len(share))
            for i, r in enumerate(v.conn.execute("SELECT name, SUM(qty) AS q FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0" + (f" AND COALESCE(portfolio,'') IN ({ph})" if share else "") + " GROUP BY name", (v.user_id, v.game, *share))):
                rows.append(("sealed", f"{gid}:{i}", {"name": r["name"], "qty": r["q"], "gameId": gid, "game": svc.game.name}))
        except Exception:  # noqa: BLE001
            pass
    info = ("meta", "info", {"title": "Friend profile", "kind": "friend", "from": svc.pget("cloud_username"), "at": time.time()})
    return [info, ("prof", "card", _card_row(svc))] + rows


def _publish_profile(svc, a, tier=""):
    """Make the profile share if it isn't there yet, then refresh this game's rows (and drop this game's rows that are switched off).  tier "best" = the best-friends share."""
    gid, e = _mine(svc, tier)
    if not e:
        sh.ensure_keypair(a)
        key, gid = sh.new_group_key(), sh.new_id()
        title = BEST_TITLE if tier == "best" else "Friend profile"
        a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": title, "from": svc.pget("cloud_username"), "kind": "friend"}, "group/name"),
                                      "label_blob": sh.seal_json(key, {"label": "owner"}, "group/label")})
        e = {"key": base64.b64encode(key).decode(), "title": title, "portfolios": [], "showValue": False, "kind": "friend", **({"tier": "best"} if tier == "best" else {})}
        o = _out(svc)
        o[gid] = e
        svc.pset("share_out", json.dumps(o))
    key = _gk(e)
    rows = rows_for(svc, e, tier)
    have = sh.pull_rows(a, gid, key)
    mine = {(c, i) for c, i, _ in rows}
    me = svc.game.id
    gone = [(c, i, None) for (c, i) in have if (c, i) not in mine and ((c in ("stats", "badges") and i == me) or (c in ("favs", "activity", "setprog", "coll", "wish", "pf", "sealed") and i.startswith(me + ":")))]
    changed = [r for r in rows if r[0] == "meta" or have.get((r[0], r[1])) != r[2]]                 # only what is new or different goes up (a big collection is not re-sent every time)
    sh.push_rows(a, gid, key, changed + gone)
    return gid, e


def _publish_all(svc, a):
    """Refresh the ordinary profile and, when I have best friends, the best-friends profile too."""
    _publish_profile(svc, a)
    if any(f.get("best") for f in _book(svc).values()) or _mine(svc, "best")[0]:
        _publish_profile(svc, a, "best")


def _ensure_best(svc, a):
    """The best-friends share, made if missing and republished only now and then (like the ordinary profile)."""
    gid, e = _mine(svc, "best")
    if e and getattr(svc, "_best_game", None) == svc.game.id and time.time() - getattr(svc, "_best_at", 0) < 600:
        return gid, e
    r = _publish_profile(svc, a, "best")
    svc._best_at, svc._best_game = time.time(), svc.game.id
    return r


def _ensure_profile(svc, a):
    """The profile share, made if missing and republished only now and then (it is checked often, and publishing is the slow part)."""
    gid, e = _mine(svc)
    fresh = e and getattr(svc, "_prof_game", None) == svc.game.id and time.time() - getattr(svc, "_prof_at", 0) < 600
    if fresh:
        return gid, e
    r = _publish_profile(svc, a)
    svc._prof_at, svc._prof_game = time.time(), svc.game.id
    return r


def _apply_renames(svc, renames):
    """A friend changed their username: everything on this device that knew them by the old name (the friend book, the shares they gave me) now uses the new one; the old name is kept as an alias so
    the labels the server still holds from before (members of my profile share) can still be matched to them."""
    from .sharing import _inn
    book, ins = _book(svc), _inn(svc)
    for old, new in renames:
        for e in ins.values():
            if _norm(e.get("from")) == old and e.get("kind") in ("friend", "trade", "circle"):
                e["from"] = new
        entry = book.pop(old, None)
        if entry is not None:
            entry["aka"] = list(dict.fromkeys([*entry.get("aka", []), old]))
            book[_norm(new)] = {**book.get(_norm(new), {}), **entry}
    svc.pset("share_in", json.dumps(ins))
    _save(svc, book)
    svc._pres_at = 0


def _aliases(book):
    """{an old name of a friend: the name they use now}"""
    return {a: u for u, f in book.items() for a in f.get("aka", [])}


def _accepted_by(svc, a):
    """Usernames of everybody who has joined MY profile share - i.e. who said yes to my request (known at once, before their own request to me has even arrived)."""
    gid, e = _mine(svc)
    if not e:
        return set()
    try:
        al = _aliases(_book(svc))
        return {al.get(_norm(_label(e, m)), _norm(_label(e, m))) for m in a.call("GET", f"/v1/groups/{gid}/members").get("members", []) if m.get("role") != "owner"} - {""}
    except Exception:  # noqa: BLE001 - offline: fall back to the usual way
        return set()


def _invite(svc, a, gid, entry, name):
    """Invite `name` to one of MY shares; 'they already have it' is fine."""
    from .sharing import invite
    try:
        invite(svc, gid, name)
    except ApiError as ex:
        if "already have" not in str(ex):
            raise


def _incoming(a, svc):
    """Offers addressed to me, with their kind: [{id, from, kind, title}]."""
    from .sharing import offers
    return offers(svc)


def _sync(svc, a):
    """The friendship housekeeping, safe to run again and again:
    - a friend request from someone I already asked = they said yes -> accept it
    - a friend request I accepted by hand -> invite them back so the friendship is two-way
    - trade-list offers from a mutual friend -> accept; and my own trade lists go to every mutual friend."""
    from .sharing import accept
    book = _book(svc)
    gid, entry = _ensure_profile(svc, a)
    offs = _incoming(a, svc)
    changed = False
    for o in offs:
        u = _norm(o["from"])
        f = book.get(u)
        if f and f.get("blocked"):
            continue
        if o.get("kind") == "friend" and o.get("title") == BEST_TITLE:
            if f and f.get("out") and f.get("in"):                         # a mutual friend made me a BEST friend: open their best-friends profile
                r = accept(svc, o["id"])
                f["best_in"] = r["id"]
                changed = True
        elif o.get("kind") == "friend" and f and f.get("out") and not f.get("in"):
            r = accept(svc, o["id"])
            f["in"], f["since"] = r["id"], time.time()
            changed = True
        elif o.get("kind") == "trade" and f and f.get("out") and f.get("in"):
            accept(svc, o["id"])
    for u, f in list(book.items()):
        if f.get("in") and not f.get("out") and not f.get("blocked"):      # I accepted their request: ask them back
            _invite(svc, a, gid, entry, u)
            f["out"], f["since"] = True, f.get("since") or time.time()
            changed = True
        if f.get("in") and f.get("out") and not f.get("blocked") and _privacy(svc)["tradelists"]:
            for tgid, te in _out(svc).items():
                if te.get("kind") == "trade" and tgid not in f.setdefault("trade", []):
                    try:
                        _invite(svc, a, tgid, te, u)
                        f["trade"].append(tgid)
                        changed = True
                    except ApiError:
                        pass
    bests = [u for u, f in book.items() if f.get("best") and f.get("in") and f.get("out") and not f.get("blocked") and not f.get("best_out")]
    if bests:
        try:
            bgid, be = _ensure_best(svc, a)
            for u in bests:
                try:
                    _invite(svc, a, bgid, be, u)
                    book[u]["best_out"] = True
                    changed = True
                except ApiError:
                    pass                                                    # tried again at the next check
        except ApiError:
            pass
    if changed:
        _save(svc, book)
    return book, offs


def _row(u, f, now_in, joined=False):
    if f.get("blocked"):
        state = "blocked"
    elif f.get("in") and f.get("out"):
        state = "friends"
    elif f.get("out") and joined:                                          # they said yes; their side of the friendship is still on its way
        state = "friends"
    elif f.get("out"):
        state = "waiting"                                                  # I asked; they haven't answered yet
    else:
        state = "request" if now_in else "other"
    return {"username": u, "nick": f.get("nick", ""), "state": state, "since": f.get("since"), "added": f.get("added") or f.get("since"), "partial": bool(state == "friends" and not (f.get("in") and f.get("out"))),
            "best": bool(f.get("best")), "bestOfMine": bool(f.get("best_out")), "bestOfTheirs": bool(f.get("best_in"))}


ONLINE_FOR = 240                                                     # seconds: somebody whose app checked in within this long counts as online


@api("friends.ping", quiet=True)
def ping(svc):
    """Tell my friends I'm around (one tiny record, at most once a minute) - or take it away when 'Show when I'm online' is off."""
    if time.time() - getattr(svc, "_ping_at", 0) < 55:
        return {"ok": True}
    a = _acct(svc)
    gid, e = _mine(svc)
    if not e:
        return {"ok": False}
    svc._ping_at = time.time()
    on = _privacy(svc).get("presence", True)

    def go():
        sh.push_rows(a, gid, _gk(e), [("meta", "presence", {"at": time.time()} if on else None)])
        return {"ok": True}
    return _call(go)


def _presence(svc, a, book):
    """{username: last seen (seconds since 1970) or None} - looked up at most every 30 seconds (the rows are fetched incrementally, so it is light)."""
    if time.time() - getattr(svc, "_pres_at", 0) < 30 and getattr(svc, "_pres", None) is not None:
        return svc._pres
    out, cards, renames = {}, {}, []
    for u, (g, e) in friend_groups(svc).items():
        f = book.get(u) or {}
        if not (f.get("in") and f.get("out")) or f.get("blocked"):
            continue
        try:
            got = pull(svc, a, g, _gk(e))
            row = got.get(("meta", "presence"))
            cards[u] = got.get(("prof", "card")) or {}
            now = str(((got.get(("meta", "info")) or {}).get("from")) or "").strip()          # the friend's profile says what they call themselves NOW
            if now and _norm(now) != u and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{2,23}", now):
                renames.append((u, now))
        except Exception:  # noqa: BLE001 - one friend's share failing hides nobody else
            row = None
        out[u] = (row or {}).get("at")
    if renames:                                                       # somebody changed their username: follow them, so the friendship, nickname and profile stay together
        _apply_renames(svc, renames)
        for old, new in renames:
            if old in out:
                out[_norm(new)] = out.pop(old)
            if old in cards:
                cards[_norm(new)] = cards.pop(old)
    svc._pres, svc._pres_at, svc._cards = out, time.time(), cards
    return out


@api("friends.list")
def friends_list(svc, _t=None):
    """Everything the Friends screen shows: my friends, requests waiting for me, requests I sent."""
    a = _acct(svc)
    out = {"friends": [], "requests": [], "sent": [], "blocked": [], "privacy": _privacy(svc), "privacyRaw": _privacy_raw(svc), "me": svc.pget("cloud_username") or ""}

    def go():
        from .safety import hidden_set, is_hidden, sync_blocks
        sync_blocks(svc)                                           # blocks made on another device (and older local ones) are brought in line first
        hid = hidden_set(svc)
        book, offs = _sync(svc, a)
        try:
            ping(svc)
        except ApiError:
            pass
        seen = _presence(svc, a, book)
        book = _book(svc)                                          # (a friend's new username may just have been followed)
        joined = _accepted_by(svc, a)
        reqs = {}
        for o in offs:
            u = _norm(o["from"])
            if o.get("kind") == "friend" and not (book.get(u) or {}).get("blocked") and not is_hidden(hid, "request", u):
                reqs[u] = o["id"]
        for u, f in sorted(book.items()):
            r = _row(u, f, u in reqs, u in joined)
            ls = seen.get(u)
            r["lastSeen"], r["online"] = ls, bool(ls and time.time() - ls < ONLINE_FOR)
            cd = (getattr(svc, "_cards", None) or {}).get(u) or {}
            r["avatar"], r["banner"], r["bio"], r["tagline"] = cd.get("avatar") or "", cd.get("banner") or "blue", cd.get("bio") or "", cd.get("tagline") or ""
            if r["state"] == "friends":
                out["friends"].append(r)
            elif r["state"] == "waiting":
                out["sent"].append(r)
            elif r["state"] == "blocked":
                out["blocked"].append(r)
        for u, oid in reqs.items():
            if not (book.get(u) or {}).get("in"):
                out["requests"].append({"username": u, "offer": oid})
    _call(go)
    return out


@api("friends.pending", quiet=True)
def pending(svc):
    """The friend requests waiting for me: ONE lookup of my offers and nothing else (no profile housekeeping, no looking at each friend), so the screen can ask every few seconds and a request shows up
    in the bell and on the Friends entry almost at once.  Not a request: somebody I already asked (my asking is the answer - the next friends.list makes them a friend), a best-friends offer,
    somebody I blocked or already am friends with.  -> {"requests": [{"username", "offer"}]}"""
    a = _acct(svc)
    book = _book(svc)
    out = []
    for o in _call(lambda: _incoming(a, svc)):
        u = _norm(o["from"])
        f = book.get(u) or {}
        if o.get("kind") == "friend" and o.get("title") != BEST_TITLE and not (f.get("blocked") or f.get("in") or f.get("out")):
            out.append({"username": u, "offer": o["id"]})
    return {"requests": out}


@api("friends.add", mutates=True)
def friends_add(svc, username):
    a = _acct(svc)
    u = _norm(username)
    if not u:
        raise ApiError("Type their username.")
    if u == _norm(svc.pget("cloud_username")):
        raise ApiError("That's you!")
    book = _book(svc)
    if (book.get(u) or {}).get("blocked"):
        raise ApiError("You blocked them - unblock them first.")

    def go():
        gid, entry = _ensure_profile(svc, a)
        _invite(svc, a, gid, entry, u)
        f = book.setdefault(u, {})
        f["out"] = True
        f.setdefault("added", time.time())
        _save(svc, book)
        for o in _incoming(a, svc):                                         # they had already asked me: this is a yes
            if _norm(o["from"]) == u and o.get("kind") == "friend" and not f.get("in"):
                from .sharing import accept
                f["in"], f["since"] = accept(svc, o["id"])["id"], time.time()
                _save(svc, book)
        return {"state": "friends" if f.get("in") else "waiting"}
    return _call(go)


@api("friends.accept", mutates=True)
def friends_accept(svc, offer, username):
    a = _acct(svc)
    u = _norm(username)

    def go():
        from .sharing import accept
        r = accept(svc, offer)
        book = _book(svc)
        f = book.setdefault(u, {})
        f["in"], f["since"] = r["id"], time.time()
        f.setdefault("added", f["since"])
        _save(svc, book)
        _sync(svc, a)
        return True
    return _call(go)


@api("friends.decline", mutates=True)
def friends_decline(svc, offer, block=False, username=""):
    from .sharing import decline
    from .safety import server_block
    if block and username:
        server_block(svc, username)                                 # first: the account server keeps the block and cuts their offer
    try:
        decline(svc, offer)
    except ApiError:
        if not block:                                               # (a blocked person's offer is already gone: nothing left to decline)
            raise
    if block and username:
        book = _book(svc)
        book[_norm(username)] = {"blocked": True, "bsync": True}
        _save(svc, book)
    return True


@api("friends.remove", mutates=True)
def friends_remove(svc, username, block=False):
    """Stop being friends: they lose my profile, I leave theirs, my trade lists stop going to them."""
    a = _acct(svc)
    u = _norm(username)
    book = _book(svc)
    f = book.get(u)
    if f is None:
        raise ApiError("They aren't on your list.")
    if block:
        from .safety import server_block
        server_block(svc, u)                                        # first, so it holds even if the rest is cut short: the account server keeps the block and ends what was shared

    names = {u, *f.get("aka", [])}                                  # the name they use now and any they used before (labels on the server may still hold the old one)

    def go():
        gid, entry = _mine(svc)
        bgid, _be = _mine(svc, "best")
        mine_groups = [g for g in [gid, bgid] + list(f.get("trade", [])) if g]
        for g in mine_groups:
            e = _out(svc).get(g)
            try:
                for m in a.call("GET", f"/v1/groups/{g}/members").get("members", []):
                    if e and _norm(_label(e, m)) in names:
                        a.call("DELETE", f"/v1/groups/{g}/members/{m['id']}")
                for x in a.call("GET", f"/v1/groups/{g}/offers").get("offers", []):
                    if _norm(x["username"]) in names:
                        a.call("DELETE", f"/v1/groups/{g}/offers/{x['id']}")
            except Exception:  # noqa: BLE001 - the share may be gone already
                pass
        from .sharing import leave
        i = _inn(svc)
        for g, e in list(i.items()):
            if _norm(e.get("from")) == u and e.get("kind") in ("friend", "trade"):
                try:
                    leave(svc, g)
                except ApiError:
                    pass
    _call(go)
    if block:
        book[u] = {"blocked": True, "bsync": True}
    else:
        book.pop(u, None)
    _save(svc, book)
    return True


@api("friends.unblock", mutates=True)
def friends_unblock(svc, username):
    from .safety import server_unblock
    server_unblock(svc, username)                                   # the account's block list is the truth (it holds on every device)
    book = _book(svc)
    book.pop(_norm(username), None)
    _save(svc, book)
    return True


@api("friends.nick", mutates=True)
def friends_nick(svc, username, nick=""):
    book = _book(svc)
    f = book.get(_norm(username))
    if not f:
        raise ApiError("They aren't on your list.")
    f["nick"] = (nick or "").strip()[:40]
    _save(svc, book)
    return True


@api("friends.privacy.set", mutates=True)
def privacy_set(svc, **kw):
    p = _privacy_raw(svc)
    for k in PRIVACY:
        if k in kw:
            p[k] = bool(kw[k])                                            # (best_paid: whether BEST friends also see what I paid)
    if "pf_share" in kw:                                              # which portfolios friends can see: a list of portfolio ids, or none = all of them
        ids = kw["pf_share"]
        p["pf_share"] = [str(i) for i in ids][:200] if isinstance(ids, list) and ids else None
    svc.pset("friend_privacy", json.dumps(p))
    a = _acct(svc)
    _call(lambda: _publish_all(svc, a))
    return p


@api("friends.favs.get", quiet=True)
def favs_get(svc):
    """My favourite cards for the current game (what friends see), plus the cards I could pick from."""
    v = svc.vault
    chosen = _favs(svc).get(svc.game.id)
    auto = chosen is None
    if auto:
        chosen = [r["id"] for r in v.top_cards(6)]
    from .cards import img
    cards = []
    for cid in chosen:
        c = v.card_basic(cid)
        if c:
            r = v.conn.execute("SELECT set_id FROM cards WHERE id=?", (cid,)).fetchone()
            cards.append({"id": cid, "name": c.get("name"), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "pic": img(cid, r["set_id"]) if r else ""})
    return {"auto": auto, "cards": cards, "max": MAX_FAVS}


@api("friends.favs.set", mutates=True)
def favs_set(svc, ids):
    ids = [i for i in dict.fromkeys(ids or []) if svc.vault.card_basic(i)][:MAX_FAVS]
    d = _favs(svc)
    d[svc.game.id] = ids
    svc.pset("friend_favs", json.dumps(d))
    a = _acct(svc)
    _call(lambda: _publish_all(svc, a))
    return len(ids)


@api("friends.profile", quiet=True)
def profile(svc, username):
    """A friend's profile + how our collections line up (trade matches for the current game)."""
    a = _acct(svc)
    u = _norm(username)
    if u not in friend_groups(svc):
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")

    def go():
        rows = _friend_rows(svc, a, u)
        stats = [d for (c, _), d in rows.items() if c == "stats"]
        favs = sorted((d for (c, _), d in rows.items() if c == "favs"), key=lambda d: (d.get("game") or "", d.get("pos", 0)))
        favs = [dict(d) for d in favs if isinstance(d, dict) and isinstance(d.get("id"), str)]
        _add_pics(svc, favs)
        badges = {d.get("gameId"): d.get("done", []) for (c, _), d in rows.items() if c == "badges"}
        from .insights import badges_for
        info = {b["id"]: {"title": b["title"], "icon": b["icon"]} for b in badges_for(svc)}
        have = {k: any(c == k for (c, _) in rows) for k in ("coll", "wish", "pf", "sealed")}
        return {"username": u, "have": have, "badges": [{"id": b, **info[b]} for b in sorted({b for v_ in badges.values() for b in v_}) if b in info], "nick": (_book(svc).get(u) or {}).get("nick", ""), "stats": sorted(stats, key=lambda s: -(s.get("cards") or 0)), "favs": favs,
                "since": (_book(svc).get(u) or {}).get("since"), "card": rows.get(("prof", "card")) or {},
                "best": bool((_book(svc).get(u) or {}).get("best")), "theirBest": u in friend_best_groups(svc)}
    out = _call(go)
    try:
        from .tradematch import lists_matches
        m = lists_matches(svc)
        out["match"] = next((x for x in m["friends"] if _norm(x["friend"]) == u), None)
    except ApiError:
        out["match"] = None
    return out


# ----------------------------------------------------------------------------------------------- friends' groups, the activity feed, set races
def friend_groups(svc):
    """{username: (group id, entry)} for every ordinary friend profile I can open (never one of somebody I blocked)."""
    book = _book(svc)
    return {_norm(e.get("from")): (g, e) for g, e in _inn(svc).items() if e.get("kind") == "friend" and e.get("from") and e.get("title") != BEST_TITLE and not (book.get(_norm(e.get("from"))) or {}).get("blocked")}


def friend_best_groups(svc):
    """{username: (group id, entry)} for the friends who made ME a best friend (their best-friends profile)."""
    return {_norm(e.get("from")): (g, e) for g, e in _inn(svc).items() if e.get("kind") == "friend" and e.get("from") and e.get("title") == BEST_TITLE}


def _friend_rows(svc, a, u):
    """Everything I can read of a friend's profile: their ordinary profile, with their best-friends profile laid over it when they made me a best friend (it holds the same kinds of rows, just more of them)."""
    f = friend_groups(svc).get(u)
    if not f:
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    rows = dict(pull(svc, a, f[0], _gk(f[1])))
    b = friend_best_groups(svc).get(u)
    if b:
        try:
            rows.update(pull(svc, a, b[0], _gk(b[1])))
        except Exception:  # noqa: BLE001 - if they took the best-friends share back, the ordinary profile is all there is
            pass
    return rows


def _kick_from(svc, a, g, names):
    """Take the people called any of `names` out of one of MY shares (and withdraw offers still waiting for them)."""
    e = _out(svc).get(g)
    try:
        for m in a.call("GET", f"/v1/groups/{g}/members").get("members", []):
            if e and _norm(_label(e, m)) in names:
                a.call("DELETE", f"/v1/groups/{g}/members/{m['id']}")
        for x in a.call("GET", f"/v1/groups/{g}/offers").get("offers", []):
            if _norm(x["username"]) in names:
                a.call("DELETE", f"/v1/groups/{g}/offers/{x['id']}")
    except Exception:  # noqa: BLE001 - the share may be gone already
        pass


@api("friends.best.set", mutates=True)
def best_set(svc, username, best=True):
    """Make a friend a BEST friend (they open my best-friends profile: everything) or an ordinary friend again (they lose it; what they already downloaded stays with them)."""
    u = _norm(username)
    book = _book(svc)
    f = book.get(u)
    if not f or not (f.get("in") and f.get("out")) or f.get("blocked"):
        raise ApiError("They have to be your friend first (their request accepted).")
    a = _acct(svc)
    if best:
        f["best"] = True
        _save(svc, book)
        _call(lambda: _sync(svc, a))                                         # makes the best-friends share if needed and invites them
    else:
        gid, _e = _mine(svc, "best")
        if gid:
            _call(lambda: _kick_from(svc, a, gid, {u, *f.get("aka", [])}))
        f["best"] = False
        f.pop("best_out", None)
        _save(svc, book)
    return {"best": bool(best)}


@api("friends.feed")
def feed(svc):
    """What friends have been up to (only what each one chose to share), newest first."""
    a = _acct(svc)
    book = _book(svc)
    out = []

    def go():
        for u, (g, e) in friend_groups(svc).items():
            if not (book.get(u) or {}).get("in") or (book.get(u) or {}).get("blocked"):
                continue
            nick = (book.get(u) or {}).get("nick") or u
            rows = _friend_rows(svc, a, u)
            for (c, _), d in rows.items():
                if c == "activity":
                    out.append({"who": u, "name": nick, "day": d.get("day"), "kind": "added", "n": d.get("n"), "names": d.get("names", []), "game": d.get("game", "")})
    _call(go)
    out.sort(key=lambda x: str(x["day"] or ""), reverse=True)
    return {"items": out[:60]}


def _set_rows(svc, a, u):
    rows = _friend_rows(svc, a, u)
    ok = lambda d: isinstance(d, dict) and isinstance(d.get("id"), str) and isinstance(d.get("name"), str) and all(isinstance(d.get(k), int) and not isinstance(d.get(k), bool) for k in ("have", "total"))
    return {d["id"]: d for (c, _), d in rows.items() if c == "setprog" and ok(d) and d.get("gameId") == svc.game.id}


@api("friends.race.sets")
def race_sets(svc, username):
    """Sets (in the open game) where my friend shares progress: both bars, so I can pick one to race."""
    from .insights import _set_progress
    a = _acct(svc)
    u = _norm(username)
    theirs = _call(lambda: _set_rows(svc, a, u))
    mine = {sid: (nm, h, n) for sid, nm, h, n in _set_progress(svc.vault)}
    out = []
    for sid, d in theirs.items():
        m = mine.get(sid)
        out.append({"id": sid, "name": d["name"], "total": d["total"], "theirs": d["have"], "mine": m[1] if m else 0, "close": abs((m[1] if m else 0) - d["have"])})
    out.sort(key=lambda x: (-(min(x["mine"], x["theirs"]) / max(1, x["total"])), x["name"]))
    return {"sets": out[:80], "shared": bool(theirs)}


@api("friends.race.set")
def race_set(svc, username, set_id):
    """One set head to head: who is further, what they have that I lack, what I have that they lack (they may not have spares - it is a list of ideas)."""
    v = svc.vault
    a = _acct(svc)
    u = _norm(username)
    d = _call(lambda: _set_rows(svc, a, u)).get(set_id)
    if not d:
        raise ApiError("They aren't sharing progress for that set.")
    mine = {r["cid"]: r["q"] for r in v.conn.execute("SELECT c.id AS cid, SUM(l.qty) AS q FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND c.set_id=? GROUP BY c.id", (v.user_id, v.game, set_id))}
    theirs = set(d.get("ids") or [])

    def card(cid, **more):
        c = v.card_basic(cid) or {}
        return {"id": cid, "name": c.get("name", cid), "no": c.get("local_id", ""), "usd": c.get("price_usd"), **more}
    out = {"set": {"id": set_id, "name": d["name"], "total": d["total"]}, "mine": len(mine), "theirs": d["have"], "complete": d["have"] >= d["total"], "know": d.get("ids") is not None or d["have"] >= d["total"]}
    if d.get("ids") is not None:
        out["theyHave"] = [card(i) for i in sorted(theirs - set(mine))][:80]                  # I could ask for these
        out["iHave"] = [card(i, qty=q) for i, q in sorted(mine.items()) if i not in theirs][:80]    # I could offer these
    return out


@api("friends.theirs")
def theirs(svc, username, what="coll", q="", game="", offset=0, limit=200, _t=None):
    """What a friend lets me see beyond the profile: their collection, wishlist, portfolios or sealed products (only what they switched on)."""
    a = _acct(svc)
    u = _norm(username)
    if u not in friend_groups(svc):
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    kind = {"coll": "coll", "wish": "wish", "pf": "pf", "sealed": "sealed"}.get(what)
    if not kind:
        raise ApiError("Unknown list.")
    rows = _call(lambda: _friend_rows(svc, a, u))
    items = [d for (c, _), d in rows.items() if c == kind and isinstance(d, dict) and (kind not in ("coll", "wish") or isinstance(d.get("id"), str)) and (d.get("gameId") is None or isinstance(d.get("gameId"), str)) and (not game or d.get("gameId") == game)]
    have = {k: any(c == k for (c, _) in rows) for k in ("coll", "wish", "pf", "sealed")}
    if kind in ("coll", "wish"):                                    # cards I hid on their list are gone for me only
        from .safety import hidden_set, is_hidden
        hid = hidden_set(svc)
        if hid:
            items = [d for d in items if not is_hidden(hid, "card", u, f"{d.get('gameId') or ''}:{d['id']}")]
    games = sorted({d.get("gameId") + "|" + str(d.get("game") or "").replace("|", " ") for d in items if d.get("gameId")})
    words = (q or "").lower().split()
    if words:
        items = [d for d in items if all(w in f"{d.get('name')} {d.get('set', '')} {d.get('no', '')} {d.get('game', '')}".lower() for w in words)]
    items.sort(key=lambda d: ((d.get("game") or ""), (d.get("rank") or 9999) if kind == "wish" else 0, -((d.get("usd") or 0) * (d.get("qty") or 1)), (d.get("name") or "").lower()))       # (a wishlist: their priority order first)
    total_qty = sum(d.get("qty") or 0 for d in items)
    page = items[int(offset):int(offset) + int(limit)]
    if kind in ("coll", "wish"):
        page = [dict(d) for d in page]
        _add_pics(svc, page)
    return {"items": page, "total": len(items), "qty": total_qty, "have": have, "games": [{"id": g.split("|")[0], "name": g.split("|")[1]} for g in games]}
