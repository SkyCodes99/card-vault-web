"""Friends.  Add a collector by username; they accept; from then on you each see the other's small PROFILE (what you both agreed to share) and everything else that works between friends
(trade lists, matches) flows to them without more inviting.

How it works, with no new server part: your profile is one private, end-to-end encrypted share (kind "friend") that only your friends can open.  Adding a friend = inviting them to it.
When they accept they invite you to theirs - two shares make one friendship.  A friend request therefore is just an offer; the server only ever holds ciphertext.

What a profile holds is your choice (Friends > Privacy): the counts of cards for each game you have visited, the total value (off by default), and up to 12 favourite cards.
Never portfolios, never what you paid.  Honest limits: a profile refreshes when you open Friends; a removed friend keeps what they already downloaded."""
import base64
import json
import time

from ..cloud import sharing as sh
from .registry import ApiError, api
from .sharing import _acct, _call, _gk, _inn, _label, _out, pull

PRIVACY = {"stats": True, "value": False, "favs": True, "tradelists": True, "badges": True, "activity": False, "sets": False,
           "collection": False, "wishlist": False, "portfolios": False, "sealed": False, "paid": False, "full": False, "presence": True, "card": True}
FULL_ON = ("stats", "value", "favs", "tradelists", "badges", "activity", "sets", "collection", "wishlist", "portfolios", "sealed")   # what "Full view" switches on ("paid" stays its own choice)
MAX_COLL = 8000                                                      # cards shown to a friend per game (a huge collection is cut here)
MAX_FAVS = 12


def _book(svc):
    try:
        d = json.loads(svc.pget("friends") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _save(svc, d):
    svc.pset("friends", json.dumps(d))


def _privacy_raw(svc):
    """The choices as saved (what each switch was set to), without "Full view" applied on top."""
    try:
        p = json.loads(svc.pget("friend_privacy") or "{}")
    except ValueError:
        p = {}
    return {**PRIVACY, **(p if isinstance(p, dict) else {})}


def _privacy(svc):
    p = _privacy_raw(svc)
    if p.get("full"):                                                # the ultimate switch: everything a friend can be shown, except what you paid unless you also chose that
        p.update({k: True for k in FULL_ON})
    return p


BANNERS = ("blue", "purple", "green", "orange", "pink", "teal", "gold", "dark")


def _card_prefs(svc):
    try:
        d = json.loads(svc.pget("profile_card") or "{}")
    except ValueError:
        d = {}
    d = d if isinstance(d, dict) else {}
    return {"bio": str(d.get("bio") or "")[:160], "tagline": str(d.get("tagline") or "")[:40], "banner": d.get("banner") if d.get("banner") in BANNERS else "blue",
            "favGame": str(d.get("favGame") or "")[:40]}


def _card_row(svc):
    """What friends see on my profile card: picture, banner colour, a line about me.  Empty when "Picture and about me" is switched off."""
    if not _privacy(svc).get("card", True):
        return {"avatar": "", "bio": "", "tagline": "", "banner": "blue", "favGame": ""}
    return {**_card_prefs(svc), "avatar": svc.pget("avatar") or ""}


@api("profile.card.get", quiet=True)
def card_get(svc):
    return {**_card_prefs(svc), "avatar": svc.pget("avatar") or "", "banners": list(BANNERS), "shared": bool(_privacy(svc).get("card", True))}


@api("profile.card.set", mutates=True)
def card_set(svc, bio=None, tagline=None, banner=None, favGame=None):
    d = _card_prefs(svc)
    if bio is not None:
        d["bio"] = str(bio).strip()[:160]
    if tagline is not None:
        d["tagline"] = str(tagline).strip()[:40]
    if banner is not None:
        if banner not in BANNERS:
            raise ApiError("Pick one of the banner colours.")
        d["banner"] = banner
    if favGame is not None:
        d["favGame"] = str(favGame).strip()[:40]
    svc.pset("profile_card", json.dumps(d))
    svc._prof_at = 0                                                  # republish my profile at the next look so friends see it soon
    return card_get(svc)


def _favs(svc):
    try:
        d = json.loads(svc.pget("friend_favs") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}                                # {gameId: [card ids]}


def _norm(name):
    return (name or "").strip().lstrip("@").lower()


def _mine(svc):
    for gid, e in _out(svc).items():
        if e.get("kind") == "friend":
            return gid, e
    return None, None


def _share_ids(svc):
    """The portfolios friends may see (database ids; '' is the main one).  Empty = all of them."""
    raw = _privacy_raw(svc).get("pf_share")
    if not isinstance(raw, list):
        return []
    from .portfolios import _db_id
    return [_db_id(i) for i in raw]


def rows_for(svc, entry):
    """The profile rows for the CURRENT game; other games' rows already in the share are left alone.  What is shown comes from the portfolios chosen under "Which portfolios" - never from
    whatever happens to be on screen at that moment."""
    v = svc.vault
    saved, tp, share = list(v.scope or []), v.target_pf, _share_ids(svc)
    v.set_scope(share)
    try:
        return _rows_for(svc, entry, share)
    finally:
        v.set_scope(saved)
        v.target_pf = tp


def _rows_for(svc, entry, share=()):
    v, priv = svc.vault, _privacy(svc)
    gid = svc.game.id
    rows = []
    if priv["stats"]:
        s = v.conn.execute("SELECT COUNT(DISTINCT l.card_id) AS u, COALESCE(SUM(l.qty),0) AS n, COALESCE(SUM(l.qty*c.price_usd),0) AS usd FROM lots_s l JOIN cards c ON c.id=l.card_id "
                           "WHERE l.user_id=? AND l.game=? AND l.deleted=0", (v.user_id, v.game)).fetchone()
        rows.append(("stats", gid, {"game": svc.game.name, "gameId": gid, "unique": s["u"], "cards": s["n"], "usd": round(s["usd"], 2) if priv["value"] else None}))
    if priv["favs"]:
        chosen = _favs(svc).get(gid)
        if chosen is None:                                                  # nothing picked yet: the most valuable cards you own
            chosen = [r["id"] for r in v.top_cards(6)]
        for i, cid in enumerate(chosen[:MAX_FAVS]):
            c = v.card_light(cid)
            if c:
                rows.append(("favs", f"{gid}:{cid}", {"id": cid, "gameId": gid, "game": svc.game.name, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""),
                                                      "usd": c.get("price_usd") if priv["value"] else None, "pos": i}))
    if priv["badges"]:
        from .insights import badges_for
        done = [b["id"] for b in badges_for(svc) if b["done"]]
        rows.append(("badges", gid, {"game": svc.game.name, "gameId": gid, "done": done}))
    if priv["activity"]:                                                    # one line per day I added cards, for the last 30 days (names only, never prices or what I paid)
        for r in v.conn.execute("SELECT substr(l.added,1,10) AS day, SUM(l.qty) AS n, GROUP_CONCAT(DISTINCT c.name) AS names FROM lots_s l JOIN cards c ON c.id=l.card_id "
                                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.added IS NOT NULL AND substr(l.added,1,10) >= date('now','-30 day') GROUP BY day ORDER BY day DESC LIMIT 20", (v.user_id, v.game)):
            names = (r["names"] or "").split(",")[:3]
            rows.append(("activity", f"{gid}:{r['day']}", {"day": r["day"], "n": r["n"], "names": names, "game": svc.game.name, "gameId": gid}))
    if priv["sets"]:                                                        # progress per set (and which cards of unfinished sets I have) so a friend can race me
        from .insights import _set_progress
        owned = {}
        for r in v.conn.execute("SELECT DISTINCT c.set_id AS sid, c.id AS cid FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0", (v.user_id, v.game)):
            owned.setdefault(r["sid"], []).append(r["cid"])
        for sid, nm, h, n in _set_progress(v)[:400]:
            rows.append(("setprog", f"{gid}:{sid}", {"gameId": gid, "id": sid, "name": nm, "have": h, "total": n, "ids": owned.get(sid, []) if (h < n and n <= 400) else None}))
    if priv["collection"]:                                                 # every card I own (name, set, number, how many) - and what I paid only if that is switched on
        paid = {r["card_id"]: r["p"] for r in v.conn.execute("SELECT card_id, SUM(purchase_price * qty) AS p FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND purchase_price IS NOT NULL GROUP BY card_id", (v.user_id, v.game))} if priv["paid"] else {}
        for r in v.conn.execute("SELECT l.card_id AS id, SUM(l.qty) AS q FROM lots_s l WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY l.card_id LIMIT ?", (v.user_id, v.game, MAX_COLL)):
            c = v.card_light(r["id"])
            if c:
                d = {"id": r["id"], "name": c.get("name", r["id"]), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "rarity": c.get("rarity") or "", "qty": r["q"], "gameId": gid, "game": svc.game.name,
                     "usd": c.get("price_usd") if priv["value"] else None}
                if priv["paid"] and r["id"] in paid:
                    d["paid"] = round(paid[r["id"]], 2)
                rows.append(("coll", f"{gid}:{r['id']}", d))
    if priv["wishlist"]:
        for cid in sorted(v.wishlist_ids())[:MAX_COLL]:
            c = v.card_light(cid)
            if c:
                rows.append(("wish", f"{gid}:{cid}", {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": c.get("price_usd") if priv["value"] else None, "gameId": gid, "game": svc.game.name}))
    if priv["portfolios"]:
        from .portfolios import MAIN, main_name
        names = {MAIN: main_name(svc)}
        names.update({p_["uuid"]: p_["name"] for p_ in v.portfolios()})
        for r in v.conn.execute("SELECT COALESCE(l.portfolio,'') AS pf, COUNT(DISTINCT l.card_id) AS u, SUM(l.qty) AS n, SUM(l.qty*c.price_usd) AS usd FROM lots_s l JOIN cards c ON c.id=l.card_id "
                                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY pf", (v.user_id, v.game)):
            rows.append(("pf", f"{gid}:{r['pf'] or 'main'}", {"name": names.get(r["pf"], "Other"), "unique": r["u"], "cards": r["n"], "usd": round(r["usd"] or 0, 2) if priv["value"] else None, "gameId": gid, "game": svc.game.name}))
    if priv["sealed"]:
        try:
            ph = ",".join("?" * len(share))
            for i, r in enumerate(v.conn.execute("SELECT name, SUM(qty) AS q FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0" + (f" AND COALESCE(portfolio,'') IN ({ph})" if share else "") + " GROUP BY name", (v.user_id, v.game, *share))):
                rows.append(("sealed", f"{gid}:{i}", {"name": r["name"], "qty": r["q"], "gameId": gid, "game": svc.game.name}))
        except Exception:  # noqa: BLE001
            pass
    info = ("meta", "info", {"title": "Friend profile", "kind": "friend", "from": svc.pget("cloud_username"), "at": time.time()})
    return [info, ("prof", "card", _card_row(svc))] + rows


def _publish_profile(svc, a):
    """Make the profile share if it isn't there yet, then refresh this game's rows (and drop this game's rows that are switched off)."""
    gid, e = _mine(svc)
    if not e:
        sh.ensure_keypair(a)
        key, gid = sh.new_group_key(), sh.new_id()
        title = "Friend profile"
        a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": title, "from": svc.pget("cloud_username"), "kind": "friend"}, "group/name"),
                                      "label_blob": sh.seal_json(key, {"label": "owner"}, "group/label")})
        e = {"key": base64.b64encode(key).decode(), "title": title, "portfolios": [], "showValue": False, "kind": "friend"}
        o = _out(svc)
        o[gid] = e
        svc.pset("share_out", json.dumps(o))
    key = _gk(e)
    rows = rows_for(svc, e)
    have = sh.pull_rows(a, gid, key)
    mine = {(c, i) for c, i, _ in rows}
    me = svc.game.id
    gone = [(c, i, None) for (c, i) in have if (c, i) not in mine and ((c in ("stats", "badges") and i == me) or (c in ("favs", "activity", "setprog", "coll", "wish", "pf", "sealed") and i.startswith(me + ":")))]
    changed = [r for r in rows if r[0] == "meta" or have.get((r[0], r[1])) != r[2]]                 # only what is new or different goes up (a big collection is not re-sent every time)
    sh.push_rows(a, gid, key, changed + gone)
    return gid, e


def _ensure_profile(svc, a):
    """The profile share, made if missing and republished only now and then (it is checked often, and publishing is the slow part)."""
    gid, e = _mine(svc)
    fresh = e and getattr(svc, "_prof_game", None) == svc.game.id and time.time() - getattr(svc, "_prof_at", 0) < 600
    if fresh:
        return gid, e
    r = _publish_profile(svc, a)
    svc._prof_at, svc._prof_game = time.time(), svc.game.id
    return r


def _accepted_by(svc, a):
    """Usernames of everybody who has joined MY profile share - i.e. who said yes to my request (known at once, before their own request to me has even arrived)."""
    gid, e = _mine(svc)
    if not e:
        return set()
    try:
        return {_norm(_label(e, m)) for m in a.call("GET", f"/v1/groups/{gid}/members").get("members", []) if m.get("role") != "owner"} - {""}
    except Exception:  # noqa: BLE001 - offline: fall back to the usual way
        return set()


def _invite(svc, a, gid, entry, name):
    """Invite `name` to one of MY shares; 'they already have it' is fine."""
    from .sharing import invite
    try:
        invite(svc, gid, name)
    except ApiError as ex:
        if "already have" not in str(ex):
            raise


def _incoming(a, svc):
    """Offers addressed to me, with their kind: [{id, from, kind, title}]."""
    from .sharing import offers
    return offers(svc)


def _sync(svc, a):
    """The friendship housekeeping, safe to run again and again:
    - a friend request from someone I already asked = they said yes -> accept it
    - a friend request I accepted by hand -> invite them back so the friendship is two-way
    - trade-list offers from a mutual friend -> accept; and my own trade lists go to every mutual friend."""
    from .sharing import accept
    book = _book(svc)
    gid, entry = _ensure_profile(svc, a)
    offs = _incoming(a, svc)
    changed = False
    for o in offs:
        u = _norm(o["from"])
        f = book.get(u)
        if f and f.get("blocked"):
            continue
        if o.get("kind") == "friend" and f and f.get("out") and not f.get("in"):
            r = accept(svc, o["id"])
            f["in"], f["since"] = r["id"], time.time()
            changed = True
        elif o.get("kind") == "trade" and f and f.get("out") and f.get("in"):
            accept(svc, o["id"])
    for u, f in list(book.items()):
        if f.get("in") and not f.get("out") and not f.get("blocked"):      # I accepted their request: ask them back
            _invite(svc, a, gid, entry, u)
            f["out"], f["since"] = True, f.get("since") or time.time()
            changed = True
        if f.get("in") and f.get("out") and not f.get("blocked") and _privacy(svc)["tradelists"]:
            for tgid, te in _out(svc).items():
                if te.get("kind") == "trade" and tgid not in f.setdefault("trade", []):
                    try:
                        _invite(svc, a, tgid, te, u)
                        f["trade"].append(tgid)
                        changed = True
                    except ApiError:
                        pass
    if changed:
        _save(svc, book)
    return book, offs


def _row(u, f, now_in, joined=False):
    if f.get("blocked"):
        state = "blocked"
    elif f.get("in") and f.get("out"):
        state = "friends"
    elif f.get("out") and joined:                                          # they said yes; their side of the friendship is still on its way
        state = "friends"
    elif f.get("out"):
        state = "waiting"                                                  # I asked; they haven't answered yet
    else:
        state = "request" if now_in else "other"
    return {"username": u, "nick": f.get("nick", ""), "state": state, "since": f.get("since"), "added": f.get("added") or f.get("since"), "partial": bool(state == "friends" and not (f.get("in") and f.get("out")))}


ONLINE_FOR = 240                                                     # seconds: somebody whose app checked in within this long counts as online


@api("friends.ping", quiet=True)
def ping(svc):
    """Tell my friends I'm around (one tiny record, at most once a minute) - or take it away when 'Show when I'm online' is off."""
    if time.time() - getattr(svc, "_ping_at", 0) < 55:
        return {"ok": True}
    a = _acct(svc)
    gid, e = _mine(svc)
    if not e:
        return {"ok": False}
    svc._ping_at = time.time()
    on = _privacy(svc).get("presence", True)

    def go():
        sh.push_rows(a, gid, _gk(e), [("meta", "presence", {"at": time.time()} if on else None)])
        return {"ok": True}
    return _call(go)


def _presence(svc, a, book):
    """{username: last seen (seconds since 1970) or None} - looked up at most every 30 seconds (the rows are fetched incrementally, so it is light)."""
    if time.time() - getattr(svc, "_pres_at", 0) < 30 and getattr(svc, "_pres", None) is not None:
        return svc._pres
    out, cards = {}, {}
    for u, (g, e) in friend_groups(svc).items():
        f = book.get(u) or {}
        if not (f.get("in") and f.get("out")) or f.get("blocked"):
            continue
        try:
            got = pull(svc, a, g, _gk(e))
            row = got.get(("meta", "presence"))
            cards[u] = got.get(("prof", "card")) or {}
        except Exception:  # noqa: BLE001 - one friend's share failing hides nobody else
            row = None
        out[u] = (row or {}).get("at")
    svc._pres, svc._pres_at, svc._cards = out, time.time(), cards
    return out


@api("friends.list")
def friends_list(svc, _t=None):
    """Everything the Friends screen shows: my friends, requests waiting for me, requests I sent."""
    a = _acct(svc)
    out = {"friends": [], "requests": [], "sent": [], "blocked": [], "privacy": _privacy(svc), "privacyRaw": _privacy_raw(svc), "me": svc.pget("cloud_username") or ""}

    def go():
        book, offs = _sync(svc, a)
        try:
            ping(svc)
        except ApiError:
            pass
        seen = _presence(svc, a, book)
        joined = _accepted_by(svc, a)
        reqs = {}
        for o in offs:
            u = _norm(o["from"])
            if o.get("kind") == "friend" and not (book.get(u) or {}).get("blocked"):
                reqs[u] = o["id"]
        for u, f in sorted(book.items()):
            r = _row(u, f, u in reqs, u in joined)
            ls = seen.get(u)
            r["lastSeen"], r["online"] = ls, bool(ls and time.time() - ls < ONLINE_FOR)
            cd = (getattr(svc, "_cards", None) or {}).get(u) or {}
            r["avatar"], r["banner"], r["bio"], r["tagline"] = cd.get("avatar") or "", cd.get("banner") or "blue", cd.get("bio") or "", cd.get("tagline") or ""
            if r["state"] == "friends":
                out["friends"].append(r)
            elif r["state"] == "waiting":
                out["sent"].append(r)
            elif r["state"] == "blocked":
                out["blocked"].append(r)
        for u, oid in reqs.items():
            if not (book.get(u) or {}).get("in"):
                out["requests"].append({"username": u, "offer": oid})
    _call(go)
    return out


@api("friends.add", mutates=True)
def friends_add(svc, username):
    a = _acct(svc)
    u = _norm(username)
    if not u:
        raise ApiError("Type their username.")
    if u == _norm(svc.pget("cloud_username")):
        raise ApiError("That's you!")
    book = _book(svc)
    if (book.get(u) or {}).get("blocked"):
        raise ApiError("You blocked them - unblock them first.")

    def go():
        gid, entry = _ensure_profile(svc, a)
        _invite(svc, a, gid, entry, u)
        f = book.setdefault(u, {})
        f["out"] = True
        f.setdefault("added", time.time())
        _save(svc, book)
        for o in _incoming(a, svc):                                         # they had already asked me: this is a yes
            if _norm(o["from"]) == u and o.get("kind") == "friend" and not f.get("in"):
                from .sharing import accept
                f["in"], f["since"] = accept(svc, o["id"])["id"], time.time()
                _save(svc, book)
        return {"state": "friends" if f.get("in") else "waiting"}
    return _call(go)


@api("friends.accept", mutates=True)
def friends_accept(svc, offer, username):
    a = _acct(svc)
    u = _norm(username)

    def go():
        from .sharing import accept
        r = accept(svc, offer)
        book = _book(svc)
        f = book.setdefault(u, {})
        f["in"], f["since"] = r["id"], time.time()
        f.setdefault("added", f["since"])
        _save(svc, book)
        _sync(svc, a)
        return True
    return _call(go)


@api("friends.decline", mutates=True)
def friends_decline(svc, offer, block=False, username=""):
    from .sharing import decline
    decline(svc, offer)
    if block and username:
        book = _book(svc)
        book.setdefault(_norm(username), {})["blocked"] = True
        _save(svc, book)
    return True


@api("friends.remove", mutates=True)
def friends_remove(svc, username, block=False):
    """Stop being friends: they lose my profile, I leave theirs, my trade lists stop going to them."""
    a = _acct(svc)
    u = _norm(username)
    book = _book(svc)
    f = book.get(u)
    if f is None:
        raise ApiError("They aren't on your list.")

    def go():
        gid, entry = _mine(svc)
        mine_groups = [g for g in [gid] + list(f.get("trade", [])) if g]
        for g in mine_groups:
            e = _out(svc).get(g)
            try:
                for m in a.call("GET", f"/v1/groups/{g}/members").get("members", []):
                    if e and _norm(_label(e, m)) == u:
                        a.call("DELETE", f"/v1/groups/{g}/members/{m['id']}")
                for x in a.call("GET", f"/v1/groups/{g}/offers").get("offers", []):
                    if _norm(x["username"]) == u:
                        a.call("DELETE", f"/v1/groups/{g}/offers/{x['id']}")
            except Exception:  # noqa: BLE001 - the share may be gone already
                pass
        from .sharing import leave
        i = _inn(svc)
        for g, e in list(i.items()):
            if _norm(e.get("from")) == u and e.get("kind") in ("friend", "trade"):
                try:
                    leave(svc, g)
                except ApiError:
                    pass
    _call(go)
    if block:
        book[u] = {"blocked": True}
    else:
        book.pop(u, None)
    _save(svc, book)
    return True


@api("friends.unblock", mutates=True)
def friends_unblock(svc, username):
    book = _book(svc)
    book.pop(_norm(username), None)
    _save(svc, book)
    return True


@api("friends.nick", mutates=True)
def friends_nick(svc, username, nick=""):
    book = _book(svc)
    f = book.get(_norm(username))
    if not f:
        raise ApiError("They aren't on your list.")
    f["nick"] = (nick or "").strip()[:40]
    _save(svc, book)
    return True


@api("friends.privacy.set", mutates=True)
def privacy_set(svc, **kw):
    p = _privacy_raw(svc)
    for k in PRIVACY:
        if k in kw:
            p[k] = bool(kw[k])
    if "pf_share" in kw:                                              # which portfolios friends can see: a list of portfolio ids, or none = all of them
        ids = kw["pf_share"]
        p["pf_share"] = [str(i) for i in ids][:200] if isinstance(ids, list) and ids else None
    svc.pset("friend_privacy", json.dumps(p))
    a = _acct(svc)
    _call(lambda: _publish_profile(svc, a))
    return p


@api("friends.favs.get", quiet=True)
def favs_get(svc):
    """My favourite cards for the current game (what friends see), plus the cards I could pick from."""
    v = svc.vault
    chosen = _favs(svc).get(svc.game.id)
    auto = chosen is None
    if auto:
        chosen = [r["id"] for r in v.top_cards(6)]
    from .cards import img
    cards = []
    for cid in chosen:
        c = v.card_light(cid)
        if c:
            r = v.conn.execute("SELECT set_id FROM cards WHERE id=?", (cid,)).fetchone()
            cards.append({"id": cid, "name": c.get("name"), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "pic": img(cid, r["set_id"]) if r else ""})
    return {"auto": auto, "cards": cards, "max": MAX_FAVS}


@api("friends.favs.set", mutates=True)
def favs_set(svc, ids):
    ids = [i for i in dict.fromkeys(ids or []) if svc.vault.card_light(i)][:MAX_FAVS]
    d = _favs(svc)
    d[svc.game.id] = ids
    svc.pset("friend_favs", json.dumps(d))
    a = _acct(svc)
    _call(lambda: _publish_profile(svc, a))
    return len(ids)


@api("friends.profile", quiet=True)
def profile(svc, username):
    """A friend's profile + how our collections line up (trade matches for the current game)."""
    a = _acct(svc)
    u = _norm(username)
    g = next((g for g, e in _inn(svc).items() if e.get("kind") == "friend" and _norm(e.get("from")) == u), None)
    if not g:
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    e = _inn(svc)[g]
    from .cards import img
    conn = svc.vault.conn

    def go():
        rows = pull(svc, a, g, _gk(e))
        stats = [d for (c, _), d in rows.items() if c == "stats"]
        favs = sorted((d for (c, _), d in rows.items() if c == "favs"), key=lambda d: (d.get("game") or "", d.get("pos", 0)))
        favs = [d for d in favs if isinstance(d, dict) and isinstance(d.get("id"), str)]
        for d in favs:
            r = conn.execute("SELECT set_id FROM cards WHERE id=?", (d["id"],)).fetchone() if d.get("gameId") == svc.game.id else None
            d["pic"] = img(d["id"], r["set_id"]) if r else ""
        badges = {d.get("gameId"): d.get("done", []) for (c, _), d in rows.items() if c == "badges"}
        from .insights import badges_for
        info = {b["id"]: {"title": b["title"], "icon": b["icon"]} for b in badges_for(svc)}
        have = {k: any(c == k for (c, _) in rows) for k in ("coll", "wish", "pf", "sealed")}
        return {"username": u, "have": have, "badges": [{"id": b, **info[b]} for b in sorted({b for v_ in badges.values() for b in v_}) if b in info], "nick": (_book(svc).get(u) or {}).get("nick", ""), "stats": sorted(stats, key=lambda s: -(s.get("cards") or 0)), "favs": favs,
                "since": (_book(svc).get(u) or {}).get("since"), "card": rows.get(("prof", "card")) or {}}
    out = _call(go)
    try:
        from .tradematch import lists_matches
        m = lists_matches(svc)
        out["match"] = next((x for x in m["friends"] if _norm(x["friend"]) == u), None)
    except ApiError:
        out["match"] = None
    return out


# ----------------------------------------------------------------------------------------------- friends' groups, the activity feed, set races
def friend_groups(svc):
    """{username: (group id, entry)} for every friend profile I can open."""
    return {_norm(e.get("from")): (g, e) for g, e in _inn(svc).items() if e.get("kind") == "friend" and e.get("from")}


@api("friends.feed")
def feed(svc):
    """What friends have been up to (only what each one chose to share), newest first."""
    a = _acct(svc)
    book = _book(svc)
    out = []

    def go():
        for u, (g, e) in friend_groups(svc).items():
            if not (book.get(u) or {}).get("in") or (book.get(u) or {}).get("blocked"):
                continue
            nick = (book.get(u) or {}).get("nick") or u
            rows = pull(svc, a, g, _gk(e))
            for (c, _), d in rows.items():
                if c == "activity":
                    out.append({"who": u, "name": nick, "day": d.get("day"), "kind": "added", "n": d.get("n"), "names": d.get("names", []), "game": d.get("game", "")})
    _call(go)
    out.sort(key=lambda x: str(x["day"] or ""), reverse=True)
    return {"items": out[:60]}


def _set_rows(svc, a, u):
    f = friend_groups(svc).get(u)
    if not f:
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    rows = pull(svc, a, f[0], _gk(f[1]))
    ok = lambda d: isinstance(d, dict) and isinstance(d.get("id"), str) and isinstance(d.get("name"), str) and all(isinstance(d.get(k), int) and not isinstance(d.get(k), bool) for k in ("have", "total"))
    return {d["id"]: d for (c, _), d in rows.items() if c == "setprog" and ok(d) and d.get("gameId") == svc.game.id}


@api("friends.race.sets")
def race_sets(svc, username):
    """Sets (in the open game) where my friend shares progress: both bars, so I can pick one to race."""
    from .insights import _set_progress
    a = _acct(svc)
    u = _norm(username)
    theirs = _call(lambda: _set_rows(svc, a, u))
    mine = {sid: (nm, h, n) for sid, nm, h, n in _set_progress(svc.vault)}
    out = []
    for sid, d in theirs.items():
        m = mine.get(sid)
        out.append({"id": sid, "name": d["name"], "total": d["total"], "theirs": d["have"], "mine": m[1] if m else 0, "close": abs((m[1] if m else 0) - d["have"])})
    out.sort(key=lambda x: (-(min(x["mine"], x["theirs"]) / max(1, x["total"])), x["name"]))
    return {"sets": out[:80], "shared": bool(theirs)}


@api("friends.race.set")
def race_set(svc, username, set_id):
    """One set head to head: who is further, what they have that I lack, what I have that they lack (they may not have spares - it is a list of ideas)."""
    v = svc.vault
    a = _acct(svc)
    u = _norm(username)
    d = _call(lambda: _set_rows(svc, a, u)).get(set_id)
    if not d:
        raise ApiError("They aren't sharing progress for that set.")
    mine = {r["cid"]: r["q"] for r in v.conn.execute("SELECT c.id AS cid, SUM(l.qty) AS q FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND c.set_id=? GROUP BY c.id", (v.user_id, v.game, set_id))}
    theirs = set(d.get("ids") or [])

    def card(cid, **more):
        c = v.card_light(cid) or {}
        return {"id": cid, "name": c.get("name", cid), "no": c.get("local_id", ""), "usd": c.get("price_usd"), **more}
    out = {"set": {"id": set_id, "name": d["name"], "total": d["total"]}, "mine": len(mine), "theirs": d["have"], "complete": d["have"] >= d["total"], "know": d.get("ids") is not None or d["have"] >= d["total"]}
    if d.get("ids") is not None:
        out["theyHave"] = [card(i) for i in sorted(theirs - set(mine))][:80]                  # I could ask for these
        out["iHave"] = [card(i, qty=q) for i, q in sorted(mine.items()) if i not in theirs][:80]    # I could offer these
    return out


@api("friends.theirs")
def theirs(svc, username, what="coll", q="", game="", offset=0, limit=200):
    """What a friend lets me see beyond the profile: their collection, wishlist, portfolios or sealed products (only what they switched on)."""
    a = _acct(svc)
    u = _norm(username)
    f = friend_groups(svc).get(u)
    if not f:
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    kind = {"coll": "coll", "wish": "wish", "pf": "pf", "sealed": "sealed"}.get(what)
    if not kind:
        raise ApiError("Unknown list.")
    rows = _call(lambda: pull(svc, a, f[0], _gk(f[1])))
    items = [d for (c, _), d in rows.items() if c == kind and isinstance(d, dict) and (kind not in ("coll", "wish") or isinstance(d.get("id"), str)) and (d.get("gameId") is None or isinstance(d.get("gameId"), str)) and (not game or d.get("gameId") == game)]
    have = {k: any(c == k for (c, _) in rows) for k in ("coll", "wish", "pf", "sealed")}
    games = sorted({d.get("gameId") + "|" + str(d.get("game") or "").replace("|", " ") for d in items if d.get("gameId")})
    words = (q or "").lower().split()
    if words:
        items = [d for d in items if all(w in f"{d.get('name')} {d.get('set', '')} {d.get('no', '')} {d.get('game', '')}".lower() for w in words)]
    items.sort(key=lambda d: ((d.get("game") or ""), -((d.get("usd") or 0) * (d.get("qty") or 1)), (d.get("name") or "").lower()))
    total_qty = sum(d.get("qty") or 0 for d in items)
    from .cards import img
    conn = svc.vault.conn
    page = items[int(offset):int(offset) + int(limit)]
    if kind in ("coll", "wish"):
        for d in page:
            r = conn.execute("SELECT set_id FROM cards WHERE id=?", (d["id"],)).fetchone() if d.get("gameId") == svc.game.id else None
            d["pic"] = img(d["id"], r["set_id"]) if r else ""
    return {"items": page, "total": len(items), "qty": total_qty, "have": have, "games": [{"id": g.split("|")[0], "name": g.split("|")[1]} for g in games]}
