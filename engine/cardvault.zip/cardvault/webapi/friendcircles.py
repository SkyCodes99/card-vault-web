"""Circles - little groups of friends who collect together.

A circle is ONE private, end-to-end encrypted share (kind "circle") made by whoever starts it; its members are invited as editors, so each of them can write their own row.  Nothing new on the server.
What is in it:
  ("circ", "def")      the circle itself, written by its owner: name, emoji, colour, a note, the members, and the GOALS - races to finish a set or a checklist (with an optional end date)
  ("prog", username)   one row per member, written by that member from their own device: how far they are on every goal; and - only if they chose "cards" - which cards of the goal they have
                       and which they could spare, so the circle can see who could help whom
Sharing level is each member's own choice per circle: "progress" (just the numbers for the circle's goals - nothing else about the collection is shown) or "cards" (also which cards, for swapping).
Only mutual friends can be invited.  Honest limits: a member can write any row in the share (it is a circle of friends, not a vault); someone who leaves keeps what they already saw."""
import base64
import json
import time

from ..cloud import sharing as sh
from .friends import _aliases, _book, _kick_from, _norm
from .registry import ApiError, api
from .sharing import _acct, _call, _gk, _inn, _label, _out, accept, decline, invite, leave, offers, pull, stop

MAX_GOALS = 12
MAX_MEMBERS = 30
MAX_IDS = 700                                                          # cards listed per goal in a member's row (a bigger goal shows numbers only)
SHARES = ("progress", "cards")


def _me(svc):
    return _norm(svc.pget("cloud_username"))


def _circles(svc):
    """{group id: (entry, i_am_owner)} of every circle I made or joined."""
    out = {g: (e, True) for g, e in _out(svc).items() if e.get("kind") == "circle"}
    out.update({g: (e, False) for g, e in _inn(svc).items() if e.get("kind") == "circle"})
    return out


def _my_old_names(svc):
    """The usernames I had before the current one (newest first)."""
    try:
        old = json.loads(svc.pget("prev_usernames") or "[]")
    except ValueError:
        old = []
    me = _me(svc)
    return [x for x in (_norm(o) for o in old if isinstance(o, str)) if x and x != me]


def _alias_map(svc, rows):
    """{an old username: the name that person uses now}, from three places: my own earlier names, the friends I follow through a rename (the friend book), and the `was` list that a renamed member
    writes into their own row (so circle members who are not friends with each other follow it too)."""
    al = dict(_aliases(_book(svc)))
    me = _me(svc)
    for o in _my_old_names(svc):
        al[o] = me
    for k, v in rows.items():
        if k[0] == "prog" and isinstance(v, dict):
            cur = _norm(v.get("u") or k[1])
            for o in (v.get("was") or []):
                o = _norm(o)
                if o and o != cur:
                    al.setdefault(o, cur)
    return al


def _canon(al, u):
    u = _norm(u)
    for _ in range(5):
        nxt = al.get(u)
        if not nxt or nxt == u:
            break
        u = nxt
    return u


def _mutual(book, u):
    f = book.get(u) or {}
    return bool(f.get("in") and f.get("out") and not f.get("blocked"))


def _shares(svc):
    try:
        d = json.loads(svc.pget("circle_share") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _my_share(svc, gid):
    return _shares(svc).get(gid) if _shares(svc).get(gid) in SHARES else "progress"


def _def(rows):
    d = rows.get(("circ", "def"))
    return d if isinstance(d, dict) else {}


def _clean_goal(g):
    if not isinstance(g, dict) or g.get("kind") not in ("set", "list") or not isinstance(g.get("id"), str):
        return None
    out = {"id": g["id"][:20], "kind": g["kind"], "game": str(g.get("game") or "")[:40], "ref": str(g.get("ref") or "")[:80], "name": str(g.get("name") or "")[:80], "created": g.get("created") or 0}
    if g["kind"] == "list":
        r = g.get("rules") if isinstance(g.get("rules"), dict) else {}
        out["rules"] = {"include": [c for c in (r.get("include") or []) if isinstance(c, dict)][:20], "exclude": [c for c in (r.get("exclude") or []) if isinstance(c, dict)][:20]}
    if isinstance(g.get("ends"), (int, float)) and not isinstance(g.get("ends"), bool):
        out["ends"] = float(g["ends"])
    return out


def _goals(d):
    return [x for x in (_clean_goal(g) for g in (d.get("goals") or [])[:MAX_GOALS]) if x]


def _ids_of(svc, goal):
    """(Progress object for the goal in the goal's game, from MY collection - every portfolio, whatever is on screen).  Must be called inside tradeany.in_game for goal['game']."""
    from .. import checklists
    v = svc.vault
    if goal["kind"] == "set":
        return checklists.progress_for_set(v, goal["ref"])
    ids = checklists.match_ids(v, goal.get("rules") or {})
    return checklists.progress_for_cards(v, ids, "cards", False, goal.get("name") or "")


def _stats(svc, goal, level):
    """{have, total, ids?, spare?} for one goal from my own collection; None when that game's list isn't on this device."""
    from .tradeany import in_game
    v = svc.vault
    saved, tp = list(v.scope or []), v.target_pf
    try:
        with in_game(svc, goal["game"] or v.game):
            v = svc.vault
            inner_saved = list(v.scope or [])
            v.set_scope([])                                               # every portfolio counts, not just the ones on screen
            try:
                p = _ids_of(svc, goal)
                owned = v.owned_map()
            finally:
                v.set_scope(inner_saved)
            ids = [t.card_id for t in p.tiles if t.card_id]
            out = {"have": p.owned, "total": p.total}
            if level == "cards" and ids and len(ids) <= MAX_IDS:
                out["ids"] = [i for i in ids if owned.get(i, 0) > 0]
                out["spare"] = [i for i in ids if (owned.get(i, 0) or 0) > 1]
            return out
    except ApiError:
        return None
    finally:
        try:
            svc.vault.set_scope(saved)
            svc.vault.target_pf = tp
        except Exception:  # noqa: BLE001
            pass


def _push_mine(svc, a, gid, e, rows, force=False):
    """Write my own row (how far I am on every goal) when it changed.  Checked at most every 90 seconds per circle unless forced."""
    me = _me(svc)
    last = svc.__dict__.setdefault("_circ_at", {})
    if not force and time.time() - last.get(gid, 0) < 90:
        return rows
    d = _def(rows)
    level = _my_share(svc, gid)
    prev = rows.get(("prog", me)) if isinstance(rows.get(("prog", me)), dict) else {}
    goals = {}
    for g in _goals(d):
        s = _stats(svc, g, level)
        if s is None:
            old = (prev.get("goals") or {}).get(g["id"])
            if old:
                goals[g["id"]] = old                                        # that game's list isn't here: keep what was already written
            continue
        was = ((prev.get("goals") or {}).get(g["id"]) or {}).get("doneAt")
        s["doneAt"] = (was or time.time()) if s["total"] and s["have"] >= s["total"] else None
        goals[g["id"]] = s
    row = {"u": me, "share": level, "goals": goals}
    was = _my_old_names(svc)
    if was:
        row["was"] = was                                                    # (so the others - friends or not - can tell that my earlier rows are mine)
    last[gid] = time.time()
    if {k: v for k, v in prev.items() if k != "at"} != row:
        row["at"] = time.time()
        sh.push_rows(a, gid, _gk(e), [("prog", me, row)])
        rows = dict(rows)
        rows[("prog", me)] = row
    return rows


def _members_online(svc, a, gid, e, rows):
    """Usernames who have actually joined (the share's member list), plus anyone who has written a row."""
    out = set()
    try:
        for m in a.call("GET", f"/v1/groups/{gid}/members").get("members", []):
            if m.get("role") != "owner":
                out.add(_norm(_label(e, m)))
    except Exception:  # noqa: BLE001 - offline: the rows tell who is in
        pass
    out |= {k[1] for k in rows if k[0] == "prog" and isinstance(k[1], str)}
    return out - {""}


def _label_of(book, u):
    return ((book.get(u) or {}).get("nick") or u)


def _card_names(svc, game, ids):
    from .tradeany import in_game
    try:
        with in_game(svc, game or svc.vault.game):
            v = svc.vault
            out = []
            for cid in ids:
                c = v.card_light(cid)
                if c:
                    out.append({"id": cid, "name": c.get("name", cid), "no": c.get("local_id", ""), "set": c.get("set_name", "")})
            return out
    except ApiError:
        return [{"id": i, "name": i, "no": "", "set": ""} for i in ids]


# ---------------------------------------------------------------------------------------------------------------- list / invitations
@api("circles.list")
def circles_list(svc, _t=None):
    """My circles (made and joined) with one line each, and the invitations waiting for me."""
    a = _acct(svc)
    out = {"circles": [], "invites": []}

    def go():
        book = _book(svc)
        for o in offers(svc):
            if o.get("kind") == "circle" and _mutual(book, _norm(o["from"])):
                out["invites"].append({"id": o["id"], "from": _norm(o["from"]), "title": o["title"]})
        for gid, (e, owner) in _circles(svc).items():
            try:
                rows = pull(svc, a, gid, _gk(e))
            except Exception:  # noqa: BLE001 - one circle failing hides none of the others
                out["circles"].append({"id": gid, "name": e.get("title") or "Circle", "emoji": "", "color": "", "owner": owner, "ownerName": _norm(e.get("from") or _me(svc)), "members": 0, "goals": 0, "offline": True})
                continue
            d = _def(rows)
            al = _alias_map(svc, rows)
            owner_name = _canon(al, d.get("owner") or e.get("from") or _me(svc))
            out["circles"].append({"id": gid, "name": (d.get("name") or e.get("title") or "Circle")[:60], "emoji": str(d.get("emoji") or "")[:4], "color": str(d.get("color") or "")[:9], "owner": owner,
                                   "ownerName": owner_name, "members": len({_canon(al, u) for u in _members_online(svc, a, gid, e, rows)} | {owner_name}),
                                   "goals": len(_goals(d)), "note": str(d.get("note") or "")[:200], "share": _my_share(svc, gid)})
    _call(go)
    return out


@api("circles.accept", mutates=True)
def circles_accept(svc, offer):
    a = _acct(svc)
    o = next((x for x in _call(lambda: offers(svc)) if x["id"] == offer), None)
    if not o or o.get("kind") != "circle":
        raise ApiError("That invitation is gone.")
    if not _mutual(_book(svc), _norm(o["from"])):
        raise ApiError("Circles only take invitations from your friends.")
    r = accept(svc, offer)
    return {"id": r["id"]}


@api("circles.decline", mutates=True)
def circles_decline(svc, offer):
    decline(svc, offer)
    return True


# ---------------------------------------------------------------------------------------------------------------- making and running a circle
@api("circles.create", mutates=True)
def circles_create(svc, name, emoji="", color="", members=None, share="progress", note=""):
    a = _acct(svc)
    name = (name or "").strip()[:40]
    if not name:
        raise ApiError("Give the circle a name.")
    book = _book(svc)
    who = list(dict.fromkeys(_norm(m) for m in (members or []) if _norm(m)))[:MAX_MEMBERS]
    for u in who:
        if not _mutual(book, u):
            raise ApiError(f"{u} isn't one of your friends yet - circles are for friends.")

    def go():
        sh.ensure_keypair(a)
        key, gid = sh.new_group_key(), sh.new_id()
        a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": name, "from": svc.pget("cloud_username"), "kind": "circle"}, "group/name"),
                                      "label_blob": sh.seal_json(key, {"label": "owner"}, "group/label")})
        e = {"key": base64.b64encode(key).decode(), "title": name, "portfolios": [], "showValue": False, "kind": "circle"}
        o = _out(svc)
        o[gid] = e
        svc.pset("share_out", json.dumps(o))
        sh_ = _shares(svc)
        sh_[gid] = share if share in SHARES else "progress"
        svc.pset("circle_share", json.dumps(sh_))
        d = {"name": name, "emoji": (emoji or "")[:4], "color": (color or "")[:9], "note": (note or "")[:200], "owner": _me(svc), "members": [_me(svc), *who], "goals": [], "at": time.time()}
        sh.push_rows(a, gid, key, [("circ", "def", d)])
        for u in who:
            try:
                invite(svc, gid, u, role="editor")
            except ApiError as ex:
                if "already have" not in str(ex):
                    raise
        _push_mine(svc, a, gid, e, {("circ", "def"): d}, force=True)
        return {"id": gid}
    return _call(go)


def _own(svc, id):
    e = _out(svc).get(id)
    if not e or e.get("kind") != "circle":
        raise ApiError("That circle is not yours to change - only the person who made it can.")
    return e


def _write_def(svc, a, id, e, mutate):
    rows = pull(svc, a, id, _gk(e))
    d = dict(_def(rows)) or {"name": e.get("title"), "owner": _me(svc), "members": [_me(svc)], "goals": []}
    mutate(d)
    d["at"] = time.time()
    sh.push_rows(a, id, _gk(e), [("circ", "def", d)])
    return d


@api("circles.update", mutates=True)
def circles_update(svc, id, name=None, emoji=None, color=None, note=None):
    e = _own(svc, id)
    a = _acct(svc)

    def edit(d):
        if name is not None and name.strip():
            d["name"] = name.strip()[:40]
        if emoji is not None:
            d["emoji"] = emoji[:4]
        if color is not None:
            d["color"] = color[:9]
        if note is not None:
            d["note"] = note[:200]
    _call(lambda: _write_def(svc, a, id, e, edit))
    return True


@api("circles.members.add", mutates=True)
def circles_members_add(svc, id, usernames):
    e = _own(svc, id)
    a = _acct(svc)
    book = _book(svc)
    who = list(dict.fromkeys(_norm(m) for m in (usernames or []) if _norm(m)))
    for u in who:
        if not _mutual(book, u):
            raise ApiError(f"{u} isn't one of your friends yet - circles are for friends.")

    def go():
        have = _def(pull(svc, a, id, _gk(e))).get("members") or []
        if len(set(have) | set(who)) > MAX_MEMBERS:
            raise ApiError(f"A circle holds up to {MAX_MEMBERS} people.")
        for u in who:
            try:
                invite(svc, id, u, role="editor")
            except ApiError as ex:
                if "already have" not in str(ex):
                    raise
        _write_def(svc, a, id, e, lambda d: d.update(members=list(dict.fromkeys([*(d.get("members") or [_me(svc)]), *who]))))
    _call(go)
    return True


@api("circles.members.remove", mutates=True)
def circles_members_remove(svc, id, username):
    e = _own(svc, id)
    a = _acct(svc)
    u = _norm(username)
    if u == _me(svc):
        raise ApiError("Delete the circle instead, or leave it to someone else first.")

    def go():
        f = (_book(svc).get(u) or {})
        gone = {u, *f.get("aka", [])}                                       # (and the names they had before: their old rows and member entry go too)
        _kick_from(svc, a, id, gone)
        sh.push_rows(a, id, _gk(e), [("prog", n, None) for n in sorted(gone)])
        _write_def(svc, a, id, e, lambda d: d.update(members=[m for m in (d.get("members") or []) if _norm(m) not in gone]))
    _call(go)
    return True


@api("circles.leave", mutates=True)
def circles_leave(svc, id):
    a = _acct(svc)
    e = _inn(svc).get(id)
    if not e or e.get("kind") != "circle":
        raise ApiError("You're not in that circle.")

    def go():
        me = None
        try:
            me = next((m["id"] for m in a.call("GET", f"/v1/groups/{id}/members").get("members", []) if m.get("me")), None)
            sh.push_rows(a, id, _gk(e), [("prog", n, None) for n in [_me(svc), *_my_old_names(svc)]])
        except Exception:  # noqa: BLE001
            pass
        leave(svc, id, member=me)
    _call(go)
    return True


@api("circles.delete", mutates=True)
def circles_delete(svc, id):
    _own(svc, id)
    stop(svc, id)
    return True


@api("circles.mine.set", mutates=True)
def circles_mine_set(svc, id, share):
    """How much of my collection this circle sees: 'progress' = just my numbers for its goals; 'cards' = also which cards of the goals I have and could spare."""
    if id not in _circles(svc):
        raise ApiError("You're not in that circle.")
    if share not in SHARES:
        raise ApiError("Choose 'progress' or 'cards'.")
    d = _shares(svc)
    d[id] = share
    svc.pset("circle_share", json.dumps(d))
    a = _acct(svc)
    e = _circles(svc)[id][0]
    _call(lambda: _push_mine(svc, a, id, e, pull(svc, a, id, _gk(e)), force=True))
    return {"share": share}


# ---------------------------------------------------------------------------------------------------------------- goals (the races)
@api("circles.goal.options", quiet=True)
def circles_goal_options(svc):
    """What the open game offers as a race: its sets and the checklists made of single cards."""
    v = svc.vault
    have = v.owned_by_set()
    sets = [{"id": s["id"], "name": s["name"], "total": s["n"] or 0, "have": have.get(s["id"], 0)} for s in v.sets() if (s["n"] or 0) > 0]
    lists = [{"id": c["id"], "name": c["name"]} for c in v.checklists() if c["mode"] == "cards"]
    return {"game": svc.game.id, "gameName": svc.game.name, "sets": sets[:900], "lists": lists}


@api("circles.goal.add", mutates=True)
def circles_goal_add(svc, id, kind, ref="", listId=None, ends=None):
    """Start a race in the open game: finish a set (ref = set id) or a checklist of single cards (listId)."""
    e = _own(svc, id)
    a = _acct(svc)
    v = svc.vault
    g = {"id": sh.new_id()[:10], "kind": kind, "game": svc.game.id, "created": time.time()}
    if ends not in (None, "", 0):
        try:
            g["ends"] = float(ends)
        except (TypeError, ValueError):
            raise ApiError("That end date isn't a date.")
    if kind == "set":
        s = next((x for x in v.sets() if x["id"] == ref), None)
        if not s:
            raise ApiError("That set isn't in this game.")
        g.update(ref=s["id"], name=s["name"])
    elif kind == "list":
        from .. import checklists
        cl = v.checklist(listId) if listId is not None else None
        if cl is None or cl["game"] != v.game or cl["mode"] != "cards":
            raise ApiError("Pick one of your checklists of single cards in this game.")
        r = checklists._load_rules(cl)
        g.update(ref=str(cl["id"]), name=cl["name"], rules={"include": r.get("include", []), "exclude": r.get("exclude", [])})
    else:
        raise ApiError("A race is a set or a checklist.")
    if not _clean_goal(g):
        raise ApiError("That can't be a race.")

    def go():
        def add(d):
            gs = _goals(d)
            if len(gs) >= MAX_GOALS:
                raise ApiError(f"A circle holds up to {MAX_GOALS} races.")
            if any(x["kind"] == g["kind"] and x["game"] == g["game"] and x["ref"] == g["ref"] for x in gs):
                raise ApiError("That race is already running in this circle.")
            d["goals"] = [*gs, _clean_goal(g)]
        d = _write_def(svc, a, id, e, add)
        _push_mine(svc, a, id, e, {("circ", "def"): d, **{k: v_ for k, v_ in pull(svc, a, id, _gk(e)).items() if k[0] == "prog"}}, force=True)
        return {"goal": g["id"]}
    return _call(go)


@api("circles.goal.remove", mutates=True)
def circles_goal_remove(svc, id, goal):
    e = _own(svc, id)
    a = _acct(svc)
    _call(lambda: _write_def(svc, a, id, e, lambda d: d.update(goals=[x for x in _goals(d) if x["id"] != goal])))
    return True


# ---------------------------------------------------------------------------------------------------------------- one circle, in full
def _rank(entries):
    """Order a goal's table: most done first; a finished goal is ranked by who finished earlier."""
    entries.sort(key=lambda x: (-(x["pct"] or 0), x["doneAt"] or 1e18, x["label"].lower()))
    for i, x in enumerate(entries):
        x["rank"] = i + 1
    return entries


def _who_label(book, me, name):
    return "You" if name == me else _label_of(book, name)


def _newest_rows(rows, al):
    """{person: their own row}.  An old row and the new one of the same person (they changed their username): the newer wins."""
    prog = {}
    for key, row in rows.items():
        if key[0] == "prog" and isinstance(row, dict):
            who = _canon(al, key[1])
            if who not in prog or (row.get("at") or 0) >= (prog[who].get("at") or 0):
                prog[who] = row
    return prog


class _People:
    """Who is in one circle, each person ONCE however many usernames they have had: the owner, those who have joined (the share's members and anybody who wrote a row), those only named in the list - and each one's own row."""

    def __init__(self, svc, a, gid, e, d, rows, me):
        self.al = _alias_map(svc, rows)                                      # somebody who changed their username is still the same person: old names are merged into the new one
        self.owner = _canon(self.al, d.get("owner") or e.get("from") or me)
        self.joined = {_canon(self.al, u) for u in _members_online(svc, a, gid, e, rows)} | {self.owner}
        named = [m for m in (d.get("members") or [self.owner]) if isinstance(m, str)] + list(self.joined)
        self.people = list(dict.fromkeys(_canon(self.al, m) for m in named))
        self.prog = _newest_rows(rows, self.al)


def _follow_renames(svc, a, gid, e, d, al):
    """The owner's member list follows a rename too (written once, for everybody)."""
    listed = [_norm(m) for m in (d.get("members") or []) if isinstance(m, str)]
    fixed = list(dict.fromkeys(_canon(al, m) for m in listed))
    if fixed and fixed != listed:
        try:
            _write_def(svc, a, gid, e, lambda dd: dd.update(members=fixed))
        except Exception:  # noqa: BLE001 - it is looked at again next time
            pass


def _member_rows(who, me, book):
    out = []
    for u in who.people:
        if (book.get(u) or {}).get("blocked"):                       # somebody I blocked disappears from my views of a shared circle
            continue
        row = who.prog.get(u) or {}
        out.append({"username": u, "label": _who_label(book, me, u), "isMe": u == me, "owner": u == who.owner, "joined": u in who.joined or u in who.prog, "friend": u == me or _mutual(book, u),
                    "share": row.get("share") or "", "at": row.get("at")})
    return out


def _race_entries(goal, who, me, book):
    """One line of a race's table for every person who has written how far they are, best first."""
    out = []
    for u in who.people:
        if (book.get(u) or {}).get("blocked"):
            continue
        s = ((who.prog.get(u) or {}).get("goals") or {}).get(goal["id"])
        if not isinstance(s, dict) or not isinstance(s.get("total"), int) or not isinstance(s.get("have"), int) or s["total"] <= 0:
            continue
        out.append({"username": u, "label": _who_label(book, me, u), "isMe": u == me, "have": s["have"], "total": s["total"], "pct": round(100.0 * s["have"] / s["total"], 1),
                    "doneAt": s.get("doneAt"), "left": s["total"] - s["have"]})
    return _rank(out)


def _race_table(goal, entries, now):
    ends = goal.get("ends")
    winner = next((x["username"] for x in sorted((x for x in entries if x["doneAt"]), key=lambda x: x["doneAt"])), None)
    return {"id": goal["id"], "kind": goal["kind"], "name": goal["name"], "game": goal["game"], "ends": ends, "over": bool(ends and ends < now), "entries": entries, "winner": winner}


def _finished_feed(goal, entries):
    return [{"at": x["doneAt"], "who": x["username"], "label": x["label"], "text": f"finished {goal['name']}", "icon": "🏆"} for x in entries if x["doneAt"]]


def _read_circle(svc, a, gid, e, owner, refresh):
    rows = pull(svc, a, gid, _gk(e))
    d = _def(rows)
    if not d:
        raise ApiError("That circle can't be read right now - try again in a moment.")
    rows = _push_mine(svc, a, gid, e, rows, force=bool(refresh))
    book, me = _book(svc), _me(svc)
    goals = _goals(d)
    who = _People(svc, a, gid, e, d, rows, me)
    if owner:
        _follow_renames(svc, a, gid, e, d, who.al)
    tables, feed, now = [], [], time.time()
    for g in goals:
        entries = _race_entries(g, who, me, book)
        tables.append(_race_table(g, entries, now))
        feed += _finished_feed(g, entries)
    feed.sort(key=lambda x: -(x["at"] or 0))
    return {"id": gid, "name": d.get("name") or e.get("title"), "emoji": d.get("emoji") or "", "color": d.get("color") or "", "note": d.get("note") or "", "owner": owner, "ownerName": who.owner,
            "members": _member_rows(who, me, book), "goals": tables, "feed": feed[:30], "share": _my_share(svc, gid), "swap": _swap(svc, goals, who.prog, me, book)}


@api("circles.get")
def circles_get(svc, id, refresh=False, _t=None):
    """Everything on one circle's screen: who is in, a table for every race, what is going on, and - for members who chose to show cards - who could help whom."""
    a = _acct(svc)
    circle = _circles(svc).get(id)
    if not circle:
        raise ApiError("That circle isn't on this device (it may have been deleted).")
    e, owner = circle
    return _call(lambda: _read_circle(svc, a, id, e, owner, refresh))


def _swap(svc, goals, prog, me, book):
    """For each race where I show my cards: what members could spare that I still need, and what I could spare that they still need (only members who show their cards too)."""
    mine = prog.get(me) or {}
    out = []
    for g in goals:
        mg = (mine.get("goals") or {}).get(g["id"]) or {}
        if mine.get("share") != "cards" or not isinstance(mg.get("ids"), list):
            continue
        from .tradeany import in_game
        try:
            with in_game(svc, g["game"] or svc.vault.game):
                every = {t.card_id for t in _ids_of(svc, g).tiles if t.card_id}
        except ApiError:
            continue
        my_have, my_spare = set(mg.get("ids") or []), set(mg.get("spare") or [])
        my_need = every - my_have
        for u, p in prog.items():
            if u == me or not _mutual(book, u):
                continue
            s = (p.get("goals") or {}).get(g["id"]) or {}
            if p.get("share") != "cards" or not isinstance(s.get("ids"), list):
                continue
            their_have = set(s.get("ids") or [])
            give_me = sorted((set(s.get("spare") or []) & my_need))[:60]
            i_give = sorted(my_spare - their_have)[:60]
            if give_me or i_give:
                out.append({"goal": g["id"], "goalName": g["name"], "username": u, "label": _label_of(book, u), "theyCanGive": _card_names(svc, g["game"], give_me), "iCanGive": _card_names(svc, g["game"], i_give)})
    return out
