"""Open a share link (/s/<token>) that may be protected (docs/skycloud_request_share_protect.md): a password gate (401), an only-these-people gate (403), or too many tries (429).
Password links: the screen asks for the password and sends it here once; it goes only to that link's own server, in a POST body, and is never kept.  People links: the signed-in account asks its
account server for a one-time ticket, then opens the link with it.  The unlock cookies are carried by hand (so they work in tests over plain http too)."""
import re

from .registry import ApiError

WRONG_PW = "That password isn't right."
NOT_LISTED = "That link isn't shared with you."
TOO_MANY = "Too many tries. Try again later."
NEED_SIGNIN = "This link is only for people the owner picked. Sign in to your account first."
GONE = "Couldn't open that link (it may be private now)."
_COOKIE = re.compile(r"(?:^|,\s*)(s[pa]_[A-Za-z0-9_-]+)=([^;,\s]+)")


def _cookies(resp, jar):
    raw = resp.raw.headers
    for c in (raw.getlist("Set-Cookie") if hasattr(raw, "getlist") else [resp.headers.get("Set-Cookie", "")]):
        for k, v in _COOKIE.findall(c or ""):
            jar[k] = v


def _get(base, token, jar, ticket=None):
    import requests
    hd = {"Cookie": "; ".join(f"{k}={v}" for k, v in jar.items())} if jar else {}
    r = requests.get(f"{base}/s/{token}" + (f"?t={ticket}" if ticket else ""), headers=hd, timeout=30, allow_redirects=False)
    _cookies(r, jar)
    if r.status_code in (301, 302, 303, 307, 308):                        # the ticket / unlock step: carry on to the clean address with the cookie just set
        return _get(base, token, jar)
    return r


def _ticket(svc, token):
    from ..cloud import skycloud as sc
    from . import accountapi
    a = accountapi.account(svc)
    if a is None:
        raise ApiError(NEED_SIGNIN)
    try:
        out = a.call("POST", f"/v1/pages/{token}/ticket", {}, timeout=30)
    except sc.CloudError as e:
        raise ApiError({403: NOT_LISTED, 429: TOO_MANY, 404: GONE}.get(e.status, str(e)))
    m = re.search(r"[?&]t=([A-Za-z0-9_-]+)", (out or {}).get("url") or "")
    if not m:
        raise ApiError(GONE)
    return m.group(1)


def read(svc, base, token, password=""):
    """-> the page text, or {"needs": "password", "message": ...} when the screen must ask for the password.  Raises ApiError with a plain sentence otherwise."""
    import requests
    jar, tried = {}, False
    r = _get(base, token, jar)
    for _ in range(4):
        if r.status_code == 200:
            return r.text
        if r.status_code == 429:
            raise ApiError(TOO_MANY)
        if r.status_code == 401:
            if not password or tried:
                return {"needs": "password", "message": WRONG_PW if tried else ""}
            tried = True
            u = requests.post(f"{base}/s/{token}/unlock", data={"password": password}, timeout=30, allow_redirects=False)
            if u.status_code == 429:
                raise ApiError(TOO_MANY)
            _cookies(u, jar)
            if not any(k.startswith("sp_") for k in jar):
                return {"needs": "password", "message": WRONG_PW}
            r = _get(base, token, jar)
        elif r.status_code == 403:
            r = _get(base, token, jar, _ticket(svc, token))
            if r.status_code == 403:
                raise ApiError(NOT_LISTED)
        else:
            break
    raise ApiError(GONE)
