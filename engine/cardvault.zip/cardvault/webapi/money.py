"""Value, profit & loss, movers, spending, finishing a set, insurance report, trade."""
from .. import grading, portfoliooptions, pricepick, reports, tools
from .cards import img, with_undo
from .registry import api
from .service import ApiError


def card_row(svc, cid, **extra):
    c = svc.vault.card_basic(cid) or {}
    return {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "price": pricepick.price_for(svc.vault, cid, c.get("price_usd")), "rarity": c.get("rarity") or "",
            "img": img(cid, c.get("set_id", "")), "qty": svc.owned.get(cid, 0), **extra}


def _sale_value(svc):
    """What the collection is worth at the recent typical (Sale Data) prices; cards without a trend yet count at their Standard price. None if no trend data at all."""
    from .. import trend
    t = trend.for_vault(svc)
    if not t.rows:
        return None
    total, covered = 0.0, 0
    for cid, qty in svc.owned.items():
        c = svc.vault.card_light(cid)
        p = t.recent(cid)
        if p is not None:
            covered += qty
        else:
            p = pricepick.price_for(svc.vault, cid, (c or {}).get("price_usd"))
        total += (p or 0) * qty
    return {"value": round(total, 2), "covered": covered, "days": t.days}


@api("money.overview")
def overview(svc):
    v = svc.vault
    st = v.stats()
    sv = v.sealed_in_view()
    tops = [{"id": r["id"], "name": r["name"], "set": r["set_name"] or r["set_id"], "rarity": r["rarity"] or "", "qty": r["qty"], "value": r["value"], "price": r["price_usd"]}
            for r in v.top_cards(25)]
    snaps = [{"day": s["day"], "total": s["total_usd"], "breakdown": s["breakdown"]} for s in v.snapshots()]
    from . import trendapi
    sale = _sale_value(svc) if trendapi.mode(svc) != "standard" else None
    return {"saleValue": sale, "stats": {"value": st["value"] + sv["value"], "cardsValue": st["value"], "sealedValue": round(sv["value"], 2), "sealedCopies": sv["copies"], "sealedUnpriced": sv["unpriced"],
                                         "valueEur": st["value_eur"], "copies": st["copies"], "unique": st["unique"], "spent": st["spent"] + sv["spent"]},
            "top": tops, "snapshots": snaps, "pricesUpdated": v.meta("prices_updated"), "priceBasis": pricepick.label(v)}


@api("money.breakdown")
def breakdown(svc, kind="set"):
    """The value of what is in view split by `kind` - only the splits the open game uses (cardvault/portfoliooptions.py); [] for one it does not offer."""
    return portfoliooptions.breakdown(svc.vault, "serie" if kind == "era" else kind)


@api("portfolio.options", quiet=True)
def portfolio_options(svc):
    """The splits (and group-bys) that make sense for the open game and what is in view: {game, kind, dims: [{key, label}]}.  Empty ones are not listed."""
    return portfoliooptions.options(svc.vault)


@api("money.profit")
def profit(svc):
    rows = tools.profit_loss(svc.vault)
    from .. import sold
    return {"rows": rows, "totals": tools.profit_totals(rows), "realised": sold.realised(svc.vault)}


@api("money.pnl")
def pnl(svc, game="", portfolio="all"):
    """Profit and loss for one game (its id) or every game (""): unrealised + realised, per item, best / worst buys, the items with no price yet (cardvault/profitloss.py).
    portfolio = the portfolio chip's choice: 'all', one portfolio id (with what is inside it) or a list of ids (valuegraph.db_ids)."""
    from .. import profitloss
    from .mydata import _other_game
    from .valuegraph import db_ids
    v = svc.vault
    v._commit()                                                                 # (other games are read through their own connection)
    return {**profitloss.report(v, game or "", _other_game, db_ids(svc, portfolio)), "portfolio": portfolio}


@api("money.holdings")
def holdings(svc):
    """What the portfolios in view hold: cards (not graded / graded) and sealed products with their value, and how much of it has a price paid entered (gain is only worked out for those)."""
    from .sealedcat import price_for
    v = svc.vault
    rows = v.conn.execute(f"SELECT l.graded, l.qty, l.purchase_price AS paid, {pricepick.sql(v, lot='l')} AS usd, l.id AS lid FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0", (v.user_id, v.game)).fetchall()
    gcost = grading.lot_costs(v)                                                                # grading cost joins what was paid
    g = {"raw": {"copies": 0, "value": 0.0}, "graded": {"copies": 0, "value": 0.0}}
    with_paid = {"copies": 0, "value": 0.0, "invested": 0.0}
    without = {"copies": 0, "value": 0.0}
    for r in rows:
        val = (r["usd"] or 0) * r["qty"]                                                            # (a graded copy is already at its graded price when one exists: pricepick.sql lot=)
        k = g["graded" if r["graded"] else "raw"]
        k["copies"] += r["qty"]; k["value"] += val
        if r["paid"] is not None:
            with_paid["copies"] += r["qty"]; with_paid["value"] += val; with_paid["invested"] += r["paid"] * r["qty"] + gcost.get(r["lid"], 0.0)
        else:
            without["copies"] += r["qty"]; without["value"] += val
    sealed = {"copies": 0, "value": 0.0}
    scope = list(v.scope or [])
    for s in v.conn.execute("SELECT name, qty, paid, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)).fetchall():
        if scope and s["pf"] not in scope:
            continue
        price = (price_for(v, s["name"]) or {}).get("price") or 0
        sealed["copies"] += s["qty"]; sealed["value"] += price * s["qty"]
        if s["paid"] is not None:
            with_paid["copies"] += s["qty"]; with_paid["value"] += price * s["qty"]; with_paid["invested"] += s["paid"] * s["qty"]
        else:
            without["copies"] += s["qty"]; without["value"] += price * s["qty"]
    total = g["raw"]["value"] + g["graded"]["value"] + sealed["value"]
    toy = portfoliooptions.kind_of(v.game) == "toy"                                             # (a toy line has items, no graded copies; a group with nothing in it is not listed)
    raw_label = "Items" if toy else "Cards (not graded)" if g["graded"]["copies"] else "Cards"
    groups = [x for x in ({"key": "raw", "label": raw_label, **g["raw"]}, {"key": "graded", "label": "Graded cards", **g["graded"]}, {"key": "sealed", "label": "Sealed products", **sealed}) if x["copies"] or x["value"]]
    for x in groups:
        x["value"] = round(x["value"], 2); x["share"] = round(100 * x["value"] / total, 1) if total else 0
    with_paid["gain"] = round(with_paid["value"] - with_paid["invested"], 2)
    with_paid["pct"] = round(100 * with_paid["gain"] / with_paid["invested"], 1) if with_paid["invested"] else None
    return {"groups": groups, "total": round(total, 2), "withPaid": {k: round(x, 2) if isinstance(x, float) else x for k, x in with_paid.items()}, "withoutPaid": {k: round(x, 2) if isinstance(x, float) else x for k, x in without.items()}}


@api("money.movers")
def movers(svc, days=7, market=False):
    r = tools.movers(svc.vault, days, bool(market))
    return (r[:150] + r[-150:] if len(r) > 300 else r) if market else r[:400]


@api("spending.list")
def spending_list(svc):
    v = svc.vault
    try:
        budget = float(v.get_setting("monthly_budget_usd") or 0)
    except ValueError:
        budget = 0.0
    return {"rows": [{"id": r["id"], "day": r["day"], "usd": r["amount_usd"], "category": r["category"], "note": r["note"] or ""} for r in v.spending_rows()],
            "byMonth": v.spending_by_month(), "budget": budget}


@api("spending.add", mutates=True)
def spending_add(svc, usd, category="Other", note="", day=None):
    v = svc.vault
    return with_undo(svc, lambda: v.add_spending(float(usd), category or "Other", note, day))


@api("spending.remove", mutates=True)
def spending_remove(svc, id):
    return with_undo(svc, lambda: svc.vault.delete_spending(id))


@api("spending.budget", mutates=True)
def spending_budget(svc, usd):
    svc.vault.set_setting("monthly_budget_usd", usd or None)
    return {"ok": True}


@api("finish.options")
def finish_options(svc):
    v = svc.vault
    from ..db import edition_of
    from .search import is_pocket_hidden
    return {"sets": [{"id": s["id"], "name": s["name"], "serie": s["serie"] or "", "edition": edition_of(s["serie"]) or "", "date": s["release_date"] or ""} for s in v.sets() if not is_pocket_hidden(svc, s["serie"])],
            "lists": [{"id": c["id"], "name": c["name"]} for c in v.checklists()]}


@api("finish.cost")
def finish_cost(svc, kind="set", key=None):
    v = svc.vault
    if key is None:
        return {"total": 0, "owned": 0, "missing": [], "cost": 0, "unpriced": 0, "steps": {}}
    res = tools.finish_cost(v, tools.finish_ids(v, kind, key))
    res["missing"] = res["missing"][:600]
    res["steps"] = {str(k): val for k, val in res["steps"].items()}
    return res


@api("report.insurance")
def insurance(svc, path):
    svc.audit("export", "insurance PDF")
    return {"lines": reports.insurance_pdf(svc.need_grant(path), svc.vault, svc.cfg.get("owner_name", ""))}


@api("report.fullExport")
def full_export(svc, path):
    svc.audit("export", "full spreadsheet")
    return {"lines": reports.full_export_xlsx(svc.need_grant(path), svc.vault)}


# ------------------------------------------------------------------------------------------------ trade
@api("trade.search")
def trade_search(svc, text="", owned_only=False):
    v = svc.vault
    rows = v.query_cards(text=text or "", show="owned" if owned_only else "all", fuzzy=True)[:60]
    return [card_row(svc, r[0]) for r in rows]


@api("trade.cards")
def trade_cards(svc, ids):
    from . import tradeany
    out = []
    for i in ids:
        g, cid = tradeany.split_key(i, svc.vault.game)                 # 'game|card id' = an item of another game
        if g == svc.vault.game:
            if svc.vault.card_light(cid):
                out.append({**card_row(svc, cid), "cid": cid, "game": g})
        else:
            r = tradeany.row_of(svc, g, cid)
            if r:
                out.append(r)
    return out


@api("trade.extras")
def trade_extras(svc, keep=1):
    return [{**card_row(svc, r["card_id"]), "extra": r["extra"]} for r in tools.duplicates(svc.vault, keep)]


@api("trade.wishlist")
def trade_wishlist(svc):
    return [card_row(svc, i) for i in sorted(svc.wishlist) if svc.vault.card_light(i)]


@api("trade.apply", mutates=True)
def trade_apply(svc, give, get, cash_give=0, cash_get=0, misc_give=None, misc_get=None, partner="", notes="", give_pct=100, get_pct=100, lenient=False):
    """Complete a trade: cards leave / arrive in the collection, cash you hand over is logged as spending, and the whole deal is kept in the trade log."""
    v = svc.vault
    cash_give, cash_get = float(cash_give or 0), float(cash_get or 0)
    misc_give, misc_get = list(misc_give or []), list(misc_get or [])
    label = f"Trade: {sum(i['qty'] for i in give)} out, {sum(i['qty'] for i in get)} in"
    log = {"partner": partner, "notes": notes, "give": give, "get": get, "cash_give": cash_give, "cash_get": cash_get, "misc_give": misc_give, "misc_get": misc_get,
           "give_pct": give_pct, "get_pct": get_pct}
    from . import tradeany, tradesealed
    if not lenient:
        tradesealed.check_give(svc, misc_give)
    parts = []
    if tradeany.is_cross(svc, give, get):                                  # items of other games: those are done in their own games first, then what is left is saved here
        if not lenient:
            home_give = tradeany.home_items(svc, give)
            owned_here = v.owned_map()
            short = [i.get("name") or i["card_id"] for i in home_give if owned_here.get(i["card_id"], 0) < i["qty"]]
            if short:
                raise ApiError("You don't own enough copies of: " + ", ".join(short[:6]))
        parts = tradeany.apply_foreign(svc, give, get, lenient)
        v = svc.vault
        log["parts"] = parts
        give, get = tradeany.home_items(svc, give), tradeany.home_items(svc, get)
    try:
        act = tools.apply_trade(v, give, get, label, log, lenient=bool(lenient))
        tradesealed.apply_sealed(svc, misc_give, misc_get)
        if cash_give > 0:
            v.add_spending(cash_give, "Trade cash", f"Cash added to a trade{(' with ' + partner) if partner else ''}")
    except ValueError as e:
        raise ApiError(str(e))
    svc.reload_state()
    return {"ok": True, "undo": {"id": tradeany.undo_token(v.game, act.id, parts), "label": label}}


@api("trade.history")
def trade_history(svc):
    out = []
    for t in svc.vault.trades():
        d = t["data"]
        names = lambda items: [f"{i.get('qty', 1)}× {i.get('name') or i.get('card_id')}" + (f" ({_game_name(i['game'])})" if i.get("game") and i["game"] != svc.vault.game else "") for i in items or []]
        out.append({"id": t["uuid"], "ts": t["ts"], "partner": t["partner"], "notes": t["notes"], "give": names(d.get("give")), "get": names(d.get("get")),
                    "reverted": d.get("reverted") or "", "cashGive": d.get("cash_give", 0), "cashGet": d.get("cash_get", 0), "miscGive": d.get("misc_give") or [], "miscGet": d.get("misc_get") or []})
    return out


def _game_name(gid):
    from .. import games
    return next((g.name for g in games.GAMES if g.id == gid), gid)


def _trade_row(svc, id):
    t = next((x for x in svc.vault.trades(1000) if x["uuid"] == id), None)
    if not t:
        raise ApiError("That trade isn't in the log any more.")
    return t


@api("trade.history.update", mutates=True)
def trade_history_update(svc, id, partner=None, notes=None):
    """Fix who the trade was with / its notes after the fact (the cards are not touched)."""
    _trade_row(svc, id)
    svc.vault.update_trade(id, partner, notes)
    return {"ok": True}


@api("trade.revert", mutates=True)
def trade_revert(svc, id):
    """Undo a completed trade after the fact: what you received goes back out of the collection, what you gave comes back, sealed products and trade cash too.
    The log entry stays, marked as reverted.  Returns the trade's details so the planner can reopen it for changes."""
    import datetime
    from . import tradeany, tradesealed
    v = svc.vault
    t = _trade_row(svc, id)
    d = t["data"]
    if d.get("reverted"):
        raise ApiError("This trade was already reverted.")
    all_give, all_get = list(d.get("give") or []), list(d.get("get") or [])
    give, get = tradeany.home_items(svc, all_give), tradeany.home_items(svc, all_get)             # this game's share (items of other games are reversed in their own games)
    owned = v.owned_map()
    short = [i.get("name") or i["card_id"] for i in get if owned.get(i["card_id"], 0) < i["qty"]]
    if short:
        raise ApiError("Can't revert: you no longer have all the cards you received (" + ", ".join(short[:5]) + "). Put them back first, or just delete the log entry.")
    tradesealed.check_give(svc, d.get("misc_get") or [])
    raw = v.conn.execute("SELECT data FROM u.trades WHERE uuid=?", (id,)).fetchone()["data"]                  # (the log entry's "reverted" mark comes off again with Undo)
    tradeany.revert_foreign(svc, all_give, all_get)
    v = svc.vault
    label = "Reverted trade" + (f" with {t['partner']}" if t["partner"] else "")
    with v.action(label) as act:
        for i in get:
            left = i["qty"]
            lots = sorted(v.lots_for(i["card_id"]), key=lambda l: (l["source"] or "") != "Trade")          # copies that came from a trade first
            for lot in lots:
                take = min(left, lot["qty"])
                if take:
                    v.change_lot_qty(lot["id"], -take)
                    left -= take
                if not left:
                    break
        for i in give:
            v.add_lot(i["card_id"], v.default_variant(i["card_id"]), "Near Mint", i["qty"], price=i.get("unit"), purchased=datetime.date.today().isoformat(), source="Trade reverted")
        v.record_price_history([i["card_id"] for i in give])
        tradesealed.apply_sealed(svc, d.get("misc_get") or [], d.get("misc_give") or [])
        if float(d.get("cash_give") or 0) > 0:
            v.add_spending(-float(d["cash_give"]), "Trade cash", "Trade reverted")
        d["reverted"] = datetime.datetime.now().isoformat(timespec="seconds")
        v.update_trade(id, data=d)
        v._remember({"t": "row", "table": "trades", "id": id, "prev": {"data": raw}})
    svc.reload_state()
    return {"ok": True, "undo": {"id": act.id, "label": label}, "trade": {"give": all_give, "get": all_get, "cash_give": d.get("cash_give", 0), "cash_get": d.get("cash_get", 0),
            "misc_give": d.get("misc_give") or [], "misc_get": d.get("misc_get") or [], "partner": t["partner"], "notes": t["notes"], "give_pct": d.get("give_pct", 100), "get_pct": d.get("get_pct", 100)}}


@api("trade.history.delete", mutates=True)
def trade_history_delete(svc, id):
    from .undoext import undoable
    v = svc.vault
    t = next((x for x in v.trades(1000) if x["uuid"] == id), None)
    return undoable(svc, "Deleted a trade from the log" + (f" (with {t['partner']})" if t and t["partner"] else ""), lambda: v.delete_trade(id), rows=[("trades", "uuid=?", (id,))])


@api("trade.suggest")
def trade_suggest(svc, amount, source="extras", exclude=None):
    """Cards from your extras (or wishlist) that add up to about `amount` dollars, to even out a trade."""
    import itertools
    amount = float(amount)
    if amount <= 0:
        return []
    skip = set(exclude or [])
    pool = trade_extras(svc, 1) if source == "extras" else [dict(c) for c in trade_wishlist(svc)]
    cands = [c for c in pool if c.get("price") and c["id"] not in skip]
    cands.sort(key=lambda c: -c["price"])
    cands = cands[:40]
    best = []
    for n in (1, 2, 3):
        for combo in itertools.combinations(cands, n):
            tot = sum(c["price"] for c in combo)
            if tot <= amount * 1.25 + 1:
                best.append((abs(tot - amount), tot, combo))
    best.sort(key=lambda t: (t[0], len(t[2])))
    return [{"total": round(tot, 2), "cards": [{k: c[k] for k in ("id", "name", "set", "number", "price", "img")} for c in combo]} for _, tot, combo in best[:6]]


@api("money.valueBreakdown", quiet=True)
def value_breakdown(svc, by="portfolio", portfolio=None):
    """Where the value is: split by portfolio, set, era, rarity or cards-vs-sealed - for every portfolio (ignores the Portfolio menu) or just inside one.
    Sealed products count as their own line (and inside a portfolio's total).  -> {rows: [{key, label, value, copies, share}], total, within}"""
    from .portfolios import MAIN, main_name
    v = svc.vault
    pf = None if portfolio in (None, "all") else ("" if portfolio in ("main", MAIN, "") else portfolio)
    names = {"": main_name(svc)}
    names.update({p["uuid"]: p["name"] for p in v.portfolios()})
    if by != "portfolio":                            # every other split is the game's own (cardvault/portfoliooptions.py): set, series, rarity, finish, edition, colour, graded, condition, product, cards vs sealed
        rows = [[n, n, val, c] for n, val, c in portfoliooptions.rows_of(v, "serie" if by == "era" else by, [] if pf is None else [pf])]
        if by not in ("checklist", "card") and not (by in ("type", "product") and rows):   # (a shown type / product split already holds them) - else sealed is its own line, so every split adds up to the same total
            seal = [s for spf, s in v.sealed_totals().items() if pf is None or spf == pf]
            if sum(s["copies"] for s in seal):
                rows.append(["sealed", "Sealed products", round(sum(s["value"] for s in seal), 2), sum(s["copies"] for s in seal)])
                rows.sort(key=lambda r: -r[2])
        total = sum(r[2] for r in rows)
        return {"rows": [{"key": k, "label": n, "value": val, "copies": c, "share": round(100 * val / total, 1) if total else 0} for k, n, val, c in rows[:300]], "total": round(total, 2),
                "within": names.get(pf, "All portfolios") if pf is not None else "All portfolios"}
    cards = v.conn.execute(
        "SELECT COALESCE(l.portfolio,'') AS pf, l.qty, "+pricepick.sql(v, lot="l")+" AS usd FROM u.lots l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0", (v.user_id, v.game)).fetchall()
    seal = v.sealed_totals()
    groups = {}

    def add(key, label, val, copies):
        g = groups.setdefault(key, {"key": key, "label": label, "value": 0.0, "copies": 0})
        g["value"] += val; g["copies"] += copies

    for r in cards:
        if pf is not None and r["pf"] != pf:
            continue
        add(r["pf"] or "main", names.get(r["pf"], "Other"), (r["usd"] or 0) * r["qty"], r["qty"])
    for spf, s in seal.items():
        if pf is not None and spf != pf:
            continue
        add(spf or "main", names.get(spf, "Other"), s["value"], s["copies"])
    total = sum(g["value"] for g in groups.values())
    rows = sorted(groups.values(), key=lambda g: -g["value"])
    for g in rows:
        g["value"] = round(g["value"], 2)
        g["share"] = round(100 * g["value"] / total, 1) if total else 0
    return {"rows": [g for g in rows if g["copies"] or g["value"]][:300], "total": round(total, 2), "within": names.get(pf, "All portfolios") if pf is not None else "All portfolios"}
