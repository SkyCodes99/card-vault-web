"""Value, profit & loss, movers, spending, finishing a set, insurance report, trade."""
from .. import reports, tools
from .cards import img, with_undo
from .registry import api
from .service import ApiError


def card_row(svc, cid, **extra):
    c = svc.vault.card_light(cid) or {}
    return {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "price": c.get("price_usd"),
            "img": img(cid, c.get("set_id", "")), "qty": svc.owned.get(cid, 0), **extra}


@api("money.overview")
def overview(svc):
    v = svc.vault
    st = v.stats()
    tops = [{"id": r["id"], "name": r["name"], "set": r["set_name"] or r["set_id"], "rarity": r["rarity"] or "", "qty": r["qty"], "value": r["value"], "price": r["price_usd"]}
            for r in v.top_cards(25)]
    snaps = [{"day": s["day"], "total": s["total_usd"], "breakdown": s["breakdown"]} for s in v.snapshots()]
    return {"stats": {"value": st["value"], "valueEur": st["value_eur"], "copies": st["copies"], "unique": st["unique"], "spent": st["spent"]},
            "top": tops, "snapshots": snaps, "pricesUpdated": v.meta("prices_updated")}


@api("money.breakdown")
def breakdown(svc, kind="set"):
    v = svc.vault
    if kind == "checklist":
        data = v.checklist_values()
    else:
        data = v.value_breakdown()[kind]
        if kind == "card":
            data = {(v.card_light(k)["name"] if v.card_light(k) else k): val for k, val in data.items()}
    return sorted(([k, val] for k, val in data.items() if val), key=lambda kv: -kv[1])


@api("money.profit")
def profit(svc):
    rows = tools.profit_loss(svc.vault)
    return {"rows": rows, "totals": tools.profit_totals(rows)}


@api("money.movers")
def movers(svc, days=7):
    return tools.movers(svc.vault, days)[:400]


@api("spending.list")
def spending_list(svc):
    v = svc.vault
    try:
        budget = float(v.get_setting("monthly_budget_usd") or 0)
    except ValueError:
        budget = 0.0
    return {"rows": [{"id": r["id"], "day": r["day"], "usd": r["amount_usd"], "category": r["category"], "note": r["note"] or ""} for r in v.spending_rows()],
            "byMonth": v.spending_by_month(), "budget": budget}


@api("spending.add", mutates=True)
def spending_add(svc, usd, category="Other", note="", day=None):
    v = svc.vault
    return with_undo(svc, lambda: v.add_spending(float(usd), category or "Other", note, day))


@api("spending.remove", mutates=True)
def spending_remove(svc, id):
    return with_undo(svc, lambda: svc.vault.delete_spending(id))


@api("spending.budget", mutates=True)
def spending_budget(svc, usd):
    svc.vault.set_setting("monthly_budget_usd", usd or None)
    return {"ok": True}


@api("finish.options")
def finish_options(svc):
    v = svc.vault
    return {"sets": [{"id": s["id"], "name": s["name"], "serie": s["serie"] or ""} for s in v.sets()],
            "lists": [{"id": c["id"], "name": c["name"]} for c in v.checklists()]}


@api("finish.cost")
def finish_cost(svc, kind="set", key=None):
    v = svc.vault
    if key is None:
        return {"total": 0, "owned": 0, "missing": [], "cost": 0, "unpriced": 0, "steps": {}}
    ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=?", (key,))] if kind == "set" else list(v.checklist_members(key))
    res = tools.finish_cost(v, ids)
    res["missing"] = res["missing"][:600]
    res["steps"] = {str(k): val for k, val in res["steps"].items()}
    return res


@api("report.insurance")
def insurance(svc, path):
    return {"lines": reports.insurance_pdf(svc.need_grant(path), svc.vault, svc.cfg.get("owner_name", ""))}


@api("report.fullExport")
def full_export(svc, path):
    return {"lines": reports.full_export_xlsx(svc.need_grant(path), svc.vault)}


# ------------------------------------------------------------------------------------------------ trade
@api("trade.search")
def trade_search(svc, text="", owned_only=False):
    v = svc.vault
    rows = v.query_cards(text=text or "", show="owned" if owned_only else "all")[:60]
    return [card_row(svc, r[0]) for r in rows]


@api("trade.cards")
def trade_cards(svc, ids):
    return [card_row(svc, i) for i in ids if svc.vault.card_light(i)]


@api("trade.extras")
def trade_extras(svc, keep=1):
    return [{**card_row(svc, r["card_id"]), "extra": r["extra"]} for r in tools.duplicates(svc.vault, keep)]


@api("trade.wishlist")
def trade_wishlist(svc):
    return [card_row(svc, i) for i in sorted(svc.wishlist) if svc.vault.card_light(i)]


@api("trade.apply", mutates=True)
def trade_apply(svc, give, get):
    v = svc.vault
    label = f"Trade: {sum(i['qty'] for i in give)} out, {sum(i['qty'] for i in get)} in"
    try:
        act = tools.apply_trade(v, give, get, label)
    except ValueError as e:
        raise ApiError(str(e))
    svc.reload_state()
    return {"ok": True, "undo": {"id": act.id, "label": label}}
