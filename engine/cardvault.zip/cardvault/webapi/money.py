"""Value, profit & loss, movers, spending, finishing a set, insurance report, trade."""
from .. import reports, tools
from .cards import img, with_undo
from .registry import api
from .service import ApiError


def card_row(svc, cid, **extra):
    c = svc.vault.card_light(cid) or {}
    return {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "price": c.get("price_usd"),
            "img": img(cid, c.get("set_id", "")), "qty": svc.owned.get(cid, 0), **extra}


def _sale_value(svc):
    """What the collection is worth at the recent typical (Sale Data) prices; cards without a trend yet count at their Standard price. None if no trend data at all."""
    from .. import trend
    t = trend.for_vault(svc)
    if not t.rows:
        return None
    total, covered = 0.0, 0
    for cid, qty in svc.owned.items():
        c = svc.vault.card_light(cid)
        p = t.recent(cid)
        if p is not None:
            covered += qty
        else:
            p = (c or {}).get("price_usd")
        total += (p or 0) * qty
    return {"value": round(total, 2), "covered": covered, "days": t.days}


@api("money.overview")
def overview(svc):
    v = svc.vault
    st = v.stats()
    tops = [{"id": r["id"], "name": r["name"], "set": r["set_name"] or r["set_id"], "rarity": r["rarity"] or "", "qty": r["qty"], "value": r["value"], "price": r["price_usd"]}
            for r in v.top_cards(25)]
    snaps = [{"day": s["day"], "total": s["total_usd"], "breakdown": s["breakdown"]} for s in v.snapshots()]
    from . import trendapi
    sale = _sale_value(svc) if trendapi.mode(svc) != "standard" else None
    return {"saleValue": sale, "stats": {"value": st["value"], "valueEur": st["value_eur"], "copies": st["copies"], "unique": st["unique"], "spent": st["spent"]},
            "top": tops, "snapshots": snaps, "pricesUpdated": v.meta("prices_updated")}


@api("money.breakdown")
def breakdown(svc, kind="set"):
    v = svc.vault
    if kind == "checklist":
        data = v.checklist_values()
    else:
        data = v.value_breakdown()[kind]
        if kind == "card":
            data = {(v.card_light(k)["name"] if v.card_light(k) else k): val for k, val in data.items()}
    return sorted(([k, val] for k, val in data.items() if val), key=lambda kv: -kv[1])


@api("money.profit")
def profit(svc):
    rows = tools.profit_loss(svc.vault)
    return {"rows": rows, "totals": tools.profit_totals(rows)}


@api("money.movers")
def movers(svc, days=7):
    return tools.movers(svc.vault, days)[:400]


@api("spending.list")
def spending_list(svc):
    v = svc.vault
    try:
        budget = float(v.get_setting("monthly_budget_usd") or 0)
    except ValueError:
        budget = 0.0
    return {"rows": [{"id": r["id"], "day": r["day"], "usd": r["amount_usd"], "category": r["category"], "note": r["note"] or ""} for r in v.spending_rows()],
            "byMonth": v.spending_by_month(), "budget": budget}


@api("spending.add", mutates=True)
def spending_add(svc, usd, category="Other", note="", day=None):
    v = svc.vault
    return with_undo(svc, lambda: v.add_spending(float(usd), category or "Other", note, day))


@api("spending.remove", mutates=True)
def spending_remove(svc, id):
    return with_undo(svc, lambda: svc.vault.delete_spending(id))


@api("spending.budget", mutates=True)
def spending_budget(svc, usd):
    svc.vault.set_setting("monthly_budget_usd", usd or None)
    return {"ok": True}


@api("finish.options")
def finish_options(svc):
    v = svc.vault
    return {"sets": [{"id": s["id"], "name": s["name"], "serie": s["serie"] or ""} for s in v.sets()],
            "lists": [{"id": c["id"], "name": c["name"]} for c in v.checklists()]}


@api("finish.cost")
def finish_cost(svc, kind="set", key=None):
    v = svc.vault
    if key is None:
        return {"total": 0, "owned": 0, "missing": [], "cost": 0, "unpriced": 0, "steps": {}}
    ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=?", (key,))] if kind == "set" else list(v.checklist_members(key))
    res = tools.finish_cost(v, ids)
    res["missing"] = res["missing"][:600]
    res["steps"] = {str(k): val for k, val in res["steps"].items()}
    return res


@api("report.insurance")
def insurance(svc, path):
    svc.audit("export", "insurance PDF")
    return {"lines": reports.insurance_pdf(svc.need_grant(path), svc.vault, svc.cfg.get("owner_name", ""))}


@api("report.fullExport")
def full_export(svc, path):
    svc.audit("export", "full spreadsheet")
    return {"lines": reports.full_export_xlsx(svc.need_grant(path), svc.vault)}


# ------------------------------------------------------------------------------------------------ trade
@api("trade.search")
def trade_search(svc, text="", owned_only=False):
    v = svc.vault
    rows = v.query_cards(text=text or "", show="owned" if owned_only else "all")[:60]
    return [card_row(svc, r[0]) for r in rows]


@api("trade.cards")
def trade_cards(svc, ids):
    return [card_row(svc, i) for i in ids if svc.vault.card_light(i)]


@api("trade.extras")
def trade_extras(svc, keep=1):
    return [{**card_row(svc, r["card_id"]), "extra": r["extra"]} for r in tools.duplicates(svc.vault, keep)]


@api("trade.wishlist")
def trade_wishlist(svc):
    return [card_row(svc, i) for i in sorted(svc.wishlist) if svc.vault.card_light(i)]


@api("trade.apply", mutates=True)
def trade_apply(svc, give, get, cash_give=0, cash_get=0, misc_give=None, misc_get=None, partner="", notes="", give_pct=100, get_pct=100):
    """Complete a trade: cards leave / arrive in the collection, cash you hand over is logged as spending, and the whole deal is kept in the trade log."""
    v = svc.vault
    cash_give, cash_get = float(cash_give or 0), float(cash_get or 0)
    misc_give, misc_get = list(misc_give or []), list(misc_get or [])
    label = f"Trade: {sum(i['qty'] for i in give)} out, {sum(i['qty'] for i in get)} in"
    log = {"partner": partner, "notes": notes, "give": give, "get": get, "cash_give": cash_give, "cash_get": cash_get, "misc_give": misc_give, "misc_get": misc_get,
           "give_pct": give_pct, "get_pct": get_pct}
    try:
        act = tools.apply_trade(v, give, get, label, log)
        if cash_give > 0:
            v.add_spending(cash_give, "Trade cash", f"Cash added to a trade{(' with ' + partner) if partner else ''}")
    except ValueError as e:
        raise ApiError(str(e))
    svc.reload_state()
    return {"ok": True, "undo": {"id": act.id, "label": label}}


@api("trade.history")
def trade_history(svc):
    out = []
    for t in svc.vault.trades():
        d = t["data"]
        names = lambda items: [f"{i.get('qty', 1)}× {i.get('name') or i.get('card_id')}" for i in items or []]
        out.append({"id": t["uuid"], "ts": t["ts"], "partner": t["partner"], "notes": t["notes"], "give": names(d.get("give")), "get": names(d.get("get")),
                    "cashGive": d.get("cash_give", 0), "cashGet": d.get("cash_get", 0), "miscGive": d.get("misc_give") or [], "miscGet": d.get("misc_get") or []})
    return out


@api("trade.history.delete", mutates=True)
def trade_history_delete(svc, id):
    svc.vault.delete_trade(id)
    return {"ok": True}


@api("trade.suggest")
def trade_suggest(svc, amount, source="extras", exclude=None):
    """Cards from your extras (or wishlist) that add up to about `amount` dollars, to even out a trade."""
    import itertools
    amount = float(amount)
    if amount <= 0:
        return []
    skip = set(exclude or [])
    pool = trade_extras(svc, 1) if source == "extras" else [dict(c) for c in trade_wishlist(svc)]
    cands = [c for c in pool if c.get("price") and c["id"] not in skip]
    cands.sort(key=lambda c: -c["price"])
    cands = cands[:40]
    best = []
    for n in (1, 2, 3):
        for combo in itertools.combinations(cands, n):
            tot = sum(c["price"] for c in combo)
            if tot <= amount * 1.25 + 1:
                best.append((abs(tot - amount), tot, combo))
    best.sort(key=lambda t: (t[0], len(t[2])))
    return [{"total": round(tot, 2), "cards": [{k: c[k] for k in ("id", "name", "set", "number", "price", "img")} for c in combo]} for _, tot, combo in best[:6]]
