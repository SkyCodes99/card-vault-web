"""'12 of 340 have no true price yet' - the ONE server-side count behind the small indicator on every list (checklists, set views, wishlist and its labels, duplicates, portfolios).

A TRUE price is the price Settings > Price sources picks, and not an eBay asking price (a toy's store price counts).  The counting itself is completion.missing_price_count(); this only says which
cards a list holds.  The screens ask `prices.missing` with {kind, id} (kind = set | checklist | wishlist | label | duplicates | owned | portfolio) or {kind: "ids", ids: [...]}; the UI is
ui/src/components/MissingPrice.jsx."""
from .. import completion, wishlabels
from .registry import api
from .service import ApiError


def _set_ids(v, set_id):
    gone = v.excluded_cards(set_id)
    return [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=?", (set_id,)) if r[0] not in gone]


def card_ids(svc, kind, id="", ids=None):
    """The card ids a list holds (see the module notes for the kinds)."""
    v = svc.vault
    if kind == "ids":
        return list(ids or [])
    if kind == "set":
        return _set_ids(v, str(id))
    if kind == "checklist":
        from .lists import progress_of
        _cl, p = progress_of(svc, int(id))
        return [t.card_id for t in p.tiles if t.card_id]
    if kind == "wishlist":
        return sorted(v.wishlist_ids())
    if kind == "label":
        _labels, assign = wishlabels.of_game(svc, v.game)
        mine = set(v.wishlist_ids())
        return sorted(c for c in mine if (assign.get(c) or "") == str(id or ""))
    if kind == "duplicates":
        from .. import tools
        return [r["card_id"] for r in tools.duplicates(v, 1)]
    if kind == "owned":                                                       # everything held in the portfolios the Viewing menu shows
        return [r[0] for r in v.conn.execute("SELECT DISTINCT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game))]
    if kind == "portfolio":
        pf = "" if id in ("", "main", None) else str(id)
        return [r[0] for r in v.conn.execute("SELECT DISTINCT card_id FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND COALESCE(portfolio,'')=?", (v.user_id, v.game, pf))]
    raise ApiError("unknown list kind")


@api("prices.missing", quiet=True)
def missing(svc, kind, id="", ids=None):
    """{missing, total} - how many of the cards of this list have no true price yet."""
    return completion.missing_price_count(svc.vault, card_ids(svc, kind, id, ids))
