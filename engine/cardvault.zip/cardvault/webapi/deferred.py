"""The website's engine has ONE thread: a call that asks the account server (friends, sharing, races, circles, organize...) used to wait for the answer inside the call, so every page waited too.

Here such a call is run so that its requests are sent by the page instead (as a quiet job, like friends.pending): the call is tried at once; the first time it reaches a request
(steps.Await.now) it stops, and the rest is done as a job whose requests the page sends.  Each time an answer is in, the call is run again from the start with the answers so far
(`log`) played back, until it gets to the end - so the code of the calls stays as it is.  Things that differ between runs (new ids, keys) are made once and played back too (stable()).
The page's engine (ui/src/engine/worker.js) holds the caller's answer back until the job is finished, while it keeps answering everything else.  Only with a page to send the
requests (jobs.HAND_OUT); the desktop and the tests without a page ask on the spot, as before."""
import json
import sqlite3
import sys
import time

from . import jobs as jobs_mod

# calls that ask the account server for something (a call outside these never waits for it in the browser engine, or is not worth the replay)
PREFIXES = ("friends.", "profile.card.", "notify.friends", "share.account.", "races.", "circles.", "binder.publish", "binder.setLock", "binder.unpublish", "binder.pageStatus",
            "ftrade.", "trade.lists.", "missing.", "gifts.", "showcase.", "sharelock.", "misc.", "safety.", "report.", "feedback.", "learn.", "weekly.")
QUICK = 120                                     # a finished deferred call's job is kept this long (seconds) for whoever asks for its answer

CTX = None                                      # the run in progress: where the answers so far are played back from (one thread: a plain global)
TOP = [False]                                   # set by the page's call entry (inline.call) for the one call it makes; nested calls (an api calling another) never start their own job


class Need(BaseException):
    """The call reached a request it has no answer for yet (not an Exception: the call's own `except Exception` must not swallow it)."""

    def __init__(self, item):
        self.item = item


class Deferred(BaseException):
    """The call goes on as a job: the page asks for its answer with poll()."""

    def __init__(self, jid):
        self.jid = jid


class _Run:
    def __init__(self, log, rand):
        self.log, self.rand, self.i, self.r = log, rand, 0, {}

    def answer(self, item):
        """Await.now(): the answer from the last run (the next logged one for the same request - a run may skip one that something it remembered from the last run makes unnecessary),
        or stop and ask."""
        sig = _sig(item)
        for k in range(self.i, len(self.log)):
            if self.log[k][0] == sig:
                self.i = k + 1
                ok, val = self.log[k][1:]
                if ok:
                    return val
                raise val
        raise Need(item)


def _sig(item):
    return (getattr(item, "method", "pause"), getattr(item, "url", ""))


class _In:
    def __init__(self, run):
        self.run = run

    def __enter__(self):
        global CTX
        self.was, CTX = CTX, self.run
        return self.run

    def __exit__(self, *a):
        global CTX
        CTX = self.was


class suspended:
    """Jobs run their own pieces: a request inside one is theirs to answer, never this call's."""

    def __enter__(self):
        global CTX
        self.was, CTX = CTX, None

    def __exit__(self, *a):
        global CTX
        CTX = self.was


def answer(item):
    """-> (True, the answer played back) while a call is being run for deferring, else (False, None): ask on the spot."""
    return (True, CTX.answer(item)) if CTX is not None else (False, None)


def stable(what, make):
    """make() once per call, however many times it is run again: a new id or key that a request already carries must be the same the next time round.
    (`what` names the kind - a run may skip one that the last run left remembered, so the n-th of a kind is not the n-th made.)"""
    c = CTX
    if c is None:
        return make()
    n = c.r[what] = c.r.get(what, 0) + 1
    if (what, n) not in c.rand:
        c.rand[(what, n)] = make()
    return c.rand[(what, n)]


def wanted(name):
    return jobs_mod.HAND_OUT and name.startswith(PREFIXES)


WROTE_FIRST = set()                             # calls seen saving something for good BEFORE a request (each run again would save it again): a test fails on any


def _try(svc, name, attempt):
    """attempt(), but whatever a run that stops at a request (Need) changed in the collection is undone: the run is made again from the start once the answer is in, so
    a change made before the request is made once, by the run that gets to the end - not once per run.  (The collection's own saves wait meanwhile - Vault._defer, as in its
    batch imports - so the run's changes stay in one open change that can be taken back.)"""
    v = getattr(svc, "vault", None)
    conn = getattr(v, "conn", None)
    if conn is None:
        return attempt()
    v.settle()                                                   # (a read or change left open by a background step is let go first, as every write does)
    prev, v._defer = v._defer, True
    conn.execute("SAVEPOINT deferred_try")
    try:
        out = attempt()
    except Need:
        try:
            conn.execute("ROLLBACK TO deferred_try")
            conn.execute("RELEASE deferred_try")
        except sqlite3.OperationalError:                         # the call saved for good before its request (a commit of its own): that cannot be undone here
            WROTE_FIRST.add(name)
            print(f"deferred: {name} saved a change before asking the server; it is made again on each run", file=sys.stderr)
        raise
    except BaseException:
        _keep(conn, prev)
        raise
    finally:
        v._defer = prev
    _keep(conn, prev)
    return out


def _keep(conn, prev):
    """The run is over: what it changed is saved, exactly as it would have been without the savepoint."""
    try:
        conn.execute("RELEASE deferred_try")
    except sqlite3.OperationalError:                             # (the call committed: the savepoint went with it)
        pass
    if not prev and conn.in_transaction:
        conn.commit()


def _steps(svc, name, attempt, log, rand, item):
    while True:
        try:
            log.append((_sig(item), True, (yield item)))
        except Exception as e:  # noqa: BLE001 - what went wrong with the request is what the call sees at that point
            log.append((_sig(item), False, e))
        try:
            with _In(_Run(log, rand)):
                return ("ok", _try(svc, name, attempt))
        except Need as n:
            item = n.item
        except Exception as e:  # noqa: BLE001
            return ("err", e)


def run(svc, name, args, attempt, mutates):
    """-> the call's answer, or raises Deferred(job id) when it has to ask the account server (the rest goes on as a job)."""
    top, TOP[0] = TOP[0], False
    if not top or CTX is not None or not wanted(name):
        return attempt()
    key = None
    if not mutates:                                                  # the same question asked again while it is still going: one job answers both
        key = name + json.dumps(args, sort_keys=True, default=str)
        for j in svc.jobs.items.values():
            if j.kind == "defer" and j.state == "running" and getattr(j, "key", None) == key:
                raise Deferred(j.id)
    log, rand = [], {}
    try:
        with _In(_Run(log, rand)):
            return _try(svc, name, attempt)
    except Need as n:
        item = n.item
    now = time.time()
    for jid in [j.id for j in svc.jobs.items.values() if j.kind == "defer" and j.state != "running" and now - j.started > QUICK]:
        svc.jobs.items.pop(jid, None)

    def done(job):
        if job.state == "done" and mutates and mutates != "quiet" and job.result and job.result[0] == "ok":
            svc.bump("changed")

    job = svc.jobs.start("defer", name, lambda emit, cancel: _steps(svc, name, attempt, log, rand, item), on_done=done, exclusive=False, quiet=True)
    job.key = key
    raise Deferred(job.id)


def poll(svc, jid):
    """-> (state, value): ("pending", None) | ("ok", answer) | ("err", the exception)."""
    job = svc.jobs.items.get(jid)
    if job is None:
        return "err", RuntimeError("That was lost - please try again.")
    if job.state == "running":
        if job.pieces is not None and svc.jobs.ready(job):
            svc.jobs._piece(job)
        if job.state == "running":
            return "pending", None
    if job.state == "done":
        return job.result
    return "err", RuntimeError(job.error or "Stopped.")
