"""The Movers panel: the top 10 price rises and drops over 1, 7 and 30 days, in one game or every game the owner collects (cardvault/marketmovers.py)."""
from .. import marketmovers
from .registry import api


@api("money.topMovers", quiet=True)
def top_movers(svc, game="all"):
    return marketmovers.movers(svc.vault, game)
