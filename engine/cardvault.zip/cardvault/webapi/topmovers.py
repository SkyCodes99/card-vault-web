"""The Movers panel: the top 10 price rises and drops over 1, 7 and 30 days, in one game or every game the owner collects (cardvault/marketmovers.py)."""
from .. import marketmovers
from .registry import api


@api("money.topMovers", quiet=True)
def top_movers(svc, game="all", portfolio="all", mine=True):
    """mine = only the cards I own (the default); False also takes the cards on my wish list.  portfolio = the portfolio chip's choice: 'all', one portfolio id (with what is inside it) or a list of ids (valuegraph.db_ids)."""
    from .valuegraph import db_ids
    return {**marketmovers.movers(svc.vault, game, pf=db_ids(svc, portfolio), only_mine=bool(mine)), "portfolio": portfolio}
