"""What the browser's engine worker calls.  Same data service as the desktop app, run one call at a time (no threads) inside a web worker.

boot(config_json) -> start;  call(name, args_json) -> reply json;  tick() -> housekeeping;  persist() -> write unsaved changes now."""
import json
import os
import sys
import traceback

svc = None
sched = None
_emit = None


def _send(ev):
    if _emit is not None:
        try:
            _emit(json.dumps(ev, default=str))
        except Exception:  # noqa: BLE001
            pass


def boot(config_json, emit=None):
    global svc, sched, _emit
    cfg = json.loads(config_json or "{}")
    _emit = emit
    from ..paths import load_config
    from . import Service
    from .scheduler import Scheduler
    base = load_config()
    base.update(cfg)
    os.makedirs(base["data_dir"], exist_ok=True)
    os.makedirs("/downloads", exist_ok=True)
    os.makedirs("/uploads", exist_ok=True)
    try:
        from ..cloud import skycloud
        skycloud.SITE_BASE = base.get("site_url", "")                       # lets the sign-in maths use the browser's fast crypto (see skycloud._pbkdf2_in_browser)
    except Exception:  # noqa: BLE001
        pass
    svc = Service(base)
    svc.listeners.append(_send)
    sched = Scheduler(svc).start()
    return json.dumps({"ok": True, "error": svc.error})


def call(name, args_json="{}"):
    try:
        out = svc.call(name, json.loads(args_json or "{}"))
        return json.dumps({"result": out}, default=str, ensure_ascii=False)
    except Exception as e:  # noqa: BLE001
        from .registry import ApiError
        if isinstance(e, ApiError):
            return json.dumps({"error": str(e), "code": e.code, **e.extra}, default=str)
        if isinstance(e, TypeError):
            return json.dumps({"error": f"bad arguments: {e}"})
        traceback.print_exc()
        return json.dumps({"error": f"{e.__class__.__name__}: {e}"})


def tick():
    try:
        sched.tick()
    except Exception:  # noqa: BLE001 - housekeeping never breaks the app
        traceback.print_exc()


def grant(path):
    """A file the person picked in the browser's file chooser (placed in /uploads)."""
    return svc.grant(path)


def recycle_state():
    """What a fresh engine needs to put the person back exactly where they were (used when the browser engine is restarted to give memory back, or after a crash): who is signed in
    (the same key 'Stay signed in' would keep - it only ever lives in the page's memory here), or that they are looking around as a guest, and which game is open."""
    if svc is None:
        return json.dumps({"kind": "none"})
    try:
        game = svc.game.id if svc.game is not None else ""
    except Exception:  # noqa: BLE001
        game = ""
    if svc.guest:
        return json.dumps({"kind": "guest", "game": game})
    if svc.session is not None:
        from ..security import crypto
        return json.dumps({"kind": "session", "id": svc.session.pid, "key": crypto.b64(svc.auth.device_key(svc.session)), "game": game})
    return json.dumps({"kind": "none", "game": game})


def persist():
    """Write the open collection (encrypted) to the browser's storage area.  Returns "" when it worked, else the reason (the page shows it and tries again)."""
    err = ""
    if svc is not None and svc.session is not None:
        try:
            svc.session.persist()
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            err = f"{e.__class__.__name__}: {e}"
        try:
            import gc
            gc.collect()                          # the browser build has a fixed amount of memory: hand back what saving used straight away
        except Exception:  # noqa: BLE001
            pass
    return err


def rescue_path():
    """The encrypted collection file of the signed-in account (the page parks a copy of it when the browser refuses a normal save)."""
    try:
        return svc.session.enc_path if svc is not None and svc.session is not None else ""
    except Exception:  # noqa: BLE001
        return ""


_seen = 0.0


def changed():
    """True once after each change to the person's data (the page then saves it right away instead of waiting for a timer)."""
    global _seen
    if svc is not None and svc.last_change > _seen:
        _seen = svc.last_change
        return True
    return False
