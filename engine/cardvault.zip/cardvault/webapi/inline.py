"""What the browser's engine worker calls.  Same data service as the desktop app, run one call at a time (no threads) inside a web worker.

boot(config_json) -> start;  call(name, args_json) -> reply json;  tick() -> housekeeping;  persist() -> write unsaved changes now;
fetches() / fetch_body(id) / fetched(id, ...) -> the requests a background job is waiting for, which the page sends with fetch() (so a sync never freezes the screens).
lazy_start(...) / game_loaded(game) / lib_loaded(name) -> a game's card list and Pillow are read in only when something needs them (ui/src/engine/gamestores.js)."""
import json
import os
import sys
import traceback

svc = None
sched = None
_emit = None


def _send(ev):
    if _emit is not None:
        try:
            _emit(json.dumps(ev, default=str))
        except Exception:  # noqa: BLE001
            pass


# Headers only the browser itself may set: sent through pyodide_http's XMLHttpRequest each one is refused with a console error (requests adds Accept-Encoding, Connection and
# Content-Length to every request), so they are taken off first.  The browser adds its own.
FORBIDDEN_HEADERS = ("Accept-Charset", "Accept-Encoding", "Access-Control-Request-Headers", "Access-Control-Request-Method", "Connection", "Content-Length", "Cookie", "Cookie2",
                     "Date", "DNT", "Expect", "Host", "Keep-Alive", "Origin", "Referer", "TE", "Trailer", "Transfer-Encoding", "Upgrade", "User-Agent", "Via")


def browser_headers():
    """Keep the headers above from reaching the browser.  Safe to call twice.
    pyodide_http mounts its OWN adapter (PyodideHTTPAdapter, a BaseAdapter - not requests' HTTPAdapter), so that is the one wrapped; its low-level send (used by urllib too)
    also skips every name in pyodide_http._core.HEADERS_TO_IGNORE, which gets the same list."""
    from requests.adapters import HTTPAdapter
    targets = [HTTPAdapter]
    try:
        from pyodide_http import _core, _requests
        _core.HEADERS_TO_IGNORE = tuple(sorted(set(_core.HEADERS_TO_IGNORE) | {h.lower() for h in FORBIDDEN_HEADERS}))
        targets.insert(0, _requests.PyodideHTTPAdapter)
    except Exception:  # noqa: BLE001 - not in the browser (desktop / tests): only requests' own adapter is there
        pass
    for cls in targets:
        send = cls.send
        if getattr(send, "_cv_quiet", False):
            continue

        def quiet_send(self, request, *a, _send=send, **kw):
            for h in FORBIDDEN_HEADERS:
                request.headers.pop(h, None)
            return _send(self, request, *a, **kw)
        quiet_send._cv_quiet = True
        cls.send = quiet_send


def boot(config_json, emit=None):
    global svc, sched, _emit
    cfg = json.loads(config_json or "{}")
    from ..runtime import IN_BROWSER
    if IN_BROWSER:
        try:
            browser_headers()
        except Exception:  # noqa: BLE001 - only quieter, never needed to work
            pass
    _emit = emit
    from ..paths import load_config
    from . import Service
    from .scheduler import Scheduler
    base = load_config()
    base.update(cfg)
    os.makedirs(base["data_dir"], exist_ok=True)
    os.makedirs("/downloads", exist_ok=True)
    os.makedirs("/uploads", exist_ok=True)
    try:
        from ..cloud import skycloud
        skycloud.SITE_BASE = base.get("site_url", "")                       # lets the sign-in maths use the browser's fast crypto (see skycloud._pbkdf2_in_browser)
    except Exception:  # noqa: BLE001
        pass
    svc = Service(base)
    svc.listeners.append(_send)
    sched = Scheduler(svc).start()
    return json.dumps({"ok": True, "error": svc.error})


def call(name, args_json="{}"):
    from . import deferred
    try:
        deferred.TOP[0] = True                                      # (the one call the page makes may go on as a job whose requests the page sends - webapi/deferred.py)
        _IN_CALL[0] = True
        try:
            out = _guarded(name, lambda: svc.call(name, json.loads(args_json or "{}")))
        finally:
            deferred.TOP[0] = False
            _IN_CALL[0] = False
        return json.dumps({"result": out}, default=str, ensure_ascii=False)
    except deferred.Deferred as d:
        return json.dumps({"deferred": d.jid})
    except NeedGame as n:                                           # the page reads that game's card list in and asks again
        return json.dumps({"needGame": n.game})
    except NeedLib as n:
        return json.dumps({"needLib": n.lib})
    except Exception as e:  # noqa: BLE001 - plain words for the page; the detail goes to the log
        from .plainerror import reply
        return json.dumps(reply(e)[1], default=str)


def deferred_poll(jid):
    """The answer of a call that went on as a job (see call): {"deferred": id} while it is still going, else the same reply as call()."""
    from . import deferred
    state, val = deferred.poll(svc, int(jid))
    if state == "pending":
        return json.dumps({"deferred": int(jid)})
    if state == "ok":
        return json.dumps({"result": val}, default=str, ensure_ascii=False)
    from .plainerror import reply
    return json.dumps(reply(val)[1], default=str)


def profile(name, args_json="{}", top=30):
    """(a developer's tool, reached through the page's cv:debug hook) Run one call under the profiler and say where its time went: what is slow in the browser engine can only be seen from inside it."""
    import cProfile
    import io
    import pstats
    pr = cProfile.Profile()
    pr.enable()
    try:
        reply = call(name, args_json)
    finally:
        pr.disable()
    text = io.StringIO()
    pstats.Stats(pr, stream=text).sort_stats("cumulative").print_stats(top)
    return json.dumps({"reply": reply[:600], "profile": text.getvalue()})


def tick():
    """The once-a-second housekeeping.  -> seconds until work() is worth calling (background work is part-way), or None."""
    try:
        return sched.tick()
    except Exception:  # noqa: BLE001 - housekeeping never breaks the app
        traceback.print_exc()


def work():
    """The next short piece of background work between ticks (see scheduler.work).  -> seconds until the next, or None."""
    try:
        return sched.work()
    except Exception:  # noqa: BLE001
        traceback.print_exc()


def grant(path):
    """A file the person picked in the browser's file chooser (placed in /uploads)."""
    return svc.grant(path)


def recycle_state():
    """What a fresh engine needs to put the person back exactly where they were (used when the browser engine is restarted to give memory back, or after a crash): who is signed in
    (the same key 'Stay signed in' would keep - it only ever lives in the page's memory here), or that they are looking around as a guest, and which game is open."""
    if svc is None:
        return json.dumps({"kind": "none"})
    try:
        game = svc.game.id if svc.game is not None else ""
    except Exception:  # noqa: BLE001
        game = ""
    if svc.guest:
        return json.dumps({"kind": "guest", "game": game})
    if svc.session is not None:
        from ..security import crypto
        return json.dumps({"kind": "session", "id": svc.session.pid, "key": crypto.b64(svc.auth.device_key(svc.session)), "game": game})
    return json.dumps({"kind": "none", "game": game})


def persist():
    """Write the open collection (encrypted) to the browser's storage area.  Returns "" when it worked, else the reason (the page shows it and tries again)."""
    err = ""
    if svc is not None and svc.session is not None:
        if sched is not None:
            sched.persist_mark = max(sched.persist_mark, svc.last_change)          # (written here: the housekeeping does not encrypt the same collection again a moment later)
        try:
            svc.session.persist()
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            err = f"{e.__class__.__name__}: {e}"
        try:
            import gc
            gc.collect()                          # the browser build has a fixed amount of memory: hand back what saving used straight away
        except Exception:  # noqa: BLE001
            pass
    return err


def rescue_path():
    """The encrypted collection file of the signed-in account (the page parks a copy of it when the browser refuses a normal save)."""
    try:
        return svc.session.enc_path if svc is not None and svc.session is not None else ""
    except Exception:  # noqa: BLE001
        return ""


def fetches():
    """The requests background jobs are waiting for that the page has not been given yet -> JSON [{id, method, url, headers, timeout, body: bool, binary: bool}] (the body itself:
    fetch_body).  binary: a file download (steps.Download) - the page hands its bytes back (fetched's `blob`), not text."""
    from . import jobs
    out = []
    for rid, req in jobs.take_new():
        out.append({"id": rid, "method": req.method, "url": req.url, "headers": req.headers(), "timeout": req.timeout, "body": req.payload is not None,
                    "binary": bool(getattr(req, "binary", False))})
    return json.dumps(out)


def fetch_body(rid):
    from . import jobs
    job_req = jobs.OUT.get(int(rid))
    return (job_req[1].body or "") if job_req else ""


def fetched(rid, status=0, text="", error="", blob=None, date=""):
    """The page's answer to request `rid` (status and body text - or, for a file download, `blob`: the bytes as a JS Uint8Array - or what went wrong: "timeout" / a reason)
    -> seconds until work() is worth calling (the job carries on), or None."""
    from . import jobs
    try:
        if blob is not None:
            text = blob.to_bytes() if hasattr(blob, "to_bytes") else bytes(blob)          # (one copy into the engine's memory: milliseconds even for a big card list)
        return 0 if jobs.answered(int(rid), int(status or 0), text or "", error or "", date=date or "") else None
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        return None


_seen = 0.0


def changed():
    """True once after each change to the person's data (the page then saves it right away instead of waiting for a timer)."""
    global _seen
    if svc is not None and svc.last_change > _seen:
        _seen = svc.last_change
        return True
    return False


# ---- a game's card list and Pillow only when needed (3.50.136 lane E; the page's side: ui/src/engine/gamestores.js and worker.js)
# Until a game is opened its folder holds empty stand-in files (so "is this list on the device?" still says yes).  Anything that really opens, writes or deletes a file in it is
# stopped here, before it happens: during the page's call the call stops (NeedGame), the page reads the list in and makes the call again - what the stopped run changed in the
# collection is taken back first (_guarded), so the change is made once.  In the housekeeping and jobs the file simply cannot be opened yet (as if it were not there); a WRITE asks
# the page to read that list in.  Pillow the same way: it is loaded with the first photo or scan.
class NeedGame(BaseException):
    """A call reached a game whose card list is not read in yet (not an Exception: the call's own `except Exception` must not swallow it)."""

    def __init__(self, game):
        super().__init__(game)
        self.game = game


class NeedLib(BaseException):
    """A call reached a library that is loaded only when first needed (Pillow)."""

    def __init__(self, lib):
        super().__init__(lib)
        self.lib = lib


_LAZY = set()                   # games whose folder holds only stand-ins
_ROOT = [""]                    # "<data dir>/games/"
_IN_CALL = [False]              # inside the page's call (inline.call)
_WANT = [None]                  # the page's callback (kind, name): the housekeeping wants a list / library read in
_LIBS = {"pillow": True}        # (True: there - the desktop and the tests; the browser marks it missing until it is loaded)
_HOOKED = [False]
_PATH_ARGS = {"open": (0,), "sqlite3.connect": (0,), "os.mkdir": (0,), "os.remove": (0,), "os.rmdir": (0,), "os.rename": (0, 1), "os.truncate": (0,),
              "os.link": (0, 1), "os.symlink": (0, 1), "shutil.rmtree": (0,), "shutil.copyfile": (0, 1), "shutil.copytree": (0, 1), "shutil.move": (0, 1)}


def _want(kind, name):
    cb = _WANT[0]
    if cb is not None:
        try:
            cb(kind, name)
        except Exception:  # noqa: BLE001 - only a hint for the page
            pass


def _lazy_game(path):
    """The game a path lies in, when that game's list is not read in yet, else ""."""
    try:
        p = os.fspath(path)
    except TypeError:
        return ""
    if isinstance(p, bytes):
        p = p.decode("utf-8", "replace")
    if not isinstance(p, str):
        return ""
    if p.startswith("file:"):                                       # (an sqlite URI)
        p = p[5:].split("?", 1)[0]
    root = _ROOT[0]
    if not root or not (p + os.sep).startswith(root) or ".." in p:
        return ""
    g = p[len(root):].replace("\\", "/").split("/", 1)[0]           # (the browser's paths have "/" only; the desktop-style tests' have "\")
    return g if g in _LAZY else ""


def _is_read(event, args):
    if event != "open":
        return False
    mode, flags = (tuple(args) + (None, None))[1:3]
    if isinstance(mode, str):
        return not any(c in mode for c in "wax+")
    return isinstance(flags, int) and not flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)


def _audit(event, args):
    if not _LAZY:
        return
    idx = _PATH_ARGS.get(event)
    if idx is None:
        return
    for i in idx:
        g = _lazy_game(args[i]) if i < len(args) else ""
        if not g:
            continue
        p = os.fspath(args[i])
        if event == "os.mkdir" and os.path.isdir(p):
            return                                                  # (os.makedirs(..., exist_ok=True) of a folder that is there: nothing is written)
        if _IN_CALL[0]:
            raise NeedGame(g)
        if event == "sqlite3.connect":
            import sqlite3
            raise sqlite3.OperationalError(f"unable to open database file (the {g} card list is not open yet)")
        import errno
        if _is_read(event, args):
            raise FileNotFoundError(errno.ENOENT, f"the {g} card list is not open yet", p)
        _want("game", g)
        raise PermissionError(errno.EACCES, f"the {g} card list is not open yet", p)


class _LazyLibs:
    """Finds nothing itself: it only notices the first `import PIL` while Pillow is not loaded yet."""

    @staticmethod
    def find_spec(name, path=None, target=None):
        if (name == "PIL" or name.startswith("PIL.")) and not _LIBS.get("pillow", True):
            if _IN_CALL[0]:
                raise NeedLib("pillow")
            _want("lib", "pillow")                                  # (the housekeeping carries on as without Pillow; the page loads it for next time)
        return None


def lazy_start(data_dir, lazy_json="[]", want=None, pillow=False):
    """Before boot: the games whose list is not read in yet, the page's callback, and whether Pillow is loaded.  The hooks are added once (an audit hook cannot be taken off again)."""
    _ROOT[0] = os.path.join(data_dir, "games", "")
    _LAZY.clear()
    _LAZY.update(json.loads(lazy_json or "[]"))
    _WANT[0] = want
    _LIBS["pillow"] = bool(pillow)
    if not _HOOKED[0]:
        _HOOKED[0] = True
        sys.addaudithook(_audit)
        sys.meta_path.insert(0, _LazyLibs)


def start_game():
    """The game that opens first (read in before boot, so opening the app never waits for it twice)."""
    try:
        from ..paths import load_config
        return str(load_config().get("game") or "pokemon")
    except Exception:  # noqa: BLE001
        return "pokemon"


def game_loaded(game):
    _LAZY.discard(game)
    if svc is not None:
        try:
            svc._exists.clear()                                     # (what was looked up while only the stand-ins were there)
        except Exception:  # noqa: BLE001
            pass
    if sched is not None:
        try:
            sched.game_loaded(game)
        except Exception:  # noqa: BLE001
            traceback.print_exc()


def lib_loaded(name):
    _LIBS[name] = True
    import importlib
    importlib.invalidate_caches()


def _guarded(name, run):
    """A call that changes the collection while a list or Pillow may still be missing: in one change that is taken back when the call stops for one (NeedGame / NeedLib), so the
    run that gets to the end makes it once.  (The savepoint way of deferred._try.)"""
    if not _LAZY and _LIBS.get("pillow", True):
        return run()
    try:
        from .registry import METHODS
        mutates = bool(METHODS.get(name, (None, False))[1])
    except Exception:  # noqa: BLE001
        mutates = False
    v = getattr(svc, "vault", None)
    conn = getattr(v, "conn", None)
    if not mutates or conn is None:
        return run()
    prev = v._defer
    try:
        v.settle()
        conn.execute("SAVEPOINT cv_need")
    except Exception:  # noqa: BLE001 - no savepoint: the call runs as it always did
        return run()
    v._defer = True
    try:
        out = run()
    except (NeedGame, NeedLib):
        v._defer = prev
        try:
            conn.execute("ROLLBACK TO cv_need")
            conn.execute("RELEASE cv_need")
        except Exception:  # noqa: BLE001 - the call saved for good before it stopped (its own commit): it is made again in full
            print(f"inline: {name} saved a change before it stopped for a card list / Pillow", file=sys.stderr)
        raise
    except BaseException:
        v._defer = prev
        _release(conn, prev)
        raise
    v._defer = prev
    _release(conn, prev)
    return out


def _release(conn, prev):
    try:
        conn.execute("RELEASE cv_need")
    except Exception:  # noqa: BLE001 - (the call committed, or switched game: the savepoint went with it)
        pass
    try:
        if not prev and conn.in_transaction:
            conn.commit()
    except Exception:  # noqa: BLE001
        pass
