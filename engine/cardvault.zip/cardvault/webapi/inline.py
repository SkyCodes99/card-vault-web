"""What the browser's engine worker calls.  Same data service as the desktop app, run one call at a time (no threads) inside a web worker.

boot(config_json) -> start;  call(name, args_json) -> reply json;  tick() -> housekeeping;  persist() -> write unsaved changes now;
fetches() / fetch_body(id) / fetched(id, ...) -> the requests a background job is waiting for, which the page sends with fetch() (so a sync never freezes the screens)."""
import json
import os
import sys
import traceback

svc = None
sched = None
_emit = None


def _send(ev):
    if _emit is not None:
        try:
            _emit(json.dumps(ev, default=str))
        except Exception:  # noqa: BLE001
            pass


# Headers only the browser itself may set: sent through pyodide_http's XMLHttpRequest each one is refused with a console error (requests adds Accept-Encoding, Connection and
# Content-Length to every request), so they are taken off first.  The browser adds its own.
FORBIDDEN_HEADERS = ("Accept-Charset", "Accept-Encoding", "Access-Control-Request-Headers", "Access-Control-Request-Method", "Connection", "Content-Length", "Cookie", "Cookie2",
                     "Date", "DNT", "Expect", "Host", "Keep-Alive", "Origin", "Referer", "TE", "Trailer", "Transfer-Encoding", "Upgrade", "User-Agent", "Via")


def browser_headers():
    """Keep the headers above from reaching the browser.  Safe to call twice.
    pyodide_http mounts its OWN adapter (PyodideHTTPAdapter, a BaseAdapter - not requests' HTTPAdapter), so that is the one wrapped; its low-level send (used by urllib too)
    also skips every name in pyodide_http._core.HEADERS_TO_IGNORE, which gets the same list."""
    from requests.adapters import HTTPAdapter
    targets = [HTTPAdapter]
    try:
        from pyodide_http import _core, _requests
        _core.HEADERS_TO_IGNORE = tuple(sorted(set(_core.HEADERS_TO_IGNORE) | {h.lower() for h in FORBIDDEN_HEADERS}))
        targets.insert(0, _requests.PyodideHTTPAdapter)
    except Exception:  # noqa: BLE001 - not in the browser (desktop / tests): only requests' own adapter is there
        pass
    for cls in targets:
        send = cls.send
        if getattr(send, "_cv_quiet", False):
            continue

        def quiet_send(self, request, *a, _send=send, **kw):
            for h in FORBIDDEN_HEADERS:
                request.headers.pop(h, None)
            return _send(self, request, *a, **kw)
        quiet_send._cv_quiet = True
        cls.send = quiet_send


def boot(config_json, emit=None):
    global svc, sched, _emit
    cfg = json.loads(config_json or "{}")
    from ..runtime import IN_BROWSER
    if IN_BROWSER:
        try:
            browser_headers()
        except Exception:  # noqa: BLE001 - only quieter, never needed to work
            pass
    _emit = emit
    from ..paths import load_config
    from . import Service
    from .scheduler import Scheduler
    base = load_config()
    base.update(cfg)
    os.makedirs(base["data_dir"], exist_ok=True)
    os.makedirs("/downloads", exist_ok=True)
    os.makedirs("/uploads", exist_ok=True)
    try:
        from ..cloud import skycloud
        skycloud.SITE_BASE = base.get("site_url", "")                       # lets the sign-in maths use the browser's fast crypto (see skycloud._pbkdf2_in_browser)
    except Exception:  # noqa: BLE001
        pass
    svc = Service(base)
    svc.listeners.append(_send)
    sched = Scheduler(svc).start()
    return json.dumps({"ok": True, "error": svc.error})


def call(name, args_json="{}"):
    from . import deferred
    try:
        deferred.TOP[0] = True                                      # (the one call the page makes may go on as a job whose requests the page sends - webapi/deferred.py)
        try:
            out = svc.call(name, json.loads(args_json or "{}"))
        finally:
            deferred.TOP[0] = False
        return json.dumps({"result": out}, default=str, ensure_ascii=False)
    except deferred.Deferred as d:
        return json.dumps({"deferred": d.jid})
    except Exception as e:  # noqa: BLE001 - plain words for the page; the detail goes to the log
        from .plainerror import reply
        return json.dumps(reply(e)[1], default=str)


def deferred_poll(jid):
    """The answer of a call that went on as a job (see call): {"deferred": id} while it is still going, else the same reply as call()."""
    from . import deferred
    state, val = deferred.poll(svc, int(jid))
    if state == "pending":
        return json.dumps({"deferred": int(jid)})
    if state == "ok":
        return json.dumps({"result": val}, default=str, ensure_ascii=False)
    from .plainerror import reply
    return json.dumps(reply(val)[1], default=str)


def profile(name, args_json="{}", top=30):
    """(a developer's tool, reached through the page's cv:debug hook) Run one call under the profiler and say where its time went: what is slow in the browser engine can only be seen from inside it."""
    import cProfile
    import io
    import pstats
    pr = cProfile.Profile()
    pr.enable()
    try:
        reply = call(name, args_json)
    finally:
        pr.disable()
    text = io.StringIO()
    pstats.Stats(pr, stream=text).sort_stats("cumulative").print_stats(top)
    return json.dumps({"reply": reply[:600], "profile": text.getvalue()})


def tick():
    """The once-a-second housekeeping.  -> seconds until work() is worth calling (background work is part-way), or None."""
    try:
        return sched.tick()
    except Exception:  # noqa: BLE001 - housekeeping never breaks the app
        traceback.print_exc()


def work():
    """The next short piece of background work between ticks (see scheduler.work).  -> seconds until the next, or None."""
    try:
        return sched.work()
    except Exception:  # noqa: BLE001
        traceback.print_exc()


def grant(path):
    """A file the person picked in the browser's file chooser (placed in /uploads)."""
    return svc.grant(path)


def recycle_state():
    """What a fresh engine needs to put the person back exactly where they were (used when the browser engine is restarted to give memory back, or after a crash): who is signed in
    (the same key 'Stay signed in' would keep - it only ever lives in the page's memory here), or that they are looking around as a guest, and which game is open."""
    if svc is None:
        return json.dumps({"kind": "none"})
    try:
        game = svc.game.id if svc.game is not None else ""
    except Exception:  # noqa: BLE001
        game = ""
    if svc.guest:
        return json.dumps({"kind": "guest", "game": game})
    if svc.session is not None:
        from ..security import crypto
        return json.dumps({"kind": "session", "id": svc.session.pid, "key": crypto.b64(svc.auth.device_key(svc.session)), "game": game})
    return json.dumps({"kind": "none", "game": game})


def persist():
    """Write the open collection (encrypted) to the browser's storage area.  Returns "" when it worked, else the reason (the page shows it and tries again)."""
    err = ""
    if svc is not None and svc.session is not None:
        if sched is not None:
            sched.persist_mark = max(sched.persist_mark, svc.last_change)          # (written here: the housekeeping does not encrypt the same collection again a moment later)
        try:
            svc.session.persist()
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            err = f"{e.__class__.__name__}: {e}"
        try:
            import gc
            gc.collect()                          # the browser build has a fixed amount of memory: hand back what saving used straight away
        except Exception:  # noqa: BLE001
            pass
    return err


def rescue_path():
    """The encrypted collection file of the signed-in account (the page parks a copy of it when the browser refuses a normal save)."""
    try:
        return svc.session.enc_path if svc is not None and svc.session is not None else ""
    except Exception:  # noqa: BLE001
        return ""


def fetches():
    """The requests background jobs are waiting for that the page has not been given yet -> JSON [{id, method, url, headers, timeout, body: bool, binary: bool}] (the body itself:
    fetch_body).  binary: a file download (steps.Download) - the page hands its bytes back (fetched's `blob`), not text."""
    from . import jobs
    out = []
    for rid, req in jobs.take_new():
        out.append({"id": rid, "method": req.method, "url": req.url, "headers": req.headers(), "timeout": req.timeout, "body": req.payload is not None,
                    "binary": bool(getattr(req, "binary", False))})
    return json.dumps(out)


def fetch_body(rid):
    from . import jobs
    job_req = jobs.OUT.get(int(rid))
    return (job_req[1].body or "") if job_req else ""


def fetched(rid, status=0, text="", error="", blob=None):
    """The page's answer to request `rid` (status and body text - or, for a file download, `blob`: the bytes as a JS Uint8Array - or what went wrong: "timeout" / a reason)
    -> seconds until work() is worth calling (the job carries on), or None."""
    from . import jobs
    try:
        if blob is not None:
            text = blob.to_bytes() if hasattr(blob, "to_bytes") else bytes(blob)          # (one copy into the engine's memory: milliseconds even for a big card list)
        return 0 if jobs.answered(int(rid), int(status or 0), text or "", error or "") else None
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        return None


_seen = 0.0


def changed():
    """True once after each change to the person's data (the page then saves it right away instead of waiting for a timer)."""
    global _seen
    if svc is not None and svc.last_change > _seen:
        _seen = svc.last_change
        return True
    return False
