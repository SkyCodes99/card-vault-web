"""The running application's state (settings, the open collection) plus the worker thread every API call goes through.

The app starts LOCKED: nothing about your collection is readable until you sign in.  Signing in decrypts your collection into a private
working folder; locking (or quitting, or the auto-lock) encrypts it back and wipes every readable copy."""
import os
import queue
import threading
import time
import traceback
import urllib.parse

from .. import bulbapedia, currency, games
from ..db import BlockedPortfolio, Vault, game_dir, image_file, logo_file, picture_url
from ..paths import load_config, save_config
from .. import runtime
from ..runtime import INLINE
from ..security.profiles import AuthManager
from .jobs import Jobs
from .registry import METHODS, PUBLIC, QUIET, ApiError  # noqa: F401  (ApiError is re-exported)

# keys that belong to the signed-in account (kept in its encrypted secrets, never in the shared config file)
PROFILE_KEYS = {"github_token", "sync_repo", "sync_enabled", "sync_last", "backup_dir", "autolock_minutes", "sync_key"}


_TAKES = {}


def _takes(fn, arg):
    """Does this method accept a keyword argument of that name?"""
    key = (fn, arg)
    if key not in _TAKES:
        import inspect
        try:
            ps = inspect.signature(fn).parameters
            _TAKES[key] = arg in ps or any(p.kind == p.VAR_KEYWORD for p in ps.values())
        except (TypeError, ValueError):
            _TAKES[key] = True
    return _TAKES[key]


GUEST_OK_PREFIX = ("auth.", "jobs.", "games.", "game.", "currency.", "app.", "dialog")      # looking around may switch games, fetch card lists, change the look
GUEST_OK = {"settings.set", "portfolio.setScope", "portfolio.setTarget", "tour.done", "undo", "redo"}


class Service:
    def __init__(self, cfg=None, insecure=None):
        self.cfg = cfg or load_config()
        # development / tests only: the old single-user, unencrypted behaviour.  Never reachable from the screens or the config file.
        self.insecure = (os.environ.get("CARDVAULT_INSECURE_DEV") == "1") if insecure is None else insecure
        currency.configure(self.cfg)
        self.auth = AuthManager(self.cfg["data_dir"])
        self.session = None
        self.guest = False           # looking around without an account: a throw-away, read-only collection that is never saved
        self.guest_cfg = {}
        self.guest_dir = None
        self.q = queue.Queue()
        self.rev = 0
        self.vault = None
        self.owned = {}
        self.wishlist = set()
        self._exists = {}
        self.listeners = []          # callables(event dict) - the server's event stream
        self.on_unlock = []          # callables() run after sign-in (the scheduler's start-up tasks)
        self.jobs = Jobs(self)
        self.last_change = 0.0       # when your data last changed (the scheduler uses it for backups and sync)
        self.last_activity = time.time()
        self.dialog_host = None      # the desktop window registers its native file pickers here
        self.quit_app = None         # ... and a way to close the app (used after installing an update)
        self.grants = {}             # file paths the user chose in a native dialog -> when (exports / imports may only touch these)
        self.ready = threading.Event()
        self.error = None
        self.inline = INLINE
        runtime.service = self
        if self.inline:                  # no threads (the browser): calls run directly, one at a time
            self._boot()
            self.ready.set()
        else:
            self.thread = threading.Thread(target=self._loop, name="cardvault-api", daemon=True)
            self.thread.start()
            self.ready.wait(60)

    # ---------------------------------------------------------------- worker
    def _boot(self):
        try:
            if self.insecure:
                self.open_game(self.cfg.get("game", "pokemon"))
            elif not runtime.IN_BROWSER:
                self._resume_device()
        except Exception as e:  # noqa: BLE001
            self.error = f"{e.__class__.__name__}: {e}"

    def _resume_device(self):
        """The Windows app set to 'Stay signed in': open the collection again without asking for the password (the key is in a file only this Windows user can open)."""
        from ..security import devicekey
        if not devicekey.supported():
            return
        for pid in devicekey.saved_profiles(self.cfg["data_dir"]):
            path = devicekey.path_for(self.cfg["data_dir"], pid)
            try:
                with open(path, "rb") as f:
                    key = devicekey.unprotect(f.read())
                self.start_session(self.auth.resume(pid, key))
                return
            except Exception:  # noqa: BLE001 - password changed / file from another Windows user: it just asks for the password
                try:
                    os.remove(path)
                except OSError:
                    pass

    def _loop(self):
        self._boot()
        self.ready.set()
        while True:
            job = self.q.get()
            if job is None:
                break
            fn, args, box, done = job
            try:
                box.append((True, fn(self, **args)))
            except ApiError as e:
                box.append((False, e))
            except BlockedPortfolio as e:
                box.append((False, ApiError(str(e), code="blocked")))
            except Exception as e:  # noqa: BLE001
                traceback.print_exc()
                box.append((False, ApiError(f"{e.__class__.__name__}: {e}")))
            done.set()

    @property
    def unlocked(self):
        return self.insecure or self.session is not None or self.guest

    def call(self, name, args=None, timeout=300):
        if name not in METHODS:
            raise ApiError(f"unknown method {name}")
        if name not in PUBLIC and not self.unlocked:
            raise ApiError("The app is locked. Sign in to continue.", code="locked")
        if name == "auth.ping":                      # only real use (clicks, keys) keeps the app unlocked - background refreshes do not
            self.last_activity = time.time()
        fn, mutates = METHODS[name]
        if self.guest and mutates and not name.startswith(GUEST_OK_PREFIX) and name not in GUEST_OK:
            raise ApiError("You're looking around as a guest, so nothing can be saved. Create a free account (or sign in) to keep what you add.", code="guest")
        if args and "t" in args and not _takes(fn, "t"):          # screens add a throw-away refresh counter "t" to re-ask; a method that doesn't use it just ignores it
            args = {k: v for k, v in args.items() if k != "t"}
        if self.inline:
            try:
                val = fn(self, **(args or {}))
            except ApiError:
                raise
            except BlockedPortfolio as e:
                raise ApiError(str(e), code="blocked")
            except Exception as e:  # noqa: BLE001
                traceback.print_exc()
                raise ApiError(f"{e.__class__.__name__}: {e}")
        else:
            box, done = [], threading.Event()
            self.q.put((fn, args or {}, box, done))
            if not done.wait(timeout):
                raise ApiError("timed out")
            ok, val = box[0]
            if not ok:
                raise val
        if mutates:
            self.bump("changed")
        return val

    def run(self, fn, timeout=300):
        """Run fn(service) on the worker thread (for tests and background jobs that need the open collection)."""
        if self.inline:
            return fn(self)
        box, done = [], threading.Event()
        self.q.put((lambda svc: fn(svc), {}, box, done))
        done.wait(timeout)
        ok, val = box[0]
        if not ok:
            raise val
        return val

    def bump(self, kind="changed", **extra):
        if kind == "changed":
            self.last_change = time.time()
        self.rev += 1
        ev = {"type": kind, "rev": self.rev, **extra}
        for fn in list(self.listeners):
            try:
                fn(ev)
            except Exception:  # noqa: BLE001
                pass

    # ---------------------------------------------------------------- signing in and out (worker thread only)
    def start_session(self, session):
        """Called after a successful sign-in / account creation."""
        self.session = session
        self.last_activity = time.time()
        self.grants.clear()
        # an older version kept the GitHub token in the shared config file: move it into this account's encrypted secrets
        legacy = self.cfg.pop("github_token", None)
        if legacy and not session.get("github_token"):
            from .. import updater
            session.set("github_token", updater.unprotect(legacy))
        for k in ("sync_repo", "sync_enabled", "sync_last", "backup_dir"):
            if k in self.cfg and session.get(k) is None:
                session.set(k, self.cfg.pop(k))
        self.save()
        self.open_game(self.cfg.get("game", "pokemon"))
        self.bump("unlocked")
        for fn in list(self.on_unlock):
            try:
                fn()
            except Exception:  # noqa: BLE001
                pass

    def start_guest(self):
        """Look around without an account: a temporary, empty, read-only collection in a scratch folder that is deleted when the guest leaves."""
        import tempfile
        if self.session is not None or self.guest:
            return
        self.guest, self.guest_cfg = True, {}
        self.guest_dir = tempfile.mkdtemp(prefix="cea_guest_")
        self.last_activity = time.time()
        self.grants.clear()
        self.open_game(self.cfg.get("game", "pokemon"))
        self.bump("unlocked")

    def end_guest(self):
        import shutil
        try:
            if self.vault:
                self.vault.close()
        finally:
            self.vault, self.guest, self.guest_cfg = None, False, {}
            self.owned, self.wishlist = {}, set()
            self._exists.clear()
            if self.guest_dir:
                shutil.rmtree(self.guest_dir, ignore_errors=True)
            self.guest_dir = None
        self.bump("locked", reason="guest left")

    def lock(self, reason="manual"):
        """Encrypt everything back to disk and forget the key."""
        if self.guest:
            self.end_guest()
            return
        if self.session is None:
            return
        sess = self.session
        try:
            if self.vault:
                try:
                    self.vault.backup_now("lock") if self.vault._changes_since_backup else None
                except Exception:  # noqa: BLE001
                    pass
                self.vault.close()
        finally:
            self.vault, self.session = None, None
            self.owned, self.wishlist = {}, set()
            self._exists.clear()
            self.grants.clear()
            sess.log_event("locked", reason)
            sess.lock()
        self.bump("locked", reason=reason)

    def audit(self, kind, detail=""):
        """Write one line to this account's security activity log (sign-ins, exports, links...)."""
        if self.session is not None:
            try:
                self.session.log_event(kind, detail)
            except Exception:  # noqa: BLE001 - the log must never break what it is recording
                pass

    def pget(self, key, default=None):
        """A setting that belongs to the signed-in account (falls back to the shared config in the unencrypted dev mode)."""
        if self.guest:
            return self.guest_cfg.get(key, default)
        if self.session is not None:
            v = self.session.get(key)
            return default if v is None else v
        return self.cfg.get(key, default)

    def pset(self, key, value):
        if self.guest:
            if value is None:
                self.guest_cfg.pop(key, None)
            else:
                self.guest_cfg[key] = value
            return
        if self.session is not None:
            self.session.set(key, value)
        elif value is None:
            self.cfg.pop(key, None)
        else:
            self.cfg[key] = value
            self.save()

    # ---------------------------------------------------------------- state (worker thread only)
    def open_game(self, game_id):
        if self.vault:
            self.vault.close()
        self.cfg["game"] = game_id
        if self.guest:
            self.vault = Vault(self.cfg["data_dir"], game_id, user_path=os.path.join(self.guest_dir, "guest.db"))
        elif self.session is not None:
            self.vault = Vault(self.cfg["data_dir"], game_id, user_path=self.session.db_path, secure=self.session)
        else:
            self.vault = Vault(self.cfg["data_dir"], game_id)
        self._exists.clear()
        self.apply_names()
        from .portfolios import load_scope
        load_scope(self)
        self.reload_state()
        try:
            from .settings import prefs_adopt
            prefs_adopt(self)
        except Exception:  # noqa: BLE001 - a missing / damaged preference must never stop the collection opening
            traceback.print_exc()

    def apply_names(self):
        """Japanese card list: show the English names (the default) or the Japanese ones, as chosen in Settings.  -> True when the names on screen changed."""
        try:
            from .. import names
            return names.apply(self.vault.conn, self.pget("jp_names", "english"))
        except Exception:  # noqa: BLE001 - names are a convenience; never stop the collection from opening
            return False

    def reload_state(self):
        self.owned = self.vault.owned_map()
        self.wishlist = self.vault.wishlist_ids()

    def save(self):
        save_config(self.cfg)

    @property
    def game(self):
        return games.game_by_id(self.vault.game)

    # ---------------------------------------------------------------- files the user picked (exports / imports may only touch these)
    def grant(self, path):
        if path:
            self.grants[os.path.normcase(os.path.abspath(path))] = time.time()
        return path

    def need_grant(self, path):
        p = os.path.normcase(os.path.abspath(path or ""))
        if not path or p not in self.grants:
            raise ApiError("Choose where to save or open the file with the file picker first.", code="no_grant")
        return path

    # ---------------------------------------------------------------- files (safe from any thread)
    def has(self, p):
        ok = self._exists.get(p)
        if ok is None:
            ok = self._exists[p] = os.path.exists(p)
        return ok

    def gdir(self):
        return game_dir(self.cfg["data_dir"], self.cfg.get("game", "pokemon"))

    def image_file(self, cid, set_id, quality=None):
        if not self.unlocked:
            return ""
        pref = quality or self.cfg.get("image_quality", "low")
        for q in (("high", "low") if pref == "high" else ("low", "high")):
            p = image_file(self.gdir(), q, cid, set_id)
            if self.has(p):
                return p
        return ""

    def fetch_image(self, cid, set_id, quality=None):
        """A picture that isn't on this PC yet: get it once from its web address, keep it as a small cache, and return the file (or "" if it can't be had)."""
        if not self.unlocked or runtime.IN_BROWSER or self.cfg.get("on_demand_images") is False:
            return ""
        q = quality or self.cfg.get("image_quality", "low")
        miss = self.__dict__.setdefault("_img_miss", {})
        key = (self.cfg.get("game", "pokemon"), cid, q)
        if miss.get(key, 0) > time.time():
            return ""
        base = ""
        try:                                   # this runs on a web-server thread: use a short connection of its own, not the vault's
            import sqlite3
            c = sqlite3.connect("file:" + os.path.join(self.gdir(), "cards.db").replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
            try:
                r = c.execute("SELECT image_base FROM cards WHERE id=?", (cid,)).fetchone()
            finally:
                c.close()
            base = (r[0] or "") if r else ""
        except Exception:  # noqa: BLE001
            base = ""
        pokemon = self.cfg.get("game", "pokemon").startswith("pokemon")
        url = (picture_url(base, q) if pokemon else base.replace("_200w", "_400w") if q == "high" else base) if base else ""
        data = b""
        if url:
            try:
                import requests
                r = requests.get(url, timeout=12, headers={"User-Agent": "CollectEmAll/3 (card picture)"})
                data = r.content if r.status_code == 200 and len(r.content) > 500 else b""
            except Exception:  # noqa: BLE001
                data = b""
        if not data:
            miss[key] = time.time() + 300           # don't hammer a picture that isn't there
            return ""
        p = image_file(self.gdir(), q, cid, set_id)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p + ".part", "wb") as f:
            f.write(data)
        os.replace(p + ".part", p)
        self._exists[p] = True
        from . import storage
        storage.after_fetch(self)
        return p

    # ---- pictures shown from their web address (the browser build keeps nothing on disk)
    def remote_image(self, cid, quality="low"):
        v = self.vault
        if v is None:
            return ""
        bases = getattr(v, "_img_bases", None)
        if bases is None:
            bases = v._img_bases = {r[0]: r[1] for r in v.conn.execute("SELECT id, image_base FROM cards WHERE image_base IS NOT NULL AND image_base!=''")}
        base = bases.get(cid)
        if not base:
            return ""
        return picture_url(base, quality) if self.game.pokemon else base

    def _set_urls(self):
        v = self.vault
        if getattr(v, "_set_urls_cache", None) is None:
            try:
                import json
                v._set_urls_cache = json.loads(v.meta("setimg_urls") or "{}")
            except ValueError:
                v._set_urls_cache = {}
        return v._set_urls_cache

    def logo_url(self, sid, row=None):
        from .. import setartmap, setimages
        try:
            logo = row["logo"] if row is not None else None
            name = row["name"] if row is not None else ""
        except (KeyError, IndexError):
            logo, name = None, ""
        if runtime.REMOTE_IMAGES:
            return (logo + ".webp") if logo else (self._set_urls().get(sid, "") or setartmap.url_for(sid, name))
        p = self.logo_file(sid)
        if p and p != setimages.generated_path(self.gdir(), sid):          # a real picture is stored here
            return f"/logo?s={urllib.parse.quote(str(sid), safe='')}"
        if logo and str(logo).startswith("https://"):                        # a finished logo address stored in the card list (set logos for the TCGplayer games)
            return logo + ".webp"
        return self._set_urls().get(sid, "") or setartmap.url_for(sid, name)        # else show it from the web; the screens draw a banner if there is none

    def symbol_url(self, sid):
        if runtime.REMOTE_IMAGES:
            return ""
        return f"/symbol?s={urllib.parse.quote(str(sid), safe='')}" if self.symbol_file(sid) else ""

    def logo_file(self, set_id):
        if not self.unlocked:
            return ""
        from .. import setimages
        for p in (logo_file(self.gdir(), set_id), bulbapedia.art_path(self.gdir(), set_id, "logo"), setimages.generated_path(self.gdir(), set_id)):
            if self.has(p):
                return p
        return ""

    def symbol_file(self, set_id):
        if not self.unlocked:
            return ""
        p = bulbapedia.art_path(self.gdir(), set_id, "symbol")
        return p if self.has(p) else ""
