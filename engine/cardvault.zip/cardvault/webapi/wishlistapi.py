"""The wishlist page: your own labels (their order is the priority), what each label and the whole list cost to finish, and sharing - with friends, or as a link anyone can open (view only, switched
off by one press).  The counting is cardvault/wishlist.py (prices from cardvault/completion.py, the same as "Cost to complete"); the link page is wishpage.py; the link itself is the account-server
page of sharepages.py (random address, refreshed in place, revoked at once)."""
from .. import wishlabels, wishlist
from .registry import ApiError, api
from . import sharepages, wishpage

KIND = "wishview"                                   # the page kind in sharepages' list of published pages (one link per game)


def _friends_see(svc):
    from .friends import _privacy
    return bool(_privacy(svc).get("wishlist"))


def _tell_friends(svc):
    """A label / its order changed: friends who can see my wishlist get the new order with my next profile refresh."""
    svc._prof_at = 0
    svc._best_at = 0


@api("wishlist.get")
def get(svc, group="label", sort="priority"):
    """The whole page: {labels: [{id, name, rank, count, owned, todo, cost, unpriced, asked}] (priority order), free: the same numbers for cards without a label, total: the same for everything,
    groups: [{key, name, ...numbers, items}]} - group = "label" | "set", sort = "priority" | "high" | "low" (price)."""
    return wishlist.view(svc, group, sort)


@api("wishlist.labels.set", mutates=True)
def labels_set(svc, labels):
    """Save the labels: a list of {id?, name} in priority order (top = most wanted).  Leave a label out and it is deleted (its cards keep no label)."""
    if not isinstance(labels, list):
        raise ApiError("Send the labels as a list.")
    from .undoext import undoable
    gone = [x["name"] for x in wishlabels.load(svc)["labels"] if x["id"] not in {str((y or {}).get("id")) for y in labels if isinstance(y, dict)}]
    label = f"Deleted the wishlist label '{gone[0]}'" if len(gone) == 1 else f"Deleted {len(gone)} wishlist labels" if gone else "Changed the wishlist labels"
    res = undoable(svc, label, lambda: wishlabels.set_labels(svc, labels), keys=[wishlabels.KEY])
    _tell_friends(svc)
    return {**res, "labels": wishlabels.load(svc)["labels"], "deleted": len(gone), "undo": res["undo"] if gone else None}      # (renaming / re-ordering is logged but shows no Undo toast)


@api("wishlist.assign", mutates=True)
def assign(svc, ids, label=""):
    """Put a label on these wishlist cards (label "" = no label)."""
    ids = [i for i in (ids or []) if isinstance(i, str)]
    try:
        n = wishlabels.assign(svc, svc.vault.game, ids, label or "")
    except LookupError:
        raise ApiError("That label is gone - pick another.")
    _tell_friends(svc)
    return {"changed": n}


@api("wishlist.share.status", quiet=True)
def share_status(svc):
    """What is shared: whether friends can see the wishlist, and the public link (None when there is none)."""
    cur = sharepages._pages(svc).get(sharepages._key(svc, KIND))
    return {"friends": _friends_see(svc), "link": cur, "signedIn": bool(svc.pget("cloud_token")), "count": len(svc.vault.wishlist_ids())}


@api("wishlist.link.publish")
def link_publish(svc, price=True, title="", note="", lock=None):
    """Make the view-only link (or refresh it: the same address) - the wishlist as it is now, grouped by label in priority order.  Prices only if `price`; never notes or what you paid."""
    view = wishlist.view(svc, "label", "priority")
    if not view["total"]["count"]:
        raise ApiError("Your wishlist is empty - add some cards to it first (the heart on a card).")
    if not view["total"]["todo"]:
        raise ApiError("Everything on your wishlist is already in your collection.")
    owner = (svc.pget("cloud_username") or "") if svc.pget("cloud_token") else ""
    title = (title or "").strip()[:80] or "My wishlist"
    page = wishpage.render(view, title, owner, note, bool(price))
    got = sharepages._publish(svc, KIND, title, page, {"price": bool(price), "title": title, "note": (note or "")[:300]}, lock)
    return {"link": got, "cards": view["total"]["todo"]}


@api("wishlist.link.refresh")
def link_refresh(svc):
    cur = sharepages._pages(svc).get(sharepages._key(svc, KIND))
    if not cur:
        raise ApiError("There is no wishlist link yet.")
    o = cur.get("opts") or {}
    return link_publish(svc, o.get("price", True), o.get("title") or "", o.get("note") or "")


@api("wishlist.link.revoke")
def link_revoke(svc):
    """Turn the link off: the address stops working at once."""
    return {"link": sharepages._revoke(svc, KIND)["page"]}
