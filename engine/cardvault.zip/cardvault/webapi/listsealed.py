"""Sealed products on a checklist: a goal like 'every Booster box of the Scarlet & Violet era' or 'one Elite trainer box per set', alone or together with cards.

The checklist only LOOKS at what you own: the products you hold live in your portfolios (Sealed products), a checklist never adds value of its own.  Ticking a product
adds one to the portfolio you are adding to; a product you already own anywhere counts once."""
import json

from .. import checklists, completion, sealedclass, sealedsets
from ..db import new_uuid, now_iso, today
from ..tcgcsv import norm_name
from . import sealedcat
from .listsource import own_source
from .registry import api
from .service import ApiError


def _rules(svc, cl_id):
    cl = svc.vault.checklist(cl_id)
    if not cl or cl["deleted"]:
        raise ApiError("checklist not found")
    return (checklists._load_rules(cl) or {}).get("sealed") or {}


def _members(svc, sr):
    rows = sealedcat._all(svc) or []
    kinds = [k for k in (sealedclass.kind_name(k) for k in (sr.get("kinds") or [])) if k in sealedclass.KINDS]
    series = set(sr.get("series") or [])
    words = norm_name(sr.get("q") or "").split()
    set_ids = {str(i) for i in (sr.get("setIds") or [])}
    out = []
    for r in rows:
        if set_ids:                                                     # "All sealed from <set>": every product of the set, read live (a product added later shows up)
            if str(r["setId"]) not in set_ids or r["kind"] in sealedclass_loose():
                continue
            if kinds and r["kind"] not in kinds and not any(a in kinds for a in r.get("also", ())):
                continue
            out.append(r)
            continue
        if kinds:
            if r["kind"] not in kinds and not any(a in kinds for a in r.get("also", ())):
                continue
        elif r["kind"] in sealedcat.HIDDEN_BY_DEFAULT:
            continue
        if series and r["serie"] not in series:
            continue
        if words and not all(w in ((r["norm"] or "") + " " + sealedcat.norm_name(r.get("set") or "")) for w in words):          # the set's name counts too
            continue
        out.append(r)
    return out


def sealedclass_loose():
    return sealedcat.LOOSE_KINDS


def _inside(svc, norms):
    """{normalised name: [lines]} - "What's inside" for the products asked for (only what a source states)."""
    from .. import sealedcontents
    out = {}
    try:
        for n, c in svc.vault.conn.execute("SELECT norm, contents FROM sealed_products WHERE contents IS NOT NULL AND contents != ''"):
            if n in norms and n not in out:
                out[n] = sealedcontents.unpack(c)
    except Exception:  # noqa: BLE001 - a list built before contents existed
        pass
    for n in norms:                                                     # the list read from the product's page (data/sealed_contents.json)
        st = sealedcontents.stated(n)
        if st and n not in out:
            out[n] = st["lines"]
    return out


def _source(norm):
    """The page a product's "What's inside" list was read from, as tile fields (none when the list came from the card list itself)."""
    from .. import sealedcontents
    st = sealedcontents.stated(norm or "")
    return {"insideSource": st.get("source") or "", "insideUrl": st.get("url") or ""} if st and st.get("url") else {}


def _owned(svc, anywhere=False):
    """{normalised product name: copies} of the sealed products held - in the portfolios being looked at, or in all of them."""
    v = svc.vault
    scope = [] if anywhere else list(v.scope or [])
    out = {}
    for r in v.conn.execute("SELECT name, qty, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)):
        if scope and r["pf"] not in scope:
            continue
        k = norm_name(r["name"])
        out[k] = out.get(k, 0) + (r["qty"] or 0)
    return out


@api("lists.sealed", quiet=True)
@own_source
def lists_sealed(svc, id, view="all", q=""):
    sr = _rules(svc, id)
    if not sr:
        return {"enabled": False, "tiles": [], "owned": 0, "total": 0}
    have = _owned(svc)
    q = (q or "").strip().lower()
    tiles, owned = [], 0
    members = _members(svc, sr)
    live = bool(sr.get("setIds"))
    inside = _inside(svc, {r["norm"] for r in members}) if live else {}
    cost = {"cost": 0.0, "unpriced": 0}
    for r in members:
        n = have.get(r["norm"] or "", 0)
        owned += 1 if n else 0
        if not n:
            if completion.true_price(r["price"], r["priceKind"]):
                cost["cost"] += r["price"]
            else:
                cost["unpriced"] += 1
        if view == "owned" and not n or view == "missing" and n:
            continue
        if q and q not in (r["name"] or "").lower():
            continue
        tiles.append({"key": "s:" + str(r["id"]), "id": r["id"], "title": r["name"], "sub": f"{r['kind']} · {r['set']}", "img": r["img"], "price": r["price"], "priceKind": r["priceKind"], "qty": n, "owned": n > 0, **({"inside": inside.get(r["norm"] or "", []), **_source(r["norm"])} if live else {})})
    total = len(members)
    out = {"enabled": True, "tiles": tiles[:600], "shown": len(tiles), "owned": owned, "total": total, "pct": round(100 * owned / total, 1) if total else 0.0}
    if live:                                                              # a live set checklist: what is left costs this much (true prices only - never an eBay ask) and how many have none yet
        out.update(live=True, costToFinish=round(cost["cost"], 2), unpriced=cost["unpriced"], priceCounts=completion.count_missing([(r["price"], r["priceKind"]) for r in members]))
    return out


@api("lists.sealedOwn", mutates=True)
def lists_sealed_own(svc, id, product, owned=True):
    """Tick (add one) or untick (remove) a sealed product from a checklist.  A product you already hold in a portfolio that is not being looked at is not added twice.  One Undo puts it back."""
    from .extras import _undoable
    return _undoable(svc, f"{'Marked' if owned else 'Cleared'} a sealed product on a checklist", lambda: _sealed_own(svc, id, product, owned))


def _sealed_own(svc, id, product, owned):
    v = svc.vault
    sr = _rules(svc, id)
    row = next((r for r in _members(svc, sr) if str(r["id"]) == str(product)), None)
    if row is None:
        raise ApiError("That product is not on this checklist.")
    key = row["norm"] or norm_name(row["name"])
    if owned:
        anywhere = _owned(svc, anywhere=True).get(key, 0)
        here = _owned(svc).get(key, 0)
        if anywhere and not here:
            raise ApiError("You already own this product in another portfolio, so it counts there. Switch the Viewing menu to see it.")
        if here:
            return {"ok": True, "already": True}
        v.check_accepts(v.target_pf, "sealed")
        v.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                       (new_uuid(), v.user_id, v.game, "", row["name"], 1, None, today(), "", "", v.target_pf, now_iso()))
    else:
        scope = list(v.scope or [])
        for r in v.conn.execute("SELECT uuid, name, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0", (v.user_id, v.game)).fetchall():
            if norm_name(r["name"]) == key and (not scope or r["pf"] in scope):
                v.conn.execute("UPDATE u.sealed SET deleted=1, updated_at=? WHERE uuid=?", (now_iso(), r["uuid"]))
    v._commit()
    try:
        v.record_sealed_history()
    except Exception:  # noqa: BLE001
        pass
    return {"ok": True}


@api("lists.sealedSetInfo", quiet=True)
def lists_sealed_set_info(svc, set_id):
    """For the set view's button: does this card set have sealed products?  -> {has, n, name, list} (list = the id of the live checklist already made for it, or None)."""
    v = svc.vault
    row = v.conn.execute("SELECT name FROM sets WHERE id=?", (set_id,)).fetchone()
    ids = sealedsets.ids_for_card_set(v.conn, set_id, row["name"] if row else "")
    e = sealedsets.entry_for_ids(v.conn, ids) if ids else None
    return {"has": bool(e), "n": e["n"] if e else 0, "name": e["name"] if e else "", "list": _existing(v, ids)}


def _existing(v, ids):
    ids = set(ids)
    for cl in v.checklists():
        if cl["deleted"]:
            continue
        sr = (checklists._load_rules(cl) or {}).get("sealed") or {}
        if sr.get("all") and ids & {str(i) for i in sr.get("setIds") or []}:
            return cl["id"]
    return None


@api("lists.sealedSet", mutates=True)
def lists_sealed_set(svc, set_id):
    """'All sealed from <set>' for a card set: opens the live checklist already made for it, or makes one.  Returns {id, created}."""
    v = svc.vault
    row = v.conn.execute("SELECT name FROM sets WHERE id=?", (set_id,)).fetchone()
    ids = sealedsets.ids_for_card_set(v.conn, set_id, row["name"] if row else "")
    e = sealedsets.entry_for_ids(v.conn, ids) if ids else None
    if not e:
        raise ApiError("This set has no sealed products.")
    have = _existing(v, ids)
    if have:
        return {"ok": True, "id": have, "created": False}
    p = sealedsets.preset_for(e)
    rules = {**p["rules"], "sources": {"mode": "all", "ids": []}}
    return {"ok": True, "id": v.create_checklist(p["name"], p["mode"], False, rules), "created": True}
