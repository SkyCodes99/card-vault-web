"""Sealed products on a checklist: a goal like 'every Booster box of the Scarlet & Violet era' or 'one Elite trainer box per set', alone or together with cards.

The checklist only LOOKS at what you own: the products you hold live in your portfolios (Sealed products), a checklist never adds value of its own.  Ticking a product
adds one to the portfolio you are adding to; a product you already own anywhere counts once."""
import json

from .. import checklists, sealedclass
from ..db import new_uuid, now_iso, today
from ..tcgcsv import norm_name
from . import sealedcat
from .registry import api
from .service import ApiError


def _rules(svc, cl_id):
    cl = svc.vault.checklist(cl_id)
    if not cl or cl["deleted"]:
        raise ApiError("checklist not found")
    return (checklists._load_rules(cl) or {}).get("sealed") or {}


def _members(svc, sr):
    rows = sealedcat._all(svc) or []
    kinds = [k for k in (sr.get("kinds") or []) if k in sealedclass.KINDS]
    series = set(sr.get("series") or [])
    words = norm_name(sr.get("q") or "").split()
    out = []
    for r in rows:
        if kinds:
            if r["kind"] not in kinds:
                continue
        elif r["kind"] in sealedcat.HIDDEN_BY_DEFAULT:
            continue
        if series and r["serie"] not in series:
            continue
        if words and not all(w in (r["norm"] or "") for w in words):
            continue
        out.append(r)
    return out


def _owned(svc, anywhere=False):
    """{normalised product name: copies} of the sealed products held - in the portfolios being looked at, or in all of them."""
    v = svc.vault
    scope = [] if anywhere else list(v.scope or [])
    out = {}
    for r in v.conn.execute("SELECT name, qty, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)):
        if scope and r["pf"] not in scope:
            continue
        k = norm_name(r["name"])
        out[k] = out.get(k, 0) + (r["qty"] or 0)
    return out


@api("lists.sealed", quiet=True)
def lists_sealed(svc, id, view="all", q=""):
    sr = _rules(svc, id)
    if not sr:
        return {"enabled": False, "tiles": [], "owned": 0, "total": 0}
    have = _owned(svc)
    q = (q or "").strip().lower()
    tiles, owned = [], 0
    for r in _members(svc, sr):
        n = have.get(r["norm"] or "", 0)
        owned += 1 if n else 0
        if view == "owned" and not n or view == "missing" and n:
            continue
        if q and q not in (r["name"] or "").lower():
            continue
        tiles.append({"key": "s:" + str(r["id"]), "id": r["id"], "title": r["name"], "sub": f"{r['kind']} · {r['set']}", "img": r["img"], "price": r["price"], "priceKind": r["priceKind"], "qty": n, "owned": n > 0})
    total = len(_members(svc, sr))
    return {"enabled": True, "tiles": tiles[:600], "shown": len(tiles), "owned": owned, "total": total, "pct": round(100 * owned / total, 1) if total else 0.0}


@api("lists.sealedOwn", mutates=True)
def lists_sealed_own(svc, id, product, owned=True):
    """Tick (add one) or untick (remove) a sealed product from a checklist.  A product you already hold in a portfolio that is not being looked at is not added twice."""
    v = svc.vault
    sr = _rules(svc, id)
    row = next((r for r in _members(svc, sr) if str(r["id"]) == str(product)), None)
    if row is None:
        raise ApiError("That product is not on this checklist.")
    key = row["norm"] or norm_name(row["name"])
    if owned:
        anywhere = _owned(svc, anywhere=True).get(key, 0)
        here = _owned(svc).get(key, 0)
        if anywhere and not here:
            raise ApiError("You already own this product in another portfolio, so it counts there. Switch the Portfolio menu at the top to see it.")
        if here:
            return {"ok": True, "already": True}
        v.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                       (new_uuid(), v.user_id, v.game, "", row["name"], 1, None, today(), "", "", v.target_pf, now_iso()))
    else:
        scope = list(v.scope or [])
        for r in v.conn.execute("SELECT uuid, name, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0", (v.user_id, v.game)).fetchall():
            if norm_name(r["name"]) == key and (not scope or r["pf"] in scope):
                v.conn.execute("UPDATE u.sealed SET deleted=1, updated_at=? WHERE uuid=?", (now_iso(), r["uuid"]))
    v._commit()
    try:
        v.record_sealed_history()
    except Exception:  # noqa: BLE001
        pass
    return {"ok": True}
