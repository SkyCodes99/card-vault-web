"""Updates, cross-device sync, backups, CSV import / export and importing from other trackers."""
import datetime
import time
import os
import tempfile
import sys
import threading

from .. import runtime, importers, updater
from ..cloud import backend as cloud_backend
from ..cloud import e2e
from ..cloud import engine, syncmarks
from ..db import game_dir
from ..version import VERSION
from .registry import api
from .service import ApiError

STATE = {"update": None, "update_status": "", "sync_status": "Cloud saving is off", "syncing": False}


# ------------------------------------------------------------------------------------------------ tokens
def sync_key(svc, create=False):
    """This account's sync key (bytes), made the first time sync is switched on."""
    raw = svc.pget("sync_key")
    if raw:
        return e2e.from_code(raw)
    if not create:
        return None
    k = e2e.new_key()
    svc.pset("sync_key", e2e.to_code(k))
    return k


_GH = {"t": "", "busy": False, "done": False}        # the GitHub CLI sign-in: looked up ONCE, in the background (it starts a program that can take seconds)


def _gh_lookup():
    try:
        _GH["t"] = updater.gh_token()
    finally:
        _GH["busy"], _GH["done"] = False, True


def _gh_cached(svc):
    """The GitHub CLI sign-in, never waited for: only owner/dev builds (running from source, or the owner's account) ask, once, on a side thread."""
    if not _GH["done"] and not _GH["busy"] and (not getattr(sys, "frozen", False) or svc.pget("cloud_admin")):
        _GH["busy"] = True
        threading.Thread(target=_gh_lookup, daemon=True, name="gh-token").start()
    return _GH["t"]


def token(svc):
    """(token, where it came from): the account's saved token, else the GitHub CLI sign-in."""
    t = svc.pget("github_token")
    if t:
        return t, "saved token (encrypted)"
    if runtime.IN_BROWSER:
        return "", ""                                  # no GitHub command-line sign-in exists in a browser (asking used to cost a second at every start)
    t = _gh_cached(svc)
    return (t, "GitHub CLI sign-in") if t else ("", "")


def _target_name(svc):
    """Where changes are saved right now: 'account' (the cloud account), 'github' (an older private-repository setup) or 'none' (only on this device)."""
    if svc.pget("cloud_token") and (svc.pget("cloud_sync_mode") or "account") == "account":
        return "account"
    if svc.pget("github_token") and svc.pget("sync_key"):          # a GitHub sync this profile really set up (never the computer's own GitHub sign-in)
        return "github"
    return "none"


def _waiting_changes(svc):
    """How many changes are still waiting to be sent: journal entries newer than the last successful sync (0 when nothing is open or nothing is waiting)."""
    import datetime
    upto = getattr(svc, "_synced_upto", 0.0)
    if svc.vault is None or svc.last_change <= upto:
        return 0
    since = datetime.datetime.fromtimestamp(upto, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ") if upto else ""
    try:
        return min(9999, max(1, svc.vault.conn.execute("SELECT COUNT(*) FROM u.journal WHERE user_id=? AND ts>?", (svc.vault.user_id, since)).fetchone()[0]))
    except Exception:  # noqa: BLE001 - a status line must never fail
        return 1


def _review_count(svc):
    """Records changed on two devices at once, waiting on the sync review list (cloud/conflicts.py)."""
    from ..cloud import conflicts
    return conflicts.count(svc.vault.conn, svc.vault.user_id) if svc.vault is not None else 0


def _failed_note():
    """A failed update's plain note (the update window left it for the reopened app), read once per start and kept until dismissed."""
    if "update_failed" not in STATE:
        STATE["update_failed"] = "" if runtime.IN_BROWSER else updater.take_failed_note()
    return STATE["update_failed"]


@api("cloud.status")
def cloud_status(svc):
    cfg = svc.cfg
    tok, src = token(svc)
    info = STATE["update"]
    return {"version": VERSION, "updateRepo": cfg.get("update_repo") or updater.UPDATE_REPO, "dataRepo": svc.pget("sync_repo") or updater.DATA_REPO,
            "tokenSource": src or "not signed in", "autoUpdates": cfg.get("auto_updates", True), "syncEnabled": bool(svc.pget("sync_enabled", True)),
            "lastCheck": cfg.get("update_last_check") or "", "lastSync": svc.pget("sync_last") or "", "updateStatus": STATE["update_status"],
            "syncStatus": STATE["sync_status"], "syncing": STATE["syncing"], "account": bool(svc.pget("cloud_token")), "target": _target_name(svc),
            "pending": bool(svc.last_change > getattr(svc, "_synced_upto", 0.0)), "waiting": _waiting_changes(svc), "retrySec": max(0, int(getattr(svc, "_sync_backoff", 0) - __import__("time").time())), "failed": STATE["sync_status"].startswith(("Couldn't save", "Your session ended")), "error": STATE.get("sync_error", ""),
            "offline": "Couldn't connect" in STATE.get("sync_error", ""), "review": _review_count(svc),
            "signedIn": bool(svc.pget("cloud_token") and svc.pget("cloud_dek")), "username": svc.pget("cloud_username") or "", "canInstall": updater.can_self_update(),
            "update": {"latest": info["latest"], "notes": info["notes"], "rollback": bool(info.get("rollback"))} if info and info.get("update") else None,
            "updateFailed": _failed_note()}


@api("cloud.setToken", mutates=True)
def set_token(svc, token=""):
    svc.pset("github_token", token.strip() or None)
    return {"ok": True}


@api("cloud.setFlag", mutates=True)
def set_flag(svc, key, value):
    if key not in ("auto_updates", "sync_enabled"):
        raise ApiError("unknown setting")
    if key == "sync_enabled":
        svc.pset(key, bool(value))
    else:
        svc.cfg[key] = bool(value)
        svc.save()
    if key == "sync_enabled" and value:
        start_sync(svc, manual=True)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ updates
def newest_release(svc, repo=None, tok=None):
    """The newest published version for this app (never the next one in line: the feed and GitHub's 'latest' both name the newest), same shape as updater.check()."""
    from . import accountapi
    if tok is None:
        tok, _ = token(svc)
    repo = repo or svc.cfg.get("update_repo") or updater.UPDATE_REPO
    base = accountapi.server_url(svc)
    preview = bool(svc.pget("preview_channel")) and bool(svc.pget("cloud_admin"))          # the owner's account can ask for preview builds first
    return (updater.check_cloud(base, channel="preview") if (base and preview) else None) or (updater.check_cloud(base) if base else None) or updater.check(repo, tok)      # your own server first, GitHub as the fallback


def save_before_update(svc, emit, timeout=60.0):
    """'Saving before update…': let a running sync finish and send changes that have not gone to your account yet, then take a safety copy.
    Returns True when nothing was left unsent (False = it waited `timeout` seconds or there is nowhere to send to; the update goes ahead, the changes stay on this computer)."""
    emit("Saving before update…", 0, 0)
    pending = lambda: svc.last_change > getattr(svc, "_synced_upto", 0.0)
    end, started = time.time() + timeout, False
    while time.time() < end:
        if svc.jobs.running("sync"):
            time.sleep(0.3)
            continue
        if pending() and not started:
            started = True
            try:
                if start_sync(svc) is not None:
                    continue
            except Exception:  # noqa: BLE001 - saving to the account is a courtesy here, never a reason to refuse the update
                pass
        break
    try:                                                          # a safety copy - on the thread that owns the collection (using it from here failed with a SQLite thread error and silently stopped every update)
        svc.run(lambda s: s.vault.backup_now("exit", s.pget("backup_dir")), timeout=60)
    except Exception:  # noqa: BLE001
        pass
    return not pending()


def check_updates(svc, manual=False):
    if runtime.IN_BROWSER:                 # the browser build updates itself: the page notices a newer published version
        return None
    tok, _ = token(svc)
    repo = svc.cfg.get("update_repo") or updater.UPDATE_REPO

    def run(emit, cancel):
        emit("Checking for updates…", 0, 0)
        info = newest_release(svc, repo, tok)
        STATE["update"] = info
        svc.cfg["update_last_check"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        if info.get("error"):
            STATE["update_status"] = info["error"]
        elif info["update"]:
            STATE["update_status"] = (f"A problem was found in the newest version. Go back to {info['latest']}? (you have {VERSION})." if info.get("rollback") else f"Version {info['latest']} is available (you have {VERSION}).")
        else:
            STATE["update_status"] = f"You're up to date (version {VERSION})."
        svc.save()
        if info.get("update") and not info.get("error"):
            svc.bump("update", version=info["latest"], rollback=bool(info.get("rollback")), notes=(info.get("notes") or "").strip().splitlines()[0][:160] if info.get("notes") else "")
        return {"update": bool(info.get("update")), "latest": info.get("latest"), "error": info.get("error", ""), "status": STATE["update_status"]}
    return svc.jobs.start("update-check", "Checking for updates", run)


@api("update.channel", mutates=True)
def update_channel(svc, preview=None):
    """The owner's account only: get preview builds first (before everybody).  Reads or sets the choice."""
    if not svc.pget("cloud_admin"):
        return {"available": False, "preview": False}
    if preview is not None:
        svc.pset("preview_channel", True if preview else None)
    return {"available": True, "preview": bool(svc.pget("preview_channel"))}


@api("update.check")
def update_check(svc, manual=True):
    try:
        j = check_updates(svc, manual)
        return {"job": j.id if j else None}
    except ApiError:
        return {"job": None}


@api("update.install")
def update_install(svc):
    info = STATE["update"]
    if not info or not info.get("update"):
        raise ApiError("There is no update to install.")
    if not updater.can_self_update():
        import webbrowser
        webbrowser.open(info.get("page") or "https://github.com/" + (svc.cfg.get("update_repo") or updater.UPDATE_REPO) + "/releases/latest")
        return {"opened": True}
    tok, _ = token(svc)

    def run(emit, cancel):
        # 1. everything saved first (the screens already emptied their outbox before asking)
        save_before_update(svc, emit)
        # 2. straight to the NEWEST version, even if a newer one came out after the bar was shown (never one version at a time)
        emit("Saving before update…", 1, 1)
        try:
            fresh = newest_release(svc, tok=tok)
            if fresh and fresh.get("update") and not fresh.get("error"):
                STATE["update"] = fresh
        except Exception:  # noqa: BLE001 - the version already found is still fine
            pass
        cur = STATE["update"]
        target = updater.app_dir()
        if updater.updater_exe(target):
            # 3. the new way: the app closes and a small window downloads (with a progress bar), swaps the files and opens the new version
            emit("Closing to update…", 1, 1)
            updater.launch_update_window(cur, target, os.getpid(), token="" if cur.get("source") in ("cloud", "preview") else tok)
            from .. import skyrelaunch
            skyrelaunch.exit_watchdog(20)          # the window waits for this program to end: make sure it really does
            if svc.quit_app:
                threading.Timer(0.8, svc.quit_app).start()
            return {"restarting": True, "window": True, "version": cur["latest"]}
        # (an install without the update window: download here, then the script swaps the files)
        dest = os.path.join(tempfile.gettempdir(), cur["asset"]["name"])
        updater.download(cur["asset"], None if cur.get("source") in ("cloud", "preview") else tok, dest, lambda a, b: emit("Downloading the update…", a, b))
        emit("Unpacking the update…", 0, 1)
        staging = updater.stage(dest, lambda a, b: emit("Unpacking the update…", a, b))
        emit("Restarting…", 1, 1)
        bat = updater.write_installer(staging, target, os.getpid())
        updater.launch_installer(bat)
        if svc.quit_app:
            threading.Timer(1.0, svc.quit_app).start()
        return {"restarting": True, "version": cur["latest"]}
    return {"job": svc.jobs.start("update-install", f"Installing {info['latest']}", run).id}


@api("update.dismissFailed")
def update_dismiss_failed(svc):
    STATE["update_failed"] = ""
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ sync
def games_to_sync(svc):
    v = svc.vault
    found = {v.game}
    for (g,) in v.conn.execute("SELECT DISTINCT game FROM u.lots WHERE user_id=? UNION SELECT DISTINCT game FROM u.checklists WHERE user_id=? "
                               "UNION SELECT DISTINCT game FROM u.wishlist WHERE user_id=?", (v.user_id,) * 3):
        if g and os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g), "cards.db")):
            found.add(g)
    return sorted(found, key=lambda g: (g != v.game, g))


def sync_target(svc, force_github=False):
    """Where this account syncs: its cloud account when signed in (end-to-end encrypted by the account's own data key), else the GitHub repository.
    -> (backend factory, e2e key, can publish the card catalogue)"""
    from . import accountapi
    from ..cloud import skycloud
    a = None if force_github else accountapi.account(svc)
    if a is not None and (svc.pget("cloud_sync_mode") or "account") == "account":
        return (lambda: skycloud.SkyCloudBackend(a)), None, False
    tok, _ = token(svc)
    if not tok:
        return None
    cfg = dict(svc.cfg)
    cfg["sync_repo"] = svc.pget("sync_repo") or updater.DATA_REPO
    return (lambda: cloud_backend.make_backend(cfg, tok)), sync_key(svc, create=True), True


def _account_state(be):
    """(fingerprint, versions) of the account before a sync, or None for a backend that cannot say.  (A step of the sync: in the browser the question is handed out - see steps.py.)"""
    if not hasattr(be, "seen"):
        return None
    try:
        return (yield from be.state_steps()) if hasattr(be, "state_steps") else be.state()
    except Exception:  # noqa: BLE001
        return None


def _fp_to_record(be, before):
    """The fingerprint to remember as 'seen' once a sync has finished.  Normally what the account holds now.  But if another device saved a document WHILE this sync was running and this sync neither read
    nor wrote that version, the change is not here yet: remember the older fingerprint, so the next look sees a difference and fetches it (it used to be marked as seen and never arrived).
    A sync that saved nothing left the account as it found it, so the fingerprint from the start is the right one - no second look needed."""
    if before and not getattr(be, "wrote", True):
        return before[0] or None
    after = (yield from _account_state(be)) if before else None
    if not after:
        return None
    foreign = any(ver != before[1].get(name) and ver != be.seen.get(name) for name, ver in after[1].items())
    return before[0] if foreign else after[0]


def start_sync(svc, manual=False, publish=True, force_github=False):
    if not svc.pget("sync_enabled", True):
        if manual:
            raise ApiError("Turn on 'Sync across my devices' in Settings first.")
        return None
    if svc.jobs.running("sync"):
        return None
    target = sync_target(svc, force_github)
    if not target:
        STATE["sync_status"] = "Sign in to an account (Settings) to save your collection to the cloud."
        return None
    make, key, can_publish = target
    publish = publish and can_publish
    upath = svc.session.db_path if svc.session is not None else None
    data_dir, device, game_list = svc.cfg["data_dir"], engine.device_id(svc.cfg), games_to_sync(svc)

    started = time.time()

    def run(emit, cancel):
        STATE["syncing"] = True
        emit("Syncing…", 0, 0)
        be = make()
        before = yield from _account_state(be)
        yield                                                                                # (in the browser each piece runs at its own moment - see Jobs.step)
        svc._fp_after = None
        marks = syncmarks.for_account(svc.cfg, be.acct) if before else None                  # (a backend that cannot say which version a document is at has no marks: every game is synced)
        versions = before[1] if before else {}
        verify = set() if getattr(svc, "_sync_verified", False) else {game_list[0]}         # the first sync after the app starts looks at the open game for real, whatever the marks say
        res = []
        for g in game_list:
            res.append((yield from engine.sync_changed_steps(data_dir, g, be, device, marks, versions, force=manual or g in verify, publish_catalog=publish, key=key, user_path=upath)))
        svc._sync_verified = True
        if hasattr(be, "acct"):                                                              # checklist races: my progress row goes out with the same batched sync (races.py)
            try:
                from . import races
                yield from races.publish_steps(svc, be.acct)
            except Exception:  # noqa: BLE001 - a race is never allowed to fail the main sync
                pass
        # copy photos travel too - but only when something could have changed (a photo added or removed here, something new on the account, or the first sync of this
        # session): the extra round trip used to happen on every single sync
        pulled_now = sum(r.get("pulled", 0) for r in res)
        fp_moved = getattr(svc, "_fp_seen", None) not in (None, svc.cfg.get("_cloud_fp"))
        if key is None and hasattr(be, "list_docs") and (manual or getattr(svc, "_photos_changed", True) or pulled_now or fp_moved):
            try:
                from .. import photolimit
                res[0]["photos"] = engine.sync_photos(data_dir, game_list[0], be, upath, limit=photolimit.limit_for(svc))
                svc._photos_changed = False
                if res[0]["photos"].get("down") and svc.vault is not None:          # (pictures of your own items that came down: put where the card pictures are)
                    from .. import customitems
                    customitems.write_pictures(svc.vault)
                    svc._exists.clear()
            except Exception as e:  # noqa: BLE001 - photos are never allowed to fail the main sync
                res[0]["photos_error"] = str(e)
            yield
        if publish:
            engine.publish_other_catalogs(data_dir, be, skip=game_list, key=key, user_path=upath)
        svc._fp_after = yield from _fp_to_record(be, before)
        if svc._fp_after is None and hasattr(be, "acct"):
            try:                                                                       # (asked here, as a step of the sync - not afterwards on the engine's own thread, where it held up clicks)
                svc._fp_after = (yield from be.acct.call_steps("GET", "/v1/docs", patient=True)).get("fp") or None
            except Exception:  # noqa: BLE001
                pass
        return res

    def done(job):
        STATE["syncing"] = False
        svc._sync_cost = job.busy                               # how long a sync keeps the engine busy here (the scheduler waits longer before the next one when it is slow)
        if job.state == "done":
            svc._synced_upto = started                 # everything changed before the sync began is now saved
            svc._unsent_since = svc.last_change if svc.last_change > started else 0.0
            STATE["sync_error"] = ""
            if getattr(svc, "_fp_after", None):
                svc.cfg["_cloud_fp"] = svc._fp_after          # what the account holds NOW: only something newer than this is a change from another device (looked up by the sync itself: no question to the server here,
                                                              # on the engine's own thread, where it held up clicks; when it could not be had, the next look simply finds a difference and syncs once more)
            pulled = sum(r["pulled"] for r in job.result)
            now = datetime.datetime.now().strftime("%H:%M")
            svc.pset("sync_last", datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
            STATE["sync_status"] = f"Saved at {now}" + (f" · {pulled} change{'s' if pulled != 1 else ''} from your other devices" if pulled else "")
            try:
                from .settings import prefs_adopt
                prefs_adopt(svc)                      # a choice made on another device (currency, budget, theme...) arrives with the sync
            except Exception:  # noqa: BLE001
                pass
            if any(not r.get("skipped") for r in job.result):
                svc.save()                                  # (what each game's sync left behind is remembered, so the next one can skip it)
            if pulled:
                svc._me_cache = None                        # a username changed on another device shows here at the next look, not minutes later
                if any(r.get("taxonomy") for r in job.result):
                    svc.vault.invalidate_index()            # a correction or a category of yours arrived: which groups cards belong to has to be worked out again
                else:
                    svc.vault._cl_rev += 1                  # copies, wishlists, lists... changed: the checklist counts are counted again; the card index itself is untouched
                svc.reload_state()
                try:
                    svc.session.persist() if svc.session is not None else None          # what arrived from your other devices is kept on this one right away
                except Exception:  # noqa: BLE001
                    pass
                svc.bump("synced", pulled=pulled)
        else:
            svc._sync_backoff = time.time() + 10                # a failed attempt: wait a little before the next one
            STATE["sync_error"] = str(job.error or "")[:160]     # the real reason, shown in Settings > Cloud saving so it can be fixed (not just "couldn't save")
            STATE["sync_status"] = "Your session ended - sign in again to keep saving." if "signed out" in str(job.error or "") else "Couldn't save just now - we'll keep trying."
    return svc.jobs.start("sync", "Syncing", run, on_done=done)


@api("sync.check", quiet=True)
def sync_check(svc, fp=""):
    """Called when the app comes back into view, and by the website's page-side poll (which hands in the account's current fingerprint `fp`, so no round trip is needed here):
    if another device changed something, fetch it now."""
    from . import accountapi
    if svc.session is None or not svc.pget("cloud_token"):
        return {"started": False}
    if fp and fp == svc.cfg.get("_cloud_fp"):
        return {"started": False, "upToDate": True}
    if svc.jobs.running("sync"):
        return {"started": False}
    svc._sync_backoff = 0
    if fp:
        svc._fp_seen = fp
        return {"started": cloudapi_start(svc) is not None}
    w = accountapi.watch(svc)
    if w["changed"]:
        svc._fp_seen = w.get("fp")
        return {"started": cloudapi_start(svc) is not None}
    return {"started": False, "upToDate": True}


def cloudapi_start(svc):
    return start_sync(svc, False, publish=False)


@api("sync.now")
def sync_now(svc, manual=True):
    j = start_sync(svc, manual)
    return {"job": j.id if j else None}


def flush_sync(svc):
    """Last chance on exit: push unsynced changes (quick, errors ignored)."""
    if not svc.pget("sync_enabled", True):
        return
    target = sync_target(svc)
    if not target:
        return
    try:
        make, key, _can = target
        engine.sync_game(svc.cfg["data_dir"], svc.vault.game, make(), engine.device_id(svc.cfg), publish_catalog=False, key=key,
                         user_path=svc.session.db_path if svc.session is not None else None)
    except Exception:  # noqa: BLE001
        pass


# ------------------------------------------------------------------------------------------------ backups
@api("backups.list")
def backups_list(svc):
    v = svc.vault
    return {"files": [{"path": f, "name": os.path.basename(f).replace("collection-", "").replace(".db", "")} for f in v.list_backups()], "dir": svc.pget("backup_dir") or ""}


@api("backups.now")
def backups_now(svc):
    return {"path": svc.vault.backup_now("manual", svc.pget("backup_dir"))}


@api("backups.setFolder", mutates=True)
def backups_folder(svc, path=""):
    if path:
        svc.need_grant(path)
    svc.pset("backup_dir", path or None)
    return {"ok": True}


@api("backups.restore", mutates=True)
def backups_restore(svc, path):
    allowed = {os.path.normcase(os.path.abspath(f)) for f in svc.vault.list_backups()}
    if os.path.normcase(os.path.abspath(path)) not in allowed:
        raise ApiError("That is not one of this account's backups.")
    svc.vault.restore_collection(path)
    svc.vault.invalidate_index()
    svc.reload_state()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ data in / out
@api("data.exportCsv")
def export_csv(svc, path):
    svc.need_grant(path)
    svc.audit("export", "collection CSV")
    return {"lines": svc.vault.export_csv(path)}


@api("data.importCsv", mutates=True)
def import_csv(svc, path):
    svc.need_grant(path)
    try:
        added, skipped = svc.vault.import_csv(path)
    except (OSError, ValueError, KeyError) as e:
        raise ApiError("That file couldn't be read. Check that it's the right kind of file and try again.")
    svc.reload_state()
    return {"added": added, "skipped": skipped}


def _import_sources(svc, r):
    """The portfolios (categories) the file talks about, with how much is in each and where it would go by default: a portfolio of the same name here if there is one, else a new one."""
    pfs = svc.vault.portfolios()
    out = {}
    for x in r["rows"]:
        k = (x.get("portfolio") or "").strip()
        d = out.setdefault(k, {"name": k, "cards": 0, "copies": 0, "sealed": 0, "wish": 0})
        if x.get("wish"):
            d["wish"] += 1
        else:
            d["cards"] += 1
            d["copies"] += x["qty"]
    for x in r["sealed"]:
        k = (x.get("portfolio") or "").strip()
        d = out.setdefault(k, {"name": k, "cards": 0, "copies": 0, "sealed": 0, "wish": 0})
        d["sealed"] += x["qty"]
    res = []
    for k, d in sorted(out.items(), key=lambda kv: (kv[0] == "", kv[0].lower())):
        uid, how = importers.best_portfolio(k, pfs)                                                                # the same name, or a close one ('Binders 1' = 'Binder 1')
        d["dest"] = "main" if k.lower() == "main" else (uid or ("new" if k else ""))                              # "" = lines with no portfolio: they go to the one you are looking at
        d["how"] = "" if k.lower() == "main" else how or ("new" if k else "")
        d["matchName"] = next((p["name"] for p in pfs if p["uuid"] == uid), "") if uid else ""
        res.append(d)
    return res


@api("import.read")
def import_read(svc, path):
    svc.need_grant(path)
    try:
        r = importers.read_rows(path, svc.vault)
    except (OSError, ValueError, UnicodeDecodeError, KeyError) as e:
        raise ApiError("That file couldn't be read. Check that it's the right kind of file and try again.")
    from . import resetimport
    v = svc.vault
    matches = []
    lights = v.card_lights([x["card_id"] for x in r["rows"][:5000]])            # (no need to wait for the whole card index for a name and a number)
    for i, x in enumerate(r["rows"][:5000]):
        c = lights.get(x["card_id"]) or {}
        matches.append({"i": i, "source": x["label"], "name": c.get("name", x["card_id"]), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "qty": x["qty"], "variant": x.get("variant") or "",
                        "condition": "Graded" if x.get("graded") else x.get("condition") or "", "paid": x.get("paid"), "portfolio": x.get("portfolio") or "", "wish": bool(x.get("wish"))})
    dest = [{"id": p["id"], "name": p["name"], "accepts": p.get("accepts") or "all"} for p in __import__("cardvault.webapi.portfolios", fromlist=["x"]).pf_list(svc)["portfolios"]]
    return {"already": resetimport.already_imported(svc, path), "format": r["format"], "columns": r["columns"], "matched": len(r["rows"]) + len(r["sealed"]),
            "copies": sum(x["qty"] for x in r["rows"] if not x.get("wish")) + sum(x["qty"] for x in r["sealed"]),
            "sealed": len(r["sealed"]), "wishlist": sum(1 for x in r["rows"] if x.get("wish")), "cards": sum(1 for x in r["rows"] if not x.get("wish")),
            "portfolios": sorted({x["portfolio"] for x in r["rows"] + r["sealed"] if x.get("portfolio")}), "sources": _import_sources(svc, r), "destinations": dest,
            "matches": matches, "matchesShown": len(matches),
            "others": [{"id": g, "name": next((x.name for x in __import__("cardvault.games", fromlist=["x"]).GAMES if x.id == g), g), "n": n} for g, n in (r.get("others") or {}).items()],
            "unmatched": [[a, b] for a, b in r["unmatched"]], "unmatchedCount": len(r["unmatched"]),
            "unmatchedRows": [{"i": i, "label": a, "why": b, "fixable": r["unmatched_raw"][i] is not None} for i, (a, b) in enumerate(r["unmatched"])],
            "review": [{"i": i, "label": x["label"], "why": x["why"], "qty": x["qty"], "options": x["options"]} for i, x in enumerate(r["review"])], "reviewCount": len(r["review"])}


@api("import.run", mutates=True)
def import_run(svc, path, choices=None, again=False, portfolio_map=None, overrides=None, include=None):
    """Import the file.
    choices        {review row number: card id} and {'u<number>': card id} - lines that were not matched, which the person matched by hand (lines not chosen are left out)
    overrides      {matched row number: card id | 'skip'} - change what a matched line became, or leave it out
    portfolio_map  {name in the file: 'skip' | 'main' | an existing portfolio's id | 'new'} - where each portfolio of the file goes (default: the same name here, made if missing)
    include        {cards, sealed, wishlist} - what kinds of lines to bring in (all by default)
    again          import a file that was already imported (it doubles the copies)."""
    svc.need_grant(path)
    from . import resetimport
    dup = resetimport.already_imported(svc, path)
    if dup and not again:
        raise ApiError(f"This exact file was already imported on {dup['ts'][:10]}. Importing it again would double every copy - take that import back first (Settings > Import history), or choose to import it again anyway.", code="already_imported")
    v = svc.vault
    r = importers.read_rows(path, v)
    rows = []
    for i, x in enumerate(r["rows"]):
        o = (overrides or {}).get(str(i), (overrides or {}).get(i))
        if o == "skip":
            continue
        if o:
            if not v.card_basic(o):
                raise ApiError("One of the cards you picked isn't in this game's list.")
            x = {**x, "card_id": o}
        rows.append(x)
    for key, cid in (choices or {}).items():
        if not cid:
            continue
        k = str(key)
        if k.startswith("u"):                                              # a line that matched nothing, fixed by picking its card
            i = int(k[1:])
            raw = r["unmatched_raw"][i] if 0 <= i < len(r["unmatched_raw"]) else None
            if raw is not None and v.card_basic(cid):
                rows.append(importers.row_for(raw, r["_cols"], cid, v))
        else:
            i = int(k)
            if 0 <= i < len(r["review"]) and any(o["id"] == cid for o in r["review"][i]["options"]):
                rows.append(importers.row_for(r["review"][i]["raw"], r["_cols"], cid, v))
    inc = {"cards": True, "sealed": True, "wishlist": True, **(include or {})}
    rows = [x for x in rows if (inc["wishlist"] if x.get("wish") else inc["cards"])]
    sealed = list(r["sealed"]) if inc["sealed"] else []
    before = {p["uuid"] for p in v.portfolios()}
    track = {}
    try:
        n, act = importers.import_rows(v, rows, f"Imported from {r['format']}", sealed, track, portfolio_map or {})
    except ValueError as e:
        raise ApiError(str(e))
    track["portfolios"] = [p["uuid"] for p in v.portfolios() if p["uuid"] not in before]
    resetimport.remember_import(svc, f"{r['format']} import ({n} copies)", track, resetimport.file_sha(path))
    svc.reload_state()
    return {"copies": n, "skipped": len(r["rows"]) + len(r["sealed"]) - len(rows) - len(sealed), "undo": {"id": act.id, "label": f"Imported {n} copies"}}


@api("import.exportUnmatched")
def import_export_unmatched(svc, path, out):
    """Save the lines of the file that could not be matched to a card (with the reason) as a spreadsheet, so they can be fixed there and imported again."""
    import csv
    svc.need_grant(path)
    svc.need_grant(out)
    r = importers.read_rows(path, svc.vault)
    rows = [(raw, why) for (label, why), raw in zip(r["unmatched"], r["unmatched_raw"])]
    if not rows:
        raise ApiError("Everything in that file matched - nothing to save.")
    cols = []
    for raw, _ in rows:
        for k in (raw or {}):
            if k not in cols:
                cols.append(k)
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(cols + ["why it did not match"])
        for (label, why), raw in zip(r["unmatched"], r["unmatched_raw"]):
            w.writerow(([raw.get(c, "") for c in cols] if raw else [label] + [""] * (len(cols) - 1)) + [why])
    return {"lines": len(rows)}


DEVICE_PREFIX = "CVL1-"


def device_code(svc):
    """Everything a new device needs to join this account's sync in one code: the private repository, its sign-in token and the sync key."""
    import base64
    import json as _json
    tok, _src = token(svc)
    body = _json.dumps({"r": svc.pget("sync_repo") or updater.DATA_REPO, "t": tok, "k": e2e.to_code(sync_key(svc, create=True))}, separators=(",", ":"))
    return DEVICE_PREFIX + base64.b32encode(body.encode("utf-8")).decode("ascii").rstrip("=")


def read_device_code(code):
    import base64
    import json as _json
    raw = "".join(ch for ch in code.strip().upper() if ch.isalnum())[len("CVL1"):]
    try:
        data = _json.loads(base64.b32decode(raw + "=" * (-len(raw) % 8)).decode("utf-8"))
        e2e.from_code(data["k"])
        return data
    except (ValueError, KeyError, TypeError, e2e.SyncKeyError):
        raise ApiError("That link code isn't right. Copy the whole code and try again.")


@api("cloud.linkCode")
def link_code(svc, password, full=False):
    """The sync key as a code to type into the phone.  Needs the account password again - it unlocks everything that was synced.
    full=True adds the repository and GitHub sign-in, so a brand-new device only needs this one code."""
    from ..security.profiles import AuthError
    try:
        svc.auth.verify_password(svc.session.pid, password, count=True)
    except AuthError as e:
        raise ApiError(str(e), code=e.code, retry_after=getattr(e, "retry_after", 0))
    svc.session.log_event("sync_key_shown")
    return {"code": device_code(svc) if full else e2e.to_code(sync_key(svc, create=True))}


@api("cloud.setLinkCode", mutates=True)
def set_link_code(svc, code):
    """Use the sync key made on another device (so this one can read what it synced).  A full link code also sets the repository and sign-in."""
    svc.audit("device_linked", "link code used")
    if code.strip().upper().startswith("CVL1"):
        data = read_device_code(code)
        svc.pset("sync_key", data["k"])
        if data.get("r"):
            svc.pset("sync_repo", data["r"])
        if data.get("t"):
            svc.pset("github_token", data["t"])
        svc.pset("sync_enabled", True)
        return {"ok": True, "full": True}
    try:
        key = e2e.from_code(code)
    except e2e.SyncKeyError as e:
        raise ApiError(str(e))
    svc.pset("sync_key", e2e.to_code(key))
    return {"ok": True}
