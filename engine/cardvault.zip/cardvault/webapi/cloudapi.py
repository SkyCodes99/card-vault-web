"""Updates, cross-device sync, backups, CSV import / export and importing from other trackers."""
import datetime
import time
import os
import tempfile
import threading

from .. import runtime, importers, updater
from ..cloud import backend as cloud_backend
from ..cloud import e2e
from ..cloud import engine
from ..db import game_dir
from ..version import VERSION
from .registry import api
from .service import ApiError

STATE = {"update": None, "update_status": "", "sync_status": "Sync is off", "syncing": False}


# ------------------------------------------------------------------------------------------------ tokens
def sync_key(svc, create=False):
    """This account's sync key (bytes), made the first time sync is switched on."""
    raw = svc.pget("sync_key")
    if raw:
        return e2e.from_code(raw)
    if not create:
        return None
    k = e2e.new_key()
    svc.pset("sync_key", e2e.to_code(k))
    return k


def token(svc):
    """(token, where it came from): the account's saved token, else the GitHub CLI sign-in."""
    t = svc.pget("github_token")
    if t:
        return t, "saved token (encrypted)"
    t = updater.gh_token()
    return (t, "GitHub CLI sign-in") if t else ("", "")


@api("cloud.status")
def cloud_status(svc):
    cfg = svc.cfg
    tok, src = token(svc)
    info = STATE["update"]
    return {"version": VERSION, "updateRepo": cfg.get("update_repo") or updater.UPDATE_REPO, "dataRepo": svc.pget("sync_repo") or updater.DATA_REPO,
            "tokenSource": src or "not signed in", "autoUpdates": cfg.get("auto_updates", True), "syncEnabled": bool(svc.pget("sync_enabled", True)),
            "lastCheck": cfg.get("update_last_check") or "", "lastSync": svc.pget("sync_last") or "", "updateStatus": STATE["update_status"],
            "syncStatus": STATE["sync_status"], "syncing": STATE["syncing"], "account": bool(svc.pget("cloud_token")),
            "pending": bool(svc.last_change > getattr(svc, "_synced_upto", 0.0)), "failed": STATE["sync_status"].startswith("Sync problem"), "canInstall": updater.can_self_update(),
            "update": {"latest": info["latest"], "notes": info["notes"]} if info and info.get("update") else None}


@api("cloud.setToken", mutates=True)
def set_token(svc, token=""):
    svc.pset("github_token", token.strip() or None)
    return {"ok": True}


@api("cloud.setFlag", mutates=True)
def set_flag(svc, key, value):
    if key not in ("auto_updates", "sync_enabled"):
        raise ApiError("unknown setting")
    if key == "sync_enabled":
        svc.pset(key, bool(value))
    else:
        svc.cfg[key] = bool(value)
        svc.save()
    if key == "sync_enabled" and value:
        start_sync(svc, manual=True)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ updates
def check_updates(svc, manual=False):
    if runtime.IN_BROWSER:                 # the browser build updates itself: the page notices a newer published version
        return None
    tok, _ = token(svc)
    repo = svc.cfg.get("update_repo") or updater.UPDATE_REPO

    def run(emit, cancel):
        emit("Checking for updates…", 0, 0)
        from . import accountapi
        base = accountapi.server_url(svc)
        info = (updater.check_cloud(base) if base else None) or updater.check(repo, tok)      # your own server first, GitHub as the fallback
        STATE["update"] = info
        svc.cfg["update_last_check"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        if info.get("error"):
            STATE["update_status"] = info["error"]
        elif info["update"]:
            STATE["update_status"] = f"Version {info['latest']} is available (you have {VERSION})."
        else:
            STATE["update_status"] = f"You're up to date (version {VERSION})."
        svc.save()
        if info.get("update") and not info.get("error"):
            svc.bump("update", version=info["latest"], notes=(info.get("notes") or "").strip().splitlines()[0][:160] if info.get("notes") else "")
        return {"update": bool(info.get("update")), "latest": info.get("latest"), "error": info.get("error", ""), "status": STATE["update_status"]}
    return svc.jobs.start("update-check", "Checking for updates", run)


@api("update.check")
def update_check(svc, manual=True):
    try:
        j = check_updates(svc, manual)
        return {"job": j.id if j else None}
    except ApiError:
        return {"job": None}


@api("update.install")
def update_install(svc):
    info = STATE["update"]
    if not info or not info.get("update"):
        raise ApiError("There is no update to install.")
    if not updater.can_self_update():
        import webbrowser
        webbrowser.open(info.get("page") or "https://github.com/" + (svc.cfg.get("update_repo") or updater.UPDATE_REPO) + "/releases/latest")
        return {"opened": True}
    tok, _ = token(svc)

    def run(emit, cancel):
        dest = os.path.join(tempfile.gettempdir(), info["asset"]["name"])
        updater.download(info["asset"], None if info.get("source") == "cloud" else tok, dest, lambda a, b: emit("Downloading the update…", a, b))
        emit("Preparing the update…", 0, 0)
        staging = updater.stage(dest)
        bat = updater.write_installer(staging, updater.app_dir(), os.getpid())
        svc.vault.backup_now("exit", svc.pget("backup_dir"))
        updater.launch_installer(bat)
        if svc.quit_app:
            threading.Timer(1.0, svc.quit_app).start()
        return {"restarting": True}
    return {"job": svc.jobs.start("update-install", f"Installing {info['latest']}", run).id}


# ------------------------------------------------------------------------------------------------ sync
def games_to_sync(svc):
    v = svc.vault
    found = {v.game}
    for (g,) in v.conn.execute("SELECT DISTINCT game FROM u.lots WHERE user_id=? UNION SELECT DISTINCT game FROM u.checklists WHERE user_id=? "
                               "UNION SELECT DISTINCT game FROM u.wishlist WHERE user_id=?", (v.user_id,) * 3):
        if g and os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g), "cards.db")):
            found.add(g)
    return sorted(found, key=lambda g: (g != v.game, g))


def sync_target(svc, force_github=False):
    """Where this account syncs: its cloud account when signed in (end-to-end encrypted by the account's own data key), else the GitHub repository.
    -> (backend factory, e2e key, can publish the card catalogue)"""
    from . import accountapi
    from ..cloud import skycloud
    a = None if force_github else accountapi.account(svc)
    if a is not None and (svc.pget("cloud_sync_mode") or "account") == "account":
        return (lambda: skycloud.SkyCloudBackend(a)), None, False
    tok, _ = token(svc)
    if not tok:
        return None
    cfg = dict(svc.cfg)
    cfg["sync_repo"] = svc.pget("sync_repo") or updater.DATA_REPO
    return (lambda: cloud_backend.make_backend(cfg, tok)), sync_key(svc, create=True), True


def start_sync(svc, manual=False, publish=True, force_github=False):
    if not svc.pget("sync_enabled", True):
        if manual:
            raise ApiError("Turn on 'Sync across my devices' in Settings first.")
        return None
    if svc.jobs.running("sync"):
        return None
    target = sync_target(svc, force_github)
    if not target:
        STATE["sync_status"] = "Sync needs your account (or a GitHub sign-in) - see Settings"
        return None
    make, key, can_publish = target
    publish = publish and can_publish
    upath = svc.session.db_path if svc.session is not None else None
    data_dir, device, game_list = svc.cfg["data_dir"], engine.device_id(svc.cfg), games_to_sync(svc)

    started = time.time()

    def run(emit, cancel):
        STATE["syncing"] = True
        emit("Syncing…", 0, 0)
        be = make()
        res = [engine.sync_game(data_dir, g, be, device, publish_catalog=publish, key=key, user_path=upath) for g in game_list]
        if key is None and hasattr(be, "list_docs"):            # an account: copy photos travel too
            try:
                res[0]["photos"] = engine.sync_photos(data_dir, game_list[0], be, upath)
            except Exception as e:  # noqa: BLE001 - photos are never allowed to fail the main sync
                res[0]["photos_error"] = str(e)
        if publish:
            engine.publish_other_catalogs(data_dir, be, skip=game_list, key=key, user_path=upath)
        return res

    def done(job):
        STATE["syncing"] = False
        if job.state == "done":
            svc._synced_upto = started                 # everything changed before the sync began is now saved
            pulled = sum(r["pulled"] for r in job.result)
            now = datetime.datetime.now().strftime("%H:%M")
            svc.pset("sync_last", datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
            STATE["sync_status"] = f"Synced at {now}" + (f" · {pulled} change{'s' if pulled != 1 else ''} received" if pulled else "")
            try:
                from .settings import prefs_adopt
                prefs_adopt(svc)                      # a choice made on another device (currency, budget, theme...) arrives with the sync
            except Exception:  # noqa: BLE001
                pass
            if pulled:
                svc.vault.invalidate_index()
                svc.reload_state()
                svc.bump("synced", pulled=pulled)
        else:
            STATE["sync_status"] = f"Sync problem: {job.error}"
    return svc.jobs.start("sync", "Syncing", run, on_done=done)


@api("sync.now")
def sync_now(svc, manual=True):
    j = start_sync(svc, manual)
    return {"job": j.id if j else None}


def flush_sync(svc):
    """Last chance on exit: push unsynced changes (quick, errors ignored)."""
    if not svc.pget("sync_enabled", True):
        return
    target = sync_target(svc)
    if not target:
        return
    try:
        make, key, _can = target
        engine.sync_game(svc.cfg["data_dir"], svc.vault.game, make(), engine.device_id(svc.cfg), publish_catalog=False, key=key,
                         user_path=svc.session.db_path if svc.session is not None else None)
    except Exception:  # noqa: BLE001
        pass


# ------------------------------------------------------------------------------------------------ backups
@api("backups.list")
def backups_list(svc):
    v = svc.vault
    return {"files": [{"path": f, "name": os.path.basename(f).replace("collection-", "").replace(".db", "")} for f in v.list_backups()], "dir": svc.pget("backup_dir") or ""}


@api("backups.now")
def backups_now(svc):
    return {"path": svc.vault.backup_now("manual", svc.pget("backup_dir"))}


@api("backups.setFolder", mutates=True)
def backups_folder(svc, path=""):
    if path:
        svc.need_grant(path)
    svc.pset("backup_dir", path or None)
    return {"ok": True}


@api("backups.restore", mutates=True)
def backups_restore(svc, path):
    allowed = {os.path.normcase(os.path.abspath(f)) for f in svc.vault.list_backups()}
    if os.path.normcase(os.path.abspath(path)) not in allowed:
        raise ApiError("That is not one of this account's backups.")
    svc.vault.restore_collection(path)
    svc.vault.invalidate_index()
    svc.reload_state()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ data in / out
@api("data.exportCsv")
def export_csv(svc, path):
    svc.need_grant(path)
    svc.audit("export", "collection CSV")
    return {"lines": svc.vault.export_csv(path)}


@api("data.importCsv", mutates=True)
def import_csv(svc, path):
    svc.need_grant(path)
    try:
        added, skipped = svc.vault.import_csv(path)
    except (OSError, ValueError, KeyError) as e:
        raise ApiError(f"Could not read that file: {e}")
    svc.reload_state()
    return {"added": added, "skipped": skipped}


@api("import.read")
def import_read(svc, path):
    svc.need_grant(path)
    try:
        r = importers.read_rows(path, svc.vault)
    except (OSError, ValueError, UnicodeDecodeError, KeyError) as e:
        raise ApiError(f"Could not read that file: {e}")
    return {"format": r["format"], "columns": r["columns"], "matched": len(r["rows"]), "copies": sum(x["qty"] for x in r["rows"]),
            "unmatched": [[a, b] for a, b in r["unmatched"][:300]], "unmatchedCount": len(r["unmatched"])}


@api("import.run", mutates=True)
def import_run(svc, path):
    svc.need_grant(path)
    r = importers.read_rows(path, svc.vault)
    n, act = importers.import_rows(svc.vault, r["rows"], f"Imported from {r['format']}")
    svc.reload_state()
    return {"copies": n, "undo": {"id": act.id, "label": f"Imported {n} copies"}}


DEVICE_PREFIX = "CVL1-"


def device_code(svc):
    """Everything a new device needs to join this account's sync in one code: the private repository, its sign-in token and the sync key."""
    import base64
    import json as _json
    tok, _src = token(svc)
    body = _json.dumps({"r": svc.pget("sync_repo") or updater.DATA_REPO, "t": tok, "k": e2e.to_code(sync_key(svc, create=True))}, separators=(",", ":"))
    return DEVICE_PREFIX + base64.b32encode(body.encode("utf-8")).decode("ascii").rstrip("=")


def read_device_code(code):
    import base64
    import json as _json
    raw = "".join(ch for ch in code.strip().upper() if ch.isalnum())[len("CVL1"):]
    try:
        data = _json.loads(base64.b32decode(raw + "=" * (-len(raw) % 8)).decode("utf-8"))
        e2e.from_code(data["k"])
        return data
    except (ValueError, KeyError, TypeError, e2e.SyncKeyError):
        raise ApiError("That link code isn't right. Copy the whole code and try again.")


@api("cloud.linkCode")
def link_code(svc, password, full=False):
    """The sync key as a code to type into the phone.  Needs the account password again - it unlocks everything that was synced.
    full=True adds the repository and GitHub sign-in, so a brand-new device only needs this one code."""
    from ..security.profiles import AuthError
    try:
        svc.auth.verify_password(svc.session.pid, password, count=True)
    except AuthError as e:
        raise ApiError(str(e), code=e.code, retry_after=getattr(e, "retry_after", 0))
    svc.session.log_event("sync_key_shown")
    return {"code": device_code(svc) if full else e2e.to_code(sync_key(svc, create=True))}


@api("cloud.setLinkCode", mutates=True)
def set_link_code(svc, code):
    """Use the sync key made on another device (so this one can read what it synced).  A full link code also sets the repository and sign-in."""
    svc.audit("device_linked", "link code used")
    if code.strip().upper().startswith("CVL1"):
        data = read_device_code(code)
        svc.pset("sync_key", data["k"])
        if data.get("r"):
            svc.pset("sync_repo", data["r"])
        if data.get("t"):
            svc.pset("github_token", data["t"])
        svc.pset("sync_enabled", True)
        return {"ok": True, "full": True}
    try:
        key = e2e.from_code(code)
    except e2e.SyncKeyError as e:
        raise ApiError(str(e))
    svc.pset("sync_key", e2e.to_code(key))
    return {"ok": True}
