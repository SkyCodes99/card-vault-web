"""Updates, cross-device sync, backups, CSV import / export and importing from other trackers."""
import datetime
import time
import os
import tempfile
import sys
import threading

from .. import runtime, importers, updater
from ..cloud import backend as cloud_backend
from ..cloud import e2e
from ..cloud import engine, syncmarks
from . import syncprogress
from ..db import game_dir
from ..version import VERSION
from .registry import api
from .service import ApiError

STATE = {"update": None, "update_status": "", "sync_status": "Cloud saving is off", "syncing": False}


# ------------------------------------------------------------------------------------------------ tokens
def sync_key(svc, create=False):
    """This account's sync key (bytes), made the first time sync is switched on."""
    raw = svc.pget("sync_key")
    if raw:
        return e2e.from_code(raw)
    if not create:
        return None
    k = e2e.new_key()
    svc.pset("sync_key", e2e.to_code(k))
    return k


_GH = {"t": "", "busy": False, "done": False}        # the GitHub CLI sign-in: looked up ONCE, in the background (it starts a program that can take seconds)


def _gh_lookup():
    try:
        _GH["t"] = updater.gh_token()
    finally:
        _GH["busy"], _GH["done"] = False, True


def _gh_cached(svc):
    """The GitHub CLI sign-in, never waited for: only owner/dev builds (running from source, or the owner's account) ask, once, on a side thread."""
    if not _GH["done"] and not _GH["busy"] and (not getattr(sys, "frozen", False) or svc.pget("cloud_admin")):
        _GH["busy"] = True
        threading.Thread(target=_gh_lookup, daemon=True, name="gh-token").start()
    return _GH["t"]


def token(svc):
    """(token, where it came from): the account's saved token, else the GitHub CLI sign-in."""
    t = svc.pget("github_token")
    if t:
        return t, "saved token (encrypted)"
    if runtime.INLINE:
        return "", ""                                  # no GitHub command-line sign-in exists in a browser (asking used to cost a second at every start); the browser-style engine on a PC (tests) is the same - it must never pick up this PC's own GitHub sign-in and sync with the real repository in one blocking step
    t = _gh_cached(svc)
    return (t, "GitHub CLI sign-in") if t else ("", "")


def _target_name(svc):
    """Where changes are saved right now: 'account' (the cloud account), 'github' (an older private-repository setup) or 'none' (only on this device)."""
    if svc.pget("cloud_token") and (svc.pget("cloud_sync_mode") or "account") == "account":
        return "account"
    if svc.pget("github_token") and svc.pget("sync_key"):          # a GitHub sync this profile really set up (never the computer's own GitHub sign-in)
        return "github"
    return "none"


def _waiting_changes(svc):
    """How many changes are still waiting to be sent: journal entries newer than the last successful sync (0 when nothing is open or nothing is waiting)."""
    import datetime
    upto = getattr(svc, "_synced_upto", 0.0)
    if svc.vault is None or svc.last_change <= upto:
        return 0
    since = datetime.datetime.fromtimestamp(upto, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ") if upto else ""
    try:
        return min(9999, max(1, svc.vault.conn.execute("SELECT COUNT(*) FROM u.journal WHERE user_id=? AND ts>?", (svc.vault.user_id, since)).fetchone()[0]))
    except Exception:  # noqa: BLE001 - a status line must never fail
        return 1


def _review_count(svc):
    """Records changed on two devices at once, waiting on the sync review list (cloud/conflicts.py)."""
    from ..cloud import conflicts
    return conflicts.count(svc.vault.conn, svc.vault.user_id) if svc.vault is not None else 0


def _failed_note():
    """A failed update's plain note (the update window left it for the reopened app), read once per start and kept until dismissed."""
    if "update_failed" not in STATE:
        STATE["update_failed"] = "" if runtime.IN_BROWSER else updater.take_failed_note()
    return STATE["update_failed"]


@api("cloud.status")
def cloud_status(svc):
    cfg = svc.cfg
    tok, src = token(svc)
    info = STATE["update"]
    return {"version": VERSION, "updateRepo": cfg.get("update_repo") or updater.UPDATE_REPO, "dataRepo": svc.pget("sync_repo") or updater.DATA_REPO,
            "tokenSource": src or "not signed in", "autoUpdates": cfg.get("auto_updates", True), "syncEnabled": bool(svc.pget("sync_enabled", True)),
            "lastCheck": cfg.get("update_last_check") or "", "lastSync": svc.pget("sync_last") or "", "updateStatus": STATE["update_status"],
            "syncStatus": STATE["sync_status"], "syncing": STATE["syncing"], "account": bool(svc.pget("cloud_token")), "target": _target_name(svc),
            "pending": bool(svc.last_change > getattr(svc, "_synced_upto", 0.0)), "waiting": _waiting_changes(svc), "retrySec": max(0, int(getattr(svc, "_sync_backoff", 0) - __import__("time").time())), "failed": STATE["sync_status"].startswith(("Couldn't save", "Your session ended")), "error": STATE.get("sync_error", ""),
            "offline": "Couldn't connect" in STATE.get("sync_error", ""), "review": _review_count(svc),
            "signedIn": bool(svc.pget("cloud_token") and svc.pget("cloud_dek")), "username": svc.pget("cloud_username") or "", "canInstall": updater.can_self_update(),
            "update": {"latest": info["latest"], "notes": info["notes"], "rollback": bool(info.get("rollback"))} if info and info.get("update") else None,
            "updateFailed": _failed_note()}


@api("cloud.setToken", mutates=True)
def set_token(svc, token=""):
    svc.pset("github_token", token.strip() or None)
    return {"ok": True}


@api("cloud.setFlag", mutates=True)
def set_flag(svc, key, value):
    if key not in ("auto_updates", "sync_enabled"):
        raise ApiError("unknown setting")
    if key == "sync_enabled":
        svc.pset(key, bool(value))
        svc.pset("sync_off_chosen", None if value else True)      # the person's own "off": a sign-in by hand keeps it (an older app's stored False was also their own toggle - marked at unlock)
    else:
        svc.cfg[key] = bool(value)
        svc.save()
    if key == "sync_enabled" and value:
        start_sync(svc, manual=True)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ updates
def newest_release(svc, repo=None, tok=None):
    """The newest published version for this app (never the next one in line: the feed and GitHub's 'latest' both name the newest), same shape as updater.check()."""
    from . import accountapi
    if tok is None:
        tok, _ = token(svc)
    repo = repo or svc.cfg.get("update_repo") or updater.UPDATE_REPO
    base = accountapi.server_url(svc)
    preview = bool(svc.pget("preview_channel")) and bool(svc.pget("cloud_admin"))          # the owner's account can ask for preview builds first
    return (updater.check_cloud(base, channel="preview") if (base and preview) else None) or (updater.check_cloud(base) if base else None) or updater.check(repo, tok)      # your own server first, GitHub as the fallback


def save_before_update(svc, emit, timeout=60.0):
    """'Saving before update…': let a running sync finish and send changes that have not gone to your account yet, then take a safety copy.
    Returns True when nothing was left unsent (False = it waited `timeout` seconds or there is nowhere to send to; the update goes ahead, the changes stay on this computer)."""
    emit("Saving before update…", 0, 0)
    pending = lambda: svc.last_change > getattr(svc, "_synced_upto", 0.0)
    end, started = time.time() + timeout, False
    while time.time() < end:
        if svc.jobs.running("sync"):
            time.sleep(0.3)
            continue
        if pending() and not started:
            started = True
            try:
                if start_sync(svc) is not None:
                    continue
            except Exception:  # noqa: BLE001 - saving to the account is a courtesy here, never a reason to refuse the update
                pass
        break
    try:
        checkpoint_now(svc, on_engine=False)                     # the change-only sync: the documents get every change too, so the version installed next (or an older one) has them
    except Exception:  # noqa: BLE001
        pass
    try:                                                          # a safety copy - on the thread that owns the collection (using it from here failed with a SQLite thread error and silently stopped every update)
        svc.run(lambda s: s.vault.backup_now("exit", s.pget("backup_dir")), timeout=60)
    except Exception:  # noqa: BLE001
        pass
    return not pending()


def check_updates(svc, manual=False):
    if runtime.IN_BROWSER:                 # the browser build updates itself: the page notices a newer published version
        return None
    tok, _ = token(svc)
    repo = svc.cfg.get("update_repo") or updater.UPDATE_REPO

    def run(emit, cancel):
        emit("Checking for updates…", 0, 0)
        info = newest_release(svc, repo, tok)
        STATE["update"] = info
        svc.cfg["update_last_check"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        if info.get("error"):
            STATE["update_status"] = info["error"]
        elif info["update"]:
            STATE["update_status"] = (f"A problem was found in the newest version. Go back to {info['latest']}? (you have {VERSION})." if info.get("rollback") else f"Version {info['latest']} is available (you have {VERSION}).")
        else:
            STATE["update_status"] = f"You're up to date (version {VERSION})."
        svc.save()
        if info.get("update") and not info.get("error"):
            svc.bump("update", version=info["latest"], rollback=bool(info.get("rollback")), notes=(info.get("notes") or "").strip().splitlines()[0][:160] if info.get("notes") else "")
        return {"update": bool(info.get("update")), "latest": info.get("latest"), "error": info.get("error", ""), "status": STATE["update_status"]}
    return svc.jobs.start("update-check", "Checking for updates", run)


@api("update.channel", mutates=True)
def update_channel(svc, preview=None):
    """The owner's account only: get preview builds first (before everybody).  Reads or sets the choice."""
    if not svc.pget("cloud_admin"):
        return {"available": False, "preview": False}
    if preview is not None:
        svc.pset("preview_channel", True if preview else None)
    return {"available": True, "preview": bool(svc.pget("preview_channel"))}


@api("update.check")
def update_check(svc, manual=True):
    try:
        j = check_updates(svc, manual)
        return {"job": j.id if j else None}
    except ApiError:
        return {"job": None}


@api("update.install")
def update_install(svc):
    info = STATE["update"]
    if not info or not info.get("update"):
        raise ApiError("There is no update to install.")
    if not updater.can_self_update():
        import webbrowser
        webbrowser.open(info.get("page") or "https://github.com/" + (svc.cfg.get("update_repo") or updater.UPDATE_REPO) + "/releases/latest")
        return {"opened": True}
    tok, _ = token(svc)

    def run(emit, cancel):
        # 1. everything saved first (the screens already emptied their outbox before asking)
        save_before_update(svc, emit)
        from . import authapi
        handoff = authapi.keep_for_update(svc)    # the new version opens already signed in (used once, within devicekey.HANDOFF_MINUTES of the new version starting)
        # 2. straight to the NEWEST version, even if a newer one came out after the bar was shown (never one version at a time)
        emit("Saving before update…", 1, 1)
        try:
            fresh = newest_release(svc, tok=tok)
            if fresh and fresh.get("update") and not fresh.get("error"):
                STATE["update"] = fresh
        except Exception:  # noqa: BLE001 - the version already found is still fine
            pass
        cur = STATE["update"]
        target = updater.app_dir()
        if updater.updater_exe(target):
            # 3. the new way: the app closes and a small window downloads (with a progress bar), swaps the files and opens the new version
            emit("Closing to update…", 1, 1)
            updater.launch_update_window(cur, target, os.getpid(), token="" if cur.get("source") in ("cloud", "preview") else tok, handoff=handoff)
            from .. import skyrelaunch
            skyrelaunch.exit_watchdog(20)          # the window waits for this program to end: make sure it really does
            if svc.quit_app:
                threading.Timer(0.8, svc.quit_app).start()
            return {"restarting": True, "window": True, "version": cur["latest"]}
        # (an install without the update window: download here, then the script swaps the files)
        dest = os.path.join(tempfile.gettempdir(), cur["asset"]["name"])
        updater.download(cur["asset"], None if cur.get("source") in ("cloud", "preview") else tok, dest, lambda a, b: emit("Downloading the update…", a, b))
        emit("Unpacking the update…", 0, 1)
        staging = updater.stage(dest, lambda a, b: emit("Unpacking the update…", a, b))
        emit("Restarting…", 1, 1)
        bat = updater.write_installer(staging, target, os.getpid())
        updater.freshen(handoff)                  # (the download above took its time: the hand-over counts from now)
        updater.launch_installer(bat)
        if svc.quit_app:
            threading.Timer(1.0, svc.quit_app).start()
        return {"restarting": True, "version": cur["latest"]}
    return {"job": svc.jobs.start("update-install", f"Installing {info['latest']}", run).id}


@api("update.dismissFailed")
def update_dismiss_failed(svc):
    STATE["update_failed"] = ""
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ sync
# 3.50.136 (docs/speed136_sync_design.md): in account mode a sync is the change-only sync - push what this device changed, pull what the others pushed (cloud/records.py), one or two
# small requests whatever the size of the collection or the number of games.  The per-game documents are written in the background as CHECKPOINTS (start_checkpoint): how a new
# device starts, how 3.50.135 and older keep syncing, and the way back.  With the change-only sync switched off (this device, or the whole account) a sync is the snapshot sync below.
# Photos, races and catalogue publishing are jobs of their own (a background sync never waits for them; a "Sync now" still does photos and races before it says it is done).
USER_KINDS = ("lots", "checklists", "wishlist", "decks", "sealed", "sold", "custom_items")          # tables holding something of the user's per game: a game with any of them is synced
SWITCH_DOC = "sync/records.json"                 # the account-wide off switch of the change-only sync: {"v": 1, "off": true|false}, sealed like every document (read by every 136+ device)
CHECKPOINT_EVERY = 300.0                         # seconds between two checkpoints of one game while it keeps changing (Phase A: devices on 3.50.135 may still be about)
CHECKPOINT_PHASE_B = 3600.0                      # ... once every device that synced in the last 30 days is on 136+ and no old device wrote for 30 days
LEGACY_QUIET = 30 * 86400
RECONCILE_GAP = 60.0                             # at most one "the account moved but the feed brought nothing" look at the documents a minute


def games_to_sync(svc):
    v = svc.vault
    found = {v.game}
    have = {r[0] for r in v.conn.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}
    kinds = [t for t in USER_KINDS if t in have]                                     # (decks, sold and own items are made the first time they are used)
    for (g,) in v.conn.execute(" UNION ".join(f"SELECT DISTINCT game FROM u.{t} WHERE user_id=?" for t in kinds), (v.user_id,) * len(kinds)):
        if g and os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g), "cards.db")):
            found.add(g)
    return sorted(found, key=lambda g: (g != v.game, g))


def sync_target(svc, force_github=False):
    """Where this account syncs: its cloud account when signed in (end-to-end encrypted by the account's own data key), else the GitHub repository.
    -> (backend factory, e2e key, can publish the card catalogue)"""
    from . import accountapi
    from ..cloud import skycloud
    a = None if force_github else accountapi.account(svc)
    if a is not None and (svc.pget("cloud_sync_mode") or "account") == "account":
        return (lambda: skycloud.SkyCloudBackend(a)), None, False
    tok, _ = token(svc)
    if not tok:
        return None
    cfg = dict(svc.cfg)
    cfg["sync_repo"] = svc.pget("sync_repo") or updater.DATA_REPO
    return (lambda: cloud_backend.make_backend(cfg, tok)), sync_key(svc, create=True), True


def records_on(svc, force_github=False):
    """Is the change-only sync in use here?  Account mode only (GitHub keeps the snapshot sync), unless this device's switch (sync_records) or the account's (SWITCH_DOC) is off."""
    if force_github or not svc.pget("cloud_token") or (svc.pget("cloud_sync_mode") or "account") != "account":
        return False
    if svc.pget("sync_records") is False or getattr(svc, "_records_account_off", False):
        return False
    return True


def push_delay(svc):
    """How long the collection should rest after a change before it is sent (for webapi/scheduler._sync_quiet): with the change-only sync a push is a few hundred bytes, so about a
    second on the website too - the 10 s batching was for whole documents.  None: keep the scheduler's own rule (the snapshot sync)."""
    return 1.0 if records_on(svc) else None


def _account_state(be):
    """(fingerprint, versions) of the account before a sync, or None for a backend that cannot say.  (A step of the sync: in the browser the question is handed out - see steps.py.)"""
    if not hasattr(be, "seen"):
        return None
    try:
        return (yield from be.state_steps()) if hasattr(be, "state_steps") else be.state()
    except Exception:  # noqa: BLE001
        return None


def _fp_to_record(be, before):
    """The fingerprint to remember as 'seen' once a sync has finished.  Normally what the account holds now.  But if another device saved a document WHILE this sync was running and this sync neither read
    nor wrote that version, the change is not here yet: remember the older fingerprint, so the next look sees a difference and fetches it (it used to be marked as seen and never arrived).
    A sync that saved nothing left the account as it found it, so the fingerprint from the start is the right one - no second look needed."""
    if before and not getattr(be, "wrote", True):
        return before[0] or None
    after = (yield from _account_state(be)) if before else None
    if not after:
        return None
    foreign = any(ver != before[1].get(name) and ver != be.seen.get(name) for name, ver in after[1].items())
    return before[0] if foreign else after[0]


def _snapshot_steps(svc, be, before, bar, data_dir, device, game_list, key, upath, force, quiet=False, upto=None, fast_wanted=False):
    """The snapshot sync of every game (read, merge, write each game's document - skipping the ones whose marks say nothing moved).  The whole sync when the change-only sync is off; a new
    device's first start and the checkpoints when it is on.  quiet: what arrives is not put in the outbox (it is in the account already); upto: this device's cursor, written into each
    document; fast_wanted: a game whose card list is not here has its document's records applied straight into the collection (no scratch collection, no merge - cloud/records.py)."""
    marks = syncmarks.for_account(svc.cfg, be.acct) if before else None                  # (a backend that cannot say which version a document is at has no marks: every game is synced)
    versions = before[1] if before else {}
    here, svc._lists_wanted = account_games(data_dir, versions, game_list)                 # the account's other games come down too (a new device used to bring only the open game)
    wanted = list(svc._lists_wanted)
    games_now = game_list + here
    bar.listed(getattr(be, "_sizes", None) or {}, [engine.data_path("local", g) for g in games_now + wanted])
    bar.games(len(games_now) + len(wanted))
    verify = set() if getattr(svc, "_sync_verified", False) else {game_list[0]}         # the first sync after the app starts looks at the open game for real, whatever the marks say
    looked = getattr(svc, "_here_verified", set())
    verify |= (set(here) | set(wanted)) - looked                                         # (a game this device has no collection in yet: looked at for real once a session - then its marks decide)
    forced = lambda g: force or g in verify
    if hasattr(be, "prefetch") and not runtime.INLINE:                                  # the desktop: the documents of the games that need a look come down side by side while the first ones merge
        be.prefetch([engine.data_path("local", g) for g in games_now if engine.needs_sync(data_dir, g, marks, versions, forced(g), user_path=upath)])
    res = []
    for g in games_now:
        res.append((yield from engine.sync_changed_steps(data_dir, g, be, device, marks, versions, force=forced(g), publish_catalog=False, key=key, user_path=upath, progress=bar.hook,
                                                         quiet=quiet, records_upto=upto)))
        bar.game_done()
    for g in wanted:                                                                     # a game whose card list is not here (yet): its records come down all the same - every count holds them (3.50.134: 2914 vs 2927)
        if fast_wanted and key is None:
            res.append((yield from _document_records_steps(svc, be, g, marks, versions, forced(g), upath, bar)))
        else:
            res.append((yield from engine.sync_records_steps(data_dir, g, be, device, marks, versions, force=forced(g), key=key, user_path=upath, progress=bar.hook, quiet=quiet, records_upto=upto)))
        bar.game_done()
    svc._sync_verified = True
    svc._here_verified = looked | set(here) | set(wanted)
    return res


def _document_records_steps(svc, be, game, marks, versions, force, upath, bar):
    """A new device's start for a game whose card list is not here: its document's records go straight into the collection (cloud/records.apply_document), with the outbox quiet."""
    from ..cloud import records
    path = engine.data_path("local", game)
    stamp = syncmarks.local_stamp(upath, game) if marks is not None else None
    if marks is not None and not force and marks.unchanged(game, versions.get(path), stamp):
        return {"game": game, "pulled": 0, "pushed": False, "conflicts": 0, "skipped": True}
    raw, ver = yield from engine._steps(be, "read", path)
    bar.hook("got", path)
    yield
    out = {"game": game, "pulled": 0, "pushed": False, "conflicts": 0, "records_upto": None}
    if not raw:
        return out
    import json as _json
    snap = _json.loads(raw.decode("utf-8"))
    out["records_upto"] = engine._upto(snap)
    conn = records.open_conn(upath)
    try:
        n, flags = records.apply_document(conn, "local", game, snap)
        conn.commit()
    finally:
        conn.close()
    out["pulled"], out["taxonomy"] = n, "taxonomy" in flags
    if marks is not None:
        if n:
            marks.forget(game)
        else:
            marks.keep(game, ver, syncmarks.local_stamp(upath, game))
    return out


def start_sync(svc, manual=False, publish=True, force_github=False, force=None, then=None):
    """force: look at every game for real, whatever the marks say (default: a manual sync does).  Bringing a collection into the account after signing in passes False - the marks
    already skip the games nothing changed in, and a forced look at all 40 games of a big account took minutes.
    then(job): runs after this sync ends, whichever way (given here, so it is in place before the job can start - and finish)."""
    force = manual if force is None else bool(force)
    if not svc.pget("sync_enabled", True):
        if manual:
            raise ApiError("Cloud saving is off. Turn on 'Save my changes to the cloud automatically' in Settings > Cloud saving first.")
        return None
    if svc.jobs.running("sync"):
        return None
    target = sync_target(svc, force_github)
    if not target:
        STATE["sync_status"] = "Sign in to an account (Settings) to save your collection to the cloud."
        return None
    make, key, can_publish = target
    publish = publish and can_publish
    upath = svc.session.db_path if svc.session is not None else None
    data_dir, device, game_list = svc.cfg["data_dir"], engine.device_id(svc.cfg), games_to_sync(svc)
    if key is None and upath and records_on(svc, force_github):
        return _start_records(svc, manual, force, make, upath, data_dir, device, game_list, then)

    started = time.time()
    applied = {"n": 0}

    def run(emit, cancel):
        STATE["syncing"] = True
        bar = syncprogress.SyncProgress(emit)
        bar.at("check")
        be = make()
        before = yield from _account_state(be)
        yield                                                                                # (in the browser each piece runs at its own moment - see Jobs.step)
        svc._fp_after = None
        res = yield from _snapshot_steps(svc, be, before, bar, data_dir, device, game_list, key, upath, force)
        if sum(r.get("pulled", 0) for r in res):
            svc.post(lambda s: _apply_pulled(s, res, applied))                                # the screens show what arrived NOW - not after the photos, races and the last look at the account
        if manual:
            yield from _side_steps(svc, be, res, key, data_dir, game_list, upath, bar)          # "Sync now": photos and races too, before it says it is done (a background sync leaves them to their own jobs)
        bar.at("check")
        svc._fp_after = yield from _fp_to_record(be, before)
        if svc._fp_after is None and hasattr(be, "acct"):
            try:                                                                       # (asked here, as a step of the sync - not afterwards on the engine's own thread, where it held up clicks)
                svc._fp_after = (yield from be.acct.call_steps("GET", "/v1/docs", patient=True)).get("fp") or None
            except Exception:  # noqa: BLE001
                pass
        return res

    def done(job):
        STATE["syncing"] = False
        svc._sync_cost = job.busy                               # how long a sync keeps the engine busy here (the scheduler waits longer before the next one when it is slow)
        fp_moved = getattr(svc, "_fp_seen", None) not in (None, svc.cfg.get("_cloud_fp"))
        if job.state == "done":
            svc._synced_upto = started                 # everything changed before the sync began is now saved
            svc._unsent_since = svc.last_change if svc.last_change > started else 0.0
            STATE["sync_error"] = ""
            if getattr(svc, "_fp_after", None):
                svc.cfg["_cloud_fp"] = svc._fp_after          # what the account holds NOW: only something newer than this is a change from another device (looked up by the sync itself: no question to the server here,
                                                              # on the engine's own thread, where it held up clicks; when it could not be had, the next look simply finds a difference and syncs once more)
            _sync_done(svc, job, applied)
            if not manual:
                _after_sync(svc, job.result, fp_moved, key)
            if publish:
                start_publish(svc, [r.get("game") for r in job.result or () if r.get("game")])
        else:
            _sync_failed(svc, job)
        if getattr(svc, "_sync_again", False) and job.state == "done":
            svc._sync_again = False
            start_sync(svc, False, publish=False)                # a card list arrived while this sync ran: its game's collection comes down now
        if then is not None:
            then(job)
    return svc.jobs.start("sync", "Syncing", run, on_done=done)


def _sync_done(svc, job, applied):
    """What every finished sync does on the engine's thread: the status line, choices made on another device, the screens."""
    pulled = sum(r.get("pulled", 0) for r in job.result or ())
    now = datetime.datetime.now().strftime("%H:%M")
    svc.pset("sync_last", datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
    STATE["sync_status"] = f"Saved at {now}" + (f" · {pulled} change{'s' if pulled != 1 else ''} from your other devices" if pulled else "")
    try:
        from .settings import prefs_adopt
        prefs_adopt(svc)                      # a choice made on another device (currency, budget, theme...) arrives with the sync
    except Exception:  # noqa: BLE001
        pass
    if any(not r.get("skipped") for r in job.result or ()):
        svc.save()                                  # (what each game's sync left behind is remembered, so the next one can skip it)
    if pulled and not applied["n"]:
        _apply_pulled(svc, job.result, applied)
    elif any((r.get("photos") or {}).get("down") for r in job.result or ()):
        svc.bump("sync")                            # photos arrived after the collection was shown: the screens look again (not a change made here: nothing is sent back)
    elif any(r.get("account") for r in job.result or ()):
        svc.bump("sync")                            # (a look or "where I was" chosen on another device)
    _get_lists(svc)


def _sync_failed(svc, job):
    svc._sync_backoff = time.time() + 10                # a failed attempt: wait a little before the next one
    STATE["sync_error"] = str(job.error or "")[:160]     # the real reason, shown in Settings > Cloud saving so it can be fixed (not just "couldn't save")
    STATE["sync_status"] = "Your session ended - sign in again to keep saving." if "signed out" in str(job.error or "") else "Couldn't save just now - we'll keep trying."


# ------------------------------------------------------------------------------------------------ the change-only sync
def _start_records(svc, manual, force, make, upath, data_dir, device, game_list, then):
    from ..cloud import records
    started = time.time()
    applied = {"n": 0}
    open_game = game_list[0]

    def run(emit, cancel):
        STATE["syncing"] = True
        bar = syncprogress.SyncProgress(emit)
        bar.at("check")
        be = make()
        akey = syncmarks.account_key(be.acct)
        feed = records.Feed(be.acct, upath, akey)
        stats = {"requests": 0, "open_game": open_game}
        res = []
        first = getattr(svc, "_rec_session", None) != akey
        st = records.state_of(upath, akey)
        if first or st.cursor is None:
            before = yield from _account_state(be)                                           # once a session: the account's documents (the off switch, an old device's writes, a new device's start)
            stats["requests"] += 1
            versions = before[1] if before else {}
            if before:
                svc._rec_listing = (time.time(), before[0], dict(versions))
            if SWITCH_DOC in versions:
                if (yield from _read_switch(be)):
                    svc._records_account_off = True                                          # switched off for the whole account: this device syncs the snapshot way (nothing is lost: the outbox keeps filling)
                    res = yield from _snapshot_steps(svc, be, before, bar, data_dir, device, game_list, None, upath, force)
                    return res
            if st.cursor is None:                                                            # this device's first change-only sync for this account: the documents are the base
                top = records.outbox_top(upath)
                res = yield from _snapshot_steps(svc, be, before, bar, data_dir, device, game_list, None, upath, force, quiet=True, fast_wanted=True)
                ups = [r.get("records_upto") for r in res if not r.get("skipped") and r.get("records_upto") is not None]
                skipped = any(r.get("skipped") for r in res)
                cursor = 0 if (skipped or not ups) else min(ups)                            # everything in the feed after the oldest document's mark comes down (a game skipped by its marks: from the start)
                records.set_cursor(upath, akey, cursor, swept=__import__("cardvault.db", fromlist=["x"]).now_iso(), since=time.time())
                written = {r["game"] for r in res if r.get("game") and not r.get("failed") and not r.get("skipped") and r["game"] not in (getattr(svc, "_lists_wanted", None) or ())}
                records.drop_checkpointed(upath, written, top)                   # what these documents now hold is not sent to the feed as well (the documents are the base: no bulk upload)
                st = records.state_of(upath, akey)
                if sum(r.get("pulled", 0) for r in res):
                    svc.post(lambda s: _apply_pulled(s, res, applied))
        conn = feed.open()
        try:
            st = records.State(conn, akey)
            if first:
                from ..db import now_iso
                swept_at = now_iso()
                records.sweep(conn, st.info.get("swept"))                                  # (the safety net: a change made by a writer without the outbox triggers)
                st.info["swept"] = swept_at
                stats["dev"] = {"version": VERSION, "last_seen": swept_at}
                records.enqueue(conn, "dev", "", device)                                    # (which version each device runs: lets the checkpoints slow down once every device is on 136+)
                st.save()
                conn.commit()
            bar.at("check")
            yield from feed.push_steps(conn, stats, st)
            yield from feed.pull_steps(conn, st, stats)
            _note_devices(svc, akey, stats, conn, st)
        finally:
            conn.close()
        if first:
            svc._rec_session = akey
        svc._sync_verified = True
        tax, items = stats.get("taxonomy", set()), stats.get("items", set())
        res.append({"game": open_game, "records": True, "pulled": stats.get("pulled", 0), "pushed": bool(stats.get("pushed")), "conflicts": 0, "review": stats.get("review", 0),
                    "taxonomy": open_game in tax, "items": sorted(items), "games": sorted(stats.get("games", ())), "requests": stats["requests"], "sent": stats.get("pushed", 0),
                    "bytes_up": stats.get("bytes_up", 0), "account": sorted(stats.get("account", ())), "ckpt": stats.get("ckpt", {}), "future": stats.get("future", [])})
        if stats.get("pulled"):
            svc.post(lambda s: _apply_pulled(s, res, applied, items))
            yield                                                                            # (the screens are told in a piece of their own; the status and settings are saved in the last)
        if manual:
            be2 = make()
            yield from be2.state_steps() if hasattr(be2, "state_steps") else iter(())
            yield from _side_steps(svc, be2, res, None, data_dir, game_list, upath, bar)
        return res

    def done(job):
        STATE["syncing"] = False
        svc._sync_cost = job.busy
        seen = getattr(svc, "_fp_seen", None)
        fp_moved = seen not in (None, svc.cfg.get("_cloud_fp"))
        if job.state == "done":
            svc._synced_upto = started
            svc._unsent_since = svc.last_change if svc.last_change > started else 0.0
            STATE["sync_error"] = ""
            listing = getattr(svc, "_rec_listing", None)
            if seen:
                svc.cfg["_cloud_fp"] = seen                    # the account as the look that started this sync saw it (if this sync sent something the next look finds a difference: one quiet pull)
            elif listing and listing[0] >= started - 1:
                svc.cfg["_cloud_fp"] = listing[1]
            svc._fp_seen = None
            last = (job.result or [{}])[-1]
            _marks_from_announcements(svc, last.get("ckpt") or {})
            _sync_done(svc, job, applied)
            if getattr(svc, "_records_account_off", False):
                pass
            elif manual:
                start_checkpoint(svc, force=True)                 # "Sync now": the documents too, at once
            else:
                if fp_moved and not last.get("pulled") and not last.get("pushed"):
                    svc._ckpt_look = True                         # the account moved but the feed brought nothing: an older device may have saved a document
                _after_sync(svc, job.result, fp_moved, None)
                start_checkpoint(svc)
        else:
            _sync_failed(svc, job)
        if getattr(svc, "_sync_again", False) and job.state == "done":
            svc._sync_again = False
            start_sync(svc, False, publish=False)
        if then is not None:
            then(job)
    return svc.jobs.start("sync", "Syncing", run, on_done=done)


def _read_switch(be):
    """Is the change-only sync switched off for the whole account?  (Unreadable = not off: the snapshot documents are always written as well, so nothing depends on it.)"""
    import json as _json
    try:
        raw, _v = yield from engine._steps(be, "read", SWITCH_DOC)
        return bool(raw) and bool((_json.loads(raw.decode("utf-8")) or {}).get("off"))
    except Exception:  # noqa: BLE001
        return False


def _note_devices(svc, akey, stats, conn, st):
    """Which version each device of the account last ran (the 'dev' records) - kept with the cursor."""
    devs = stats.get("devices") or {}
    if not devs:
        return
    known = st.info.setdefault("devices", {})
    for k, rec in devs.items():
        if isinstance(rec, dict):
            known[k] = {"version": str(rec.get("version") or ""), "last_seen": str(rec.get("last_seen") or "")}
    st.save()
    conn.commit()


def _marks_from_announcements(svc, ckpt):
    """Another device on 136+ wrote a checkpoint and said so in the feed (after everything that is in it): this device already has all of it, so that version need not be downloaded.
    Only the document's version moves in the marks - this device's own stamp stays, so its own changes still go into its next checkpoint."""
    if not ckpt:
        return
    try:
        from . import accountapi
        a = accountapi.account(svc)
        if a is None:
            return
        store = syncmarks.for_account(svc.cfg, a).store
        for game, rec in ckpt.items():
            ver = str((rec or {}).get("version") or "")
            if ver and game in store and len(store[game]) == 2:
                store[game] = [ver, store[game][1]]
    except Exception:  # noqa: BLE001 - a missed shortcut only costs one download
        pass


def _phase_b(svc, st_info):
    """Every device that synced in the last 30 days is on 136+ and no old device saved anything for 30 days: checkpoints slow down to hourly."""
    from ..version import VERSION as V

    def ver(s):
        try:
            return tuple(int(x) for x in str(s).split(".")[:3])
        except ValueError:
            return (0,)
    if time.time() - float(st_info.get("legacy_seen", st_info.get("since", time.time())) or 0) < LEGACY_QUIET:
        return False
    recent = [d for d in (st_info.get("devices") or {}).values() if d.get("last_seen", "") >= (datetime.datetime.utcnow() - datetime.timedelta(days=30)).strftime("%Y-%m-%d")]
    return bool(recent) and all(ver(d.get("version")) >= (3, 50, 136) for d in recent) and ver(V) >= (3, 50, 136)


def _checkpoint_due(svc, force=False):
    """-> (account key, the games changed here since their last checkpoint, look at the documents?) or None when no checkpoint job is needed now."""
    from ..cloud import records
    from . import accountapi
    a = accountapi.account(svc)
    if a is None or svc.session is None:
        return None
    akey = syncmarks.account_key(a)
    st = records.state_of(svc.session.db_path, akey)
    if st.cursor is None:
        return None                                                # (no change-only sync yet: the first sync does the documents)
    every = CHECKPOINT_PHASE_B if _phase_b(svc, st.info) else CHECKPOINT_EVERY
    last = svc.__dict__.setdefault("_ckpt_at", {})
    now = time.time()
    dirty = {g: t for g, t in (st.info.get("dirty") or {}).items() if force or now - last.get(g, 0) >= every}
    asked = bool(getattr(svc, "_ckpt_look", False)) and now - getattr(svc, "_ckpt_looked", 0) >= RECONCILE_GAP
    look = asked or not getattr(svc, "_ckpt_session", False)
    if not (force or dirty or look):
        return None
    return akey, dirty, "asked" if asked else look


def _checkpoint_steps(svc, make, akey, dirty, force, look, game_list, cancel=None):
    """The checkpoint itself (see start_checkpoint).  game_list: games_to_sync, worked out on the engine's thread (it reads the open collection).  -> [per-game results]"""
    from ..cloud import records
    from ..db import now_iso
    upath = svc.session.db_path
    data_dir, device = svc.cfg["data_dir"], engine.device_id(svc.cfg)
    last = svc.__dict__.setdefault("_ckpt_at", {})
    be = make()
    st = records.state_of(upath, akey)
    before = yield from _account_state(be)                         # one look at the documents (versions: what another device saved)
    if before is None:
        return []
    marks = syncmarks.for_account(svc.cfg, be.acct)
    versions = before[1]
    here, wanted = account_games(data_dir, versions, game_list)
    res, wrote, done_games = [], {}, set()

    def theirs(g):                                                 # the document moved since this device last met it, and no 136+ device announced it as a checkpoint of the feed
        v, m = versions.get(engine.data_path("local", g)), marks.store.get(g)
        return bool(v) and (not m or m[0] != str(v))
    stop = lambda: cancel is not None and cancel.is_set()          # (signing out / locking: the collection is about to be put away)
    for g in game_list + here:                                     # (a game whose stamp moved only because the feed brought another device's change is that device's to checkpoint)
        if stop():
            return res
        if not (g in dirty or theirs(g)) or not engine.needs_sync(data_dir, g, marks, versions, False, user_path=upath):
            continue
        r = yield from engine.sync_changed_steps(data_dir, g, be, device, marks, versions, force=False, publish_catalog=False, key=None, user_path=upath, records_upto=st.cursor)
        last[g] = time.time()
        done_games.add(g)
        res.append(r)
        if r.get("pushed"):
            wrote[g] = be.seen.get(engine.data_path("local", g))
        yield
    for g in wanted:                                               # a game whose card list is not here: when its document moved (an older device), or it changed here
        if stop():
            return res
        if not (g in dirty or theirs(g)) or marks.unchanged(g, versions.get(engine.data_path("local", g)), syncmarks.local_stamp(upath, g)):
            continue
        r = yield from engine.sync_records_steps(data_dir, g, be, device, marks, versions, force=False, key=None, user_path=upath, records_upto=st.cursor)
        last[g] = time.time()
        done_games.add(g)
        res.append(r)
        if r.get("pushed"):
            wrote[g] = be.seen.get(engine.data_path("local", g))
        yield
    if wrote:                                                      # "this version is a checkpoint of what is in the feed": the other new devices need not download it
        feed = records.Feed(be.acct, upath, akey)
        rows = [feed.row_for("ckpt", g, "", {"version": str(v), "device": device, "updated_at": now_iso()})[0] for g, v in wrote.items() if v]
        if rows:
            try:
                yield from be.acct.call_steps("POST", "/v1/records", {"rows": rows}, timeout=60, patient=True)
            except Exception:  # noqa: BLE001 - only a shortcut for the others
                pass
    conn = records.open_conn(upath)
    try:
        st2 = records.State(conn, akey)
        d = st2.info.get("dirty") or {}
        for g in done_games | set(dirty):
            if g in d and float(d[g]) <= float(dirty.get(g, d[g])):
                d.pop(g, None)                                     # (checkpointed - unless it changed again meanwhile)
        st2.info["dirty"] = d
        if any(r.get("pulled") for r in res):
            st2.info["legacy_seen"] = time.time()                 # an older device saved something: Phase B waits 30 more days
        st2.save()
        conn.commit()
    finally:
        conn.close()
    return res


def _checkpoint_done(svc, results, look):
    svc._ckpt_session = True
    if look == "asked":                                           # (only a look asked for by "the account moved" counts toward RECONCILE_GAP; the one at the start of a session does not)
        svc._ckpt_look, svc._ckpt_looked = False, time.time()
    if any(not r.get("skipped") for r in results or ()):
        svc.save()
    if any(r.get("pulled") for r in results or ()):
        _apply_pulled(svc, results, {"n": 0})                     # what an older device saved is on the screens, and goes out to the feed with the next sync
        _sync_soon(svc)


def start_checkpoint(svc, force=False):
    """The background CHECKPOINT job (change-only sync on): today's snapshot sync for the games this device changed since their last checkpoint (at most every CHECKPOINT_EVERY seconds
    per game, or at once with force), and for the games whose document another device saved without announcing it in the feed (an older version: what it changed is applied here with
    the outbox on, so it reaches the feed - and every other new device - once).  Each document written says how far into the feed it is (records_upto).  Low priority, never part of
    a sync: a sync never waits for it."""
    if svc.session is None or svc.vault is None or svc.jobs.running("checkpoint") or not records_on(svc) or not svc.pget("sync_enabled", True):
        return None
    target = sync_target(svc)
    if not target or target[1] is not None:
        return None
    due = _checkpoint_due(svc, force)
    if due is None:
        return None
    akey, dirty, look = due
    game_list = games_to_sync(svc)

    def run(emit, cancel):
        return (yield from _checkpoint_steps(svc, target[0], akey, dirty, force, look, game_list, cancel))

    def done(job):
        if job.state == "done":
            _checkpoint_done(svc, job.result, look)
    return svc.jobs.start("checkpoint", "Saving a copy to your account", run, on_done=done, quiet=True)


@api("sync.checkpoint")
def sync_checkpoint(svc):
    """The page is being hidden / closed (the website): every change goes into the documents now, in the background."""
    j = start_checkpoint(svc, force=True) if records_on(svc) else None
    return {"job": j.id if j else None}


def checkpoint_now(svc, on_engine=True):
    """Closing, an update, signing out (the desktop): the documents get every change now, right here (an older version - or a rollback - then has everything)."""
    from ..steps import run as run_steps
    if runtime.INLINE or not records_on(svc) or not svc.pget("sync_enabled", True):
        return
    target = sync_target(svc)
    if not target or target[1] is not None:
        return
    due = _checkpoint_due(svc, True)
    if due is None:
        return
    akey, dirty, look = due
    try:
        game_list = games_to_sync(svc) if on_engine else svc.run(games_to_sync, timeout=30)
        res = run_steps(_checkpoint_steps(svc, target[0], akey, dirty, True, look, game_list))
    except Exception:  # noqa: BLE001 - a courtesy: the change is on this device and in the feed already
        return
    if on_engine:
        _checkpoint_done(svc, res, look)
    else:
        svc.post(lambda s: _checkpoint_done(s, res, look))


def _side_steps(svc, be, res, key, data_dir, game_list, upath, bar):
    """Photos and races, as steps of a "Sync now" (a background sync starts them as jobs of their own: _after_sync)."""
    if hasattr(be, "acct"):
        try:
            from . import races
            yield from races.publish_steps(svc, be.acct)
        except Exception:  # noqa: BLE001 - a race is never allowed to fail the main sync
            pass
    if key is None and hasattr(be, "list_docs"):
        try:
            from .. import photolimit
            res[0]["photos"] = yield from engine.sync_photos_steps(data_dir, game_list[0], be, upath, limit=photolimit.limit_for(svc), progress=bar.photos)
            svc._photos_changed = False
            if res[0]["photos"].get("down") and svc.vault is not None:          # (pictures of your own items that came down: put where the card pictures are)
                from .. import customitems
                customitems.write_pictures(svc.vault)
                svc._exists.clear()
        except Exception as e:  # noqa: BLE001 - photos are never allowed to fail the main sync
            res[0]["photos_error"] = str(e)
        yield


def _after_sync(svc, results, fp_moved, key):
    """A background sync is done: the photos and the races go as jobs of their own (a failure there never fails a sync, and a sync never waits for them)."""
    pulled = sum(r.get("pulled", 0) for r in results or ())
    if key is None and (getattr(svc, "_photos_changed", True) or pulled or fp_moved):
        start_photos(svc)
    start_races(svc)


def start_photos(svc):
    """Copy photos: their own low-priority job (they used to ride in the sync job: 500 photos on a fresh device = 500 round trips before the sync said it was done)."""
    if svc.session is None or svc.vault is None or svc.jobs.running("photos") or not svc.pget("sync_enabled", True):
        return None
    target = sync_target(svc)
    if not target or target[1] is not None:
        return None
    make, upath, data_dir, game = target[0], svc.session.db_path, svc.cfg["data_dir"], svc.vault.game

    def run(emit, cancel):
        from .. import photolimit
        be = make()
        if hasattr(be, "state_steps"):
            yield from be.state_steps()                            # (the listing the photo step compares with)
        return (yield from engine.sync_photos_steps(data_dir, game, be, upath, limit=photolimit.limit_for(svc)))

    def done(job):
        if job.state == "done":
            svc._photos_changed = False
            if (job.result or {}).get("down") and svc.vault is not None:
                from .. import customitems
                customitems.write_pictures(svc.vault)
                svc._exists.clear()
                svc.bump("sync")
    return svc.jobs.start("photos", "Syncing photos", run, on_done=done, quiet=True)


def start_races(svc):
    """Checklist races: my progress row goes out as a small job of its own (races.py) - only when there is a race."""
    from . import accountapi, races
    if svc.session is None or svc.jobs.running("races"):
        return None
    try:
        if not races._races(svc):
            return None
    except Exception:  # noqa: BLE001
        return None
    a = accountapi.account(svc)
    if a is None:
        return None

    def run(emit, cancel):
        yield from races.publish_steps(svc, a)
        return {}
    return svc.jobs.start("races", "Race progress", run, quiet=True)


def start_publish(svc, games_done):
    """GitHub mode: the phone's card list of each synced game, as a job of its own - at most once a day per game, and compared with what this device last published (no download first)."""
    if not games_done or svc.jobs.running("publish"):
        return None
    target = sync_target(svc)
    if not target or not target[2]:
        return None
    make, key = target[0], target[1]
    data_dir, upath = svc.cfg["data_dir"], svc.session.db_path if svc.session is not None else None
    published = svc.cfg.setdefault("_published", {})
    due = [g for g in games_done if time.time() - float((published.get(g) or {}).get("at", 0)) >= 86400]
    if not due:
        return None

    def run(emit, cancel):
        import gzip
        import hashlib
        import json as _json
        from ..db import Vault
        be, out = make(), {}
        for g in due:
            if not os.path.exists(os.path.join(game_dir(data_dir, g), "cards.db")):
                continue
            v = Vault(data_dir, g, "local", user_path=upath)
            try:
                if not v.card_count():
                    continue
                data = gzip.compress(_json.dumps(engine.build_catalog(v), ensure_ascii=False, separators=(",", ":")).encode("utf-8"), 9, mtime=0)
            finally:
                v.close()
            path = f"catalog/{g}.json.gz"
            data = e2e.wrap(key, data, path) if key else data
            dg = hashlib.sha1(data).hexdigest()
            mine = published.get(g) or {}
            if mine.get("digest") == dg:
                out[g] = "unchanged"
            else:
                etag = mine.get("etag")
                if not etag:
                    _raw, etag = be.read(path)                    # (only the first time: after that the version written here is kept)
                try:
                    etag = be.write(path, data, etag, f"Card list for {g}")
                except cloud_backend.Conflict:
                    _raw, etag = be.read(path)
                    etag = be.write(path, data, etag, f"Card list for {g}")
                out[g] = f"published {len(data) // 1024} KB"
            published[g] = {"digest": dg, "etag": etag or mine.get("etag"), "at": time.time()}
            yield
        return out
    return svc.jobs.start("publish", "Publishing the card list", run, on_done=lambda job: svc.save(), quiet=True)


def _apply_pulled(svc, results, applied, items=()):
    """What the sync brought down is written: make every screen show it.  (Engine thread.)  Done as soon as the games are merged, once per sync."""
    if applied["n"]:
        return
    pulled = sum(r.get("pulled", 0) for r in results)
    applied["n"] = pulled
    svc._me_cache = None                        # a username changed on another device shows here at the next look, not minutes later
    if svc.vault is not None:
        if svc.vault.game in (items or ()):
            from .. import customitems
            customitems.materialize(svc.vault)  # (your own items that arrived through the feed: their cards in the open game's list)
        if any(r.get("taxonomy") for r in results):
            svc.vault.invalidate_index()        # a correction or a category of yours arrived: which groups cards belong to has to be worked out again
            svc.vault._register_taxonomy()
        else:
            svc.vault._cl_rev += 1              # copies, wishlists, lists... changed: the checklist counts are counted again; the card index itself is untouched
        svc.pulled_rev += 1                     # every answer kept about the collection (portfolio counts, Home, checklists) is worked out again - see Service.data_mark
        svc.reload_state()
    try:
        if svc.session is not None and not runtime.INLINE:
            svc.session.persist()               # what arrived from your other devices is kept on this one right away (the website's page saves after every answer it hands in: not twice, not inside a piece)
    except Exception:  # noqa: BLE001
        pass
    svc.bump("synced", pulled=pulled)


def account_games(data_dir, versions, game_list):
    """The games the account holds a record for, beyond `game_list`.  -> (games whose card list is on this device: synced now,
    games whose card list is not: looked at after this sync and their lists fetched when there is something in them - see _get_lists)."""
    from .. import games
    here, wanted = [], []
    for name in sorted(versions or {}):
        if not (name.startswith("users/local/") and name.endswith(".json") and name.count("/") == 2):
            continue
        g = name[len("users/local/"):-5]
        if g in game_list:
            continue
        try:
            ok = games.game_by_id(g).id == g and games.game_by_id(g).available
        except Exception:  # noqa: BLE001 - a game this version does not know
            ok = False
        if ok:
            (here if os.path.exists(os.path.join(game_dir(data_dir, g), "cards.db")) else wanted).append(g)
    return here, wanted


def _lists_candidates(svc):
    """Account games whose card list is not on this device: the ones the documents named, plus the ones the feed brought records of."""
    from .. import games
    out = set(getattr(svc, "_lists_wanted", None) or [])
    if svc.session is not None and records_on(svc):
        from ..cloud import records
        try:
            conn = records.open_conn(svc.session.db_path)
            try:
                have = records.games_with_items(conn)
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            have = set()
        for g in have:
            try:
                ok = games.game_by_id(g).id == g and games.game_by_id(g).available
            except Exception:  # noqa: BLE001
                ok = False
            if ok and not os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g), "cards.db")):
                out.add(g)
    return sorted(out)


def _get_lists(svc):
    """After a sync: the account has records of a game whose card list is not on this device.  Only the games flagged "Keep for offline use" (gamesapi.offline_on: the desktop keeps
    every list, the website none by default) get their list, one after another in the background; a game that is not flagged shows its collection from the records that came down and
    gets its list when it is opened.  Whether a game holds anything comes from this device's own tables (what the feed / the documents brought), never from downloading its document."""
    from . import gamesapi
    tried = getattr(svc, "_lists_tried", set())
    wanted = [g for g in _lists_candidates(svc) if g not in tried]
    if not wanted:
        return
    try:
        wanted = [g for g in wanted if gamesapi.offline_on(svc, g)]
    except Exception:  # noqa: BLE001
        return
    if not wanted:
        return
    if not sync_target(svc):
        return
    svc._lists_tried = tried | set(wanted)
    upath = svc.session.db_path if svc.session is not None else None
    have = set()
    if upath:
        from ..cloud import records
        conn = records.open_conn(upath)
        try:
            have = records.games_with_items(conn)
        finally:
            conn.close()
    _next_list(svc, [g for g in wanted if g in have])          # (an empty record of a game opened once is not worth a big download)


def _has_items(raw, key, path):
    import json
    try:
        snap = json.loads((e2e.unwrap(key, raw, path) if key else raw).decode("utf-8"))
    except Exception:  # noqa: BLE001
        return False
    live = lambda rows: any(isinstance(r, dict) and not r.get("deleted") for r in (rows or []))
    return any(live(snap.get(k)) for k in ("lots", "wishlist", "checklists", "sealed"))


def _next_list(svc, todo):
    """Fetch the next game's card list; when it is in, sync (its collection comes down) and go on to the next."""
    from . import gamesapi
    while todo:
        g = todo.pop(0)
        try:
            jid = gamesapi.ensure_job(svc, g, after=lambda ok: ((_sync_soon(svc) if ok and not records_on(svc) else None), _next_list(svc, todo)))
        except Exception:  # noqa: BLE001
            jid = None
        if jid is not None:
            return                                # the next one starts when this one is done


def _sync_soon(svc):
    """Sync now - or, when one is running, straight after it (it may have started before the new card list was in)."""
    if svc.jobs.running("sync"):
        svc._sync_again = True
    else:
        start_sync(svc, False, publish=False)


@api("sync.check", quiet=True)
def sync_check(svc, fp=""):
    """Called when the app comes back into view, and by the website's page-side poll (which hands in the account's current fingerprint `fp`, so no round trip is needed here):
    if another device changed something, fetch it now."""
    from . import accountapi
    if svc.session is None or not svc.pget("cloud_token"):
        return {"started": False}
    if not svc.pget("sync_enabled", True):
        return {"started": False, "off": True}          # cloud saving switched off: no look at the account at all (the website's poll used to ask it every few seconds)
    if fp and fp == svc.cfg.get("_cloud_fp"):
        return {"started": False, "upToDate": True}
    if svc.jobs.running("sync"):
        return {"started": False}
    svc._sync_backoff = 0
    if fp:
        svc._fp_seen = fp
        return {"started": cloudapi_start(svc) is not None}
    w = accountapi.watch(svc)
    if w["changed"]:
        svc._fp_seen = w.get("fp")
        return {"started": cloudapi_start(svc) is not None}
    return {"started": False, "upToDate": True}


def cloudapi_start(svc):
    return start_sync(svc, False, publish=False)


@api("sync.now")
def sync_now(svc, manual=True):
    j = start_sync(svc, manual)
    return {"job": j.id if j else None}


@api("sync.records")
def sync_records(svc, device=None, account=None):
    """The change-only sync's two off switches (Settings > Cloud saving, hidden): `device` for this device, `account` for every device of the account (a sealed document every
    136+ device reads at the start of a session).  Off = the snapshot sync of 3.50.135; nothing is lost either way (the outbox keeps filling and goes out when it is back on)."""
    if device is not None:
        svc.pset("sync_records", None if device else False)
    if account is not None:
        from . import accountapi
        from ..cloud import skycloud
        a = accountapi.account(svc, True)
        import json as _json
        be = skycloud.SkyCloudBackend(a)
        _raw, ver = be.read(SWITCH_DOC)
        be.write(SWITCH_DOC, _json.dumps({"v": 1, "off": not account}).encode("utf-8"), ver)
        svc._records_account_off = not account
        svc._rec_session = None
    from ..cloud import records
    st = {}
    if svc.session is not None:
        try:
            from . import accountapi
            a = accountapi.account(svc)
            st = records.state_of(svc.session.db_path, syncmarks.account_key(a)).__dict__ if a else {}
        except Exception:  # noqa: BLE001
            st = {}
    return {"device": svc.pget("sync_records") is not False, "account": not getattr(svc, "_records_account_off", False), "on": records_on(svc),
            "cursor": st.get("cursor"), "clockOffsetMin": round(__import__("cardvault.db", fromlist=["x"]).hlc_offset() / 60.0, 1)}


def flush_sync(svc):
    """Last chance on exit: push unsynced changes (quick, errors ignored).  With the change-only sync: the outbox goes out, then the open game's document is checkpointed."""
    if not svc.pget("sync_enabled", True):
        return
    target = sync_target(svc)
    if not target:
        return
    try:
        make, key, _can = target
        upath = svc.session.db_path if svc.session is not None else None
        if key is None and upath and records_on(svc):
            from ..cloud import records
            from ..steps import run as run_steps
            be = make()
            feed = records.Feed(be.acct, upath, syncmarks.account_key(be.acct))
            conn = feed.open()
            try:
                run_steps(feed.push_steps(conn, {}))
            finally:
                conn.close()
            checkpoint_now(svc)                         # (every game changed here since its last checkpoint; nothing at all when there is none)
            return
        engine.sync_game(svc.cfg["data_dir"], svc.vault.game, make(), engine.device_id(svc.cfg), publish_catalog=False, key=key,
                         user_path=upath)
    except Exception:  # noqa: BLE001
        pass


# ------------------------------------------------------------------------------------------------ backups
@api("backups.list")
def backups_list(svc):
    v = svc.vault
    return {"files": [{"path": f, "name": os.path.basename(f).replace("collection-", "").replace(".db", "")} for f in v.list_backups()], "dir": svc.pget("backup_dir") or ""}


@api("backups.now")
def backups_now(svc):
    return {"path": svc.vault.backup_now("manual", svc.pget("backup_dir"))}


@api("backups.setFolder", mutates=True)
def backups_folder(svc, path=""):
    if path:
        svc.need_grant(path)
    svc.pset("backup_dir", path or None)
    return {"ok": True}


@api("backups.restore", mutates=True)
def backups_restore(svc, path):
    allowed = {os.path.normcase(os.path.abspath(f)) for f in svc.vault.list_backups()}
    if os.path.normcase(os.path.abspath(path)) not in allowed:
        raise ApiError("That is not one of this account's backups.")
    svc.vault.restore_collection(path)
    svc.vault.invalidate_index()
    svc.reload_state()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ data in / out
@api("data.exportCsv")
def export_csv(svc, path):
    svc.need_grant(path)
    svc.audit("export", "collection CSV")
    return {"lines": svc.vault.export_csv(path)}


@api("data.importCsv", mutates=True)
def import_csv(svc, path):
    svc.need_grant(path)
    try:
        added, skipped = svc.vault.import_csv(path)
    except (OSError, ValueError, KeyError) as e:
        raise ApiError("That file couldn't be read. Check that it's the right kind of file and try again.")
    svc.reload_state()
    return {"added": added, "skipped": skipped}


def _import_sources(svc, r):
    """The portfolios (categories) the file talks about, with how much is in each and where it would go by default: a portfolio of the same name here if there is one, else a new one."""
    pfs = svc.vault.portfolios()
    out = {}
    for x in r["rows"]:
        k = (x.get("portfolio") or "").strip()
        d = out.setdefault(k, {"name": k, "cards": 0, "copies": 0, "sealed": 0, "wish": 0})
        if x.get("wish"):
            d["wish"] += 1
        else:
            d["cards"] += 1
            d["copies"] += x["qty"]
    for x in r["sealed"]:
        k = (x.get("portfolio") or "").strip()
        d = out.setdefault(k, {"name": k, "cards": 0, "copies": 0, "sealed": 0, "wish": 0})
        d["sealed"] += x["qty"]
    res = []
    for k, d in sorted(out.items(), key=lambda kv: (kv[0] == "", kv[0].lower())):
        uid, how = importers.best_portfolio(k, pfs)                                                                # the same name, or a close one ('Binders 1' = 'Binder 1')
        d["dest"] = "main" if k.lower() == "main" else (uid or ("new" if k else ""))                              # "" = lines with no portfolio: they go to the one you are looking at
        d["how"] = "" if k.lower() == "main" else how or ("new" if k else "")
        d["matchName"] = next((p["name"] for p in pfs if p["uuid"] == uid), "") if uid else ""
        res.append(d)
    return res


@api("import.read")
def import_read(svc, path):
    svc.need_grant(path)
    try:
        r = importers.read_rows(path, svc.vault)
    except (OSError, ValueError, UnicodeDecodeError, KeyError) as e:
        raise ApiError("That file couldn't be read. Check that it's the right kind of file and try again.")
    from . import resetimport
    v = svc.vault
    matches = []
    lights = v.card_lights([x["card_id"] for x in r["rows"][:5000]])            # (no need to wait for the whole card index for a name and a number)
    for i, x in enumerate(r["rows"][:5000]):
        c = lights.get(x["card_id"]) or {}
        matches.append({"i": i, "source": x["label"], "name": c.get("name", x["card_id"]), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "qty": x["qty"], "variant": x.get("variant") or "",
                        "condition": "Graded" if x.get("graded") else x.get("condition") or "", "paid": x.get("paid"), "portfolio": x.get("portfolio") or "", "wish": bool(x.get("wish"))})
    dest = [{"id": p["id"], "name": p["name"], "accepts": p.get("accepts") or "all"} for p in __import__("cardvault.webapi.portfolios", fromlist=["x"]).pf_list(svc)["portfolios"]]
    return {"already": resetimport.already_imported(svc, path), "format": r["format"], "columns": r["columns"], "matched": len(r["rows"]) + len(r["sealed"]),
            "copies": sum(x["qty"] for x in r["rows"] if not x.get("wish")) + sum(x["qty"] for x in r["sealed"]),
            "sealed": len(r["sealed"]), "wishlist": sum(1 for x in r["rows"] if x.get("wish")), "cards": sum(1 for x in r["rows"] if not x.get("wish")),
            "portfolios": sorted({x["portfolio"] for x in r["rows"] + r["sealed"] if x.get("portfolio")}), "sources": _import_sources(svc, r), "destinations": dest,
            "matches": matches, "matchesShown": len(matches),
            "others": [{"id": g, "name": next((x.name for x in __import__("cardvault.games", fromlist=["x"]).GAMES if x.id == g), g), "n": n} for g, n in (r.get("others") or {}).items()],
            "unmatched": [[a, b] for a, b in r["unmatched"]], "unmatchedCount": len(r["unmatched"]),
            "unmatchedRows": [{"i": i, "label": a, "why": b, "fixable": r["unmatched_raw"][i] is not None} for i, (a, b) in enumerate(r["unmatched"])],
            "review": [{"i": i, "label": x["label"], "why": x["why"], "qty": x["qty"], "options": x["options"]} for i, x in enumerate(r["review"])], "reviewCount": len(r["review"])}


@api("import.run", mutates=True)
def import_run(svc, path, choices=None, again=False, portfolio_map=None, overrides=None, include=None):
    """Import the file.
    choices        {review row number: card id} and {'u<number>': card id} - lines that were not matched, which the person matched by hand (lines not chosen are left out)
    overrides      {matched row number: card id | 'skip'} - change what a matched line became, or leave it out
    portfolio_map  {name in the file: 'skip' | 'main' | an existing portfolio's id | 'new'} - where each portfolio of the file goes (default: the same name here, made if missing)
    include        {cards, sealed, wishlist} - what kinds of lines to bring in (all by default)
    again          import a file that was already imported (it doubles the copies)."""
    svc.need_grant(path)
    from . import resetimport
    dup = resetimport.already_imported(svc, path)
    if dup and not again:
        raise ApiError(f"This exact file was already imported on {dup['ts'][:10]}. Importing it again would double every copy - take that import back first (Settings > Import history), or choose to import it again anyway.", code="already_imported")
    v = svc.vault
    r = importers.read_rows(path, v)
    rows = []
    for i, x in enumerate(r["rows"]):
        o = (overrides or {}).get(str(i), (overrides or {}).get(i))
        if o == "skip":
            continue
        if o:
            if not v.card_basic(o):
                raise ApiError("One of the cards you picked isn't in this game's list.")
            x = {**x, "card_id": o}
        rows.append(x)
    for key, cid in (choices or {}).items():
        if not cid:
            continue
        k = str(key)
        if k.startswith("u"):                                              # a line that matched nothing, fixed by picking its card
            i = int(k[1:])
            raw = r["unmatched_raw"][i] if 0 <= i < len(r["unmatched_raw"]) else None
            if raw is not None and v.card_basic(cid):
                rows.append(importers.row_for(raw, r["_cols"], cid, v))
        else:
            i = int(k)
            if 0 <= i < len(r["review"]) and any(o["id"] == cid for o in r["review"][i]["options"]):
                rows.append(importers.row_for(r["review"][i]["raw"], r["_cols"], cid, v))
    inc = {"cards": True, "sealed": True, "wishlist": True, **(include or {})}
    rows = [x for x in rows if (inc["wishlist"] if x.get("wish") else inc["cards"])]
    sealed = list(r["sealed"]) if inc["sealed"] else []
    before = {p["uuid"] for p in v.portfolios()}
    track = {}
    try:
        n, act = importers.import_rows(v, rows, f"Imported from {r['format']}", sealed, track, portfolio_map or {})
    except ValueError as e:
        raise ApiError(str(e))
    track["portfolios"] = [p["uuid"] for p in v.portfolios() if p["uuid"] not in before]
    resetimport.remember_import(svc, f"{r['format']} import ({n} copies)", track, resetimport.file_sha(path))
    svc.reload_state()
    return {"copies": n, "skipped": len(r["rows"]) + len(r["sealed"]) - len(rows) - len(sealed), "undo": {"id": act.id, "label": f"Imported {n} copies"}}


@api("import.exportUnmatched")
def import_export_unmatched(svc, path, out):
    """Save the lines of the file that could not be matched to a card (with the reason) as a spreadsheet, so they can be fixed there and imported again."""
    import csv
    svc.need_grant(path)
    svc.need_grant(out)
    r = importers.read_rows(path, svc.vault)
    rows = [(raw, why) for (label, why), raw in zip(r["unmatched"], r["unmatched_raw"])]
    if not rows:
        raise ApiError("Everything in that file matched - nothing to save.")
    cols = []
    for raw, _ in rows:
        for k in (raw or {}):
            if k not in cols:
                cols.append(k)
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(cols + ["why it did not match"])
        for (label, why), raw in zip(r["unmatched"], r["unmatched_raw"]):
            w.writerow(([raw.get(c, "") for c in cols] if raw else [label] + [""] * (len(cols) - 1)) + [why])
    return {"lines": len(rows)}


DEVICE_PREFIX = "CVL1-"


def device_code(svc):
    """Everything a new device needs to join this account's sync in one code: the private repository, its sign-in token and the sync key."""
    import base64
    import json as _json
    tok, _src = token(svc)
    body = _json.dumps({"r": svc.pget("sync_repo") or updater.DATA_REPO, "t": tok, "k": e2e.to_code(sync_key(svc, create=True))}, separators=(",", ":"))
    return DEVICE_PREFIX + base64.b32encode(body.encode("utf-8")).decode("ascii").rstrip("=")


def read_device_code(code):
    import base64
    import json as _json
    raw = "".join(ch for ch in code.strip().upper() if ch.isalnum())[len("CVL1"):]
    try:
        data = _json.loads(base64.b32decode(raw + "=" * (-len(raw) % 8)).decode("utf-8"))
        e2e.from_code(data["k"])
        return data
    except (ValueError, KeyError, TypeError, e2e.SyncKeyError):
        raise ApiError("That link code isn't right. Copy the whole code and try again.")


@api("cloud.linkCode")
def link_code(svc, password, full=False):
    """The sync key as a code to type into the phone.  Needs the account password again - it unlocks everything that was synced.
    full=True adds the repository and GitHub sign-in, so a brand-new device only needs this one code."""
    from ..security.profiles import AuthError
    try:
        svc.auth.verify_password(svc.session.pid, password, count=True)
    except AuthError as e:
        raise ApiError(str(e), code=e.code, retry_after=getattr(e, "retry_after", 0))
    svc.session.log_event("sync_key_shown")
    return {"code": device_code(svc) if full else e2e.to_code(sync_key(svc, create=True))}


@api("cloud.setLinkCode", mutates=True)
def set_link_code(svc, code):
    """Use the sync key made on another device (so this one can read what it synced).  A full link code also sets the repository and sign-in."""
    svc.audit("device_linked", "link code used")
    if code.strip().upper().startswith("CVL1"):
        data = read_device_code(code)
        svc.pset("sync_key", data["k"])
        if data.get("r"):
            svc.pset("sync_repo", data["r"])
        if data.get("t"):
            svc.pset("github_token", data["t"])
        svc.pset("sync_enabled", True)
        return {"ok": True, "full": True}
    try:
        key = e2e.from_code(code)
    except e2e.SyncKeyError as e:
        raise ApiError(str(e))
    svc.pset("sync_key", e2e.to_code(key))
    return {"ok": True}
