"""The boxes screen of Find & Add ("Browse by"): a game's sets, or its cards grouped one way - rarity, card type, colour, blade, season, trait ... - illustrators, or Pokémon by Pokédex number.

modes(svc, edition)   the ways THIS game can be browsed (worked out from the card list alone, so the first screen never waits for the whole card index)
overview(...)         the boxes of one way, with the person's progress in each, the picture that stands for it, and the search / progress / sort asked for
"""
import re

from .. import checklists, completion, gamefacets, pricepick, runtime, setgoals, taxonomy
from . import filtercache
from .cards import GENERATIONS, img
from .registry import api

SPECIAL_FROM = "2026-10-01"          # a Pokémon set dated from here on is only the placeholder of a special group (Alternate Art Promos ...), see _is_special


# ---------------------------------------------------------------------------------------------------------------- small helpers
def group_section(g):
    if g.id in ("art", "ir", "sir", "gallery", "tg", "gg", "art_alt", "altart"):
        return "art"
    return g.parent or "art"


def frac(box):
    return (box["owned"] / box["total"]) if box["total"] else 0


def by_id_price(v, cid):
    c = v._index_by_id.get(cid) if getattr(v, "_index_by_id", None) else None
    return pricepick.price_for(v, cid, (c or {}).get("price_usd")) or 0          # the price Settings > Price sources picks


def _by_set(v):
    """The card list grouped by set (kept until the card list changes)."""
    idx = v.card_index()
    hit = getattr(v, "_by_set_cache", None)
    if hit and hit[0] is idx:
        return hit[1]
    out = {}
    for c in idx:
        out.setdefault(c["set_id"], []).append(c)
    v._by_set_cache = (idx, out)
    return out


def _era_date(label):
    """A date to sort an era box by: the END of the years in its name ('Black & White (2011-2013)' -> 2013-12-31).  Open-ended or 'any year' sort by their own rules."""
    years = re.findall(r"(\d{4})", label or "")
    return f"{years[-1]}-12-31" if years else "0001-01-01"


def _is_special(g, s):
    """A real set filed in its series (Delta Reign, Mega Evolution, 2026-11-06) is a set, however new: only a set with no series of its own is a special group's placeholder."""
    return g.pokemon and (s["serie"] == "Miscellaneous" or ((s["release_date"] or "") >= SPECIAL_FROM and not s["serie"]))


class Ask:
    """What one request for boxes asks: the game, the text typed, which progress to show, and what the person owns."""

    def __init__(self, svc, edition, q, status):
        self.svc, self.v, self.g, self.owned = svc, svc.vault, svc.game, svc.owned
        self.edition, self.q, self.status = edition, (q or "").strip().lower(), status
        self.voc = gamefacets.vocab(self.g.id)

    def keeps(self, owned, total):
        """Does a box with this much done pass the progress filter (In progress / Complete / Not started)?"""
        if self.status == "progress":
            return 0 < owned < total
        if self.status == "complete":
            return bool(total) and owned >= total
        if self.status == "none":
            return owned == 0
        return True

    def owned_in(self, ids):
        return sum(1 for i in ids if self.owned.get(i, 0) > 0)

    def cover(self, ids):
        """The picture of the most striking card among these (or '')."""
        top = self.v.best_card(ids)
        return img(top["id"], top["set_id"]) if top else ""


# ---------------------------------------------------------------------------------------------------------------- the ways to browse
def _grouping_modes(v, g, voc):
    """One way per grouping the game has - rarity, card type, colour / attribute and its own filters - each only when there are at least three things to choose from."""
    scan = lambda c: [r[0] for r in v.conn.execute(f"SELECT DISTINCT {c} FROM cards WHERE {c} IS NOT NULL AND {c}!=''")]
    cols = filtercache.kept(v, "browse_columns", lambda: {c: scan(c) for c in ("types", "rarity", "category")})          # (three scans of the whole list: kept between sessions)
    types = sorted({p.strip() for t in cols["types"] for p in str(t).split(",") if p.strip()})
    rarities, categories, colours = gamefacets.dimension_values(g.id, cols["rarity"], cols["category"], types)                  # (the same rule that makes the groups themselves)
    label = lambda t: str(t)[:1].upper() + str(t)[1:]
    out = []
    if len(rarities) >= 3:
        out.append(["sec:rarity", voc["rarityLabel"]])
    if len(categories) >= 3:
        out.append(["sec:ctype", "Card type"])
    if len(colours) >= 3:
        out.append(["sec:color", label(g.type_label)])
    for d in gamefacets.values(v.conn, g.id):
        if d["key"] in gamefacets.SET_FACETS.get(g.id, ()):
            continue                                                       # (it is the sets again)
        if sum(1 for x in d["values"] if x["v"] != "Regular") >= 3:        # (a two-way choice - in stock / sold out - is a filter, not a way to browse)
            out.append(["sec:f_" + d["key"], label(d["label"])])
    if v.custom_groups():
        out.append(["sec:custom", "My categories"])
    return out


def _build_modes(v, g):
    voc = gamefacets.vocab(g.id)
    modes = [["sets", voc["setLabel"]]]
    modes += [["cats", "Rarities"]] if g.pokemon else _grouping_modes(v, g, voc)
    if filtercache.kept(v, "has_artist", lambda: bool(v.conn.execute("SELECT 1 FROM cards WHERE illustrator IS NOT NULL AND illustrator NOT IN ('', 'None', 'N/A') LIMIT 1").fetchone())):   # (a list without any reads all of it)
        modes.append(["ill", "Illustrators"])
    if g.pokemon:
        modes.append(["mon", "Pokémon"])
    return modes


def modes(svc, edition):
    """The ways THIS game can be browsed as boxes: [[mode key, label]] - sets (called what the game calls them), one entry for every way the game groups its cards, illustrators and Pokémon where it has them.
    Never a way that has nothing to choose from.  Worked out from the card list alone (a few queries), NOT from the whole card index: the first screen must not wait for that."""
    v = svc.vault
    key = v.catalog_fp()
    hit = getattr(v, "_modes_cache", None)
    if hit is None or key is None or hit[0] != key:
        hit = v._modes_cache = (key, {})
    if edition not in hit[1]:
        hit[1][edition] = _build_modes(v, svc.game)
    return hit[1][edition]


# ---------------------------------------------------------------------------------------------------------------- how far the person is in each set (counted by cardvault/completion.py)


# ---------------------------------------------------------------------------------------------------------------- the boxes of a game's sets
class _SetFacts:
    """The per-set numbers one screen of set boxes needs, read once: what each set holds and is worth, what the person owns, and (Pokémon) the special groups' cards."""

    def __init__(self, ask, level, patterns):
        v, svc = ask.v, ask.svc
        self.owned = v.owned_by_set()
        pick = pricepick.sql(v)                                                                      # the price every total uses (Settings > Price sources)
        sums = lambda: [list(r) for r in v.conn.execute(f"SELECT c.set_id, SUM({pick}), COUNT({pick}) FROM cards c GROUP BY c.set_id")]
        worth = filtercache.kept(v, "set_values", sums) if pick == "c.price_usd" else sums()         # (kept between sessions only for the standard price)
        self.values = {r[0]: (r[1] or 0.0, r[2]) for r in worth}                                   # what each whole set is worth (the card list alone: kept between sessions)
        self.own_value = {r[0]: r[1] or 0.0 for r in v.conn.execute(
            f"SELECT c.set_id, SUM(l.qty * {pricepick.sql(v, lot='l')}) FROM cards c JOIN lots_s l ON l.card_id=c.id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY c.set_id", (v.user_id, v.game))}
        self.goals = {sid: completion.clamp(g, ask.g, level) for sid, g in setgoals.load(v).items()}      # the goal picked for each set; the page's own choice (`level`) stands for the others
        self.default = completion.clamp(level, ask.g)
        self.levels = {g: completion.counts(svc, g, patterns) for g in {self.default, *self.goals.values()}}
        self.eras = {gr.id: gr.label for gr in taxonomy.groups() if gr.parent == "era"} if ask.g.pokemon else {}
        self.cards_of = _by_set(v) if self.eras else {}


class _HiddenKinds:
    """The groups of 'not a real set' cards the person switched off (Extras): which sets they hide.  Searching for a set by name still finds it."""

    def __init__(self, svc, mode, q):
        from .setkinds_api import hidden_kinds, kind_map
        self.kinds = hidden_kinds(svc) if mode == "sets" else set()
        self.kind_of = kind_map(svc) if self.kinds else {}
        self.sets, self.q = [], q

    def hides(self, set_id):
        if self.kinds and not self.q and self.kind_of.get(str(set_id)) in self.kinds:
            self.sets.append(set_id)
            return True
        return False

    def summary(self):
        return {"sets": len(self.sets), "kinds": sorted({self.kind_of[str(i)] for i in self.sets})} if self.sets else None


def _set_box(svc, facts, s, owned, total):
    year = (s["release_date"] or "")[:4]
    value, priced = facts.values.get(s["id"], (0, 0))
    return {"key": s["id"], "kind": "set", "title": s["name"], "sub": f"{s['serie'] or ''}{' · ' + year if year else ''}", "owned": owned, "total": total,
            "value": round(value, 2), "priced": priced, "ownedValue": round(facts.own_value.get(s["id"], 0.0), 2),
            "logo": svc.logo_url(s["id"], s), "symbol": svc.symbol_url(s["id"], s), "date": (s["release_date"] or "")[:10]}


def _special_boxes(ask, facts, s):
    """A special group (Alternate Art Promos, Burger King Promos...) holds cards from many years: one box per era, never one made-up year.  -> [(box, the date to sort it by)]"""
    v, svc = ask.v, ask.svc
    parts = {}
    for c in facts.cards_of[s["id"]]:
        era = next((x for x in (c.get("groups") or []) if x in facts.eras and x != "e_pre_swsh"), "e_misc")
        parts.setdefault(era, []).append(c["id"])
    out = []
    for era, ids in sorted(parts.items(), key=lambda kv: list(facts.eras).index(kv[0]) if kv[0] in facts.eras else 99):
        owned = ask.owned_in(ids)
        if not ask.keeps(owned, len(ids)):
            continue
        label = facts.eras.get(era, "Other years")
        box = {"key": s["id"], "kind": "set", "era": era, "title": f"{s['name']} · {label}" if len(parts) > 1 else s["name"], "sub": f"{label} · various years", "owned": owned, "total": len(ids),
               "value": round(sum(by_id_price(v, i) for i in ids), 2), "priced": sum(1 for i in ids if by_id_price(v, i)), "logo": svc.logo_url(s["id"], s), "symbol": svc.symbol_url(s["id"], s)}
        out.append((box, _era_date(label)))
    return out


def _boxes_of_set(ask, facts, s):
    """The box (or, for a special group, the boxes) of one set that passes the search and progress filters.  -> [(box, the date to sort it by)]"""
    goal = facts.goals.get(s["id"], facts.default)
    owned, total = facts.levels[goal].get(s["id"]) or (facts.owned.get(s["id"], 0), s["n"] or 0)        # progress at this set's goal: standard / master / extra
    if not ask.keeps(owned, total):
        return []
    special = _is_special(ask.g, s)
    if special and facts.cards_of.get(s["id"]):
        return _special_boxes(ask, facts, s)
    box = _set_box(ask.svc, facts, s, owned, total)
    box["goal"], box["goalName"] = goal, completion.LABELS[goal]
    box["goals"] = list(completion.allowed(ask.g))                              # (a game with one goal shows no tag to change)
    box["goalPicked"] = s["id"] in facts.goals
    if special:
        box["sub"] = f"{s['serie'] or ''} · various years"
    return [(box, "0001-01-01" if special else (s["release_date"] or ""))]


def _sort_sets(items, sort):
    """items = [(box, date, set name)]: newest / oldest first (a special group's era boxes sort by the ERA they show, so older eras sit with the older sets), by name, or by progress / size."""
    key = {"new": lambda t: (t[1], t[2]), "old": lambda t: (t[1], t[2]), "name": lambda t: t[2].lower(), "most": lambda t: -frac(t[0]), "least": lambda t: frac(t[0]), "big": lambda t: -t[0]["total"]}.get(sort)
    if key:
        items.sort(key=key, reverse=(sort == "new"))
        if sort in ("new", "old"):
            items.sort(key=lambda t: not t[1])                          # (a set with no known date goes last, newest or oldest first - the sort is stable)
    return [box for box, _when, _name in items]


def _sets_boxes(ask, era, sort, level, patterns):
    """-> (boxes, the series to pick from, what Extras hid)"""
    v = ask.v
    hidden = _HiddenKinds(ask.svc, "sets", ask.q)
    facts = _SetFacts(ask, level, patterns)
    sets = v.sets(ask.edition)
    series = list(dict.fromkeys(s["serie"] for s in sets if s["serie"]))
    items = []
    for s in sets:
        if era and s["serie"] != era:
            continue
        if ask.q and ask.q not in s["name"].lower() and ask.q not in s["id"].lower():
            continue
        if s["id"] not in facts.values:                                       # a set the card list has no cards for: nothing to show or collect
            continue
        if hidden.hides(s["id"]):
            continue
        items += [(box, when, s["name"]) for box, when in _boxes_of_set(ask, facts, s)]
    eras = [{"key": "", "label": "All series / eras"}] + [{"key": n, "label": n} for n in series]
    return _sort_sets(items, sort), eras, hidden.summary()


def _with_covers(ask, boxes):
    """A set with no logo (every toy list, some new card sets) shows the picture of one of its own items, not a made-up banner."""
    if all(b.get("logo") for b in boxes):
        return
    cover = ask.v.set_covers()
    for b in boxes:
        if not b.get("logo") and cover.get(b["key"]):
            b["cardImg"] = img(cover[b["key"]], b["key"])


# ---------------------------------------------------------------------------------------------------------------- the boxes of one grouping, illustrators, Pokémon
def _group_sub(sec, n, section_title, one_section, voc):
    if one_section:
        return f"{n:,} {voc['noun'] if n != 1 else voc['nounOne']}"
    return "Scene art" if sec == "art" else (section_title or "")


def _group_boxes(ask, section, one_section):
    """One box per group of the chosen section ('all' = every section).  -> (boxes, the sections to pick from)"""
    v = ask.v
    sections = dict(taxonomy.SECTIONS)
    counts = v.group_counts(ask.edition)
    boxes = []
    for gr in taxonomy.groups():
        sec = group_section(gr)
        if (section != "all" and sec != section) or (ask.q and ask.q not in gr.label.lower()):
            continue
        owned, n = counts.get(gr.id, (0, 0))
        if not n or not ask.keeps(owned, n):                                  # a group with no cards in this game isn't worth a box
            continue
        title = sections.get(sec) or taxonomy.LABEL.get(sec, sec)
        boxes.append({"key": gr.id, "kind": "group", "title": gr.label, "sub": _group_sub(sec, n, title, one_section, ask.voc), "help": gr.help or "", "owned": owned, "total": n,
                      "cardImg": ask.cover(v.group_ids(gr.id, ask.edition))})
    eras = [] if one_section else [{"key": "all", "label": "All rarities"}] + [{"key": sec, "label": title or taxonomy.LABEL.get(sec, sec)} for sec, title in taxonomy.SECTIONS]
    return boxes, eras


def _count_text(n):
    return f"{n:,} card{'s' if n != 1 else ''}"


def _illustrator_boxes(ask):
    boxes = []
    for name, ids in ask.v.facets(ask.edition)["illustrator"].items():
        if ask.q and ask.q not in name.lower():
            continue
        owned = ask.owned_in(ids)
        if ask.keeps(owned, len(ids)):
            boxes.append({"key": name, "kind": "illustrator", "title": name, "sub": _count_text(len(ids)), "owned": owned, "total": len(ids), "cardImg": ask.cover(ids)})
    return boxes


def _pokemon_boxes(ask, era):
    """One box per Pokémon (by Pokédex number) within the generation chosen.  -> (boxes, the generations to pick from)"""
    names = checklists.dex_names(ask.v)
    low, high = (int(x) for x in (era or "1-1025").split("-"))
    boxes = []
    for number, ids in ask.v.facets(ask.edition)["dex"].items():
        title = f"#{number:04d} {names.get(number, '?')}"
        if not low <= number <= high or (ask.q and ask.q not in title.lower()):
            continue
        owned = ask.owned_in(ids)
        if ask.keeps(owned, len(ids)):
            boxes.append({"key": str(number), "kind": "pokemon", "title": title, "sub": _count_text(len(ids)), "owned": owned, "total": len(ids), "cardImg": ask.cover(ids)})
    return boxes, [{"key": k, "label": t} for k, t in GENERATIONS]


def _sort_plain(boxes, sort, mode):
    key = {"name": lambda b: b["title"].lower(), "big": lambda b: -b["total"], "most": lambda b: -frac(b), "least": frac}.get(sort)
    if key:
        boxes.sort(key=key)
    elif mode == "mon":
        boxes.sort(key=lambda b: int(b["key"]))


# ---------------------------------------------------------------------------------------------------------------- the request
def _resolve(svc, mode, era, edition):
    """-> (mode, the section when one grouping is shown on its own, era): a way of browsing this game does not have (it was chosen in another game) falls back to the sets."""
    section = ""
    if str(mode).startswith("sec:"):                                          # one way of grouping (rarity, blade, season ...) shown on its own
        section, mode, era = str(mode)[4:], "cats", str(mode)[4:]
    asked = ("sec:" + section) if section else mode
    if mode != "sets" and not any(m[0] == asked for m in modes(svc, edition)):
        return "sets", "", ""
    return mode, section, era


@api("cards.overview")
def overview(svc, mode="sets", edition=None, era="", q="", status="all", sort=None, level="standard", patterns=False):
    g = svc.game
    mode, section, era = _resolve(svc, mode, era, edition)
    sort = sort or ("new" if mode == "sets" else ("default" if section else "name"))
    ask = Ask(svc, edition, q, status)
    eras, extras = [], None
    if mode == "sets":
        boxes, eras, extras = _sets_boxes(ask, era, sort, level, patterns)
        _with_covers(ask, boxes)
    elif mode == "cats":
        boxes, eras = _group_boxes(ask, era or "all", bool(section))
    elif mode == "ill":
        boxes = _illustrator_boxes(ask)
    else:
        boxes, eras = _pokemon_boxes(ask, era)
    if mode != "sets":
        _sort_plain(boxes, sort, mode)
    with_logos = sum(1 for b in boxes if b.get("logo"))
    return {"boxes": boxes, "eras": eras, "extras": extras, "needArt": bool(mode == "sets" and g.pokemon and boxes and with_logos < 0.3 * len(boxes) and not ask.q and not era
                                                                            and not runtime.IN_BROWSER),      # (the website can't download set pictures: no banner that leads nowhere)
            "modes": modes(svc, edition), "mode": ("sec:" + section) if section else mode, "noun": ask.voc["noun"], "voc": ask.voc}
