"""Report a problem with a card: the player's calls (report.*) and the owner's pull of the server's list (dev.reports.pull).  Rules and storage: cardvault/cardreports.py; the server half is
described in docs/skycloud_request_card_reports.md.  A server without the endpoint is not an error: the button just says "coming soon" and reports wait on the device."""
from .. import cardreports, reportqueue
from ..cloud import skycloud as sc
from .accountapi import account
from .registry import ApiError, api


@api("report.mine", quiet=True)
def mine(svc):
    """{reasons, ids: the items of this game I reported, left: reports I may still send today, available: True | False (server lacks it) | None (not signed in / not reachable)}."""
    a = account(svc)
    avail = None
    if a is not None:
        pend = any(r.get("state") == "pending" for r in cardreports.load(svc).values())
        avail = cardreports.flush(svc, a)["available"] if pend else getattr(svc, "_rep_avail", None)
        if avail is None:
            avail = cardreports.probe(a)
        svc._rep_avail = avail
    return {"reasons": cardreports.REASONS, "ids": cardreports.reported(svc, svc.vault.game), "left": cardreports.left(svc), "available": avail, "signedIn": a is not None}


@api("report.add", mutates=True)
def add(svc, id, reason, note="", name=""):
    """Report a problem with item `id`.  Always answers "thanks" - also when the server ignores it as one too many for that item."""
    try:
        state = cardreports.add(svc, svc.vault.game, id, reason, note, name)
    except ValueError as e:
        raise ApiError(str(e))
    a = account(svc)
    if a is not None and state == "new":
        try:
            cardreports.flush(svc, a)
        except Exception:  # noqa: BLE001 - offline: it waits and is sent with the next look
            pass
    return {"ok": True, "state": state}


@api("dev.reports.pull")
def pull(svc):
    """Owner: fetch the items players reported (the server's list since the last checker run) for the checkers to do first, and put them on the review list."""
    a = account(svc, need=True)
    try:
        out = a.call("GET", "/v1/admin/reports/pending", None, timeout=30)
    except sc.CloudError as e:
        raise ApiError("The server has no reports list yet." if e.status == 404 else str(e))
    n = reportqueue.store(out.get("items") or [])
    return {"items": n, "listed": reportqueue.to_review_list()}
