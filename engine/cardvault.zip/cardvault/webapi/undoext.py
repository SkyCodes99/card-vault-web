"""Undo for the actions that don't go through the lots/sealed bookkeeping: every delete, move and quantity change gets the same recent-actions entry and the same 7-second Undo toast.
undoable() runs one user action as ONE log entry that remembers what it changed:
  - rows=[(table, where, params)]  database rows changed with plain SQL (cardvault/rowundo.py)
  - keys=["setting", ...]          account settings that hold lists (goals, price alerts, wishlist labels, the opened-packs log): the old and new text is kept ("pset" ops)
  - restore_before_undo()          puts the settings (and a cancelled friend trade proposal, "ftrade" ops) back; the database rows are put back by Vault.undo_action"""
import json

from .. import rowundo


def undoable(svc, label, fn, rows=(), keys=()):
    """fn() as ONE undoable action -> fn's result plus {"ok", "undo": {id, label} | None}."""
    from .cards import with_undo
    v = svc.vault
    prev = {k: svc.pget(k) for k in keys}

    def body():
        out = fn()
        for k in keys:
            now = svc.pget(k)
            if now != prev[k]:
                v._remember({"t": "pset", "key": k, "prev": prev[k], "next": now})
        return out
    return with_undo(svc, lambda: rowundo.track(v, label, list(rows), body))


def _records(text):
    """A setting that is a JSON list of {id, ...} records -> that list, else None."""
    try:
        d = json.loads(text) if isinstance(text, str) else None
    except ValueError:
        return None
    return d if isinstance(d, list) and all(isinstance(r, dict) and "id" in r for r in d) else None


def _put_back(svc, op):
    key, prev, nxt = op["key"], op.get("prev"), op.get("next")
    cur = svc.pget(key)
    pl, nl, cl = _records(prev), _records(nxt), _records(cur)
    if cur == nxt or pl is None or nl is None or cl is None:
        svc.pset(key, prev)                                          # untouched since (the usual case): exactly the old text
        return
    p, n = {r["id"]: r for r in pl}, {r["id"]: r for r in nl}        # changed since: undo only this action's records, keep the newer ones
    added, changed = set(n) - set(p), {i for i in set(p) & set(n) if p[i] != n[i]}
    out = [p[r["id"]] if r["id"] in changed else r for r in cl if r["id"] not in added]
    have = {r["id"] for r in out}
    out += [p[i] for i in (set(p) - set(n)) | changed if i not in have]
    rank = {r["id"]: i for i, r in enumerate(pl)}
    out.sort(key=lambda r: rank.get(r["id"], 1 << 30))
    svc.pset(key, json.dumps(out))


def restore_before_undo(svc, action_id):
    """Before an action is undone: put back its settings and cloud rows (the database rows are undone by the vault)."""
    v = svc.vault
    r = v.conn.execute("SELECT ops, undone FROM u.actions WHERE id=? AND user_id=? AND game=?", (action_id, v.user_id, v.game)).fetchone()
    if not r or r["undone"]:
        return
    for op in reversed(json.loads(r["ops"])):
        if op.get("t") == "pset":
            _put_back(svc, op)
        elif op.get("t") == "ftrade":
            from .friendtrade import restore_proposal
            restore_proposal(svc, op["row"])
