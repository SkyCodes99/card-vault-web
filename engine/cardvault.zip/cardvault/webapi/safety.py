"""Report, hide and block - what the App Store and Google Play ask for when people can see things from each other (friend profiles, wishlists, trade offers, friend requests, usernames).

REPORT  goes to the account server (POST /v1/reports) and lands in the OWNER'S Dev Tools > Feedback list as kind "report" (reporter and reported are usernames only).  It is server-side on purpose:
        the report is written on a stranger's device, and the local review list (reviewlist.py) lives on the owner's computer, so it could never receive it.
HIDE    hides one thing (a friend request, a trade offer, a card on someone's wishlist) for me only.  Kept with my account's settings; nobody is told.
BLOCK   is kept on the account server (so it holds on every device) and ENFORCED there: the two can't find each other, offer, accept or join through a link, and what they shared with each other
        is cut when the block is made (see SkyCloud safety.py).  This device also marks them blocked so they vanish from the lists.  Unblock lifts it."""
import json
import time

from ..cloud import skycloud as sc
from .accountapi import account
from .registry import ApiError, api

REASONS = ("spam", "harassment", "inappropriate", "impersonation", "scam", "other")
WHERES = ("profile", "collection", "wishlist", "list", "showcase", "trade", "request", "username", "other")
HIDE_KINDS = ("request", "trade", "card")
SYNC_EVERY = 30                                                     # seconds between looks at the account's block list while the Friends screen refreshes


def _norm(name):
    return (name or "").strip().lstrip("@").lower()


def _book(svc):
    from .friends import _book as b
    return b(svc)


def _acct(svc):
    a = account(svc)
    if a is None:
        raise ApiError("Sign in to your account first (Settings > Account) - blocking and reporting go through it, so they hold on every device.", code="no_account")
    return a


def _call(a, method, path, body=None):
    try:
        return a.call(method, path, body, timeout=30)
    except sc.CloudError as e:
        if e.status == 404:
            raise ApiError("Nobody has that username - or the account server hasn't had its update for this yet.")
        raise ApiError(str(e))


# ---------------------------------------------------------------------------------------------------------------------------------------------- block
def server_block(svc, username):
    """Tell the account server (it enforces the block and cuts what was shared).  Raises if it could not."""
    u = _norm(username)
    _call(_acct(svc), "PUT", "/v1/blocks/" + u)
    return u


def server_unblock(svc, username):
    _call(_acct(svc), "DELETE", "/v1/blocks/" + _norm(username))


def _save(svc, book):
    from .friends import _save as s
    s(svc, book)


def sync_blocks(svc, force=False):
    """Make this device agree with the account's block list (a block made on another device shows up here; one made here before blocks lived on the server is sent up).  Never raises."""
    if not force and time.time() - getattr(svc, "_blocks_at", 0) < SYNC_EVERY:
        return
    svc._blocks_at = time.time()
    try:
        a = account(svc)
        if a is None:
            return
        remote = {_norm(b["username"]) for b in _call(a, "GET", "/v1/blocks").get("blocked", [])}
        book = _book(svc)
        changed = False
        for u in remote:
            f = book.get(u)
            if not f or not f.get("blocked") or not f.get("bsync"):
                book[u] = {"blocked": True, "bsync": True}              # (their friendship data is already cut by the server)
                changed = True
        for u, f in list(book.items()):
            if f.get("blocked") and u not in remote:
                if f.get("bsync"):                                       # lifted on another device
                    book.pop(u)
                else:                                                    # blocked here before it was kept on the server: send it up
                    try:
                        _call(a, "PUT", "/v1/blocks/" + u)
                        f["bsync"] = True
                    except ApiError:
                        continue
                changed = True
        if changed:
            _save(svc, book)
    except Exception:  # noqa: BLE001 - offline: tried again at the next refresh
        svc._blocks_at = 0


@api("safety.blocked", quiet=True)
def blocked(svc):
    """The people I blocked, from the account (the same on every device).  -> {"blocked": [{username, since}]}"""
    a = _acct(svc)
    rows = _call(a, "GET", "/v1/blocks").get("blocked", [])
    sync_blocks(svc, force=True)
    return {"blocked": [{"username": _norm(r["username"]), "since": r.get("since")} for r in rows]}


@api("safety.block", mutates=True)
def block(svc, username):
    """Block someone: from anywhere (a request, a trade offer, a profile).  They can't see my things, send requests or trades, and they disappear from my lists."""
    u = _norm(username)
    if not u:
        raise ApiError("Type their username.")
    if u == _norm(svc.pget("cloud_username")):
        raise ApiError("That's you!")
    from .friends import friends_remove
    if u in _book(svc):
        friends_remove(svc, u, block=True)                              # takes the friendship apart, blocks on the server, marks them blocked here
    else:
        server_block(svc, u)
        book = _book(svc)
        book[u] = {"blocked": True, "bsync": True}
        _save(svc, book)
    return {"username": u}


@api("safety.unblock", mutates=True)
def unblock(svc, username):
    u = _norm(username)
    server_unblock(svc, u)
    book = _book(svc)
    if (book.get(u) or {}).get("blocked"):
        book.pop(u)
        _save(svc, book)
    return {"username": u}


# ---------------------------------------------------------------------------------------------------------------------------------------------- report
@api("safety.report", mutates=False)
def report(svc, username, reason, where="profile", item="", note=""):
    """Report a person (or one of their things) to the app's owner.  A reason is needed; the note is optional."""
    u = _norm(username)
    if not u:
        raise ApiError("Who is this about?")
    if reason not in REASONS:
        raise ApiError("Pick a reason.")
    where = where if where in WHERES else "other"
    _call(_acct(svc), "POST", "/v1/reports", {"target": u, "where": where, "item": str(item or "")[:120], "reason": reason, "note": str(note or "").strip()[:500], "app": "Collect Em All"})
    return {"ok": True}


# ---------------------------------------------------------------------------------------------------------------------------------------------- hide
def _hidden_raw(svc):
    try:
        d = json.loads(svc.pget("safety_hidden") or "[]")
    except ValueError:
        d = []
    return [x for x in d if isinstance(x, list) and len(x) == 3] if isinstance(d, list) else []


def hidden_set(svc):
    return {tuple(x) for x in _hidden_raw(svc)}


def is_hidden(hidden, kind, username, ref=""):
    return (kind, _norm(username), str(ref or "")) in hidden


@api("safety.hide", mutates=True)
def hide(svc, kind, username, ref=""):
    """Hide one thing for me only: kind = request | trade | card; ref says which one (the trade's id, the card's id...)."""
    if kind not in HIDE_KINDS:
        raise ApiError("That can't be hidden.")
    row = [kind, _norm(username), str(ref or "")[:120]]
    cur = _hidden_raw(svc)
    if row not in cur:
        cur.append(row)
    svc.pset("safety_hidden", json.dumps(cur[-2000:]))
    return {"hidden": len(cur)}


@api("safety.unhide", mutates=True)
def unhide(svc, kind=None, username="", ref=""):
    """Show a hidden thing again - or, with nothing named, everything I hid."""
    cur = _hidden_raw(svc)
    if kind:
        cur = [x for x in cur if x != [kind, _norm(username), str(ref or "")]]
    else:
        cur = []
    svc.pset("safety_hidden", json.dumps(cur))
    return {"hidden": len(cur)}


@api("safety.hiddenCount", quiet=True)
def hidden_count(svc):
    return {"hidden": len(_hidden_raw(svc))}
