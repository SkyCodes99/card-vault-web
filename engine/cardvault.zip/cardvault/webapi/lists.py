"""Checklists: progress, slot options for Pokédex / rarity lists, rules for the editor, presets, exports."""
import contextlib
import json

from .. import checklists, exports, taxonomy, variantprice
from .cards import _target_name, img, scope_ids, with_undo
from .registry import api
from .service import ApiError

NO_CARD = "No Card Exists"


@contextlib.contextmanager
def _from_checklist(svc):
    """A card ticked on a checklist that lands in Main is flagged as not yet placed: the person is asked which portfolio it belongs to."""
    v = svc.vault
    v._from_list = True
    try:
        yield
    finally:
        v._from_list = False


def progress_of(svc, cl_id):
    v = svc.vault
    cl = v.checklist(cl_id)
    if not cl or cl["deleted"]:
        raise ApiError("checklist not found")
    return cl, checklists.progress_for_checklist(v, cl)


def _with_sale(svc, rows):
    from . import trendapi
    trendapi.attach(svc, [r for r in rows if r.get("id") and not r.get("slot")])
    return rows


VAR_ABBR = {"Normal": "N", "Holo": "H", "Reverse Holo": "RH", "1st Edition": "1E", "W Promo": "WP"}


def tile_dict(svc, t, cl_id=None, oc=None):
    """One tile of a progress view as plain data."""
    v = svc.vault
    if t.card_id is None and t.key:                      # a Pokédex number with no card in the chosen categories
        return {"key": t.key, "slot": True, "id": "", "title": t.label, "sub": NO_CARD, "owned": False, "qty": 0, "noCard": True, "img": ""}
    c = v.card_light(t.card_id)
    if not c:
        return None
    base = {"id": t.card_id, "img": img(t.card_id, c["set_id"]), "tcg": c.get("tcg_id") or "", "wish": t.card_id in svc.wishlist}
    if t.candidates:
        n = len(t.candidates)
        return {**base, "key": t.key, "slot": True, "title": t.label, "sub": f"{len(t.owned_cards)}/{n} owned" if t.owned else f"{n} option{'s' if n != 1 else ''}",
                "owned": t.owned, "qty": t.qty, "options": n, "ownedOptions": len(t.owned_cards)}
    price, exact = (variantprice.price_for(c, t.variant) if t.variant else (c.get("price_usd"), False))          # a printing's own market price (the Holo is not the 1st Edition)
    # "Scyther - Jungle" / "#10 · Holo · Rare · NM" / price: the name with its set on the first line, the number, printing, rarity and (if owned) condition on the second
    second = " · ".join(x for x in (f"#{c['local_id']}", t.variant or "", c.get("rarity") or "", (_cond(oc, t) if t.owned else "")) if x)
    return {**base, "key": f"{t.card_id}|{t.variant or ''}", "slot": False, "title": f"{c['name']} - {c.get('set_name')}" if c.get("set_name") else c["name"],
            "sub": second, "owned": t.owned, "qty": t.qty, "variant": t.variant or "", "price": price, "priceKind": "" if exact else (c.get("price_kind") or "")}


def _cond(oc, t):
    if not oc:
        return ""
    vs = oc.get(t.card_id) or {}
    return vs.get(t.variant) if t.variant else "/".join(dict.fromkeys(x for x in vs.values() if x))


@api("lists.all")
def lists_all(svc):
    v = svc.vault
    out = []
    for cl in v.checklists():
        pr = checklists.progress_for_checklist(v, cl)
        owned, total = pr.owned, pr.total
        if (checklists._load_rules(cl) or {}).get("sealed"):                 # sealed products on the list count too
            try:
                from .listsealed import lists_sealed
                sl = lists_sealed(svc, cl["id"])
                owned, total = owned + sl["owned"], total + sl["total"]
            except Exception:  # noqa: BLE001
                pass
        out.append({"id": cl["id"], "name": cl["name"], "owned": owned, "total": total, "pct": round(100 * owned / total, 1) if total else 0.0, "mode": cl["mode"]})
    return out


@api("lists.get")
def lists_get(svc, id, view="all", q="", sort=""):
    cl, p = progress_of(svc, id)
    mode = cl["mode"]
    q = (q or "").strip().lower()
    tiles, pocket = [], 0
    oc = svc.vault.owned_conditions()
    for t in p.view(view):
        d = tile_dict(svc, t, id, oc)
        if not d:
            continue
        if q:
            c = svc.vault.card_light(t.card_id) or {}
            hay = f"{d['title']} {c.get('set_name') or ''} {c.get('rarity') or ''}".lower()
            if q not in hay:
                continue
        c0 = svc.vault.card_light(t.card_id) or {}
        pocket += 1 if c0.get("edition") == "pocket" else 0
        d["_k"] = (c0.get("release_date") or "", c0.get("set_id") or "", c0.get("sort_key") or 0, (d.get("title") or "").lower(), d.get("price"))
        tiles.append(d)
    if sort:                                         # how the list is ordered: oldest / newest first, price, name (the default keeps the list's own order)
        none_last = lambda v, rev: ((v is None), (-v if rev else v) if v is not None else 0)
        keys = {"oldest": lambda d: (d["_k"][0] or "9999", d["_k"][1], d["_k"][2]), "priceHigh": lambda d: none_last(d["_k"][4], True), "priceLow": lambda d: none_last(d["_k"][4], False), "name": lambda d: d["_k"][3]}
        if sort == "newest":
            tiles.sort(key=lambda d: (d["_k"][1], d["_k"][2]))
            tiles.sort(key=lambda d: d["_k"][0], reverse=True)
        elif sort in keys:
            tiles.sort(key=keys[sort])
    for d in tiles:
        d.pop("_k", None)
    unit = {"dex": "Pokémon", "rarity": "rarities"}.get(mode) or ("card variants" if cl["per_variant"] else "cards")
    sub = {"dex": "One card per Pokémon", "rarity": "One card of each rarity in each set"}.get(mode) or ("Every card, each variant counted" if cl["per_variant"] else "Every card on the list")
    return {"id": id, "name": cl["name"], "mode": mode, "perVariant": bool(cl["per_variant"]), "subtitle": sub, "unit": unit, "owned": p.owned, "total": p.total,
            "pct": p.pct, "pocket": pocket, "tiles": _with_sale(svc, tiles), "hasSlots": bool(p.tiles) and any(t.key for t in p.tiles[:3]), "rules": checklists._load_rules(cl)}


@api("lists.options")
def lists_options(svc, id, slot):
    v = svc.vault
    cl, p = progress_of(svc, id)
    t = next((x for x in p.tiles if x.key == slot), None)
    if t is None:
        raise ApiError("slot not found")
    if not t.candidates:
        return {"title": t.label, "noCard": True, "options": []}
    pick = v.picks(id).get(slot)
    opts = []
    for cid in t.candidates:
        c = v.card_light(cid)
        qn = svc.owned.get(cid, 0)
        opts.append({"id": cid, "img": img(cid, c["set_id"]), "tcg": c.get("tcg_id") or "", "title": c["name"], "sub": f"{c['set_name']} · {c['local_id']} · {c.get('rarity') or ''}", "qty": qn,
                     "price": c.get("price_usd"), "priceKind": c.get("price_kind") or "", "owned": qn > 0, "picked": cid == pick or (pick is None and cid == t.card_id and qn > 0)})
    return {"title": t.label, "noCard": False, "options": _with_sale(svc, opts)}


@api("lists.pick", mutates=True)
def lists_pick(svc, id, slot, card):
    v = svc.vault
    v.set_pick(id, slot, None if v.picks(id).get(slot) == card else card)
    return {"ok": True}


@api("lists.optionOwn", mutates=True)
def lists_option_own(svc, id, slot, card):
    """Tick / untick one option of a slot; a newly owned card becomes the shown one if none is chosen yet."""
    v = svc.vault
    owned = svc.owned.get(card, 0) > 0
    from .cards import guard_elsewhere
    guard_elsewhere(svc, card, [1] if owned else [])
    name = (v.card_light(card) or {}).get("name", card)

    def run():
        with v.action(f"{'Removed' if owned else 'Marked'} {name}{'' if owned else ' as owned'}"), _from_checklist(svc):
            (v.set_owned(card, False) if owned else v.set_owned(card, True))
            if not owned:
                v.record_price_history([card])
            pick = v.picks(id).get(slot)
            if not owned and not pick:
                v.set_pick(id, slot, card)
            elif owned and pick == card:
                v.set_pick(id, slot, None)
    return with_undo(svc, run)


@api("lists.slotOwn", mutates=True)
def lists_slot_own(svc, id, slot, owned):
    """The tick-box of a whole slot: mark its only option owned, or clear every owned option."""
    v = svc.vault
    cl, p = progress_of(svc, id)
    t = next((x for x in p.tiles if x.key == slot), None)
    if t is None or not t.candidates:
        raise ApiError("No Card Exists")
    if owned:
        # one click ticks the card already showing for this spot (the picked one, else the first option); the other options stay available
        ids = [t.card_id if t.card_id in t.candidates else t.candidates[0]]
        from .cards import guard_elsewhere
        guard_elsewhere(svc, ids[0], [1] if svc.owned.get(ids[0], 0) > 0 else [])
    else:
        ids = list(t.owned_cards)

    def run():
        with v.action(f"{'Marked' if owned else 'Cleared'} {t.label}" + (f" - added to {_target_name(svc)}" if owned else "")), _from_checklist(svc):
            v.mark_many(ids, bool(owned))
            if owned:
                v.record_price_history(ids)
    return with_undo(svc, run)


@api("lists.slotInfo")
def lists_slot_info(svc, id, slot):
    cl, p = progress_of(svc, id)
    t = next((x for x in p.tiles if x.key == slot), None)
    if t is None:
        return {}
    names = [svc.vault.card_light(c)["name"] for c in t.owned_cards[:4]]
    return {"label": t.label, "owned": t.owned, "options": len(t.candidates), "ownedNames": names}


# ------------------------------------------------------------------------------------------------ creating / editing
@api("lists.create", mutates=True)
def lists_create(svc, name, mode="cards", perVariant=False, rules=None):
    if not name or not name.strip():
        raise ApiError("Please give the checklist a name.")
    rules = rules or {}
    if not rules.get("include") and not rules.get("sealed"):
        raise ApiError("Add at least one condition to a group so the list isn't empty.")
    per = bool(perVariant) and mode == "cards"
    cid = svc.vault.create_checklist(name.strip(), mode, per, rules)
    return {"ok": True, "id": cid}


@api("lists.update", mutates=True)
def lists_update(svc, id, name, mode="cards", perVariant=False, rules=None):
    rules = rules or {}
    if not name or not name.strip():
        raise ApiError("Please give the checklist a name.")
    if not rules.get("include") and not rules.get("sealed"):
        raise ApiError("Add at least one condition to a group so the list isn't empty.")
    v = svc.vault
    before = checklists.members(v, v.checklist(id)) if v.checklist(id) else []
    v.update_checklist(id, name.strip(), mode, bool(perVariant) and mode == "cards", rules)
    # Changing the rules must never take a card you have already ticked off the list: any owned card that the new rules no longer match is kept on it by hand
    # (you can still untick / remove it yourself).  A card you removed from the list by hand stays removed.
    now_in = set(checklists.members(v, v.checklist(id)))
    held = v.checklist_manual(id)["excluded"]
    kept = [cid for cid in before if cid not in now_in and cid not in held and svc.owned.get(cid, 0) > 0]
    for cid in kept:
        v.set_checklist_card(id, cid, "manual")
    return {"ok": True, "id": id, "kept": len(kept)}


@api("lists.delete", mutates=True)
def lists_delete(svc, id):
    v = svc.vault
    cl = v.checklist(id)
    if not cl:
        raise ApiError("checklist not found")

    def run():
        with v.action(f"Deleted checklist '{cl['name']}'"):
            v.delete_checklist(id)
    return with_undo(svc, run)


@api("lists.presets")
def lists_presets(svc):
    return [{"name": k, **checklists.PRESETS[k]} for k in checklists.presets_for(svc.game)]


@api("lists.fromPreset", mutates=True)
def lists_from_preset(svc, name):
    p = checklists.PRESETS[name]
    return {"ok": True, "id": svc.vault.create_checklist(name, p["mode"], p["per_variant"], p["rules"])}


@api("lists.preview")
def lists_preview(svc, rules, mode="cards", dexAll=False):
    v = svc.vault
    ids = checklists.match_ids(v, rules or {})
    if mode == "dex":
        prog = checklists.progress_for_cards(v, ids, "dex", dex_all=bool(dexAll))
        have = sum(1 for t in prog.tiles if t.candidates)
        return {"matches": len(ids), "slots": prog.total, "withCards": have}
    if mode == "rarity":
        prog = checklists.progress_for_cards(v, ids, "rarity")
        return {"matches": len(ids), "slots": prog.total}
    return {"matches": len(ids)}


@api("rules.options")
def rules_options(svc):
    """Everything the rule builder offers to choose from."""
    v, g = svc.vault, svc.game
    facets = v.facets()
    out = {
        "groups": [{"id": x.id, "label": x.label, "parent": x.parent, "help": getattr(x, "help", "")} for x in taxonomy.groups()],
        "sections": [[s, t] for s, t in taxonomy.SECTIONS],
        "pokemon": g.pokemon, "family": g.family, "typeLabel": g.type_label,
        "sets": [{"id": s["id"], "name": s["name"]} for s in v.sets()], "series": list(v.series_names()), "rarities": v.distinct("rarity"), "types": v.distinct("types"),
        "illustrators": [{"name": n, "count": len(ids)} for n, ids in sorted(facets["illustrator"].items())],
        "categories": v.distinct("category") if not g.pokemon else ["Pokemon", "Trainer", "Energy"],
    }
    if g.pokemon:
        names = checklists.dex_names(v)
        out["dex"] = [{"num": d, "name": names.get(d, "?"), "count": len(ids)} for d, ids in sorted(facets["dex"].items())]
    return out


# ------------------------------------------------------------------------------------------------ exporting
def progress_source(svc, source):
    v = svc.vault
    kind = source.get("kind")
    if kind == "list":
        cl, p = progress_of(svc, source["id"])
        return p, cl["name"]
    val = source.get("val")
    if kind == "set":
        return checklists.progress_for_set(v, val), source.get("title") or val
    ids = scope_ids(v, kind, val, source.get("edition"))
    return checklists.progress_for_cards(v, ids or []), source.get("title") or str(val)



def runtime_remote():
    from .. import runtime
    return runtime.REMOTE_IMAGES


@api("export.info")
def export_info(svc, source):
    p, title = progress_source(svc, source)
    return {"title": title, "owned": p.owned, "total": p.total, "pct": p.pct}


@api("export.run")
def export_run(svc, source, path, which="missing", fmt="xlsx", images=True):
    v = svc.vault
    svc.need_grant(path)
    svc.audit("export", f"{which} list ({fmt})")
    p, title = progress_source(svc, source)
    rows = checklists.missing_rows(v, p) if which == "missing" else exports.owned_rows(v, p)
    if not rows:
        raise ApiError(f"There is nothing {which} in this list.")
    if fmt == "txt":
        exports.export_txt(path, title, rows, p.owned, p.total, which)
    else:
        def extra(r):
            c = v.card(r.get("card_id")) if r.get("card_id") else None
            if not c:
                return {}
            light = v.card_light(r["card_id"]) or {}
            from .. import taxonomy
            return {"rarity": taxonomy.card_rarity_label(light, light.get("groups")) if svc.game.pokemon and light else (c["rarity"] or ""),
                    "kind": c["category"] or "", "stage": c["stage"] or "", "hp": c["hp"] or "", "released": (c["release_date"] or "")[:10]}

        def fetch(r):
            url = svc.remote_image(r.get("card_id"), "low") if runtime_remote() else ""
            if not url:
                return None
            import requests
            resp = requests.get(url, timeout=20)
            return resp.content if resp.ok else None
        exports.export_xlsx(path, title, rows, p.owned, p.total, v.gdir, bool(images), which, None, extra=extra, fetch=fetch)
    return {"lines": len(rows), "path": path}
