"""Checklists: progress, slot options for Pokédex / rarity lists, rules for the editor, presets, exports."""
import contextlib
import json

from .. import checklists, exports, taxonomy, variantprice
from .cards import _target_name, img, scope_ids, with_undo
from .listsource import own_source, source_of, source_scope
from .registry import api
from .service import ApiError

NO_CARD = "No Card Exists"


@contextlib.contextmanager
def _from_checklist(svc):
    """A card ticked on a checklist that lands in Main is flagged as not yet placed: the person is asked which portfolio it belongs to."""
    v = svc.vault
    v._from_list = True
    try:
        yield
    finally:
        v._from_list = False


def progress_of(svc, cl_id):
    v = svc.vault
    cl = v.checklist(cl_id)
    if not cl or cl["deleted"]:
        raise ApiError("checklist not found")
    return cl, checklists.progress_for_checklist(v, cl)


def _with_sale(svc, rows):
    from . import trendapi
    trendapi.attach(svc, [r for r in rows if r.get("id") and not r.get("slot")])
    return rows


VAR_ABBR = {"Normal": "N", "Holo": "H", "Reverse Holo": "RH", "1st Edition": "1E", "W Promo": "WP"}


def tile_dict(svc, t, cl_id=None, oc=None):
    """One tile of a progress view as plain data."""
    v = svc.vault
    if t.card_id is None and t.key:                      # a Pokédex number with no card in the chosen categories
        return {"key": t.key, "slot": True, "id": "", "title": t.label, "sub": NO_CARD, "owned": False, "qty": 0, "noCard": True, "img": ""}
    c = v.card_light(t.card_id)
    if not c:
        return None
    base = {"id": t.card_id, "img": img(t.card_id, c["set_id"]), "tcg": c.get("tcg_id") or "", "wish": t.card_id in svc.wishlist}
    if t.candidates:
        n = len(t.candidates)
        return {**base, "key": t.key, "slot": True, "title": t.label, "sub": f"{len(t.owned_cards)}/{n} owned" if t.owned else f"{n} option{'s' if n != 1 else ''}",
                "owned": t.owned, "qty": t.qty, "options": n, "ownedOptions": len(t.owned_cards)}
    price, exact = (variantprice.price_for(c, t.variant) if t.variant else (c.get("price_usd"), False))          # a printing's own market price (the Holo is not the 1st Edition)
    # "Scyther - Jungle" / "#10 · Holo · Rare · NM" / price: the name with its set on the first line, the number, printing, rarity and (if owned) condition on the second
    second = " · ".join(x for x in (f"#{c['local_id']}", t.variant or "", c.get("rarity") or "", (_cond(oc, t) if t.owned else "")) if x)
    return {**base, "key": f"{t.card_id}|{t.variant or ''}", "slot": False, "title": f"{c['name']} - {c.get('set_name')}" if c.get("set_name") else c["name"],
            "sub": second, "owned": t.owned, "qty": t.qty, "variant": t.variant or "", "price": price, "priceKind": "" if exact else (c.get("price_kind") or "")}


def _cond(oc, t):
    if not oc:
        return ""
    vs = oc.get(t.card_id) or {}
    return vs.get(t.variant) if t.variant else "/".join(dict.fromkeys(x for x in vs.values() if x))


@api("lists.portfolio", quiet=True)
def lists_portfolio(svc, id):
    """The portfolios a checklist is shown under (a checklist can be tied to portfolios; it never holds cards itself)."""
    from .portfolios import _state
    st = _state(svc)
    under = [p["id"] for p in st["portfolios"] if any(c["id"] == int(id) for c in p.get("checklists", []))]
    return {"under": under, "portfolios": [{"id": p["id"], "name": p["name"]} for p in st["portfolios"]]}


@api("lists.setPortfolio", mutates=True)
def lists_set_portfolio(svc, id, portfolio):
    """Put a checklist under ONE portfolio (taking it from the others).  portfolio 'none' = under no portfolio."""
    from .portfolios import MAIN, _clean, meta_of
    v = svc.vault
    cid = int(id)
    for p in v.portfolios():
        m = meta_of(p)
        ls = [x for x in (m.get("lists") or []) if str(x) != str(cid)]
        if p["uuid"] == portfolio:
            ls.append(cid)
        if ls != (m.get("lists") or []):
            m["lists"] = ls
            v.update_portfolio(p["uuid"], None, None, _clean(m))
    svc.reload_state()
    return {"ok": True}


@api("lists.setPortfolios", mutates=True)
def lists_set_portfolios(svc, id, portfolios):
    """Show a checklist under any number of portfolios (a goal is not tied to one).  portfolios = the portfolio ids it should be under (none = under no portfolio)."""
    from .portfolios import _clean, meta_of
    v = svc.vault
    cid = int(id)
    want = set(portfolios or [])
    for p in v.portfolios():
        m = meta_of(p)
        ls = [x for x in (m.get("lists") or []) if str(x) != str(cid)]
        if p["uuid"] in want:
            ls.append(cid)
        if ls != (m.get("lists") or []):
            m["lists"] = ls
            v.update_portfolio(p["uuid"], None, None, _clean(m))
    svc.reload_state()
    return {"ok": True}


@api("lists.all")
def lists_all(svc, fast=False):
    """Every checklist with its progress.  fast=True answers at once with just the names (the screen shows the list straight away, then asks again for the progress, which takes a moment
    with many checklists); one checklist that cannot be counted never hides the others."""
    v = svc.vault
    out = []
    owned_now = svc.owned if isinstance(svc.owned, dict) else {}
    stamp = (svc.last_change, id(v.card_index()), len(owned_now), sum(x for x in owned_now.values() if isinstance(x, int)))
    cache = getattr(v, "_lists_cache", None)
    if cache is None or cache["stamp"] != stamp:                      # anything in the collection changed: count again
        cache = v._lists_cache = {"stamp": stamp, "rows": {}}
    scope_key = tuple(sorted(str(x) for x in (v.scope or [])))
    for cl in v.checklists():
        rules = checklists._load_rules(cl) or {}
        row = {"id": cl["id"], "name": cl["name"], "owned": None, "total": None, "pct": None, "mode": cl["mode"], "icon": rules.get("icon", ""), "source": source_of(cl)}
        ckey = (cl["id"], repr(rules), scope_key if row["source"]["mode"] == "view" else ())          # only a checklist that follows the current view depends on which portfolios are ticked
        if not fast and ckey in cache["rows"]:
            row.update(cache["rows"][ckey])
        elif not fast:
            try:
                with source_scope(svc, cl):                                       # each checklist counts from its own source (everything / chosen portfolios / the current view)
                    pr = checklists.progress_for_checklist(v, cl)
                    owned, total = pr.owned, pr.total
                    if rules.get("sealed"):                                       # sealed products on the list count too
                        try:
                            from .listsealed import lists_sealed
                            sl = lists_sealed(svc, cl["id"])
                            owned, total = owned + sl["owned"], total + sl["total"]
                        except Exception:  # noqa: BLE001
                            pass
                row.update({"owned": owned, "total": total, "pct": round(100 * owned / total, 1) if total else 0.0})
                cache["rows"][ckey] = {k: row[k] for k in ("owned", "total", "pct")}
            except Exception:  # noqa: BLE001 - this one could not be counted right now: it is still listed
                row.update({"owned": 0, "total": 0, "pct": 0.0, "error": True})
        out.append(row)
    return out


@api("lists.get")
@own_source
def lists_get(svc, id, view="all", q="", sort=""):
    cl, p = progress_of(svc, id)
    mode = cl["mode"]
    q = (q or "").strip().lower()
    tiles, pocket = [], 0
    oc = svc.vault.owned_conditions()
    for t in p.view(view):
        d = tile_dict(svc, t, id, oc)
        if not d:
            continue
        if q:
            c = svc.vault.card_light(t.card_id) or {}
            hay = f"{d['title']} {c.get('set_name') or ''} {c.get('rarity') or ''}".lower()
            if q not in hay:
                continue
        c0 = svc.vault.card_light(t.card_id) or {}
        pocket += 1 if c0.get("edition") == "pocket" else 0
        d["_k"] = (c0.get("eff_date") if "eff_date" in c0 else (c0.get("release_date") or ""), c0.get("set_id") or "", c0.get("sort_key") or 0, (d.get("title") or "").lower(), d.get("price"))
        tiles.append(d)
    if sort:                                         # how the list is ordered: oldest / newest first, price, name (the default keeps the list's own order)
        none_last = lambda v, rev: ((v is None), (-v if rev else v) if v is not None else 0)
        keys = {"oldest": lambda d: (d["_k"][0] or "9999", d["_k"][1], d["_k"][2]), "priceHigh": lambda d: none_last(d["_k"][4], True), "priceLow": lambda d: none_last(d["_k"][4], False), "name": lambda d: d["_k"][3]}
        if sort == "newest":
            tiles.sort(key=lambda d: (d["_k"][1], d["_k"][2]))
            tiles.sort(key=lambda d: d["_k"][0], reverse=True)
        elif sort in keys:
            tiles.sort(key=keys[sort])
    for d in tiles:
        d.pop("_k", None)
    unit = {"dex": "Pokémon", "rarity": "rarities"}.get(mode) or ("card variants" if cl["per_variant"] else "cards")
    sub = {"dex": "One card per Pokémon", "rarity": "One card of each rarity in each set"}.get(mode) or ("Every card, each variant counted" if cl["per_variant"] else "Every card on the list")
    elsewhere = 0
    if svc.vault.scope:                                   # a checklist only counts what is in the portfolios being looked at: say how much more is owned in the others
        v = svc.vault
        saved, tp = list(v.scope), v.target_pf
        try:
            v.set_scope(None)
            _cl, pall = progress_of(svc, id)
            elsewhere = max(0, pall.owned - p.owned)
        finally:
            v.set_scope(saved)
            v.target_pf = tp
    return {"id": id, "name": cl["name"], "icon": (checklists._load_rules(cl) or {}).get("icon", ""), "mode": mode, "elsewhere": elsewhere, "perVariant": bool(cl["per_variant"]), "subtitle": sub, "unit": unit, "owned": p.owned, "total": p.total,
            "pct": p.pct, "pocket": pocket, "tiles": _with_sale(svc, tiles), "hasSlots": bool(p.tiles) and any(t.key for t in p.tiles[:3]), "rules": checklists._load_rules(cl)}


@api("lists.options")
def lists_options(svc, id, slot):
    v = svc.vault
    cl, p = progress_of(svc, id)
    t = next((x for x in p.tiles if x.key == slot), None)
    if t is None:
        raise ApiError("slot not found")
    if not t.candidates:
        return {"title": t.label, "noCard": True, "options": []}
    pick = v.picks(id).get(slot)
    opts = []
    for cid in t.candidates:
        c = v.card_light(cid)
        qn = svc.owned.get(cid, 0)
        opts.append({"id": cid, "img": img(cid, c["set_id"]), "tcg": c.get("tcg_id") or "", "title": c["name"], "sub": f"{c['set_name']} · {c['local_id']} · {c.get('rarity') or ''}", "qty": qn,
                     "price": c.get("price_usd"), "priceKind": c.get("price_kind") or "", "owned": qn > 0, "picked": cid == pick or (pick is None and cid == t.card_id and qn > 0)})
    return {"title": t.label, "noCard": False, "options": _with_sale(svc, opts)}


@api("lists.pick", mutates=True)
def lists_pick(svc, id, slot, card):
    v = svc.vault
    v.set_pick(id, slot, None if v.picks(id).get(slot) == card else card)
    return {"ok": True}


@api("lists.optionOwn", mutates=True)
def lists_option_own(svc, id, slot, card):
    """Tick / untick one option of a slot; a newly owned card becomes the shown one if none is chosen yet."""
    v = svc.vault
    owned = svc.owned.get(card, 0) > 0
    from .cards import guard_elsewhere
    guard_elsewhere(svc, card, [1] if owned else [])
    name = (v.card_light(card) or {}).get("name", card)

    def run():
        with v.action(f"{'Removed' if owned else 'Marked'} {name}{'' if owned else ' as owned'}"), _from_checklist(svc):
            (v.set_owned(card, False) if owned else v.set_owned(card, True))
            if not owned:
                v.record_price_history([card])
            pick = v.picks(id).get(slot)
            if not owned and not pick:
                v.set_pick(id, slot, card)
            elif owned and pick == card:
                v.set_pick(id, slot, None)
    return with_undo(svc, run)


@api("lists.slotOwn", mutates=True)
def lists_slot_own(svc, id, slot, owned):
    """The tick-box of a whole slot: mark its only option owned, or clear every owned option."""
    v = svc.vault
    cl, p = progress_of(svc, id)
    t = next((x for x in p.tiles if x.key == slot), None)
    if t is None or not t.candidates:
        raise ApiError("No Card Exists")
    if owned:
        # one click ticks the card already showing for this spot (the picked one, else the first option); the other options stay available
        ids = [t.card_id if t.card_id in t.candidates else t.candidates[0]]
        from .cards import guard_elsewhere
        guard_elsewhere(svc, ids[0], [1] if svc.owned.get(ids[0], 0) > 0 else [])
    else:
        ids = list(t.owned_cards)

    def run():
        with v.action(f"{'Marked' if owned else 'Cleared'} {t.label}" + (f" - added to {_target_name(svc)}" if owned else "")), _from_checklist(svc):
            v.mark_many(ids, bool(owned))
            if owned:
                v.record_price_history(ids)
    return with_undo(svc, run)


@api("lists.slotInfo")
def lists_slot_info(svc, id, slot):
    cl, p = progress_of(svc, id)
    t = next((x for x in p.tiles if x.key == slot), None)
    if t is None:
        return {}
    names = [svc.vault.card_light(c)["name"] for c in t.owned_cards[:4]]
    return {"label": t.label, "owned": t.owned, "options": len(t.candidates), "ownedNames": names}


# ------------------------------------------------------------------------------------------------ creating / editing
@api("lists.create", mutates=True)
def lists_create(svc, name, mode="cards", perVariant=False, rules=None):
    if not name or not name.strip():
        raise ApiError("Please give the checklist a name.")
    rules = rules or {}
    if not rules.get("include") and not rules.get("sealed"):
        raise ApiError("Add at least one condition to a group so the list isn't empty.")
    per = bool(perVariant) and mode == "cards"
    rules = {**rules, "sources": rules.get("sources") or {"mode": "all", "ids": []}}      # a new checklist counts everything you own, until you choose otherwise
    cid = svc.vault.create_checklist(name.strip(), mode, per, rules)
    return {"ok": True, "id": cid}


@api("lists.update", mutates=True)
def lists_update(svc, id, name, mode="cards", perVariant=False, rules=None):
    rules = rules or {}
    if not name or not name.strip():
        raise ApiError("Please give the checklist a name.")
    if not rules.get("include") and not rules.get("sealed"):
        raise ApiError("Add at least one condition to a group so the list isn't empty.")
    v = svc.vault
    before = checklists.members(v, v.checklist(id)) if v.checklist(id) else []
    if v.checklist(id):                                              # editing the rules must not lose the icon or where it counts from
        old = checklists._load_rules(v.checklist(id)) or {}
        for k in ("icon", "sources"):
            if k not in rules and old.get(k):
                rules = {**rules, k: old[k]}
    v.update_checklist(id, name.strip(), mode, bool(perVariant) and mode == "cards", rules)
    # Changing the rules must never take a card you have already ticked off the list: any owned card that the new rules no longer match is kept on it by hand
    # (you can still untick / remove it yourself).  A card you removed from the list by hand stays removed.
    now_in = set(checklists.members(v, v.checklist(id)))
    held = v.checklist_manual(id)["excluded"]
    kept = [cid for cid in before if cid not in now_in and cid not in held and svc.owned.get(cid, 0) > 0]
    for cid in kept:
        v.set_checklist_card(id, cid, "manual")
    return {"ok": True, "id": id, "kept": len(kept)}


@api("lists.setIcon", mutates=True)
def lists_set_icon(svc, id, icon=""):
    """An icon (an emoji, up to 4 characters) shown beside the checklist everywhere it is listed.  Kept with the checklist's rules so it syncs with it."""
    v = svc.vault
    cl = v.checklist(id)
    if not cl:
        raise ApiError("checklist not found")
    rules = dict(checklists._load_rules(cl) or {})
    if icon:
        rules["icon"] = str(icon)[:4]
    else:
        rules.pop("icon", None)
    v.update_checklist(id, cl["name"], cl["mode"], bool(cl["per_variant"]), rules, cl["notes"] or "")
    return {"ok": True}


@api("lists.delete", mutates=True)
def lists_delete(svc, id):
    v = svc.vault
    cl = v.checklist(id)
    if not cl:
        raise ApiError("checklist not found")

    def run():
        with v.action(f"Deleted checklist '{cl['name']}'"):
            v.delete_checklist(id)
    return with_undo(svc, run)


@api("lists.presets")
def lists_presets(svc):
    return [{"name": k, **checklists.PRESETS[k]} for k in checklists.presets_for(svc.game)]


@api("lists.fromPreset", mutates=True)
def lists_from_preset(svc, name):
    p = checklists.PRESETS[name]
    return {"ok": True, "id": svc.vault.create_checklist(name, p["mode"], p["per_variant"], p["rules"])}


@api("lists.preview")
def lists_preview(svc, rules, mode="cards", dexAll=False):
    v = svc.vault
    ids = checklists.match_ids(v, rules or {})
    if mode == "dex":
        prog = checklists.progress_for_cards(v, ids, "dex", dex_all=bool(dexAll))
        have = sum(1 for t in prog.tiles if t.candidates)
        return {"matches": len(ids), "slots": prog.total, "withCards": have}
    if mode == "rarity":
        prog = checklists.progress_for_cards(v, ids, "rarity")
        return {"matches": len(ids), "slots": prog.total}
    return {"matches": len(ids)}


@api("rules.options")
def rules_options(svc):
    """Everything the rule builder offers to choose from."""
    v, g = svc.vault, svc.game
    facets = v.facets()
    out = {
        "groups": [{"id": x.id, "label": x.label, "parent": x.parent, "help": getattr(x, "help", "")} for x in taxonomy.groups()],
        "sections": [[s, t] for s, t in taxonomy.SECTIONS],
        "pokemon": g.pokemon, "family": g.family, "typeLabel": g.type_label,
        "sets": [{"id": s["id"], "name": s["name"]} for s in v.sets()], "series": list(v.series_names()), "rarities": v.distinct("rarity"), "types": v.distinct("types"),
        "illustrators": [{"name": n, "count": len(ids)} for n, ids in sorted(facets["illustrator"].items())],
        "categories": v.distinct("category") if not g.pokemon else ["Pokemon", "Trainer", "Energy"],
    }
    if g.pokemon:
        names = checklists.dex_names(v)
        out["dex"] = [{"num": d, "name": names.get(d, "?"), "count": len(ids)} for d, ids in sorted(facets["dex"].items())]
    return out


# ------------------------------------------------------------------------------------------------ exporting
def progress_source(svc, source):
    v = svc.vault
    kind = source.get("kind")
    if kind == "list":
        cl, p = progress_of(svc, source["id"])
        return p, cl["name"]
    val = source.get("val")
    if kind == "set":
        return checklists.progress_for_set(v, val), source.get("title") or val
    ids = scope_ids(v, kind, val, source.get("edition"))
    return checklists.progress_for_cards(v, ids or []), source.get("title") or str(val)



def runtime_remote():
    from .. import runtime
    return runtime.REMOTE_IMAGES


@api("export.info")
def export_info(svc, source):
    p, title = progress_source(svc, source)
    return {"title": title, "owned": p.owned, "total": p.total, "pct": p.pct}


@api("export.run")
def export_run(svc, source, path, which="missing", fmt="xlsx", images=True):
    v = svc.vault
    svc.need_grant(path)
    svc.audit("export", f"{which} list ({fmt})")
    p, title = progress_source(svc, source)
    rows = checklists.missing_rows(v, p) if which == "missing" else exports.owned_rows(v, p)
    if not rows:
        raise ApiError(f"There is nothing {which} in this list.")
    if fmt == "txt":
        exports.export_txt(path, title, rows, p.owned, p.total, which)
    else:
        def extra(r):
            c = v.card(r.get("card_id")) if r.get("card_id") else None
            if not c:
                return {}
            light = v.card_light(r["card_id"]) or {}
            from .. import taxonomy
            return {"rarity": taxonomy.card_rarity_label(light, light.get("groups")) if svc.game.pokemon and light else (c["rarity"] or ""),
                    "kind": c["category"] or "", "stage": c["stage"] or "", "hp": c["hp"] or "", "released": (c["release_date"] or "")[:10]}

        def fetch(r):
            url = svc.remote_image(r.get("card_id"), "low") if runtime_remote() else ""
            if not url:
                return None
            import requests
            resp = requests.get(url, timeout=20)
            return resp.content if resp.ok else None
        exports.export_xlsx(path, title, rows, p.owned, p.total, v.gdir, bool(images), which, None, extra=extra, fetch=fetch)
    return {"lines": len(rows), "path": path}


# ---- the order of the checklists: dragged by hand, A-Z, or by how complete they are - one choice used wherever checklists are listed
ORDER_KEY = "list_order"
SORT_MODES = ("manual", "az", "pctHigh", "pctLow")


def _order(svc):
    try:
        d = json.loads(svc.pget(ORDER_KEY) or "{}")
    except ValueError:
        d = {}
    d = d if isinstance(d, dict) else {}
    return {"mode": d.get("mode") if d.get("mode") in SORT_MODES else "manual", "ids": [i for i in (d.get("ids") or []) if isinstance(i, (int, str))][:2000]}


@api("lists.order.get", quiet=True)
def order_get(svc):
    return _order(svc)


@api("lists.order.set", mutates=True)
def order_set(svc, mode=None, ids=None):
    """mode: manual | az | pctHigh | pctLow.  ids: the hand-made order (a drag sets it and switches to manual)."""
    cur = _order(svc)
    if mode is not None:
        if mode not in SORT_MODES:
            raise ApiError("Unknown sort.")
        cur["mode"] = mode
    if ids is not None:
        cur["ids"] = list(ids)[:2000]
    svc.pset(ORDER_KEY, json.dumps(cur))
    return cur
