"""Your own items (cardvault/customitems.py): add something that is in no catalog, change it, delete it, see the list and the totals.  Each action is one Undo.
create picks the game (an installed one, or "Other"), so the form can say where an item lives; amounts arrive in dollars (the screen turns typed amounts into dollars with money.toUsd)."""
from .. import customitems, games
from .registry import api
from .service import ApiError


def _undo(svc, fn):
    from .cards import with_undo
    try:
        return with_undo(svc, fn)
    except customitems.CustomError as e:
        raise ApiError(str(e))


def _pictures_changed(svc):
    svc._exists.clear()                                   # (the picture file is new: forget that it was missing)
    svc._photos_changed = True                            # (and the account's photo sync has something to send)


@api("custom.options", quiet=True)
def custom_options(svc):
    """What the form offers: the games on this device (and "Other"), the conditions, and the game now open."""
    from . import gamesapi
    from ..db import CONDITIONS
    out = [{"id": g.id, "name": g.name} for g in games.GAMES if g.available and (g.own or gamesapi.has_catalog(svc, g.id))]
    if not any(x["id"] == customitems.OTHER_GAME for x in out):
        out.append({"id": customitems.OTHER_GAME, "name": games.game_by_id(customitems.OTHER_GAME).name})
    return {"games": out, "game": svc.vault.game, "conditions": CONDITIONS, "other": customitems.OTHER_GAME}


@api("custom.get", quiet=True)
def custom_get(svc, uuid):
    try:
        return customitems.get(svc.vault, uuid)
    except customitems.CustomError as e:
        raise ApiError(str(e))


@api("custom.list", quiet=True)
def custom_list(svc):
    return customitems.listing(svc.vault)


@api("custom.summary", quiet=True)
def custom_summary(svc):
    """{items, copies, estimate}: how many of your own items you hold here and what your estimates add up to (they count in the total, as "your estimate")."""
    return customitems.summary(svc.vault)


@api("custom.create", mutates=True)
def custom_create(svc, name, game="", set_name="", series="", number="", category="", labels=None, estimate=None, qty=1, condition="Near Mint", paid=None, notes="", location="", portfolio=None,
                  picture=""):
    """Add an item of your own.  `game` = an installed game or "other" (default: the game open now).  -> {uuid, id, game, undo}."""
    from . import gamesapi
    g = games.game_by_id(game or svc.vault.game)
    if game and g.id != game:
        raise ApiError("That game isn't available.")
    if g.id != svc.vault.game:
        if not (g.own or gamesapi.has_catalog(svc, g.id)):
            raise ApiError(f"{g.name} isn't on this device yet - open it once first, or pick Other.")
        svc.open_game(g.id)
        svc.save()
    d = {"name": name, "set_name": set_name, "series": series, "number": number, "category": category, "labels": labels, "estimate": estimate, "qty": qty, "condition": condition,
         "paid": paid, "notes": notes, "location": location, "picture": picture}
    if portfolio is not None:
        d["portfolio"] = portfolio
    r = _undo(svc, lambda: customitems.create(svc.vault, d))
    if picture:
        _pictures_changed(svc)
    return {**r, "game": svc.vault.game}


@api("custom.edit", mutates=True)
def custom_edit(svc, uuid, **fields):
    """Change an item: name, set_name, series, number, category, labels, estimate, picture ("" removes it), and its first stack: qty, condition, paid, notes, location, portfolio.  Only what is sent changes."""
    allowed = {"name", "set_name", "series", "number", "category", "labels", "estimate", "picture", "qty", "condition", "paid", "notes", "location", "portfolio"}
    bad = set(fields) - allowed
    if bad:
        raise ApiError("Unknown field: " + ", ".join(sorted(bad)))
    r = _undo(svc, lambda: customitems.edit(svc.vault, uuid, fields))
    if "picture" in fields:
        _pictures_changed(svc)
    return r


@api("custom.delete", mutates=True)
def custom_delete(svc, uuid):
    return _undo(svc, lambda: customitems.remove(svc.vault, uuid))
