"""Scan a barcode (Scanner > Scan barcode, or typed): `barcode.lookup` finds the item across every game on this device.  Adding it is Find & Add's own path
(lot.add for a card / toy, sealed.save for a sealed product), so there is nothing second to keep in step."""
import re

from .. import barcodes
from .registry import api
from .search import _games


@api("barcode.lookup", quiet=True)
def barcode_lookup(svc, code=""):
    """-> {code, results: [...], message, known}.  Results are shaped like search.global rows plus shelf / shelfName; `known` = the name you gave this barcode when you added a sealed product by hand."""
    lists = _games(svc)
    for _gid, _name, path in lists:
        barcodes.prepare(path)
    out = barcodes.lookup(lists, code)
    digits = re.sub(r"\D", "", str(code or ""))
    row = svc.vault.conn.execute("SELECT name FROM u.upc_names WHERE upc=? OR upc=?", (digits, digits.lstrip("0"))).fetchone() if digits else None
    out["known"] = row[0] if row else ""
    return out
