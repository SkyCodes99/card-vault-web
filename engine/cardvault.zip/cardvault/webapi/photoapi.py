"""Photos of your portfolio items (a card copy or a sealed purchase): up to 4 each, the first is the cover.  The rules live in cardvault/lotpics.py; the account sync in cloud/photos.py.
photo.list / photo.add / photo.order / photo.delete.  Own items keep their pictures through custom.* (customitems.py) - photo.delete works for them too."""
import base64

from .. import lotpics, photolimit
from ..custompics import PictureError
from .registry import ApiError, api


def _photo_owner(svc, lot=None, uuid=None):
    """The uuid a photo is kept under: a card copy (by its number) or a sealed purchase (by its uuid) - or None."""
    if uuid:
        c = svc.vault.conn
        ok = c.execute("SELECT 1 FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (uuid, svc.vault.user_id)).fetchone() or \
            c.execute("SELECT 1 FROM u.lots WHERE uuid=? AND user_id=? AND deleted=0", (uuid, svc.vault.user_id)).fetchone()
        return uuid if ok else None
    r = svc.vault.get_lot(lot) if lot is not None else None
    return r["uuid"] if r else None


@api("photo.list")
def photo_list(svc, lot=None, uuid=None):
    """-> [{id, side, img}] cover first (an item from before the 4-photo limit may show more than 4)."""
    owner = _photo_owner(svc, lot, uuid)
    if not owner:
        return []
    return [{"id": r["id"], "side": r["side"], "img": "data:image/jpeg;base64," + base64.b64encode(r["data"]).decode()} for r in lotpics.rows(svc.vault.conn, owner) if r["data"]]


@api("photo.add", mutates=True)
def photo_add(svc, image, side="front", lot=None, uuid=None):
    owner = _photo_owner(svc, lot, uuid)
    if not owner:
        raise ApiError("copy not found")
    lotpics.check_room(svc.vault.conn, owner)
    photolimit.check_can_add(svc)                    # (signed in and already at the account's photo limit: a clear message, nothing removed)
    try:
        pid = lotpics.add(svc.vault, owner, image, side)
    except PictureError as e:
        raise ApiError(str(e))
    svc._photos_changed = True
    svc.vault.commit()
    return {"ok": True, "id": pid}


@api("photo.order", mutates=True)
def photo_order(svc, ids, lot=None, uuid=None):
    """The wanted order of an item's photos as photo ids, cover first.  Only positions change - no photo is added or removed."""
    owner = _photo_owner(svc, lot, uuid)
    if not owner:
        raise ApiError("copy not found")
    if lotpics.arrange(svc.vault, owner, ids):
        svc._photos_changed = True
        svc.vault.commit()
    return {"ok": True}


def _owns_photo(svc, owner_uuid):
    """The photo's copy, sealed purchase or own item belongs to the signed-in person (3.50.132: photo.delete took any photo number)."""
    c, me = svc.vault.conn, svc.vault.user_id
    for table in ("lots", "sealed", "custom_items"):
        try:
            if c.execute(f"SELECT 1 FROM u.{table} WHERE uuid=? AND user_id=?", (owner_uuid, me)).fetchone():
                return True
        except Exception:  # noqa: BLE001 - a collection from before that kind of item
            continue
    return False


@api("photo.delete", mutates=True)
def photo_delete(svc, id):
    """Only a photo of your own things; one undoable entry (Undo in the message and in Recent actions puts the photo back, in the same place)."""
    from ..cloud import photos
    from .cards import with_undo
    v = svc.vault
    row = v.conn.execute("SELECT id, lot_uuid, side, data, added, pos FROM u.lot_photos WHERE id=?", (id,)).fetchone()
    if not row:
        return {"ok": True, "undo": None}             # (already gone - a second tap)
    if not _owns_photo(svc, row["lot_uuid"]):
        raise ApiError("photo not found")

    def go():
        with v.action("Deleted a photo"):
            if row["data"]:                           # remember it was removed, so a synced copy on another device doesn't bring it back
                v.conn.execute("INSERT OR REPLACE INTO u.photo_deleted VALUES(?,datetime('now'))", (photos.key_for(row["lot_uuid"], row["data"]),))
            v.conn.execute("DELETE FROM u.lot_photos WHERE id=?", (row["id"],))
            v._remember({"t": "photo", "id": row["id"], "lot": row["lot_uuid"], "side": row["side"], "added": row["added"], "pos": row["pos"],
                         "data": base64.b64encode(row["data"] or b"").decode("ascii")})
    svc._photos_changed = True
    return with_undo(svc, go)
