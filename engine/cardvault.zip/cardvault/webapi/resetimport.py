"""Start over (reset the collection) and take an import back.

Both are safe: a reset first saves a full backup (which can be restored from Settings > Backups), and every import remembers exactly what it added so it can be removed
again later - even after other changes - without touching anything that was already there."""
import datetime
import json

from ..db import now_iso
from .registry import ApiError, api

HIST = "import_history"


def _hist(svc):
    try:
        h = json.loads(svc.pget(HIST) or "[]")
    except ValueError:
        h = []
    return h if isinstance(h, list) else []


def file_sha(path):
    import hashlib
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return ""


def already_imported(svc, path):
    """The earlier import (not taken back) of this very same file, or None - so a file is not imported twice by accident (every copy would be doubled)."""
    sha = file_sha(path)
    if not sha:
        return None
    for e in reversed(_hist(svc)):
        if e.get("sha") == sha and not e.get("reverted") and e.get("game") == svc.vault.game:
            return {"id": e["id"], "ts": e["ts"], "label": e["label"]}
    return None


def remember_import(svc, label, track, sha=""):               # (each entry gets its own id even when two imports happen in the same second)
    """Called after an import: keep what it created (lots with how many copies, sealed rows, wishlist cards, new portfolios)."""
    entry = {"id": datetime.datetime.now().strftime("%Y%m%d%H%M%S") + "-" + __import__("uuid").uuid4().hex[:4], "ts": datetime.datetime.now().isoformat(timespec="seconds"), "label": label, "game": svc.vault.game,
             "lots": track.get("lots", []), "sealed": track.get("sealed", []), "wish": track.get("wish", []), "portfolios": track.get("portfolios", []), "reverted": "", "sha": sha}
    svc.pset(HIST, json.dumps((_hist(svc) + [entry])[-20:]))
    return entry["id"]


@api("import.history", quiet=True)
def import_history(svc):
    out = []
    for e in reversed(_hist(svc)):
        out.append({"id": e["id"], "ts": e["ts"], "label": e["label"], "copies": sum(x["qty"] for x in e["lots"]) + sum(x["qty"] for x in e["sealed"]), "wish": len(e["wish"]),
                    "portfolios": len(e["portfolios"]), "reverted": e.get("reverted") or ""})
    return out


@api("import.revert", mutates=True)
def import_revert(svc, id):
    """Take an import back: the copies it added are removed (only the amount it added), the sealed products and wishlist cards it added go, and portfolios it made are
    removed if they are empty now.  Everything else - including copies you added yourself to the same cards - stays."""
    v = svc.vault
    hist = _hist(svc)
    e = next((x for x in hist if x["id"] == id), None)
    if not e:
        raise ApiError("That import isn't in the history.")
    if e.get("reverted"):
        raise ApiError("That import was already taken back.")
    removed = 0
    with v.action(f"Reverted import: {e['label']}"):
        for x in e["lots"]:
            r = v.conn.execute("SELECT id, qty FROM u.lots WHERE uuid=? AND user_id=? AND deleted=0", (x["lot"], v.user_id)).fetchone()
            if r:
                take = min(x["qty"], r["qty"] or 0)
                v.change_lot_qty(r["id"], -take)
                removed += take
        for x in e["sealed"]:
            r = v.conn.execute("SELECT qty FROM u.sealed WHERE uuid=? AND deleted=0", (x["uuid"],)).fetchone()
            if r:
                v.conn.execute("UPDATE u.sealed SET deleted=1, qty=0, updated_at=? WHERE uuid=?", (now_iso(), x["uuid"]))
                removed += x["qty"]
        for cid in e["wish"]:
            if cid in v.wishlist_ids():
                v.toggle_wishlist(cid)
        for pf in e["portfolios"]:
            n = v.conn.execute("SELECT COUNT(*) FROM u.lots WHERE portfolio=? AND deleted=0 AND qty>0", (pf,)).fetchone()[0] + v.conn.execute("SELECT COUNT(*) FROM u.sealed WHERE portfolio=? AND deleted=0", (pf,)).fetchone()[0]
            if not n:
                v.delete_portfolio(pf)
        v.commit()
    for x in hist:
        if x["id"] == id:
            x["reverted"] = datetime.datetime.now().isoformat(timespec="seconds")
    svc.pset(HIST, json.dumps(hist))
    svc.reload_state()
    return {"removed": removed}


@api("data.reset", mutates=True)
def data_reset(svc, scope="cards", games="this", confirm=""):
    """Start over.  scope 'cards' = copies, sealed products and wishlist; 'everything' = also portfolios, checklists, binders, trade log and spending.
    games 'this' = the open game only, 'all' = every game.  Needs confirm == 'RESET'.  A full backup is saved first."""
    if (confirm or "").strip().upper() != "RESET":
        raise ApiError("Type RESET to confirm.")
    v = svc.vault
    try:
        backup = v.backup_now("before-reset", svc.pget("backup_dir"))
    except Exception as ex:  # noqa: BLE001
        raise ApiError(f"Nothing was reset: the safety backup couldn't be saved ({ex}).")
    if not backup:                                                   # (3.50.132) backup_now returns None when no backup folder could be written: never reset without one
        raise ApiError("Nothing was reset: the safety backup couldn't be saved.")
    ts = now_iso()
    g = "" if games == "all" else " AND game=?"
    ga = () if games == "all" else (v.game,)
    c = v.conn
    n_lots = c.execute(f"SELECT COUNT(*) FROM u.lots WHERE user_id=? AND deleted=0{g}", (v.user_id, *ga)).fetchone()[0]
    c.execute(f"UPDATE u.lots SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
    c.execute(f"UPDATE u.sealed SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
    for (gm, cid) in c.execute(f"SELECT game, card_id FROM u.wishlist WHERE user_id=?{g}", (v.user_id, *ga)).fetchall():
        c.execute("DELETE FROM u.wishlist WHERE user_id=? AND game=? AND card_id=?", (v.user_id, gm, cid))
        c.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (v.user_id, gm, "wishlist", cid, ts))
    if scope == "everything":
        c.execute(f"UPDATE u.checklists SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
        c.execute(f"UPDATE u.trades SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
        c.execute(f"UPDATE u.spending SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
        c.execute(f"UPDATE u.dream_binders SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
        c.execute(f"UPDATE u.decks SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0{g}", (ts, v.user_id, *ga))
        if games == "all":
            c.execute("UPDATE u.portfolios SET deleted=1, updated_at=? WHERE user_id=? AND deleted=0", (ts, v.user_id))
    v.log("collection.reset", "collection", "", {"scope": scope, "games": games, "copies": n_lots})
    v._commit()
    svc.pset(HIST, "[]")
    svc.reload_state()
    return {"copies": n_lots, "backup": backup}
