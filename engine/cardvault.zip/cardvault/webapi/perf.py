"""A small, private record of what made the app wait during this session: the slow calls, chores and jobs - what each was called and how long it took, never anything about what is in a collection.
Shown (and copied for a bug report) by Settings > Speed check, so "the site is slow" can be answered with the actual names and numbers."""
import collections
import time

from ..version import VERSION
from .registry import api

SLOW = 0.3                                          # seconds: anything quicker is not worth a line
_slow = collections.deque(maxlen=80)                # (clock time, kind, name, seconds), newest last
_totals = {}                                        # (kind, name) -> [how many times, total seconds, the slowest time]


def note(kind, name, seconds):
    t = _totals.setdefault((kind, name), [0, 0.0, 0.0])
    t[0] += 1
    t[1] += seconds
    t[2] = max(t[2], seconds)
    if seconds >= SLOW:
        _slow.append((time.time(), kind, name, round(seconds, 2)))


class timed:
    """`with perf.timed("call", name): ...` - records how long the block took."""

    def __init__(self, kind, name):
        self.kind, self.name = kind, name

    def __enter__(self):
        self.t0 = time.perf_counter()

    def __exit__(self, *exc):
        note(self.kind, self.name, time.perf_counter() - self.t0)
        return False


def report(slow=25, heaviest=12):
    now = time.time()
    return {"version": VERSION,
            "slow": [{"ago": int(now - at), "kind": kind, "name": name, "seconds": sec} for at, kind, name, sec in list(_slow)[-slow:]][::-1],
            "heaviest": [{"kind": k[0], "name": k[1], "count": v[0], "total": round(v[1], 1), "worst": round(v[2], 2)}
                         for k, v in sorted(_totals.items(), key=lambda kv: -kv[1][1])[:heaviest]]}


@api("app.perf", quiet=True)
def perf(svc):
    from .. import games
    from . import gamesapi
    here = [{"id": g.id, "cards": gamesapi._one(svc, g.id, "SELECT COUNT(*) FROM cards") or 0} for g in games.GAMES if g.available and gamesapi.has_catalog(svc, g.id)]
    return {**report(), "games": here}
