"""A tiny local web server (127.0.0.1 only): serves the React screens, answers their data calls and sends card pictures.

Nothing here is reachable from other computers.  Data calls need a random token that only the app window knows."""
import json
import mimetypes
import os
import queue
import secrets
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .registry import ApiError
from .plainerror import FORBIDDEN, NOT_JSON, TOO_LARGE, reply
from .service import Service

MAX_BODY = 8 * 1024 * 1024
# The built-in scanner (ui/src/scanweb) loads its engine + models from Card Data and runs them in the page (WebAssembly): only that one address is allowed, for scripts and downloads.
_SCAN = "https://sky-carddata-tnnwxj.azurewebsites.net" + (" " + os.environ["CV_SCANNER_DEV_ORIGIN"] if os.environ.get("CV_SCANNER_DEV_ORIGIN") else "")      # the dev origin is for tests only
CSP = ("default-src 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline'; script-src 'self' 'wasm-unsafe-eval' " + _SCAN + "; connect-src 'self' " + _SCAN + "; "
       "worker-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
IMG_TYPES = {".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif"}


def webui_dir():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
        return os.path.join(base, "cardvault", "webui")
    dev = os.path.join(os.path.dirname(here), "ui", "dist")
    return dev if os.path.isdir(dev) else os.path.join(here, "webui")


class Server:
    def __init__(self, service=None, port=0, token=None, static_dir=None):
        self.svc = service or Service()
        self.token = token or secrets.token_urlsafe(24)
        self.static = static_dir or webui_dir()
        self.streams = []
        self.tickets = {}          # one-time passes for the live-update stream (so the real token never appears in a web address)
        self.bad_tries = []        # times of rejected data calls: a burst of them means something is guessing the token
        self.lock = threading.Lock()
        outer = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            # ---- helpers
            def send(self, code, body=b"", ctype="application/json", extra=None):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Cross-Origin-Resource-Policy", "same-origin")
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            def json(self, code, obj):
                self.send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

            def authed(self, qs=None):
                return secrets.compare_digest(self.headers.get("X-CV-Token", ""), outer.token)

            def host_ok(self):
                return (self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost"))

            def origin_ok(self):
                """Browsers say which page a request came from: anything but this app's own address is refused (blocks other websites)."""
                o = self.headers.get("Origin")
                return o is None or o in (f"http://127.0.0.1:{outer.port}", f"http://localhost:{outer.port}") or outer.token == "dev"

            def reject(self, why):
                now = time.time()
                outer.bad_tries = [t for t in outer.bad_tries if now - t < 60] + [now]
                time.sleep(min(2.0, 0.05 * len(outer.bad_tries)))         # slow down anything hammering the door
                self.json(403, {"error": FORBIDDEN, "code": "forbidden"})

            # ---- routes
            def do_POST(self):
                # always take the request body off the connection first, so a refusal can never leave bytes behind that the next request misreads
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    n = -1
                if n < 0 or n > MAX_BODY:
                    self.close_connection = True
                    return self.json(413, {"error": TOO_LARGE, "code": "too_large"})
                raw = self.rfile.read(n) if n else b""
                if not self.host_ok() or not self.origin_ok():
                    return self.reject("forbidden")
                u = urllib.parse.urlparse(self.path)
                if not u.path.startswith("/api/") or not self.authed():
                    return self.reject("forbidden")
                if not (self.headers.get("Content-Type") or "").startswith("application/json"):
                    return self.json(415, {"error": NOT_JSON, "code": "not_json"})
                if u.path == "/api/auth.ticket":
                    t = secrets.token_urlsafe(18)
                    outer.tickets = {k: v for k, v in outer.tickets.items() if v > time.time()}
                    outer.tickets[t] = time.time() + 30
                    return self.json(200, {"result": {"ticket": t}})
                try:
                    args = json.loads(raw or b"{}")
                except ValueError:
                    return self.json(400, {"error": NOT_JSON, "code": "bad_json"})
                try:
                    out = outer.svc.call(u.path[5:], args)
                except Exception as e:  # noqa: BLE001 - every failure leaves as plain words; the detail goes to the log
                    status, body = reply(e)
                    return self.json(status, body)
                self.json(200, {"result": out})

            def do_GET(self):
                if not self.host_ok():
                    return self.json(403, {"error": FORBIDDEN, "code": "forbidden"})
                u = urllib.parse.urlparse(self.path)
                qs = urllib.parse.parse_qs(u.query)
                p = u.path
                if p == "/events":
                    return self.events(qs)
                if p in ("/img", "/logo", "/symbol"):
                    return self.picture(p, qs)
                self.static_file(p)

            do_HEAD = do_GET

            def picture(self, kind, qs):
                svc = outer.svc
                try:
                    if kind == "/img":
                        q = (qs.get("q") or [None])[0]
                        path = svc.image_file(qs["c"][0], qs["s"][0], q) or svc.fetch_image(qs["c"][0], qs["s"][0], q)
                    elif kind == "/logo":
                        path = svc.logo_file(qs["s"][0])
                    else:
                        path = svc.symbol_file(qs["s"][0])
                except (KeyError, AttributeError):
                    path = ""
                if not path:
                    if kind == "/img":                                    # not fetched by this program (a host that only shows pictures to browsers, or a refusal): let the browser load it from its own address
                        try:
                            url = svc.browser_image_url(qs["c"][0], (qs.get("q") or [None])[0])
                        except (KeyError, AttributeError):
                            url = ""
                        if url:
                            self.send_response(302)
                            self.send_header("Location", url)
                            self.send_header("Cache-Control", "max-age=600")
                            self.send_header("Content-Length", "0")
                            self.end_headers()
                            return
                    return self.send(404, b"", "text/plain")
                try:
                    with open(path, "rb") as f:
                        data = f.read()
                except OSError:
                    return self.send(404, b"", "text/plain")
                self.send(200, data, IMG_TYPES.get(os.path.splitext(path)[1].lower(), "application/octet-stream"), {"Cache-Control": "max-age=3600"})

            def events(self, qs):
                ticket = (qs.get("k") or [""])[0]
                if outer.tickets.pop(ticket, 0) < time.time():
                    return self.reject("forbidden")
                box = queue.Queue()
                outer.streams.append(box)
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "keep-alive")
                self.end_headers()
                try:
                    self.wfile.write(b": hello\n\n")
                    self.wfile.flush()
                    while True:
                        try:
                            ev = box.get(timeout=20)
                            self.wfile.write(f"data: {json.dumps(ev)}\n\n".encode())
                        except queue.Empty:
                            self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                except (OSError, ValueError):
                    pass
                finally:
                    if box in outer.streams:
                        outer.streams.remove(box)

            def static_file(self, p):
                rel = urllib.parse.unquote(p.lstrip("/")) or "index.html"
                full = os.path.normpath(os.path.join(outer.static, rel))
                if not full.startswith(os.path.normpath(outer.static)) or not os.path.isfile(full):
                    full = os.path.join(outer.static, "index.html")       # single-page app: unknown paths show the app
                    if not os.path.isfile(full):
                        return self.send(404, b"The screens have not been built (run npm run build in ui/).", "text/plain")
                try:
                    with open(full, "rb") as f:
                        data = f.read()
                except OSError:
                    return self.send(404, b"", "text/plain")
                ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
                if full.endswith("index.html"):
                    data = data.replace(b"__CV_TOKEN__", outer.token.encode())
                self.send(200, data, ctype + ("; charset=utf-8" if ctype.startswith("text/") or ctype.endswith("javascript") else ""),
                          {"Content-Security-Policy": CSP} if full.endswith(".html") else None)

        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self.svc.listeners.append(self._fan_out)
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="cardvault-http", daemon=True)

    def _fan_out(self, ev):
        for box in list(self.streams):
            box.put(ev)

    def start(self):
        self.thread.start()
        return self

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}/"

    def stop(self):
        self.httpd.shutdown()


if __name__ == "__main__":
    # development: python -m cardvault.webapi.server [port]   (the Vite dev server proxies to it with token "dev")
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    srv = Server(port=port, token="dev").start()
    print("serving", srv.url, flush=True)
    threading.Event().wait()
