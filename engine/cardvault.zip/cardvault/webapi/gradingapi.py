"""Grading tracker methods (cardvault/grading.py): send cards, mark received, enter the grade that came back, list the submissions.  Each change is one undo."""
from .. import grading
from .registry import ApiError, api


def _undo(svc, fn):
    from .cards import with_undo
    try:
        return with_undo(svc, fn)
    except grading.GradingError as e:
        raise ApiError(str(e))


@api("grading.list", quiet=True)
def grading_list(svc):
    return grading.listing(svc.vault)


@api("grading.send", mutates=True)
def grading_send(svc, lots=None, cards=None, company="PSA", service="", sent="", cost=0, submission=""):
    """cost = dollars per card (the screen turns what was typed into dollars with money.toUsd)."""
    return _undo(svc, lambda: grading.send(svc.vault, lots or [], cards or [], company, service, sent, cost, submission))


@api("grading.received", mutates=True)
def grading_received(svc, ids, day=""):
    return _undo(svc, lambda: grading.received(svc.vault, ids, day))


@api("grading.graded", mutates=True)
def grading_graded(svc, id, grade, cert="", day=""):
    return _undo(svc, lambda: grading.graded(svc.vault, id, grade, cert, day))


@api("grading.returned", mutates=True)
def grading_returned(svc, id, day=""):
    """The card came back without a grade."""
    return _undo(svc, lambda: grading.returned(svc.vault, id, day))


@api("grading.remove", mutates=True)
def grading_remove(svc, id):
    """Take a submission off the tracker (entered by mistake)."""
    return _undo(svc, lambda: grading.remove(svc.vault, id))
