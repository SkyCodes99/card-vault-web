"""The collector's planning tools: cost to complete a set, the wanted-card finder, chase cards, the decklist checker, the pack-opening log, condition-aware value (an ESTIMATE) and the
upcoming-sets calendar.  Everything here only READS your collection and the shared Card Data (nothing about you leaves the device) except where a feature says so."""
import datetime
import gzip
import json
import re
import time

from .. import sync, trend
from ..db import CONDITIONS, new_uuid, today
from .registry import ApiError, api


# ------------------------------------------------------------------------------------------------ cost to complete a set
def _owned_ids(v):
    return set(v.owned_map().keys())


@api("plan.setOptions")
def set_options(svc):
    """Every set with how many of its cards you have - the picker for cost-to-complete and chase cards."""
    v = svc.vault
    owned = v.owned_by_set()
    return {"sets": [{"id": s["id"], "name": s["name"], "n": s["n"] or 0, "have": owned.get(s["id"], 0), "date": s["release_date"] or ""} for s in v.sets() if (s["n"] or 0) > 0]}


@api("plan.setCost")
def set_cost(svc, set_id, limit=300):
    """What it costs to finish one set: every missing card with its price, a cheaper other printing of the same card where one exists, and which to buy first."""
    v = svc.vault
    s = next((x for x in v.sets() if x["id"] == set_id), None)
    if not s:
        raise ApiError("That set isn't in this game's list.")
    have = _owned_ids(v)
    rows = []
    for c in v.conn.execute("SELECT id, name, local_id, rarity, price_usd FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,)):
        if c["id"] in have:
            continue
        cheaper = v.conn.execute("SELECT c.id, c.price_usd, s.name AS set_name FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.name=? AND c.id<>? AND c.price_usd IS NOT NULL "
                                 "AND (? IS NULL OR c.price_usd < ?) ORDER BY c.price_usd LIMIT 1", (c["name"], c["id"], c["price_usd"], c["price_usd"])).fetchone()
        rows.append({"id": c["id"], "name": c["name"], "number": c["local_id"], "rarity": c["rarity"] or "", "price": c["price_usd"],
                     "cheaper": {"id": cheaper["id"], "price": cheaper["price_usd"], "set": cheaper["set_name"] or ""} if cheaper else None})
    priced = [r for r in rows if r["price"] is not None]
    total = round(sum(r["price"] for r in priced), 2)
    rows.sort(key=lambda r: (r["price"] is None, r["price"] or 0))                  # cheapest first: each purchase moves the set forward the most per dollar
    ranked_total = 0.0
    for r in rows:                                                                    # "buy first": the cheapest cards, and a running total so a budget can be read off the list
        ranked_total += r["price"] or 0
        r["running"] = round(ranked_total, 2)
    return {"set": {"id": s["id"], "name": s["name"], "n": s["n"] or 0, "have": (s["n"] or 0) - len(rows)}, "missing": len(rows), "total": total,
            "noPrice": len(rows) - len(priced), "savings": round(sum(r["price"] - r["cheaper"]["price"] for r in priced if r["cheaper"]), 2), "rows": rows[:max(1, int(limit))]}


# ------------------------------------------------------------------------------------------------ wanted-card finder
@api("plan.wanted")
def wanted(svc):
    """Every wishlist card with its price today, how it moved over 30 days, and a flag when it looks like a good moment to buy (clearly under its 30-day typical price)."""
    v = svc.vault
    t = trend.for_vault(svc)
    rows = []
    for cid in v.wishlist_ids():
        c = v.card_light(cid)
        if not c:
            continue
        i = t.info(cid)
        price = c.get("price_usd")
        now = (i or {}).get("today") if (i or {}).get("today") is not None else price
        m30 = (i or {}).get("median30")
        pct = round((now - m30) / m30 * 100, 1) if (now is not None and m30) else None
        flag, why = "", ""
        if pct is not None and pct <= -10:
            flag, why = "good", f"{abs(pct)}% under its 30-day typical price"
        elif pct is not None and pct >= 15:
            flag, why = "high", f"{pct}% over its 30-day typical price - maybe wait"
        rows.append({"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "price": now, "median30": m30, "pct": pct,
                     "recent": (i or {}).get("recent"), "flag": flag, "why": why, "haveTrend": bool(i)})
    rows.sort(key=lambda r: ({"good": 0, "": 1, "high": 2}[r["flag"]], -(abs(r["pct"]) if r["pct"] is not None else 0)))
    return {"rows": rows, "days": t.days, "good": sum(1 for r in rows if r["flag"] == "good")}


# ------------------------------------------------------------------------------------------------ chase cards
@api("plan.chase")
def chase(svc, set_id, n=6):
    """The most valuable cards of one set, with how each is moving."""
    v = svc.vault
    t = trend.for_vault(svc)
    have = _owned_ids(v)
    out = []
    for c in v.conn.execute("SELECT id, name, local_id, rarity, price_usd FROM cards WHERE set_id=? AND price_usd IS NOT NULL ORDER BY price_usd DESC LIMIT ?", (set_id, max(1, min(30, int(n))))):
        i = t.info(c["id"]) or {}
        out.append({"id": c["id"], "name": c["name"], "number": c["local_id"], "rarity": c["rarity"] or "", "price": c["price_usd"], "change": i.get("change"), "trend": i.get("trend") or "",
                    "owned": c["id"] in have, "img": svc.remote_image(c["id"], "low")})
    return {"rows": out}


# ------------------------------------------------------------------------------------------------ decklist checker
_DECK_LINE = re.compile(r"^\s*(\d{1,3})\s*[xX]?\s+(.+?)\s*$")


def _clean_deck_name(raw):
    n = re.sub(r"\s*\*[A-Za-z]+\*\s*", " ", raw)                                  # MTG foil marks like *F*
    n = re.sub(r"\s*\([A-Za-z0-9\-]{2,8}\)\s*[A-Za-z0-9\-]*\s*$", "", n)         # Arena: "Lightning Bolt (M11) 149"
    n = re.sub(r"\s+[A-Z][A-Z0-9\-]{1,5}\s+\d{1,3}[a-zA-Z]?\s*$", "", n)         # Pokemon TCG Live: "Pikachu ex SVI 57"
    n = re.sub(r"\s+#?\d{1,3}[a-zA-Z]?/\d{1,3}\s*$", "", n)                       # "Pikachu 025/165"
    return n.strip()


def parse_deck(text):
    """-> [(qty, name)] from a pasted list (Pokemon TCG Live, Magic Arena / MTGO, and plain 'qty name' lists).  Headers (Pokemon: 12, Deck, Sideboard) and blank lines are skipped."""
    out = []
    for line in (text or "").splitlines():
        m = _DECK_LINE.match(line)
        if not m:
            continue
        name = _clean_deck_name(m.group(2))
        if name:
            out.append((int(m.group(1)), name))
    return out


@api("plan.deck")
def deck_check(svc, text):
    """Check a pasted deck list against what you own.  A card counts if you own ANY printing of that name (decks play the same card whatever the print)."""
    from ..importers import norm
    v = svc.vault
    lines = parse_deck(text)
    if not lines:
        raise ApiError("I couldn't find any card lines. Paste the list with one card per line, like '4 Pikachu ex' or '4x Lightning Bolt'.")
    by_name = {}
    for r in v.conn.execute("SELECT id, name, price_usd FROM cards"):
        by_name.setdefault(norm(r["name"]), []).append((r["id"], r["price_usd"]))
    owned = v.owned_map()
    merged = {}
    for q, name in lines:                                                          # the same card on two lines (a sideboard, say) adds up
        k = norm(name)
        merged[k] = (merged[k][0] + q, merged[k][1]) if k in merged else (q, name)
    rows, missing_cost, unknown = [], 0.0, []
    for k, (q, name) in merged.items():
        cands = by_name.get(k)
        if not cands:                                                              # a loose second try: the list may leave out a suffix ("Pikachu ex" vs "Pikachu")
            cands = next((c for kk, c in by_name.items() if kk.startswith(k + " ") or k.startswith(kk + " ")), None)
        if not cands:
            unknown.append(name)
            rows.append({"name": name, "need": q, "have": 0, "missing": q, "unknown": True, "price": None, "cost": None})
            continue
        have = sum(owned.get(cid, 0) for cid, _ in cands)
        prices = [p for _, p in cands if p is not None]
        cheapest = min(prices) if prices else None
        miss = max(0, q - have)
        cost = None if cheapest is None else round(cheapest * miss, 2)
        missing_cost += cost or 0
        rows.append({"name": name, "need": q, "have": min(have, q), "owned": have, "missing": miss, "price": cheapest, "cost": cost, "unknown": False})
    rows.sort(key=lambda r: (r["missing"] == 0, -(r["cost"] or 0)))
    return {"rows": rows, "total": sum(r["need"] for r in rows), "have": sum(r["have"] for r in rows), "missing": sum(r["missing"] for r in rows), "cost": round(missing_cost, 2), "unknown": unknown}


# ------------------------------------------------------------------------------------------------ pack-opening log
PACKS = "pack_log"


def _packs(svc):
    try:
        got = json.loads(svc.pget(PACKS) or "[]")
    except ValueError:
        got = []
    return [p for p in got if isinstance(p, dict) and p.get("id")]


@api("packs.list")
def packs_list(svc, hit=5.0):
    """The log, newest first, with what each pull is worth today, and the totals: cost, value pulled, hit rate and the best pulls."""
    v = svc.vault
    hit = float(hit)
    rows, best, cost, value, hit_packs, packs = [], [], 0.0, 0.0, 0, 0
    for p in reversed(_packs(svc)):
        if p.get("game") != v.game:
            continue
        pulls = []
        for x in p.get("pulls", []):
            c = v.card_light(x["id"]) or {}
            pr = c.get("price_usd")
            pulls.append({"id": x["id"], "name": c.get("name", x.get("name", "")), "price": pr})
        val = round(sum(x["price"] or 0 for x in pulls), 2)
        hits = [x for x in pulls if (x["price"] or 0) >= hit]
        rows.append({**{k: p.get(k) for k in ("id", "day", "product", "packs", "cost", "note")}, "pulls": pulls, "value": val, "hits": len(hits)})
        cost += p.get("cost") or 0
        value += val
        packs += int(p.get("packs") or 0)
        hit_packs += min(len(hits), int(p.get("packs") or 0))
        best += [{**x, "product": p.get("product"), "day": p.get("day")} for x in pulls]
    best.sort(key=lambda x: -(x["price"] or 0))
    return {"rows": rows, "totals": {"packs": packs, "cost": round(cost, 2), "value": round(value, 2), "net": round(value - cost, 2), "hits": hit_packs,
                                      "hitRate": round(100 * hit_packs / packs, 1) if packs else None}, "best": best[:5], "hitAt": hit}


@api("packs.add", mutates=True)
def packs_add(svc, product, packs=1, cost=None, pulls=None, day="", note="", add_to_collection=False):
    """Log opening `packs` of a product (what it cost in total, which cards came out).  The pulls can be added to your collection in the same step (one Undo)."""
    from .cards import with_undo
    v = svc.vault
    product = (product or "").strip()
    if not product:
        raise ApiError("Say which product you opened.")
    ids = [i for i in (pulls or []) if v.card_light(i)]
    entry = {"id": new_uuid(), "game": v.game, "day": day or today(), "product": product[:120], "packs": max(1, int(packs)), "cost": None if cost in (None, "") else round(float(cost), 2),
             "pulls": [{"id": i} for i in ids], "note": (note or "")[:200]}
    log = _packs(svc) + [entry]
    svc.pset(PACKS, json.dumps(log[-400:]))

    def add():
        with v.action(f"Opened {entry['packs']} x {product}"):
            for i in ids:
                v.add_lot(i, v.default_variant(i), "Near Mint", 1, price=None, purchased=entry["day"], source="Pack opening")
    return with_undo(svc, add) if (add_to_collection and ids) else {"ok": True, "id": entry["id"]}


@api("packs.delete", mutates=True)
def packs_delete(svc, id):
    svc.pset(PACKS, json.dumps([p for p in _packs(svc) if p["id"] != id]))
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ condition-aware value (an ESTIMATE)
FACTORS = "cond_factors"
DEFAULT_FACTORS = {"Near Mint": 1.0, "Lightly Played": 0.85, "Moderately Played": 0.70, "Heavily Played": 0.50, "Damaged": 0.35}


def factors(svc):
    try:
        got = json.loads(svc.pget(FACTORS) or "{}")
    except ValueError:
        got = {}
    return {c: float(got.get(c, DEFAULT_FACTORS[c])) for c in CONDITIONS}


@api("cond.get")
def cond_get(svc):
    return {"factors": factors(svc), "defaults": DEFAULT_FACTORS, "conditions": list(CONDITIONS),
            "note": "ESTIMATE. Card Data prices are Near Mint market prices. These percentages are only a rough guide - you can change them to match what you see sell."}


@api("cond.set", mutates=True)
def cond_set(svc, factors_in=None, reset=False):
    if reset:
        svc.pset(FACTORS, json.dumps({}))
        return {"ok": True}
    new = {}
    for c in CONDITIONS:
        try:
            x = float((factors_in or {}).get(c, DEFAULT_FACTORS[c]))
        except (TypeError, ValueError):
            raise ApiError(f"'{c}' needs a number, like 0.85 for 85%.")
        if not 0.05 <= x <= 1.5:
            raise ApiError(f"'{c}' has to be between 5% and 150%.")
        new[c] = round(x, 3)
    svc.pset(FACTORS, json.dumps(new))
    return {"ok": True}


@api("cond.value")
def cond_value(svc):
    """What the collection is worth when each copy is valued by its condition (an ESTIMATE next to the usual Near Mint value).  Graded copies are valued as they are (no factor)."""
    v = svc.vault
    f = factors(svc)
    by, nm_total, est_total, graded = {}, 0.0, 0.0, 0.0
    for r in v.conn.execute("SELECT l.qty, l.condition, l.graded, c.price_usd AS usd FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 AND c.price_usd IS NOT NULL",
                            (v.user_id, v.game)):
        full = r["qty"] * r["usd"]
        if r["graded"]:
            graded += full
            nm_total += full
            est_total += full
            continue
        cond = r["condition"] if r["condition"] in f else "Near Mint"
        d = by.setdefault(cond, {"copies": 0, "nm": 0.0, "est": 0.0})
        d["copies"] += r["qty"]
        d["nm"] += full
        d["est"] += full * f[cond]
        nm_total += full
        est_total += full * f[cond]
    return {"rows": [{"condition": c, "factor": f[c], "copies": d["copies"], "nm": round(d["nm"], 2), "estimate": round(d["est"], 2)} for c, d in by.items()],
            "nmTotal": round(nm_total, 2), "estimate": round(est_total, 2), "difference": round(est_total - nm_total, 2), "graded": round(graded, 2),
            "note": "ESTIMATE - Near Mint market prices scaled by the percentages you set for each condition."}


# ------------------------------------------------------------------------------------------------ upcoming sets calendar
_CAL = {"at": 0.0, "data": None}


def _fetch_gz(url):
    raw = sync._get(url, as_json=False, tries=2)
    if not raw:
        return None
    raw = bytes(raw)
    return json.loads(gzip.decompress(raw) if raw[:2] == bytes([0x1F, 0x8B]) else raw)


@api("calendar.upcoming")
def calendar_upcoming(svc, all_games=True):
    """Sets that have not come out yet, soonest first.  Only dates AFTER today are real release dates (older dates in the list are when a shop imported the set), so only those are shown."""
    from .. import carddata
    base = (svc.cfg.get("carddata_url") or carddata.BASE).rstrip("/")
    if not _CAL["data"] or time.time() - _CAL["at"] > 6 * 3600:
        man = sync._get(base + "/sets/manifest.json", tries=2)
        if not isinstance(man, dict) or not isinstance(man.get("games"), dict):
            raise ApiError("The release calendar can't be reached right now. Try again in a little while.")
        out = []
        for gid, info in man["games"].items():
            if not info.get("upcoming"):
                continue
            doc = _fetch_gz(f"{base}/sets/{gid}.json.gz")
            for s in (doc or {}).get("sets", []):
                if s.get("published") and s["published"] > today():
                    out.append({"game": gid, "name": s.get("name", ""), "abbr": s.get("abbr", ""), "date": s["published"]})
        _CAL.update(at=time.time(), data=sorted(out, key=lambda x: (x["date"], x["game"], x["name"])), built=man.get("built", ""))
    rows = _CAL["data"]
    mine = svc.vault.game
    if not all_games:
        rows = [r for r in rows if r["game"] == mine]
    d0 = datetime.date.today()
    return {"rows": [{**r, "days": (datetime.date.fromisoformat(r["date"]) - d0).days, "mine": r["game"] == mine} for r in rows], "built": _CAL.get("built", "")}
