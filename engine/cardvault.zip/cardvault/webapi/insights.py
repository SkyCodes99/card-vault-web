"""Little helpers that look across the collection: the weekly price digest, side-by-side card comparison, quick-add by typing, milestones and the year in review.
Everything here is for the game that is open and is worked out on this device from data it already has (prices come from the saved Trend, never guessed)."""
import re
from collections import Counter

from .. import pricepick, trend
from .cards import img, lot_add
from .registry import ApiError, api

COND = {"nm": "Near Mint", "lp": "Lightly Played", "mp": "Moderately Played", "hp": "Heavily Played", "dmg": "Damaged", "d": "Damaged",
        "near": "Near Mint", "mint": "Near Mint", "light": "Lightly Played", "moderate": "Moderately Played", "heavy": "Heavily Played", "damaged": "Damaged"}


def _owned_rows(v):
    """[(card id, copies)] for everything owned in the open game."""
    return v.conn.execute("SELECT card_id, SUM(qty) AS q FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY card_id", (v.user_id, v.game)).fetchall()


def _set_progress(v):
    """[(set id, name, have, total)] for sets with at least one card owned."""
    have = v.owned_by_set()
    out = []
    for s in v.sets():
        n = s["n"] or 0
        h = have.get(s["id"], 0)
        if n and h:
            out.append((s["id"], s["name"], h, n))
    return out


# ----------------------------------------------------------------------------------------------- weekly digest
@api("digest.get", quiet=True)
def digest(svc):
    """What moved this week: owned cards up / down against their 30-day typical price, wishlist cards that look cheap, sets that are nearly done."""
    from .planner import wanted
    v = svc.vault
    t = trend.for_vault(svc)
    moves = []
    for r in _owned_rows(v):
        i = t.info(r["card_id"])
        c = v.card_light(r["card_id"])
        if i and i.get("change") is not None and c:
            moves.append({"id": r["card_id"], "name": c.get("name"), "set": c.get("set_name", ""), "price": i.get("today"), "change": i["change"], "qty": r["q"]})
    up = sorted((m for m in moves if m["change"] >= 3), key=lambda m: -m["change"] * (m["price"] or 0))[:5]
    down = sorted((m for m in moves if m["change"] <= -3), key=lambda m: m["change"] * (m["price"] or 0))[:5]
    try:
        cheap = [r for r in wanted(svc)["rows"] if r["flag"] == "good"][:5]
    except ApiError:
        cheap = []
    near = sorted(({"id": sid, "name": nm, "have": h, "total": n, "missing": n - h} for sid, nm, h, n in _set_progress(v) if n >= 20 and 0.8 <= h / n < 1),
                  key=lambda x: x["missing"])[:4]
    return {"up": up, "down": down, "cheap": cheap, "near": near, "days": t.days, "empty": not (up or down or cheap or near)}


# ----------------------------------------------------------------------------------------------- compare
@api("compare.cards", quiet=True)
def compare(svc, ids):
    """2 to 4 cards side by side: picture, price, how it moved, my copies, rarity and the saved price history."""
    v = svc.vault
    ids = [i for i in dict.fromkeys(ids or []) if v.card_light(i)][:4]
    if len(ids) < 2:
        raise ApiError("Pick at least two cards to compare.")
    t = trend.for_vault(svc)
    owned = {r["card_id"]: r["q"] for r in _owned_rows(v)}
    wish = v.wishlist_ids()
    out = []
    for cid in ids:
        c = v.conn.execute("SELECT c.id, c.name, c.local_id, c.rarity, c.set_id, c.price_usd, c.illustrator, s.name AS set_name, s.release_date FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id=?", (cid,)).fetchone()
        i = t.info(cid) or {}
        hist = [{"day": d, "usd": usd} for d, usd, _ in v.price_history(cid) if usd is not None][-60:]
        out.append({"id": cid, "name": c["name"], "no": c["local_id"], "rarity": c["rarity"] or "", "set": c["set_name"] or "", "released": c["release_date"] or "", "artist": c["illustrator"] or "",
                    "price": c["price_usd"], "change": i.get("change"), "median30": i.get("median30"), "owned": owned.get(cid, 0), "wish": cid in wish, "pic": img(cid, c["set_id"] or ""), "history": hist})
    best = min((c for c in out if c["price"]), key=lambda c: c["price"], default=None)
    return {"cards": out, "cheapest": best["id"] if best else None}


# ----------------------------------------------------------------------------------------------- quick add by typing
_QTY = re.compile(r"(?:^|\s)(?:x\s*(\d{1,3})|(\d{1,3})\s*x)(?=\s|$)", re.I)


def _parse_line(line):
    qty, cond = 1, "Near Mint"
    m = _QTY.search(line)
    if m:
        qty = int(m.group(1) or m.group(2))
        line = (line[:m.start()] + " " + line[m.end():]).strip()
    words = []
    for w in line.split():
        k = w.lower().strip(",;")
        if k in COND and not (k in ("mint", "near", "light", "heavy", "moderate", "damaged", "d") and len(line.split()) == 1):
            cond = COND[k]
        else:
            words.append(w)
    return max(1, min(qty, 999)), cond, " ".join(words)


@api("quick.batch", quiet=True)
def quick_batch(svc, lines):
    """Each typed line ("char ex 151 x2 nm") -> how many, which condition and the best matching cards."""
    v = svc.vault
    out = []
    for line in [l for l in (lines or []) if (l or "").strip()][:60]:
        qty, cond, text = _parse_line(line.strip())
        raw = v.query_cards(text=text, sort="default")[:4] if text else []
        matches = []
        for r in raw:
            c = v.card_light(r[0]) or {}
            matches.append({"id": r[0], "name": c.get("name", r[1]), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "price": c.get("price_usd"), "pic": img(r[0], r[2] or "")})
        out.append({"line": line.strip(), "qty": qty, "cond": cond, "text": text, "matches": matches})
    return {"lines": out}


@api("quick.batchAdd", mutates=True)
def quick_batch_add(svc, items):
    """Add the chosen match of each line: [{id, qty, cond}]."""
    done = 0
    for it in (items or [])[:60]:
        if not it.get("id"):
            continue
        lot_add(svc, id=it["id"], qty=max(1, int(it.get("qty") or 1)), condition=it.get("cond") or "Near Mint")
        done += int(it.get("qty") or 1)
    return {"added": done}


# ----------------------------------------------------------------------------------------------- milestones + year in review
_TIERS = [("cards", "copies", [(100, "First 100 cards"), (500, "500 cards"), (1000, "1,000 cards"), (5000, "5,000 cards")], "🃏"),
          ("unique", "different cards", [(50, "50 different cards"), (250, "250 different"), (1000, "1,000 different")], "✨"),
          ("started", "sets started", [(3, "3 sets started"), (10, "10 sets started"), (25, "25 sets started")], "📚"),
          ("finished", "sets completed", [(1, "First set completed"), (3, "3 sets completed"), (10, "10 sets completed")], "🏆"),
          ("value", "collection value", [(100, "$100 collection"), (1000, "$1,000 collection"), (10000, "$10,000 collection")], "💎"),
          ("graded", "graded cards", [(1, "First graded card"), (10, "10 graded cards")], "🔒"),
          ("sealed", "sealed products", [(1, "First sealed product"), (10, "10 sealed products")], "📦")]


def _facts(svc):
    v = svc.vault
    rows = _owned_rows(v)
    prog = _set_progress(v)
    value = v.conn.execute(f"SELECT COALESCE(SUM(l.qty*{pricepick.sql(v, lot='l')}),0) FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0", (v.user_id, v.game)).fetchone()[0]
    graded = v.conn.execute("SELECT COALESCE(SUM(qty),0) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND graded=1", (v.user_id, v.game)).fetchone()[0]
    try:
        sealed = v.conn.execute("SELECT COALESCE(SUM(qty),0) FROM u.sealed WHERE user_id=? AND game=? AND deleted=0", (v.user_id, v.game)).fetchone()[0]
    except Exception:  # noqa: BLE001
        sealed = 0
    return {"cards": sum(r["q"] for r in rows), "unique": len(rows), "started": len(prog), "finished": sum(1 for _, _, h, n in prog if h >= n and n >= 10), "value": round(value, 2), "graded": graded, "sealed": sealed}


def badges_for(svc):
    f = _facts(svc)
    out = []
    for key, unit, tiers, icon in _TIERS:
        for target, title in tiers:
            out.append({"id": f"{key}{target}", "title": title, "icon": icon, "done": f[key] >= target, "have": f[key], "target": target, "unit": unit})
    return out


@api("milestones.get", quiet=True)
def milestones(svc):
    b = badges_for(svc)
    nxt = {}
    for x in b:                                                          # the closest unfinished badge of each kind
        k = re.sub(r"\d+$", "", x["id"])
        if not x["done"] and k not in nxt:
            nxt[k] = x
    return {"badges": b, "done": sum(1 for x in b if x["done"]), "next": sorted(nxt.values(), key=lambda x: -(x["have"] / x["target"]))[:3], "facts": _facts(svc)}


@api("review.year", quiet=True)
def review_year(svc, year=None):
    """A year in numbers, from when each copy was added: how many, the best one, the busiest set and month."""
    import datetime
    v = svc.vault
    y = str(year or datetime.date.today().year)
    rows = v.conn.execute(f"SELECT l.card_id, l.qty, l.added, c.name, {pricepick.sql(v, lot='l')} AS price_usd, s.name AS set_name FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
                          "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND substr(COALESCE(l.added,''),1,4)=?", (v.user_id, v.game, y)).fetchall()
    cards = sum(r["qty"] for r in rows)
    best = max(rows, key=lambda r: r["price_usd"] or 0, default=None)
    sets = Counter()
    months = Counter()
    for r in rows:
        sets[r["set_name"] or "?"] += r["qty"]
        months[(r["added"] or "")[5:7]] += r["qty"]
    names = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    top_set = sets.most_common(1)
    top_month = months.most_common(1)
    first = min((r["added"] for r in rows if r["added"]), default=None)
    f = _facts(svc)
    return {"year": y, "game": svc.game.name, "cards": cards, "unique": len({r["card_id"] for r in rows}), "value": round(sum((r["price_usd"] or 0) * r["qty"] for r in rows), 2),
            "best": {"name": best["name"], "usd": best["price_usd"], "set": best["set_name"] or ""} if best and best["price_usd"] else None,
            "topSet": {"name": top_set[0][0], "n": top_set[0][1]} if top_set else None,
            "topMonth": {"name": names[int(top_month[0][0])], "n": top_month[0][1]} if top_month and top_month[0][0].isdigit() and 1 <= int(top_month[0][0]) <= 12 else None,
            "first": (first or "")[:10], "badges": sum(1 for b in badges_for(svc) if b["done"]), "total": f["cards"], "totalValue": f["value"], "setsDone": f["finished"]}


# ----------------------------------------------------------------------------------------------- compare sets
@api("compare.sets", quiet=True)
def compare_sets(svc, ids):
    """2 to 4 sets side by side: size, how much of each I own, what it is worth, and what finishing it would cost (from today's prices)."""
    v = svc.vault
    ids = [i for i in dict.fromkeys(ids or []) if v.conn.execute("SELECT 1 FROM sets WHERE id=?", (i,)).fetchone()][:4]
    if len(ids) < 2:
        raise ApiError("Pick at least two sets to compare.")
    owned = {r["card_id"]: r["q"] for r in _owned_rows(v)}
    out = []
    for sid in ids:
        s = v.conn.execute("SELECT id, name, serie, release_date FROM sets WHERE id=?", (sid,)).fetchone()
        cards = v.conn.execute(f"SELECT c.id, c.name, c.local_id, c.rarity, {pricepick.sql(v)} AS price_usd FROM cards c WHERE c.set_id=?", (sid,)).fetchall()
        have = [c for c in cards if owned.get(c["id"], 0) > 0]
        miss = [c for c in cards if owned.get(c["id"], 0) <= 0]
        total_val = sum(c["price_usd"] or 0 for c in cards)
        rar = Counter(c["rarity"] or "?" for c in cards)
        top_miss = sorted((c for c in miss if c["price_usd"]), key=lambda c: -c["price_usd"])[:3]
        out.append({"id": sid, "name": s["name"], "serie": s["serie"] or "", "date": s["release_date"] or "", "total": len(cards), "owned": len(have), "pct": round(100 * len(have) / len(cards), 1) if cards else 0,
                    "copies": sum(owned[c["id"]] for c in have), "valueOwned": round(sum((c["price_usd"] or 0) * owned[c["id"]] for c in have), 2), "setValue": round(total_val, 2),
                    "avg": round(total_val / len(cards), 2) if cards else 0, "costToFinish": round(sum(c["price_usd"] or 0 for c in miss), 2), "unpriced": sum(1 for c in miss if not c["price_usd"]),
                    "topMissing": [{"id": c["id"], "name": c["name"], "no": c["local_id"], "usd": c["price_usd"]} for c in top_miss], "rarities": [[k, n] for k, n in rar.most_common(3)]})
    return {"sets": out}


# ----------------------------------------------------------------------------------------------- compare with a friend
@api("compare.friend")
def compare_friend(svc, username):
    """My collection next to a friend's (only possible when they switched on 'my whole collection' or Full view): what we both own, what only one of us has, and set progress side by side."""
    from ..cloud import sharing as sh
    from .friends import _gk, _norm, friend_groups
    from .sharing import _acct, _call, pull
    a = _acct(svc)
    u = _norm(username)
    f = friend_groups(svc).get(u)
    if not f:
        raise ApiError("Their profile isn't on this device yet - open Friends once while online.")
    rows = _call(lambda: pull(svc, a, f[0], _gk(f[1])))
    gid = svc.game.id
    theirs = {d["id"]: d for (c, _), d in rows.items() if c == "coll" and d.get("gameId") == gid}
    wish = {d["id"] for (c, _), d in rows.items() if c == "wish" and d.get("gameId") == gid}
    if not theirs:
        return {"shared": False, "username": u}
    v = svc.vault
    mine = {r["card_id"]: r["q"] for r in _owned_rows(v)}
    my_wish = v.wishlist_ids()

    def card(cid, **more):
        c = v.card_light(cid) or {}
        d = theirs.get(cid) or {}
        return {"id": cid, "name": c.get("name") or d.get("name", cid), "set": c.get("set_name") or d.get("set", ""), "no": c.get("local_id") or d.get("no", ""), "usd": pricepick.price_for(v, cid, c.get("price_usd")), **more}
    both = [c for c in mine if c in theirs]
    only_m = [c for c in mine if c not in theirs]
    only_t = [c for c in theirs if c not in mine]
    their_q = {c: d.get("qty", 1) for c, d in theirs.items()}
    val = lambda ids, q: round(sum((pricepick.price_for(v, c, (v.card_light(c) or {}).get("price_usd")) or 0) * q.get(c, 1) for c in ids), 2)
    sets = {}
    for cid in set(mine) | set(theirs):
        c = v.card_light(cid)
        if not c:
            continue
        e = sets.setdefault(c.get("set_id"), {"name": c.get("set_name", ""), "mine": 0, "theirs": 0})
        e["mine"] += 1 if cid in mine else 0
        e["theirs"] += 1 if cid in theirs else 0
    totals = {r["id"]: r["n"] for r in v.sets()}
    set_rows = sorted(({"id": k, "name": e["name"], "mine": e["mine"], "theirs": e["theirs"], "total": totals.get(k, 0)} for k, e in sets.items() if k), key=lambda e: -(max(e["mine"], e["theirs"]) / max(1, e["total"])))[:10]
    return {"shared": True, "username": u, "game": svc.game.name, "mineCards": len(mine), "theirCards": len(theirs), "both": len(both), "onlyMine": len(only_m), "onlyTheirs": len(only_t),
            "valueMine": val(mine, mine), "valueTheirs": val(theirs, their_q), "valueOnlyMine": val(only_m, mine), "valueOnlyTheirs": val(only_t, their_q),
            "iHaveTheyLack": sorted((card(c, qty=mine[c]) for c in only_m), key=lambda x: -(x["usd"] or 0))[:12],
            "theyHaveILack": sorted((card(c, qty=their_q[c]) for c in only_t), key=lambda x: -(x["usd"] or 0))[:12],
            "theyWantIHave": [card(c) for c in wish if c in mine][:12], "iWantTheyHave": [card(c) for c in my_wish if c in theirs][:12], "sets": set_rows}
