"""Which items of a race are already in my portfolios (only ever SUGGESTED to tick, see races.py).

Three ways an item is found, from sure to careful:
  1. the item's own card (or one of the cards the checklist counts for it) is held - any language, condition, graded or not;
  2. the same, where the item wants one printing (Holo, Reverse Holo...): the lot's label is compared without caring about capitals or spaces, and a lot filed as "Other" or with no label counts when the card only
     comes in one printing (it can't be anything else);
  3. ANOTHER printing of the same card (the same card in a different set or a parallel art, by cardprintings.identity - name, number or artist as the game demands) when none of the race's own cards is held.
     Never when two items of the race are the same card (which one would it be?), and never for a list item that stands for several cards.  Shown as "(another printing)"."""
from .. import cardprintings
from ..checklists import card_variants
from ..db import VARIANT_LABELS

OTHER = " (another printing)"
_KNOWN = {" ".join(x.lower().split()) for x in VARIANT_LABELS.values()}


def _n(s):
    return " ".join(str(s or "").lower().split())


def _rows(conn, ids):
    ids = list(ids)
    for i in range(0, len(ids), 500):
        part = ids[i:i + 500]
        yield from conn.execute(f"SELECT id, name, local_id, hp, illustrator, set_id FROM cards WHERE id IN ({','.join('?' * len(part))})", part).fetchall()


def _ident(game, r):
    """What makes two cards the same card here.  Pokemon: name, HP and artist are not enough alone (the Unown letters, two Charizard ex of one set), so the printed number must be the same too and the cards must be in
    different sets (a reprint)."""
    i = cardprintings.identity(game, r["name"], r["local_id"], r["hp"], r["illustrator"])
    return i + (cardprintings.number_root(r["local_id"]),) if game in cardprintings.BY_ARTIST else i


def _fits(v, want, cid, var, single):
    """Does a lot with this printing label count for an item that wants the printing `want`?"""
    if not want:
        return True
    if _n(var) == _n(want):
        return True
    if _n(var) in _KNOWN:                       # a different, named printing: no
        return False
    if cid not in single:
        single[cid] = len(card_variants(v.card_light(cid) or {})) == 1
    return single[cid]


def where_owned(svc, d, label):
    """{item key: [portfolio labels]} for the race definition `d`.  `label(portfolio id)` gives the portfolio's name."""
    v = svc.vault
    rows = v.conn.execute("SELECT card_id, variant, COALESCE(portfolio,'') FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)).fetchall()
    by_card, single = {}, {}
    for cid, var, pf in rows:
        by_card.setdefault(cid, []).append((var, pf))
    items = [it for it in d.get("items") or [] if isinstance(it, dict) and it.get("k")]
    race_cards = {c for it in items for c in it.get("c") or []}
    out, loose = {}, []
    for it in items:
        pfs = []
        for cid in it.get("c") or []:
            for var, pf in by_card.get(cid, ()):
                if _fits(v, it.get("v"), cid, var, single) and pf not in pfs:
                    pfs.append(pf)
        if pfs:
            out[it["k"]] = sorted({label(p) for p in pfs}, key=str.lower)
        elif len(it.get("c") or []) == 1:
            loose.append(it)
    other = [c for c in by_card if c not in race_cards]
    if loose and other:
        game = v.game
        want, sets = {}, {}
        for r in _rows(v.conn, {c for it in items for c in it.get("c") or []}):
            want[r["id"]], sets[r["id"]] = _ident(game, r), r["set_id"]
        taken = {}
        for it in items:
            for cid in it.get("c") or []:
                if cid in want:
                    taken[want[cid]] = taken.get(want[cid], 0) + 1
        mine = {}
        for r in _rows(v.conn, other):
            mine.setdefault(_ident(game, r), []).append((r["id"], r["set_id"]))
        for it in loose:
            ident = want.get(it["c"][0])
            if not ident or not ident[0] or (game not in cardprintings.NAME_ONLY and not ident[-1]) or taken.get(ident) != 1:
                continue
            pfs = []
            for cid, sid in mine.get(ident, ()):
                if game in cardprintings.BY_ARTIST and sid == sets.get(it["c"][0]):
                    continue
                for var, pf in by_card[cid]:
                    if _fits(v, it.get("v"), cid, var, single) and pf not in pfs:
                        pfs.append(pf)
            if pfs:
                out[it["k"]] = sorted({label(p) + OTHER for p in pfs}, key=str.lower)
    return out
