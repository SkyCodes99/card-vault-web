"""IMPORT A LIST (Portfolios > Import a list, and Find & Add): a pasted list or a CSV / TSV file of products, how many and which portfolio (price paid and date when given).

listimport.read   the whole list at once -> each row matched (exact / several possible / none), its portfolio worked out, pictures and prices for the preview
listimport.find   a search by hand for one row that matched nothing
listimport.add    everything ticked, as ONE undoable change (copies, sealed products and any new portfolios) -> what went where

The column reading is cardvault/listimport.py; the card matching is the tracker import's own (cardvault/importers.py: set + number, name + number, name)."""
from .. import importers, listimport, rowundo, sealedclass
from ..db import CONDITIONS, BlockedPortfolio
from ..importers import _NOISE, name_ok, norm, norm_number
from ..tcgcsv import norm_name
from .cards import img, with_undo
from .registry import ApiError, api

MAX_ROWS = 5000
MAX_TEXT = 3_000_000
_LOOSE = ("Loose card / energy", "Code card", "Oversize / promo card")
_FALLBACK_SEARCHES = 120                    # rows that share no word with any card name get the app's own search (fuzzy, aliases); a cap keeps a long list of nonsense quick


def _sealed_rows(svc):
    from .devsealed import rows as fixed_rows                       # the sealed list with the owner's corrections, the same one Find & Add > Sealed shows
    try:
        return [r for r in (fixed_rows(svc) or []) if not r.get("hidden")]
    except Exception:  # noqa: BLE001 - a game with no sealed list
        return []


def _clean(name):
    import re
    return norm(re.sub(r"\s*[\(\[].*?[\)\]]\s*", " ", (name or "").split(" - ")[0]))


class _Finder:
    """What one import matches against, read once: the card list (by set + number, name + number, name and each word of a name) and the sealed list."""

    def __init__(self, svc):
        self.svc, self.v = svc, svc.vault
        self.m = importers.Matcher(self.v)
        self.words = {}
        for cid, (cn, _sn, _ln, _shown) in self.m.info.items():
            for w in set(norm(cn).split()) - _NOISE:
                self.words.setdefault(w, []).append(cid)
        self.sealed = _sealed_rows(svc)
        self.s_words, self.s_by_norm = {}, {}
        for k, r in enumerate(self.sealed):
            n = r.get("norm") or norm_name(r["name"])
            self.s_by_norm.setdefault(n, []).append(k)
            for w in set(n.split()):
                self.s_words.setdefault(w, []).append(k)
        self.searches = 0

    # ---- cards
    def card_opts(self, name, set_name, number, limit=6):
        """[(score, card id)] best first.  A name with the set's own words in it ('Charizard ex 151') counts as the name plus that set."""
        n, s, num = _clean(name), norm(set_name), norm_number(number)
        nw = set(n.split())
        keys = [w for w in nw if w not in _NOISE] or list(nw)
        pools = [self.words[w] for w in keys if w in self.words]
        if not pools:
            return []
        out = []
        for cid in min(pools, key=len)[:6000]:
            cn, sn, ln, _shown = self.m.info[cid]
            if not name_ok(name, cn):
                continue
            cw = set(norm(cn).split())
            rest = nw - cw
            score = 3 if not rest else (5 if rest <= (set(sn.split()) | {num, norm_number(ln)}) else 1)
            score -= min(2, len(cw - nw))                                 # 'Charizard ex' is a better answer to 'charizard ex' than 'Charizard ex Box Topper'
            if num and norm_number(ln) == num:
                score += 3
            if s and sn:
                score += 3 if s == sn else 1 if (s in sn or sn in s) else 0          # 'Base Set' is Base Set, ahead of Base Set 2 and Base Set (Shadowless)
            out.append((score, sn, cid))
        out.sort(key=lambda t: (-t[0], t[1]))
        return [(sc, cid) for sc, _sn, cid in out[:limit]]

    # ---- sealed products
    def sealed_opts(self, name, set_name="", limit=6):
        """[(score 0..1, index into self.sealed)] best first."""
        n = norm_name(name)
        if not n or not self.sealed:
            return []
        exact = self.s_by_norm.get(n, [])
        if exact:
            s = norm_name(set_name)
            same = [k for k in exact if s and norm_name(self.sealed[k].get("set") or "") == s] or exact
            return [(1.0, k) for k in same[:limit]]
        words = set(n.split())
        pools = [self.s_words[w] for w in words if w in self.s_words]
        if not pools:
            return []
        hay_s = set(norm_name(set_name).split())
        out = []
        pools.sort(key=len)
        for k in set(pools[0]) | set(pools[1] if len(pools) > 1 and len(pools[1]) < 3000 else ()):          # (the rarest words: a typo in one of them still finds it)
            r = self.sealed[k]
            have = set((r.get("norm") or norm_name(r["name"])).split()) | set(norm_name(r.get("set") or "").split())
            sc = len(words & have) / len(words | (have - hay_s))
            if len(words & have) >= max(1, round(len(words) * .6)):
                out.append((round(sc, 3), k))
        out.sort(key=lambda t: (-t[0], self.sealed[t[1]]["name"]))
        return out[:limit]

    def sealed_opt(self, k):
        r = self.sealed[k]
        return {"kind": "sealed", "id": str(r["id"]), "name": r["name"], "set": r.get("set") or "", "no": "", "price": r.get("price"), "pic": r.get("img") or ""}

    # ---- one row
    def match(self, row):
        """-> (status 'exact' | 'choose' | 'none', why, [options: card ids (str) or sealed dicts])."""
        v = self.v
        name, set_name, number = row["name"], row["set"], row["number"]
        if row.get("game") and importers._other_game(row["game"], v.game):
            return "none", f"This row is for {row['game']} - open that game at the top and import these rows there", []
        if not name and not number:
            return "none", "This row has no product name", []
        sealedish = bool(self.sealed) and bool(name) and not number and sealedclass.kind_of(name, v.game) not in _LOOSE
        s_opts = self.sealed_opts(name, set_name) if sealedish else []
        if s_opts and s_opts[0][0] == 1.0 and (len(s_opts) == 1 or s_opts[1][0] < 1.0):
            return "exact", "", [self.sealed_opt(s_opts[0][1])]
        cid, _why = self.m.find(name, set_name, number)
        if cid and not s_opts:
            return "exact", "", [cid]
        c_opts = self.card_opts(name, set_name, number) if name else []
        if c_opts and not s_opts and c_opts[0][0] >= 5 and (len(c_opts) == 1 or c_opts[1][0] < c_opts[0][0]):
            return "exact", "", [c_opts[0][1]]
        opts = [self.sealed_opt(k) for _, k in s_opts] + [c for _, c in c_opts]
        if cid and cid not in opts:
            opts.insert(0, cid)
        if not opts and name and not sealedish and self.sealed and not number:
            opts = [self.sealed_opt(k) for _, k in self.sealed_opts(name, set_name)]
        if not opts and name and self.searches < _FALLBACK_SEARCHES:
            self.searches += 1
            try:
                opts = [r[0] for r in v.query_cards(text=f"{name} {set_name} {number}".strip(), sort="default")[:6]]
            except Exception:  # noqa: BLE001 - the card index is still being worked out: the row is left for a search by hand
                opts = []
        if not opts:
            return "none", "Nothing in this game's list matches - search for it by hand, or leave it out", []
        return "choose", "", opts[:6]

    def card_opt(self, cid, lights):
        c = lights.get(cid) or {}
        return {"kind": "card", "id": cid, "name": c.get("name", cid), "set": c.get("set_name") or "", "no": c.get("local_id") or "", "price": c.get("price_usd"), "pic": img(cid, c.get("set_id") or "")}

    def fill(self, opts_lists):
        """Card ids -> option dicts (one read of the card list for all of them)."""
        ids = [o for opts in opts_lists for o in opts if isinstance(o, str)]
        lights = self.v.card_lights(ids) if ids else {}
        return [[self.card_opt(o, lights) if isinstance(o, str) else o for o in opts] for opts in opts_lists]


def _destinations(svc):
    from .portfolios import pf_list
    st = pf_list(svc)
    pfs = [{"id": p["id"], "name": p["name"], "icon": p.get("icon") or "", "depth": p.get("depth") or 0, "accepts": p.get("accepts") or "all"} for p in st["portfolios"]]
    return pfs, st.get("target") or "main"


def _pf_for(name, pfs):
    """A portfolio name in the list -> one of mine ('same' or a close spelling), or 'new:<name>' (made when the list is added), or '' (none given: the default)."""
    key = (name or "").strip()
    if not key:
        return "", ""
    usable = [{"uuid": p["id"], "name": p["name"]} for p in pfs if p["accepts"] != "none"]
    uid, how = importers.best_portfolio(key, usable)
    if uid:
        return uid, how
    if norm(key) == "main":
        return "main", "same"
    return "new:" + key[:80], "new"


@api("listimport.read", quiet=True)
def read(svc, text, mapping=None):
    """Read a list -> {columns, header, rows: [{..fields, status, why, options, pick, pf}], portfolios, target, counts, plan}."""
    v = svc.vault
    text = text or ""
    if len(text) > MAX_TEXT:
        raise ApiError("That list is too long for one go - split it into smaller files (up to 5,000 rows each).")
    pfs, target = _destinations(svc)
    t = listimport.read_table(text, mapping, [p["name"] for p in pfs], [s["name"] for s in v.sets()])
    rows = t["rows"][:MAX_ROWS]
    f = _Finder(svc)
    matched = [f.match(r) for r in rows]
    opts = f.fill([m[2] for m in matched])
    names = {p["id"]: p["name"] for p in pfs}
    out, counts = [], {"exact": 0, "choose": 0, "none": 0}
    for r, (status, why, _o), o in zip(rows, matched, opts):
        pf, how = _pf_for(r["portfolio"], pfs)
        counts[status] += 1
        out.append({**r, "status": status, "why": why, "options": o, "pick": 0 if status == "exact" else -1, "pf": pf, "pfHow": how})
    chosen = [{"pf": x["pf"] or target, "qty": x["qty"], "paid": x["paid"], "price": x["options"][0]["price"]} for x in out if x["status"] == "exact"]
    return {"columns": t["columns"], "header": t["header"], "delimiter": t["delimiter"], "fields": [[k, listimport.LABELS[k]] for k in ("",) + listimport.FIELDS],
            "rows": out, "more": max(0, len(t["rows"]) - MAX_ROWS), "portfolios": [p for p in pfs if p["accepts"] != "none"], "target": target, "counts": counts,
            "newPortfolios": sorted({x["pf"][4:] for x in out if x["pf"].startswith("new:")}), "plan": listimport.plan(chosen, names)}


@api("listimport.find", quiet=True)
def find(svc, q):
    """A search by hand for one row: the cards and sealed products that match `q` (pictures and prices included)."""
    q = (q or "").strip()
    if not q:
        return {"options": []}
    f = _Finder(svc)
    c = [cid for _, cid in f.card_opts(q, "", "", 8)]
    if len(c) < 8:
        try:
            c += [r[0] for r in svc.vault.query_cards(text=q, sort="default")[:8] if r[0] not in c]
        except Exception:  # noqa: BLE001
            pass
    s = [f.sealed_opt(k) for _, k in f.sealed_opts(q, "", 6)]
    return {"options": f.fill([s + c[:8]])[0]}


@api("listimport.add", mutates=True)
def add(svc, items, label=None):
    """Add what was ticked: items = [{kind 'card' | 'sealed', id, qty, cond?, paid?, date?, pf ('main' | a portfolio id | 'new:<name>')}].
    ONE undoable change: Undo takes back every copy and sealed product and removes the portfolios it made.  Nothing is added unless all of it can be.
    -> {added (copies), items, portfolios: [{id, name, items, copies, paid, value}], undo}"""
    v = svc.vault
    items = [it for it in (items or [])[:MAX_ROWS] if isinstance(it, dict) and it.get("id")]
    if not items:
        raise ApiError("Nothing is ticked to add.")
    pfs, _target = _destinations(svc)
    ids = {p["id"] for p in pfs}
    sealed = {str(r["id"]): r for r in _sealed_rows(svc)} if any(it.get("kind") == "sealed" for it in items) else {}
    lights = v.card_lights([it["id"] for it in items if it.get("kind") != "sealed"])
    clean = []
    for it in items:                                                     # check all of it first
        kind = "sealed" if it.get("kind") == "sealed" else "card"
        if kind == "sealed" and str(it["id"]) not in sealed:
            raise ApiError("One of the sealed products isn't in this game's list any more - read the list again.")
        if kind == "card" and it["id"] not in lights:
            raise ApiError("One of the cards isn't in this game's list - is the right game open at the top?")
        pf = str(it.get("pf") or "main")
        if pf.startswith("new:"):
            if not pf[4:].strip():
                raise ApiError("A new portfolio needs a name.")
        elif pf not in ids:
            raise ApiError("One of the chosen portfolios doesn't exist any more - pick another one.")
        else:
            try:
                v.check_accepts("" if pf == "main" else pf, "sealed" if kind == "sealed" else v.item_kind())
            except BlockedPortfolio as e:
                raise ApiError(str(e))
        paid = it.get("paid")
        try:
            paid = None if paid in (None, "") else round(float(paid), 2)
        except (TypeError, ValueError):
            paid = None
        cond = it.get("cond") if it.get("cond") in CONDITIONS else "Near Mint"
        clean.append({"kind": kind, "id": str(it["id"]), "qty": max(1, min(int(it.get("qty") or 1), 99999)), "paid": paid, "date": listimport.parse_date(it.get("date")), "cond": cond, "pf": pf})
    made = {}

    def pf_id(pf):
        if not pf.startswith("new:"):
            return "" if pf == "main" else pf
        name = pf[4:].strip()[:80]
        if name.lower() not in made:
            have = next((p["id"] for p in pfs if p["name"].strip().lower() == name.lower() and p["accepts"] != "none" and p["id"] != "main"), None)
            made[name.lower()] = have or v.create_portfolio(name)
        return made[name.lower()]

    def run():
        from .extras import sealed_save
        for it in clean:
            pid = pf_id(it["pf"])
            if it["kind"] == "sealed":
                sealed_save(svc, sealed[it["id"]]["name"], qty=it["qty"], paid=it["paid"], purchased=it["date"], portfolio=pid or "main")
            else:
                v.add_lot(it["id"], v.default_variant(it["id"]), it["cond"], it["qty"], False, "", "", it["paid"], "", "English", purchased=it["date"], portfolio=pid)
        v.record_price_history(list({it["id"] for it in clean if it["kind"] == "card"}))

    n = sum(it["qty"] for it in clean)
    what = label or f"Imported a list ({n} item{'' if n == 1 else 's'})"
    out = with_undo(svc, lambda: rowundo.track(v, what, [("portfolios", "user_id=?", (v.user_id,)), ("sealed", "user_id=? AND game=?", (v.user_id, v.game))], run))
    names = {p["id"]: p["name"] for p in pfs}
    for key, uid in made.items():
        names[uid] = next((it["pf"][4:].strip() for it in clean if it["pf"].lower() == "new:" + key), key)
    price = lambda it: (sealed[it["id"]].get("price") if it["kind"] == "sealed" else (lights.get(it["id"]) or {}).get("price_usd"))
    summary = listimport.plan([{"pf": (pf_id(it["pf"]) or "main"), "qty": it["qty"], "paid": it["paid"], "price": price(it)} for it in clean], names)
    return {"added": n, "items": len(clean), "portfolios": [{**p, "id": p["pf"]} for p in summary], "made": len(made), "undo": out.get("undo")}
