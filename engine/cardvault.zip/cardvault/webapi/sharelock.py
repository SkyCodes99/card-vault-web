"""Protect a share link: an optional password and/or a list of usernames who must be signed in to see it.  Protocol and what the account server must do: docs/skycloud_request_share_protect.md.

The password is typed in the app, sent once over HTTPS to the account server (which hashes it) and is never kept on this device, never put in a link and never put in the page.  This device remembers only
THAT a password is set and the list of usernames (opts.lock on the link record).  Old links stay open.  When the server does not know this yet, `sharelock.status` says available:false and the screens show nothing."""
import re
import time

from ..cloud import skycloud as sc
from .accountapi import account
from .registry import ApiError, api

CAP_FOR = 600                                   # seconds a "the server supports it" answer is trusted
NAME_OK = re.compile(r"^[a-z0-9._-]{3,24}$")
MAX_ALLOW, MIN_PW, MAX_PW = 50, 4, 200
KINDS = ("missing", "gifts", "wishview")        # the link kinds of sharepages.py / wishlistapi.py


def available(svc):
    """True when this device has an account AND the account server can protect links (asked at most every CAP_FOR seconds; never raises)."""
    a = account(svc)
    if a is None:
        return False
    at, ok = getattr(svc, "_lock_cap", (0, False))
    if time.time() - at < CAP_FOR:
        return ok
    try:
        ok = bool((a.call("GET", "/v1/pages/protect/status", None, timeout=15) or {}).get("enabled"))
    except Exception:  # noqa: BLE001 - an older server (404), offline, anything: the options stay hidden
        ok = False
    svc._lock_cap = (time.time(), ok)
    return ok


def clean(lock):
    """Check what the screen sent.  -> (body for the server, what this device keeps) - or (None, None) when nothing changes.
    lock = {password?: text, clear_password?: true, allow?: [usernames] ([] = anyone may look again)}; a key that is missing stays as it is."""
    if not lock:
        return None, None
    if not isinstance(lock, dict):
        raise ApiError("That protection choice isn't valid.")
    body, keep = {}, {}
    pw = lock.get("password")
    if pw:
        if not isinstance(pw, str) or not MIN_PW <= len(pw) <= MAX_PW:
            raise ApiError(f"The password needs {MIN_PW} to {MAX_PW} characters.")
        body["password"], keep["password"] = pw, True
    elif lock.get("clear_password"):
        body["clear_password"], keep["password"] = True, False
    if lock.get("allow") is not None:
        names = []
        for n in lock["allow"] if isinstance(lock["allow"], list) else []:
            n = str(n).strip().lstrip("@").lower()
            if not NAME_OK.match(n):
                raise ApiError(f"'{n}' isn't a username.")
            if n not in names:
                names.append(n)
        if len(names) > MAX_ALLOW:
            raise ApiError(f"You can pick up to {MAX_ALLOW} people.")
        body["allow"], keep["allow"] = names, names
    return (body or None), (keep or None)


def merge(old, keep):
    """The lock record this device keeps after a change: {password: bool, allow: [usernames]}."""
    out = {"password": bool((old or {}).get("password")), "allow": list((old or {}).get("allow") or [])}
    out.update(keep or {})
    return out


def need_server(svc):
    if not available(svc):
        raise ApiError("Protecting links isn't switched on yet.")


def explain(e):
    """A CloudError from a protection call as one plain sentence."""
    if e.status == 404:
        return "That link isn't on the server any more - make it again."
    return str(e)


@api("sharelock.status", quiet=True)
def status(svc):
    """{available} - the screens show the password / people choices only when this is true."""
    return {"available": available(svc)}


@api("sharelock.set", mutates=True)
def set_lock(svc, kind, lock):
    """Change or remove the protection of a link that already exists (no need to update the page)."""
    from . import sharepages
    if kind not in KINDS:
        raise ApiError("Unknown link.")
    body, keep = clean(lock)
    if body is None:
        return {"lock": None}
    need_server(svc)
    pages, k = sharepages._pages(svc), sharepages._key(svc, kind)
    cur = pages.get(k)
    if not cur:
        raise ApiError("Make the link first.")
    try:
        account(svc, need=True).call("PUT", "/v1/pages/" + cur["token"] + "/protect", body, timeout=30)
    except sc.CloudError as e:
        raise ApiError(explain(e))
    cur.setdefault("opts", {})["lock"] = merge((cur.get("opts") or {}).get("lock"), keep)
    sharepages._save_pages(svc, pages)
    return {"lock": cur["opts"]["lock"]}
