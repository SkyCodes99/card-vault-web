"""Public pages made from your collection: "what I'm missing" (one set, several sets, or a goal) and the gift wishlist.  Both are published through your Collect Em All account as a link anyone can
open (no account needed to read), can be refreshed (the same link) and revoked (the link stops working at once).  The pages hold only what you choose: names, numbers and pictures; prices only if you tick
them; never quantities, notes or what you paid.  Shared pages run in a sandbox (no storage, no navigation) - they use the address fragment for anything they remember."""
import csv
import datetime
import html as H
import io
import json
import re

from .registry import ApiError, api

PAGES = "public_pages"                                          # {"<game>|<kind>": {token, url, title, updated, opts}}
ID_OK = re.compile(r"[^A-Za-z0-9_.:\-]")


def _pages(svc):
    try:
        return json.loads(svc.pget(PAGES) or "{}")
    except ValueError:
        return {}


def _save_pages(svc, pages):
    svc.pset(PAGES, json.dumps(pages))


def _key(svc, kind):
    return f"{svc.game.id}|{kind}"


def _publish(svc, kind, title, html_text, opts, lock=None):
    """Publish or refresh the link.  `lock` (see sharelock.py) is the optional password / people choice; it travels in the same call so a new link is never open for a moment.  Without it, an existing lock stays."""
    from ..cloud import skycloud as sc
    from . import accountapi, sharelock
    a = accountapi.account(svc, need=True)
    body = {"title": title, "html": html_text}
    pages, k = _pages(svc), _key(svc, kind)
    cur = pages.get(k)
    send, keep = sharelock.clean(lock)
    if send:
        sharelock.need_server(svc)
        body["protect"] = send
    try:
        out = None
        if cur:
            try:
                r = a.call("PUT", "/v1/pages/" + cur["token"], body, timeout=120)
                out = {"token": cur["token"], "url": r.get("url") or cur["url"]}
            except sc.CloudError as e:
                if e.status != 404:                              # 404: the page was removed on the server - make a new link
                    raise
        if out is None:
            out = a.call("POST", "/v1/pages", body, timeout=120)
    except sc.CloudError as e:
        raise ApiError(str(e))
    old = ((cur or {}).get("opts") or {}).get("lock") if cur and cur.get("token") == out["token"] else None
    opts = {**opts, **({"lock": sharelock.merge(old, keep)} if (old or keep) else {})}
    pages[k] = {"token": out["token"], "url": out["url"], "title": title, "updated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "opts": opts}
    svc.pset(PAGES, json.dumps(pages))
    return pages[k]


def _revoke(svc, kind):
    from ..cloud import skycloud as sc
    from . import accountapi
    a = accountapi.account(svc, need=True)
    pages, k = _pages(svc), _key(svc, kind)
    cur = pages.pop(k, None)
    if cur:
        try:
            a.call("DELETE", "/v1/pages/" + cur["token"])
        except sc.CloudError as e:
            if e.status != 404:
                pages[k] = cur
                raise ApiError(str(e))
        svc.pset(PAGES, json.dumps(pages))
    return {"page": None}


# ------------------------------------------------------------------------------------------------ what I'm missing
def _theme_missing(v, g):
    """The missing cards of an 'own every <name>' goal, or - for a Pokédex-range goal - one (cheapest) card for each Pokémon you still need -> [card id]."""
    from .goals import _dex_range
    owned = set(v.owned_map().keys())
    if g["type"] == "name":
        like = "%" + str(g["key"]).replace("%", "").replace("_", "") + "%"
        return [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE name LIKE ? ORDER BY sort_key", (like,)) if r[0] not in owned]
    a, b = _dex_range(g["key"])
    cheapest, have = {}, set()
    for cid, dex, price in v.conn.execute("SELECT id, dex, price_usd FROM cards WHERE dex IS NOT NULL AND dex<>''"):
        try:
            n = int(str(dex).split(",")[0])
        except ValueError:
            continue
        if not a <= n <= b:
            continue
        if cid in owned:
            have.add(n)
        if price is not None and (n not in cheapest or price < cheapest[n][0]):
            cheapest[n] = (price, cid)
    return [cid for n, (_p, cid) in sorted(cheapest.items()) if n not in have]


def missing_groups(svc, set_ids=(), goal_ids=(), price=False):
    """Missing cards grouped for display: [{title, have, total, cards:[{id, name, number, rarity, img, price?}]}]."""
    from . import goals as G
    v = svc.vault
    owned = set(v.owned_map().keys())
    groups = []

    def card(cid, extra=None):
        c = v.card_light(cid) or {}
        d = {"id": cid, "name": c.get("name", cid), "number": c.get("local_id", ""), "rarity": c.get("rarity") or "", "set": c.get("set_name", ""), "img": svc.remote_image(cid, "low")}
        if price and c.get("price_usd") is not None:
            d["price"] = round(c["price_usd"], 2)
        return d
    chosen = list(dict.fromkeys(set_ids or ()))
    mine = {g["id"]: g for g in G._all(svc) if g.get("game") == v.game}
    for gid in goal_ids or ():
        g = mine.get(gid)
        if not g:
            continue
        if g["type"] == "set":
            if g["key"] not in chosen:
                chosen.append(g["key"])
        elif g["type"] in ("name", "dex"):
            ids = _theme_missing(v, g)
            total = G._theme_progress(v, g)[1]
            groups.append({"title": g["name"], "have": total - len(ids), "total": total, "cards": [card(i) for i in ids]})
    sets = {s["id"]: s for s in v.sets()}
    for sid in chosen:
        s = sets.get(sid)
        if not s:
            continue
        miss = [c["id"] for c in v.conn.execute("SELECT id FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (sid,)) if c["id"] not in owned]
        groups.append({"title": s["name"], "have": (s["n"] or 0) - len(miss), "total": s["n"] or 0, "cards": [card(i) for i in miss]})
    return groups


@api("missing.preview")
def missing_preview(svc, set_ids=None, goal_ids=None, price=False):
    g = missing_groups(svc, set_ids or [], goal_ids or [], bool(price))
    return {"groups": [{"title": x["title"], "have": x["have"], "total": x["total"], "missing": len(x["cards"])} for x in g], "missing": sum(len(x["cards"]) for x in g)}


def _missing_text(groups, price):
    out = []
    for g in groups:
        out.append(f"{g['title']} - missing {len(g['cards'])} of {g['total']}")
        for c in g["cards"]:
            out.append(f"  #{c['number']} {c['name']}" + (f" (${c['price']:.2f})" if price and c.get("price") is not None else ""))
        out.append("")
    return "\n".join(out).strip()


@api("missing.text")
def missing_text(svc, set_ids=None, goal_ids=None, price=False):
    g = missing_groups(svc, set_ids or [], goal_ids or [], bool(price))
    if not any(x["cards"] for x in g):
        raise ApiError("Nothing is missing there - or nothing was chosen.")
    return {"text": _missing_text(g, bool(price))}


MISSING_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>__TITLE__</title><style>
:root{color-scheme:light dark;--bg:#f5f7fb;--card:#fff;--ink:#1a2236;--mute:#6b7488;--acc:#4a7cff;--line:#dfe5f0}
@media(prefers-color-scheme:dark){:root{--bg:#0e1220;--card:#1a2136;--ink:#e9edf7;--mute:#98a2bb;--line:#2a3350}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}
header{padding:28px 20px;text-align:center;background:linear-gradient(135deg,#2a4fb8,#8a4fd1);color:#fff}header h1{margin:0 0 4px;font-size:26px}header p{margin:0;opacity:.9}
main{max-width:1000px;margin:0 auto;padding:18px}h2{margin:26px 0 4px}.sub{color:var(--mute);margin-bottom:10px}
.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px}.c{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:8px}
.c img{width:100%;aspect-ratio:63/88;object-fit:contain;border-radius:8px;background:var(--bg)}.n{font-weight:650;margin-top:4px;font-size:13px}.s{color:var(--mute);font-size:12px}.v{font-weight:700}
footer{text-align:center;color:var(--mute);padding:22px;font-size:13px}@media print{header{background:none;color:#000}.c{break-inside:avoid}}
</style></head><body><header><h1 id="t"></h1><p id="b"></p></header><main id="m"></main><footer>Made with Collect Em All &middot; updated <span id="u"></span></footer>
<script>var D=__DATA__;var esc=function(s){var d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML};
document.getElementById('t').textContent=D.title;document.getElementById('b').textContent=(D.owner?D.owner+' is missing ':'Missing ')+D.total.toLocaleString()+' card'+(D.total===1?'':'s');document.getElementById('u').textContent=D.updated;
var h='';D.groups.forEach(function(g){h+='<h2>'+esc(g.title)+'</h2><div class="sub">'+g.have.toLocaleString()+' of '+g.total.toLocaleString()+' owned &middot; missing '+g.cards.length.toLocaleString()+'</div><div class="g">'+
g.cards.map(function(c){return '<div class="c">'+(c.img?'<img loading="lazy" alt="'+esc(c.name)+'" src="'+esc(c.img)+'">':'')+'<div class="n">'+esc(c.name)+'</div><div class="s">#'+esc(c.number)+(c.rarity?' &middot; '+esc(c.rarity):'')+'</div>'+(c.price!=null?'<div class="v">$'+Number(c.price).toFixed(2)+'</div>':'')+'</div>'}).join('')+'</div>'});
document.getElementById('m').innerHTML=h||'<p class="sub">Nothing is missing - the collection is complete!</p>';</script></body></html>"""


def missing_page(svc, groups, title):
    payload = {"title": title, "owner": (svc.pget("cloud_username") or "") if svc.pget("cloud_token") else "", "updated": datetime.date.today().isoformat(),
               "total": sum(len(g["cards"]) for g in groups), "groups": groups}
    data = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    return MISSING_PAGE.replace("__TITLE__", H.escape(title)).replace("__DATA__", data)


@api("missing.status", quiet=True)
def missing_status(svc):
    return {"page": _pages(svc).get(_key(svc, "missing"))}


@api("missing.publish")
def missing_publish(svc, set_ids=None, goal_ids=None, price=False, title="", lock=None):
    """Publish (or refresh, same link) the list of what is missing from the chosen sets / goals."""
    groups = missing_groups(svc, set_ids or [], goal_ids or [], bool(price))
    if not groups:
        raise ApiError("Pick at least one set or goal first.")
    title = (title or "").strip() or ("What I'm missing - " + groups[0]["title"] + (f" +{len(groups) - 1} more" if len(groups) > 1 else ""))
    page = _publish(svc, "missing", title, missing_page(svc, groups, title), {"set_ids": set_ids or [], "goal_ids": goal_ids or [], "price": bool(price), "title": title}, lock)
    return {"page": page, "missing": sum(len(g["cards"]) for g in groups)}


@api("missing.refresh")
def missing_refresh(svc):
    """Update the published link with today's collection, using the same choices as last time."""
    cur = _pages(svc).get(_key(svc, "missing"))
    if not cur:
        raise ApiError("There is no link to refresh yet.")
    o = cur.get("opts") or {}
    return missing_publish(svc, o.get("set_ids"), o.get("goal_ids"), o.get("price"), o.get("title") or "")


@api("missing.revoke")
def missing_revoke(svc):
    return _revoke(svc, "missing")


@api("data.exportMissing")
def export_missing(svc, path, kind="csv", set_ids=None, goal_ids=None, price=False):
    """Save the missing list as a spreadsheet (csv), plain text (txt) or a printable web page (html)."""
    svc.need_grant(path)
    groups = missing_groups(svc, set_ids or [], goal_ids or [], bool(price))
    if not any(g["cards"] for g in groups):
        raise ApiError("Nothing is missing there - or nothing was chosen.")
    if kind == "html":
        text = missing_page(svc, groups, "What I'm missing")
    elif kind == "txt":
        text = _missing_text(groups, bool(price))
    else:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["list", "number", "name", "set", "rarity"] + (["price"] if price else []))
        for g in groups:
            for c in g["cards"]:
                w.writerow([g["title"], c["number"], c["name"], c["set"], c["rarity"]] + ([c.get("price", "")] if price else []))
        text = buf.getvalue()
    with open(path, "w", encoding="utf-8-sig" if kind == "csv" else "utf-8", newline="") as f:
        f.write(text)
    return {"lines": sum(len(g["cards"]) for g in groups)}


# ------------------------------------------------------------------------------------------------ gift wishlist
GIFT_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>__TITLE__</title><style>
:root{color-scheme:light dark;--bg:#f7f3fb;--card:#fff;--ink:#241a36;--mute:#756a8c;--acc:#8a4fd1;--line:#e5dcf0;--ok:#2f9a6a}
@media(prefers-color-scheme:dark){:root{--bg:#150f22;--card:#211735;--ink:#efe9fb;--mute:#a79cc0;--line:#35294f}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}
header{padding:28px 20px;text-align:center;background:linear-gradient(135deg,#8a4fd1,#d14f9a);color:#fff}header h1{margin:0 0 4px;font-size:26px}header p{margin:0;opacity:.92}
main{max-width:1000px;margin:0 auto;padding:18px}.note{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 14px;margin-bottom:14px}
.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}.c{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px;display:flex;flex-direction:column;gap:4px}
.c img{width:100%;aspect-ratio:63/88;object-fit:contain;border-radius:8px;background:var(--bg)}.n{font-weight:650}.s{color:var(--mute);font-size:12px}.v{font-weight:700}
button{font:inherit;border:0;border-radius:10px;padding:8px 10px;background:var(--acc);color:#fff;cursor:pointer;margin-top:auto}button.mine{background:var(--ok)}button[disabled]{background:var(--line);color:var(--mute);cursor:default}
.tag{font-size:13px;color:var(--mute);margin-top:auto;padding:8px 0}footer{text-align:center;color:var(--mute);padding:22px;font-size:13px}
</style></head><body><header><h1 id="t"></h1><p id="b"></p></header><main><div class="note" id="note"></div><div class="g" id="g"></div></main><footer>Made with Collect Em All</footer>
<script>var D=__DATA__;var T=location.pathname.split('/').filter(Boolean).pop();var OWNER=location.hash.indexOf('owner')>=0;
var esc=function(s){var d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML};
function meId(){var m=location.hash.match(/me=([A-Za-z0-9_-]{16,40})/);if(m)return m[1];var a=new Uint8Array(13),id='';try{crypto.getRandomValues(a)}catch(e){for(var i=0;i<13;i++)a[i]=Math.random()*256}
for(var j=0;j<a.length;j++)id+=('0'+a[j].toString(16)).slice(-2);try{history.replaceState(null,'','#me='+id)}catch(e){try{location.hash='me='+id}catch(e2){}}return id}
var ME=OWNER?'':meId(),state={};
var UN=(document.querySelector('meta[name=page-unlock]')||{}).content||'',HD=function(h){h=h||{};if(UN)h['X-Page-Unlock']=UN;return h};
document.getElementById('t').textContent=D.title;document.getElementById('b').textContent=(D.owner?D.owner+"'s wishlist":'Wishlist');
document.getElementById('note').textContent=OWNER?'Owner preview: nobody sees who is buying what, and this page hides the marks from you so the surprise stays a surprise.':(D.note||'Pick something you would like to give and press "I\\'m buying this" so nobody doubles up. Only you will know it is you.');
function draw(){document.getElementById('g').innerHTML=D.items.map(function(c){var st=state[c.id];var btn='';
if(!OWNER){if(st==='taken')btn='<div class="tag">Someone is already getting this</div>';else if(st==='mine')btn='<button class="mine" data-i="'+esc(c.id)+'" data-a="release">&#10003; I\\'m buying this (tap to undo)</button>';else btn='<button data-i="'+esc(c.id)+'" data-a="claim">I\\'m buying this</button>'}
return '<div class="c">'+(c.img?'<img loading="lazy" alt="'+esc(c.name)+'" src="'+esc(c.img)+'">':'')+'<div class="n">'+esc(c.name)+'</div><div class="s">'+esc(c.set)+(c.number?' &middot; #'+esc(c.number):'')+'</div>'+(c.price!=null?'<div class="v">about $'+Number(c.price).toFixed(2)+'</div>':'')+btn+'</div>'}).join('')||'<p>The wishlist is empty.</p>'}
function load(){if(OWNER){draw();return}fetch('/v1/gifts/'+T+'?me='+ME,{headers:HD()}).then(function(r){return r.json()}).then(function(j){state=j.items||{};draw()}).catch(function(){draw()})}
document.getElementById('g').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var item=b.getAttribute('data-i'),a=b.getAttribute('data-a');b.disabled=true;
fetch('/v1/gifts/'+T+'/'+a,{method:'POST',headers:HD({'Content-Type':'application/json'}),body:JSON.stringify({item:item,me:ME})}).then(function(r){if(r.status===409){state[item]='taken'}else if(r.ok){if(a==='claim')state[item]='mine';else delete state[item]}draw()}).catch(function(){draw()})});
load();</script></body></html>"""


def gift_payload(svc, price=False, title="", note=""):
    v = svc.vault
    items = []
    for cid in sorted(v.wishlist_ids()):
        c = v.card_light(cid)
        if not c:
            continue
        d = {"id": ID_OK.sub("_", str(cid))[:80], "name": c.get("name", cid), "set": c.get("set_name", ""), "number": c.get("local_id", ""), "img": svc.remote_image(cid, "low")}
        if price and c.get("price_usd") is not None:
            d["price"] = round(c["price_usd"], 2)
        items.append(d)
    owner = (svc.pget("cloud_username") or "") if svc.pget("cloud_token") else ""
    return {"title": title or "My wishlist", "owner": owner, "note": (note or "")[:300], "items": items}


@api("gifts.status", quiet=True)
def gifts_status(svc):
    return {"page": _pages(svc).get(_key(svc, "gifts")), "count": len(svc.vault.wishlist_ids())}


@api("gifts.publish")
def gifts_publish(svc, price=False, title="", note="", lock=None):
    """Publish (or refresh, same link) the wishlist as a gift list relatives can open without an account and quietly mark 'I'm buying this'.  Who marked what is never shown to you."""
    p = gift_payload(svc, bool(price), (title or "").strip(), note)
    if not p["items"]:
        raise ApiError("Your wishlist is empty - add some cards to it first (the heart on a card).")
    data = json.dumps(p, ensure_ascii=False).replace("</", "<\\/")
    page = GIFT_PAGE.replace("__TITLE__", H.escape(p["title"])).replace("__DATA__", data)
    return {"page": _publish(svc, "gifts", p["title"], page, {"price": bool(price), "title": title or "", "note": note or ""}, lock), "items": len(p["items"])}


@api("gifts.refresh")
def gifts_refresh(svc):
    cur = _pages(svc).get(_key(svc, "gifts"))
    if not cur:
        raise ApiError("There is no gift list to refresh yet.")
    o = cur.get("opts") or {}
    return gifts_publish(svc, o.get("price"), o.get("title") or "", o.get("note") or "")


@api("gifts.revoke")
def gifts_revoke(svc):
    return _revoke(svc, "gifts")
