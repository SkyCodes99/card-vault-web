"""The goal of each set (Standard / Master / Extra) and what finishing a set at that goal takes - see cardvault/completion.py (the counting) and cardvault/setgoals.py (what is saved and synced)."""
from .. import completion, setgoals
from .registry import ApiError, api


def _set_exists(svc, set_id):
    if not svc.vault.conn.execute("SELECT 1 FROM sets WHERE id=?", (set_id,)).fetchone():
        raise ApiError("set not found")


@api("set.goals")
def goals(svc):
    """The goals this game offers, their names and the goal picked for each set ({set id: goal}; sets without a pick are not in it)."""
    ok = completion.allowed(svc.game)
    return {"allowed": list(ok), "names": {g: completion.LABELS[g] for g in ok}, "picked": {s: g for s, g in setgoals.load(svc.vault).items() if g in ok}}


@api("set.goal.set", mutates=True)
def goal_set(svc, set_id, goal=""):
    """Pick the goal of one set (goal "" = back to the default)."""
    _set_exists(svc, set_id)
    if goal and goal not in completion.allowed(svc.game):
        raise ApiError("This game does not have that goal.")
    setgoals.save(svc.vault, set_id, goal)
    return {"ok": True, "setId": set_id, "goal": goal or None}


@api("set.completion")
def set_completion(svc, set_id, goal="", extra_kinds=None, patterns=False, full=False):
    """What finishing one set takes at a goal (the picked one when none is asked): required / owned / missing (ids and count) / % and the price of the missing part (`missingCost` in US dollars,
    `unpriced` = how many missing ones have no price yet).  `full` also lists every required id."""
    _set_exists(svc, set_id)
    goal = _goal_of(svc, set_id, goal)
    return {"setId": set_id, **completion.for_set(svc, set_id, goal, extra_kinds, patterns, full)}


# ---------------------------------------------------------------------------------------------------------------- what finishing costs ("Cost to complete")
def _goal_of(svc, set_id, goal):
    return goal or setgoals.load(svc.vault).get(set_id) or completion.STANDARD


def sets_costs(svc, level="standard", patterns=False):
    """{set id: {goal, missing, cost, unpriced, asked}} for every set that still misses something at its goal (the picked one, else `level`) - the ONE table the tiles, the overview,
    the analytics screens and the wishlist all read their "cost to complete" from."""
    v = svc.vault
    default = completion.clamp(level, svc.game)
    picked = {sid: completion.clamp(g, svc.game, default) for sid, g in setgoals.load(v).items()}
    tables = {g: completion.costs(svc, g, patterns) for g in {default, *picked.values()}}
    sets = {}
    for g, table in tables.items():
        for sid, (n, cost, unpriced, asked) in table.items():
            if picked.get(sid, default) == g:
                sets[sid] = {"goal": g, "missing": n, "cost": cost, "unpriced": unpriced, "asked": asked}
    return sets


def finish_numbers(table, set_ids):
    """The "cost to complete" of these sets added up from sets_costs(): {missing, cost, unpriced, asked} (a set that misses nothing adds nothing)."""
    rows = [table[s] for s in set_ids if s in table]
    return {"missing": sum(r["missing"] for r in rows), "cost": round(sum(r["cost"] for r in rows), 2), "unpriced": sum(r["unpriced"] for r in rows), "asked": round(sum(r["asked"] for r in rows), 2)}


@api("set.costs")
def set_costs(svc, level="standard", patterns=False):
    """What finishing each set / toy collection costs at its goal (the picked one, else `level` = the page's default goal, as on the tiles):
    {"sets": {set id: {goal, missing, cost, unpriced, asked}}} for every set that still misses something (cost in US dollars, `unpriced` = missing ones without a price, `asked` = the part of
    the cost that is eBay asking prices), and "started": the same added up over the sets you have begun (own at least one of) - finished ones counted in "done"."""
    v = svc.vault
    sets = sets_costs(svc, level, patterns)
    begun = [sid for sid, n in v.owned_by_set().items() if n]
    left = [sets[sid] for sid in begun if sid in sets]
    started = {"sets": len(begun), "done": len(begun) - len(left), "missing": sum(x["missing"] for x in left), "cost": round(sum(x["cost"] for x in left), 2),
               "unpriced": sum(x["unpriced"] for x in left), "asked": round(sum(x["asked"] for x in left), 2)}
    return {"sets": sets, "started": started}


@api("set.missing")
def set_missing(svc, set_id, goal="", extra_kinds=None, patterns=False):
    """The "missing items" list of one set at a goal (the picked one when none is asked): every item still needed with its picture, number and price, dearest first (no price last),
    plus the summary numbers of set.completion.  `ask` marks an eBay asking price (shown labelled, with its kind)."""
    from .cards import img
    _set_exists(svc, set_id)
    goal = _goal_of(svc, set_id, goal)
    its = completion.items(svc, set_id, goal, extra_kinds, patterns)
    summ = completion.summarize(its, completion.clamp(goal, svc.game, completion.MASTER))
    miss = [i for i in its if not i["owned"]]
    light = svc.vault.card_lights([i["card"] for i in miss])
    rows = []
    for i in miss:
        c = light.get(i["card"]) or {}
        rows.append({"id": i["id"], "card": i["card"], "name": c.get("name") or i["card"], "number": c.get("local_id") or "", "rarity": c.get("rarity") or "", "variant": i["variant"],
                     "extra": i["extra"], "price": i["price"], "exact": i["exact"], "ask": bool(i["ask"]), "kind": i["ask"],
                     "img": img(i["card"], c.get("set_id") or set_id)})
    rows.sort(key=lambda r: (r["price"] is None, -(r["price"] or 0)))
    title = svc.vault.conn.execute("SELECT name FROM sets WHERE id=?", (set_id,)).fetchone()[0]
    summ.pop("missing")
    return {"setId": set_id, "title": title, **summ, "items": rows}
