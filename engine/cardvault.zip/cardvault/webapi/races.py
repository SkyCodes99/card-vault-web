"""Checklist races - a few friends race to finish the same checklist.

A race is its OWN little system, riding on one private, end-to-end encrypted group (kind "race", see cloud/sharing.py; the server only ever holds sealed blobs):
  ("race_def", "def")         the frozen race: name, game and the checklist's item list as it was when the race began.  Only the creator can write it (the server checks).
  ("race_prog", <member id>)  one row per racer, written only by that racer (the server checks): which race items they ticked, how many, the percent, when they last changed it
                              and when they reached 100%.  Never anything about their collection or portfolios.
Each racer's race ticks are kept apart from their checklists and collection (the account setting "race_ticks", which follows the account to its other devices) and are NEVER
ticked automatically: items of the race that are already in one of your portfolios are only SUGGESTED, with the portfolio names, and tick when you confirm them.  Unticking never
touches a portfolio.  A tick is saved on this device at once; the progress row is sent by the regular background sync (cloudapi.start_sync -> publish_steps), never while you click.
Leaving (or a block) takes your row with you; the creator ends the race by deleting the group.  Honor system: no prizes, just for fun."""
import base64
import json
import time

from ..cloud import sharing as sh
from ..cloud import skycloud as sc
from .friends import _book, _norm
from .portfolios import MAIN
from .registry import ApiError, api
from .sharing import _acct, _call, _gk, _inn, _label, _names, _out, accept, decline, invite, leave, offers, pull, stop

MAX_ITEMS = 3000
MAX_RACERS = 20                     # the server's limit for one group (the creator included)
DEF, PROG = "race_def", "race_prog"
FULL = "You're already in as many races and circles as an account can be (10). Leave or end one first."


def _me(svc):
    return _norm(svc.pget("cloud_username"))


def _mutual(book, u):
    """A friend I said yes to (their side may still be on its way - the friends list shows them as a friend already); never someone I blocked."""
    f = book.get(u) or {}
    return bool(f.get("out") and not f.get("blocked"))


def _races(svc):
    """{group id: (entry, i_made_it)} of every race I started or joined."""
    out = {g: (e, True) for g, e in _out(svc).items() if e.get("kind") == "race"}
    out.update({g: (e, False) for g, e in _inn(svc).items() if e.get("kind") == "race"})
    return out


# ---------------------------------------------------------------------------------------------------- my race ticks (this account only, apart from everything else)
def _all_ticks(svc):
    try:
        d = json.loads(svc.pget("race_ticks") or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _ticks(svc, gid):
    t = _all_ticks(svc).get(gid)
    return t if isinstance(t, dict) else {}


def _save_ticks(svc, gid, t):
    d = _all_ticks(svc)
    if t is None:
        d.pop(gid, None)
    else:
        d[gid] = t
    svc.pset("race_ticks", json.dumps(d, separators=(",", ":")))
    try:   # into the account's synced choices right away (not on the 5 s housekeeping pass): a page closed a moment after a tick would otherwise get the older ticks back when it opens
        from .settings import prefs_touch
        prefs_touch(svc)
    except Exception:  # noqa: BLE001 - the housekeeping pass stores it a few seconds later anyway
        pass


def _forget(svc, gid):
    """A race that is over for me (ended, left): its keys and my ticks go from this device."""
    for k, load in (("share_out", _out), ("share_in", _inn)):
        d = load(svc)
        if d.pop(gid, None) is not None:
            svc.pset(k, json.dumps(d))
    _save_ticks(svc, gid, None)
    getattr(svc, "_race_sent", {}).pop(gid, None)
    getattr(svc, "_rowcache", {}).pop(gid, None)


def _gone(ex):
    return isinstance(ex, sc.CloudError) and ex.status in (403, 404)


# ---------------------------------------------------------------------------------------------------- the frozen item list
def _items_of(svc, cl):
    """The checklist's items as they are right now, for the race definition: [{k, n, s, c: [card ids that count], v?, sid, ib}]."""
    from .. import checklists
    v = svc.vault
    saved, tp = list(v.scope or []), v.target_pf
    v.set_scope([])
    try:
        p = checklists.progress_for_checklist(v, cl)
    finally:
        v.set_scope(saved)
        v.target_pf = tp
    out = []
    for t in p.tiles:
        if t.card_id is None:                                     # a Pokédex number with no card at all can never be had: not part of a race
            continue
        c = v.card_light(t.card_id) or {}
        key = t.key or (f"{t.card_id}|{t.variant}" if t.variant else t.card_id)
        it = {"k": str(key)[:120], "n": (t.label if t.candidates else c.get("name")) or t.card_id, "s": " · ".join(x for x in (c.get("set_name") or "", f"#{c['local_id']}" if c.get("local_id") else "", t.variant or "") if x),
              "c": list(t.candidates or [t.card_id])[:60], "sid": c.get("set_id") or ""}
        if t.variant:
            it["v"] = t.variant
        ib = svc.remote_image(t.card_id, "low")
        if isinstance(ib, str) and ib.startswith("http"):
            it["ib"] = ib                                         # a picture racers in another game (or without this list) can still show
        out.append(it)
    return out


def _def(rows):
    d = rows.get((DEF, "def"))
    return d if isinstance(d, dict) and isinstance(d.get("items"), list) else {}


def _keys(d):
    return [str(i.get("k")) for i in d.get("items") or [] if isinstance(i, dict) and i.get("k")]


# ---------------------------------------------------------------------------------------------------- my progress row (what the other racers see of me)
def _row(svc, gid, me_id, total):
    t = _ticks(svc, gid)
    have = sorted(set(t.get("k") or []))
    n = len(have)
    return {"m": me_id, "u": _me(svc), "h": have, "n": n, "t": total, "pct": round(100.0 * n / total, 1) if total else 0.0, "at": t.get("at") or 0, "done": t.get("done") if total and n >= total else None}


def _my_id(svc, a, gid, e):
    if e.get("me"):
        return e["me"]
    me = next((m["id"] for m in a.call("GET", f"/v1/groups/{gid}/members").get("members", []) if m.get("me")), None)
    if me:
        _remember_me(svc, gid, me)
    return me


def _remember_me(svc, gid, me):
    for k, load in (("share_out", _out), ("share_in", _inn)):
        d = load(svc)
        if gid in d:
            d[gid]["me"] = me
            svc.pset(k, json.dumps(d))


def _seal_row(key, me_id, row):
    return {"coll": PROG, "id": me_id, "updated_at": time.time(), "deleted": False, "blob": sh.seal_json(key, row, f"{PROG}/{me_id}")}


def _publish_one(svc, a, gid, e, total=None):
    """Send my row now if it changed since it was last sent (the race screen does this when it opens; the background sync does it after ticks)."""
    sent = svc.__dict__.setdefault("_race_sent", {})
    t = _ticks(svc, gid)
    total = total if total is not None else t.get("t")
    if total is None:
        return False
    me = _my_id(svc, a, gid, e)
    if not me:
        return False
    row = _row(svc, gid, me, total)
    sig = json.dumps(row, sort_keys=True)
    if sent.get(gid) == sig:
        return False
    a.call("POST", f"/v1/groups/{gid}/records", {"rows": [_seal_row(_gk(e), me, row)]})
    sent[gid] = sig
    return True


def publish_steps(svc, a):
    """A step of the regular sync (cloudapi.start_sync): every race whose ticks changed since my row was last sent gets its row sent - as steps of the job, so the screens never wait for it."""
    sent = svc.__dict__.setdefault("_race_sent", {})
    known = svc.__dict__.setdefault("_race_me", {})
    for gid, (e, _owner) in list(_races(svc).items()):
        t = _ticks(svc, gid)
        if t.get("t") is None:
            continue
        try:
            me = e.get("me") or known.get(gid)
            if not me:
                me = next((m["id"] for m in (yield from a.call_steps("GET", f"/v1/groups/{gid}/members")).get("members", []) if m.get("me")), None)
                if not me:
                    continue
                known[gid] = me
            row = _row(svc, gid, me, t["t"])
            sig = json.dumps(row, sort_keys=True)
            if sent.get(gid) == sig:
                continue
            yield from a.call_steps("POST", f"/v1/groups/{gid}/records", {"rows": [_seal_row(_gk(e), me, row)]})
            sent[gid] = sig
        except sc.CloudError:                                      # the race is gone or the server is busy: looked at again next time
            continue


# ---------------------------------------------------------------------------------------------------- suggestions: race items already in my portfolios
def _where_owned(svc, d):
    """{item key: [portfolio names]} for every race item that is in one of my portfolios (every portfolio, whatever the Viewing menu shows).  None when the race's game isn't the open one."""
    v = svc.vault
    if not d or d.get("game") != svc.game.id:
        return None
    rows = v.conn.execute("SELECT card_id, variant, COALESCE(portfolio,'') FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)).fetchall()
    by_card = {}
    for cid, var, pf in rows:
        by_card.setdefault(cid, []).append((var, pf))
    names = _names(svc)
    out = {}
    for it in d.get("items") or []:
        want_v = it.get("v")
        pfs = []
        for cid in it.get("c") or []:
            for var, pf in by_card.get(cid, ()):
                if want_v and var != want_v:
                    continue
                if pf not in pfs:
                    pfs.append(pf)
        if pfs:
            out[it["k"]] = sorted({names.get(p or MAIN) or p or "Main" for p in pfs}, key=str.lower)
    return out


def _suggestions(svc, gid, d):
    found = _where_owned(svc, d)
    if found is None:
        return None
    mine = set(_ticks(svc, gid).get("k") or [])
    return {k: v for k, v in found.items() if k not in mine}


# ---------------------------------------------------------------------------------------------------- list / invitations
@api("races.list")
def races_list(svc, _t=None):
    """My races (started and joined), one line each, and the race invitations waiting for me."""
    a = _acct(svc)
    out = {"races": [], "invites": []}

    def go():
        book = _book(svc)
        for o in offers(svc):
            if o.get("kind") == "race" and _mutual(book, _norm(o["from"])):
                out["invites"].append({"id": o["id"], "from": _norm(o["from"]), "title": o["title"]})
        for gid, (e, owner) in _races(svc).items():
            try:
                rows = pull(svc, a, gid, _gk(e))
            except Exception as ex:  # noqa: BLE001 - one race failing hides none of the others
                if _gone(ex):
                    _forget(svc, gid)                             # the creator ended it (or I was taken out)
                    continue
                out["races"].append({"id": gid, "name": e.get("title") or "Race", "owner": owner, "offline": True})
                continue
            d = _def(rows)
            total = len(_keys(d))
            t = _ticks(svc, gid)
            if d and t.get("t") != total:
                _save_ticks(svc, gid, {**t, "t": total})
            n = len(set(t.get("k") or []) & set(_keys(d)))
            sug = _suggestions(svc, gid, d)
            out["races"].append({"id": gid, "name": d.get("name") or e.get("title") or "Race", "owner": owner, "ownerName": _norm(d.get("owner") or e.get("from") or _me(svc)),
                                 "game": d.get("gameName") or "", "list": d.get("list") or "", "total": total, "have": n, "pct": round(100.0 * n / total, 1) if total else 0.0,
                                 "racers": len({r.get("m") for (c, _), r in rows.items() if c == PROG and isinstance(r, dict)}) or 1, "suggest": len(sug) if sug else 0})
    _call(go)
    out["suggest"] = sum(r.get("suggest") or 0 for r in out["races"])
    return out


@api("races.accept", mutates=True)
def races_accept(svc, offer):
    _acct(svc)
    o = next((x for x in _call(lambda: offers(svc)) if x["id"] == offer), None)
    if not o or o.get("kind") != "race":
        raise ApiError("That race invitation is gone.")
    if not _mutual(_book(svc), _norm(o["from"])):
        raise ApiError("Races only take invitations from your friends.")
    try:
        r = accept(svc, offer)
    except ApiError as ex:
        if "too many groups" in str(ex):
            raise ApiError(FULL)
        if "full" in str(ex):
            raise ApiError(f"That race is full ({MAX_RACERS} racers).")
        raise
    try:                                                              # (how many items the race has: my ticks can tell when I have finished)
        e = _inn(svc).get(r["id"]) or {}
        d = _def(sh.pull_rows(_acct(svc), r["id"], _gk(e)))
        if d:
            _save_ticks(svc, r["id"], {**_ticks(svc, r["id"]), "t": len(_keys(d))})
    except Exception:  # noqa: BLE001 - the race screen works it out when it opens
        pass
    return {"id": r["id"]}


@api("races.decline", mutates=True)
def races_decline(svc, offer):
    decline(svc, offer)
    return True


# ---------------------------------------------------------------------------------------------------- starting, leaving and ending a race
@api("races.create", mutates=True)
def races_create(svc, listId, name="", members=None):
    """Race friends on one of my checklists: its item list is frozen into the race, and each friend gets an invitation."""
    a = _acct(svc)
    v = svc.vault
    try:
        cl = v.checklist(int(listId))
    except (TypeError, ValueError):
        cl = None
    if cl is None or cl["deleted"] or cl["user_id"] != v.user_id or cl["game"] != v.game:
        raise ApiError("Pick one of your checklists in this game.")
    book = _book(svc)
    who = list(dict.fromkeys(_norm(m) for m in (members or []) if _norm(m)))
    if not who:
        raise ApiError("Pick at least one friend to race.")
    if len(who) > MAX_RACERS - 1:
        raise ApiError(f"A race holds up to {MAX_RACERS} people (you and {MAX_RACERS - 1} friends).")
    for u in who:
        if not _mutual(book, u):
            raise ApiError(f"{u} isn't one of your friends yet - races are for friends.")
    items = _items_of(svc, cl)
    if not items:
        raise ApiError("That checklist has no cards to race for.")
    if len(items) > MAX_ITEMS:
        raise ApiError(f"That checklist is too big for a race ({len(items):,} items - a race holds up to {MAX_ITEMS:,}).")
    title = ((name or "").strip() or cl["name"])[:60]
    me = _me(svc)

    def go():
        sh.ensure_keypair(a)
        key, gid = sh.new_group_key(), sh.new_id()
        try:
            r = a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": title, "from": svc.pget("cloud_username"), "kind": "race"}, "group/name"),
                                              "label_blob": sh.seal_json(key, {"label": me}, "group/label")})
        except sc.CloudError as ex:
            if ex.status == 413:
                raise ApiError(FULL)
            raise
        e = {"key": base64.b64encode(key).decode(), "title": title, "portfolios": [], "showValue": False, "kind": "race", "me": r.get("me") or ""}
        o = _out(svc)
        o[gid] = e
        svc.pset("share_out", json.dumps(o))
        d = {"v": 1, "name": title, "list": cl["name"], "game": svc.game.id, "gameName": svc.game.name, "owner": me, "created": time.time(), "items": items}
        sh.push_rows(a, gid, key, [(DEF, "def", d)])
        _save_ticks(svc, gid, {"k": [], "at": 0, "done": None, "t": len(items)})
        _publish_one(svc, a, gid, e, len(items))
        missed = []
        for u in who:
            try:
                invite(svc, gid, u, role="editor")
            except ApiError as ex:
                if "already have" not in str(ex):
                    missed.append(u)
        return {"id": gid, "missed": missed}
    return _call(go)


@api("races.leave", mutates=True)
def races_leave(svc, id):
    a = _acct(svc)
    e = _inn(svc).get(id)
    if not e or e.get("kind") != "race":
        raise ApiError("You're not in that race.")

    def go():
        me = None
        try:
            me = _my_id(svc, a, id, e)
        except sc.CloudError as ex:
            if not _gone(ex):
                raise
        if me:
            try:
                leave(svc, id, member=me)                      # (the server takes my progress row with me)
            except ApiError:
                pass
        _forget(svc, id)
    _call(go)
    return True


@api("races.end", mutates=True)
def races_end(svc, id):
    _acct(svc)
    e = _out(svc).get(id)
    if not e or e.get("kind") != "race":
        raise ApiError("Only the person who started the race can end it.")
    try:
        stop(svc, id)
    except ApiError as ex:
        if "not found" not in str(ex).lower() and "404" not in str(ex):
            raise
    _forget(svc, id)
    return True


# ---------------------------------------------------------------------------------------------------- ticking (local only - the outbox keeps it; the sync sends my row)
@api("races.tick", mutates=True)
def races_tick(svc, id, keys, on=True):
    """Tick (or untick) race items - in this race only.  Never touches a checklist, a portfolio or the collection."""
    if id not in _races(svc):
        raise ApiError("You're not in that race.")
    keys = [str(k) for k in (keys if isinstance(keys, list) else [keys]) if k is not None][:MAX_ITEMS]
    t = dict(_ticks(svc, id))
    have = set(t.get("k") or [])
    before = set(have)
    have = (have | set(keys)) if on else (have - set(keys))
    if have != before:
        t["k"] = sorted(have)
        t["at"] = time.time()
        total = t.get("t")
        if total and len(have) >= total:
            t["done"] = t.get("done") or t["at"]
        else:
            t["done"] = None
        _save_ticks(svc, id, t)
    total = t.get("t") or 0
    return {"have": len(have), "total": total, "done": t.get("done")}


# ---------------------------------------------------------------------------------------------------- one race, in full
def _rank(entries):
    """Most ticked first; among equals, whoever finished earlier, then whoever got there earlier."""
    entries.sort(key=lambda x: (-x["have"], x["done"] or 1e18, x["at"] or 1e18, x["username"]))
    for i, x in enumerate(entries):
        x["rank"] = i + 1
    return entries


def _read(svc, a, gid, e, owner):
    rows = pull(svc, a, gid, _gk(e))
    d = _def(rows)
    if not d:
        raise ApiError("That race can't be read right now - try again in a moment.")
    items = [i for i in d["items"] if isinstance(i, dict) and i.get("k")]
    keys = [str(i["k"]) for i in items]
    kset = set(keys)
    total = len(keys)
    t = _ticks(svc, gid)
    if t.get("t") != total:
        t = {**t, "t": total}
        _save_ticks(svc, gid, t)
    members = a.call("GET", f"/v1/groups/{gid}/members").get("members", [])
    me_id = next((m["id"] for m in members if m.get("me")), None) or e.get("me")
    if me_id and e.get("me") != me_id:
        _remember_me(svc, gid, me_id)
        e = {**e, "me": me_id}
    mine = set(t.get("k") or [])
    if not mine and not t.get("at"):                              # a new device (or ticks from before): start from my own row on the server
        old = next((r for (c, _), r in rows.items() if c == PROG and isinstance(r, dict) and r.get("m") == me_id), None)
        if old and isinstance(old.get("h"), list) and old["h"]:
            t = {**t, "k": [k for k in old["h"] if k in kset], "at": old.get("at") or time.time(), "done": old.get("done")}
            _save_ticks(svc, gid, t)
            mine = set(t["k"])
    try:
        _publish_one(svc, a, gid, e, total)
    except sc.CloudError:
        pass
    book, me = _book(svc), _me(svc)
    labels = {m["id"]: _norm(_label(e, m)) for m in members}
    prog = {}
    for (c, _), r in rows.items():
        if c == PROG and isinstance(r, dict) and r.get("m") in labels:          # only people still in the race (someone who left took their row with them)
            prog[r["m"]] = r
    entries = []
    for mid, label in labels.items():
        who = label or _norm((prog.get(mid) or {}).get("u")) or "?"
        if who != me and (book.get(who) or {}).get("blocked"):
            continue
        if mid == me_id:
            have, at, done = sorted(mine & kset), t.get("at") or 0, (t.get("done") if total and len(mine & kset) >= total else None)
        else:
            r = prog.get(mid) or {}
            have = sorted(set(r.get("h") or []) & kset) if isinstance(r.get("h"), list) else []
            at, done = r.get("at") or 0, (r.get("done") or r.get("at")) if total and len(have) >= total else None
        entries.append({"id": mid, "username": who, "isMe": mid == me_id, "owner": who == _norm(d.get("owner")), "have": len(have), "total": total,
                        "pct": round(100.0 * len(have) / total, 1) if total else 0.0, "at": at or None, "done": done, "_h": set(have), "joined": mid in prog or mid == me_id})
    _rank(entries)
    finishers = [{"username": x["username"], "isMe": x["isMe"], "at": x["done"]} for x in sorted((x for x in entries if x["done"]), key=lambda x: x["done"])]
    for i, f in enumerate(finishers):
        f["place"] = i + 1
    sug = _suggestions(svc, gid, d)
    same_game = d.get("game") == svc.game.id
    from .cards import img
    grid = []
    for it in items:
        pic = ""
        if same_game and it.get("c"):
            try:
                pic = img(it["c"][0], it.get("sid") or "")
            except Exception:  # noqa: BLE001
                pic = ""
        grid.append({"k": it["k"], "name": it.get("n") or it["k"], "sub": it.get("s") or "", "img": pic or it.get("ib") or "", "who": [i for i, x in enumerate(entries) if it["k"] in x["_h"]],
                     "mine": it["k"] in mine, "where": (sug or {}).get(it["k"]) or []})
    for x in entries:
        x.pop("_h", None)
    return {"id": gid, "name": d.get("name") or e.get("title"), "list": d.get("list") or "", "game": d.get("gameName") or "", "sameGame": same_game, "owner": owner,
            "ownerName": _norm(d.get("owner")), "created": d.get("created"), "total": total, "racers": entries, "finishers": finishers, "items": grid,
            "suggest": [{"k": k, "name": next((g["name"] for g in grid if g["k"] == k), k), "where": v} for k, v in (sug or {}).items()],
            "suggestNote": "" if sug is not None else f"Open {d.get('gameName') or 'that game'} to see which of these are already in your portfolios."}


@api("races.get")
def races_get(svc, id, _t=None):
    """Everything on one race's screen: the leaderboard, who finished when, the items x racers grid, and my suggestions."""
    a = _acct(svc)
    r = _races(svc).get(id)
    if not r:
        raise ApiError("That race isn't on this device (it may have ended).")
    e, owner = r

    def go():
        try:
            return _read(svc, a, id, e, owner)
        except sc.CloudError as ex:
            if _gone(ex):
                _forget(svc, id)
                raise ApiError("That race has ended.")
            raise
    return _call(go)
