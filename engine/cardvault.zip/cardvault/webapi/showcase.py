"""Showcase: an optional public page for your collection (title, totals, top 10 by value, the portfolios you pick).  Nothing is public unless you turn it on;
it is published as a static page to a public repository on YOUR GitHub account, and turning it off removes it.  You can also open other collectors' showcases by link."""
import base64
import datetime
import html
import json
import re

from .. import tools
from .portfolios import MAIN, main_name
from .registry import ApiError, api

REPO_NAME = "collect-em-all-showcase"
DEFAULTS = {"public": False, "title": "", "bio": "", "portfolios": [], "show_value": True, "show_top10": True, "show_stats": True, "show_sets": True, "cover": "", "slug": "", "url": "", "published": ""}


def settings(svc):
    raw = svc.pget("showcase")
    try:
        d = json.loads(raw) if isinstance(raw, str) else (raw or {})
    except ValueError:
        d = {}
    return {**DEFAULTS, **d}


def _save(svc, d):
    svc.pset("showcase", json.dumps(d))


def build_payload(svc, cfg):
    """What the public page contains - built only from what the owner switched on."""
    v = svc.vault
    saved = v.scope
    want = [("" if p == MAIN else p) for p in (cfg.get("portfolios") or [])]
    v.set_scope(want)
    try:
        st = v.stats()
        top = [r for r in v.top_cards(10)]
        sets = []
        if cfg.get("show_sets"):
            owned = v.owned_by_set()
            for s in v.sets():
                o = owned.get(s["id"], 0)
                if o and (s["n"] or 0):
                    sets.append({"name": s["name"], "owned": o, "total": s["n"], "pct": round(100.0 * o / s["n"], 1)})
            sets.sort(key=lambda x: (-x["pct"], -x["owned"]))
            sets = sets[:12]
        names = {p["id"]: p["name"] for p in [{"id": MAIN, "name": main_name(svc)}] + [{"id": p["uuid"], "name": p["name"]} for p in v.portfolios()]}
        shown = want or [""]
        pfs = []
    finally:
        v.set_scope(saved)
    show_value = bool(cfg.get("show_value"))
    stats_all = v.portfolio_stats()
    ids = [(MAIN if i == "" else i) for i in (want or [""] + [p["uuid"] for p in v.portfolios()])]
    for pid in ids:
        s = stats_all.get(("" if pid == MAIN else pid), {"copies": 0, "unique": 0, "value": 0})
        pfs.append({"name": names.get(pid, pid), "cards": s["copies"], "unique": s["unique"], **({"value": round(s["value"], 2)} if show_value else {})})
    owner = (svc.pget("cloud_username") or "") if svc.pget("cloud_token") else ""
    payload = {"format": 1, "owner": owner, "game": svc.game.name, "title": cfg.get("title") or "My collection", "bio": cfg.get("bio") or "", "updated": datetime.date.today().isoformat(),
               "app": "Collect Em All", "portfolios": pfs}
    if cfg.get("cover"):
        payload["cover"] = {"id": cfg["cover"], "img": svc.remote_image(cfg["cover"], "high"), "name": (v.card_light(cfg["cover"]) or {}).get("name", "")}
    if cfg.get("show_stats"):
        payload["stats"] = {"cards": st["copies"], "unique": st["unique"], **({"value": round(st["value"], 2)} if show_value else {})}
    if cfg.get("show_top10"):
        payload["top10"] = [{"id": r["id"], "name": r["name"], "set": r["set_name"] or r["set_id"], "number": r["local_id"], "rarity": r["rarity"] or "", "qty": r["qty"],
                             "img": svc.remote_image(r["id"], "low"),
                             **({"price": r["price_usd"], "value": round(r["value"] or 0, 2)} if show_value else {})} for r in top]
    if sets:
        payload["sets"] = sets
    return payload


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>
:root{color-scheme:light dark;--bg:#f5f7fb;--card:#fff;--ink:#1a2236;--mute:#6b7488;--acc:#4a7cff;--line:#dfe5f0}
@media(prefers-color-scheme:dark){:root{--bg:#0e1220;--card:#1a2136;--ink:#e9edf7;--mute:#98a2bb;--line:#2a3350}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}
header{padding:36px 20px 20px;text-align:center;background:linear-gradient(135deg,#2a4fb8,#8a4fd1);color:#fff}header.hc{display:flex;align-items:center;justify-content:center;gap:22px;text-align:left;flex-wrap:wrap}header img{height:190px;border-radius:12px;box-shadow:0 12px 30px rgba(0,0,0,.45);transform:rotate(-3deg)}
header h1{margin:0 0 6px;font-size:30px}header p{margin:0;opacity:.9}
main{max-width:1040px;margin:0 auto;padding:20px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:-34px 0 18px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;text-align:center;box-shadow:0 6px 18px rgba(0,0,0,.08)}
.stat b{display:block;font-size:24px}.stat span{color:var(--mute);font-size:13px}
h2{margin:26px 0 10px}
.top{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}
.c{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px;position:relative}
.c img{width:100%;aspect-ratio:63/88;object-fit:contain;border-radius:8px;background:var(--bg)}
.c .rk{position:absolute;top:6px;left:6px;background:var(--acc);color:#fff;border-radius:99px;padding:1px 9px;font-weight:700}
.c .n{font-weight:650;margin-top:6px}.c .s{color:var(--mute);font-size:12px}.c .v{font-weight:700;margin-top:2px}
.row{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 14px;margin-bottom:8px;display:flex;gap:12px;align-items:center}
.bar{flex:1;height:8px;background:var(--line);border-radius:5px;overflow:hidden}.bar i{display:block;height:100%;background:var(--acc)}
footer{text-align:center;color:var(--mute);padding:26px;font-size:13px}
</style></head><body><header><h1 id="t"></h1><p id="b"></p></header><main id="m"></main>
<footer>Made with Collect Em All &middot; updated <span id="u"></span></footer>
<script>var D=__DATA__;
var $=function(i){return document.getElementById(i)};var money=function(v){return '$'+Number(v).toLocaleString(undefined,{maximumFractionDigits:2})};
var esc=function(s){var d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML};
if(D.cover&&D.cover.img){var hd=document.querySelector('header');hd.className='hc';hd.insertAdjacentHTML('afterbegin','<img alt="'+esc(D.cover.name)+'" src="'+esc(D.cover.img)+'">');var tx=document.createElement('div');while(hd.children.length>1){tx.appendChild(hd.children[1]);}hd.appendChild(tx);}
$('t').textContent=D.title;$('b').textContent=(D.owner?'by '+D.owner+' · ':'')+(D.bio||D.game);$('u').textContent=D.updated;var h='';
if(D.stats){h+='<div class="stats"><div class="stat"><b>'+D.stats.cards.toLocaleString()+'</b><span>cards</span></div><div class="stat"><b>'+D.stats.unique.toLocaleString()+'</b><span>different cards</span></div>'+(D.stats.value!=null?'<div class="stat"><b>'+money(D.stats.value)+'</b><span>estimated value</span></div>':'')+'</div>';}
if(D.top10&&D.top10.length){h+='<h2>Top 10 most valuable</h2><div class="top">'+D.top10.map(function(c,i){return '<div class="c"><span class="rk">'+(i+1)+'</span>'+(c.img?'<img loading="lazy" alt="'+esc(c.name)+'" src="'+esc(c.img)+'">':'')+'<div class="n">'+esc(c.name)+'</div><div class="s">'+esc(c.set)+' #'+esc(c.number)+(c.qty>1?' &middot; x'+c.qty:'')+'</div>'+(c.value!=null?'<div class="v">'+money(c.value)+'</div>':'')+'</div>'}).join('')+'</div>';}
if(D.portfolios&&D.portfolios.length>1){h+='<h2>Portfolios</h2>'+D.portfolios.map(function(p){return '<div class="row"><b style="flex:1">'+esc(p.name)+'</b><span>'+p.cards.toLocaleString()+' cards</span>'+(p.value!=null?'<span>'+money(p.value)+'</span>':'')+'</div>'}).join('');}
if(D.sets&&D.sets.length){h+='<h2>Sets in progress</h2>'+D.sets.map(function(s){return '<div class="row"><span style="width:230px">'+esc(s.name)+'</span><div class="bar"><i style="width:'+s.pct+'%"></i></div><b>'+s.pct+'%</b></div>'}).join('');}
$('m').innerHTML=h;</script></body></html>"""


def page_html(payload):
    data = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    return PAGE.replace("__TITLE__", html.escape(payload.get("title") or "Collection")).replace("__DATA__", data)


def _gh(svc):
    from . import cloudapi
    import requests
    tok, _ = cloudapi.token(svc)
    if not tok:
        raise ApiError("Publishing your showcase isn't set up for this account yet.")
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json", "User-Agent": "CollectEmAll/3 (showcase)", "X-GitHub-Api-Version": "2022-11-28"})
    return s, tok


@api("showcase.get")
def get(svc):
    cfg = settings(svc)
    try:
        preview = build_payload(svc, cfg)
    except Exception as e:  # noqa: BLE001
        preview = {"error": str(e)}
    return {"settings": cfg, "preview": preview}


@api("showcase.set")
def set_cfg(svc, settings_in):
    cfg = settings(svc)
    for k in ("title", "bio", "portfolios", "show_value", "show_top10", "show_stats", "show_sets", "cover"):
        if k in settings_in:
            cfg[k] = settings_in[k]
    _save(svc, cfg)
    return get(svc)


@api("showcase.publish")
def publish(svc):
    """Make the showcase public: writes a page to <you>/collect-em-all-showcase on GitHub and turns on GitHub Pages."""
    from ..cloud.backend import GitHubRepoBackend
    cfg = settings(svc)
    s, tok = _gh(svc)
    me = s.get("https://api.github.com/user", timeout=30)
    if me.status_code != 200:
        raise ApiError("Couldn't publish your showcase. Please try again later.")
    login = me.json()["login"]
    full = f"{login}/{REPO_NAME}"
    r = s.get(f"https://api.github.com/repos/{full}", timeout=30)
    if r.status_code == 404:
        c = s.post("https://api.github.com/user/repos", json={"name": REPO_NAME, "description": "Collect Em All showcase pages", "private": False, "auto_init": True}, timeout=60)
        if c.status_code not in (201, 422):
            raise ApiError("Couldn't publish your showcase right now. Please try again later.")
    slug = cfg.get("slug") or (re.sub(r"[^a-z0-9]+", "-", (cfg.get("title") or login).lower()).strip("-")[:24] + "-" + base64.b32encode(__import__("os").urandom(4)).decode().lower().rstrip("="))
    svc.audit("showcase_published", cfg.get("title") or "")
    payload = build_payload(svc, cfg)
    b = GitHubRepoBackend(full, tok)
    for name, data in ((f"u/{slug}/data.json", json.dumps(payload, ensure_ascii=False).encode("utf-8")), (f"u/{slug}/index.html", page_html(payload).encode("utf-8"))):
        _, sha = b.read(name)
        b.write(name, data, sha, "Update showcase")
    s.post(f"https://api.github.com/repos/{full}/pages", json={"source": {"branch": "main", "path": "/"}}, timeout=30)     # 409 = already on
    url = f"https://{login.lower()}.github.io/{REPO_NAME}/u/{slug}/"
    cfg.update(public=True, slug=slug, url=url, published=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), repo=full)
    _save(svc, cfg)
    return {"url": url}


@api("showcase.unpublish")
def unpublish(svc):
    from ..cloud.backend import GitHubRepoBackend
    cfg = settings(svc)
    svc.audit("showcase_removed")
    if cfg.get("repo") and cfg.get("slug"):
        s, tok = _gh(svc)
        b = GitHubRepoBackend(cfg["repo"], tok)
        for name in (f"u/{cfg['slug']}/data.json", f"u/{cfg['slug']}/index.html"):
            _, sha = b.read(name)
            if sha:
                s.delete(f"https://api.github.com/repos/{cfg['repo']}/contents/{name}", json={"message": "Remove showcase", "sha": sha, "branch": "main"}, timeout=60)
    cfg.update(public=False, url="", published="")
    _save(svc, cfg)
    return {"ok": True}


@api("showcase.fetch")
def fetch(svc, url):
    """Open somebody else's showcase (a link to a page published by this app)."""
    import requests
    m = re.match(r"^https://([a-z0-9-]+)\.github\.io/" + REPO_NAME + r"/u/([a-z0-9-]+)/?(?:index\.html|data\.json)?$", (url or "").strip().lower())
    if not m:
        raise ApiError("That doesn't look like a Collect Em All showcase link.")
    try:
        r = requests.get(f"https://{m.group(1)}.github.io/{REPO_NAME}/u/{m.group(2)}/data.json", timeout=30)
        r.raise_for_status()
        data = r.json()
    except (requests.RequestException, ValueError):
        raise ApiError("Couldn't open that showcase (it may be private now).")
    return data
