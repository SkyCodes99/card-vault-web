"""Settings > Account & security > Weekly email: an optional weekly note (value, change, biggest movers, new releases).  OFF by default; the choice follows the account (synced pref "weekly_email").
Only the account server can send e-mail, and it cannot read your collection, so while the switch is on this device hands the server the ready-made short text about once a day
(`maybe_send`, from the scheduler) and the server mails the newest one to the account's own address once a week.  Nothing is sent while it is off; no address is read, kept or logged here.
Server side: docs/server_requests.md (request 2).  An older server without it says so, and the switch stays off."""
import datetime
import time

from .. import premium, weeklydigest
from ..cloud import skycloud as sc
from .registry import ApiError, api

KEY = "weekly_email"            # True once the server accepted the switch (synced with the account's choices)
SENT = "weekly_sent"            # the day this device last handed the server a fresh note (device only)
BASE = "/v1/weekly-email"


def _account(svc):
    from .accountapi import account
    return account(svc, need=True)


def _server(svc, method, path, body=None, timeout=8):
    try:
        return _account(svc).call(method, path, body, timeout=timeout) or {}
    except sc.CloudError as e:
        if e.status == 404:
            raise ApiError("The account server can't send the weekly email yet - it arrives with the next server update.", code="unavailable")
        raise ApiError("Couldn't reach your account just now. Try again in a moment.")


@api("weekly.status", quiet=True)
def status(svc):
    """-> {on, available}.  `available` is False when the account server doesn't have the weekly email yet (then the switch is hidden-off with a note); None = couldn't ask just now."""
    if not premium.signed_in(svc):
        return {"on": False, "available": False}
    out = {"on": bool(svc.pget(KEY)), "available": True}
    try:
        got = _server(svc, "GET", BASE)
        out["on"] = bool(got.get("on"))
    except ApiError as e:
        out["available"] = False if e.code == "unavailable" else None
    return out


@api("weekly.set", mutates=True)
def set_on(svc, on):
    on = bool(on)
    if not premium.signed_in(svc):
        raise ApiError("Sign in to your account first - the email goes to the address on your account.", code="no_account")
    _server(svc, "PUT", BASE, {"on": on})
    svc.pset(KEY, True if on else None)
    svc.pset(SENT, None)
    if on:
        maybe_send(svc)                                   # the first note is ready for the server straight away
    return {"ok": True, "on": on}


@api("weekly.preview", quiet=True)
def preview(svc):
    """The note as it would be written right now (shown in Settings so nobody is surprised)."""
    got = weeklydigest.build(svc)
    return {"text": got["text"] if got else "", "empty": got is None}


def maybe_send(svc, now=None):
    """Called by the scheduler every few minutes: when the switch is on and no note went out today, write one and hand it to the server.  Quiet; any trouble waits an hour."""
    if not svc.pget(KEY) or not premium.signed_in(svc) or svc.vault is None:
        return False
    now = now or time.time()
    today = datetime.date.fromtimestamp(now).isoformat()
    if svc.pget(SENT) == today or now < getattr(svc, "_weekly_wait", 0):
        return False
    try:
        note = weeklydigest.build(svc)
        if note:
            _server(svc, "PUT", BASE + "/digest", note, timeout=15)
        svc.pset(SENT, today)
        return bool(note)
    except Exception:  # noqa: BLE001 - offline or an older server: try again later, never bother anyone
        svc._weekly_wait = now + 3600
        return False
