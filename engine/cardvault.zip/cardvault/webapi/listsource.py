"""Where a checklist counts what you own FROM.  Kept with the checklist's rules as  rules["sources"] = {"mode": "all" | "pick" | "view", "ids": [portfolio ids]}:
  all  - everything you own, in every portfolio (the default for new checklists)
  pick - only these portfolios (a category counts everything inside it)
  view - whatever the Portfolio menu is showing right now (how checklists always worked before; still used by checklists made earlier until you choose)
A checklist with an explicit source is read with that view of the collection, whatever the Portfolio menu says."""
import contextlib
import functools

from .. import checklists
from .registry import api
from .service import ApiError


def source_of(cl):
    s = (checklists._load_rules(cl) or {}).get("sources") or {}
    mode = s.get("mode") if s.get("mode") in ("all", "pick", "view") else "view"
    return {"mode": mode, "ids": list(s.get("ids") or []) if mode == "pick" else []}


@contextlib.contextmanager
def source_scope(svc, cl):
    """While inside: the collection is looked at through this checklist's own source."""
    from .portfolios import _db_id, with_descendants
    src = source_of(cl) if cl is not None else {"mode": "view"}
    if src["mode"] == "view":
        yield
        return
    v = svc.vault
    saved, target, owned, wish = (list(v.scope) if v.scope else None), v.target_pf, svc.owned, svc.wishlist
    ids = None
    if src["mode"] == "pick":
        ids = [_db_id(i) for i in dict.fromkeys(with_descendants(svc, src["ids"]))] or None
    try:
        if sorted(ids or []) != sorted(saved or []):
            v.set_scope(ids)
            svc.owned = v.owned_map()
        yield
    finally:
        if sorted(ids or []) != sorted(saved or []):
            v.set_scope(saved)
            svc.owned = owned
        v.target_pf = target


def own_source(fn):
    """For an api method whose first argument after svc is the checklist id."""
    @functools.wraps(fn)
    def wrapper(svc, id, *a, **k):
        cl = svc.vault.checklist(id)
        with source_scope(svc, cl):
            return fn(svc, id, *a, **k)
    return wrapper


@api("lists.source", quiet=True)
def lists_source(svc, id):
    cl = svc.vault.checklist(id)
    if not cl:
        raise ApiError("checklist not found")
    return source_of(cl)


@api("lists.setSource", mutates=True)
def lists_set_source(svc, id, mode, ids=None):
    """mode 'all' | 'pick' | 'view'; for 'pick', ids = the portfolios / categories to count (at least one).  Also shows the checklist under exactly those portfolios."""
    if mode not in ("all", "pick", "view"):
        raise ApiError("Choose where this checklist counts from.")
    ids = [str(i) for i in (ids or [])]
    if mode == "pick" and not ids:
        raise ApiError("Pick at least one portfolio, or choose 'Everything I own'.")
    v = svc.vault
    cl = v.checklist(id)
    if not cl:
        raise ApiError("checklist not found")
    rules = dict(checklists._load_rules(cl) or {})
    rules["sources"] = {"mode": mode, "ids": ids if mode == "pick" else []}
    v.update_checklist(id, cl["name"], cl["mode"], bool(cl["per_variant"]), rules, cl["notes"] or "")
    from .lists import lists_set_portfolios
    lists_set_portfolios(svc, id, ids if mode == "pick" else [])
    svc.bump("changed")
    return source_of(v.checklist(id))
