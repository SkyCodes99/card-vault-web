"""Home (ui/src/pages/home/): the collection at a glance, in ONE question.  A short summary - every tile on the screen opens the full page - so nothing here is new work:
  value       the collection's total (the same stats as Analytics) and today's change (marketmovers.my_day, the Movers panel's 1-day rule, on the cards I hold)
  movers      the 3 biggest moves of MY copies today (the same pass)
  sets        the 3 started sets with the fewest items still missing, with "$X to finish" (setgoalsapi.sets_costs: the one table the set boxes read; None + _later until it is kept)
  recent      the last 5 things added
  goals       my goals (goals.progress) and the goals with a price (the price alerts list: "under $N to finish" for a set, "under $N" for a card or product)
Today's moves are kept until the collection, the prices or the day change, so opening Home again costs next to nothing."""
import datetime

from .. import marketmovers, pricepick
from ..db import IndexNotReady
from . import alerts, goals
from .registry import api

SETS, RECENT, GOALS = 3, 5, 4


def _today(svc, v):
    """marketmovers.my_day.  Each card's move is kept until the prices or the day change (an add works out only the new card's); the answer until the collection changes too."""
    stamp = (v.game, v.meta("prices_updated"), datetime.date.today().isoformat())
    key = (svc.data_mark(), v.user_id, tuple(v.scope or ()), stamp)
    kept = getattr(svc, "_home_day", None)
    if kept and kept["key"] == key:
        return kept["day"]
    moves = kept["moves"] if kept and kept["stamp"] == stamp else {}
    owned = v.owned_map()
    new = [cid for cid in owned if cid not in moves]
    if new:
        moves.update(marketmovers.day_moves(v, new))
    day = marketmovers.my_day(v, owned, moves=moves)
    svc._home_day = {"key": key, "stamp": stamp, "moves": moves, "day": day}
    return day


def _closest(svc, v):
    """The started sets closest to finishing (fewest missing at each set's own goal), or None while the card index - or the whole card list's part of the costs (about a second
    for Magic) - is not worked out yet: Home never waits for it.  The page then asks set.costs itself, as the set boxes do, and asks again."""
    from .setgoalsapi import sets_costs, sets_costs_ready
    try:
        if not sets_costs_ready(svc):
            return None, None
        table = sets_costs(svc)
    except IndexNotReady:
        return None, None
    started = [sid for sid, n in v.owned_by_set().items() if n and sid in table]
    started.sort(key=lambda sid: (table[sid]["missing"], table[sid]["cost"]))
    pick = started[:SETS]
    names = dict(v.conn.execute(f"SELECT id, name FROM sets WHERE id IN ({','.join('?' * len(pick))})", pick).fetchall()) if pick else {}
    return [{"id": sid, "name": names.get(sid, sid), **table[sid]} for sid in pick], {sid: r["cost"] for sid, r in table.items()}


def _recent(v):
    from .cards import img
    rows = v.conn.execute("SELECT card_id, qty, COALESCE(NULLIF(added,''), updated_at) AS day FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY day DESC, id DESC LIMIT ?",
                          (v.user_id, v.game, RECENT * 2)).fetchall()
    lights = v.card_lights([r["card_id"] for r in rows])
    out = []
    for r in rows:
        c = lights.get(r["card_id"])
        if c and len(out) < RECENT:
            out.append({"id": r["card_id"], "name": c.get("name") or r["card_id"], "qty": r["qty"], "price": pricepick.price_for(v, r["card_id"], c.get("price_usd")), "img": img(r["card_id"], c.get("set_id") or "")})
    return out


def _goals(svc, costs):
    """Every goal, the ones that need you first: reached price goals, then goals in progress (closest first), then the other price goals."""
    rows = []
    for g in goals.progress(svc):
        if g["pct"] >= 100:
            continue
        rows.append({"id": g["id"], "kind": "goal", "type": g["type"], "name": g["name"], "key": g.get("key", ""), "pct": g["pct"], "have": g["have"], "total": g["total"], "money": bool(g.get("money")),
                     "cost": costs.get(g["key"]) if g["type"] == "set" and costs is not None else None})
    rows.sort(key=lambda r: -r["pct"])
    mine = [a for a in alerts._all(svc) if a.get("game") == svc.vault.game]
    watch = alerts.listing(svc, mine, costs)["rows"] if mine else []
    hits = [{"id": a["id"], "kind": "price", "type": a["type"], "name": a["name"], "key": a["key"], "dir": a["dir"], "price": a["price"], "now": a["now"], "hit": a["hit"]} for a in watch]
    order = [r for r in hits if r["hit"]] + rows + [r for r in hits if not r["hit"]]
    return order[:GOALS], len(order)


@api("home.glance", quiet=True)
def glance(svc):
    v = svc.vault
    st, sealed = v.stats(), v.sealed_in_view()
    day = _today(svc, v)
    sets, costs = _closest(svc, v)
    shown, n_goals = _goals(svc, costs)
    return {"value": round(st["value"] + sealed["value"], 2), "copies": st["copies"] + sealed["copies"], "unique": st["unique"],
            "today": {"change": day["change"], "compared": day["compared"]}, "movers": day["top"],
            "sets": sets, "recent": _recent(v), "goals": shown, "goalCount": n_goals, "game": svc.game.name, **({"_later": True} if sets is None else {})}
