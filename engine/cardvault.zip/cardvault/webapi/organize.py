"""Organize: binder pages, duplicates, storage locations."""
from .. import tools
from .cards import img
from .money import card_row
from .registry import api


def _checklist_pockets(svc, list_id):
    """One pocket per ENTRY of the checklist, in its order - exactly what the checklist shows (one card per Pokemon / per rarity slot, or each card / variant), and a pocket counts as
    owned only when that entry is owned within this checklist (not any card that merely could fit)."""
    from .lists import progress_of, tile_dict
    cl, p = progress_of(svc, int(list_id))
    out = []
    for t in p.tiles:
        d = tile_dict(svc, t, int(list_id))
        if not d or d.get("noCard") or not d.get("id"):
            continue
        c = svc.vault.card_light(d["id"]) or {}
        out.append({"id": d["id"], "name": d.get("title") or c.get("name", ""), "number": c.get("local_id", ""), "qty": d.get("qty", 0) if d.get("owned") else 0,
                    "img": d.get("img"), "tcg": d.get("tcg", ""), "label": d.get("sub", "")})
    return out


@api("binder.cards")
def binder_cards(svc, kind="set", key=None):
    v = svc.vault
    if kind == "set":
        left = v.excluded_cards(key) if key else set()                  # cards the person left out of this set are not part of it
        ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (key,)) if r[0] not in left] if key else []
    elif kind == "list":
        return _checklist_pockets(svc, key) if key else []
    else:
        ids = [r[0] for r in v.conn.execute(
            "SELECT c.id FROM cards c WHERE c.id IN (SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0) "
            "ORDER BY (SELECT release_date FROM sets WHERE id=c.set_id), c.set_id, c.sort_key, c.local_id", (v.user_id, v.game))]
    out = []
    for cid in ids:
        c = v.card_light(cid)
        if c:
            out.append({"id": cid, "name": c["name"], "number": c["local_id"], "qty": svc.owned.get(cid, 0), "img": img(cid, c["set_id"]), "tcg": c.get("tcg_id") or ""})
    return out


@api("duplicates.list")
def duplicates(svc, keep=1):
    return [{"id": r["card_id"], "name": r["name"], "set": r["set_name"] or "", "number": r["number"], "qty": r["qty"], "extra": r["extra"], "unit": r["unit"],
             "value": r["value"]} for r in tools.duplicates(svc.vault, keep)]


@api("locations.list")
def locations(svc):
    loc = tools.locations(svc.vault)
    names = sorted(loc, key=lambda n: (n == "(no location)", n.lower()))
    return [{"name": n, **loc[n]} for n in names]


@api("locations.cards")
def location_cards(svc, name):
    return [card_row(svc, i) for i in tools.cards_in_location(svc.vault, name) if svc.vault.card_light(i)]
