"""Organize: binder pages, duplicates, storage locations."""
from .. import tools
from .cards import img
from .money import card_row
from .registry import api


@api("binder.cards")
def binder_cards(svc, kind="set", key=None):
    v = svc.vault
    if kind == "set":
        ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (key,))] if key else []
    elif kind == "list":
        ids = list(v.checklist_members(key)) if key else []
    else:
        ids = [r[0] for r in v.conn.execute(
            "SELECT c.id FROM cards c WHERE c.id IN (SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0) "
            "ORDER BY (SELECT release_date FROM sets WHERE id=c.set_id), c.set_id, c.sort_key, c.local_id", (v.user_id, v.game))]
    out = []
    for cid in ids:
        c = v.card_light(cid)
        if c:
            out.append({"id": cid, "name": c["name"], "number": c["local_id"], "qty": svc.owned.get(cid, 0), "img": img(cid, c["set_id"])})
    return out


@api("duplicates.list")
def duplicates(svc, keep=1):
    return [{"id": r["card_id"], "name": r["name"], "set": r["set_name"] or "", "number": r["number"], "qty": r["qty"], "extra": r["extra"], "unit": r["unit"],
             "value": r["value"]} for r in tools.duplicates(svc.vault, keep)]


@api("locations.list")
def locations(svc):
    loc = tools.locations(svc.vault)
    names = sorted(loc, key=lambda n: (n == "(no location)", n.lower()))
    return [{"name": n, **loc[n]} for n in names]


@api("locations.cards")
def location_cards(svc, name):
    return [card_row(svc, i) for i in tools.cards_in_location(svc.vault, name) if svc.vault.card_light(i)]
