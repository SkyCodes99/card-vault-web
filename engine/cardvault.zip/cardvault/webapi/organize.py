"""Organize: binder pages, duplicates, storage locations."""
from .. import tools
from .cards import img
from .money import card_row
from .registry import api
from .service import ApiError


def _checklist_pockets(svc, list_id):
    """One pocket per ENTRY of the checklist, in its order - exactly what the checklist shows (one card per Pokemon / per rarity slot, or each card / variant), and a pocket counts as
    owned only when that entry is owned within this checklist (not any card that merely could fit)."""
    from .lists import progress_of, tile_dict
    cl, p = progress_of(svc, int(list_id))
    out = []
    for t in p.tiles:
        d = tile_dict(svc, t, int(list_id))
        if d and d.get("noCard"):                                        # a Pokedex number with no card in the chosen categories: a blank spot in the binder
            out.append({"id": "", "none": True, "name": d.get("title") or "", "number": "", "qty": 0, "img": "", "tcg": "", "label": "No card exists"})
            continue
        if not d or not d.get("id"):
            continue
        c = svc.vault.card_light(d["id"]) or {}
        out.append({"id": d["id"], "name": d.get("title") or c.get("name", ""), "number": c.get("local_id", ""), "qty": d.get("qty", 0) if d.get("owned") else 0,
                    "img": d.get("img"), "tcg": d.get("tcg", ""), "label": d.get("sub", ""),
                    "slot": d.get("key") if d.get("slot") else "", "options": d.get("options", 0)})
    return out


@api("binder.cards")
def binder_cards(svc, kind="set", key=None):
    v = svc.vault
    if kind == "set":
        left = v.excluded_cards(key) if key else set()                  # cards the person left out of this set are not part of it
        ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (key,)) if r[0] not in left] if key else []
    elif kind == "list":
        return _checklist_pockets(svc, key) if key else []
    else:
        ids = [r[0] for r in v.conn.execute(
            "SELECT c.id FROM cards c WHERE c.id IN (SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0) "
            "ORDER BY (SELECT release_date FROM sets WHERE id=c.set_id), c.set_id, c.sort_key, c.local_id", (v.user_id, v.game))]
    out = []
    for cid in ids:
        c = v.card_light(cid)
        if c:
            out.append({"id": cid, "name": c["name"], "number": c["local_id"], "qty": svc.owned.get(cid, 0), "img": img(cid, c["set_id"]), "tcg": c.get("tcg_id") or ""})
    return out


def binder_payload(svc, kind, key, title="", owner=""):
    """What a shared binder page may contain: for each spot its picture, name, number and whether it is owned / still needed / has no card.  Never prices, copies or notes."""
    from ..db import picture_url
    v = svc.vault
    cards = binder_cards(svc, kind, key)
    ids = [c["id"] for c in cards if c["id"]]
    base = {}
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        for cid, b in v.conn.execute(f"SELECT id, image_base FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk):
            base[cid] = b
    slots = []
    for c in cards:
        if c.get("none"):
            slots.append({"state": "none", "name": c["name"], "number": ""})
            continue
        url = picture_url(base.get(c["id"]) or "", "low") if base.get(c["id"]) else ""
        if not url and c.get("tcg"):
            url = f"https://tcgplayer-cdn.tcgplayer.com/product/{c['tcg']}_200w.jpg"
        slots.append({"state": "owned" if c["qty"] > 0 else "missing", "name": c["name"], "number": str(c["number"]), "img": url})
    if not title:
        title = {"set": lambda: next((x["name"] for x in v.sets() if x["id"] == key), "Binder"), "list": lambda: (v.checklist(int(key)) or {"name": "Binder"})["name"]}.get(kind, lambda: "My collection")()
    return {"schema": SCHEMA_BINDER, "title": title, "owner": owner or "", "subtitle": {"set": "Set binder", "list": "Checklist binder"}.get(kind, "Cards I own"), "slots": slots}


SCHEMA_BINDER = 1


@api("binder.exportPage")
def binder_export(svc, kind, key, path, title="", owner="", layout="3x3"):
    """Save the binder as one web page anyone can open (and send): colour = owned, grey = needed, blank = no card exists."""
    from .. import binderpage
    svc.need_grant(path)
    if kind != "own" and not key:
        raise ApiError("Choose a set or a checklist first.")
    payload = binder_payload(svc, kind, key, title, owner)
    payload["layout"] = layout
    page = binderpage.page_html(payload)
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
    return {"path": path, "slots": len(payload["slots"]), "kb": round(len(page) / 1000)}


def _pages(svc):
    import json
    try:
        return json.loads(svc.pget("binder_pages") or "{}")
    except ValueError:
        return {}


def _page_key(svc, kind, key):
    return f"{svc.game.id}|{kind}|{key or ''}"


@api("binder.pageStatus", quiet=True)
def binder_page_status(svc, kind, key):
    """Is this binder already published as a link (and where)?"""
    return {"page": _pages(svc).get(_page_key(svc, kind, key)) or None}


@api("binder.publish")
def binder_publish(svc, kind, key, title="", owner="", layout="3x3"):
    """Publish (or refresh) this binder as a link anyone can open.  The page holds only what the binder shows (picture, name, number, owned / needed / no card) - never prices, copies or notes."""
    import json
    from .. import binderpage
    from ..cloud import skycloud as sc
    from . import accountapi
    a = accountapi.account(svc, need=True)
    if kind != "own" and not key:
        raise ApiError("Choose a set or a checklist first.")
    payload = binder_payload(svc, kind, key, title, owner)
    payload["layout"] = layout
    body = {"title": payload["title"], "html": binderpage.page_html(payload)}
    pages, k = _pages(svc), _page_key(svc, kind, key)
    cur = pages.get(k)
    try:
        if cur:
            try:
                out = a.call("PUT", "/v1/pages/" + cur["token"], body, timeout=120)
                out = {"token": cur["token"], "url": out.get("url") or cur["url"]}
            except sc.CloudError as e:
                if e.status != 404:
                    raise
                cur = None
        if not cur:
            out = a.call("POST", "/v1/pages", body, timeout=120)
    except sc.CloudError as e:
        raise ApiError(str(e))
    pages[k] = {"token": out["token"], "url": out["url"], "title": payload["title"]}
    svc.pset("binder_pages", json.dumps(pages))
    return {"page": pages[k], "slots": len(payload["slots"])}


@api("binder.unpublish")
def binder_unpublish(svc, kind, key):
    """Take the link down: the page stops working immediately."""
    import json
    from ..cloud import skycloud as sc
    from . import accountapi
    a = accountapi.account(svc, need=True)
    pages, k = _pages(svc), _page_key(svc, kind, key)
    cur = pages.pop(k, None)
    if cur:
        try:
            a.call("DELETE", "/v1/pages/" + cur["token"])
        except sc.CloudError as e:
            if e.status != 404:
                pages[k] = cur
                raise ApiError(str(e))
        svc.pset("binder_pages", json.dumps(pages))
    return {"page": None}


@api("duplicates.list")
def duplicates(svc, keep=1):
    return [{"id": r["card_id"], "name": r["name"], "set": r["set_name"] or "", "number": r["number"], "qty": r["qty"], "extra": r["extra"], "unit": r["unit"],
             "value": r["value"]} for r in tools.duplicates(svc.vault, keep)]


@api("locations.list")
def locations(svc):
    loc = tools.locations(svc.vault)
    names = sorted(loc, key=lambda n: (n == "(no location)", n.lower()))
    return [{"name": n, **loc[n]} for n in names]


@api("locations.cards")
def location_cards(svc, name):
    return [card_row(svc, i) for i in tools.cards_in_location(svc.vault, name) if svc.vault.card_light(i)]
