"""The What's new feed (cardvault/whatsnew.py): the daily news written from data - new sets and products, the owner's price movers, releases in the next 14 days, Shop restocks."""
from .. import whatsnew
from .registry import api


@api("whatsnew.get", quiet=True)
def get(svc, all=False, days=30):
    """-> {days: [{day, lines: [{type, game, text}], movers: [{kind rise|drop, game, game_name, name, old, new, pct, span}]}], mine, all}. Newest day first; the owner's games unless all."""
    return whatsnew.feed(svc, bool(all), max(1, min(int(days or 30), 30)))
