"""price.detail: the card drawer's price per grade / printing / language / condition and the newest asking prices (cardvault/pricedetail.py).  Reads stored data only."""
from .. import langlink, pricedetail
from .registry import api


@api("price.detail", quiet=True)
def price_detail(svc, id):
    """{printings: [{name, usd}], english: {game, rows} | None, asks: {grades, conditions, languages, recent, at}}"""
    cid = str(id)
    r = svc.vault.conn.execute("SELECT variant_prices, variants, price_usd FROM cards WHERE id=?", (cid,)).fetchone()
    row = {"variant_prices": r["variant_prices"], "variants": r["variants"], "price_usd": r["price_usd"]} if r else {}
    link = None
    if svc.game.id in langlink.ENGLISH_OF:
        from .scanweb import english
        link = (english(svc, [{"game": svc.game.id, "id": cid}]) or [None])[0]
    return pricedetail.detail(svc.vault.conn, cid, row, link)
