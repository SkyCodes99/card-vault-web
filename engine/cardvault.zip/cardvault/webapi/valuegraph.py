"""The value graph on the home page (Analytics -> Overview): the same series as portfolio.history, but for ONE portfolio chosen on the graph itself ("all" = everything), answered from a kept copy.
  - up to date -> the kept copy, no work;
  - the collection or its prices changed since -> the kept copy is answered AT ONCE (marked _later, so the screen asks again a second later) and the new one is worked out in the
    background in short steps (graphwarm.py) - never inside a question, so a click is never stuck behind seconds of graph work (owner, 2026-11-12: zero delay);
  - nothing kept yet -> a 'pending' answer at once (the screen draws the last graph it saved itself meanwhile) and the same background work.
The chosen portfolio is not the sidebar's view: the sidebar's choice is put back untouched when the graph is done."""
import copy
import datetime
import json
from contextlib import contextmanager

from .. import graphcache, portfoliooptions, pricepick, valueseries
from .portfolios import MAIN, _api_id, _db_id, main_name, with_descendants
from .registry import api


def db_ids(svc, portfolio):
    """The portfolios behind the dropdown's choice, as database ids (a category brings everything inside it); None = everything.
    A list (the side bar's ticked portfolios) is exactly those portfolios; an empty list, or one naming none that still exist, is everything."""
    if portfolio in (None, "", "all") or portfolio == []:
        return None
    known = {p["uuid"] for p in svc.vault.portfolios()} | {MAIN}
    if isinstance(portfolio, (list, tuple)):
        return [_db_id(i) for i in portfolio if i in known] or None
    if portfolio not in known:
        return None                                         # deleted somewhere else: show everything
    return [_db_id(i) for i in with_descendants(svc, [_api_id(_db_id(portfolio))])]


def name_of(svc, portfolio):
    """What the dropdown calls this choice (kept with the graph, so the dropdown can name it before the portfolio list has loaded)."""
    if portfolio == MAIN:
        return main_name(svc)
    return next((p["name"] for p in svc.vault.portfolios() if p["uuid"] == portfolio), "All")


def _show(v, ids):
    v.conn.execute("DELETE FROM temp.scope")
    for i in ids or []:
        v.conn.execute("INSERT OR IGNORE INTO temp.scope VALUES(?)", (i,))
    v.scope = list(ids) if ids else None
    v._commit()


@contextmanager
def viewing(v, ids):
    """Look at exactly these portfolios for a moment (tools.* read the view), then go back to what the sidebar shows."""
    before = list(v.scope) if v.scope else None
    _show(v, ids)
    try:
        yield
    finally:
        _show(v, before)


def stamp(v, svc=None):
    """Changes whenever something the graph is built from changes: the copies, the sealed products, the prices (and which prices are used), the day."""
    from .. import sethistory
    parts = [datetime.date.today().isoformat(), pricepick.label(v), v.meta("prices_updated"), v.game, v.user_id, "modes-1", sethistory.folder_stamp(svc, v.game) if svc else 0]
    for table in ("lots", "sealed"):
        parts += list(v.conn.execute(f"SELECT COUNT(*), COALESCE(SUM(qty),0), COALESCE(SUM(deleted),0), COALESCE(MAX(updated_at),'') FROM u.{table} WHERE user_id=? AND game=?", (v.user_id, v.game)).fetchone())
    parts += [r[0] for r in v.conn.execute("SELECT updated_at FROM u.portfolios WHERE user_id=? ORDER BY uuid", (v.user_id,))]          # (which portfolios exist and what is inside a category)
    return json.dumps(parts, default=str)


def build_steps(svc, portfolio, range_key, start=None, end=None, mode="full"):
    """The graph in short steps (a generator that returns it): each step looks at the chosen portfolios only while it runs, so the sidebar's view is right between two steps."""
    v, ids = svc.vault, db_ids(svc, portfolio)
    gen = valueseries.series_steps(v, range_key, start or None, end or None, mode=mode, svc=svc)
    while True:
        with viewing(v, ids):
            try:
                next(gen)
            except StopIteration as e:
                s = e.value
                break
        yield
    yield                                                   # (the splits below are a step of their own)
    pts = s["points"]
    opts = portfoliooptions.options(v, ids or [])
    return {**s, "options": opts, "portfolio": portfolio or "all", "name": name_of(svc, portfolio) if portfolio not in (None, "", "all") else "All", "range": range_key, "game": svc.game.id, "value": s.get("total", pts[-1]["value"] if pts else 0.0), "invested": pts[-1]["invested"] if pts else 0.0}


def key_of(v, portfolio, range_key, start=None, end=None, mode="full"):
    return json.dumps([v.user_id, portfolio, range_key, start or "", end or ""] + ([mode] if mode != "full" else []))


def args_of(key):
    """key_of backwards: (portfolio, range, start, end, mode), or None for a key that is not a graph's (kept() keeps Analytics > Value's series in the same file)."""
    try:
        k = json.loads(key)
    except ValueError:
        return None
    if not isinstance(k, list) or len(k) not in (5, 6) or k[1] == "series":
        return None
    return k[1], k[2], k[3], k[4], (k[5] if len(k) == 6 else "full")


def kept(svc, parts, work):
    """The same kept-copy answer for any value series of what the sidebar shows (Analytics > Value): `parts` name it, `work()` works it out.  A long price history
    is a few seconds of work on a big collection, so an unchanged one is never worked out twice.  A changed one is worked out at once - never the old copy first (that showed a moved copy
    still in its old portfolio, and two questions in a row got two different answers) - and each caller gets its own copy of the kept answer."""
    v = svc.vault
    key = json.dumps([v.user_id, "series", sorted(v.scope or [])] + list(parts))
    now = stamp(v, svc)
    k = graphcache.get(v, key)
    if k and k["stamp"] == now:
        return copy.deepcopy(k["result"])
    result = work()
    graphcache.put(v, key, now, copy.deepcopy(result))
    return result


@api("portfolio.graph", quiet=True)
def graph(svc, portfolio="all", range="1m", start=None, end=None, mode="full"):
    """Always answered at once, never worked out here: the kept graph (fresh, or the last one with _later while the new one is worked out in the background, graphwarm.py),
    or - nothing kept yet - an empty 'pending' answer (the screen keeps drawing the graph it saved itself) and _later."""
    from . import graphwarm
    v = svc.vault
    portfolio = portfolio or "all"
    mode = mode if mode in ("full", "purchase") else "full"
    key = key_of(v, portfolio, range, start, end, mode)
    kept = graphcache.get(v, key)
    if kept and kept["stamp"] == stamp(v, svc):
        return {**kept["result"], "fresh": True}
    graphwarm.want(svc, key, first=True)
    if kept:
        return {**kept["result"], "fresh": False, "_later": True}
    return {"points": [], "pending": True, "fresh": False, "_later": True, "portfolio": portfolio, "range": range, "mode": mode, "game": svc.game.id}
