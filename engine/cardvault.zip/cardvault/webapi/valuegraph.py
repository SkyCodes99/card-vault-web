"""The value graph on the home page (Analytics -> Overview): the same series as portfolio.history, but for ONE portfolio chosen on the graph itself ("all" = everything), answered from a kept copy.
  - up to date -> the kept copy, no work;
  - the collection or its prices changed since -> the kept copy is answered AT ONCE (marked _later, so the screen asks again a second later) and the new one is worked out on that second question;
  - nothing kept yet -> worked out now (the screen draws the last graph it saved itself meanwhile).
The chosen portfolio is not the sidebar's view: the sidebar's choice is put back untouched when the graph is done."""
import copy
import datetime
import json
from contextlib import contextmanager

from .. import graphcache, portfoliooptions, pricepick, tools
from .portfolios import MAIN, _api_id, _db_id, main_name, with_descendants
from .registry import api

_SERVED = set()                       # (key, stamp of the kept copy) already answered as 'old' once: the next question gets the new one


def db_ids(svc, portfolio):
    """The portfolios behind the dropdown's choice, as database ids (a category brings everything inside it); None = everything."""
    if portfolio in (None, "", "all"):
        return None
    known = {p["uuid"] for p in svc.vault.portfolios()} | {MAIN}
    if portfolio not in known:
        return None                                         # deleted somewhere else: show everything
    return [_db_id(i) for i in with_descendants(svc, [_api_id(_db_id(portfolio))])]


def name_of(svc, portfolio):
    """What the dropdown calls this choice (kept with the graph, so the dropdown can name it before the portfolio list has loaded)."""
    if portfolio == MAIN:
        return main_name(svc)
    return next((p["name"] for p in svc.vault.portfolios() if p["uuid"] == portfolio), "All")


def _show(v, ids):
    v.conn.execute("DELETE FROM temp.scope")
    for i in ids or []:
        v.conn.execute("INSERT OR IGNORE INTO temp.scope VALUES(?)", (i,))
    v.scope = list(ids) if ids else None
    v._commit()


@contextmanager
def viewing(v, ids):
    """Look at exactly these portfolios for a moment (tools.* read the view), then go back to what the sidebar shows."""
    before = list(v.scope) if v.scope else None
    _show(v, ids)
    try:
        yield
    finally:
        _show(v, before)


def stamp(v, svc=None):
    """Changes whenever something the graph is built from changes: the copies, the sealed products, the prices (and which prices are used), the day."""
    from .. import sethistory
    parts = [datetime.date.today().isoformat(), pricepick.label(v), v.meta("prices_updated"), v.game, v.user_id, "modes-1", sethistory.folder_stamp(svc, v.game) if svc else 0]
    for table in ("lots", "sealed"):
        parts += list(v.conn.execute(f"SELECT COUNT(*), COALESCE(SUM(qty),0), COALESCE(SUM(deleted),0), COALESCE(MAX(updated_at),'') FROM u.{table} WHERE user_id=? AND game=?", (v.user_id, v.game)).fetchone())
    parts += [r[0] for r in v.conn.execute("SELECT updated_at FROM u.portfolios WHERE user_id=? ORDER BY uuid", (v.user_id,))]          # (which portfolios exist and what is inside a category)
    return json.dumps(parts, default=str)


def build(svc, portfolio, range_key, start=None, end=None, mode="full"):
    v = svc.vault
    with viewing(v, db_ids(svc, portfolio)):
        s = tools.portfolio_series(v, range_key, start or None, end or None, mode=mode, svc=svc)
    pts = s["points"]
    opts = portfoliooptions.options(v, db_ids(svc, portfolio) or [])
    return {**s, "options": opts, "portfolio": portfolio or "all", "name": name_of(svc, portfolio) if portfolio not in (None, "", "all") else "All", "range": range_key, "game": svc.game.id, "value": s.get("total", pts[-1]["value"] if pts else 0.0), "invested": pts[-1]["invested"] if pts else 0.0}


def kept(svc, parts, work):
    """The same kept-copy answer for any value series of what the sidebar shows (Analytics > Value): `parts` name it, `work()` works it out.  A long price history
    is a few seconds of work on a big collection, so an unchanged one is never worked out twice.  A changed one is worked out at once - never the old copy first (that showed a moved copy
    still in its old portfolio, and two questions in a row got two different answers) - and each caller gets its own copy of the kept answer."""
    v = svc.vault
    key = json.dumps([v.user_id, "series", sorted(v.scope or [])] + list(parts))
    now = stamp(v, svc)
    k = graphcache.get(v, key)
    if k and k["stamp"] == now:
        return copy.deepcopy(k["result"])
    result = work()
    graphcache.put(v, key, now, copy.deepcopy(result))
    return result


@api("portfolio.graph", quiet=True)
def graph(svc, portfolio="all", range="1m", start=None, end=None, mode="full"):
    v = svc.vault
    portfolio = portfolio or "all"
    mode = mode if mode in ("full", "purchase") else "full"
    key = json.dumps([v.user_id, portfolio, range, start or "", end or ""] + ([mode] if mode != "full" else []))
    now = stamp(v, svc)
    kept = graphcache.get(v, key)
    if kept and kept["stamp"] == now:
        return {**kept["result"], "fresh": True}
    if kept and (key, kept["stamp"]) not in _SERVED:
        _SERVED.add((key, kept["stamp"]))
        return {**kept["result"], "fresh": False, "_later": True}
    result = build(svc, portfolio, range, start, end, mode)
    graphcache.put(v, key, now, result)
    return {**result, "fresh": True}
