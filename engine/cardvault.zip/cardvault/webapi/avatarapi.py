"""Profile picture: a small square picture (the screen shrinks and crops it first, 2 MB at most to pick) saved with your profile and synced to your other devices."""
import base64
import re

from .registry import api
from .service import ApiError

MAX_BYTES = 150_000                 # the screen sends a ~256 px picture (about 20-40 KB); this is a safety limit, not the 2 MB picking limit
_RX = re.compile(r"^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$")
_MAGIC = {"jpeg": bytes([0xFF, 0xD8, 0xFF]), "png": bytes([0x89]) + b"PNG", "webp": b"RIFF"}


@api("profile.setAvatar", mutates=True)
def set_avatar(svc, data):
    m = _RX.match(data or "")
    if not m:
        raise ApiError("That picture couldn't be read.")
    raw = base64.b64decode(m.group(2))
    if len(raw) > MAX_BYTES or not raw.startswith(_MAGIC[m.group(1)]):
        raise ApiError("That picture is too large or not a valid image.")
    svc.pset("avatar", data)
    svc.audit("avatar_changed", "")
    return {"ok": True}


@api("profile.clearAvatar", mutates=True)
def clear_avatar(svc):
    svc.pset("avatar", None)
    return {"ok": True}
