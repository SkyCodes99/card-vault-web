"""Portfolios hold the cards; checklists are a view.

Every card you own belongs to a portfolio, and the portfolios carry the real value and statistics.  A checklist is only a hand-made mini collection drawn from
those portfolios - its own numbers are a picture and never add to the totals.  A card that was ticked on a checklist without a portfolio of its own (it landed
in Main) is "not placed yet": the person is asked, again and again until it is done, to move it into a portfolio they have made.  Cards only move; nothing is deleted."""
import json

from .. import checklists
from ..db import now_iso
from .registry import api
from .service import ApiError


def _members(svc):
    """{card id: [checklist names]} - every card that sits on at least one checklist."""
    v = svc.vault
    out = {}
    for cl in v.checklists():
        try:
            for cid in checklists.members(v, cl):
                out.setdefault(cid, []).append(cl["name"])
        except Exception:  # noqa: BLE001 - a broken list must not block the rest
            continue
    return out


def _scan(svc):
    """The first time on this device: the owned cards that sit on a checklist and have no portfolio of their own are flagged as needing one."""
    v = svc.vault
    key = "placement_scanned_" + v.game
    if svc.pget(key):
        return
    v.conn.execute("UPDATE u.lots SET portfolio='' WHERE user_id=? AND game=? AND portfolio='@lists'", (v.user_id, v.game))      # (from a short-lived earlier layout)
    if v.conn.execute("SELECT 1 FROM u.lots WHERE user_id=? AND game=? AND placed IS NULL AND deleted=0 LIMIT 1", (v.user_id, v.game)).fetchone():
        mem = _members(svc)
        rows = v.conn.execute("SELECT uuid, card_id, COALESCE(portfolio,'') FROM u.lots WHERE user_id=? AND game=? AND placed IS NULL", (v.user_id, v.game)).fetchall()
        for uid, cid, pf in rows:
            v.conn.execute("UPDATE u.lots SET placed=? WHERE uuid=?", (0 if (not pf and cid in mem) else 1, uid))
    v._commit()
    svc.pset(key, "1")


def _pending(svc):
    v = svc.vault
    _scan(svc)
    return v.conn.execute(
        "SELECT l.uuid, l.card_id, l.qty, c.name, c.local_id, s.name AS set_name FROM u.lots l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
        "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 AND l.placed=0 AND COALESCE(l.portfolio,'')='' ORDER BY s.name, c.local_id", (v.user_id, v.game)).fetchall()


def _portfolios(svc):
    return [{"id": p["uuid"], "name": p["name"]} for p in svc.vault.portfolios()]


@api("lists.placement.status", quiet=True)
def status(svc):
    v = svc.vault
    rows = _pending(svc)
    still = rows
    pfs = _portfolios(svc)
    note = _undo_note(svc)
    return {"count": len(still), "copies": sum(r["qty"] for r in still), "portfolios": pfs, "hasPortfolio": bool(pfs),
            "undo": ({"n": len(note["lots"]), "at": note["at"]} if note and note.get("game") == v.game else None)}


@api("lists.placement.items", quiet=True)
def items(svc):
    """The cards waiting for a portfolio, with the checklists they are on."""
    rows = _pending(svc)
    mem = _members(svc)
    return {"total": len(rows), "portfolios": _portfolios(svc),
            "items": [{"lot": r["uuid"], "card": r["card_id"], "name": r["name"], "number": r["local_id"], "set": r["set_name"] or "", "qty": r["qty"], "lists": mem.get(r["card_id"], [])[:3]}
                      for r in rows[:5000]]}


def _undo_note(svc):
    try:
        raw = svc.pget("placement_undo")
        return json.loads(raw) if isinstance(raw, str) and raw else None
    except ValueError:
        return None


@api("lists.placement.assign", mutates=True)
def assign(svc, moves):
    """Move cards into portfolios: moves = [{lot, portfolio}].  A portfolio the person has made is required (Main does not count)."""
    v = svc.vault
    real = {p["id"] for p in _portfolios(svc)}
    if not real:
        raise ApiError("Make a portfolio first - the cards need somewhere to go.")
    prev, now = [], now_iso()
    for m in moves or []:
        lot, to = m.get("lot"), m.get("portfolio")
        if not lot:
            continue
        if to not in real:
            raise ApiError("Pick one of your portfolios for every card.")
        r = v.conn.execute("SELECT COALESCE(portfolio,''), COALESCE(placed,1) FROM u.lots WHERE uuid=? AND user_id=?", (lot, v.user_id)).fetchone()
        if not r:
            continue
        prev.append({"lot": lot, "portfolio": r[0], "placed": r[1]})
        v.conn.execute("UPDATE u.lots SET portfolio=?, placed=1, updated_at=? WHERE uuid=? AND user_id=?", (to, now, lot, v.user_id))
    svc.pset("placement_undo", json.dumps({"lots": prev, "game": v.game, "at": now}))
    v._commit()
    return {"moved": len(prev)}


@api("lists.placement.undo", mutates=True)
def undo(svc):
    v = svc.vault
    u = _undo_note(svc)
    if not u or u.get("game") != v.game:
        raise ApiError("There is nothing to undo.")
    now = now_iso()
    for m in u["lots"]:
        v.conn.execute("UPDATE u.lots SET portfolio=?, placed=?, updated_at=? WHERE uuid=? AND user_id=?", (m["portfolio"], m["placed"], now, m["lot"], v.user_id))
    svc.pset("placement_undo", None)
    v._commit()
    return {"restored": len(u["lots"])}
