"""The New release calendar (cardvault/releasecal.py): upcoming and recent releases by month, filtered by game / kind, and "Add to wishlist" from a calendar line."""
import json

from .. import releasecal
from .registry import ApiError, api


@api("releases.get", quiet=True)
def get(svc, game="", kind=""):
    """-> {months: [{key, label, when, items}], tba: [...], counts, games, game, kind}. Dates are the catalogs' own; an announced item without a date is under 'date TBA'."""
    return releasecal.calendar(svc, game or None, kind or None)


@api("releases.wish", mutates=True)
def wish(svc, id, on=True):
    """Add a calendar item to the wishlist: a set whose cards are in the catalog (of the game you have open) puts its cards on the wishlist; anything else is saved as a wanted release (on=False takes it off again)."""
    v = svc.vault
    want = releasecal.wants(svc)
    if not on:
        want.pop(id, None)
        svc.pset(releasecal.KEY, json.dumps(want))
        return {"ok": True, "cards": 0, "saved": False}
    it = releasecal.find(v.data_dir, id)
    if not it:
        raise ApiError("That release is not in the calendar any more.")
    if it["kind"] in ("set", "toy") and it["ref"] and it["game"] == v.game:
        from .cards import with_undo
        have = v.wishlist_ids()
        ids = [c for c in releasecal.set_card_ids(v.data_dir, it["game"], it["ref"]) if c not in have]
        if ids:
            def run():
                with v.action(f"Added {it['name']} to the wishlist"):
                    for c in ids:
                        v.toggle_wishlist(c)
            res = with_undo(svc, run)
            res.update(cards=len(ids), saved=False)
            return res
    want[id] = {"name": it["name"], "game": it["game"], "date": it["date"]}
    svc.pset(releasecal.KEY, json.dumps(want))
    return {"ok": True, "cards": 0, "saved": True}
