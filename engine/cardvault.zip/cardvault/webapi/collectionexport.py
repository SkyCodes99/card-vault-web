"""Export my collection: every card I own, all games, as a spreadsheet - CSV at the path the person picked, and an XLSX beside it when openpyxl is there.
The columns are the ones Settings > Import reads back (card_id, variant, condition, qty, graded, grades, cert, purchase_price, notes, language,
location, edition, purchased, source, portfolio), plus kind (card or sealed), upc and the game, so the file re-imports with nothing lost.  The rest is for reading: set, number, name, current price
(the Settings > Price sources choice) and labels (the person's own card tags).
Only this person's own copies, tags and portfolio names are written: never another user's data, an email, a key or a sign-in detail.
Free, always."""
import csv
import os

from .registry import api
from . import mydata
from .. import pricepick
from ..customitems import PREFIX

HEAD = ["game", "card_id", "set", "number", "name", "variant", "condition", "language", "qty", "graded", "grade_company", "grade", "cert", "slab_status",
        "purchase_price", "current_price", "labels", "notes", "location", "edition", "purchased", "source", "portfolio", "kind", "upc",
        "your_estimate", "custom", "series", "item_category"]                                  # (the last four: an item of your own - cardvault/customitems.py - comes back as itself)


def _labels(conn, user_id, game):
    """The person's own card tags for one game as 'tag=value' (empty value: just 'tag')."""
    out = {}
    for cid, tag, val in conn.execute("SELECT card_id, tag, value FROM u.card_tags WHERE user_id=? AND game=? ORDER BY tag", (user_id, game)):
        out.setdefault(cid, []).append(f"{tag}={val}" if val not in (None, "") else str(tag))
    return {cid: "; ".join(parts) for cid, parts in out.items()}


def _game_rows(g, gid, user_id):
    picked = pricepick.prices_or_main(g)
    labels = _labels(g.conn, user_id, gid)
    rows = []
    mine = {PREFIX + r["uuid"]: r for r in g.conn.execute("SELECT * FROM u.custom_items WHERE user_id=? AND game=? AND deleted=0", (user_id, gid))}
    for r in g.conn.execute(
            "SELECT l.*, c.name, c.local_id, c.price_usd AS usd, s.name AS set_name FROM u.lots l "
            "LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 ORDER BY l.id", (user_id, gid)):
        now = pricepick.copy_price(g, r["card_id"], r["graded"], r["grade_company"], r["grade"], picked.get(r["card_id"]) if picked is not None else r["usd"])      # a graded copy: its graded price when one exists
        item = mine.get(r["card_id"])                                                  # an item of your own: its estimate is "your estimate", not a current (market) price
        rows.append([gid, r["card_id"], r["set_name"] or "", r["local_id"] or "", r["name"] or "", r["variant"] or "", r["condition"] or "",
                     r["language"] or "", r["qty"], r["graded"] or 0, r["grade_company"] or "", r["grade"] or "", r["cert"] or "", r["slab_status"] or "",
                     "" if r["purchase_price"] is None else r["purchase_price"], "" if now is None or item else now,
                     "; ".join(x for x in (item["labels"] or "").split(",") if x) if item else labels.get(r["card_id"], ""), r["notes"] or "", r["location"] or "", r["edition"] or "", r["purchased"] or "",
                     r["source"] or "", g._pf_name(r["portfolio"]), "card", "",
                     "" if not item or item["estimate"] is None else item["estimate"], 1 if item else "", item["series"] or "" if item else "", item["category"] or "" if item else ""])
    for r in g.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY rowid", (user_id, gid)):
        rows.append([gid, "", "", "", r["name"] or "", "", "", "", r["qty"], 0, "", "", "", "",
                     "" if r["paid"] is None else r["paid"], "", "", r["notes"] or "", "", "", r["purchased"] or "",
                     r["source"] or "", g._pf_name(r["portfolio"]), "sealed", r["upc"] or "", "", "", "", ""])
    return rows


def _xlsx(rows, dest, head=None, title="Collection"):
    """The same table as a workbook (one sheet, header frozen).  Returns False when openpyxl is not installed."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        return False
    wb = Workbook()
    ws = wb.active
    ws.title = title
    ws.append(head or HEAD)
    for row in rows:
        ws.append(row)
    for c in ws[1]:
        c.font = Font(bold=True)
    for cells in ws.iter_rows(min_row=2):
        for c in cells:
            if isinstance(c.value, str) and c.value[:1] in "=+-@":      # text typed by the person is never read as a formula
                c.data_type = "s"
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(dest)
    return True


@api("data.exportCollection")
def export_collection(svc, path):
    """Every card you own, all games: CSV at `path` (the file picker's choice) and an .xlsx beside it.  Settings > Import reads the CSV back."""
    svc.need_grant(path)
    v = svc.vault
    v._commit()
    rows, games = [], 0
    for gid in mydata._games(v.conn, v.user_id):
        g = v if gid == v.game else mydata._other_game(v, gid)
        try:
            rows += _game_rows(g, gid, v.user_id)
        finally:
            if g is not v:
                g.conn.close()
        games += 1
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(HEAD)
        w.writerows(rows)
    xlsx = _xlsx(rows, os.path.splitext(path)[0] + ".xlsx")
    svc.audit("export", "my collection (CSV" + (" + XLSX)" if xlsx else ")"))
    return {"lines": len(rows), "games": games, "xlsx": xlsx}
