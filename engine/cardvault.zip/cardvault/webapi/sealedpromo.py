"""Sealed products <-> the promo cards that come with them.  A booster box, a premium collection or a pre-release kit often holds a promo card (or a stamped card) that lives in a promo set,
so you could not tell from the card where it came from, or from the box what promo it holds.  Two kinds of link:
  - links YOU make (saved with your account settings, so they follow you to every device), and
  - suggestions the app works out from the names: a promo card whose "(source)" text is part of the product's name (e.g. "(Pokemon Center Elite Trainer Box)"), or a collection product that is
    named after the card ("Charizard ex Super-Premium Collection").  Suggestions are labelled as guesses and never become a link until you accept them."""
import json
import re

from .cards import img
from .registry import ApiError, api

KEY = "sealed_promos"                                   # {product name: [card ids]}
GENERIC = {"promo", "holo", "exclusive", "stamp", "stamped", "foil", "non", "the", "of", "and", "pokemon", "tcg", "card", "cards", "set", "league", "event", "prize", "box", "pack", "case", "kit", "tin"}
KIND = {"premium", "collection", "trainer", "trainers", "elite", "special", "deluxe", "battle", "deck", "bundle", "blister", "booster", "mini", "ultra", "super", "poster", "illustration", "gift", "holiday"}      # words that name a KIND of product, not which one
COLLECTION_WORDS = ("collection", "tin", "box", "bundle", "blister", "deck", "kit")


def _links(svc):
    try:
        d = json.loads(svc.pget(KEY) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _tokens(s):
    return {t for t in re.sub(r"[^a-z0-9]+", " ", (s or "").lower().replace("é", "e")).split() if t}


def _seq(s):
    return [t for t in re.sub(r"[^a-z0-9]+", " ", (s or "").lower().replace("é", "e")).split() if t]


def _paren_hit(paren, name_seq, name_set):
    """Does a card's "(source)" text point at THIS product?  Yes when the whole phrase (e.g. "Pokemon Center Elite Trainer Box") appears in the product's name, or when it names a set / series
    (two words that are neither generic nor a product kind, e.g. "Prismatic Evolutions") that the product's name also holds.  "(Premium Collection Promo)" alone matches nothing: that says what
    KIND of product it came in, not which one."""
    seq = _seq(paren)
    while seq and seq[-1] in GENERIC:
        seq.pop()
    if len(seq) >= 3 and (" " + " ".join(seq) + " ") in (" " + " ".join(name_seq) + " "):
        return len(seq) + 1
    ident = {t for t in seq if t not in GENERIC and t not in KIND}
    if len(ident) >= 2 and ident <= name_set:
        return 2 + len(ident)
    return 0


def _promo_cards(svc):
    """[(card id, name, set name, number, base name, tags)] for cards that live in promo sets (cached until the card list changes)."""
    v = svc.vault
    stamp = id(v.card_index())
    hit = getattr(svc, "_promo_idx", None)
    if hit and hit[0] == stamp:
        return hit[1]
    rows = []
    for r in v.conn.execute("SELECT c.id, c.name, c.local_id, c.rarity, s.name AS sname FROM cards c JOIN sets s ON s.id=c.set_id WHERE s.name LIKE '%Promo%' OR c.rarity LIKE 'Promo%' OR s.serie='Miscellaneous'"):
        nm = r["name"] or ""
        paren = re.findall(r"\(([^)]*)\)", nm)
        base = re.sub(r"\s*-\s*[\w./]+\s*(\(.*\))?$|\s*\(.*\)$", "", nm).strip().lower()
        rows.append((r["id"], nm, r["sname"] or "", r["local_id"] or "", base, [p for p in paren]))
    svc._promo_idx = (stamp, rows)
    return rows


def _card(svc, cid, owned):
    c = svc.vault.card_light(cid) or {}
    r = svc.vault.conn.execute("SELECT set_id FROM cards WHERE id=?", (cid,)).fetchone()
    return {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": c.get("price_usd"), "pic": img(cid, r["set_id"]) if r else "", "owned": owned.get(cid, 0)}


def _owned(svc):
    v = svc.vault
    return {r["card_id"]: r["q"] for r in v.conn.execute("SELECT card_id, SUM(qty) AS q FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY card_id", (v.user_id, v.game))}


def _suggest(svc, name):
    """Guesses from the names, best first."""
    pt = _tokens(name)
    ps = _seq(name)
    low = (name or "").lower()
    out = []
    for cid, nm, sname, no, base, parens in _promo_cards(svc):
        score = 0
        for p in parens:
            score = max(score, _paren_hit(p, ps, pt))                                  # "(Prismatic Evolutions Stamp)" inside "Prismatic Evolutions Booster Bundle"
        m = re.match(re.escape(base) + r"\s+(\S+)", low) if len(base) >= 5 else None
        if m and any(w in low for w in COLLECTION_WORDS) and re.match(r"(super|premium|ultra|special|collection|tin|box|elite|poster|binder|illustration|battle|v-|vmax|gx|deluxe|league|figure|pin)", m.group(1)):
            score = max(score, 9)                                                       # the product is named after the card, e.g. "Charizard ex Super-Premium Collection"                                                       # "Charizard ex Super-Premium Collection" holds the Charizard ex promo
        if score:
            out.append((score, cid))
    out.sort(key=lambda x: (-x[0], x[1]))
    return [cid for _, cid in out[:12]]


@api("sealed.promos", quiet=True)
def promos(svc, name, _t=None):
    """The promo cards linked to one sealed product (by you) and the app's guesses."""
    owned = _owned(svc)
    linked = [c for c in _links(svc).get(name, []) if svc.vault.card_light(c)]
    guess = [c for c in _suggest(svc, name) if c not in linked]
    return {"name": name, "linked": [_card(svc, c, owned) for c in linked], "suggested": [_card(svc, c, owned) for c in guess]}


@api("sealed.promoLink", mutates=True)
def promo_link(svc, name, card, on=True):
    if not name or not svc.vault.card_light(card):
        raise ApiError("Pick a sealed product and a card.")
    d = _links(svc)
    cur = [c for c in d.get(name, []) if c != card]
    if on:
        cur.append(card)
    if cur:
        d[name] = cur[:40]
    else:
        d.pop(name, None)
    svc.pset(KEY, json.dumps(d))
    return {"ok": True, "n": len(cur)}


@api("sealed.promoSearch", quiet=True)
def promo_search(svc, q, limit=20):
    """Cards to link: a text search that puts promo cards first."""
    v = svc.vault
    owned = _owned(svc)
    ids = [r[0] for r in v.query_cards(text=(q or "").strip(), sort="default")[:400]]
    promo = {p[0] for p in _promo_cards(svc)}
    ids.sort(key=lambda i: 0 if i in promo else 1)
    return {"cards": [{**_card(svc, i, owned), "promo": i in promo} for i in ids[:max(1, min(60, int(limit)))]]}


_FIRST = re.compile(r"(super|premium|ultra|special|collection|tin|box|elite|poster|binder|illustration|battle|v-|vmax|gx|deluxe|league|figure|pin)")


def _sealed_index(svc):
    """[(product name, its lower-case name, its tokens)] - built once per card list."""
    v = svc.vault
    stamp = id(v.card_index())
    hit = getattr(svc, "_sealed_idx", None)
    if hit and hit[0] == stamp:
        return hit[1]
    try:
        rows = [(r[0], r[0].lower(), _tokens(r[0]), _seq(r[0])) for r in v.conn.execute("SELECT DISTINCT name FROM sealed_products WHERE name != ''")]
    except Exception:  # noqa: BLE001 - a game with no sealed products
        rows = []
    svc._sealed_idx = (stamp, rows)
    return rows


@api("card.fromSealed", quiet=True)
def from_sealed(svc, card):
    """The sealed products a card comes in: the ones you linked it to, and likely ones from the names."""
    mine = [n for n, cs in _links(svc).items() if card in cs]
    rec = next((p for p in _promo_cards(svc) if p[0] == card), None)
    likely = []
    if rec:
        _cid, _nm, _sn, _no, base, parens = rec
        for name, low, pt, ps in _sealed_index(svc):
            if name in mine:
                continue
            ok = any(_paren_hit(p, ps, pt) for p in parens)
            if not ok and len(base) >= 5 and any(w in low for w in COLLECTION_WORDS):
                m = re.match(re.escape(base) + r"\s+(\S+)", low)
                ok = bool(m and _FIRST.match(m.group(1)))
            if ok:
                likely.append(name)
            if len(likely) >= 8:
                break
    return {"linked": mine, "likely": likely}


def _has_sealed(svc):
    try:
        svc.vault.conn.execute("SELECT 1 FROM sealed_products LIMIT 1")
        return True
    except Exception:  # noqa: BLE001
        return False
