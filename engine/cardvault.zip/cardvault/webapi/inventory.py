"""'Everything I own': one flat list of the cards and sealed products held in the portfolios being looked at (or in all of them), instead of set by set."""
from .cards import img
from .portfolios import MAIN, main_name
from .registry import ApiError, api


@api("inventory.list", quiet=True)
def inventory_list(svc, kind="all", q="", sort="value", group="none", limit=200, offset=0):
    from .. import sealedprice
    v = svc.vault
    names = {"": main_name(svc)}
    names.update({p["uuid"]: p["name"] for p in v.portfolios()})
    scope = list(v.scope or [])
    words = [w for w in (q or "").lower().split() if w]
    rows = []
    if kind in ("all", "cards"):
        for r in v.conn.execute(
                "SELECT l.id AS lotid, l.uuid AS lot, l.card_id, l.variant, l.condition, l.graded, l.grade_company, l.grade, l.qty, l.purchase_price AS paid, l.location, l.added, COALESCE(l.portfolio,'') AS pf, "
                "c.name, c.local_id, c.rarity, c.price_usd AS usd, c.set_id, s.name AS set_name, s.release_date FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0", (v.user_id, v.game)):
            cond = (f"{r['grade_company'] or ''} {r['grade'] or ''}".strip() or "Graded") if r["graded"] else v.COND_ABBR.get(r["condition"] or "", r["condition"] or "")
            rows.append({"type": "card", "id": r["card_id"], "lot": r["lot"], "name": r["name"], "sub": " · ".join(x for x in (r["set_name"] or "", f"#{r['local_id']}", r["variant"] or "", r["rarity"] or "", cond) if x),
                         "qty": r["qty"], "price": r["usd"], "value": round((r["usd"] or 0) * r["qty"], 2), "paid": r["paid"], "pf": r["pf"], "portfolio": names.get(r["pf"], "Other"),
                         "set": r["set_name"] or "", "setDate": r["release_date"] or "", "added": r["added"] or "", "location": r["location"] or "", "img": img(r["card_id"], r["set_id"] or "")})
    if kind in ("all", "sealed"):
        for r in v.conn.execute("SELECT uuid, name, qty, paid, purchased, COALESCE(portfolio,'') AS pf, notes FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)):
            if scope and r["pf"] not in scope:
                continue
            p = sealedprice.price_for(v, r["name"])
            rows.append({"type": "sealed", "id": r["uuid"], "lot": r["uuid"], "name": r["name"], "sub": "Sealed product" + (f" · bought {r['purchased']}" if r["purchased"] else ""), "qty": r["qty"], "price": p["price"] if p else None,
                         "value": round(((p or {}).get("price") or 0) * r["qty"], 2), "paid": r["paid"], "pf": r["pf"], "portfolio": names.get(r["pf"], "Other"), "set": "Sealed products", "setDate": "",
                         "added": r["purchased"] or "", "location": "", "img": sealedprice.image_for(v, r["name"])})
    if words:
        rows = [r for r in rows if all(w in f"{r['name']} {r['sub']} {r['portfolio']} {r['location']}".lower() for w in words)]
    key = {"value": lambda r: -r["value"], "valueAsc": lambda r: r["value"], "name": lambda r: r["name"].lower(), "newest": lambda r: r["added"] or "", "oldest": lambda r: r["added"] or "9999",
           "set": lambda r: (r["setDate"] or "", r["set"]), "qty": lambda r: -r["qty"]}.get(sort, lambda r: -r["value"])
    rows.sort(key=key, reverse=(sort in ("newest",)))
    if group == "portfolio":
        rows.sort(key=lambda r: r["portfolio"].lower())
    elif group == "set":
        rows.sort(key=lambda r: (r["set"].lower()))
    total_copies = sum(r["qty"] for r in rows)
    out = {"rows": rows[int(offset):int(offset) + int(limit)], "total": len(rows), "copies": total_copies, "value": round(sum(r["value"] for r in rows), 2),
           "cards": sum(r["qty"] for r in rows if r["type"] == "card"), "sealed": sum(r["qty"] for r in rows if r["type"] == "sealed")}
    return out


@api("inventory.move", mutates=True)
def inventory_move(svc, items, portfolio):
    """Move cards (their stacks) and sealed products to another portfolio.  items = [{type: 'card'|'sealed', lot: <uuid>}]."""
    from ..db import now_iso
    v = svc.vault
    pid = "" if portfolio in ("main", MAIN, "", None) else portfolio
    if pid and not any(p["uuid"] == pid for p in v.portfolios()):
        raise ApiError("That portfolio doesn't exist.")
    cards = [x["lot"] for x in items if x.get("type") == "card" and x.get("lot")]
    seal = [x["lot"] for x in items if x.get("type") == "sealed" and x.get("lot")]
    if cards:
        v.check_accepts(pid, "cards")
    if seal:
        v.check_accepts(pid, "sealed")
    ts, n = now_iso(), 0
    with v.action(f"Moved {len(cards) + len(seal)} item(s) to {main_name(svc) if not pid else next(p['name'] for p in v.portfolios() if p['uuid'] == pid)}"):
        for u in cards:
            n += v.conn.execute("UPDATE u.lots SET portfolio=?, placed=1, updated_at=? WHERE uuid=? AND user_id=? AND deleted=0", (pid, ts, u, v.user_id)).rowcount
        for u in seal:
            n += v.conn.execute("UPDATE u.sealed SET portfolio=?, updated_at=? WHERE uuid=? AND user_id=? AND deleted=0", (pid, ts, u, v.user_id)).rowcount
        v.commit()
    svc.reload_state()
    return {"moved": n}
