"""'Everything I own': one flat list of the cards and sealed products held in the portfolios being looked at (or in all of them), instead of set by set."""
from .cards import img
from .portfolios import MAIN, main_name
from .registry import ApiError, api


@api("inventory.list", quiet=True)
def inventory_list(svc, kind="all", q="", sort="value", group="none", limit=200, offset=0, price_min=None, price_max=None, graded="", rarity="", set_text="", pf_text="", min_qty=None, result="", condition="", place="", variant=""):
    from .. import sealedprice
    v = svc.vault
    names = {"": main_name(svc)}
    names.update({p["uuid"]: p["name"] for p in v.portfolios()})
    scope = list(v.scope or [])
    words = [w for w in (q or "").lower().split() if w]
    rows = []
    if kind in ("all", "cards"):
        for r in v.conn.execute(
                "SELECT l.id AS lotid, l.uuid AS lot, l.card_id, l.variant, l.condition, l.graded, l.grade_company, l.grade, l.qty, l.purchase_price AS paid, l.location, l.added, COALESCE(l.portfolio,'') AS pf, "
                "c.name, c.local_id, c.rarity, c.price_usd AS usd, c.set_id, s.name AS set_name, s.release_date FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0", (v.user_id, v.game)):
            cond = (f"{r['grade_company'] or ''} {r['grade'] or ''}".strip() or "Graded") if r["graded"] else v.COND_ABBR.get(r["condition"] or "", r["condition"] or "")
            rows.append({"type": "card", "id": r["card_id"], "lot": r["lot"], "name": r["name"], "sub": " · ".join(x for x in (r["set_name"] or "", f"#{r['local_id']}", r["variant"] or "", r["rarity"] or "", cond) if x),
                         "qty": r["qty"], "price": r["usd"], "value": round((r["usd"] or 0) * r["qty"], 2), "paid": r["paid"], "pf": r["pf"], "portfolio": names.get(r["pf"], "Other"),
                         "set": r["set_name"] or "", "setDate": r["release_date"] or "", "added": r["added"] or "", "location": r["location"] or "", "img": img(r["card_id"], r["set_id"] or ""),
                         "rarity": r["rarity"] or "", "isGraded": bool(r["graded"]), "cond": r["condition"] or "", "variantName": r["variant"] or ""})
    if kind in ("all", "sealed"):
        for r in v.conn.execute("SELECT uuid, name, qty, paid, purchased, COALESCE(portfolio,'') AS pf, notes FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)):
            if scope and r["pf"] not in scope:
                continue
            p = sealedprice.price_for(v, r["name"])
            rows.append({"type": "sealed", "id": r["uuid"], "lot": r["uuid"], "name": r["name"], "sub": "Sealed product" + (f" · bought {r['purchased']}" if r["purchased"] else ""), "qty": r["qty"], "price": p["price"] if p else None,
                         "value": round(((p or {}).get("price") or 0) * r["qty"], 2), "paid": r["paid"], "pf": r["pf"], "portfolio": names.get(r["pf"], "Other"), "set": "Sealed products", "setDate": "",
                         "added": r["purchased"] or "", "location": "", "img": sealedprice.image_for(v, r["name"]), "rarity": "", "isGraded": False})
    for r in rows:                                                              # what each stack has made against what was paid (when a price paid is known)
        r["gain"] = round(r["value"] - r["paid"] * r["qty"], 2) if (r["paid"] is not None and r["price"] is not None) else None
    if condition:
        rows = [r for r in rows if r["type"] == "card" and (r.get("cond") or "") == condition and not r.get("isGraded")]
    if place:
        rows = [r for r in rows if place.lower() in (r.get("location") or "").lower()]
    if variant:
        rows = [r for r in rows if variant.lower() in (r.get("variantName") or "").lower()]
    pmin = None if price_min in (None, "") else float(price_min)
    pmax = None if price_max in (None, "") else float(price_max)
    if pmin is not None:
        rows = [r for r in rows if r["price"] is not None and r["price"] >= pmin]
    if pmax is not None:
        rows = [r for r in rows if r["price"] is not None and r["price"] <= pmax]
    if graded == "yes":
        rows = [r for r in rows if r["isGraded"]]
    elif graded == "no":
        rows = [r for r in rows if r["type"] == "sealed" or not r["isGraded"]]
    if rarity:
        rows = [r for r in rows if rarity.lower() in r["rarity"].lower()]
    if set_text:
        rows = [r for r in rows if all(w in r["set"].lower() for w in set_text.lower().split())]
    if pf_text:
        rows = [r for r in rows if all(w in r["portfolio"].lower() for w in pf_text.lower().split())]
    if min_qty not in (None, ""):
        rows = [r for r in rows if r["qty"] >= int(min_qty)]
    if result == "gain":
        rows = [r for r in rows if r["gain"] is not None and r["gain"] > 0]
    elif result == "loss":
        rows = [r for r in rows if r["gain"] is not None and r["gain"] < 0]
    elif result == "nopaid":
        rows = [r for r in rows if r["paid"] is None]
    if words:
        rows = [r for r in rows if all(w in f"{r['name']} {r['sub']} {r['portfolio']} {r['location']}".lower() for w in words)]
    key = {"value": lambda r: -r["value"], "valueAsc": lambda r: r["value"], "name": lambda r: r["name"].lower(), "newest": lambda r: r["added"] or "", "oldest": lambda r: r["added"] or "9999",
           "set": lambda r: (r["setDate"] or "", r["set"]), "qty": lambda r: -r["qty"],
           "namez": lambda r: tuple(-ord(c) for c in r["name"].lower()[:24]), "qtyasc": lambda r: r["qty"], "price": lambda r: -(r["price"] or 0), "priceasc": lambda r: (r["price"] is None, r["price"] or 0),
           "paid": lambda r: -((r["paid"] or 0) * r["qty"]), "gain": lambda r: -(r["gain"] if r["gain"] is not None else -1e12), "loss": lambda r: (r["gain"] is None, r["gain"] or 0),
           "rarity": lambda r: (not r["rarity"], r["rarity"].lower(), r["name"].lower()), "portfolio": lambda r: (r["portfolio"].lower(), r["name"].lower()),
           "setname": lambda r: (r["set"].lower(), r["name"].lower())}.get(sort, lambda r: -r["value"])
    rows.sort(key=key, reverse=(sort in ("newest",)))
    if group == "portfolio":
        rows.sort(key=lambda r: r["portfolio"].lower())
    elif group == "set":
        rows.sort(key=lambda r: (r["set"].lower()))
    total_copies = sum(r["qty"] for r in rows)
    out = {"rows": rows[int(offset):int(offset) + int(limit)], "total": len(rows), "copies": total_copies, "value": round(sum(r["value"] for r in rows), 2),
           "cards": sum(r["qty"] for r in rows if r["type"] == "card"), "sealed": sum(r["qty"] for r in rows if r["type"] == "sealed")}
    return out


@api("inventory.adjust", mutates=True)
def inventory_adjust(svc, type, lot, delta):
    """The + / - on a tile in Portfolios: one more or one fewer copy of THIS stack (a card in this portfolio / condition, or a sealed row).  At 0 the stack is removed (undo brings it back)."""
    from .cards import with_undo
    from .extras import sealed_adjust
    v = svc.vault
    delta = max(-9999, min(9999, int(delta)))                                  # +1 / -1 from the buttons, or the difference when a quantity is typed in
    if delta == 0:
        return {"qty": None}
    if type == "sealed":
        return sealed_adjust(svc, delta, id=lot)
    r = v.conn.execute("SELECT id, card_id FROM u.lots WHERE uuid=? AND user_id=? AND deleted=0", (lot, v.user_id)).fetchone()
    if not r:
        raise ApiError("That copy isn't in your collection any more.")
    name = (v.card_light(r["card_id"]) or {}).get("name", r["card_id"])

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {name}"):
            v.change_lot_qty(r["id"], delta)
    return with_undo(svc, run)


@api("inventory.move", mutates=True)
def inventory_move(svc, items, portfolio):
    """Move cards (their stacks) and sealed products to another portfolio.  items = [{type: 'card'|'sealed', lot: <uuid>}]."""
    from ..db import now_iso
    v = svc.vault
    pid = "" if portfolio in ("main", MAIN, "", None) else portfolio
    if pid and not any(p["uuid"] == pid for p in v.portfolios()):
        raise ApiError("That portfolio doesn't exist.")
    cards = [x["lot"] for x in items if x.get("type") == "card" and x.get("lot")]
    seal = [x["lot"] for x in items if x.get("type") == "sealed" and x.get("lot")]
    if cards:
        v.check_accepts(pid, "cards")
    if seal:
        v.check_accepts(pid, "sealed")
    ts, n = now_iso(), 0
    with v.action(f"Moved {len(cards) + len(seal)} item(s) to {main_name(svc) if not pid else next(p['name'] for p in v.portfolios() if p['uuid'] == pid)}"):
        for u in cards:
            n += v.conn.execute("UPDATE u.lots SET portfolio=?, placed=1, updated_at=? WHERE uuid=? AND user_id=? AND deleted=0", (pid, ts, u, v.user_id)).rowcount

        def move_sealed():                                  # (kept undoable: the rows' earlier portfolio is remembered)
            nonlocal n
            for u in seal:
                n += v.conn.execute("UPDATE u.sealed SET portfolio=?, updated_at=? WHERE uuid=? AND user_id=? AND deleted=0", (pid, ts, u, v.user_id)).rowcount
        if seal:
            v.sealed_action("", move_sealed)
        v.commit()
    svc.reload_state()
    return {"moved": n}


@api("inventory.bulkEdit", mutates=True)
def inventory_bulk_edit(svc, items, paid=None, purchased=None, source=None):
    """Set the price paid (each), the date bought and/or where it was bought for many picked items at once (cards and sealed).  A field left out (None) is not touched;
    an empty paid ('') clears the price.  One Undo puts every item back."""
    from ..db import now_iso
    from .cards import with_undo
    v = svc.vault
    if paid is None and purchased is None and source is None:
        raise ApiError("Choose what to change first.")
    price = None if paid in (None, "") else round(float(paid), 4)
    cards = [x["lot"] for x in items if x.get("type") == "card" and x.get("lot")]
    seal = [x["lot"] for x in items if x.get("type") == "sealed" and x.get("lot")]

    def run():
        n = 0
        with v.action(f"Changed details of {len(cards) + len(seal)} item(s)"):
            for u in cards:
                r = v.conn.execute("SELECT id FROM u.lots WHERE uuid=? AND user_id=? AND deleted=0", (u, v.user_id)).fetchone()
                if not r:
                    continue
                f = {}
                if paid is not None:
                    f["purchase_price"] = price
                if purchased is not None:
                    f["purchased"] = purchased
                if source is not None:
                    f["source"] = source
                v.update_lot(r["id"], **f)
                n += 1

            def sealed():
                nonlocal n
                for u in seal:
                    sets, args = [], []
                    if paid is not None:
                        sets.append("paid=?"); args.append(price)
                    if purchased is not None:
                        sets.append("purchased=?"); args.append(purchased)
                    if source is not None:
                        sets.append("source=?"); args.append(source)
                    n += v.conn.execute(f"UPDATE u.sealed SET {', '.join(sets)}, updated_at=? WHERE uuid=? AND user_id=? AND deleted=0", (*args, now_iso(), u, v.user_id)).rowcount
                v.commit()
            if seal:
                v.sealed_action("", sealed)
        return {"changed": n}
    return with_undo(svc, run)
