"""Portfolio analytics: what one portfolio, a category of portfolios, or any hand-picked mix of them is worth - cards, sealed products and linked checklists."""
import contextlib
import statistics

from .. import sealedclass, tools
from ..db import now_iso
from .cards import img
from .listanalytics import progress_of, slot_rows, summarise, combined_rows
from .portfolios import MAIN, _db_id, _state, with_descendants
from .registry import api
from .setanalytics import BUCKETS
from .sealedcat import price_for


@contextlib.contextmanager
def _viewing(v, ids):
    """Look at exactly these portfolios (db ids; empty = all) for a moment, then put the person's own view back."""
    before, target = list(v.scope or []), v.target_pf
    v.set_scope(ids)
    try:
        yield
    finally:
        v.set_scope(before)
        v.target_pf = target


def _list_ids(rows, selected):
    ids, every = [], False
    for r in rows:
        if r["id"] in selected:
            every = every or r["allLists"]
            ids.extend(r["lists"])
    return ids, every


@api("portfolio.analytics")
def pf_analytics(svc, ids=None, children=True, range="all"):
    """ids = portfolios (api ids, 'main' = Main); none = everything.  children = a category counts everything inside it."""
    v = svc.vault
    st = _state(svc)
    rows = {r["id"]: r for r in st["portfolios"]}
    chosen = [i for i in (ids or []) if i in rows] or list(rows)
    selected = with_descendants(svc, chosen) if children else chosen
    selected = [i for i in dict.fromkeys(selected) if i in rows]
    db_ids = [_db_id(i) for i in selected]
    everything = len(selected) == len(rows)
    marks = ",".join("?" * len(db_ids))
    lots = v.conn.execute(
        f"SELECT l.card_id, l.qty, l.purchase_price, COALESCE(l.portfolio,'') AS pf, c.name, c.local_id, c.rarity, c.price_usd, c.price_kind, c.tcg_id, c.set_id, s.name AS set_name, s.serie "
        f"FROM u.lots l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 AND COALESCE(l.portfolio,'') IN ({marks})",
        [v.user_id, v.game, *db_ids]).fetchall()
    sealed = v.conn.execute(f"SELECT name, qty, paid, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(portfolio,'') IN ({marks})",
                            [v.user_id, v.game, *db_ids]).fetchall()

    value = lambda l: l["qty"] * (l["price_usd"] or 0)
    cards_value = sum(value(l) for l in lots)
    cards_spent = sum(l["qty"] * l["purchase_price"] for l in lots if l["purchase_price"] is not None)
    copies = sum(l["qty"] for l in lots)

    kinds, sealed_value, sealed_spent, sealed_qty, unpriced = {}, 0.0, 0.0, 0, 0
    for s in sealed:
        pr = price_for(v, s["name"])
        val = (pr["price"] if pr else None)
        k = sealedclass.kind_of(s["name"], v.game)
        g = kinds.setdefault(k, {"kind": k, "qty": 0, "value": 0.0, "paid": 0.0})
        g["qty"] += s["qty"] or 0
        g["value"] += (val or 0) * (s["qty"] or 0)
        g["paid"] += (s["paid"] or 0) * (s["qty"] or 0)
        sealed_value += (val or 0) * (s["qty"] or 0)
        sealed_spent += (s["paid"] or 0) * (s["qty"] or 0)
        sealed_qty += s["qty"] or 0
        unpriced += 1 if val is None else 0

    def group(key):
        out = {}
        for l in lots:
            name = (l[key] or "Unlabelled") if key != "serie" else (l[key] or "Other")
            g = out.setdefault(name, {"label": name, "n": 0, "value": 0.0})
            g["n"] += l["qty"]
            g["value"] += value(l)
        return [{**g, "value": round(g["value"], 2)} for g in sorted(out.values(), key=lambda g: -g["value"])]

    by_card = {}
    for l in lots:
        r = by_card.setdefault(l["card_id"], {"id": l["card_id"], "name": l["name"], "number": l["local_id"], "set": l["set_name"] or "", "rarity": l["rarity"] or "", "price": l["price_usd"],
                                              "priceKind": l["price_kind"] or "", "qty": 0, "img": img(l["card_id"], l["set_id"]), "tcg": l["tcg_id"] or ""})
        r["qty"] += l["qty"]
    top = sorted((r for r in by_card.values() if r["price"] is not None), key=lambda r: -r["price"] * r["qty"])[:12]
    prices = [l["price_usd"] for l in lots if l["price_usd"] is not None]

    per = []
    for i in selected:
        r = rows[i]
        own_sealed = sum(((price_for(v, s["name"]) or {}).get("price") or 0) * (s["qty"] or 0) for s in sealed if _db_id(i) == s["pf"])
        per.append({"id": i, "name": r["name"], "color": r["color"], "depth": r["depth"], "parent": r["parent"], "copies": r["copies"], "cardValue": round(r["value"], 2), "sealedValue": round(own_sealed, 2),
                    "value": round(r["value"] + own_sealed, 2), "spent": round(r["spent"], 2)})

    # checklists tied to these portfolios (counted against the whole collection, not just what is in the portfolio)
    list_ids, every = _list_ids(st["portfolios"], selected)
    all_lists = [c["id"] for c in v.checklists()]
    if every:
        list_ids = all_lists
    list_ids = [i for i in dict.fromkeys(list_ids) if i in all_lists]
    lists, combined = [], None
    if list_ids:
        with _viewing(v, []):
            svc.reload_state()
            for i in list_ids:
                cl, p = progress_of(svc, i)
                sl = slot_rows(svc, p)
                s = summarise(svc, sl)
                lists.append({"id": i, "name": cl["name"], "owned": s["owned"], "total": s["cards"], "pct": s["pct"], "totalValue": s["totalValue"], "ownedValue": s["ownedValue"], "missingValue": s["missingValue"]})
            combined = summarise(svc, combined_rows(svc, list_ids), "pflists:" + ",".join(sorted(str(i) for i in list_ids))[:150])
        svc.reload_state()

    hist = {"points": [], "realFrom": None, "firstBuy": None}
    with _viewing(v, [] if everything else db_ids):
        hist = tools.portfolio_series(v, range)
    svc.reload_state()
    total, spent = cards_value + sealed_value, cards_spent + sealed_spent
    name = rows[selected[0]]["name"] if len(chosen) == 1 else ("Everything" if everything else f"{len(chosen)} portfolios together")
    return {"name": name, "ids": selected, "chosen": chosen, "everything": everything, "copies": copies, "unique": len(by_card), "sealedQty": sealed_qty,
            "cardValue": round(cards_value, 2), "sealedValue": round(sealed_value, 2), "value": round(total, 2), "spent": round(spent, 2),
            "gain": round(total - spent, 2) if spent else None, "gainPct": round((total / spent - 1) * 100, 1) if spent else None, "unpricedSealed": unpriced,
            "avg": round(sum(prices) / len(prices), 2) if prices else None, "median": round(statistics.median(prices), 2) if prices else None,
            "rarities": group("rarity")[:14], "sets": group("set_name")[:14], "eras": group("serie")[:14], "top": [{k: r[k] for k in ("id", "name", "number", "set", "rarity", "price", "priceKind", "qty", "img", "tcg")} for r in top],
            "buckets": [{"label": lab, "n": sum(1 for p in prices if lo <= p < hi)} for lab, lo, hi in BUCKETS],
            "sealed": [{**k, "value": round(k["value"], 2), "paid": round(k["paid"], 2)} for k in sorted(kinds.values(), key=lambda k: -k["value"])],
            "parts": per, "lists": lists, "listsTotal": combined, "history": hist["points"], "realFrom": hist["realFrom"]}


@api("portfolio.splitSealed", mutates=True)
def split_sealed(svc, id=MAIN):
    """Sort this portfolio's sealed products into sub-portfolios by product type (Booster box, Tin, Sleeved booster...).  Nothing is deleted; products only move."""
    from .portfolios import _meta_from, meta_of
    v = svc.vault
    here = _db_id(id)
    items = v.conn.execute("SELECT uuid, name FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(portfolio,'')=?", (v.user_id, v.game, here)).fetchall()
    if not items:
        return {"moved": 0, "made": []}
    existing = {p["name"].lower(): p["uuid"] for p in v.portfolios() if meta_of(p).get("parent") == id}
    made, moved = [], 0
    for it in items:
        k = sealedclass.kind_of(it["name"], v.game)
        pid = existing.get(k.lower())
        if not pid:
            pid = v.create_portfolio(k, "", {"parent": id})
            existing[k.lower()] = pid
            made.append(k)
        v.conn.execute("UPDATE u.sealed SET portfolio=?, updated_at=? WHERE uuid=?", (pid, now_iso(), it["uuid"]))
        moved += 1
    v._commit()
    return {"moved": moved, "made": made}


@api("sealed.move", mutates=True)
def sealed_move(svc, ids, portfolio=MAIN):
    v = svc.vault
    for i in ids:
        v.conn.execute("UPDATE u.sealed SET portfolio=?, updated_at=? WHERE uuid=? AND user_id=?", (_db_id(portfolio), now_iso(), i, v.user_id))
    v._commit()
    return {"moved": len(ids)}
