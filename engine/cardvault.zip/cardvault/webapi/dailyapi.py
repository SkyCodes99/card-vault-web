"""The once-a-day price update (see cardvault/dailyprices.py): when to look, what to apply."""
import time

from .. import dailyprices
from ..db import game_dir
from . import gamesapi, trendapi  # noqa: F401
from .registry import api


def _installed(svc):
    from .. import games
    return [g.id for g in games.GAMES if g.available and gamesapi.has_catalog(svc, g.id)]


def check(svc, force=False):
    """Look for the day's prices.  Sets svc._daily_next (a time.time() value) to when to look again: 5 minutes if the new day isn't published yet, else tomorrow 20:03 UTC."""
    now = time.time()
    if svc.session is None or svc.vault is None:
        svc._daily_next = now + 30
        return {"applied": 0}
    exp = dailyprices.expected_day()
    games_here = _installed(svc)
    gd = lambda g: game_dir(svc.cfg["data_dir"], g)
    pending = [g for g in games_here if dailyprices.local_built(gd(g)) < exp]
    applied = 0
    m = None
    if pending:
        from .. import carddata
        base, m = carddata.first_manifest(svc, "prices", dailyprices.manifest)
        for g in pending:
            e = (m or {}).get("games", {}).get(g) or {}
            day = e.get("built") or (m or {}).get("built") or ""
            if m and day > dailyprices.local_built(gd(g)):
                try:
                    applied += dailyprices.fetch_and_apply(gd(g), base, g)
                except Exception:  # noqa: BLE001 - try again at the next look
                    continue
        pending = [g for g in games_here if dailyprices.local_built(gd(g)) < exp and (m is None or g in (m.get("games") or {}))]          # a game the website does not publish prices for yet is not waited for
    stale = [g for g in games_here if dailyprices.subtypes_built(gd(g)) < dailyprices.local_built(gd(g)) or not dailyprices.subtypes_built(gd(g))]          # printing prices not stored yet (first run after an update, or the file was late)
    if stale and not applied and getattr(svc, "_sub_try", 0) < time.time():
        from .. import carddata
        base, m = carddata.first_manifest(svc, "prices", dailyprices.manifest)
        got = 0
        for g in stale:
            if m and g in (m.get("games") or {}) and (m["games"][g].get("subtypes") or 0):
                try:
                    got += 1 if dailyprices.fetch_subtypes(gd(g), base, g) else 0
                except Exception:  # noqa: BLE001
                    continue
        svc._sub_try = time.time() + (6 * 3600 if not got else 0)             # nothing there yet: ask again in a few hours, not every minute
        applied += got
    if applied:
        def record(s):
            s.vault.invalidate_index()
            s.vault.record_price_history()
            s.vault.take_snapshot()
            s.reload_state()
            s.bump("changed")
        record(svc)                                       # check() runs on the service thread already
    svc._daily_next = time.time() + (dailyprices.retry_delay() if pending else dailyprices.next_daily_run() + 5)
    svc._daily_state = {"expected": exp, "waiting": pending, "applied": applied}
    return {"applied": applied, "waiting": pending}


@api("prices.daily", quiet=True)
def status(svc):
    st = getattr(svc, "_daily_state", None) or {}
    v = svc.vault
    return {"expected": st.get("expected", dailyprices.expected_day()), "waiting": st.get("waiting", []), "updated": (v.meta("prices_updated") if v else "") or "",
            "nextCheckInSeconds": max(0, int(getattr(svc, "_daily_next", 0) - time.time()))}


@api("prices.checkNow")
def check_now(svc):
    """The 'check now' button: look right away (it does not change the once-a-day schedule: if the day is there, it is applied and checking stops)."""
    return check(svc, True)


# ------------------------------------------------------------------------------------------------ card lists: what you have, what is published, update now
@api("catalogs.status")
def catalogs_status(svc):
    """For every game on this device: when its card list was built, when the website's newest was built, and when its prices are from."""
    from .. import catalogdb, games
    from .. import carddata
    _b, m = carddata.first_manifest(svc, "catalog", catalogdb.manifest)
    m = m or {}
    out = []
    for g in games.GAMES:
        if not g.available or not gamesapi.has_catalog(svc, g.id):
            continue
        gdir = game_dir(svc.cfg["data_dir"], g.id)
        mine = catalogdb.local_built(gdir) or ""
        theirs = ((m.get("games") or {}).get(g.id) or {}).get("built", "")
        out.append({"id": g.id, "name": g.name, "built": mine, "published": theirs, "upToDate": bool(theirs) and mine >= theirs if theirs else None,
                    "pricesFrom": dailyprices.local_built(gdir) or ""})
    probe = ""
    if not m:
        try:                                                    # say exactly what the first address answered, so a problem can be seen instead of guessed
            import requests
            b0 = carddata.bases(svc, "catalog")[0]
            r = requests.get(b0 + "/manifest.json", timeout=15)
            probe = f"{b0}: HTTP {r.status_code}, {len(r.content)} bytes, {r.headers.get('content-type', '?')}"
        except Exception as e:  # noqa: BLE001
            probe = f"{type(e).__name__}: {str(e)[:160]}"
    return {"games": out, "reachable": bool(m), "busy": bool(svc.jobs.running("games")), "errors": list(carddata.last_errors), "probe": probe}


@api("catalogs.updateNow")
def catalogs_update_now(svc):
    """Fetch every newer card list now (the game you are looking at first), then today's prices."""
    j = gamesapi.refresh_catalogs(svc)
    svc._more_catalogs = True                               # the next games follow one after another
    svc._daily_next = 0                                     # and the price check runs at the next tick
    return {"job": j}
