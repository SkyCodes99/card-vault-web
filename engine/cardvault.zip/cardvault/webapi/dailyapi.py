"""The DAILY CHECK: once a day the app looks for today's prices (see cardvault/dailyprices.py: when to look, what to apply) and, with them, for NEW ITEMS - newer card lists with new cards,
sets, sealed products and toys (see gamesapi.refresh_catalogs).  Both are shown together in Settings -> Daily check."""
import time

from .. import dailyprices
from ..db import game_dir
from ..runtime import INLINE
from . import gamesapi, trendapi  # noqa: F401
from .registry import api


def _installed(svc):
    """The games on this device, the one you are looking at first."""
    from .. import games
    here = [g.id for g in games.GAMES if g.available and gamesapi.has_catalog(svc, g.id)]
    return sorted(here, key=lambda g: g != (svc.vault.game if svc.vault is not None else ""))


def _one_at_a_time(svc, delay=8):
    """The browser's engine has no threads: applying a day's prices to every game in one go would freeze the app for as long as all of them take together.  There, one game is done per look and the next
    follows a moment later (the screens get the engine back in between)."""
    svc._daily_next = time.time() + delay


def check(svc, force=False):
    """Look for the day's prices.  Sets svc._daily_next (a time.time() value) to when to look again: 5 minutes if the new day isn't published yet, else tomorrow 20:03 UTC."""
    return dailyprices.run(check_steps(svc, force))


def check_steps(svc, force=False):
    """check(), one short step at a time: a generator that yields between steps and returns check()'s answer.  The browser's engine has no threads, and the day's prices for a big game (Magic:
    115,000 prices + every printing's price) took 8 seconds in one go - every click waited for it.  There the scheduler does one step per quiet moment (see Scheduler.steps)."""
    now = time.time()
    if svc.session is None or svc.vault is None:
        svc._daily_next = now + 30
        return {"applied": 0}
    game_at_start = svc.vault.game
    exp = dailyprices.expected_day()
    games_here = _installed(svc)
    gd = lambda g: game_dir(svc.cfg["data_dir"], g)
    pending = [g for g in games_here if dailyprices.local_built(gd(g)) < exp]
    applied, more, touched = 0, False, set()
    m = None
    svc._daily_error = ""
    if pending:
        from .. import carddata
        base, m = carddata.first_manifest(svc, "prices", dailyprices.manifest)
        if m is None:
            svc._daily_error = "The price list on the website couldn't be reached" + ((": " + carddata.last_errors[0]) if carddata.last_errors else "") + "."
        svc._daily_latest = (m or {}).get("built") or getattr(svc, "_daily_latest", "")
        for g in pending:
            e = (m or {}).get("games", {}).get(g) or {}
            day = e.get("built") or (m or {}).get("built") or ""
            if m and day > dailyprices.local_built(gd(g)):
                try:
                    yield
                    applied += yield from dailyprices.fetch_and_apply_steps(gd(g), base, g)
                except Exception as ex:  # noqa: BLE001 - try again at the next look
                    svc._daily_error = f"Getting today's prices failed: {str(ex)[:160]}"
                    continue
                touched.add(g)
                if INLINE:
                    break                                         # (one game this time - see _one_at_a_time)
        pending = [g for g in games_here if dailyprices.local_built(gd(g)) < exp and (m is None or g in (m.get("games") or {}))]          # a game the website does not publish prices for yet is not waited for
        more = INLINE and applied and any(((m or {}).get("games", {}).get(g) or {}).get("built", "") > dailyprices.local_built(gd(g)) for g in pending)          # published, and still to be applied here
    stale = [g for g in games_here if dailyprices.subtypes_built(gd(g)) < dailyprices.local_built(gd(g)) or not dailyprices.subtypes_built(gd(g))]          # printing prices not stored yet (first run after an update, or the file was late)
    if stale and not applied and getattr(svc, "_sub_try", 0) < time.time():
        from .. import carddata
        base, m = carddata.first_manifest(svc, "prices", dailyprices.manifest)
        got = 0
        for g in stale:
            if m and g in (m.get("games") or {}) and (m["games"][g].get("subtypes") or 0):
                try:
                    yield
                    got += 1 if (yield from dailyprices.fetch_subtypes_steps(gd(g), base, g)) else 0
                except Exception:  # noqa: BLE001
                    continue
                touched.add(g)
                if INLINE and got:
                    break                                         # (one game this time)
        svc._sub_try = time.time() + (6 * 3600 if not got else 0)             # nothing there yet: ask again in a few hours, not every minute
        applied += got
        more = INLINE and bool(got) and len(stale) > 1
    same = lambda: svc.vault is not None and svc.vault.game == game_at_start          # (between steps you may have switched games or signed out)
    if applied and game_at_start in touched and same():          # (prices of a game you are not looking at change nothing on screen: its card index and your value history stay as they are)
        svc.vault.invalidate_index()
        for step in (lambda v: v.record_price_history(), lambda v: v.take_snapshot()):          # (the card index is worked out again a few short steps at a time - see scheduler.warm)
            yield
            if same():
                step(svc.vault)
        yield
        if same():
            svc.reload_state()
            svc.bump("changed")
    svc._daily_next = time.time() + (dailyprices.retry_delay() if pending else dailyprices.next_daily_run() + 5)
    if not pending and getattr(svc, "_items_day", "") != exp:      # the day's prices are in: now the other half of the daily check - look for new items (newer card lists), once a day
        svc._items_day = exp
        svc._more_catalogs = True
    if more:
        _one_at_a_time(svc)
    svc._daily_state = {"expected": exp, "waiting": pending, "applied": applied, "checked": time.time()}
    return {"applied": applied, "waiting": pending, "error": getattr(svc, "_daily_error", "")}


@api("prices.daily", quiet=True)
def status(svc):
    st = getattr(svc, "_daily_state", None) or {}
    v = svc.vault
    gd = game_dir(svc.cfg["data_dir"], v.game) if v else ""
    return {"expected": st.get("expected", dailyprices.expected_day()), "waiting": st.get("waiting", []), "updated": ((dailyprices.local_built(gd) if gd else "") or (v.meta("prices_updated") if v else "")) or "",
            "checked": bool(st.get("checked")), "error": getattr(svc, "_daily_error", ""), "latest": getattr(svc, "_daily_latest", ""),
            "nextCheckInSeconds": max(0, int(getattr(svc, "_daily_next", 0) - time.time()))}


def check_soon(svc):
    """The browser's 'look now': the step-by-step check starts at the next tick (clicks are answered in between its steps) -> what is known so far, with working=True."""
    svc._daily_next, svc._daily_hurry = 0, True
    st = getattr(svc, "_daily_state", None) or {}
    return {"applied": 0, "waiting": st.get("waiting", []), "error": "", "working": True}


@api("prices.checkNow")
def check_now(svc):
    """Look for today's prices right away (it does not change the once-a-day schedule: if the day is there, it is applied and checking stops)."""
    return check_soon(svc) if INLINE else check(svc, True)


@api("daily.checkNow")
def daily_check_now(svc):
    """The 'Check now' button of the daily check: today's prices AND new items (newer card lists, fetched in the background).
    -> {prices: what prices.checkNow says, job: the card-list job or None, items: 'fetching' (a card list is being fetched) | 'waiting' (another update has the list open: it follows in a moment) | 'none'}"""
    prices = check_now(svc)
    job = None
    if svc.jobs.running("games"):
        items = "fetching"
    else:
        job = gamesapi.refresh_catalogs(svc)
        svc._more_catalogs = True                          # the next games follow one after another
        items = "fetching" if job else ("waiting" if gamesapi.list_in_use(svc) else "none")
    svc._items_day = dailyprices.expected_day()
    return {"prices": prices, "job": job, "items": items}


# ------------------------------------------------------------------------------------------------ card lists: what you have, what is published, update now
@api("catalogs.status")
def catalogs_status(svc):
    """For every game on this device: when its card list was built, when the website's newest was built, and when its prices are from."""
    from .. import catalogdb, games
    from .. import carddata
    _b, m = carddata.first_manifest(svc, "catalog", catalogdb.manifest)
    m = m or {}
    out = []
    for g in games.GAMES:
        if not g.available or not gamesapi.has_catalog(svc, g.id):
            continue
        gdir = game_dir(svc.cfg["data_dir"], g.id)
        mine = catalogdb.local_built(gdir) or ""
        theirs = ((m.get("games") or {}).get(g.id) or {}).get("built", "")
        out.append({"id": g.id, "name": g.name, "built": mine, "published": theirs, "upToDate": bool(theirs) and mine >= theirs if theirs else None,
                    "pricesFrom": dailyprices.local_built(gdir) or ""})
    probe = ""
    if not m:
        try:                                                    # say exactly what the first address answered, so a problem can be seen instead of guessed
            import requests
            b0 = carddata.bases(svc, "catalog")[0]
            r = requests.get(b0 + "/manifest.json", timeout=15)
            probe = f"{b0}: HTTP {r.status_code}, {len(r.content)} bytes, {r.headers.get('content-type', '?')}"
        except Exception as e:  # noqa: BLE001
            probe = f"{type(e).__name__}: {str(e)[:160]}"
    return {"games": out, "reachable": bool(m), "busy": bool(svc.jobs.running("games")), "errors": list(carddata.last_errors), "probe": probe}


@api("catalogs.updateNow")
def catalogs_update_now(svc):
    """Fetch every newer card list now (the game you are looking at first), then today's prices."""
    j = gamesapi.refresh_catalogs(svc)
    svc._more_catalogs = True                               # the next games follow one after another
    svc._daily_next = 0                                     # and the price check runs at the next tick
    return {"job": j}
