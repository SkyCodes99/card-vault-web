"""Graded copies and Gem Rate on a card (cardvault/gradedpop.py): pop.card reads them (cached, polite), pop.connect / pop.disconnect keep the optional source key in this profile's encrypted secrets."""
from .. import gradedpop
from .registry import ApiError, api


def _secret(svc):
    s = getattr(svc, "session", None)
    return (lambda: s.get("pop_key")) if s is not None else None


@api("pop.card", quiet=True)
def pop_card(svc, id):
    """{state, rows: [{company, total, gem, grades: [{grade, n}]}], updated, source}; state 'unsupported' for a game the source does not cover."""
    if svc.game.id != "pokemon":
        return {"state": "unsupported", "rows": [], "updated": "", "source": gradedpop.SOURCE}
    r = svc.vault.conn.execute("SELECT tcg_id FROM cards WHERE id=?", (id,)).fetchone()
    return gradedpop.for_card(svc.vault.conn, r[0] if r else "", _secret(svc))


@api("pop.connect")
def pop_connect(svc, key):
    k = str(key or "").strip()
    if not k or len(k) > 200 or any(c.isspace() for c in k):
        raise ApiError("That does not look like a key.")
    if getattr(svc, "session", None) is None:
        raise ApiError("Sign in first: the key is kept in your account's encrypted storage.")
    svc.session.set("pop_key", k)
    return {"ok": True}


@api("pop.disconnect")
def pop_disconnect(svc):
    if getattr(svc, "session", None) is not None:
        svc.session.set("pop_key", None)
    return {"ok": True}
