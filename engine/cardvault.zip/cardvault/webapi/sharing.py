"""Share a portfolio with another account by username (view-only).  The owner publishes a sealed snapshot of the cards and sealed products in the portfolios they pick;
the person they name gets an offer, says yes, and then sees it under "Shared with me".  The server only ever holds ciphertext (see cardvault/cloud/sharing.py).

Honest limits: view-only (no editing together), the snapshot is refreshed when the owner presses Update, and a removed person keeps what they had already downloaded."""
import base64
import json
import urllib.parse

from ..cloud import sharing as sh
from ..cloud import skycloud as sc
from .accountapi import account
from .portfolios import MAIN, main_name
from .registry import ApiError, api


def _acct(svc):
    a = account(svc, need=True)
    if not svc.pget("cloud_username"):
        raise ApiError("Pick a username first (Settings > Account) so people can find you.")
    return a


def _call(fn):
    try:
        return fn()
    except sc.CloudError as e:
        raise ApiError(str(e))
    except ApiError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ApiError(f"Sharing didn't work: {e}")


def _load(svc, key):
    try:
        d = json.loads(svc.pget(key) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def ensure_ready(svc):
    """Turn sharing on for this account in the background (once): the person's share key is made and stored, so anybody can find them by username and share with them.  Without it,
    a name only became findable after its owner had opened the Share screen."""
    if getattr(svc, "_kp_done", False):
        return
    a = account(svc)
    if a is None or not svc.pget("cloud_username"):
        return
    try:
        sh.ensure_keypair(a)
        svc._kp_done = True
    except Exception as e:  # noqa: BLE001 - offline or the server is busy: tried again later
        print("sharing: could not turn it on yet:", repr(e)[:200])


def _out(svc):
    return _load(svc, "share_out")


def _inn(svc):
    return _load(svc, "share_in")


def _gk(entry):
    return base64.b64decode(entry["key"])


def _label(entry, m):
    try:
        return sh.open_json(_gk(entry), m["label_blob"], "group/label").get("label") or ""
    except Exception:  # noqa: BLE001
        return ""


def _snapshot(svc, portfolios):
    """The rows to publish for these portfolios: every card (with its picture, price and how many) and every sealed product."""
    v = svc.vault
    saved = v.scope
    want = [("" if p == MAIN else p) for p in portfolios]
    v.set_scope(want)
    try:
        cards = v.conn.execute(
            "SELECT c.id, c.name, c.local_id, c.rarity, c.image_base, c.price_usd, s.name AS set_name, SUM(l.qty) AS qty FROM lots_s l JOIN cards c ON c.id=l.card_id "
            "LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.id", (v.user_id, v.game)).fetchall()
        marks = ",".join("?" * len(want)) or "''"
        sealed = v.conn.execute(f"SELECT uuid, name, SUM(qty) AS qty FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND COALESCE(portfolio,'') IN ({marks}) GROUP BY name",
                                (v.user_id, v.game, *want)).fetchall()
    finally:
        v.set_scope(saved)
    rows = [("cards", r["id"], {"id": r["id"], "name": r["name"], "no": r["local_id"], "rarity": r["rarity"], "img": r["image_base"], "usd": r["price_usd"], "set": r["set_name"], "qty": r["qty"]}) for r in cards]
    rows += [("sealed", "s-" + r["uuid"], {"name": r["name"], "qty": r["qty"]}) for r in sealed]
    return rows


def _names(svc):
    names = {MAIN: main_name(svc)}
    names.update({p["uuid"]: p["name"] for p in svc.vault.portfolios()})
    return names


def _publish(svc, a, gid, entry):
    if entry.get("kind") == "trade":                                       # a trade-lists share holds wants + spares, not portfolios (see tradematch.py)
        from . import tradematch
        key = _gk(entry)
        rows = tradematch.rows_for(svc, entry)
        have = sh.pull_rows(a, gid, key)
        mine = {(c, i) for c, i, _ in rows}
        sh.push_rows(a, gid, key, rows + [(c, i, None) for (c, i) in have if (c, i) not in mine and c in ("wants", "haves")])
        return len(rows)
    if entry.get("kind") == "friend":                                      # the friend profile (see friends.py)
        from . import friends
        friends._publish_profile(svc, a)
        return 1
    key = _gk(entry)
    rows = _snapshot(svc, entry["portfolios"])
    have = sh.pull_rows(a, gid, key)
    mine = {(c, i) for c, i, _ in rows}
    gone = [(c, i, None) for (c, i) in have if (c, i) not in mine and c in ("cards", "sealed")]
    names = _names(svc)
    info = ("meta", "info", {"title": entry["title"], "game": svc.game.name, "gameId": svc.game.id if hasattr(svc.game, "id") else "", "from": svc.pget("cloud_username"),
                             "portfolios": [names.get(p, p) for p in entry["portfolios"]], "cards": sum(r[2]["qty"] or 0 for r in rows if r[0] == "cards"),
                             "unique": sum(1 for r in rows if r[0] == "cards"), "usd": round(sum((r[2]["usd"] or 0) * (r[2]["qty"] or 0) for r in rows if r[0] == "cards"), 2) if entry.get("showValue") else None})
    sh.push_rows(a, gid, key, [info] + rows + gone)
    return len(rows)


# --------------------------------------------------------------------------- owner side
@api("share.account.status", quiet=True)
def status(svc):
    a = account(svc)
    if not a:
        return {"signedIn": False}
    out = {"signedIn": True, "username": svc.pget("cloud_username") or "", "shares": [], "offers": 0, "incoming": []}
    if not out["username"]:
        return out
    o, i = _out(svc), _inn(svc)

    def go():
        out["offers"] = len(a.call("GET", "/v1/offers").get("offers", []))
        for gid, e in o.items():
            if e.get("kind") == "friend":                                  # friend profiles live on the Friends screen
                continue
            offs = {x["username"]: x for x in a.call("GET", f"/v1/groups/{gid}/offers").get("offers", [])}
            mem = a.call("GET", f"/v1/groups/{gid}/members").get("members", [])
            out["shares"].append({"id": gid, "title": e["title"], "kind": e.get("kind", ""), "portfolios": e["portfolios"], "showValue": bool(e.get("showValue")),
                                  "pending": [{"username": u, "offer": x["id"]} for u, x in offs.items()],
                                  "members": [{"id": m["id"], "label": _label(e, m), "role": m.get("role")} for m in mem if m.get("role") != "owner"]})
        out["incoming"] = [{"id": g, "title": e.get("title"), "from": e.get("from"), "kind": e.get("kind", "")} for g, e in i.items() if e.get("kind") != "friend"]
    _call(go)
    return out


@api("share.account.create", mutates=True)
def create(svc, portfolios, title="", showValue=False):
    """Start sharing: makes the group, publishes the snapshot.  Then invite people by username."""
    a = _acct(svc)
    if not portfolios:
        raise ApiError("Pick at least one portfolio to share.")
    names = _names(svc)
    title = (title or ", ".join(names.get(p, p) for p in portfolios))[:80]

    def go():
        sh.ensure_keypair(a)
        key, gid = sh.new_group_key(), sh.new_id()
        a.call("POST", "/v1/groups", {"id": gid, "name_blob": sh.seal_json(key, {"title": title, "from": svc.pget("cloud_username")}, "group/name"),
                                      "label_blob": sh.seal_json(key, {"label": "owner"}, "group/label")})
        entry = {"key": base64.b64encode(key).decode(), "title": title, "portfolios": list(portfolios), "showValue": bool(showValue)}
        o = _out(svc)
        o[gid] = entry
        svc.pset("share_out", json.dumps(o))
        n = _publish(svc, a, gid, entry)
        return {"id": gid, "published": n}
    return _call(go)


@api("share.account.update", mutates=True)
def update(svc, id):
    a, e = _acct(svc), _out(svc).get(id)
    if not e:
        raise ApiError("That share isn't on this device. Sharing keys are kept on the device that made them.")
    return {"published": _call(lambda: _publish(svc, a, id, e))}


@api("share.account.invite", mutates=True)
def invite(svc, id, username):
    a, e = _acct(svc), _out(svc).get(id)
    if not e:
        raise ApiError("That share isn't on this device.")
    name = (username or "").strip().lstrip("@").lower()
    if not name:
        raise ApiError("Type their username.")

    def go():
        try:
            p = a.call("GET", "/v1/people/" + urllib.parse.quote(name))
        except sc.CloudError as ex:
            if ex.status == 404:
                raise ApiError("No one with that username can receive shares yet (or it's your own name). Check the spelling - and they need to have signed in to Collect Em All at least once on a recent version.")
            raise
        blob = sh.box_seal(p["pubkey"], _gk(e))
        try:
            a.call("POST", f"/v1/groups/{id}/share", {"id": sh.new_id(), "username": name, "blob": blob, "role": "viewer"})
        except sc.CloudError as ex:
            if ex.status == 409:
                raise ApiError("They already have this.")
            raise
        return {"ok": True}
    return _call(go)


@api("share.account.cancelOffer", mutates=True)
def cancel_offer(svc, id, offer):
    _call(lambda: _acct(svc).call("DELETE", f"/v1/groups/{id}/offers/{offer}"))
    return True


@api("share.account.remove", mutates=True)
def remove_person(svc, id, member):
    _call(lambda: _acct(svc).call("DELETE", f"/v1/groups/{id}/members/{member}"))
    return True


@api("share.account.stop", mutates=True)
def stop(svc, id):
    """Delete the share for everybody (the server removes the records and open offers)."""
    a = _acct(svc)
    _call(lambda: a.call("DELETE", f"/v1/groups/{id}"))
    o = _out(svc)
    o.pop(id, None)
    svc.pset("share_out", json.dumps(o))
    return True


# --------------------------------------------------------------------------- receiving side
@api("share.account.offers")
def offers(svc):
    a = _acct(svc)

    def go():
        priv, _ = sh.ensure_keypair(a)
        out = []
        for o in a.call("GET", "/v1/offers").get("offers", []):
            try:
                key = sh.box_open(priv, o["blob"])
                nm = sh.open_json(key, o["name_blob"], "group/name")
            except Exception:  # noqa: BLE001
                continue
            out.append({"id": o["id"], "from": o["from"], "title": nm.get("title") or "A shared collection", "kind": nm.get("kind", "")})
        return out
    return _call(go)


@api("share.account.accept", mutates=True)
def accept(svc, id):
    a = _acct(svc)

    def go():
        priv, _ = sh.ensure_keypair(a)
        o = next((x for x in a.call("GET", "/v1/offers").get("offers", []) if x["id"] == id), None)
        if not o:
            raise ApiError("That offer is gone.")
        key = sh.box_open(priv, o["blob"])
        nm = sh.open_json(key, o["name_blob"], "group/name")
        r = a.call("POST", f"/v1/offers/{id}/accept", {"label_blob": sh.seal_json(key, {"label": svc.pget("cloud_username") or ""}, "group/label")})
        i = _inn(svc)
        i[r["id"]] = {"key": base64.b64encode(key).decode(), "title": nm.get("title"), "from": o["from"], **({"kind": nm["kind"]} if nm.get("kind") else {})}
        svc.pset("share_in", json.dumps(i))
        return {"id": r["id"]}
    return _call(go)


@api("share.account.decline", mutates=True)
def decline(svc, id):
    _call(lambda: _acct(svc).call("DELETE", f"/v1/offers/{id}"))
    return True


@api("share.account.view", quiet=True)
def view(svc, id, q=""):
    """What someone shared with me: the info line plus the cards and sealed products (read-only)."""
    a, e = _acct(svc), _inn(svc).get(id)
    if not e:
        raise ApiError("That share isn't on this device.")
    rows = _call(lambda: sh.pull_rows(a, id, _gk(e)))
    info = rows.get(("meta", "info")) or {"title": e.get("title"), "from": e.get("from")}
    words = (q or "").lower().split()
    cards = sorted((v for (c, _), v in rows.items() if c == "cards"), key=lambda x: -((x.get("usd") or 0) * (x.get("qty") or 0)))
    if words:
        cards = [c for c in cards if all(w in f"{c.get('name')} {c.get('set')} {c.get('no')}".lower() for w in words)]
    from .cards import img
    conn = svc.vault.conn
    for c in cards[:600]:          # the picture comes from this device's own card list (same game), so no picture data travels in the share
        r = conn.execute("SELECT set_id FROM cards WHERE id=?", (c["id"],)).fetchone()
        c["pic"] = img(c["id"], r["set_id"]) if r else ""
    sealed = sorted((v for (c, _), v in rows.items() if c == "sealed"), key=lambda x: x.get("name") or "")
    return {"info": info, "cards": cards[:600], "total": len(cards), "sealed": sealed}


@api("share.account.leave", mutates=True)
def leave(svc, id, member=None):
    a = _acct(svc)
    i = _inn(svc)
    if member:
        _call(lambda: a.call("DELETE", f"/v1/groups/{id}/members/{member}"))
    i.pop(id, None)
    svc.pset("share_in", json.dumps(i))
    return True
