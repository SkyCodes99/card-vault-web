"""Cards: set / category / illustrator / Pokémon boxes, card lists, one card's details and every way of changing what you own."""
import json
import re
import urllib.parse
from operator import itemgetter

from ..details.match import clean as textclean
from .. import cardtext, checklists, gamefacets, legality, msrp, onesource, pullrates, pricepick, pricestats, provenance, runtime, selllinks, shoplinks, taxonomy
from ..db import CONDITIONS, GRADERS, VARIANT_FLAGS, VARIANT_LABELS, clean_flags, fix_text
from . import comiccovers, filtercache, gameversions, otherprices
from .registry import api
from .service import ApiError

MAX_SECTION_CARDS = 4000
PAGE_MAX = 2000                   # (a list asked for up to this many rows may be answered page-only: Vault.query_page)
NEWEST_KEPT = 200                 # (the first cards of a game's whole list, kept beside it for its first look)
GENERATIONS = [("", "All generations"), ("1-151", "Gen I · #1–151"), ("152-251", "Gen II · #152–251"), ("252-386", "Gen III · #252–386"),
               ("387-493", "Gen IV · #387–493"), ("494-649", "Gen V · #494–649"), ("650-721", "Gen VI · #650–721"), ("722-809", "Gen VII · #722–809"),
               ("810-905", "Gen VIII · #810–905"), ("906-1025", "Gen IX · #906–1025")]
LANGUAGES = ["English", "Japanese", "Korean", "Chinese", "German", "French", "Italian", "Spanish", "Portuguese", "Other"]
EDITIONS = ["", "1st Edition", "Shadowless", "Unlimited", "Stamped", "Prerelease", "Staff", "Promo", "Error / misprint", "Other"]
GRADES = ["10", "9.5", "9", "8.5", "8", "7.5", "7", "6.5", "6", "5.5", "5", "4.5", "4", "3.5", "3", "2.5", "2", "1.5", "1", "Authentic", "Altered"]


def q(s):
    return urllib.parse.quote(str(s), safe="")


def img(cid, set_id, quality=""):
    svc = getattr(runtime.thread, "svc", None) or runtime.service
    if svc is not None:
        if runtime.REMOTE_IMAGES:
            url = svc.remote_image(cid, quality or "low")
            if url:
                return url
        if not svc.has_picture_source(cid, set_id):
            return ""                                                  # no picture exists for it: nothing to ask for (the screen shows its placeholder)
    return f"/img?c={q(cid)}&s={q(set_id)}" + (f"&q={quality}" if quality else "")


def _sale(svc, cid):
    """Sale Data for the card panel: the recent typical price from our saved price history (None when it is switched off or has no data yet)."""
    from . import trendapi
    from .. import trend
    if trendapi.mode(svc) == "standard":
        return None
    t = trend.for_vault(svc)
    i = t.info(cid)
    return {**(i or {}), "have": bool(i), "daysSaved": t.days, "ask": t.ask_info(cid)}


def _no_price_why(svc, c):
    """Why a card shows no price (shown instead of a bare 'no price'; never a made-up number)."""
    sname = (c["set_name"] or "") if "set_name" in c.keys() else ""
    if "pocket" in sname.lower() or str(c["set_id"] or "").startswith(("A1", "A2", "A3", "A4", "B1", "P-A")):
        return "This is a digital (TCG Pocket) card, so it has no market price."
    if svc.game.id == "comics":
        return "No price: no free source with real comic prices is allowed yet, so none is shown rather than a guess."
    if svc.game.id == "videogames":
        return "No price: no free source with real video game prices is allowed yet, so none is shown rather than a guess."
    if svc.game.id in ("onepiece", "unionarena", "yugioh", "dbs"):
        return "It is on TCGplayer but has no price yet - no recent sales."
    return "No TCGplayer price has been found for this card yet."


def lot_dict(l):
    return {"id": l["id"], "variant": l["variant"], "condition": l["condition"], "language": l["language"], "qty": l["qty"], "graded": bool(l["graded"]),
            "company": l["grade_company"] or "", "grade": l["grade"] or "", "cert": l["cert"] or "", "slabStatus": (l["slab_status"] if "slab_status" in l.keys() else "") or "", "paid": l["purchase_price"], "notes": l["notes"] or "",
            "location": l["location"] or "", "edition": l["edition"] or "", "purchased": l["purchased"] or "", "added": (l["added"] or "")[:10], "source": l["source"] or "",
            "portfolio": l["portfolio"] or "main"}


def _vp(r, lab):
    """(price of this printing, whether it is that printing's own price)"""
    from .. import variantprice
    return variantprice.price_for({"variant_prices": r["variant_prices"], "variants": r["variants"], "price_usd": r["price_usd"]}, lab)


def _target_name(svc):
    """The name of the portfolio new cards are being added to (shown whenever something is marked, so it is always clear where it went)."""
    from .complete import pf_name
    return pf_name(svc, svc.vault.target_pf)


def with_undo(svc, fn):
    """Run a change, reload the shared state and say how to undo it."""
    v = svc.vault
    before = v.conn.execute("SELECT COALESCE(MAX(id),0) FROM u.actions").fetchone()[0]
    out = fn()
    svc.reload_state()
    last = v.last_undoable()
    undo = {"id": last["id"], "label": last["label"]} if last and last["id"] > before else None
    return {"ok": True, "undo": undo, **(out if isinstance(out, dict) else {})}


def q_(s):
    return urllib.parse.quote(str(s), safe="")


# ------------------------------------------------------------------------------------------------ one scope's cards
def scope_ids(v, kind, val, edition):
    if kind == "group":
        return v.group_ids(val, edition)
    if kind == "illustrator":
        return v.facets(edition)["illustrator"].get(val, [])
    if kind == "pokemon":
        return v.facets(edition)["dex"].get(int(val), [])
    return None


_POCKET_SETS = "SELECT id FROM sets WHERE serie LIKE '%pocket%'"


def _filter_scope(kind, val, edition):
    """What the Cards page has open, as (condition on the cards table, args) for counting the filters within it (gamefacets._within) - None for the whole list.
    One set: that set's cards only.  Pokémon's physical cards / TCG Pocket (the 'edition' the page shows): those only."""
    conds, args = [], []
    if kind == "set" and val:
        conds.append("set_id = ?")
        args.append(str(val))
    if edition == "tcg":
        conds.append(f"set_id NOT IN ({_POCKET_SETS})")
    elif edition == "pocket":
        conds.append(f"set_id IN ({_POCKET_SETS})")
    return (" AND ".join(conds), args) if conds else None


@api("cards.filters")
def filters(svc, kind="all", val=None, edition=None):
    """The Cards page's filters with how many cards have each value - counted within what is open (one set, the physical cards only), not the whole game."""
    v, g = svc.vault, svc.game
    scope = _filter_scope(kind, val, edition)
    ck = v.catalog_fp()                                       # the filters come from the card list alone: they are worked out again only when that changes (not at every change to your collection)
    memo = v.__dict__.setdefault("_filters_cache", {})
    key = (ck, repr(scope))
    if ck is not None and key in memo:
        return memo[key]
    name = "filters" if scope is None else f"filters_{edition}" if kind != "set" else None      # (the whole list and each edition are kept in a file beside it; one set is quick to count)
    out = filtercache.load(v, name) if name else None         # (the same card list as last session: its filters are in the file beside it)
    if out is None:
        out = _filters(svc, v, g, scope, kind == "set", edition)
        if name:
            filtercache.save(v, out, name)
    if len(memo) > 40:
        memo.clear()
    memo[key] = out
    return out


def _pokemon_eras(v, g, edition=None):
    """The eras in order, each with how many cards it has (Pokémon only)."""
    if not g.pokemon:
        return []
    groups = (grp for grp in taxonomy.groups() if grp.parent == "era")
    return [{"id": grp.id, "label": grp.label, "n": n} for grp in groups if (n := len(v.group_ids(grp.id, edition)))]


def _sort_choices(v, g, basics):
    """The orders the list can be sorted in - only the ones that mean something for THIS game (no price order for a list without prices, no illustrator order where there are no illustrators ...)."""
    voc = gamefacets.vocab(g.id)
    numbered = bool(v.conn.execute("SELECT 1 FROM cards WHERE local_id IS NOT NULL AND local_id NOT IN ('', '0') LIMIT 1").fetchone())
    sorts = [["default", "Newest to oldest"], ["oldest", "Oldest to newest"]]
    if v._has_pop() and v.conn.execute("SELECT 1 FROM cards WHERE popularity IS NOT NULL LIMIT 1").fetchone():
        sorts.insert(0, ["popular", "Popular"])
    if basics["hasPrices"]:
        sorts += [["price", "Highest price first"], ["priceasc", "Lowest price first"]]
    sorts += [["owned", "Owned first"], ["unowned", "Not owned first"], ["name", "Name A–Z"], ["namez", "Name Z–A"]]
    if numbered:
        sorts.append(["numasc", f"{voc['setLabelOne']}, then {voc['nounOne']} number"])
    sorts.append(["set", f"{voc['setLabelOne']} name A–Z"])
    if len(basics["rarities"]) > 1:
        sorts.append(["rarity", f"{voc['rarityLabel']} A–Z"])
    if basics["hasArtist"]:
        sorts.append(["artist", "Illustrator A–Z"])
    if g.pokemon:
        sorts.append(["dex", "Pokédex number"])
    if g.id == "mtg" and v.conn.execute("SELECT 1 FROM cards WHERE color_key IS NOT NULL AND color_key != '' LIMIT 1").fetchone():
        sorts.append(["color", "Colour (white, blue, black, red, green, gold, colourless)"])
    return sorts


def _filters(svc, v, g, scope=None, one_set=False, edition=None):
    basics = gamefacets.basics(v.conn, g.id, scope)               # which filters make sense for this game: a filter with nothing to choose from is not shown
    try:
        facets = gamefacets.filters(v.conn, g.id, scope)          # the game's own (see gamefacets): card kind, attribute, trait, special printing... / product type, availability, edition...
    except Exception:  # noqa: BLE001 - a list without them still has its other filters
        facets = []
    lg = legality.facet(v.conn, scope)                        # 'Legal in' (Standard, Modern, TCG...): only where a source gave format legality (Pokemon, Magic, Yu-Gi-Oh!)
    if lg:
        facets = list(facets) + [lg]
    return {"facets": facets, "types": basics["types"], "rarities": basics["rarities"], "typeLabel": g.type_label, "eras": [] if one_set else _pokemon_eras(v, g, edition), "hasArtist": basics["hasArtist"],
            "hasDates": basics["hasDates"], "hasPrices": basics["hasPrices"], "sorts": _sort_choices(v, g, basics), "voc": gamefacets.vocab(g.id)}


def _rows(svc, v, shown, names=None):
    """The rows of the cards shown ([(id, name, set id, number)]): what you own of each, its price, picture and trend."""
    from . import trendapi
    if names is None:
        names = {s["id"]: s["name"] for s in v.sets()}
    owned, wish, oc = svc.owned, svc.wishlist, v.owned_conditions(r[0] for r in shown)          # (just the cards shown: a 3,000-card collection need not be read for a page of 60)
    lights = v.card_lights(r[0] for r in shown)                                     # (just these cards: a game opened a moment ago need not have its whole card index yet)
    rows = []
    retail = msrp.lookup(v.conn, [x[0] for x in shown])                              # the maker's retail price (MSRP): shown beside the market price, never mixed into it
    one = onesource.ids(v.conn, "cards", [x[0] for x in shown])                      # 'only one source so far' (the daily accuracy check; never changes a price)
    for cid, name, set_id, local_id in shown:
        light = lights.get(cid) or {}
        rows.append({"id": cid, "name": fix_text(name), "setId": set_id, "set": names.get(set_id, set_id), "number": local_id, "qty": owned.get(cid, 0), "wish": cid in wish,
                     "cond": "/".join(dict.fromkeys(x for x in (oc.get(cid) or {}).values() if x)),
                     "price": light.get("price_usd"), "tcg": light.get("tcg_id") or "", "priceKind": light.get("price_kind") or "", "digital": "pocket" in (light.get("serie") or "").lower(), "rarity": light.get("rarity") or "", "img": img(cid, set_id), "msrp": retail.get(cid), "one": cid in one, **({"key": True} if comiccovers.is_key_row(light) else {})})
    pricepick.patch(v, rows)                                                       # the price Settings > Price sources picks (no change for Standard)
    pricepick.attach_owned(v, rows)                                                # what the copies you own are worth (graded copies at their graded price)
    trendapi.attach(svc, rows)
    return rows


def _place_ids(v, place):
    """The cards with a copy stored in a place whose name contains these words ('Box A' finds 'Box A (red)')."""
    return {r[0] for r in v.conn.execute("SELECT DISTINCT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND instr(LOWER(location), ?) > 0",
                                         (v.user_id, v.game, place.lower()))}


@api("cards.list")
def cards_list(svc, kind="all", val=None, edition=None, text="", show="all", ctype="", rarity="", sort="default", split=False, limit=1500, era="",
               price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None, priced="", letter="", place="", facets=None, _t=None):
    show = "wishlist" if show == "wish" else show                  # (the short name means the wishlist too - it used to fall through to the whole list)
    v = svc.vault
    g_pokemon = svc.game.pokemon
    plain = kind == "all" and show == "all" and sort == "default" and not split and not edition and not any((text, ctype, rarity, era, set_text, artist, priced, letter, place, facets)) and \
        all(x in (None, "") for x in (price_min, price_max, year_min, year_max))
    head = None
    if plain and not v.whole_order_kept(edition):                 # (the whole order isn't at hand yet: the first 200 are kept beside the list instead - sorting 100k cards for one page is a third of a second)
        head = [tuple(r) for r in filtercache.kept(v, "newest", lambda: [list(r) for r in v.newest_cards(NEWEST_KEPT)])][:limit] if limit <= NEWEST_KEPT else v.newest_cards(limit)
    if head is not None:                                          # the first look at a game's whole list: just the first page, without putting every card in order first
        mine = [c for c, q in svc.owned.items() if q > 0]
        n_owned = sum(v.conn.execute(f"SELECT COUNT(*) FROM cards WHERE id IN ({','.join('?' * len(part))})", part).fetchone()[0] for part in (mine[i:i + 500] for i in range(0, len(mine), 500)))
        return {"rows": _rows(svc, v, head), "total": v.card_count(), "owned": n_owned, "sections": None, "leftOut": 0}
    ids = scope_ids(v, kind, val, edition)
    qkw = dict(set_id=val if kind == "set" else None, show=show, ctype=ctype or None, rarity=rarity or None, sort=sort, only_ids=ids, edition=edition,
               price_min=None if price_min in (None, "") else price_min, price_max=None if price_max in (None, "") else price_max,
               set_text=set_text or "", artist=artist or "", year_min=year_min, year_max=year_max, priced=priced or "", letter=letter or "")
    words = (text or "").strip()
    at_place = _place_ids(v, words) if words and not place else set()    # a search word that is a storage place ('Box A') also finds the cards kept there, after the name matches
    if kind == "all" and show == "all" and sort == "default" and not (split or edition or era or place or facets or at_place or ids is not None) and type(limit) is int and 0 < limit <= PAGE_MAX:
        # a big answer (a typed 'l': 87,000 cards): just the page shown and the two counts, from SQL (Vault.query_page)
        got = v.query_page(limit, [c for c, q in svc.owned.items() if q > 0], text=words, **{k: x for k, x in qkw.items() if k not in ("set_id", "show", "sort", "only_ids", "edition")})
        if got is not None:
            names = {s["id"]: s["name"] for s in v.sets()}
            return {"rows": _rows(svc, v, got[0], names), "total": got[1], "owned": got[2], "sections": None, "leftOut": 0}
    raw = v.query_cards(text=words, fuzzy=True, **qkw)
    if at_place:                                                  # (the ids of every hit only when a place matches: 87,000 of them for a typed 'l')
        in_place = at_place - {r[0] for r in raw}
        if ids is not None:
            in_place &= set(ids)
        if in_place:
            raw = list(raw) + [r for r in v.query_cards(text="", only_ids=sorted(in_place), **{k: x for k, x in qkw.items() if k != "only_ids"}) if r[0] in in_place]
    if place:                                                     # the 'Stored in' filter: only the cards with a copy in that place
        keep = _place_ids(v, place.strip())
        raw = [r for r in raw if r[0] in keep]
    if era:                                                       # only the cards of one era (Original 1999-2003, XY, Sword & Shield ...)
        in_era = set(v.group_ids(era))
        raw = [r for r in raw if r[0] in in_era]
    if isinstance(facets, dict) and facets:                       # the game's own filters: every chosen filter must match, any of its chosen values will do
        want = {str(k): [str(x) for x in vals] for k, vals in facets.items() if isinstance(vals, (list, tuple)) and vals}
        gamefacets.ensure(v.conn, svc.game.id)                    # (read straight from the card list's own filter table - not from the card index, which a game that has just been opened may not have yet)
        keep = None
        for k, vals in want.items():
            marks = ",".join("?" * len(vals))
            if k == "category":
                cur = {r[0] for r in v.conn.execute(f"SELECT id FROM cards WHERE category IN ({marks})", vals)}
            elif k == legality.FACET_KEY:
                cur = legality.card_ids(v.conn, vals)
            elif k == cardtext.KEY:                               # 'Card text': the typed words are in the card's text
                cur = cardtext.card_ids(v.conn, vals)
            else:
                cur = {r[0] for r in v.conn.execute(f"SELECT card_id FROM card_facets WHERE facet=? AND value IN ({marks})", [k, *vals])}
            keep = cur if keep is None else keep & cur
        raw = [r for r in raw if r[0] in keep] if keep is not None else raw
    names = {s["id"]: s["name"] for s in v.sets()}
    owned = svc.owned
    left_n = 0
    if kind == "set":                                   # cards the person left out of this set (they stay out of the list, the totals and the progress; "Left out" shows them)
        from .setanalytics import _excluded
        excl = _excluded(v, val)
        left_n = len(excl)
        raw = [r for r in raw if (r[0] in excl) == (show == "left")]
    pos = {c for c, q in owned.items() if q > 0}
    n_all, n_owned = len(raw), sum(map(pos.__contains__, map(itemgetter(0), raw)))     # the counts come from the ids alone; only the cards that are shown get their full row (a 100,000-card game stays quick)
    rows = _rows(svc, v, raw if split else raw[:limit], names)
    out = {"rows": rows, "total": n_all, "owned": n_owned, "sections": None, "leftOut": left_n}
    if split:
        if len(rows) > MAX_SECTION_CARDS:
            out["splitRefused"] = True
        else:
            by = {}
            for r in rows:
                light = v.card_light(r["id"]) or {}
                lab = taxonomy.card_rarity_label(light, light.get("groups")) if (g_pokemon and light) else (r["rarity"] or "Unlabelled")
                by.setdefault(lab, []).append(r["id"])
            rank = taxonomy.label_rank if g_pokemon else taxonomy.rarity_rank
            out["sections"] = [{"title": t, "ids": by[t]} for t in sorted(by, key=lambda x: (rank(x), x))]
    if kind != "all":
        if kind == "set":
            prog = checklists.progress_for_set(v, val)
        else:
            prog = checklists.progress_for_cards(v, ids or [])
        out["progress"] = {"owned": prog.owned, "total": prog.total, "pct": prog.pct}
        out["title"] = names.get(val, val) if kind == "set" else taxonomy.LABEL.get(val, val) if kind == "group" else \
            (f"#{int(val):04d} {checklists.dex_names(v).get(int(val), '?')}" if kind == "pokemon" else val)
    return out


# ------------------------------------------------------------------------------------------------ one card
@api("card.detail")
def detail(svc, id):
    v, g = svc.vault, svc.game
    c = v.card(id)
    if not c:
        raise ApiError("card not found")
    raw = {}
    try:
        raw = json.loads(c["raw"] or "{}")
    except ValueError:
        pass
    t = lambda s: fix_text(s) if s else ""
    labels, lists = _later(v, id)
    number = f"{c['local_id']}/{c['set_official']}" if (c["set_official"] and g.pokemon) else c["local_id"]
    flags = {}
    try:
        flags = clean_flags(json.loads(c["variants"] or "{}"), c["rarity"])
    except ValueError:
        pass
    variants = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)] or ["Normal"]
    facts = []
    if g.pokemon:
        for lab, key in (("Type", "types"), ("Stage", "stage"), ("Illustrator", "illustrator")):
            if c[key]:
                facts.append([lab, t(c[key])])
        if c["hp"]:
            facts.append(["HP", str(c["hp"])])
        if c["evolve_from"]:
            facts.append(["Evolves from", t(c["evolve_from"])])
        if c["dex"]:
            facts.append(["Pokédex", "#" + c["dex"].replace(",", ", #")])
        if re.fullmatch(r"[A-Z]", str(raw.get("regulationMark") or "")):
            facts.append(["Regulation mark", raw["regulationMark"]])
        if isinstance(raw.get("ext"), dict) and not raw.get("attacks"):             # a card only TCGplayer lists (a promo pack, a World Championship deck ...): its attacks, text, weakness and retreat are in the shop's own record
            for k, val in raw["ext"].items():
                if k not in ("Number", "Rarity", "HP", "Stage", "Card Type", "Description") and val not in ("", None):
                    facts.append([k, t(textclean(str(val)))])
    else:
        ext = raw.get("ext", {})
        facts = [[k, t(textclean(str(ext[k]).replace(";", ", ")))] for k in ext if k not in ("Description", "Number") and ext[k] not in ("", None)]
        if c["illustrator"] and str(c["illustrator"]).strip().upper() != "N/A":      # the artist is a column of the card (the shop's own record has none), shown with its other facts
            facts.insert(0, ["Illustrator", t(c["illustrator"])])
    blocks = []
    for ab in raw.get("abilities") or []:
        blocks.append({"title": f"{t(ab.get('type', 'Ability'))}: {t(ab.get('name'))}", "text": t(ab.get("effect"))})
    for at in raw.get("attacks") or []:
        blocks.append({"title": f"{t(at.get('name'))} {at.get('damage', '')}".strip(), "cost": " ".join(at.get("cost") or []), "text": t(at.get("effect"))})
    if raw.get("effect"):
        blocks.append({"title": "", "text": t(raw["effect"])})
    extras = []
    for lab, key in (("Weakness", "weaknesses"), ("Resistance", "resistances")):
        if raw.get(key):
            extras.append([lab, ", ".join(f"{x.get('type')} {t(x.get('value', ''))}" for x in raw[key])])
    if raw.get("retreat") is not None:
        extras.append(["Retreat", str(raw["retreat"])])
    hist = [{"day": d, "usd": usd} for d, usd, _ in v.price_history(id) if usd is not None]
    lots = [lot_dict(l) for l in v.lots_for(id)]
    pf_names = {"": __import__("cardvault.webapi.portfolios", fromlist=["x"]).main_name(svc), **{p["uuid"]: p["name"] for p in v.portfolios()}}
    usd, kind = pricepick.shown(v, id, c["price_usd"], c["price_kind"] if "price_kind" in c.keys() else "")       # the picked price (Standard: the main price, as before)
    all_lots = v.lots_for(id)
    by_pf = {}
    for d, l in zip(lots, all_lots):                                               # each copy at its own price: a graded copy at its graded price when one exists ("no graded price yet" otherwise)
        gp = pricepick.graded_price(v, id, l["grade_company"], l["grade"]) if l["graded"] else None
        d["value"] = round((gp[0] if gp else usd or 0) * l["qty"], 2)
        d["noGradedPrice"] = bool(l["graded"]) and gp is None
        if l["qty"] > 0:
            k = by_pf.setdefault(l["portfolio"] or "", [0, 0.0])
            k[0] += l["qty"]
            k[1] += d["value"]
    holdings = [{"id": pf or "main", "name": pf_names.get(pf, "Other"), "qty": q, "value": round(val, 2)} for pf, (q, val) in by_pf.items()]
    return {
        "holdings": holdings,
        "id": id, "name": t(c["name"]), "setId": c["set_id"], "set": c["set_name"] or c["set_id"], "number": number, "rarity": c["rarity"] or "",
        "img": img(id, c["set_id"]), "imgHigh": img(id, c["set_id"], "high"), "imgNote": raw.get("image_note") or "", "tcg": (c["tcg_id"] if "tcg_id" in c.keys() else None) or "", "kinds": labels, "facts": facts, "blocks": blocks, "extras": extras,
        "description": t(c["description"]), "priceUsd": usd, "priceMain": c["price_usd"], "priceBasis": "" if pricepick.prices(v) is None else pricepick.label(v), "priceEur": c["price_eur"], "priceUpdated": c["price_updated"], "history": hist, "historyMore": len(hist) < 2 and bool(c["set_id"]), "stats": pricestats.stats(hist, c["price_kind"] if "price_kind" in c.keys() else ""), "sources": provenance.for_card(v.conn, id), "legality": legality.for_card(v.conn, id), "printRun": pullrates.print_run(v.game, c["set_id"], t(c["name"])), "freePrices": otherprices.for_card(v.conn, id, t(c["name"]), (c["tcg_id"] if "tcg_id" in c.keys() else None) or ""),
        "priceKind": kind, "priceSrc": pricepick.source_info(v, id), "priceMainKind": (c["price_kind"] if "price_kind" in c.keys() else None) or "", "noPriceWhy": "" if usd is not None else _no_price_why(svc, c),
        "sale": _sale(svc, id), "msrp": msrp.lookup(v.conn, [id]).get(id), "one": bool(c["one_source"]) if "one_source" in c.keys() else False,
        "key": comiccovers.key_note(raw), "covers": comiccovers.covers_of(v.conn, id, c["set_id"], c["local_id"], img) if g.id == "comics" else [],
        "versions": gameversions.versions_of(v.conn, id, raw, img) if g.id == "videogames" else [], "seriesGames": gameversions.series_of(v.conn, id, raw, img) if g.id == "videogames" else None,
        "shop": shoplinks.for_item(t(c["name"]), c["set_name"] or "", number, (c["tcg_id"] if "tcg_id" in c.keys() else None) or "", raw),
        "sell": selllinks.for_item(g.id, t(c["name"]), c["set_name"] or "", number),
        "lots": lots, "qty": sum(l["qty"] for l in lots), "wish": id in svc.wishlist, "variants": variants + ["Other"],
        "lists": lists if lists is not None else [{"id": cl["id"], "name": cl["name"], "member": None} for cl in v.checklists()],
        "options": {"conditions": CONDITIONS, "graders": GRADERS, "grades": GRADES, "languages": LANGUAGES, "editions": EDITIONS,
                    "locations": __import__("cardvault.tools", fromlist=["x"]).known_locations(v),
                    "sources": __import__("cardvault.tools", fromlist=["x"]).known_sources(v),
                    "portfolios": [{"id": "main", "name": __import__("cardvault.webapi.portfolios", fromlist=["x"]).main_name(svc)}] + [{"id": p["uuid"], "name": p["name"], "accepts": v.accepts_of(p["uuid"])} for p in v.portfolios() if v.accepts_of(p["uuid"]) != "none"],           # a category holds portfolios, never cards
                    "target": (v.target_pf or "main")},
    }


def _later(v, card_id):
    """(the card's kinds - Full Art, Secret ..., which checklists it is on) - or (None, None) while the card index is still being worked out (see scheduler.warm): both need it, so a card clicked
    in the first seconds opens at once and the panel asks card.later a moment later, instead of waiting seconds for the whole index."""
    if v._index is None:
        return None, None
    light = v.card_light(card_id) or {}
    kinds = [taxonomy.LABEL[x] for x in light.get("groups", []) if x in taxonomy.LABEL]
    return kinds, [{"id": cl["id"], "name": cl["name"], "member": card_id in set(v.checklist_members(cl["id"]))} for cl in v.checklists()]


@api("card.later", quiet=True)
def later(svc, id):
    kinds, lists = _later(svc.vault, id)
    return {"kinds": kinds, "lists": lists}


# ------------------------------------------------------------------------------------------------ changing what you own
def guard_elsewhere(svc, card_id, scoped_lots):
    """You can't 'mark as owned' a card you already hold in a portfolio that isn't being looked at - that would quietly make a second copy.  Say where it is instead."""
    if scoped_lots:
        return
    where = svc.vault.owned_where(card_id)
    if where:
        from .portfolios import main_name
        names = {p["uuid"]: p["name"] for p in svc.vault.portfolios()}
        txt = ", ".join(f"{names.get(pf, main_name(svc)) if pf else main_name(svc)} (x{q})" for pf, q in where)
        raise ApiError(f"You already own this card: {txt}. It counts once, there. To add another copy on purpose, use 'Add another copy' in the card's panel; to see it here, switch the Portfolio menu at the top.")


@api("own.toggle", mutates=True)
def own_toggle(svc, id, variant=""):
    v = svc.vault
    lots = v.lots_for(id)
    guard_elsewhere(svc, id, lots)
    name = (v.card_basic(id) or {}).get("name", id)
    owned = bool([l for l in lots if (not variant or l["variant"] == variant)])

    def run():
        with v.action(f"{'Removed' if owned else 'Marked'} {name}{(' as owned in ' + _target_name(svc)) if not owned else ''}"):
            if owned:
                (v.set_variant_owned(id, variant, False) if variant else v.set_owned(id, False))
            else:
                (v.set_variant_owned(id, variant, True) if variant else v.set_owned(id, True))
                v.record_price_history([id])
    return with_undo(svc, run)


@api("own.needsConfirm")
def needs_confirm(svc, id, variant=""):
    v = svc.vault
    if variant:
        lots = [l for l in v.lots_for(id) if l["variant"] == variant]
        heavy = any(l["qty"] > 1 or l["graded"] or l["purchase_price"] is not None or l["notes"] for l in lots)
        n = sum(l["qty"] for l in lots)
    else:
        heavy = v.needs_remove_confirmation(id)
        n = sum(l["qty"] for l in v.lots_for(id))
    return {"confirm": heavy and n > 0, "copies": n}


@api("qty.adjust", mutates=True)
def qty_adjust(svc, id, delta, variant=None):
    v = svc.vault
    name = (v.card_basic(id) or {}).get("name", id)

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {name}" + (f" - in {_target_name(svc)}" if delta > 0 else "")):
            if delta > 0:
                v.add_lot(id, variant or v.default_variant(id), "Near Mint", delta)
                v.record_price_history([id])
            else:
                for _ in range(-delta):
                    v.remove_one(id, variant or None)
    return with_undo(svc, run)


@api("lot.add", mutates=True)
def lot_add(svc, id, variant="Normal", condition="Near Mint", qty=1, graded=False, company="", grade="", paid=None, notes="", language="English",
            cert="", location="", edition="", purchased="", source="", portfolio=None, slab_status=""):
    v = svc.vault
    made = {}

    def run():
        with v.action("Added a copy"):
            made["lot"] = v.add_lot(id, variant or v.default_variant(id), "Graded" if graded else condition, int(qty), bool(graded), company if graded else "", grade if graded else "",
                                    paid, notes, language, cert=cert if (graded or svc.game.family == "collectibles") else "", location=location, edition=edition, purchased=purchased or "", source=source or "",
                                    portfolio=None if portfolio in (None, "") else ("" if portfolio == "main" else portfolio), slab_status=slab_status)
            v.record_price_history([id])
    out = with_undo(svc, run)
    out["lot"] = made.get("lot")                                    # which stack it went into (a picture can be attached to it)
    return out


@api("lot.update", mutates=True)
def lot_update(svc, lot, fields):
    v = svc.vault
    mapped = {"company": "grade_company", "paid": "purchase_price", "slabStatus": "slab_status"}
    data = {mapped.get(k, k): val for k, val in fields.items()}
    if data.get("portfolio") == "main":
        data["portfolio"] = ""
    if "graded" in data:
        data["graded"] = 1 if data["graded"] else 0
        if data["graded"]:
            data["condition"] = "Graded"
    return with_undo(svc, lambda: v.update_lot(lot, **data))


@api("lot.moveSome", mutates=True)
def lot_move_some(svc, lot, portfolio, qty):
    """Move some (or all) of a stack of copies to another portfolio.  The moved copies are the same items: they keep their purchase date, price paid and so their whole value history."""
    v = svc.vault
    r = v.get_lot(lot)
    if not r:
        raise ApiError("copy not found")
    to = "" if portfolio == "main" else portfolio
    n = max(1, int(qty))
    if (r["portfolio"] or "") == to:
        return {"moved": 0}
    if n >= r["qty"]:
        return with_undo(svc, lambda: v.update_lot(lot, portfolio=to))
    def run():
        with v.action(f"Moved {n} of {r['qty']} copies"):
            v.update_lot(lot, qty=r["qty"] - n)
            nid = v.add_lot(r["card_id"], r["variant"], r["condition"], n, bool(r["graded"]), r["grade_company"] or "", r["grade"] or "", r["purchase_price"], r["notes"] or "",
                            r["language"] or "English", cert=r["cert"] or "", location=r["location"] or "", edition=r["edition"] or "", purchased=r["purchased"] or "", source=r["source"] or "", portfolio=to, slab_status=r["slab_status"] or "")
            v.conn.execute("UPDATE u.lots SET added=? WHERE id=? AND added > ?", (r["added"], nid, r["added"]))
    return with_undo(svc, run)


@api("lot.qty", mutates=True)
def lot_qty(svc, lot, delta):
    return with_undo(svc, lambda: svc.vault.change_lot_qty(lot, delta))


@api("lot.remove", mutates=True)
def lot_remove(svc, lot):
    return with_undo(svc, lambda: svc.vault.delete_lot(lot))


@api("wish.toggle", mutates=True)
def wish_toggle(svc, id):
    v = svc.vault

    def run():
        v.toggle_wishlist(id)
        if id in v.wishlist_ids():
            v.record_price_history([id])
    return with_undo(svc, run)


@api("bulk.mark", mutates=True)
def bulk_mark(svc, ids, owned):
    v = svc.vault
    todo = [i for i in ids if (svc.owned.get(i, 0) == 0) == bool(owned)]
    n = len(todo)

    def run():
        with v.action(f"{'Marked' if owned else 'Removed'} {n} card{'s' if n != 1 else ''}"):
            v.mark_many(todo, bool(owned))
            if owned:
                v.record_price_history(todo)
        return {"count": n}
    return with_undo(svc, run)


@api("bulk.move", mutates=True)
def bulk_move(svc, ids, portfolio):
    """Move every copy (in the portfolios being looked at) of these cards to another portfolio."""
    from ..db import now_iso
    v = svc.vault
    pid = "" if portfolio in ("main", "", None) else portfolio
    if pid and not any(p["uuid"] == pid for p in v.portfolios()):
        raise ApiError("That portfolio doesn't exist.")
    v.check_accepts(pid, v.item_kind())
    ids = list(dict.fromkeys(ids))
    from .undoext import undoable
    lids = [r[0] for r in v.conn.execute(f"SELECT id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND card_id IN ({','.join('?' * len(ids))})", (v.user_id, v.game, *ids)).fetchall()]

    def run():
        for lid in lids:
            v.conn.execute("UPDATE u.lots SET portfolio=?, placed=1, updated_at=? WHERE id=?", (pid, now_iso(), lid))
        v._commit()
        return {"moved": len(lids)}
    return undoable(svc, f"Moved {len(ids)} card{'s' if len(ids) != 1 else ''} to another portfolio", run, rows=[("lots", lids)])


@api("bulk.qty", mutates=True)
def bulk_qty(svc, ids, delta):
    v = svc.vault
    ids = list(dict.fromkeys(ids))

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {len(ids)} card{'s' if len(ids) != 1 else ''}"):
            for i in ids:
                if delta > 0:
                    v.add_lot(i, v.default_variant(i), "Near Mint", delta)
                else:
                    for _ in range(-delta):
                        v.remove_one(i)
            if delta > 0:
                v.record_price_history(ids)
    return with_undo(svc, run)


@api("bulk.wish", mutates=True)
def bulk_wish(svc, ids):
    v = svc.vault

    def run():
        with v.action(f"Changed the wishlist of {len(ids)} cards"):
            for i in ids:
                v.toggle_wishlist(i)
    return with_undo(svc, run)


@api("card.lists", mutates=True)
def card_lists(svc, id, checklist, member):
    """Add a card to (or take it off) one of your checklists."""
    v = svc.vault
    manual = v.checklist_manual(checklist)
    cl = v.checklist(checklist)

    def run():
        with v.action(f"{'Added' if member else 'Took'} {(v.card_basic(id) or {}).get('name', 'a card')} {'to' if member else 'off'} the checklist '{cl['name'] if cl else ''}'"):
            if member:
                v.set_checklist_card(checklist, id, None if id in manual["excluded"] else "manual")
                if id not in v.checklist_members(checklist):
                    v.set_checklist_card(checklist, id, "manual")
            else:
                v.set_checklist_card(checklist, id, None if id in manual["manual"] else "excluded")
    return with_undo(svc, run)


# ------------------------------------------------------------------------------------------------ undo
@api("undo", mutates=True)
def undo(svc, id):
    if isinstance(id, str) and id.startswith("x:"):                     # a trade that touched several games: undo each game's part
        from . import tradeany
        return tradeany.undo_multi(svc, id)
    from .lotsbulk import undo_labels                                   # (a bulk edit also changed wishlist labels, kept in a setting)
    undo_labels(svc, id)
    n = svc.vault.undo_action(id)
    svc._photos_changed = True                                          # (an undone photo delete has a photo for the account sync to send)
    svc.reload_state()
    return {"ok": True, "reversed": n}


@api("undo.last", mutates=True)
def undo_last(svc):
    r = svc.vault.last_undoable()
    if not r:
        return {"ok": False}
    from .lotsbulk import undo_labels
    undo_labels(svc, r["id"])
    svc.vault.undo_action(r["id"])
    svc._photos_changed = True
    svc.reload_state()
    return {"ok": True, "label": r["label"]}


@api("actions.recent")
def actions_recent(svc, limit=100, offset=0, q=""):
    """Your changes, newest first (the last 1000 are kept): searchable by what they say, and paged with offset."""
    rows = svc.vault.recent_actions(min(int(limit), 500), max(0, int(offset)), q)
    return [{"id": r["id"], "ts": r["ts"], "label": r["label"], "count": r["count"], "undone": bool(r["undone"])} for r in rows]


# ------------------------------------------------------------------------------------------------ master set (every variant of every card)
@api("cards.master")
def master(svc, set_id, graded_only=False, text="", show="all", extended=False, level="", extra_kinds=None, patterns=False, limit=0):
    """A set 'unstacked': one tile per card per variant (normal, reverse holo, holo, 1st edition...), so a master set can be tracked.
    Progress counts every variant; the base size of the set is reported next to it.
    `limit`: only the first N tiles are filled in (price, picture) and sent - the screen shows them at once and asks for the rest straight after.  The counts always cover
    the whole set; `count` says how many tiles there are in all.  (A 5,565-card Magic set sent 1.8 MB and took ~0.9 s in the browser before its first tile could show.)"""
    v = svc.vault
    s = next((x for x in v.sets() if x["id"] == set_id), None)
    if not s:
        raise ApiError("set not found")
    have = {}
    for cid, var, q, gq, gr in v.conn.execute(
            "SELECT l.card_id, l.variant, SUM(l.qty), SUM(CASE WHEN l.graded=1 THEN l.qty ELSE 0 END), "
            "GROUP_CONCAT(CASE WHEN l.graded=1 THEN l.grade_company||' '||l.grade END, ', ') "
            "FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE c.set_id=? AND l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY l.card_id, l.variant",
            (set_id, v.user_id, v.game)):
        have[(cid, var)] = (q, gq, gr or "")
    from .setanalytics import _excluded
    excl = _excluded(v, set_id)                       # cards the person chose to leave out of this master set
    oc = v.owned_conditions()
    rows, owned_n, total_n, groups = [], 0, 0, {}
    std_total = std_owned = 0
    from .. import completion, setgoals
    level = level if level in completion.GOALS else (setgoals.load(v).get(set_id) or ("extended" if extended else "master"))     # (no level asked: the goal picked for this set)
    level = completion.clamp(level, svc.game, "standard")
    tl = (text or "").strip().lower()
    for r in v.conn.execute("SELECT id, name, local_id, price_usd, price_kind, rarity, variants, tcg_id, variant_prices FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,)):
        try:
            flags = clean_flags(json.loads(r["variants"] or "{}"), r["rarity"])
        except ValueError:
            flags = {}
        labels = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)] or ["Normal"]
        left = r["id"] in excl
        g = groups.setdefault(r["rarity"] or "Unlabelled", {"rarity": r["rarity"] or "Unlabelled", "n": 0, "left": 0})
        g["n"] += 1
        g["left"] += 1 if left else 0
        per = []                                                          # (label, copies counted, graded copies, grades) for every version of this card
        for lab in labels:
            q, gq, gr = have.get((r["id"], lab), (0, 0, ""))
            per.append((lab, gq if graded_only else q, gq, gr))
        if not left:
            std_total += 1
            std_owned += 1 if any(c > 0 for _, c, _, _ in per) else 0
            for _lab, c, _gq, _gr in per:
                total_n += 1
                owned_n += 1 if c > 0 else 0
        if left != (show == "left"):
            continue                                              # left-out cards only show under "Left out"; everything else hides them
        if tl and tl not in (r["name"] or "").lower() and tl not in str(r["local_id"]).lower():
            continue
        if level == "standard":                                   # the plain set: one tile per card, owned in whichever version you have
            owned_any = [x for x in per if x[1] > 0]
            pick = owned_any[0] if owned_any else per[0]
            shown = [(pick[0], sum(x[1] for x in per), sum(x[2] for x in per), pick[3])]
        else:
            shown = per
        for lab, counted, gq, gr in shown:
            if show == "owned" and counted == 0 or show == "missing" and counted > 0:
                continue
            rows.append((r, lab, counted, gq, gr, left))                   # (filled in below - only the tiles that are sent)
    extras, ext_total, ext_owned, kinds_seen = [], 0, 0, {}
    try:                                                                   # the EXTENDED master set: stamped, Cosmos Holo, staff and pre-release promos that name this set
        from .masterextra import PATTERNS, extras_for_set, group_of, GROUPS
        extras = extras_for_set(svc, s)
    except Exception:  # noqa: BLE001 - a game without promo sets simply has none
        extras, GROUPS, PATTERNS = [], (), "patterns"

        def group_of(_lab):
            return "other"
    for _cid, _nm, _no, lab in extras:
        kinds_seen[group_of(lab)] = kinds_seen.get(group_of(lab), 0) + 1
    want = set(extra_kinds) if extra_kinds else {g for g, _t in GROUPS} | {"other"}
    want.discard(PATTERNS)
    if patterns:                                                         # the separate checkmark: pattern printings count only when it is ticked
        want.add(PATTERNS)
    for cid, nm, no, lab in extras:
        if group_of(lab) not in want:
            continue
        q = svc.owned.get(cid, 0)
        ext_total += 1
        ext_owned += 1 if q > 0 else 0
        if level != "extended" or show == "left" or (tl and tl not in (nm or "").lower()) or (show == "owned" and q == 0) or (show == "missing" and q > 0):
            continue
        rows.append((None, (cid, nm, no, lab), q))

    def tile(x):
        if x[0] is None:                                                   # an extra card of the extended set
            (cid, nm, no, lab), q = x[1], x[2]
            c = v.card_light(cid) or {}
            return {"key": f"{cid}|extra", "id": cid, "name": fix_text(nm), "number": no, "variant": v.default_variant(cid), "qty": q, "graded": 0, "cond": "", "grades": "", "tcg": c.get("tcg_id") or "",
                    "price": c.get("price_usd"), "priceKind": "", "left": False, "img": img(cid, c.get("set_id") or ""), "extra": lab}
        r, lab, counted, gq, gr, left = x
        price, own = _vp(r, lab)
        return {"key": f"{r['id']}|{lab}", "id": r["id"], "name": fix_text(r["name"]), "number": r["local_id"], "variant": lab, "qty": counted, "graded": gq,
                "cond": (oc.get(r["id"]) or {}).get(lab, ""), "grades": gr, "tcg": r["tcg_id"] or "", "price": price, "priceKind": "" if own else (r["price_kind"] or ""), "left": left, "img": img(r["id"], set_id)}
    count = len(rows)
    lim = max(0, int(limit or 0))
    rows = [tile(x) for x in (rows[:lim] if lim else rows)]
    tiers = {"standard": {"owned": std_owned, "total": std_total}, "master": {"owned": owned_n, "total": total_n}, "extended": {"owned": owned_n + ext_owned, "total": total_n + ext_total}}
    for t in tiers.values():
        t["pct"] = (100.0 * t["owned"] / t["total"]) if t["total"] else 0.0
    cur = tiers[level]
    owned_n, total_n = cur["owned"], cur["total"]
    official = s["official"] or s["total"] or 0
    pricepick.patch(v, rows)
    return {"rows": rows, "count": count, "more": count > len(rows), "extrasCount": len(extras), "patternsN": kinds_seen.get(PATTERNS, 0), "extraKinds": [{"id": g, "name": t, "n": kinds_seen.get(g, 0)} for g, t in (*GROUPS, ("other", "Other promos")) if kinds_seen.get(g)], "level": level, "goals": list(completion.allowed(svc.game)), "tiers": tiers,
            "title": s["name"], "owned": owned_n, "total": total_n, "leftOut": len(excl), "groups": sorted(groups.values(), key=lambda g: -g["n"]), "base": {"official": official, "listed": s["n"] if "n" in s.keys() else count},
            "pct": (100.0 * owned_n / total_n) if total_n else 0.0}
