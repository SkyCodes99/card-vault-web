"""Cards: set / category / illustrator / Pokémon boxes, card lists, one card's details and every way of changing what you own."""
import json
import urllib.parse

from .. import checklists, runtime, taxonomy
from ..db import CONDITIONS, GRADERS, VARIANT_FLAGS, VARIANT_LABELS, fix_text
from .registry import api
from .service import ApiError

MAX_SECTION_CARDS = 4000
GENERATIONS = [("", "All generations"), ("1-151", "Gen I · #1–151"), ("152-251", "Gen II · #152–251"), ("252-386", "Gen III · #252–386"),
               ("387-493", "Gen IV · #387–493"), ("494-649", "Gen V · #494–649"), ("650-721", "Gen VI · #650–721"), ("722-809", "Gen VII · #722–809"),
               ("810-905", "Gen VIII · #810–905"), ("906-1025", "Gen IX · #906–1025")]
LANGUAGES = ["English", "Japanese", "Korean", "Chinese", "German", "French", "Italian", "Spanish", "Portuguese", "Other"]
EDITIONS = ["", "1st Edition", "Shadowless", "Unlimited", "Stamped", "Prerelease", "Staff", "Promo", "Error / misprint", "Other"]
GRADES = ["10", "9.5", "9", "8.5", "8", "7.5", "7", "6.5", "6", "5.5", "5", "4.5", "4", "3.5", "3", "2.5", "2", "1.5", "1", "Authentic", "Altered"]


def q(s):
    return urllib.parse.quote(str(s), safe="")


def img(cid, set_id, quality=""):
    if runtime.REMOTE_IMAGES and runtime.service is not None:
        url = runtime.service.remote_image(cid, quality or "low")
        if url:
            return url
    return f"/img?c={q(cid)}&s={q(set_id)}" + (f"&q={quality}" if quality else "")


def group_section(g):
    if g.id in ("art", "ir", "sir", "gallery", "tg", "gg", "art_alt", "altart"):
        return "art"
    return g.parent or "art"


def lot_dict(l):
    return {"id": l["id"], "variant": l["variant"], "condition": l["condition"], "language": l["language"], "qty": l["qty"], "graded": bool(l["graded"]),
            "company": l["grade_company"] or "", "grade": l["grade"] or "", "cert": l["cert"] or "", "paid": l["purchase_price"], "notes": l["notes"] or "",
            "location": l["location"] or "", "edition": l["edition"] or ""}


def with_undo(svc, fn):
    """Run a change, reload the shared state and say how to undo it."""
    v = svc.vault
    before = v.conn.execute("SELECT COALESCE(MAX(id),0) FROM u.actions").fetchone()[0]
    out = fn()
    svc.reload_state()
    last = v.last_undoable()
    undo = {"id": last["id"], "label": last["label"]} if last and last["id"] > before else None
    return {"ok": True, "undo": undo, **(out if isinstance(out, dict) else {})}


# ------------------------------------------------------------------------------------------------ boxes
@api("cards.overview")
def overview(svc, mode="sets", edition=None, era="", q="", status="all", sort=None):
    v, g = svc.vault, svc.game
    q = (q or "").strip().lower()
    owned_map = svc.owned
    boxes = []
    eras = []
    sort = sort or ("new" if mode == "sets" else "name")

    def ok(o, n):
        return (0 < o < n) if status == "progress" else (bool(n) and o >= n) if status == "complete" else (o == 0) if status == "none" else True

    if mode == "sets":
        seen = []
        for s in v.sets(edition):
            if s["serie"] and s["serie"] not in seen:
                seen.append(s["serie"])
        eras = [{"key": "", "label": "All series / eras"}] + [{"key": n, "label": n} for n in seen]
        owned = v.owned_by_set()
        items = []
        for s in v.sets(edition):
            if era and s["serie"] != era:
                continue
            if q and q not in s["name"].lower() and q not in s["id"].lower():
                continue
            o, n = owned.get(s["id"], 0), s["n"] or 0
            if not ok(o, n):
                continue
            year = (s["release_date"] or "")[:4]
            items.append((s, {"key": s["id"], "kind": "set", "title": s["name"], "sub": f"{s['serie'] or ''}{' · ' + year if year else ''}", "owned": o, "total": n,
                              "logo": svc.logo_url(s["id"], s), "symbol": svc.symbol_url(s["id"])}))
        key = {"old": lambda t: (t[0]["release_date"] or "", t[0]["name"]), "name": lambda t: t[0]["name"].lower(), "most": lambda t: -frac(t[1]),
               "least": lambda t: frac(t[1]), "big": lambda t: -t[1]["total"]}.get(sort)
        if key:
            items.sort(key=key)
        boxes = [b for _, b in items]
    elif mode == "cats":
        eras = [{"key": "all", "label": "All kinds of cards"}] + [{"key": sec, "label": title or taxonomy.LABEL.get(sec, sec)} for sec, title in taxonomy.SECTIONS]
        counts = v.group_counts(edition)
        section = era or "all"
        for gr in taxonomy.groups():
            sec = group_section(gr)
            if section != "all" and sec != section:
                continue
            if q and q not in gr.label.lower():
                continue
            o, n = counts.get(gr.id, (0, 0))
            if not ok(o, n):
                continue
            title = dict(taxonomy.SECTIONS).get(sec) or taxonomy.LABEL.get(sec, sec)
            boxes.append({"key": gr.id, "kind": "group", "title": gr.label, "sub": "Art cards" if sec == "art" else (title or ""), "owned": o, "total": n})
    elif mode == "ill":
        for name, ids in v.facets(edition)["illustrator"].items():
            if q and q not in name.lower():
                continue
            o = sum(1 for i in ids if owned_map.get(i, 0) > 0)
            if ok(o, len(ids)):
                boxes.append({"key": name, "kind": "illustrator", "title": name, "sub": f"{len(ids):,} card{'s' if len(ids) != 1 else ''}", "owned": o, "total": len(ids)})
    else:
        eras = [{"key": k, "label": t} for k, t in GENERATIONS]
        names = checklists.dex_names(v)
        lo, hi = (int(x) for x in (era or "1-1025").split("-"))
        for d, ids in v.facets(edition)["dex"].items():
            if not lo <= d <= hi:
                continue
            title = f"#{d:04d} {names.get(d, '?')}"
            if q and q not in title.lower():
                continue
            o = sum(1 for i in ids if owned_map.get(i, 0) > 0)
            if ok(o, len(ids)):
                boxes.append({"key": str(d), "kind": "pokemon", "title": title, "sub": f"{len(ids):,} card{'s' if len(ids) != 1 else ''}", "owned": o, "total": len(ids)})
    if mode != "sets":
        key = {"name": lambda b: b["title"].lower(), "big": lambda b: -b["total"], "most": lambda b: -frac(b), "least": frac}.get(sort)
        if key:
            boxes.sort(key=key)
        elif mode == "mon":
            boxes.sort(key=lambda b: int(b["key"]))
    with_logos = sum(1 for b in boxes if b.get("logo"))
    return {"boxes": boxes, "eras": eras, "needArt": bool(mode == "sets" and g.pokemon and boxes and with_logos < 0.3 * len(boxes) and not q and not era)}


def q_(s):
    return urllib.parse.quote(str(s), safe="")


def frac(b):
    return (b["owned"] / b["total"]) if b["total"] else 0


# ------------------------------------------------------------------------------------------------ one scope's cards
def scope_ids(v, kind, val, edition):
    if kind == "group":
        return v.group_ids(val, edition)
    if kind == "illustrator":
        return v.facets(edition)["illustrator"].get(val, [])
    if kind == "pokemon":
        return v.facets(edition)["dex"].get(int(val), [])
    return None


@api("cards.filters")
def filters(svc):
    v, g = svc.vault, svc.game
    return {"types": v.distinct("types"), "rarities": v.distinct("rarity"), "typeLabel": g.type_label}


@api("cards.list")
def cards_list(svc, kind="all", val=None, edition=None, text="", show="all", ctype="", rarity="", sort="default", split=False, limit=1500):
    v = svc.vault
    ids = scope_ids(v, kind, val, edition)
    raw = v.query_cards(set_id=val if kind == "set" else None, text=(text or "").strip(), show=show, ctype=ctype or None, rarity=rarity or None,
                        sort=sort, only_ids=ids, edition=edition)
    names = {s["id"]: s["name"] for s in v.sets()}
    owned, wish = svc.owned, svc.wishlist
    rows = []
    for cid, name, set_id, local_id in raw:
        light = v.card_light(cid) or {}
        qn = owned.get(cid, 0)
        rows.append({"id": cid, "name": fix_text(name), "setId": set_id, "set": names.get(set_id, set_id), "number": local_id, "qty": qn, "wish": cid in wish,
                     "price": light.get("price_usd"), "rarity": light.get("rarity") or "", "img": img(cid, set_id)})
    n_all, n_owned = len(rows), sum(1 for r in rows if r["qty"] > 0)
    out = {"rows": rows if split else rows[:limit], "total": n_all, "owned": n_owned, "sections": None}
    if split:
        if len(rows) > MAX_SECTION_CARDS:
            out["splitRefused"] = True
        else:
            by = {}
            for r in rows:
                by.setdefault(r["rarity"] or "Unlabelled", []).append(r["id"])
            out["sections"] = [{"title": t, "ids": by[t]} for t in sorted(by, key=lambda x: (taxonomy.rarity_rank(x), x))]
    if kind != "all":
        if kind == "set":
            prog = checklists.progress_for_set(v, val)
        else:
            prog = checklists.progress_for_cards(v, ids or [])
        out["progress"] = {"owned": prog.owned, "total": prog.total, "pct": prog.pct}
        out["title"] = names.get(val, val) if kind == "set" else taxonomy.LABEL.get(val, val) if kind == "group" else \
            (f"#{int(val):04d} {checklists.dex_names(v).get(int(val), '?')}" if kind == "pokemon" else val)
    return out


# ------------------------------------------------------------------------------------------------ one card
@api("card.detail")
def detail(svc, id):
    v, g = svc.vault, svc.game
    c = v.card(id)
    if not c:
        raise ApiError("card not found")
    raw = {}
    try:
        raw = json.loads(c["raw"] or "{}")
    except ValueError:
        pass
    t = lambda s: fix_text(s) if s else ""
    light = v.card_light(id) or {}
    labels = [taxonomy.LABEL[x] for x in light.get("groups", []) if x in taxonomy.LABEL]
    number = f"{c['local_id']}/{c['set_official']}" if (c["set_official"] and g.pokemon) else c["local_id"]
    flags = {}
    try:
        flags = json.loads(c["variants"] or "{}")
    except ValueError:
        pass
    variants = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)] or ["Normal"]
    facts = []
    if g.pokemon:
        for lab, key in (("Type", "types"), ("Stage", "stage"), ("Illustrator", "illustrator")):
            if c[key]:
                facts.append([lab, t(c[key])])
        if c["hp"]:
            facts.append(["HP", str(c["hp"])])
        if c["evolve_from"]:
            facts.append(["Evolves from", t(c["evolve_from"])])
        if c["dex"]:
            facts.append(["Pokédex", "#" + c["dex"].replace(",", ", #")])
    else:
        ext = raw.get("ext", {})
        facts = [[k, t(str(ext[k]).replace(";", ", "))] for k in ext if k not in ("Description", "Number") and ext[k] not in ("", None)]
    blocks = []
    for ab in raw.get("abilities") or []:
        blocks.append({"title": f"{t(ab.get('type', 'Ability'))}: {t(ab.get('name'))}", "text": t(ab.get("effect"))})
    for at in raw.get("attacks") or []:
        blocks.append({"title": f"{t(at.get('name'))} {at.get('damage', '')}".strip(), "cost": " ".join(at.get("cost") or []), "text": t(at.get("effect"))})
    if raw.get("effect"):
        blocks.append({"title": "", "text": t(raw["effect"])})
    extras = []
    for lab, key in (("Weakness", "weaknesses"), ("Resistance", "resistances")):
        if raw.get(key):
            extras.append([lab, ", ".join(f"{x.get('type')} {t(x.get('value', ''))}" for x in raw[key])])
    if raw.get("retreat") is not None:
        extras.append(["Retreat", str(raw["retreat"])])
    hist = [{"day": d, "usd": usd} for d, usd, _ in v.price_history(id) if usd is not None]
    lots = [lot_dict(l) for l in v.lots_for(id)]
    return {
        "id": id, "name": t(c["name"]), "setId": c["set_id"], "set": c["set_name"] or c["set_id"], "number": number, "rarity": c["rarity"] or "",
        "img": img(id, c["set_id"]), "imgHigh": img(id, c["set_id"], "high"), "kinds": labels, "facts": facts, "blocks": blocks, "extras": extras,
        "description": t(c["description"]), "priceUsd": c["price_usd"], "priceEur": c["price_eur"], "priceUpdated": c["price_updated"], "history": hist,
        "lots": lots, "qty": sum(l["qty"] for l in lots), "wish": id in svc.wishlist, "variants": variants + ["Other"],
        "lists": [{"id": cl["id"], "name": cl["name"], "member": id in set(v.checklist_members(cl["id"]))} for cl in v.checklists()],
        "options": {"conditions": CONDITIONS, "graders": GRADERS, "grades": GRADES, "languages": LANGUAGES, "editions": EDITIONS,
                    "locations": __import__("cardvault.tools", fromlist=["x"]).known_locations(v)},
    }


# ------------------------------------------------------------------------------------------------ changing what you own
@api("own.toggle", mutates=True)
def own_toggle(svc, id, variant=""):
    v = svc.vault
    lots = v.lots_for(id)
    name = (v.card_light(id) or {}).get("name", id)
    owned = bool([l for l in lots if (not variant or l["variant"] == variant)])

    def run():
        with v.action(f"{'Removed' if owned else 'Marked'} {name}{' as owned' if not owned else ''}"):
            if owned:
                (v.set_variant_owned(id, variant, False) if variant else v.set_owned(id, False))
            else:
                (v.set_variant_owned(id, variant, True) if variant else v.set_owned(id, True))
                v.record_price_history([id])
    return with_undo(svc, run)


@api("own.needsConfirm")
def needs_confirm(svc, id, variant=""):
    v = svc.vault
    if variant:
        lots = [l for l in v.lots_for(id) if l["variant"] == variant]
        heavy = any(l["qty"] > 1 or l["graded"] or l["purchase_price"] is not None or l["notes"] for l in lots)
        n = sum(l["qty"] for l in lots)
    else:
        heavy = v.needs_remove_confirmation(id)
        n = sum(l["qty"] for l in v.lots_for(id))
    return {"confirm": heavy and n > 0, "copies": n}


@api("qty.adjust", mutates=True)
def qty_adjust(svc, id, delta):
    v = svc.vault
    name = (v.card_light(id) or {}).get("name", id)

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {name}"):
            if delta > 0:
                v.add_lot(id, v.default_variant(id), "Near Mint", delta)
                v.record_price_history([id])
            else:
                for _ in range(-delta):
                    v.remove_one(id)
    return with_undo(svc, run)


@api("lot.add", mutates=True)
def lot_add(svc, id, variant="Normal", condition="Near Mint", qty=1, graded=False, company="", grade="", paid=None, notes="", language="English",
            cert="", location="", edition=""):
    v = svc.vault

    def run():
        with v.action("Added a copy"):
            v.add_lot(id, variant, "Graded" if graded else condition, int(qty), bool(graded), company if graded else "", grade if graded else "",
                      paid, notes, language, cert=cert if graded else "", location=location, edition=edition)
            v.record_price_history([id])
    return with_undo(svc, run)


@api("lot.update", mutates=True)
def lot_update(svc, lot, fields):
    v = svc.vault
    mapped = {"company": "grade_company", "paid": "purchase_price"}
    data = {mapped.get(k, k): val for k, val in fields.items()}
    if "graded" in data:
        data["graded"] = 1 if data["graded"] else 0
        if data["graded"]:
            data["condition"] = "Graded"
    return with_undo(svc, lambda: v.update_lot(lot, **data))


@api("lot.qty", mutates=True)
def lot_qty(svc, lot, delta):
    return with_undo(svc, lambda: svc.vault.change_lot_qty(lot, delta))


@api("lot.remove", mutates=True)
def lot_remove(svc, lot):
    return with_undo(svc, lambda: svc.vault.delete_lot(lot))


@api("wish.toggle", mutates=True)
def wish_toggle(svc, id):
    v = svc.vault

    def run():
        v.toggle_wishlist(id)
        if id in v.wishlist_ids():
            v.record_price_history([id])
    return with_undo(svc, run)


@api("bulk.mark", mutates=True)
def bulk_mark(svc, ids, owned):
    v = svc.vault
    todo = [i for i in ids if (svc.owned.get(i, 0) == 0) == bool(owned)]
    n = len(todo)

    def run():
        with v.action(f"{'Marked' if owned else 'Removed'} {n} card{'s' if n != 1 else ''}"):
            v.mark_many(todo, bool(owned))
            if owned:
                v.record_price_history(todo)
        return {"count": n}
    return with_undo(svc, run)


@api("bulk.edit", mutates=True)
def bulk_edit(svc, ids, fields):
    v = svc.vault
    have = [i for i in dict.fromkeys(ids) if svc.owned.get(i, 0) > 0]
    mapped = {"company": "grade_company"}
    data = {mapped.get(k, k): val for k, val in fields.items()}
    return with_undo(svc, lambda: {"count": v.bulk_update_lots(have, **data)} if have and data else {"count": 0})


@api("bulk.qty", mutates=True)
def bulk_qty(svc, ids, delta):
    v = svc.vault
    ids = list(dict.fromkeys(ids))

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {len(ids)} card{'s' if len(ids) != 1 else ''}"):
            for i in ids:
                if delta > 0:
                    v.add_lot(i, v.default_variant(i), "Near Mint", delta)
                else:
                    for _ in range(-delta):
                        v.remove_one(i)
            if delta > 0:
                v.record_price_history(ids)
    return with_undo(svc, run)


@api("bulk.wish", mutates=True)
def bulk_wish(svc, ids):
    v = svc.vault

    def run():
        with v.action(f"Changed the wishlist of {len(ids)} cards"):
            for i in ids:
                v.toggle_wishlist(i)
    return with_undo(svc, run)


@api("card.lists", mutates=True)
def card_lists(svc, id, checklist, member):
    """Add a card to (or take it off) one of your checklists."""
    v = svc.vault
    manual = v.checklist_manual(checklist)
    if member:
        v.set_checklist_card(checklist, id, None if id in manual["excluded"] else "manual")
        if id not in v.checklist_members(checklist):
            v.set_checklist_card(checklist, id, "manual")
    else:
        v.set_checklist_card(checklist, id, None if id in manual["manual"] else "excluded")
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ undo
@api("undo", mutates=True)
def undo(svc, id):
    n = svc.vault.undo_action(id)
    svc.reload_state()
    return {"ok": True, "reversed": n}


@api("undo.last", mutates=True)
def undo_last(svc):
    r = svc.vault.last_undoable()
    if not r:
        return {"ok": False}
    svc.vault.undo_action(r["id"])
    svc.reload_state()
    return {"ok": True, "label": r["label"]}


@api("actions.recent")
def actions_recent(svc, limit=100):
    return [{"id": r["id"], "ts": r["ts"], "label": r["label"], "count": r["count"], "undone": bool(r["undone"])} for r in svc.vault.recent_actions(limit)]
