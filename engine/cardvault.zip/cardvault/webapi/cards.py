"""Cards: set / category / illustrator / Pokémon boxes, card lists, one card's details and every way of changing what you own."""
import json
import urllib.parse

from .. import checklists, gamefacets, runtime, taxonomy
from ..db import CONDITIONS, GRADERS, VARIANT_FLAGS, VARIANT_LABELS, clean_flags, fix_text
from .registry import api
from .service import ApiError

MAX_SECTION_CARDS = 4000
GENERATIONS = [("", "All generations"), ("1-151", "Gen I · #1–151"), ("152-251", "Gen II · #152–251"), ("252-386", "Gen III · #252–386"),
               ("387-493", "Gen IV · #387–493"), ("494-649", "Gen V · #494–649"), ("650-721", "Gen VI · #650–721"), ("722-809", "Gen VII · #722–809"),
               ("810-905", "Gen VIII · #810–905"), ("906-1025", "Gen IX · #906–1025")]
LANGUAGES = ["English", "Japanese", "Korean", "Chinese", "German", "French", "Italian", "Spanish", "Portuguese", "Other"]
EDITIONS = ["", "1st Edition", "Shadowless", "Unlimited", "Stamped", "Prerelease", "Staff", "Promo", "Error / misprint", "Other"]
GRADES = ["10", "9.5", "9", "8.5", "8", "7.5", "7", "6.5", "6", "5.5", "5", "4.5", "4", "3.5", "3", "2.5", "2", "1.5", "1", "Authentic", "Altered"]


def q(s):
    return urllib.parse.quote(str(s), safe="")


def img(cid, set_id, quality=""):
    svc = getattr(runtime.thread, "svc", None) or runtime.service
    if svc is not None:
        if runtime.REMOTE_IMAGES:
            url = svc.remote_image(cid, quality or "low")
            if url:
                return url
        if not svc.has_picture_source(cid, set_id):
            return ""                                                  # no picture exists for it: nothing to ask for (the screen shows its placeholder)
    return f"/img?c={q(cid)}&s={q(set_id)}" + (f"&q={quality}" if quality else "")


def _sale(svc, cid):
    """Sale Data for the card panel: the recent typical price from our saved price history (None when it is switched off or has no data yet)."""
    from . import trendapi
    from .. import trend
    if trendapi.mode(svc) == "standard":
        return None
    t = trend.for_vault(svc)
    i = t.info(cid)
    return {**(i or {}), "have": bool(i), "daysSaved": t.days}


def _no_price_why(svc, c):
    """Why a card shows no price (shown instead of a bare 'no price'; never a made-up number)."""
    sname = (c["set_name"] or "") if "set_name" in c.keys() else ""
    if "pocket" in sname.lower() or str(c["set_id"] or "").startswith(("A1", "A2", "A3", "A4", "B1", "P-A")):
        return "This is a digital (TCG Pocket) card, so it has no market price."
    if svc.game.id in ("onepiece", "unionarena", "yugioh", "dbs"):
        return "It is on TCGplayer but has no price yet - no recent sales."
    return "No TCGplayer price has been found for this card yet."


def lot_dict(l):
    return {"id": l["id"], "variant": l["variant"], "condition": l["condition"], "language": l["language"], "qty": l["qty"], "graded": bool(l["graded"]),
            "company": l["grade_company"] or "", "grade": l["grade"] or "", "cert": l["cert"] or "", "paid": l["purchase_price"], "notes": l["notes"] or "",
            "location": l["location"] or "", "edition": l["edition"] or "", "purchased": l["purchased"] or "", "added": (l["added"] or "")[:10], "source": l["source"] or "",
            "portfolio": l["portfolio"] or "main"}


def _vp(r, lab):
    """(price of this printing, whether it is that printing's own price)"""
    from .. import variantprice
    return variantprice.price_for({"variant_prices": r["variant_prices"], "variants": r["variants"], "price_usd": r["price_usd"]}, lab)


def _target_name(svc):
    """The name of the portfolio new cards are being added to (shown whenever something is marked, so it is always clear where it went)."""
    from .complete import pf_name
    return pf_name(svc, svc.vault.target_pf)


def with_undo(svc, fn):
    """Run a change, reload the shared state and say how to undo it."""
    v = svc.vault
    before = v.conn.execute("SELECT COALESCE(MAX(id),0) FROM u.actions").fetchone()[0]
    out = fn()
    svc.reload_state()
    last = v.last_undoable()
    undo = {"id": last["id"], "label": last["label"]} if last and last["id"] > before else None
    return {"ok": True, "undo": undo, **(out if isinstance(out, dict) else {})}


def q_(s):
    return urllib.parse.quote(str(s), safe="")


# ------------------------------------------------------------------------------------------------ one scope's cards
def scope_ids(v, kind, val, edition):
    if kind == "group":
        return v.group_ids(val, edition)
    if kind == "illustrator":
        return v.facets(edition)["illustrator"].get(val, [])
    if kind == "pokemon":
        return v.facets(edition)["dex"].get(int(val), [])
    return None


@api("cards.filters")
def filters(svc):
    v, g = svc.vault, svc.game
    ck = v.catalog_fp()                                       # the filters come from the card list alone: they are worked out again only when that changes (not at every change to your collection)
    hit = getattr(v, "_filters_cache", None)
    if hit and ck is not None and hit[0] == ck:
        return hit[1]
    out = _filters(svc, v, g)
    v._filters_cache = (ck, out)
    return out


def _pokemon_eras(v, g):
    """The eras in order, each with how many cards it has (Pokémon only)."""
    if not g.pokemon:
        return []
    groups = (grp for grp in taxonomy.groups() if grp.parent == "era")
    return [{"id": grp.id, "label": grp.label, "n": n} for grp in groups if (n := len(v.group_ids(grp.id)))]


def _sort_choices(v, g, basics):
    """The orders the list can be sorted in - only the ones that mean something for THIS game (no price order for a list without prices, no illustrator order where there are no illustrators ...)."""
    voc = gamefacets.vocab(g.id)
    numbered = bool(v.conn.execute("SELECT 1 FROM cards WHERE local_id IS NOT NULL AND local_id NOT IN ('', '0') LIMIT 1").fetchone())
    sorts = [["default", "Newest to oldest"], ["oldest", "Oldest to newest"]]
    if basics["hasPrices"]:
        sorts += [["price", "Highest price first"], ["priceasc", "Lowest price first"]]
    sorts += [["owned", "Owned first"], ["unowned", "Not owned first"], ["name", "Name A–Z"], ["namez", "Name Z–A"]]
    if numbered:
        sorts.append(["numasc", f"{voc['setLabelOne']}, then {voc['nounOne']} number"])
    sorts.append(["set", f"{voc['setLabelOne']} name A–Z"])
    if len(basics["rarities"]) > 1:
        sorts.append(["rarity", f"{voc['rarityLabel']} A–Z"])
    if basics["hasArtist"]:
        sorts.append(["artist", "Illustrator A–Z"])
    if g.pokemon:
        sorts.append(["dex", "Pokédex number"])
    return sorts


def _filters(svc, v, g):
    basics = gamefacets.basics(v.conn, g.id)                      # which filters make sense for this game: a filter with nothing to choose from is not shown
    try:
        facets = gamefacets.filters(v.conn, g.id)                 # the game's own (see gamefacets): card kind, attribute, trait, special printing... / product type, availability, edition...
    except Exception:  # noqa: BLE001 - a list without them still has its other filters
        facets = []
    return {"facets": facets, "types": basics["types"], "rarities": basics["rarities"], "typeLabel": g.type_label, "eras": _pokemon_eras(v, g), "hasArtist": basics["hasArtist"],
            "hasDates": basics["hasDates"], "hasPrices": basics["hasPrices"], "sorts": _sort_choices(v, g, basics), "voc": gamefacets.vocab(g.id)}


@api("cards.list")
def cards_list(svc, kind="all", val=None, edition=None, text="", show="all", ctype="", rarity="", sort="default", split=False, limit=1500, era="",
               price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None, priced="", letter="", facets=None, _t=None):
    v = svc.vault
    g_pokemon = svc.game.pokemon
    ids = scope_ids(v, kind, val, edition)
    raw = v.query_cards(set_id=val if kind == "set" else None, text=(text or "").strip(), show=show, ctype=ctype or None, rarity=rarity or None,
                        sort=sort, only_ids=ids, edition=edition, price_min=None if price_min in (None, "") else price_min, price_max=None if price_max in (None, "") else price_max,
                        set_text=set_text or "", artist=artist or "", year_min=year_min, year_max=year_max, priced=priced or "", letter=letter or "")
    if era:                                                       # only the cards of one era (Original 1999-2003, XY, Sword & Shield ...)
        in_era = set(v.group_ids(era))
        raw = [r for r in raw if r[0] in in_era]
    if isinstance(facets, dict) and facets:                       # the game's own filters: every chosen filter must match, any of its chosen values will do
        want = {str(k): [str(x) for x in vals] for k, vals in facets.items() if isinstance(vals, (list, tuple)) and vals}
        gamefacets.ensure(v.conn, svc.game.id)                    # (read straight from the card list's own filter table - not from the card index, which a game that has just been opened may not have yet)
        keep = None
        for k, vals in want.items():
            marks = ",".join("?" * len(vals))
            if k == "category":
                cur = {r[0] for r in v.conn.execute(f"SELECT id FROM cards WHERE category IN ({marks})", vals)}
            else:
                cur = {r[0] for r in v.conn.execute(f"SELECT card_id FROM card_facets WHERE facet=? AND value IN ({marks})", [k, *vals])}
            keep = cur if keep is None else keep & cur
        raw = [r for r in raw if r[0] in keep] if keep is not None else raw
    names = {s["id"]: s["name"] for s in v.sets()}
    owned, wish = svc.owned, svc.wishlist
    left_n = 0
    if kind == "set":                                   # cards the person left out of this set (they stay out of the list, the totals and the progress; "Left out" shows them)
        from .setanalytics import _excluded
        excl = _excluded(v, val)
        left_n = len(excl)
        raw = [r for r in raw if (r[0] in excl) == (show == "left")]
    rows = []
    oc = v.owned_conditions()
    n_all, n_owned = len(raw), sum(1 for r in raw if owned.get(r[0], 0) > 0)       # the counts come from the ids alone; only the cards that are shown get their full row (a 100,000-card game stays quick)
    for cid, name, set_id, local_id in (raw if split else raw[:limit]):
        light = v.card_light(cid) or {}
        qn = owned.get(cid, 0)
        rows.append({"id": cid, "name": fix_text(name), "setId": set_id, "set": names.get(set_id, set_id), "number": local_id, "qty": qn, "wish": cid in wish,
                     "cond": "/".join(dict.fromkeys(x for x in (oc.get(cid) or {}).values() if x)),
                     "price": light.get("price_usd"), "tcg": light.get("tcg_id") or "", "priceKind": light.get("price_kind") or "", "digital": "pocket" in (light.get("serie") or "").lower(), "rarity": light.get("rarity") or "", "img": img(cid, set_id)})
    from . import trendapi
    trendapi.attach(svc, rows if split else rows[:limit])
    out = {"rows": rows if split else rows[:limit], "total": n_all, "owned": n_owned, "sections": None, "leftOut": left_n}
    if split:
        if len(rows) > MAX_SECTION_CARDS:
            out["splitRefused"] = True
        else:
            by = {}
            for r in rows:
                light = v.card_light(r["id"]) or {}
                lab = taxonomy.card_rarity_label(light, light.get("groups")) if (g_pokemon and light) else (r["rarity"] or "Unlabelled")
                by.setdefault(lab, []).append(r["id"])
            rank = taxonomy.label_rank if g_pokemon else taxonomy.rarity_rank
            out["sections"] = [{"title": t, "ids": by[t]} for t in sorted(by, key=lambda x: (rank(x), x))]
    if kind != "all":
        if kind == "set":
            prog = checklists.progress_for_set(v, val)
        else:
            prog = checklists.progress_for_cards(v, ids or [])
        out["progress"] = {"owned": prog.owned, "total": prog.total, "pct": prog.pct}
        out["title"] = names.get(val, val) if kind == "set" else taxonomy.LABEL.get(val, val) if kind == "group" else \
            (f"#{int(val):04d} {checklists.dex_names(v).get(int(val), '?')}" if kind == "pokemon" else val)
    return out


# ------------------------------------------------------------------------------------------------ one card
@api("card.detail")
def detail(svc, id):
    v, g = svc.vault, svc.game
    c = v.card(id)
    if not c:
        raise ApiError("card not found")
    raw = {}
    try:
        raw = json.loads(c["raw"] or "{}")
    except ValueError:
        pass
    t = lambda s: fix_text(s) if s else ""
    light = v.card_light(id) or {}
    labels = [taxonomy.LABEL[x] for x in light.get("groups", []) if x in taxonomy.LABEL]
    number = f"{c['local_id']}/{c['set_official']}" if (c["set_official"] and g.pokemon) else c["local_id"]
    flags = {}
    try:
        flags = clean_flags(json.loads(c["variants"] or "{}"), c["rarity"])
    except ValueError:
        pass
    variants = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)] or ["Normal"]
    facts = []
    if g.pokemon:
        for lab, key in (("Type", "types"), ("Stage", "stage"), ("Illustrator", "illustrator")):
            if c[key]:
                facts.append([lab, t(c[key])])
        if c["hp"]:
            facts.append(["HP", str(c["hp"])])
        if c["evolve_from"]:
            facts.append(["Evolves from", t(c["evolve_from"])])
        if c["dex"]:
            facts.append(["Pokédex", "#" + c["dex"].replace(",", ", #")])
    else:
        ext = raw.get("ext", {})
        facts = [[k, t(str(ext[k]).replace(";", ", "))] for k in ext if k not in ("Description", "Number") and ext[k] not in ("", None)]
    blocks = []
    for ab in raw.get("abilities") or []:
        blocks.append({"title": f"{t(ab.get('type', 'Ability'))}: {t(ab.get('name'))}", "text": t(ab.get("effect"))})
    for at in raw.get("attacks") or []:
        blocks.append({"title": f"{t(at.get('name'))} {at.get('damage', '')}".strip(), "cost": " ".join(at.get("cost") or []), "text": t(at.get("effect"))})
    if raw.get("effect"):
        blocks.append({"title": "", "text": t(raw["effect"])})
    extras = []
    for lab, key in (("Weakness", "weaknesses"), ("Resistance", "resistances")):
        if raw.get(key):
            extras.append([lab, ", ".join(f"{x.get('type')} {t(x.get('value', ''))}" for x in raw[key])])
    if raw.get("retreat") is not None:
        extras.append(["Retreat", str(raw["retreat"])])
    hist = [{"day": d, "usd": usd} for d, usd, _ in v.price_history(id) if usd is not None]
    lots = [lot_dict(l) for l in v.lots_for(id)]
    pf_names = {"": __import__("cardvault.webapi.portfolios", fromlist=["x"]).main_name(svc), **{p["uuid"]: p["name"] for p in v.portfolios()}}
    holdings = [{"id": pf or "main", "name": pf_names.get(pf, "Other"), "qty": q, "value": round((c["price_usd"] or 0) * q, 2)} for pf, q in v.conn.execute(
        "SELECT COALESCE(portfolio,''), SUM(qty) FROM u.lots WHERE user_id=? AND game=? AND card_id=? AND deleted=0 AND qty>0 GROUP BY COALESCE(portfolio,'')", (v.user_id, g.id, id))]
    return {
        "holdings": holdings,
        "id": id, "name": t(c["name"]), "setId": c["set_id"], "set": c["set_name"] or c["set_id"], "number": number, "rarity": c["rarity"] or "",
        "img": img(id, c["set_id"]), "imgHigh": img(id, c["set_id"], "high"), "imgNote": raw.get("image_note") or "", "tcg": (c["tcg_id"] if "tcg_id" in c.keys() else None) or "", "kinds": labels, "facts": facts, "blocks": blocks, "extras": extras,
        "description": t(c["description"]), "priceUsd": c["price_usd"], "priceEur": c["price_eur"], "priceUpdated": c["price_updated"], "history": hist,
        "priceKind": (c["price_kind"] if "price_kind" in c.keys() else None) or "", "noPriceWhy": "" if c["price_usd"] is not None else _no_price_why(svc, c),
        "sale": _sale(svc, id),
        "lots": lots, "qty": sum(l["qty"] for l in lots), "wish": id in svc.wishlist, "variants": variants + ["Other"],
        "lists": [{"id": cl["id"], "name": cl["name"], "member": id in set(v.checklist_members(cl["id"]))} for cl in v.checklists()],
        "options": {"conditions": CONDITIONS, "graders": GRADERS, "grades": GRADES, "languages": LANGUAGES, "editions": EDITIONS,
                    "locations": __import__("cardvault.tools", fromlist=["x"]).known_locations(v),
                    "sources": __import__("cardvault.tools", fromlist=["x"]).known_sources(v),
                    "portfolios": [{"id": "main", "name": __import__("cardvault.webapi.portfolios", fromlist=["x"]).main_name(svc)}] + [{"id": p["uuid"], "name": p["name"], "accepts": v.accepts_of(p["uuid"])} for p in v.portfolios() if v.accepts_of(p["uuid"]) != "none"],           # a category holds portfolios, never cards
                    "target": (v.target_pf or "main")},
    }


# ------------------------------------------------------------------------------------------------ changing what you own
def guard_elsewhere(svc, card_id, scoped_lots):
    """You can't 'mark as owned' a card you already hold in a portfolio that isn't being looked at - that would quietly make a second copy.  Say where it is instead."""
    if scoped_lots:
        return
    where = svc.vault.owned_where(card_id)
    if where:
        from .portfolios import main_name
        names = {p["uuid"]: p["name"] for p in svc.vault.portfolios()}
        txt = ", ".join(f"{names.get(pf, main_name(svc)) if pf else main_name(svc)} (x{q})" for pf, q in where)
        raise ApiError(f"You already own this card: {txt}. It counts once, there. To add another copy on purpose, use 'Add another copy' in the card's panel; to see it here, switch the Portfolio menu at the top.")


@api("own.toggle", mutates=True)
def own_toggle(svc, id, variant=""):
    v = svc.vault
    lots = v.lots_for(id)
    guard_elsewhere(svc, id, lots)
    name = (v.card_light(id) or {}).get("name", id)
    owned = bool([l for l in lots if (not variant or l["variant"] == variant)])

    def run():
        with v.action(f"{'Removed' if owned else 'Marked'} {name}{(' as owned in ' + _target_name(svc)) if not owned else ''}"):
            if owned:
                (v.set_variant_owned(id, variant, False) if variant else v.set_owned(id, False))
            else:
                (v.set_variant_owned(id, variant, True) if variant else v.set_owned(id, True))
                v.record_price_history([id])
    return with_undo(svc, run)


@api("own.needsConfirm")
def needs_confirm(svc, id, variant=""):
    v = svc.vault
    if variant:
        lots = [l for l in v.lots_for(id) if l["variant"] == variant]
        heavy = any(l["qty"] > 1 or l["graded"] or l["purchase_price"] is not None or l["notes"] for l in lots)
        n = sum(l["qty"] for l in lots)
    else:
        heavy = v.needs_remove_confirmation(id)
        n = sum(l["qty"] for l in v.lots_for(id))
    return {"confirm": heavy and n > 0, "copies": n}


@api("qty.adjust", mutates=True)
def qty_adjust(svc, id, delta, variant=None):
    v = svc.vault
    name = (v.card_light(id) or {}).get("name", id)

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {name}" + (f" - in {_target_name(svc)}" if delta > 0 else "")):
            if delta > 0:
                v.add_lot(id, variant or v.default_variant(id), "Near Mint", delta)
                v.record_price_history([id])
            else:
                for _ in range(-delta):
                    v.remove_one(id, variant or None)
    return with_undo(svc, run)


@api("lot.add", mutates=True)
def lot_add(svc, id, variant="Normal", condition="Near Mint", qty=1, graded=False, company="", grade="", paid=None, notes="", language="English",
            cert="", location="", edition="", purchased="", source="", portfolio=None):
    v = svc.vault
    made = {}

    def run():
        with v.action("Added a copy"):
            made["lot"] = v.add_lot(id, variant or v.default_variant(id), "Graded" if graded else condition, int(qty), bool(graded), company if graded else "", grade if graded else "",
                                    paid, notes, language, cert=cert if (graded or svc.game.family == "collectibles") else "", location=location, edition=edition, purchased=purchased or "", source=source or "",
                                    portfolio=None if portfolio in (None, "") else ("" if portfolio == "main" else portfolio))
            v.record_price_history([id])
    out = with_undo(svc, run)
    out["lot"] = made.get("lot")                                    # which stack it went into (a picture can be attached to it)
    return out


@api("lot.update", mutates=True)
def lot_update(svc, lot, fields):
    v = svc.vault
    mapped = {"company": "grade_company", "paid": "purchase_price"}
    data = {mapped.get(k, k): val for k, val in fields.items()}
    if data.get("portfolio") == "main":
        data["portfolio"] = ""
    if "graded" in data:
        data["graded"] = 1 if data["graded"] else 0
        if data["graded"]:
            data["condition"] = "Graded"
    return with_undo(svc, lambda: v.update_lot(lot, **data))


@api("lot.moveSome", mutates=True)
def lot_move_some(svc, lot, portfolio, qty):
    """Move some (or all) of a stack of copies to another portfolio.  The moved copies are the same items: they keep their purchase date, price paid and so their whole value history."""
    v = svc.vault
    r = v.get_lot(lot)
    if not r:
        raise ApiError("copy not found")
    to = "" if portfolio == "main" else portfolio
    n = max(1, int(qty))
    if (r["portfolio"] or "") == to:
        return {"moved": 0}
    if n >= r["qty"]:
        return with_undo(svc, lambda: v.update_lot(lot, portfolio=to))
    def run():
        with v.action(f"Moved {n} of {r['qty']} copies"):
            v.update_lot(lot, qty=r["qty"] - n)
            nid = v.add_lot(r["card_id"], r["variant"], r["condition"], n, bool(r["graded"]), r["grade_company"] or "", r["grade"] or "", r["purchase_price"], r["notes"] or "",
                            r["language"] or "English", cert=r["cert"] or "", location=r["location"] or "", edition=r["edition"] or "", purchased=r["purchased"] or "", source=r["source"] or "", portfolio=to)
            v.conn.execute("UPDATE u.lots SET added=? WHERE id=? AND added > ?", (r["added"], nid, r["added"]))
    return with_undo(svc, run)


@api("lot.qty", mutates=True)
def lot_qty(svc, lot, delta):
    return with_undo(svc, lambda: svc.vault.change_lot_qty(lot, delta))


@api("lot.remove", mutates=True)
def lot_remove(svc, lot):
    return with_undo(svc, lambda: svc.vault.delete_lot(lot))


@api("wish.toggle", mutates=True)
def wish_toggle(svc, id):
    v = svc.vault

    def run():
        v.toggle_wishlist(id)
        if id in v.wishlist_ids():
            v.record_price_history([id])
    return with_undo(svc, run)


@api("bulk.mark", mutates=True)
def bulk_mark(svc, ids, owned):
    v = svc.vault
    todo = [i for i in ids if (svc.owned.get(i, 0) == 0) == bool(owned)]
    n = len(todo)

    def run():
        with v.action(f"{'Marked' if owned else 'Removed'} {n} card{'s' if n != 1 else ''}"):
            v.mark_many(todo, bool(owned))
            if owned:
                v.record_price_history(todo)
        return {"count": n}
    return with_undo(svc, run)


@api("bulk.move", mutates=True)
def bulk_move(svc, ids, portfolio):
    """Move every copy (in the portfolios being looked at) of these cards to another portfolio."""
    from ..db import now_iso
    v = svc.vault
    pid = "" if portfolio in ("main", "", None) else portfolio
    if pid and not any(p["uuid"] == pid for p in v.portfolios()):
        raise ApiError("That portfolio doesn't exist.")
    v.check_accepts(pid, v.item_kind())
    ids = list(dict.fromkeys(ids))
    n = 0
    with v.action(f"Moved {len(ids)} card{'s' if len(ids) != 1 else ''} to another portfolio"):
        for lid, in v.conn.execute(f"SELECT id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND card_id IN ({','.join('?' * len(ids))})", (v.user_id, v.game, *ids)).fetchall():
            v.conn.execute("UPDATE u.lots SET portfolio=?, placed=1, updated_at=? WHERE id=?", (pid, now_iso(), lid))
            n += 1
        v._commit()
    return with_undo(svc, lambda: {"moved": n})


@api("bulk.edit", mutates=True)
def bulk_edit(svc, ids, fields):
    v = svc.vault
    have = [i for i in dict.fromkeys(ids) if svc.owned.get(i, 0) > 0]
    mapped = {"company": "grade_company"}
    data = {mapped.get(k, k): val for k, val in fields.items()}
    return with_undo(svc, lambda: {"count": v.bulk_update_lots(have, **data)} if have and data else {"count": 0})


@api("bulk.qty", mutates=True)
def bulk_qty(svc, ids, delta):
    v = svc.vault
    ids = list(dict.fromkeys(ids))

    def run():
        with v.action(f"{'Added' if delta > 0 else 'Removed'} a copy of {len(ids)} card{'s' if len(ids) != 1 else ''}"):
            for i in ids:
                if delta > 0:
                    v.add_lot(i, v.default_variant(i), "Near Mint", delta)
                else:
                    for _ in range(-delta):
                        v.remove_one(i)
            if delta > 0:
                v.record_price_history(ids)
    return with_undo(svc, run)


@api("bulk.wish", mutates=True)
def bulk_wish(svc, ids):
    v = svc.vault

    def run():
        with v.action(f"Changed the wishlist of {len(ids)} cards"):
            for i in ids:
                v.toggle_wishlist(i)
    return with_undo(svc, run)


@api("card.lists", mutates=True)
def card_lists(svc, id, checklist, member):
    """Add a card to (or take it off) one of your checklists."""
    v = svc.vault
    manual = v.checklist_manual(checklist)
    if member:
        v.set_checklist_card(checklist, id, None if id in manual["excluded"] else "manual")
        if id not in v.checklist_members(checklist):
            v.set_checklist_card(checklist, id, "manual")
    else:
        v.set_checklist_card(checklist, id, None if id in manual["manual"] else "excluded")
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ undo
@api("undo", mutates=True)
def undo(svc, id):
    if isinstance(id, str) and id.startswith("x:"):                     # a trade that touched several games: undo each game's part
        from . import tradeany
        return tradeany.undo_multi(svc, id)
    n = svc.vault.undo_action(id)
    svc.reload_state()
    return {"ok": True, "reversed": n}


@api("undo.last", mutates=True)
def undo_last(svc):
    r = svc.vault.last_undoable()
    if not r:
        return {"ok": False}
    svc.vault.undo_action(r["id"])
    svc.reload_state()
    return {"ok": True, "label": r["label"]}


@api("actions.recent")
def actions_recent(svc, limit=100, offset=0, q=""):
    """Your changes, newest first (the last 1000 are kept): searchable by what they say, and paged with offset."""
    rows = svc.vault.recent_actions(min(int(limit), 500), max(0, int(offset)), q)
    return [{"id": r["id"], "ts": r["ts"], "label": r["label"], "count": r["count"], "undone": bool(r["undone"])} for r in rows]


# ------------------------------------------------------------------------------------------------ master set (every variant of every card)
@api("cards.master")
def master(svc, set_id, graded_only=False, text="", show="all", extended=False, level="", extra_kinds=None, patterns=False):
    """A set 'unstacked': one tile per card per variant (normal, reverse holo, holo, 1st edition...), so a master set can be tracked.
    Progress counts every variant; the base size of the set is reported next to it."""
    v = svc.vault
    s = next((x for x in v.sets() if x["id"] == set_id), None)
    if not s:
        raise ApiError("set not found")
    have = {}
    for cid, var, q, gq, gr in v.conn.execute(
            "SELECT l.card_id, l.variant, SUM(l.qty), SUM(CASE WHEN l.graded=1 THEN l.qty ELSE 0 END), "
            "GROUP_CONCAT(CASE WHEN l.graded=1 THEN l.grade_company||' '||l.grade END, ', ') "
            "FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE c.set_id=? AND l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 GROUP BY l.card_id, l.variant",
            (set_id, v.user_id, v.game)):
        have[(cid, var)] = (q, gq, gr or "")
    from .setanalytics import _excluded
    excl = _excluded(v, set_id)                       # cards the person chose to leave out of this master set
    oc = v.owned_conditions()
    rows, owned_n, total_n, groups = [], 0, 0, {}
    std_total = std_owned = 0
    level = level if level in ("standard", "master", "extended") else ("extended" if extended else "master")
    tl = (text or "").strip().lower()
    for r in v.conn.execute("SELECT id, name, local_id, price_usd, price_kind, rarity, variants, tcg_id, variant_prices FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,)):
        try:
            flags = clean_flags(json.loads(r["variants"] or "{}"), r["rarity"])
        except ValueError:
            flags = {}
        labels = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)] or ["Normal"]
        left = r["id"] in excl
        g = groups.setdefault(r["rarity"] or "Unlabelled", {"rarity": r["rarity"] or "Unlabelled", "n": 0, "left": 0})
        g["n"] += 1
        g["left"] += 1 if left else 0
        per = []                                                          # (label, copies counted, graded copies, grades) for every version of this card
        for lab in labels:
            q, gq, gr = have.get((r["id"], lab), (0, 0, ""))
            per.append((lab, gq if graded_only else q, gq, gr))
        if not left:
            std_total += 1
            std_owned += 1 if any(c > 0 for _, c, _, _ in per) else 0
            for _lab, c, _gq, _gr in per:
                total_n += 1
                owned_n += 1 if c > 0 else 0
        if left != (show == "left"):
            continue                                              # left-out cards only show under "Left out"; everything else hides them
        if tl and tl not in (r["name"] or "").lower() and tl not in str(r["local_id"]).lower():
            continue
        if level == "standard":                                   # the plain set: one tile per card, owned in whichever version you have
            owned_any = [x for x in per if x[1] > 0]
            pick = owned_any[0] if owned_any else per[0]
            shown = [(pick[0], sum(x[1] for x in per), sum(x[2] for x in per), pick[3])]
        else:
            shown = per
        for lab, counted, gq, gr in shown:
            if show == "owned" and counted == 0 or show == "missing" and counted > 0:
                continue
            rows.append({"key": f"{r['id']}|{lab}", "id": r["id"], "name": fix_text(r["name"]), "number": r["local_id"], "variant": lab, "qty": counted, "graded": gq,
                         "cond": (oc.get(r["id"]) or {}).get(lab, ""), "grades": gr, "tcg": r["tcg_id"] or "", "price": _vp(r, lab)[0], "priceKind": "" if _vp(r, lab)[1] else (r["price_kind"] or ""), "left": left, "img": img(r["id"], set_id)})
    extras, ext_total, ext_owned, kinds_seen = [], 0, 0, {}
    try:                                                                   # the EXTENDED master set: stamped, Cosmos Holo, staff and pre-release promos that name this set
        from .masterextra import PATTERNS, extras_for_set, group_of, GROUPS
        extras = extras_for_set(svc, s)
    except Exception:  # noqa: BLE001 - a game without promo sets simply has none
        extras, GROUPS, PATTERNS = [], (), "patterns"

        def group_of(_lab):
            return "other"
    for _cid, _nm, _no, lab in extras:
        kinds_seen[group_of(lab)] = kinds_seen.get(group_of(lab), 0) + 1
    want = set(extra_kinds) if extra_kinds else {g for g, _t in GROUPS} | {"other"}
    want.discard(PATTERNS)
    if patterns:                                                         # the separate checkmark: pattern printings count only when it is ticked
        want.add(PATTERNS)
    for cid, nm, no, lab in extras:
        if group_of(lab) not in want:
            continue
        q = svc.owned.get(cid, 0)
        ext_total += 1
        ext_owned += 1 if q > 0 else 0
        if level != "extended" or show == "left" or (tl and tl not in (nm or "").lower()) or (show == "owned" and q == 0) or (show == "missing" and q > 0):
            continue
        c = v.card_light(cid) or {}
        rows.append({"key": f"{cid}|extra", "id": cid, "name": fix_text(nm), "number": no, "variant": v.default_variant(cid), "qty": q, "graded": 0, "cond": "", "grades": "", "tcg": c.get("tcg_id") or "",
                     "price": c.get("price_usd"), "priceKind": "", "left": False, "img": img(cid, c.get("set_id") or ""), "extra": lab})
    tiers = {"standard": {"owned": std_owned, "total": std_total}, "master": {"owned": owned_n, "total": total_n}, "extended": {"owned": owned_n + ext_owned, "total": total_n + ext_total}}
    for t in tiers.values():
        t["pct"] = (100.0 * t["owned"] / t["total"]) if t["total"] else 0.0
    cur = tiers[level]
    owned_n, total_n = cur["owned"], cur["total"]
    official = s["official"] or s["total"] or 0
    return {"rows": rows, "extrasCount": len(extras), "patternsN": kinds_seen.get(PATTERNS, 0), "extraKinds": [{"id": g, "name": t, "n": kinds_seen.get(g, 0)} for g, t in (*GROUPS, ("other", "Other promos")) if kinds_seen.get(g)], "level": level, "tiers": tiers,
            "title": s["name"], "owned": owned_n, "total": total_n, "leftOut": len(excl), "groups": sorted(groups.values(), key=lambda g: -g["n"]), "base": {"official": official, "listed": s["n"] if "n" in s.keys() else len(rows)},
            "pct": (100.0 * owned_n / total_n) if total_n else 0.0}
