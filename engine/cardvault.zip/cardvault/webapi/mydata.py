"""Download everything: ONE zip with all of the person's own data, made on this device from the unlocked local collection (the account server only
ever holds it encrypted and never opens it).  Same on the PC and on the website (there the file lands in /downloads and the page offers it).

Inside the zip:
  collection.csv      every copy owned, all games - the app's own CSV columns (Settings > Import reads it back) with a leading "game" column
  games/<game>.json   everything else per game in the sync snapshot format (wishlist, checklists, trades, sealed, portfolios, binders, ...)
  account.json        goals, settings and the username (never the email, passwords, keys or sign-in tokens)
  photos/             the person's own photos of their copies
  README.txt          what each file is"""
import csv
import datetime
import io
import json
import os
import shutil
import sqlite3
import tempfile
import types
import zipfile

from .registry import api
from ..db import Vault, game_dir
from ..cloud.snapshot import export_snapshot

FORMAT = 1
GAME_TABLES = ("lots", "wishlist", "checklists", "sealed", "trades", "card_tags", "custom_groups", "dream_binders", "spending", "shares", "snapshots", "sold", "custom_items")
SECRET_WORDS = ("token", "secret", "password", "passwd", "dek", "private_key", "lsalt", "totp", "email", "security_log")     # never written into the file, whatever a setting is called

README = """Collect Em All - your data
==========================
Made on {made} on your own device.

collection.csv     Every card you own, all games (opens in Excel / Google Sheets).
                   Settings > Import in the app reads it back.
games/*.json       Everything else for each game: wishlist, checklists, trades, sealed products,
                   portfolios, binders, spending, tags and value history.
account.json       Your goals, settings and username.
photos/            Photos you took of your own cards.

Nothing in this file is encrypted, so keep it somewhere safe.
"""


def _games(conn, user_id):
    found = set()
    for t in GAME_TABLES:
        try:
            found |= {r[0] for r in conn.execute(f"SELECT DISTINCT game FROM u.{t} WHERE user_id=?", (user_id,)) if r[0] and r[0] != "*"}
        except sqlite3.Error:
            continue
    return sorted(found)


def _other_game(v, gid):
    """A read-only stand-in for another game's Vault: that game's card list (names, sets, numbers) if it is on this device, plus the same collection."""
    cards = os.path.join(game_dir(v.data_dir, gid), "cards.db")
    if os.path.exists(cards):
        conn = sqlite3.connect(f"file:{cards}?mode=ro", uri=True)
    else:                                                                      # the game's card list is not downloaded: copies still come out, just without names
        conn = sqlite3.connect(":memory:")
        conn.executescript("CREATE TABLE cards(id TEXT, name TEXT, local_id TEXT, set_id TEXT, price_usd REAL, price_kind TEXT); CREATE TABLE sets(id TEXT, name TEXT);")
    conn.row_factory = sqlite3.Row
    conn.execute("ATTACH DATABASE ? AS u", (v.user_path,))
    shim = types.SimpleNamespace(conn=conn, user_id=v.user_id, game=gid, data_dir=v.data_dir, CSV_COLUMNS=Vault.CSV_COLUMNS, look_get=v.look_get)
    shim._pf_name = types.MethodType(Vault._pf_name, shim)
    return shim


def _collection_rows(v, tmpdir):
    """The app's own CSV export (Vault.export_csv - the format Import reads), for one game."""
    p = os.path.join(tmpdir, "c.csv")
    Vault.export_csv(v, p)
    with open(p, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    os.remove(p)
    return rows[1:]


def _clean(d, email=""):
    """Settings minus anything secret-sounding, and the account email blanked wherever it turns up (the security log, a note...)."""
    if isinstance(d, dict):
        return {k: _clean(x, email) for k, x in d.items() if not any(w in str(k).lower() for w in SECRET_WORDS)}
    if isinstance(d, list):
        return [_clean(x, email) for x in d]
    if isinstance(d, str) and email and email in d.lower():
        return d.lower().replace(email, "(your email)")
    return d


def _json(text):
    try:
        return json.loads(text or "{}")
    except ValueError:
        return {}


def _account_part(svc, v):
    from .settings import prefs_collect
    from . import goals
    try:
        prefs = prefs_collect(svc)
    except Exception:  # noqa: BLE001 - settings must never stop the rest of the export
        prefs = {}
    per_game = {}
    for g, k, val in v.conn.execute("SELECT game, key, value FROM u.settings WHERE user_id=? ORDER BY game, key", (v.user_id,)):
        per_game.setdefault(g, {})[k] = val
    return _clean({"username": svc.pget("cloud_username") or "", "goals": goals._all(svc), "goals_done": _json(svc.pget(goals.DONE)),
                   "settings": prefs, "game_settings": per_game}, (svc.pget("cloud_email") or "").strip().lower())


def _photo_ext(data):
    b = bytes(data[:12])
    if b.startswith(b"\x89PNG"):
        return "png"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return "webp"
    return "jpg"


def build_zip(svc, path):
    v = svc.vault
    v._commit()
    made = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    counts = {"copies": 0, "games": 0, "photos": 0}
    tmpdir = tempfile.mkdtemp()                       # NOT next to `path`: on the website everything in /downloads is offered to the person
    part = os.path.join(tmpdir, "all.zip")
    try:
        with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED) as z:
            out = io.StringIO()
            w = csv.writer(out)
            w.writerow(["game", *Vault.CSV_COLUMNS])
            for gid in _games(v.conn, v.user_id):
                g = v if gid == v.game else _other_game(v, gid)
                try:
                    rows = _collection_rows(g, tmpdir)
                    w.writerows([gid, *r] for r in rows)
                    counts["copies"] += len(rows)
                    z.writestr(f"games/{gid}.json", json.dumps(export_snapshot(g, "export"), ensure_ascii=False, indent=1))
                    counts["games"] += 1
                finally:
                    if g is not v:
                        g.conn.close()
            z.writestr("collection.csv", "\ufeff" + out.getvalue())
            z.writestr("account.json", json.dumps(_account_part(svc, v), ensure_ascii=False, indent=1, default=str))
            for pid, lot, side, data in v.conn.execute("SELECT id, lot_uuid, side, data FROM u.lot_photos ORDER BY id"):
                if data:
                    z.writestr(f"photos/{lot or 'photo'}-{side or 'other'}-{pid}.{_photo_ext(data)}", bytes(data))
                    counts["photos"] += 1
            z.writestr("manifest.json", json.dumps({"app": "Collect Em All", "format": FORMAT, "made": made, **counts}, indent=1))
            z.writestr("README.txt", README.format(made=made))
        shutil.move(part, path)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    return {"bytes": os.path.getsize(path), **counts}


@api("data.exportAll")
def export_all(svc, path):
    """Download everything (see the top of this file).  `path` comes from dialog.save."""
    svc.need_grant(path)
    r = build_zip(svc, path)
    svc.audit("export", "all my data (zip)")
    return r
