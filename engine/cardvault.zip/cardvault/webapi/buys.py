"""Purchases ranked by what they made: every card lot and sealed purchase that has a price paid, against today's price (best and worst buys)."""
import json

from .. import pricepick, sealedprice
from .registry import api


@api("buys.ranked")
def ranked(svc, limit=8):
    v = svc.vault
    rows = []
    for r in v.conn.execute(
            "SELECT l.card_id, l.variant, l.qty, l.purchase_price AS paid, COALESCE(NULLIF(l.purchased,''), substr(l.added,1,10)) AS day, COALESCE(l.portfolio,'') AS pf, "
            "c.name, c.price_usd AS usd, s.name AS set_name FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 AND l.purchase_price IS NOT NULL AND c.price_usd IS NOT NULL", (v.user_id, v.game)):
        if v.scope and r["pf"] not in v.scope:
            continue
        rows.append(_row("card", r["card_id"], r["name"], r["set_name"] or "", r["variant"] or "", r["qty"], r["paid"], r["usd"], r["day"] or ""))
    for r in v.conn.execute("SELECT uuid, name, qty, paid, purchased, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND paid IS NOT NULL", (v.user_id, v.game)):
        if v.scope and r["pf"] not in v.scope:
            continue
        p = sealedprice.price_for(v, r["name"])
        if p and p.get("price") is not None:
            rows.append(_row("sealed", r["uuid"], r["name"], "Sealed product", "", r["qty"], r["paid"], p["price"], r["purchased"] or ""))
    rows.sort(key=lambda x: -x["gain"])
    n = max(1, min(50, int(limit)))
    best = [x for x in rows if x["gain"] > 0][:n]
    worst = [x for x in sorted(rows, key=lambda x: x["gain"]) if x["gain"] < 0][:n]
    return {"best": best, "worst": worst, "count": len(rows),
            "spent": round(sum(x["paid"] * x["qty"] for x in rows), 2), "worth": round(sum(x["now"] * x["qty"] for x in rows), 2)}


def _row(kind, id, name, sub, variant, qty, paid, now, day):
    return {"type": kind, "id": id, "name": name, "sub": " · ".join(x for x in (sub, variant) if x), "qty": qty, "paid": round(paid, 4), "now": round(now, 4), "day": day,
            "gain": round((now - paid) * qty, 2), "pct": round((now - paid) / paid * 100, 1) if paid else None}


# ---- opened sealed products: taken out of the sealed list, remembered with what they cost (a pref, so it syncs with the account)
KEY = "sealed_opened"


def _opened(svc):
    try:
        got = json.loads(svc.pget(KEY) or "[]")                       # kept as text, like the showcase settings
    except ValueError:
        got = []
    return [x for x in got if isinstance(x, dict)]


def open_some(svc, id, qty=1):
    """Mark `qty` of one purchase as opened: they leave the sealed list (and its value), and the cost is kept in the Opened list."""
    from ..db import new_uuid, now_iso, today
    from .registry import ApiError
    v = svc.vault
    row = v.conn.execute("SELECT * FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (id, v.user_id)).fetchone()
    if not row:
        raise ApiError("That product isn't in your list any more.")
    n = max(1, min(int(qty), row["qty"] or 0))
    left = (row["qty"] or 0) - n
    if left <= 0:
        v.conn.execute("UPDATE u.sealed SET qty=0, deleted=1, updated_at=? WHERE uuid=?", (now_iso(), id))
    else:
        v.conn.execute("UPDATE u.sealed SET qty=?, updated_at=? WHERE uuid=?", (left, now_iso(), id))
    v.commit()
    log = _opened(svc)
    log.append({"id": new_uuid(), "game": v.game, "name": row["name"], "qty": n, "paid": row["paid"], "day": today(), "bought": row["purchased"] or ""})
    svc.pset(KEY, json.dumps(log[-500:]))
    return {"opened": n, "left": max(left, 0)}


@api("sealed.opened")
def opened_list(svc):
    v = svc.vault
    rows = [x for x in reversed(_opened(svc)) if x.get("game") == v.game]
    return {"rows": rows, "count": sum(x["qty"] for x in rows), "cost": round(sum((x.get("paid") or 0) * x["qty"] for x in rows), 2)}


@api("sealed.openedRemove", mutates=True)
def opened_remove(svc, id):
    from .undoext import undoable
    return undoable(svc, "Removed an opened-product entry", lambda: svc.pset(KEY, json.dumps([x for x in _opened(svc) if x.get("id") != id])), keys=[KEY])


# ---- split an averaged price back into real purchases (the total spent never changes)
def _rest_price(total_qty, avg, k, price):
    """The price the other copies must carry so qty*avg stays the same after `k` of them are given their own `price`."""
    return max(0.0, round((total_qty * avg - k * price) / (total_qty - k), 4))


def sealed_split(svc, id, qty, paid):
    """Give `qty` copies of one sealed purchase their own price; the rest take the price that keeps the total spent the same."""
    from ..db import new_uuid, now_iso
    from .registry import ApiError
    v = svc.vault
    r = v.conn.execute("SELECT * FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (id, v.user_id)).fetchone()
    if not r:
        raise ApiError("That product isn't in your list any more.")
    k, n = int(qty), r["qty"] or 0
    if k < 1 or k >= n:
        raise ApiError(f"Choose between 1 and {n - 1} copies to give their own price.")
    if r["paid"] is None:
        raise ApiError("This purchase has no price yet - type the price paid first, then split it.")
    rest = _rest_price(n, r["paid"], k, float(paid))
    ts = now_iso()
    v.conn.execute("UPDATE u.sealed SET qty=?, paid=?, updated_at=? WHERE uuid=?", (n - k, rest, ts, id))
    v.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                   (new_uuid(), v.user_id, v.game, r["upc"] or "", r["name"], k, float(paid), r["purchased"] or "", r["source"] or "", r["notes"] or "", r["portfolio"] or "", ts))
    v.commit()
    return {"rest": rest}


@api("lot.split", mutates=True)
def lot_split(svc, lot, qty, paid):
    """The same for a stack of cards: `qty` copies get their own price paid, the rest keep the total spent unchanged."""
    from .cards import with_undo
    from .registry import ApiError
    v = svc.vault
    r = v.get_lot(lot)
    if not r:
        raise ApiError("copy not found")
    k, n = int(qty), r["qty"]
    if k < 1 or k >= n:
        raise ApiError(f"Choose between 1 and {n - 1} copies to give their own price.")
    if r["purchase_price"] is None:
        raise ApiError("This stack has no price yet - type the price paid first, then split it.")
    rest = _rest_price(n, r["purchase_price"], k, float(paid))

    def run():
        with v.action(f"Split {k} of {n} copies to their own price"):
            v.update_lot(lot, qty=n - k, purchase_price=rest)
            nid = v.add_lot(r["card_id"], r["variant"], r["condition"], k, bool(r["graded"]), r["grade_company"] or "", r["grade"] or "", float(paid), r["notes"] or "",
                            r["language"] or "English", cert=r["cert"] or "", location=r["location"] or "", edition=r["edition"] or "", purchased=r["purchased"] or "",
                            source=r["source"] or "", portfolio=r["portfolio"] or "")
            v.conn.execute("UPDATE u.lots SET added=? WHERE id=? AND added > ?", (r["added"], nid, r["added"]))
    return with_undo(svc, run)


@api("data.exportPurchases")
def export_purchases(svc, path):
    """A spreadsheet with ONE ROW PER PURCHASE (cards and sealed): how many, paid each, paid in total, today's price and the gain - so a sheet's totals match the app."""
    import csv
    v = svc.vault
    svc.need_grant(path)
    svc.audit("export", "purchases CSV")
    head = ["type", "name", "set", "variant", "qty", "paid_each", "paid_total", "price_now", "value_now", "gain", "bought", "bought_at", "portfolio"]
    n = 0
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(head)

        def line(kind, name, sub, variant, qty, paid, now, day, src, pf):
            nonlocal n
            tot = None if paid is None else round(paid * qty, 2)
            val = None if now is None else round(now * qty, 2)
            w.writerow([kind, name, sub, variant, qty, "" if paid is None else paid, "" if tot is None else tot, "" if now is None else now, "" if val is None else val,
                        "" if (tot is None or val is None) else round(val - tot, 2), day or "", src or "", v._pf_name(pf)])
            n += 1
        for r in v.conn.execute(
                "SELECT l.*, c.name, c.price_usd AS usd, s.name AS set_name FROM u.lots l LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 ORDER BY l.id", (v.user_id, v.game)):
            line("card", r["name"], r["set_name"] or "", r["variant"] or "", r["qty"], r["purchase_price"], r["usd"], r["purchased"] or (r["added"] or "")[:10], r["source"], r["portfolio"])
        for r in v.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY name COLLATE NOCASE, purchased", (v.user_id, v.game)):
            p = sealedprice.price_for(v, r["name"])
            line("sealed", r["name"], "Sealed product", "", r["qty"], r["paid"], p["price"] if p else None, r["purchased"], r["source"], r["portfolio"])
    return {"lines": n}


# ---- the same card + version sitting in more than one portfolio (often an accidental double entry)
@api("dupes.find")
def dupes_find(svc, limit=200):
    v = svc.vault
    names = {"": __import__("cardvault.webapi.portfolios", fromlist=["x"]).main_name(svc), **{p["uuid"]: p["name"] for p in v.portfolios()}}
    by = {}
    for r in v.conn.execute(
            "SELECT l.id, l.card_id, l.variant, l.qty, COALESCE(l.portfolio,'') AS pf, c.name, c.local_id, s.name AS set_name FROM lots_s l JOIN cards c ON c.id=l.card_id "
            "LEFT JOIN sets s ON s.id=c.set_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 AND l.graded=0", (v.user_id, v.game)):
        e = by.setdefault((r["card_id"], r["variant"] or ""), {"card": r["card_id"], "variant": r["variant"] or "", "name": r["name"], "sub": f"{r['set_name'] or ''} #{r['local_id']}", "where": {}})
        e["where"][r["pf"]] = e["where"].get(r["pf"], 0) + r["qty"]
    out = []
    for e in by.values():
        if len(e["where"]) > 1:
            e["where"] = [{"id": pf or "main", "name": names.get(pf, "Other"), "qty": q} for pf, q in e["where"].items()]
            e["total"] = sum(w["qty"] for w in e["where"])
            out.append(e)
    out.sort(key=lambda e: (-e["total"], e["name"]))
    return {"rows": out[:max(1, int(limit))], "count": len(out)}


@api("dupes.merge", mutates=True)
def dupes_merge(svc, card, variant, portfolio):
    """Bring every ungraded copy of this card + version together in one portfolio (they keep their prices and dates; undo puts them back)."""
    from .cards import with_undo
    v = svc.vault
    to = "" if portfolio == "main" else portfolio

    def run():
        with v.action("Brought the copies of one card together"):
            for r in v.conn.execute("SELECT id, portfolio FROM lots_s WHERE user_id=? AND game=? AND card_id=? AND COALESCE(variant,'')=? AND deleted=0 AND qty>0 AND graded=0",
                                    (v.user_id, v.game, card, variant or "")).fetchall():
                if (r["portfolio"] or "") != to:
                    v.update_lot(r["id"], portfolio=to)
    return with_undo(svc, run)


@api("sealed.open", mutates=True)
def open_some_api(svc, id, qty=1):
    from .undoext import undoable
    return undoable(svc, "Marked sealed products as opened", lambda: svc.vault.sealed_action("Marked sealed products as opened", lambda: open_some(svc, id, qty)), keys=[KEY])


@api("sealed.split", mutates=True)
def sealed_split_api(svc, id, qty, paid):
    from .extras import _undoable
    return _undoable(svc, "Split a sealed price", lambda: sealed_split(svc, id, qty, paid))


@api("sealed.history")
def sealed_history(svc, name):
    """The saved daily market price of one sealed product (recorded once a day for everything you own) - for the chart on its purchase screen."""
    from ..tcgcsv import norm_name
    v = svc.vault
    v.record_sealed_history()                                    # today's point is there straight away
    v.commit()
    rows = [(d, usd) for d, usd, _eur in v.price_history("sealed:" + norm_name(name)) if usd is not None]
    from .. import pricestats
    return {"points": [{"day": d, "usd": usd} for d, usd in rows], "stats": pricestats.stats(rows, "market")}


@api("sell.list")
def sell_list(svc, items, fee=13.0):
    """A sell list for the picked cards / sealed products: what each is worth now, what you paid, what is left after selling fees, and the profit - with totals."""
    v = svc.vault
    cut = max(0.0, min(90.0, float(fee))) / 100
    rows = []

    def add(kind, name, sub, qty, paid, now):
        net = None if now is None else round(now * (1 - cut), 2)
        cost = None if paid is None else round(paid * qty, 2)
        rows.append({"type": kind, "name": name, "sub": sub, "qty": qty, "paid": paid, "now": now, "gross": None if now is None else round(now * qty, 2),
                     "net": None if net is None else round(net * qty, 2), "cost": cost,
                     "profit": None if (net is None or cost is None) else round(net * qty - cost, 2),
                     "breakEven": None if paid is None else round(paid / (1 - cut), 2) if cut < 1 else None})
    for x in items:
        if x.get("type") == "card" and x.get("lot"):
            r = v.conn.execute("SELECT l.qty, l.purchase_price AS paid, l.variant, c.name, c.price_usd AS usd, s.name AS set_name FROM u.lots l JOIN cards c ON c.id=l.card_id "
                               "LEFT JOIN sets s ON s.id=c.set_id WHERE l.uuid=? AND l.user_id=? AND l.deleted=0", (x["lot"], v.user_id)).fetchone()
            if r:
                add("card", r["name"], " · ".join(p for p in (r["set_name"] or "", r["variant"] or "") if p), r["qty"], r["paid"], r["usd"])
        elif x.get("type") == "card" and x.get("id") and not x.get("lot"):     # a card by its id (the Duplicates view): its extras, priced now; no paid price is kept per card
            c = v.card_basic(x["id"])
            qty = min(int(x.get("qty") or 1), v.owned_map().get(x["id"], 0))
            if c and qty > 0:
                add("card", c["name"], c.get("set_name") or "", qty, None, pricepick.price_for(v, x["id"], c.get("price_usd")))
        elif x.get("type") == "sealed" and x.get("lot"):
            r = v.conn.execute("SELECT name, qty, paid FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (x["lot"], v.user_id)).fetchone()
            if r:
                p = sealedprice.price_for(v, r["name"])
                add("sealed", r["name"], "Sealed product", r["qty"], r["paid"], p["price"] if p else None)
    tot = lambda k: round(sum(r[k] for r in rows if r[k] is not None), 2)
    return {"rows": rows, "fee": fee, "totals": {"gross": tot("gross"), "net": tot("net"), "cost": tot("cost"), "profit": tot("profit"), "count": sum(r["qty"] for r in rows)},
            "noPrice": sum(1 for r in rows if r["now"] is None)}


@api("data.exportReport")
def export_report(svc, path):
    """An inventory report as a printable web page (print it to PDF from the browser): every card and sealed product with how many, what you paid and what it is worth, plus totals.
    Meant for insurance, a move or a sale.  It contains no pictures, so opening it never connects to the internet."""
    import datetime
    import html as H
    v = svc.vault
    svc.need_grant(path)
    svc.audit("export", "inventory report")
    e = lambda x: H.escape(str(x if x is not None else ""))
    m = lambda x: "" if x is None else f"${x:,.2f}"
    cards, sealed = [], []
    for r in v.conn.execute(
            "SELECT l.*, c.name, c.local_id, c.price_usd AS usd, s.name AS set_name FROM u.lots l LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0 ORDER BY s.name, c.name", (v.user_id, v.game)):
        grade = f"{r['grade_company'] or ''} {r['grade'] or ''}".strip() if r["graded"] else r["condition"]
        cards.append((r["name"], r["set_name"] or "", r["local_id"], r["variant"] or "", grade or "", r["qty"], r["purchase_price"], r["usd"], r["purchased"] or "", r["cert"] or ""))
    for r in v.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY name COLLATE NOCASE", (v.user_id, v.game)):
        p = sealedprice.price_for(v, r["name"])
        sealed.append((r["name"], r["qty"], r["paid"], p["price"] if p else None, r["purchased"] or ""))
    val = lambda q, u: 0 if u is None else q * u
    c_val, s_val = sum(val(c[5], c[7]) for c in cards), sum(val(s[1], s[3]) for s in sealed)
    c_paid, s_paid = sum(val(c[5], c[6]) for c in cards), sum(val(s[1], s[2]) for s in sealed)
    rows_c = "".join(f"<tr><td>{e(c[0])}</td><td>{e(c[1])}</td><td>{e(c[2])}</td><td>{e(c[3])}</td><td>{e(c[4])}</td><td>{e(c[9])}</td><td class=r>{c[5]}</td><td class=r>{m(c[6])}</td><td class=r>{m(c[7])}</td><td class=r>{m(val(c[5], c[7]) if c[7] is not None else None)}</td><td>{e(c[8])}</td></tr>" for c in cards)
    rows_s = "".join(f"<tr><td>{e(s[0])}</td><td class=r>{s[1]}</td><td class=r>{m(s[2])}</td><td class=r>{m(s[3])}</td><td class=r>{m(val(s[1], s[3]) if s[3] is not None else None)}</td><td>{e(s[4])}</td></tr>" for s in sealed)
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Collection report</title><style>
body{{font:14px/1.45 system-ui,sans-serif;margin:32px;color:#1a2236}}h1{{margin:0 0 4px}}h2{{margin:28px 0 8px}}table{{border-collapse:collapse;width:100%;font-size:12.5px}}
th,td{{border-bottom:1px solid #d8deea;padding:5px 8px;text-align:left}}th{{background:#eef1f8}}td.r,th.r{{text-align:right}}.sum{{display:flex;gap:24px;flex-wrap:wrap;margin:14px 0}}
.sum div{{border:1px solid #d8deea;border-radius:10px;padding:10px 16px}}.sum b{{display:block;font-size:20px}}.m{{color:#6b7488}}@media print{{body{{margin:12mm}}tr{{break-inside:avoid}}}}
</style></head><body><h1>Collection report - {e(svc.game.name)}</h1>
<div class=m>Prepared {datetime.date.today().isoformat()} by Collect Em All{(' for ' + e(svc.pget('cloud_username'))) if svc.pget('cloud_username') else ''}. Values are TCGplayer market prices on that day, not a valuation or an appraisal.</div>
<div class=sum><div><b>{sum(c[5] for c in cards):,}</b>cards</div><div><b>{sum(s[1] for s in sealed):,}</b>sealed products</div><div><b>{m(c_val + s_val)}</b>market value</div><div><b>{m(c_paid + s_paid)}</b>paid (where entered)</div></div>
<h2>Cards ({len(cards)} lines)</h2><table><thead><tr><th>Card</th><th>Set</th><th>No.</th><th>Version</th><th>Condition / grade</th><th>Cert</th><th class=r>Qty</th><th class=r>Paid each</th><th class=r>Price</th><th class=r>Value</th><th>Bought</th></tr></thead><tbody>{rows_c}</tbody>
<tfoot><tr><th colspan=9>Cards total</th><th class=r>{m(c_val)}</th><th></th></tr></tfoot></table>
<h2>Sealed products ({len(sealed)} lines)</h2><table><thead><tr><th>Product</th><th class=r>Qty</th><th class=r>Paid each</th><th class=r>Price</th><th class=r>Value</th><th>Bought</th></tr></thead><tbody>{rows_s}</tbody>
<tfoot><tr><th colspan=4>Sealed total</th><th class=r>{m(s_val)}</th><th></th></tr></tfoot></table>
<p class=m>Tip: open this file in a browser and choose Print, then "Save as PDF".</p></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
    return {"lines": len(cards) + len(sealed)}
