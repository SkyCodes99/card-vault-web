"""Card tools: a rundown of every card game on this device - how many cards and sets, the newest set, when prices were last updated, how many sets have a logo."""
import os
import sqlite3

from .. import games
from ..db import game_dir
from .registry import api


@api("dev.games", quiet=True)
def dev_games(svc):
    out = []
    for g in games.GAMES:
        if not g.available:
            continue
        path = os.path.join(game_dir(svc.cfg["data_dir"], g.id), "cards.db")
        row = {"id": g.id, "name": g.name, "installed": False, "cards": 0, "sets": 0, "newest": "", "newestDate": "", "sealed": 0, "rarities": 0, "priced": 0, "logos": 0, "pricesUpdated": ""}
        if os.path.exists(path):
            try:
                c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
                try:
                    row["cards"] = c.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
                    row["priced"] = c.execute("SELECT COUNT(*) FROM cards WHERE price_usd IS NOT NULL").fetchone()[0]
                    row["rarities"] = c.execute("SELECT COUNT(DISTINCT rarity) FROM cards WHERE rarity IS NOT NULL AND rarity != ''").fetchone()[0]
                    row["sets"] = c.execute("SELECT COUNT(*) FROM sets").fetchone()[0]
                    row["logos"] = c.execute("SELECT COUNT(*) FROM sets WHERE logo IS NOT NULL AND logo != ''").fetchone()[0]
                    n = c.execute("SELECT name, release_date FROM sets WHERE release_date IS NOT NULL AND release_date != '' AND release_date <= date('now', '+1 day') ORDER BY release_date DESC LIMIT 1").fetchone()
                    if n:
                        row["newest"], row["newestDate"] = n[0], (n[1] or "")[:10]
                    try:
                        row["sealed"] = c.execute("SELECT COUNT(*) FROM sealed_products").fetchone()[0]
                    except sqlite3.Error:
                        pass
                    m = c.execute("SELECT value FROM meta WHERE key='prices_updated'").fetchone()
                    row["pricesUpdated"] = m[0] if m else ""
                    row["installed"] = row["cards"] > 0
                finally:
                    c.close()
            except sqlite3.Error:
                pass
        out.append(row)
    return {"games": out, "open": svc.vault.game}


@api("dev.accounts", quiet=True)
def dev_accounts(svc):
    """The owner's account tracker: how many accounts exist and how many joined lately (counts only; the server never tells names or emails)."""
    from ..cloud import skycloud as sc
    from .accountapi import account
    from .registry import ApiError
    if not svc.pget("cloud_admin"):
        raise ApiError("Only the owner's account can see this.")
    a = account(svc, need=True)
    try:
        return a.call("GET", "/v1/admin/accounts")
    except sc.CloudError as e:
        if e.status == 404:
            raise ApiError("The account server doesn't have the tracker yet - it arrives with the next server update.")
        raise ApiError(str(e))


def _my_tags(svc):
    """This device's own hand corrections for the open game as the Card Data format: {tcg_id: {"tags": {tag: yes|no}}} (cards without a TCGplayer id can't be shared)."""
    v = svc.vault
    rows = v.conn.execute("SELECT t.card_id, t.tag, t.value, c.tcg_id FROM u.card_tags t JOIN cards c ON c.id=t.card_id WHERE t.user_id=? AND t.game=? AND c.tcg_id IS NOT NULL", (v.user_id, v.game)).fetchall()
    out, skipped = {}, 0
    for r in rows:
        if r["value"] in ("yes", "no"):
            out.setdefault(str(r["tcg_id"]), {"tags": {}})["tags"][r["tag"]] = r["value"]
        else:
            skipped += 1
    return out


@api("dev.corrections.count", quiet=True)
def corrections_count(svc):
    return {"cards": len(_my_tags(svc)), "game": svc.game.name, "admin": bool(svc.pget("cloud_admin"))}


HIST_KEY = "corr_history"


def _hist(svc):
    import json
    try:
        h = json.loads(svc.pget(HIST_KEY) or "[]")
    except ValueError:
        h = []
    return h if isinstance(h, list) else []


def _post(a, game, patch, what="cards"):
    """Send {tcg_id: {"tags": {...}} | None} for one game through the account server (None removes that card's correction).  what="sealed": {product id: {kind, serie, hidden} | None}."""
    from ..cloud import skycloud as sc
    from .registry import ApiError
    try:
        a.call("POST", f"/v1/carddata/corrections/{what}", {"games": {game: patch}}, timeout=90)
    except sc.CloudError as e:
        raise ApiError("The account server doesn't have corrections publishing yet - it comes with the next server update." if e.status == 404
                       else "Your sign-in has expired - sign in again in Settings > Account, then publish again." if e.status == 401 else str(e))


@api("dev.corrections.publish")
def corrections_publish(svc):
    """Owner only.  Runs in the background (you keep working; nothing signs you out): sends this game's hand corrections to Card Data and remembers what they replaced, so they can be reverted."""
    import datetime
    import json
    from .accountapi import account
    from .registry import ApiError
    from .. import carddata, corrections
    if not svc.pget("cloud_admin"):
        raise ApiError("Only the owner's account can publish corrections.")
    mine = _my_tags(svc)
    if not mine:
        raise ApiError("There are no hand corrections on this device for this game yet.")
    a = account(svc, need=True)                                  # everything that touches the collection is read HERE; the background job only talks to the network
    game, gname = svc.game.id, svc.game.name
    data_dir = svc.cfg["data_dir"]
    cd_base = (svc.cfg.get("carddata_url") or carddata.BASE).rstrip("/")

    def run(emit, cancel):
        emit("Publishing corrections…", 0, 2)
        try:
            corrections.refresh(data_dir, cd_base + "/corrections")        # the copy that is live right now, so the revert knows what to put back
        except Exception:  # noqa: BLE001
            pass
        live = (corrections.load(data_dir).get("games") or {}).get(game) or {}
        previous = {t: (live[t].get("tags") if isinstance(live.get(t), dict) else None) for t in mine}
        _post(a, game, mine)
        entry = {"id": datetime.datetime.now().strftime("%Y%m%d%H%M%S"), "ts": datetime.datetime.now().isoformat(timespec="seconds"), "game": game, "gameName": gname,
                 "count": len(mine), "previous": previous, "reverted": ""}
        svc.run(lambda s: s.pset(HIST_KEY, json.dumps((_hist(s) + [entry])[-20:])), timeout=30)
        emit("Published", 2, 2)
        return {"published": len(mine), "game": gname}
    return {"job": svc.jobs.start("corrections-publish", f"Publishing {len(mine)} corrections", run).id}


@api("dev.corrections.history", quiet=True)
def corrections_history(svc):
    return [{"id": h["id"], "ts": h["ts"], "game": (h.get("gameName") or h["game"]) + (" (sealed products)" if h.get("what") == "sealed" else ""), "count": h["count"], "reverted": h.get("reverted") or ""} for h in reversed(_hist(svc))]


@api("dev.corrections.revert")
def corrections_revert(svc, id):
    """Put the shared card data back the way it was before that publish (cards that had no correction before lose it again).  Also runs in the background."""
    import datetime
    import json
    from .accountapi import account
    from .registry import ApiError
    if not svc.pget("cloud_admin"):
        raise ApiError("Only the owner's account can revert corrections.")
    h = next((x for x in _hist(svc) if x["id"] == id), None)
    if not h:
        raise ApiError("That publish isn't in the history.")
    if h.get("reverted"):
        raise ApiError("That one was already reverted.")
    a = account(svc, need=True)

    def run(emit, cancel):
        emit("Reverting corrections…", 0, 2)
        if h.get("what") == "sealed":
            patch = dict(h["previous"])                                   # product id -> what it was before (None = it had no published correction)
        else:
            patch = {t: ({"tags": prev} if prev is not None else None) for t, prev in h["previous"].items()}
        (_post(a, h["game"], patch, "sealed") if h.get("what") == "sealed" else _post(a, h["game"], patch))

        def mark(s):
            hist = _hist(s)
            for x in hist:
                if x["id"] == id:
                    x["reverted"] = datetime.datetime.now().isoformat(timespec="seconds")
            s.pset(HIST_KEY, json.dumps(hist))
        svc.run(mark, timeout=30)
        emit("Reverted", 2, 2)
        return {"reverted": len(patch)}
    return {"job": svc.jobs.start("corrections-revert", f"Reverting {len(h['previous'])} corrections", run).id}
