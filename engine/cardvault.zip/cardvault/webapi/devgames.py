"""Card tools: a rundown of every card game on this device - how many cards and sets, the newest set, when prices were last updated, how many sets have a logo."""
import os
import sqlite3

from .. import games
from ..db import game_dir
from .registry import api


@api("dev.games", quiet=True)
def dev_games(svc):
    out = []
    for g in games.GAMES:
        if not g.available:
            continue
        path = os.path.join(game_dir(svc.cfg["data_dir"], g.id), "cards.db")
        row = {"id": g.id, "name": g.name, "installed": False, "cards": 0, "sets": 0, "newest": "", "newestDate": "", "sealed": 0, "rarities": 0, "priced": 0, "logos": 0, "pricesUpdated": ""}
        if os.path.exists(path):
            try:
                c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
                try:
                    row["cards"] = c.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
                    row["priced"] = c.execute("SELECT COUNT(*) FROM cards WHERE price_usd IS NOT NULL").fetchone()[0]
                    row["rarities"] = c.execute("SELECT COUNT(DISTINCT rarity) FROM cards WHERE rarity IS NOT NULL AND rarity != ''").fetchone()[0]
                    row["sets"] = c.execute("SELECT COUNT(*) FROM sets").fetchone()[0]
                    row["logos"] = c.execute("SELECT COUNT(*) FROM sets WHERE logo IS NOT NULL AND logo != ''").fetchone()[0]
                    n = c.execute("SELECT name, release_date FROM sets WHERE release_date IS NOT NULL AND release_date != '' AND release_date <= date('now', '+1 day') ORDER BY release_date DESC LIMIT 1").fetchone()
                    if n:
                        row["newest"], row["newestDate"] = n[0], (n[1] or "")[:10]
                    try:
                        row["sealed"] = c.execute("SELECT COUNT(*) FROM sealed_products").fetchone()[0]
                    except sqlite3.Error:
                        pass
                    m = c.execute("SELECT value FROM meta WHERE key='prices_updated'").fetchone()
                    row["pricesUpdated"] = m[0] if m else ""
                    row["installed"] = row["cards"] > 0
                finally:
                    c.close()
            except sqlite3.Error:
                pass
        out.append(row)
    return {"games": out, "open": svc.vault.game}
