"""Sold history methods (cardvault/sold.py): mark copies sold (one card, many cards, a sell list), the history page with its totals, and a CSV / XLSX export of the sold rows.  Each sale is one undo."""
import csv
import os

from .. import sold
from .registry import ApiError, api

HEAD = ["game", "date sold", "kind", "card_id", "set", "number", "name", "variant", "condition", "grade", "qty", "sale price each", "revenue", "fees", "shipping", "price paid each",
        "grading cost", "cost basis", "realised profit", "where sold", "notes"]


def _undo(svc, fn):
    from .cards import with_undo
    try:
        return with_undo(svc, fn)
    except sold.SoldError as e:
        raise ApiError(str(e))


@api("sold.preview", quiet=True)
def sold_preview(svc, items):
    """The picked things for the Mark sold window: name, how many are owned, today's value of one and what was paid."""
    return {"rows": sold.preview(svc.vault, items or [])}


@api("sold.mark", mutates=True)
def sold_mark(svc, items, day="", place="", fees=0, shipping=0, notes=""):
    """items = [{lot | card | sealed, qty, price (dollars, each)}]; fees and shipping are totals for the whole sale (the screen turns typed amounts into dollars with money.toUsd)."""
    return _undo(svc, lambda: sold.mark(svc.vault, items or [], day, place, fees, shipping, notes))


@api("sold.list", quiet=True)
def sold_list(svc, q="", game="", start="", end="", place=""):
    return sold.listing(svc.vault, q, game, start, end, place)


@api("sold.export")
def sold_export(svc, path, q="", game="", start="", end="", place=""):
    """The sold rows now showing (same filters as the page) as a CSV at `path` and an .xlsx beside it.  A separate file from the collection export, so Import never brings a sold copy back."""
    from . import collectionexport
    svc.need_grant(path)
    r = sold.listing(svc.vault, q, game, start, end, place)
    rows = [[x["game"], x["day"], x["kind"], x["card_id"], x["set"], x["number"], x["name"], x["variant"], x["condition"], x["grade"], x["qty"], x["price"], x["revenue"], x["fee"], x["shipping"],
             "" if x["paid"] is None else x["paid"], x["gradingCost"], "" if x["cost"] is None else x["cost"], "" if x["profit"] is None else x["profit"], x["place"], x["notes"]] for x in r["rows"]]
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(HEAD)
        w.writerows(rows)
    xlsx = collectionexport._xlsx(rows, os.path.splitext(path)[0] + ".xlsx", HEAD, "Sold")
    svc.audit("export", "sold history (CSV" + (" + XLSX)" if xlsx else ")"))
    return {"lines": len(rows), "xlsx": xlsx}
