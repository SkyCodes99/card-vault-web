"""How far a sync has got, for the progress bar at the bottom of the window (ui/src/components/SyncBar.jsx).  Only real counts: bytes of the account's documents received out of what the
account listed for the games being synced, bytes sent out of what was packed to send, photos done out of photos to move.  A step that has no total (asking the account what it holds, the merge
on this device) is reported with total 0 and the bar draws it as a moving segment, never a made-up percent."""
import time

PARTS = ("check", "receive", "send", "photos")


class SyncProgress:
    def __init__(self, emit):
        self._emit = emit
        self.parts = {k: [0, 0] for k in PARTS}           # part -> [done, total]
        self.phase = "check"
        self.sizes = {}                                   # document -> size the account listed
        self._last = 0.0

    def tell(self, force=False):
        now = time.time()
        if not force and now - self._last < 0.1:
            return
        self._last = now
        self._emit("Syncing…", 0, 0, phase=self.phase, parts=[{"key": k, "done": d, "total": t} for k, (d, t) in self.parts.items()])

    def at(self, phase):
        self.phase = phase
        self.tell(True)

    def listed(self, sizes, docs):
        """The account's listing is in: what will be received is the listed size of each game's document."""
        self.sizes = dict(sizes or {})
        self.parts["check"] = [1, 1]
        self.parts["receive"][1] = sum(int(self.sizes.get(d) or 0) for d in docs) or 0
        self.at("receive")

    def hook(self, what, path, n=0):
        """engine.sync_game_steps reports here: 'got' a document, 'skip' one (nothing moved since the last sync), 'pack' n bytes to send, 'put' them, 'merge' on this device."""
        r, s = self.parts["receive"], self.parts["send"]
        size = int(self.sizes.get(path) or 0)
        if what == "got":
            r[0] = min(r[1], r[0] + size)
        elif what == "skip":
            r[1] = max(r[0], r[1] - size)                 # not needed after all: it leaves the total, it is not counted as received
        elif what == "merge":
            self.phase = "merge"
        elif what == "pack":
            s[1] += n
            self.phase = "send"
        elif what == "put":
            s[0] = min(s[1], s[0] + n)
        self.tell(what in ("got", "put"))

    def photos(self, done, total):
        self.parts["photos"] = [done, total]
        self.phase = "photos"
        self.tell(done in (0, total))
