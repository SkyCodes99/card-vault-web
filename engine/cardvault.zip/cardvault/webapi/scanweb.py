"""The browser scanner's lookups.  The recognising itself happens in the page (ui/src/scanweb); this only turns the ids it matched into names, sets, prices and pictures,
and says how many copies the person already owns.  Works the same on the website, the phone and the desktop app."""
from . import cards as cardsapi
from .registry import api


@api("scanweb.describe", quiet=True)
def describe(svc, kind="card", ids=None):
    """kind 'card' | 'sealed'; ids = what the recogniser matched (this game's own ids).  -> one row per id, same order."""
    v = svc.vault
    ids = [str(i) for i in (ids or [])][:300]
    out = []
    if not ids:
        return out
    q = ",".join("?" * len(ids))
    if kind == "sealed":
        got = {r["id"]: r for r in v.conn.execute(f"SELECT id, name, set_name, price_usd, image_base, kind FROM sealed_products WHERE id IN ({q})", ids)}
        for i in ids:
            r = got.get(i)
            out.append({"id": i, "kind": "sealed", "name": r["name"] if r else "Unknown product", "set": (r["set_name"] if r else "") or "", "sub": (r["kind"] if r else "") or "Sealed product",
                        "price": r["price_usd"] if r else None, "thumb": (r["image_base"] or "").replace("_200w", "_400w") if r else "", "owned": 0})
        return out
    got = {r["id"]: r for r in v.conn.execute(
        f"SELECT c.id, c.name, c.local_id, c.set_id, c.rarity, c.price_usd, s.name AS set_name FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id IN ({q})", ids)}
    for i in ids:
        r = got.get(i)
        out.append({"id": i, "kind": "card", "name": r["name"] if r else "Not in your card list", "set": (r["set_name"] if r else "") or "", "number": (r["local_id"] if r else "") or "",
                    "set_id": r["set_id"] if r else "", "rarity": (r["rarity"] if r else "") or "", "price": r["price_usd"] if r else None,
                    "thumb": cardsapi.img(i, r["set_id"]) if r else "", "owned": svc.owned.get(i, 0)})
    return out


@api("scanweb.addSealed", mutates=True)
def add_sealed(svc, items, portfolio=None):
    """Add scanned sealed products.  items = [{name, qty, paid?, source?, purchased?}] -> the same rows the Sealed page makes, in the chosen portfolio."""
    from .extras import sealed_save
    n = 0
    for it in items or []:
        sealed_save(svc, it["name"], qty=int(it.get("qty") or 1), paid=it.get("paid"), purchased=it.get("purchased") or "", source=it.get("source") or "", portfolio=portfolio, notes="Added by the scanner")
        n += int(it.get("qty") or 1)
    return {"ok": True, "added": n}
