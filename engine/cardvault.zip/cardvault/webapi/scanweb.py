"""The browser scanner's lookups.  The recognising itself happens in the page (ui/src/scanweb); this only turns the ids it matched into names, sets, prices and pictures,
and says how many copies the person already owns.  Works the same on the website, the phone and the desktop app."""
import sqlite3

from ..db import picture_url
from . import cards as cardsapi
from .registry import ApiError, api


@api("scanweb.describe", quiet=True)
def describe(svc, kind="card", ids=None):
    """kind 'card' | 'sealed'; ids = what the recogniser matched (this game's own ids).  -> one row per id, same order."""
    v = svc.vault
    ids = [str(i) for i in (ids or [])][:300]
    out = []
    if not ids:
        return out
    q = ",".join("?" * len(ids))
    if kind == "sealed":
        got = {r["id"]: r for r in v.conn.execute(f"SELECT id, name, set_name, price_usd, image_base, kind FROM sealed_products WHERE id IN ({q})", ids)}
        for i in ids:
            r = got.get(i)
            out.append({"id": i, "kind": "sealed", "name": r["name"] if r else "Unknown product", "set": (r["set_name"] if r else "") or "", "sub": (r["kind"] if r else "") or "Sealed product",
                        "price": r["price_usd"] if r else None, "thumb": (r["image_base"] or "").replace("_200w", "_400w") if r else "", "owned": 0})
        return out
    got = {r["id"]: r for r in v.conn.execute(
        f"SELECT c.id, c.name, c.local_id, c.set_id, c.rarity, c.price_usd, s.name AS set_name FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id IN ({q})", ids)}
    for i in ids:
        r = got.get(i)
        out.append({"id": i, "kind": "card", "name": r["name"] if r else "Not in your card list", "set": (r["set_name"] if r else "") or "", "number": (r["local_id"] if r else "") or "",
                    "set_id": r["set_id"] if r else "", "rarity": (r["rarity"] if r else "") or "", "price": r["price_usd"] if r else None,
                    "thumb": cardsapi.img(i, r["set_id"]) if r else "", "owned": svc.owned.get(i, 0)})
    return out


@api("scanweb.games", quiet=True)
def scan_games(svc):
    """The games whose card list is on this device - the ones a scan can look in and add to.  -> [game id]"""
    from . import gamesapi
    from .search import _games
    return [gid for gid, _name, _path in _games(svc) if gamesapi.has_catalog(svc, gid)]


@api("scanweb.printings", quiet=True)
def printings(svc, items):
    """The other printings of recognised cards - the same card in other sets and rarities - for the person to pick the right one.  items = [{game?, id}] (a game left out is the open one).
    -> one answer per item, same order: {id, game, rarities: [easiest pull first], printings: [{id, name, set, setId, number, rarity, variant, price, thumb, owned, released}]} newest set first.
    A game whose card list is not on this device answers with no printings."""
    from . import tradeany
    from .search import _owned
    from .. import cardprintings
    out = []
    for it in (items or [])[:60]:
        game, cid = str((it or {}).get("game") or svc.vault.game), str((it or {}).get("id") or "")
        rows = []
        if cid:
            with tradeany.reader(svc, game) as conn:
                rows = cardprintings.same_card(conn, game, cid)[:80] if conn is not None else []                  # (newest first; a basic land has 700: the rarities offered are those of the printings shown)
        owned, home = _owned(svc, game, [r["id"] for r in rows]), game == svc.vault.game
        out.append({"id": cid, "game": game, "rarities": cardprintings.rarities_of(game, rows), "printings": [
            {"id": r["id"], "name": r["name"], "set": r["set_name"] or "", "setId": r["set_id"], "number": r["local_id"] or "", "rarity": r["rarity"] or "", "price": r["price_usd"],
             "variant": cardprintings.variant_of(game, r["name"], r["rarity"], r["local_id"]), "thumb": cardsapi.img(r["id"], r["set_id"]) if home else picture_url(r["image_base"], "low"),
             "owned": owned.get(r["id"], 0), "released": r["released"] or ""} for r in rows]})
    return out


@api("scanweb.addSealed", mutates=True)
def add_sealed(svc, items, portfolio=None):
    """Add scanned sealed products.  items = [{name, qty, paid?, source?, purchased?, game?, ref?}] (a game left out is the open one; the others are added inside their own game) -> the same rows the Sealed page makes,
    in the chosen portfolio.  -> {added, rows, undo}: `rows` maps each item's `ref` to the row it made, and one Undo takes all of it back."""
    from . import tradeany
    from .extras import _undoable, sealed_save
    home, n, rows, parts = svc.vault.game, 0, {}, []
    for g in dict.fromkeys(it.get("game") or home for it in items or []):
        with tradeany.in_game(svc, g):
            for it in items:
                if (it.get("game") or home) == g:
                    r = _undoable(svc, "Added a scanned sealed product", lambda: sealed_save(svc, it["name"], qty=int(it.get("qty") or 1), paid=it.get("paid"), purchased=it.get("purchased") or "", source=it.get("source") or "", portfolio=portfolio, notes="Added by the scanner"))
                    n += int(it.get("qty") or 1)
                    if it.get("ref") is not None:
                        rows[str(it["ref"])] = r.get("id")
                    if r.get("undo"):
                        parts.append(f"{g}:{r['undo']['id']}")
    if any((it.get("game") or home) != home for it in items or []):
        svc.reload_state()
    return {"ok": True, "added": n, "rows": rows, "undo": {"id": "x:" + ";".join(parts), "label": f"Added {n} from the scanner"} if parts else None}


@api("scanweb.removeAdded", mutates=True)
def remove_added(svc, items):
    """Take scanned items back out later: items = [{game, kind ('card'|'sealed'), lot (the stack a card went into) or row (the sealed row), qty}] - exactly the copies that scan added come off (a stack that held
    other copies keeps them).  -> {removed, undo}; one Undo puts them all back."""
    from . import tradeany
    from .extras import sealed_delete_api
    from .cards import lot_qty
    home, n, parts = svc.vault.game, 0, []
    by = {}
    for it in (items or [])[:300]:
        by.setdefault(it.get("game") or home, []).append(it)
    for g, its in by.items():
        with tradeany.in_game(svc, g):
            for it in its:
                r = sealed_delete_api(svc, id=it["row"]) if it.get("kind") == "sealed" and it.get("row") else lot_qty(svc, it["lot"], -max(1, int(it.get("qty") or 1))) if it.get("lot") is not None else None
                if r:
                    n += max(1, int(it.get("qty") or 1))
                    if r.get("undo"):
                        parts.append(f"{g}:{r['undo']['id']}")
    svc.reload_state()
    return {"ok": True, "removed": n, "undo": {"id": "x:" + ";".join(parts), "label": f"Took back {n} scanned"} if parts else None}


def _sealed_row(svc, game, pid):
    """One sealed product of any game, in the shape `describe` gives for the open game's."""
    from . import tradeany
    from .. import games as games_mod
    row = None
    with tradeany.reader(svc, game) as conn:
        try:
            row = conn.execute("SELECT id, name, set_name, price_usd, image_base, kind FROM sealed_products WHERE id=?", (pid,)).fetchone() if conn is not None and pid else None
        except sqlite3.Error:                                              # (a list with no sealed products at all)
            row = None
    return {"id": pid, "game": game, "gameName": next((x.name for x in games_mod.GAMES if x.id == game), game), "kind": "sealed", "name": row["name"] if row else "Unknown product",
            "set": (row["set_name"] if row else "") or "", "sub": (row["kind"] if row else "") or "Sealed product", "price": row["price_usd"] if row else None,
            "thumb": (row["image_base"] or "").replace("_200w", "_400w") if row else "", "owned": 0}


@api("scanweb.describeAny", quiet=True)
def describe_any(svc, items, kind="card"):
    """Matches that may belong to ANY game (toys, figures, plushies, accessories included): items = [{game, id}] -> one row each (same order) with name, set, rarity, picture, price and how many are owned
    in that game.  kind 'card' (default) | 'sealed'.  A game that is not on this device (or a card that is not in its list) comes back as 'Not in your card list'."""
    from . import tradeany
    out = []
    for it in (items or [])[:300]:
        g, cid = str((it or {}).get("game") or svc.vault.game), str((it or {}).get("id") or "")
        if kind == "sealed":
            out.append(_sealed_row(svc, g, cid))
            continue
        r = tradeany.row_of(svc, g, cid) if cid else None
        out.append({"id": cid, "game": g, "gameName": (r or {}).get("gameName") or g, "kind": "card", "name": r["name"] if r else "Not in your card list", "set": (r or {}).get("set", ""),
                    "number": (r or {}).get("number", ""), "rarity": (r or {}).get("rarity", ""), "price": (r or {}).get("price"), "thumb": (r or {}).get("img", ""), "owned": (r or {}).get("qty", 0)})
    return out


@api("scanweb.addAny", mutates=True)
def add_any(svc, items, portfolio=None):
    """Add scanned items of ANY game: items = [{game, id, qty?, paid?, condition?, source?, purchased?, portfolio?, ref?}] - what is left out is the usual (Near Mint, source 'Scanner', `portfolio` for all).
    Each game's items are added inside that game (the open game is left as it was).  -> {added, undo, lots}; one Undo takes back all of it, and `lots` maps each item's `ref` to the stack it went into
    (a picture of the card can be attached to it)."""
    from . import tradeany
    from .. import games as games_mod
    home = svc.vault.game
    by_game = tradeany.by_game([{**it, "game": it.get("game") or home} for it in (items or [])[:300] if it.get("id")], home)
    added, parts, lots = 0, [], {}
    for g in [home, *[x for x in by_game if x != home]]:
        if g not in by_game:
            continue
        with tradeany.in_game(svc, g):
            for it in by_game[g]:
                if not svc.vault.card_light(str(it["id"])):
                    raise ApiError(f"{it.get('name') or it['id']} isn't in the {next((x.name for x in games_mod.GAMES if x.id == g), g)} list on this device.")
            for it in by_game[g]:
                r = cardsapi.lot_add(svc, id=str(it["id"]), qty=max(1, int(it.get("qty") or 1)), paid=it.get("paid"), condition=it.get("condition") or "Near Mint", source=it.get("source") or "Scanner",
                                     purchased=it.get("purchased") or "", portfolio=it["portfolio"] if it.get("portfolio") else portfolio)
                added += max(1, int(it.get("qty") or 1))
                if it.get("ref") is not None:
                    lots[str(it["ref"])] = r.get("lot")
                if r.get("undo"):
                    parts.append(f"{g}:{r['undo']['id']}")
    svc.reload_state()
    return {"ok": True, "added": added, "lots": lots, "undo": {"id": "x:" + ";".join(parts), "label": f"Added {added} from the scanner"} if parts else None}
