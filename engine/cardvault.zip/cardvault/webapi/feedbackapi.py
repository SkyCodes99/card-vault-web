"""Feedback: anybody signed in can send a suggestion, concern or bug note to the owner; the owner reads them (and marks them seen / done) in Dev Tools > Feedback.
It goes to the account server (nothing is sent anywhere else) and carries a name, never an email."""
from ..cloud import skycloud as sc
from ..version import VERSION
from .accountapi import account
from .registry import ApiError, api

KINDS = ("suggestion", "concern", "bug", "other")


def _call(svc, method, path, body=None):
    a = account(svc)
    if a is None:
        raise ApiError("Sign in to your account first (Settings > Account) - feedback is sent through it, so it cannot be flooded by strangers.", code="no_account")
    try:
        return a.call(method, path, body, timeout=30)
    except sc.CloudError as e:
        if e.status == 404:
            raise ApiError("The server can't take feedback just yet - it arrives with the next server update.")
        raise ApiError(str(e))


@api("feedback.send")
def send(svc, text, kind="suggestion"):
    kind = kind if kind in KINDS else "other"
    text = (text or "").strip()
    if len(text) < 3:
        raise ApiError("Write a few words first.")
    _call(svc, "POST", "/v1/feedback", {"kind": kind, "text": text[:4000], "app": "Collect Em All", "version": VERSION})
    return {"ok": True}


# ---- the owner's inbox (named dev.* so the Dev Tools owner-only rule covers it)
@api("dev.feedback.list", quiet=True)
def inbox(svc):
    return _call(svc, "GET", "/v1/admin/feedback")


@api("dev.feedback.set")
def mark(svc, id, status=None, note=None):
    body = {}
    if status:
        body["status"] = status
    if note is not None:
        body["note"] = note
    return _call(svc, "POST", f"/v1/admin/feedback/{int(id)}", body)


@api("dev.feedback.delete")
def remove(svc, id):
    return _call(svc, "DELETE", f"/v1/admin/feedback/{int(id)}")
