"""Search by cert (slab) number: typing a cert number in either search box puts my graded copies with that number first (cardvault/slabs.py).
search.py wraps its two search calls with first_slabs(); a hit is an ordinary result row plus `slab` = {cert, company, grade, status}."""
import functools
import sqlite3

from .. import slabs


def hits(svc, q, paths, game="", owned=""):
    """Result rows for my graded copies whose cert number matches `q`.  paths = [(game id, name, card list path)] (search._games)."""
    if owned == "no" or svc.vault is None:
        return []
    found = slabs.find(svc.vault, q, game)
    if not found:
        return []
    from .cards import img
    out = []
    for gid, gname, path in paths:
        mine = [f for f in found if f["game"] == gid]
        if not mine:
            continue
        ids = sorted({f["card_id"] for f in mine})
        try:
            c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
            try:
                info = {r[0]: r for r in c.execute("SELECT c.id, c.set_id, c.name, c.local_id, c.rarity, s.name, c.price_usd FROM cards c LEFT JOIN sets s ON s.id=c.set_id "
                                                   f"WHERE c.id IN ({','.join('?' * len(ids))})", ids)}
            finally:
                c.close()
        except sqlite3.Error:
            continue
        for f in mine:
            r = info.get(f["card_id"])
            if r:
                out.append({"game": gid, "gameName": gname, "id": r[0], "set": r[5] or "", "name": r[2], "number": r[3], "rarity": r[4] or "", "img": img(r[0], r[1]) if gid == svc.vault.game else "",
                            "owned": f["qty"], "wish": False, "price": r[6], "installed": True, "slab": {k: f[k] for k in ("cert", "company", "grade", "status")}})
    return out


def first_slabs(paths_of):
    """Decorator for a search call: on the first page, my copies matching a cert number come before the usual results (a card is never listed twice).  paths_of(svc) = search._games."""
    def wrap(fn):
        @functools.wraps(fn)
        def run(svc, *a, **k):
            out = fn(svc, *a, **k)
            q = k.get("q", a[0] if a else "")
            if isinstance(out, dict) and isinstance(out.get("results"), list) and not int(k.get("offset") or 0):
                top = hits(svc, q, paths_of(svc), k.get("game") or "", k.get("owned") or "") if k.get("kinds") != ["sealed"] and k.get("what") != "sealed" else []
                if top:
                    seen = {(r["game"], r["id"]) for r in top}
                    out["results"] = top + [r for r in out["results"] if (r.get("game"), r.get("id")) not in seen]
            return out
        return run
    return wrap
