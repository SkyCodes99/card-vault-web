"""A backup file you keep yourself: everything in your collection (all games, photos, lists, settings) in ONE file, locked with a password you choose.
Works the same on the PC and on the website.  The file is encrypted on this device; the password is never saved or sent anywhere."""
import base64
import json
import os
import sqlite3
import tempfile
import zlib

from .registry import api
from .service import ApiError
from ..security import crypto

MAGIC = b"CEABKP1\n"
PURPOSE = "collect-em-all/backup-file/v1"


def _plain_copy(svc):
    v = svc.vault
    v._commit()
    fd, plain = tempfile.mkstemp(suffix=".db", dir=os.path.dirname(v.user_path))
    os.close(fd)
    src, dest = sqlite3.connect(v.user_path), sqlite3.connect(plain)
    try:
        src.backup(dest)
    finally:
        dest.close()
        src.close()
    return plain


@api("backupfile.create")
def create(svc, path, password):
    """Save the encrypted backup file to `path` (picked with the Save dialog)."""
    problems = crypto.check_password(password, "")
    if problems:
        raise ApiError(problems[0], code="weak_password")
    svc.need_grant(path)
    from .settings import prefs_collect
    plain = _plain_copy(svc)
    try:
        with open(plain, "rb") as f:
            db_bytes = f.read()
    finally:
        crypto.wipe_file(plain)
    head = json.dumps({"app": "Collect Em All", "made": __import__("datetime").datetime.utcnow().isoformat() + "Z", "game": svc.vault.game, "prefs": prefs_collect(svc)}).encode()
    payload = zlib.compress(len(head).to_bytes(4, "big") + head + db_bytes, 6)
    salt = crypto.random_bytes(16)
    blob = MAGIC + salt + crypto.seal(crypto.derive_key(password, salt), payload, PURPOSE)
    tmp = path + ".part"
    with open(tmp, "wb") as f:
        f.write(blob)
    os.replace(tmp, path)
    svc.audit("backup_file_saved", "")
    return {"bytes": len(blob)}


@api("backupfile.restore", mutates=True)
def restore(svc, data, password):
    """Replace this profile's collection with a backup file (sent as base64).  A safety copy of the current collection is kept first."""
    try:
        blob = base64.b64decode(data.encode("ascii"))
    except Exception:  # noqa: BLE001
        raise ApiError("That file couldn't be read.")
    if blob[:len(MAGIC)] != MAGIC:
        raise ApiError("That is not a Collect Em All backup file.")
    salt, sealed = blob[len(MAGIC):len(MAGIC) + 16], blob[len(MAGIC) + 16:]
    try:
        payload = zlib.decompress(crypto.open_sealed(crypto.derive_key(password, salt), sealed, PURPOSE))
    except crypto.CryptoError:
        raise ApiError("Wrong password - or the file is damaged.", code="wrong_password")
    n = int.from_bytes(payload[:4], "big")
    head, db_bytes = json.loads(payload[4:4 + n]), payload[4 + n:]
    v = svc.vault
    fd, plain = tempfile.mkstemp(suffix=".db", dir=os.path.dirname(v.user_path))
    os.close(fd)
    try:
        with open(plain, "wb") as f:
            f.write(db_bytes)
        c = sqlite3.connect(plain)
        try:
            ok = c.execute("PRAGMA integrity_check").fetchone()[0] == "ok" and c.execute("SELECT 1 FROM sqlite_master WHERE name='lots'").fetchone()
        finally:
            c.close()
        if not ok:
            raise ApiError("That backup is damaged, so nothing was changed.")
        v.restore_collection(plain)
    finally:
        crypto.wipe_file(plain)
    v.invalidate_index()
    svc.reload_state()
    svc.audit("backup_file_restored", "")
    return {"ok": True, "made": head.get("made", "")}
