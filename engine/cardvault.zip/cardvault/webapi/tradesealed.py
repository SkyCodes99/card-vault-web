"""Sealed products in a trade: search the sealed list (with how many you own), and move them in / out of the collection when the trade is completed."""
from .. import sealedclass
from ..db import new_uuid, now_iso, today
from ..tcgcsv import norm_name
from . import sealedcat
from .listsealed import _owned
from .registry import api
from .service import ApiError


@api("trade.sealed", quiet=True)
def trade_sealed(svc, q="", owned_only=False, limit=40):
    rows = sealedcat._all(svc) or []
    words = norm_name(q).split()
    have = _owned(svc, anywhere=True)
    out = []
    for r in rows:
        if r["kind"] in sealedcat.LOOSE_KINDS:
            continue
        n = have.get(r["norm"] or "", 0)
        if owned_only and not n:
            continue
        if words and not all(w in ((r["norm"] or "") + " " + sealedcat.norm_name(r.get("set") or "")) for w in words):          # the set's name counts too
            continue
        out.append({"id": r["id"], "name": r["name"], "img": r["img"], "price": r["price"], "kind": r["kind"], "set": r["set"], "have": n})
        if len(out) >= int(limit):
            break
    return out


def check_give(svc, items):
    """The sealed products offered must be owned (enough of them)."""
    have = _owned(svc, anywhere=True)
    for m in items or []:
        if m.get("sealed") and have.get(norm_name(m.get("name") or ""), 0) < int(m.get("qty") or 1):
            raise ApiError(f"You don't own enough of: {m.get('name')}")


def apply_sealed(svc, give, get):
    """Hand over the sealed products you give (from the portfolios that hold them) and add the ones you get to the portfolio you are adding to."""
    v = svc.vault
    for m in give or []:
        if not m.get("sealed"):
            continue
        left, key = int(m.get("qty") or 1), norm_name(m.get("name") or "")
        for r in v.conn.execute("SELECT uuid, name, qty FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY qty DESC", (v.user_id, v.game)).fetchall():
            if left <= 0:
                break
            if norm_name(r["name"]) != key:
                continue
            take = min(left, r["qty"] or 0)
            if take >= (r["qty"] or 0):
                v.conn.execute("UPDATE u.sealed SET deleted=1, qty=0, updated_at=? WHERE uuid=?", (now_iso(), r["uuid"]))
            else:
                v.conn.execute("UPDATE u.sealed SET qty=qty-?, updated_at=? WHERE uuid=?", (take, now_iso(), r["uuid"]))
            left -= take
    for m in get or []:
        if not m.get("sealed"):
            continue
        v.check_accepts(v.target_pf, "sealed")
        v.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                       (new_uuid(), v.user_id, v.game, "", m.get("name"), int(m.get("qty") or 1), m.get("price"), today(), "Trade", "", v.target_pf, now_iso()))
    v._commit()
    try:
        v.record_sealed_history()
    except Exception:  # noqa: BLE001
        pass
