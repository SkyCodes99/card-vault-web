"""Kept value graphs (valuegraph.py) worked out again in the background, a short step at a time, so the home page graph is ready before it is asked for and a click never waits behind
seconds of graph work.  The browser build takes a step whenever the engine is free (scheduler.work); the desktop's scheduler thread takes them one per turn of the engine.
  - want(): a graph a screen asked for that is out of date or not kept yet (the newest asked comes first);
  - recent(): the graphs kept last, and every portfolio for the range and way last looked at, when the collection or its prices have changed (after start-up, after a change, a new day);
  - step(): the next short step; the answer is kept only if nothing it was built from changed meanwhile (else it is worked out again);
  - quiet(): whether a step may run now - never while somebody is clicking or a question was just asked (a screen waiting for its graph only needs a short gap between questions).
A step stops between two pieces as soon as a question is waiting (busy), so a click waits for one piece at most."""
import json
import time

from .. import graphcache
from . import valuegraph

STEP = 0.08                    # seconds of work per step at most (one part of the price changes is a few hundredths of a second)
RECENT = 12                    # graphs kept up to date in the background at most
QUIET = 1.5                    # seconds with no question before background graph work (nobody is waiting for a graph)
GAP = 0.3                      # seconds since the last question when a screen IS waiting for its graph
WANTED = 10                    # seconds a screen's question for a graph counts as waiting for it


def _box(svc):
    return svc.__dict__.setdefault("_graphwarm", {"todo": [], "cur": None})


def want(svc, key, first=False):
    """Queue a graph; first=True: a screen asked for it (it goes first, and its steps need only a short gap between questions)."""
    v, todo = svc.vault, _box(svc)["todo"]
    if first:
        svc._graph_wanted = time.time()
    todo[:] = [t for t in todo if t[1] != key]
    todo.insert(0, (v, key)) if first else todo.append((v, key))


def pending(svc):
    b = _box(svc)
    return bool(b["todo"] or b["cur"])


def quiet(svc, now=None):
    """Whether background graph work may take a step now."""
    now = now or time.time()
    since = now - max(getattr(svc, "last_call", 0), getattr(svc, "last_activity", 0))
    return since >= QUIET or (now - getattr(svc, "_graph_wanted", 0) < WANTED and since >= GAP)


def recent(svc):
    """Queue the kept graphs that are out of date: the newest kept ones, then every portfolio for the newest kept range and way.  -> how many were queued."""
    v = svc.vault
    if v is None or pending(svc):
        return 0
    keys = [k for k in graphcache.newest(v) if valuegraph.args_of(k) and json.loads(k)[0] == v.user_id]
    if keys:
        _pf, rk, start, end, mode = valuegraph.args_of(keys[0])
        for pf in ["all"] + [p["uuid"] for p in v.portfolios()] + [valuegraph.MAIN]:
            k = valuegraph.key_of(v, pf, rk, start, end, mode)
            if k not in keys:
                keys.append(k)
    now = valuegraph.stamp(v, svc)
    n = 0
    for k in keys[:RECENT]:
        e = graphcache.get(v, k)
        if not e or e["stamp"] != now:
            want(svc, k)
            n += 1
    return n


def step(svc, budget=STEP, busy=None):
    """The next short step of background graph work.  busy() -> True when a question is waiting: the step stops after the piece it is on.  -> True while there is more."""
    b = _box(svc)
    v = svc.vault
    if b["cur"] is None:
        while b["todo"]:
            tv, key = b["todo"].pop(0)
            if tv is not v or v is None:
                continue                                                    # (another game or account since)
            now = valuegraph.stamp(v, svc)
            e = graphcache.get(v, key)
            if e and e["stamp"] == now:
                continue                                                    # (already up to date)
            pf, rk, start, end, mode = valuegraph.args_of(key)
            b["cur"] = (v, key, now, valuegraph.build_steps(svc, pf, rk, start, end, mode))
            break
        else:
            return False
    cv, key, at, gen = b["cur"]
    if cv is not v:
        b["cur"] = None
        return pending(svc)
    t0 = time.perf_counter()
    try:
        while True:
            t = time.perf_counter()
            next(gen)
            now = time.perf_counter()
            if now - t0 + (now - t) >= budget or (busy and busy()):         # (another piece as long as the last one would go over, or a question is waiting: stop here)
                return True
    except StopIteration as e:
        b["cur"] = None
        if valuegraph.stamp(v, svc) == at:
            graphcache.put(v, key, at, e.value)
        else:
            want(svc, key)                                                  # (something changed while it was worked out: again, with the change)
    except Exception:                                                       # noqa: BLE001 - a graph that cannot be worked out is not asked again until a screen asks for it
        b["cur"] = None
        raise
    return pending(svc)


def finish(svc):
    """Every waiting graph, now (tests; a caller that must have them done)."""
    while step(svc, budget=60):
        pass
