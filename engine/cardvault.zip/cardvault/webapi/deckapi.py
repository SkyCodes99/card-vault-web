"""The deck builder's methods (cardvault/decks.py and friends): list, open, make, rename, copy and delete decks, change counts, search cards to add, check what you own and what's missing,
check the rules of a format, stats, and decklists as text (copy out / paste in).  Every change is ONE Undo."""
from .. import deckcards, decklist, deckown, deckrules, decks, deckstats, deckzones
from .cards import img, with_undo
from .registry import api
from .service import ApiError
from .undoext import undoable


def _spec(v):
    return [("decks", "user_id=? AND game=?", (v.user_id, v.game))]


def _do(svc, label, fn):
    try:
        return undoable(svc, label, fn, rows=_spec(svc.vault))
    except decks.DeckError as e:
        raise ApiError(str(e))


def _supported(v):
    if v.game not in decks.GAMES:
        raise ApiError(decks.NOT_READY)


def _deck(v, id):
    try:
        return decks.get(v, id)
    except decks.DeckError as e:
        raise ApiError(str(e))


@api("deck.list", quiet=True)
def deck_list(svc):
    v = svc.vault
    ok = v.game in decks.GAMES
    rows = decks.all_decks(v) if ok else []
    info = deckcards.info_for(v, {deckzones.zone_of(c)[1] for d in rows for c in d["cards"]}) if rows else {}
    fmts = deckrules.formats(v.game)
    out = []
    for d in rows:
        lead = next((info[deckzones.zone_of(c)[1]]["name"] for c in d["cards"] if deckzones.zone_of(c)[1] in info and info[deckzones.zone_of(c)[1]]["section"] == "Leader"), "")
        fmt = d["fmt"] or (fmts[0][0] if fmts else "")
        lo, hi = deckrules.sizes(v.game, fmt)
        out.append({"id": d["id"], "name": d["name"], "fmt": d["fmt"], "count": deckrules.main_count(v.game, d["cards"], info), "leader": lead, "updated": d["updated"], "min": lo, "max": hi})
    lo, hi = deckrules.sizes(v.game, fmts[0][0] if fmts else "")
    return {"supported": ok, "game": v.game, "decks": out, "formats": [{"k": k, "label": lb} for k, lb in fmts], "size": hi or lo, "min": lo, "max": hi}


@api("deck.get", quiet=True)
def deck_get(svc, id):
    """Everything the builder screen shows for one deck: the cards by group, what you own and what's missing, the rules check and the stats."""
    v = svc.vault
    _supported(v)
    d = _deck(v, id)
    flat = deckzones.flat(d["cards"])
    info = deckcards.info_for(v, flat)
    own = deckown.check(v, flat, info)
    by_id = {r["id"]: r for r in own["rows"]}
    cards = []
    for key, n in d["cards"].items():
        zone, cid = deckzones.zone_of(key)
        c = info.get(cid)
        if not c:
            cards.append({"id": cid, "key": key, "zone": zone, "name": "Card no longer in the list", "section": "Other", "group": "other", "count": n, "missing": True, "gone": True,
                          "set": "", "number": "", "img": "", "inSize": False, "have": 0, "owned": 0, "price": None, "colors": []})          # (every field a card row has: the screen shows a note, not 'you own {n}')
            continue
        o = by_id.get(cid, {})
        cards.append({"id": cid, "key": key, "zone": zone, "name": c["name"], "set": c["set_name"], "number": c["number"], "section": c["section"], "count": n, "img": img(cid, c["set_id"]),
                      "group": deckcards.group_id(v.game, c, zone), "inSize": _in_size(v.game, c, zone),
                      "cost": c.get("cost"), "mark": c.get("mark", ""), "colors": c["colors"], "have": o.get("have", 0), "owned": o.get("owned", 0), "price": o.get("price")})
    order = {s: i for i, s in enumerate(deckcards.sections(v.game))}
    gorder = {g: i for i, (g, _) in enumerate(deckcards.groups(v.game))}
    cards.sort(key=lambda x: (gorder.get(x.get("group"), 0), order.get(x["section"], 99), x.get("cost") if x.get("cost") is not None else 99, x["name"]))
    fmts = deckrules.formats(v.game)
    lo, hi = deckrules.sizes(v.game, d["fmt"] or (fmts[0][0] if fmts else ""))
    return {"id": d["id"], "name": d["name"], "fmt": d["fmt"], "game": v.game, "cards": cards, "sections": list(deckcards.sections(v.game)), "zones": list(deckzones.zones_for(v.game)),
            "groups": [{"id": g, "k": lb} for g, lb in deckcards.groups(v.game)], "min": lo, "max": hi, "size": hi or lo,
            "own": {k: own[k] for k in ("need", "have", "missing", "cost", "noPrice")}, "missingRows": [r for r in own["rows"] if r["missing"]],
            "legal": deckrules.check(v, d["cards"], info), "stats": deckstats.stats(v.game, d["cards"], info)}


def _in_size(game, c, zone):
    """Does this line count toward the deck's size (not the Leader / DON!!, the Extra Deck or the side deck)?"""
    if zone == "side":
        return False
    return c["section"] not in deckcards.NOT_IN_SIZE and not (game == "yugioh" and c["section"] == "Extra Deck")


@api("deck.search", quiet=True)
def deck_search(svc, text, limit=24):
    """Cards to add: by name, or by card number (OP01-001, 'SVI 57')."""
    v = svc.vault
    t = (text or "").strip()
    if len(t) < 2:
        return {"results": []}
    ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE UPPER(local_id)=? LIMIT ?", (t.upper(), limit))]
    ids += [r[0] for r in v.query_cards(text=t)[: max(0, limit - len(ids))] if r[0] not in ids]
    info = deckcards.info_for(v, ids)
    return {"results": [{"id": i, "name": info[i]["name"], "set": info[i]["set_name"], "number": info[i]["number"], "section": info[i]["section"], "img": img(i, info[i]["set_id"]),
                         "owned": svc.owned.get(i, 0), "cost": info[i].get("cost"), "colors": info[i]["colors"]} for i in ids if i in info]}


@api("deck.create", mutates=True)
def deck_create(svc, name, fmt=""):
    _supported(svc.vault)
    box = {}
    out = _do(svc, f"Made the deck '{(name or '').strip()[:40]}'", lambda: box.setdefault("id", decks.create(svc.vault, name, fmt)))
    return {**out, "id": box.get("id")}


@api("deck.rename", mutates=True)
def deck_rename(svc, id, name):
    return _do(svc, f"Renamed a deck to '{(name or '').strip()[:40]}'", lambda: decks.rename(svc.vault, id, name))


@api("deck.setFormat", mutates=True)
def deck_set_format(svc, id, fmt):
    return _do(svc, "Changed a deck's format", lambda: decks.set_format(svc.vault, id, fmt))


@api("deck.duplicate", mutates=True)
def deck_duplicate(svc, id):
    box = {}
    out = _do(svc, f"Copied the deck '{_deck(svc.vault, id)['name']}'", lambda: box.setdefault("id", decks.duplicate(svc.vault, id)))
    return {**out, "id": box.get("id")}


@api("deck.delete", mutates=True)
def deck_delete(svc, id):
    return _do(svc, f"Deleted the deck '{_deck(svc.vault, id)['name']}'", lambda: decks.remove(svc.vault, id))


@api("deck.count", mutates=True)
def deck_count(svc, id, card, delta=None, count=None, zone="main"):
    v = svc.vault
    c = v.card_basic(card) or {}
    box = {}
    out = _do(svc, f"Changed {c.get('name', 'a card')} in a deck", lambda: box.setdefault("n", decks.change_count(v, id, card, delta=delta, count=count, zone=zone)))
    return {**out, "count": box.get("n", 0)}


@api("deck.move", mutates=True)
def deck_move(svc, id, card, src, dst, n=1):
    """Moves copies of a card between the deck's parts (main / side / commander) - ONE undo."""
    v = svc.vault
    c = v.card_basic(card) or {}
    box = {}
    out = _do(svc, f"Moved {c.get('name', 'a card')} in a deck", lambda: box.setdefault("n", decks.move(v, id, card, src, dst, n)))
    return {**out, "moved": box.get("n", 0)}


@api("deck.export", quiet=True)
def deck_export(svc, id):
    v = svc.vault
    d = _deck(v, id)
    return {"text": decklist.export(v.game, d["cards"], deckcards.info_for(v, deckzones.flat(d["cards"])), v)}


@api("deck.import", mutates=True)
def deck_import(svc, text, id=None, name="", add=False):
    """Paste a decklist: a new deck (no id), the deck's cards replaced (id), or the lines added to it (id + add: fixing the lines that didn't match).  The unmatched lines come back."""
    v = svc.vault
    _supported(v)
    got = decklist.parse(v, text)
    if not got["lines"]:
        raise ApiError("I couldn't find any card lines. Paste one card per line, like '4 Pikachu ex SVI 57' or '4xOP01-001'.")
    if id and not add and not got["cards"]:
        raise ApiError("None of these lines matched a card in this game, so the deck was left as it was.")          # (replacing with nothing would empty the deck)
    box = {}

    def run():
        cur = decks.get(v, id)["cards"] if id and add else {}
        for cid, n in got["cards"].items():
            cur[cid] = cur.get(cid, 0) + n
        box["over"] = sum(max(0, n - decks.MAX_COPIES_STORED) for n in cur.values())          # (one card is kept at most MAX_COPIES_STORED times: say how many did not fit)
        if not id:
            box["id"] = decks.create(v, name or "Pasted deck", "", cur)
            return
        decks.set_cards(v, id, cur)
        box["id"] = id
    out = _do(svc, "Pasted a decklist", run)
    over = box.get("over", 0)
    return {**out, "id": box.get("id"), "unmatched": got["unmatched"], "matched": sum(got["cards"].values()) - over, "clipped": over}


@api("deck.wishMissing", mutates=True)
def deck_wish_missing(svc, id):
    """Every card the deck is still missing goes on the wishlist (ONE undo).  -> how many were added."""
    v = svc.vault
    d = _deck(v, id)
    flat = deckzones.flat(d["cards"])
    own = deckown.check(v, flat, deckcards.info_for(v, flat))
    have = v.wishlist_ids()
    todo = [r["id"] for r in own["rows"] if r["missing"] and r["id"] not in have]

    def run():
        if todo:
            with v.action(f"Added {len(todo)} missing card{'' if len(todo) == 1 else 's'} of '{d['name']}' to the wishlist"):
                for cid in todo:
                    v.toggle_wishlist(cid)
                v.record_price_history(todo)
        return {"added": len(todo)}
    return with_undo(svc, run)
