"""The card scanner tab: photos / camera pictures are sent to the Card Scanner engine that runs on this computer (a separate add-on, because it brings its own
AI model), and what it recognises can then be added to any portfolio.  The engine is started and stopped by the app; nothing leaves this computer."""
import atexit
import base64
import json
import os
import secrets
import subprocess
import sys
import threading

from .. import runtime
from . import cloudapi
from .registry import ApiError, api

STATE = {"proc": None, "url": "", "pin": "", "version": "", "cards": 0, "status": "stopped", "error": ""}
EXE = "CardScannerApp.exe"
ADDON_PREFIX = "CollectEmAll-scanner-win64"
_lock = threading.Lock()


def _candidates(svc):
    home = os.path.expanduser("~")
    app = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else ""
    out = [svc.cfg.get("scanner_path") or "", os.path.join(svc.cfg["data_dir"], "scanner", EXE), os.path.join(app, "scanner", EXE) if app else "",
           os.path.join(home, "Desktop", "Claude Projects", "Card Scanner Files", EXE), os.path.join(home, "CardScanner", "build_out", "CardScannerApp", EXE)]
    return [p for p in out if p]


def find_exe(svc):
    if not sys.platform.startswith("win") or runtime.IN_BROWSER:
        return ""
    for p in _candidates(svc):
        if os.path.isfile(p):
            return p
    return ""


def _stop():
    p = STATE.get("proc")
    STATE["proc"] = None
    STATE.update(status="stopped", url="")
    if p and p.poll() is None:
        try:
            p.stdin.write(b"STOP\n")
            p.stdin.flush()
        except OSError:
            pass
        try:
            p.wait(5)
        except subprocess.TimeoutExpired:
            p.kill()


atexit.register(_stop)


def _write_scanner_config(svc):
    """Point the scanner at this app's card pictures (its own settings file)."""
    folder = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Card Scanner")
    path = os.path.join(folder, "config.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg["vault_dir"] = svc.cfg["data_dir"]
    try:
        os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass


@api("scanner.status", quiet=True)
def status(svc):
    p = STATE.get("proc")
    alive = bool(p and p.poll() is None)
    if not alive and STATE["status"] == "running":
        STATE.update(status="stopped", url="")
    exe = find_exe(svc)
    return {"platform": "browser" if runtime.IN_BROWSER else sys.platform, "installed": bool(exe), "path": exe, "status": STATE["status"], "running": alive and STATE["status"] == "running",
            "version": STATE["version"], "cards": STATE["cards"], "error": STATE["error"], "windows": sys.platform.startswith("win") and not runtime.IN_BROWSER}


@api("scanner.start")
def start(svc):
    exe = find_exe(svc)
    if not exe:
        raise ApiError("The scanner add-on isn't installed yet.")
    if STATE["status"] in ("running", "starting"):
        return {"job": None}

    def run(emit, cancel):
        with _lock:
            STATE.update(status="starting", error="")
            emit("Starting the scanner…", 0, 0)
            _write_scanner_config(svc)
            pin = "".join(secrets.choice("0123456789") for _ in range(6))
            kw = {"creationflags": 0x08000000} if sys.platform.startswith("win") else {}
            proc = subprocess.Popen([exe, "--serve", "--port", "8791", "--pin", pin, "--read-only"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    cwd=os.path.dirname(exe), **kw)
            STATE["proc"] = proc
            for raw in proc.stdout:
                line = raw.decode("utf-8", "replace").strip()
                if line.startswith("STATUS"):
                    emit(line[7:] or "Learning your card pictures…", 0, 0)
                elif line.startswith("READY"):
                    info = json.loads(line[6:])
                    STATE.update(status="running", url=info["url"].rstrip("/"), pin=info["pin"], version=info.get("version", ""), cards=info.get("cards", 0))
                    return {"ok": True}
                elif line.startswith("ERROR"):
                    STATE.update(status="stopped", error=line[6:])
                    raise RuntimeError(line[6:])
                if cancel.is_set():
                    _stop()
                    break
            STATE.update(status="stopped", error=STATE["error"] or "The scanner stopped unexpectedly.")
            raise RuntimeError(STATE["error"])
    j = svc.jobs.start("scanner", "Starting the card scanner", run)
    return {"job": j.id}


@api("scanner.stop")
def stop(svc):
    _stop()
    return {"ok": True}


@api("scanner.scan")
def scan(svc, image, mode="one"):
    """image = a JPEG as base64.  -> the cards it found (best guess + alternatives), with what you already own."""
    import requests
    if STATE["status"] != "running":
        raise ApiError("The scanner isn't running. Press Start scanner first.")
    try:
        data = base64.b64decode(image.split(",", 1)[-1])
    except ValueError:
        raise ApiError("That isn't a picture.")
    try:
        r = requests.post(f"{STATE['url']}/api/scan?mode={'many' if mode == 'many' else 'one'}", data=data, headers={"X-PIN": STATE["pin"], "Content-Type": "image/jpeg"}, timeout=180)
    except requests.RequestException:
        STATE["status"] = "stopped"
        raise ApiError("The scanner stopped answering - start it again.")
    if r.status_code != 200:
        raise ApiError(r.json().get("error", "The scanner couldn't read that picture.") if r.headers.get("content-type", "").startswith("application/json") else "Scan failed.")
    out = r.json()
    for c in out.get("cards", []):
        c["owned"] = svc.owned.get(c["card_id"], 0)
        light = svc.vault.card_light(c["card_id"]) or {}
        c["set_id"] = light.get("set_id", "")
    return out


@api("scanner.install")
def install(svc):
    """Download the scanner add-on from the releases page (checksum verified) into the data folder."""
    from .. import updater
    if not sys.platform.startswith("win"):
        raise ApiError("The scanner add-on is for Windows.")
    tok, _ = cloudapi.token(svc)
    repo = svc.cfg.get("update_repo") or updater.UPDATE_REPO

    def run(emit, cancel):
        import hashlib
        import tempfile
        import zipfile
        import requests
        emit("Looking for the scanner add-on…", 0, 0)
        hdr = {"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json"} if tok else {"Accept": "application/vnd.github+json"}
        rel = None
        for r in requests.get(f"https://api.github.com/repos/{repo}/releases?per_page=30", headers=hdr, timeout=30).json():
            if any(a["name"].startswith(ADDON_PREFIX) and a["name"].endswith(".zip") for a in r.get("assets", [])):
                rel = r
                break
        if not rel:
            raise RuntimeError("The scanner add-on hasn't been published yet.")
        asset = next(a for a in rel["assets"] if a["name"].startswith(ADDON_PREFIX) and a["name"].endswith(".zip"))
        side = next((a for a in rel["assets"] if a["name"] == asset["name"] + ".sha256"), None)
        want = ""
        if side:
            want = requests.get(side["url"], headers={**hdr, "Accept": "application/octet-stream"}, timeout=30).text.split()[0].lower()
        if not want:
            raise RuntimeError("The add-on has no checksum file, so it was not installed.")
        tmp = os.path.join(tempfile.mkdtemp(prefix="cea_scanner_"), "addon.zip")
        h = hashlib.sha256()
        with requests.get(asset["url"], headers={**hdr, "Accept": "application/octet-stream"}, stream=True, timeout=60) as resp, open(tmp, "wb") as f:
            total, done = int(asset.get("size") or 0), 0
            for chunk in resp.iter_content(1 << 20):
                f.write(chunk)
                h.update(chunk)
                done += len(chunk)
                emit("Downloading the scanner add-on…", done, total)
                if cancel.is_set():
                    raise RuntimeError("Stopped.")
        if h.hexdigest() != want:
            raise RuntimeError("The download didn't match its checksum and was discarded.")
        dest = os.path.join(svc.cfg["data_dir"], "scanner")
        emit("Unpacking…", 0, 0)
        root = os.path.realpath(dest)
        os.makedirs(dest, exist_ok=True)
        with zipfile.ZipFile(tmp) as z:
            for info in z.infolist():
                target = os.path.realpath(os.path.join(dest, info.filename))
                if os.path.isabs(info.filename) or not (target == root or target.startswith(root + os.sep)):
                    raise RuntimeError("The add-on contains an unsafe path and was refused.")
            z.extractall(dest)
        return {"ok": True}
    j = svc.jobs.start("scanner-install", "Installing the scanner add-on", run)
    return {"job": j.id}
