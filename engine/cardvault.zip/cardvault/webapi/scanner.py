"""The card scanner tab: photos / camera pictures are sent to the Card Scanner engine that runs on this computer (a separate add-on, because it brings its own
AI model), and what it recognises can then be added to any portfolio.  The engine is started and stopped by the app; nothing leaves this computer."""
import atexit
import base64
import json
import os
import re
import secrets
import subprocess
import sys
import threading

from .. import runtime
from . import cloudapi
from .registry import ApiError, api

STATE = {"proc": None, "url": "", "pin": "", "version": "", "cards": 0, "status": "stopped", "error": ""}
EXE = "CardScannerApp.exe"
ADDON_PREFIX = "CollectEmAll-scanner-win64"
SCANNER_REPO = "SkyCodes99/card-scanner"           # the Card Scanner project: publishing a release there is how this app gets scanner updates
_lock = threading.Lock()


def _addon_dir(svc):
    return os.path.join(svc.cfg["data_dir"], "scanner")


def _addon_current(svc):
    """The newest installed add-on: <data>/scanner/versions/<ver>/ (several versions live side by side; current.txt names the one to use)."""
    try:
        with open(os.path.join(_addon_dir(svc), "current.txt"), encoding="utf-8") as f:
            name = f.read().strip()
        return os.path.join(_addon_dir(svc), "versions", name, EXE) if name else ""
    except OSError:
        return ""


def installed_version(svc):
    p = _addon_current(svc)
    return os.path.basename(os.path.dirname(p)) if p and os.path.isfile(p) else ""


def _vkey(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4]) or (0,)


def latest_release(svc):
    """The newest published scanner add-on across the scanner's own repository and this app's releases -> (version, asset, sha asset, headers) or None."""
    import requests
    from . import cloudapi
    from .. import updater
    tok, _ = cloudapi.token(svc)
    hdr = {"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json"} if tok else {"Accept": "application/vnd.github+json"}
    best = None
    for repo in dict.fromkeys([svc.cfg.get("scanner_repo") or SCANNER_REPO, svc.cfg.get("update_repo") or updater.UPDATE_REPO]):
        try:
            rels = requests.get(f"https://api.github.com/repos/{repo}/releases?per_page=30", headers=hdr, timeout=30).json()
        except (requests.RequestException, ValueError):
            continue
        for r in rels if isinstance(rels, list) else []:
            for a in r.get("assets", []):
                m = re.match(re.escape(ADDON_PREFIX) + r"-([\d.]+)\.zip$", a["name"])
                if m and (best is None or _vkey(m.group(1)) > _vkey(best[0])):
                    best = (m.group(1), a, next((x for x in r["assets"] if x["name"] == a["name"] + ".sha256"), None), hdr)
    return best


def _candidates(svc):
    home = os.path.expanduser("~")
    app = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else ""
    files = os.path.join(home, "Desktop", "Claude Projects", "Card Scanner Files")
    current = ""
    try:                                   # Card Scanner 2.3+ installs side by side: versions\<version>\ and current.txt names the newest
        with open(os.path.join(files, "current.txt"), "r", encoding="utf-8") as f:
            name = f.read().strip()
        current = os.path.join(files, "versions", name, EXE) if name else ""
    except OSError:
        pass
    out = [svc.cfg.get("scanner_path") or "", _addon_current(svc), os.path.join(svc.cfg["data_dir"], "scanner", EXE), os.path.join(app, "scanner", EXE) if app else "",
           current, os.path.join(files, EXE), os.path.join(home, "CardScanner", "build_out", "CardScannerApp", EXE)]
    return [p for p in out if p]


def find_exe(svc):
    if not sys.platform.startswith("win") or runtime.IN_BROWSER:
        return ""
    for p in _candidates(svc):
        if os.path.isfile(p):
            return p
    return ""


def _stop():
    p = STATE.get("proc")
    STATE["proc"] = None
    STATE.update(status="stopped", url="")
    if p and p.poll() is None:
        try:
            p.stdin.write(b"STOP\n")
            p.stdin.flush()
        except OSError:
            pass
        try:
            p.wait(5)
        except subprocess.TimeoutExpired:
            p.kill()


atexit.register(_stop)


def _write_scanner_config(svc):
    """Point the scanner at this app's card pictures (its own settings file)."""
    folder = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Card Scanner")
    path = os.path.join(folder, "config.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg["vault_dir"] = svc.cfg["data_dir"]
    try:
        os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass


@api("scanner.status", quiet=True)
def status(svc):
    if runtime.IN_BROWSER:                 # the add-on is a Windows program: nothing to look for (and nothing to poll) in the browser
        return {"platform": "browser", "installed": False, "path": "", "status": "stopped", "running": False, "installedVersion": "", "latest": "", "updateAvailable": False,
                "version": "", "cards": 0, "error": "", "windows": False}
    p = STATE.get("proc")
    alive = bool(p and p.poll() is None)
    if not alive and STATE["status"] == "running":
        STATE.update(status="stopped", url="")
    exe = find_exe(svc)
    return {"platform": "browser" if runtime.IN_BROWSER else sys.platform, "installed": bool(exe), "path": exe, "status": STATE["status"], "running": alive and STATE["status"] == "running",
            "installedVersion": installed_version(svc), "latest": STATE.get("latest", ""), "updateAvailable": bool(STATE.get("latest") and installed_version(svc) and _vkey(STATE["latest"]) > _vkey(installed_version(svc))),
            "version": STATE["version"], "cards": STATE["cards"], "error": STATE["error"], "windows": sys.platform.startswith("win") and not runtime.IN_BROWSER}


@api("scanner.start")
def start(svc):
    exe = find_exe(svc)
    if not exe:
        raise ApiError("The scanner add-on isn't installed yet.")
    if STATE["status"] in ("running", "starting"):
        return {"job": None}

    def run(emit, cancel):
        with _lock:
            STATE.update(status="starting", error="")
            emit("Starting the scanner…", 0, 0)
            _write_scanner_config(svc)
            pin = "".join(secrets.choice("0123456789") for _ in range(6))
            kw = {"creationflags": 0x08000000} if sys.platform.startswith("win") else {}
            proc = subprocess.Popen([exe, "--serve", "--port", "8791", "--pin", pin, "--read-only"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    cwd=os.path.dirname(exe), **kw)
            STATE["proc"] = proc
            for raw in proc.stdout:
                line = raw.decode("utf-8", "replace").strip()
                if line.startswith("STATUS"):
                    emit(line[7:] or "Learning your card pictures…", 0, 0)
                elif line.startswith("READY"):
                    info = json.loads(line[6:])
                    STATE.update(status="running", url=info["url"].rstrip("/"), pin=info["pin"], version=info.get("version", ""), cards=info.get("cards", 0))
                    return {"ok": True}
                elif line.startswith("ERROR"):
                    STATE.update(status="stopped", error=line[6:])
                    raise RuntimeError(line[6:])
                if cancel.is_set():
                    _stop()
                    break
            STATE.update(status="stopped", error=STATE["error"] or "The scanner stopped unexpectedly.")
            raise RuntimeError(STATE["error"])
    j = svc.jobs.start("scanner", "Starting the card scanner", run)
    return {"job": j.id}


@api("scanner.stop")
def stop(svc):
    _stop()
    return {"ok": True}


@api("scanner.scan")
def scan(svc, image, mode="one"):
    """image = a JPEG as base64.  -> the cards it found (best guess + alternatives), with what you already own."""
    import requests
    if STATE["status"] != "running":
        raise ApiError("The scanner isn't running. Press Start scanner first.")
    try:
        data = base64.b64decode(image.split(",", 1)[-1])
    except ValueError:
        raise ApiError("That isn't a picture.")
    try:
        r = requests.post(f"{STATE['url']}/api/scan?mode={'many' if mode == 'many' else 'one'}", data=data, headers={"X-PIN": STATE["pin"], "Content-Type": "image/jpeg"}, timeout=180)
    except requests.RequestException:
        STATE["status"] = "stopped"
        raise ApiError("The scanner stopped answering - start it again.")
    if r.status_code != 200:
        raise ApiError(r.json().get("error", "The scanner couldn't read that picture.") if r.headers.get("content-type", "").startswith("application/json") else "Scan failed.")
    out = r.json()
    for c in out.get("cards", []):
        c["owned"] = svc.owned.get(c["card_id"], 0)
        light = svc.vault.card_light(c["card_id"]) or {}
        c["set_id"] = light.get("set_id", "")
    return out


def check_update(svc):
    """Look for a newer scanner add-on (also run quietly in the background); remembers the answer for the Scanner tab."""
    if not sys.platform.startswith("win") or runtime.IN_BROWSER:
        return None
    rel = latest_release(svc)
    STATE["latest"] = rel[0] if rel else ""
    return STATE["latest"]


@api("scanner.check")
def check(svc):
    check_update(svc)
    return status(svc)


@api("scanner.install")
def install(svc):
    """Download the newest scanner add-on (checksum verified) into <data>/scanner/versions/<version>; also used to update.  Older versions are tidied up."""
    if not sys.platform.startswith("win"):
        raise ApiError("The scanner add-on is for Windows.")

    def run(emit, cancel):
        import hashlib
        import shutil
        import tempfile
        import zipfile
        import requests
        emit("Looking for the scanner add-on…", 0, 0)
        rel = latest_release(svc)
        if not rel:
            raise RuntimeError("The scanner add-on hasn't been published yet.")
        ver, asset, side, hdr = rel
        if installed_version(svc) == ver and _addon_current(svc) and os.path.isfile(_addon_current(svc)):
            return {"ok": True, "version": ver}
        if not side:
            raise RuntimeError("The add-on has no checksum file, so it was not installed.")
        want = requests.get(side["url"], headers={**hdr, "Accept": "application/octet-stream"}, timeout=30).text.split()[0].lower()
        tmp = os.path.join(tempfile.mkdtemp(prefix="cea_scanner_"), "addon.zip")
        h = hashlib.sha256()
        with requests.get(asset["url"], headers={**hdr, "Accept": "application/octet-stream"}, stream=True, timeout=60) as resp, open(tmp, "wb") as f:
            total, done = int(asset.get("size") or 0), 0
            for chunk in resp.iter_content(1 << 20):
                f.write(chunk)
                h.update(chunk)
                done += len(chunk)
                emit(f"Downloading the scanner add-on {ver}…", done, total)
                if cancel.is_set():
                    raise RuntimeError("Stopped.")
        if h.hexdigest() != want:
            raise RuntimeError("The download didn't match its checksum and was discarded.")
        dest = os.path.join(_addon_dir(svc), "versions", ver)
        emit("Unpacking…", 0, 0)
        root = os.path.realpath(dest)
        shutil.rmtree(dest, ignore_errors=True)
        os.makedirs(dest, exist_ok=True)
        with zipfile.ZipFile(tmp) as z:
            for info in z.infolist():
                target = os.path.realpath(os.path.join(dest, info.filename))
                if os.path.isabs(info.filename) or not (target == root or target.startswith(root + os.sep)):
                    shutil.rmtree(dest, ignore_errors=True)
                    raise RuntimeError("The add-on contains an unsafe path and was refused.")
            z.extractall(dest)
        if not os.path.isfile(os.path.join(dest, EXE)):
            shutil.rmtree(dest, ignore_errors=True)
            raise RuntimeError("The add-on doesn't contain the scanner.")
        _stop()                                         # a running (older) scanner is closed; the new one starts on the next Start
        with open(os.path.join(_addon_dir(svc), "current.txt"), "w", encoding="utf-8") as f:
            f.write(ver)
        vers = os.path.join(_addon_dir(svc), "versions")
        for old in sorted(os.listdir(vers), key=_vkey, reverse=True)[2:]:         # keep the newest two
            shutil.rmtree(os.path.join(vers, old), ignore_errors=True)
        STATE["latest"] = ver
        return {"ok": True, "version": ver}
    j = svc.jobs.start("scanner-install", "Installing the scanner add-on", run)
    return {"job": j.id}
