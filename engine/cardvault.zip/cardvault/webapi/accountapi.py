"""Cloud account: sign in / register with the app's own account server, devices, password and recovery, "move my collection to my account", live sync.
The account's keys are made on this device (see cloud/skycloud.py); what is kept here (encrypted with the rest of this profile's secrets) is the sign-in token and the data key."""
import base64
import datetime
import platform

from ..cloud import skycloud as sc
from . import cloudapi
from .registry import ApiError, api

KEYS = ("cloud_token", "cloud_dek", "cloud_email", "cloud_username")


def server_url(svc):
    return (svc.pget("cloud_url") or svc.cfg.get("cloud_url") or sc.DEFAULT_URL or "").rstrip("/")


def device_name(svc):
    from ..runtime import IN_BROWSER
    if IN_BROWSER:
        return "Web browser"
    return f"{platform.node() or 'Computer'} ({platform.system() or 'desktop'})"[:60]


def account(svc, need=False):
    """The signed-in Account for this profile, or None."""
    tok, dek = svc.pget("cloud_token"), svc.pget("cloud_dek")
    if not (tok and dek):
        if need:
            raise ApiError("You're not signed in to your account yet.", code="no_account")
        return None
    return sc.Account(server_url(svc), tok, base64.b64decode(dek), svc.pget("cloud_email") or "")


def _store(svc, a):
    if getattr(a, "username", ""):
        svc.pset("cloud_username", a.username)
    svc.pset("cloud_token", a.token)
    svc.pset("cloud_dek", base64.b64encode(a.dek).decode())
    svc.pset("cloud_email", a.email)
    svc.pset("sync_enabled", True)


def _wrap(fn):
    try:
        return fn()
    except sc.CloudError as e:
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"), need_totp=bool(e.extra.get("need_totp")))


@api("account.status", quiet=True)
def status(svc):
    a = account(svc)
    url = server_url(svc)
    return {"configured": bool(url), "url": url, "signedIn": a is not None, "email": a.email if a else "", "username": (svc.pget("cloud_username") or "") if a else "", "sync": svc.pget("cloud_sync_mode") or ("account" if a else "github")}


@api("account.available", public=True, quiet=True)
def available(svc):
    """Before anyone has signed in: is there an account server to offer?"""
    return {"configured": bool(svc.cfg.get("cloud_url") or sc.DEFAULT_URL)}


@api("account.setServer")
def set_server(svc, url):
    url = (url or "").strip().rstrip("/")
    if url and not (url.startswith("https://") or url.startswith("http://127.0.0.1") or url.startswith("http://localhost")):
        raise ApiError("The account server address must start with https:// .", code="bad_url")
    svc.pset("cloud_url", url or None)
    return {"url": server_url(svc)}


@api("account.register")
def register(svc, email, password, username=""):
    if not server_url(svc):
        raise ApiError("The account server address isn't set yet.", code="no_server")
    a = sc.Account(server_url(svc))
    if username and not sc.clean_username(username):
        raise ApiError("A username is 3-24 letters, numbers, dots, dashes or underscores.", code="bad_username")
    recovery = _wrap(lambda: a.register(email, password, device_name(svc), username))
    _store(svc, a)
    svc.audit("account_created", email)
    return {"recoveryKey": recovery, "email": a.email, "username": getattr(a, "username", "")}


@api("account.login")
def login(svc, email, password, totp=""):
    if not server_url(svc):
        raise ApiError("The account server address isn't set yet.", code="no_server")
    a = sc.Account(server_url(svc))
    _wrap(lambda: a.login(email, password, device_name(svc), totp))
    _store(svc, a)
    svc.audit("account_signed_in", email)
    return {"email": a.email, "username": getattr(a, "username", "")}


@api("account.setUsername")
def set_username(svc, username):
    """Pick (or change) the username: it is also the name shown for this account, and an alternative to the email when signing in."""
    a = account(svc, True)
    u = _wrap(lambda: a.set_username(username))
    svc.pset("cloud_username", u)
    return {"username": u}


@api("account.logout")
def logout(svc):
    a = account(svc)
    if a:
        a.logout()
    for k in KEYS:
        svc.pset(k, None)
    svc.pset("cloud_sync_mode", None)
    svc.audit("account_signed_out")
    return {"ok": True}


@api("account.devices")
def devices(svc):
    return _wrap(lambda: account(svc, True).devices())


@api("account.revoke")
def revoke(svc, id):
    _wrap(lambda: account(svc, True).revoke(id))
    svc.audit("device_signed_out", id)
    return {"ok": True}


@api("account.revokeOthers")
def revoke_others(svc):
    _wrap(lambda: account(svc, True).revoke_others())
    svc.audit("other_devices_signed_out")
    return {"ok": True}


@api("account.changePassword")
def change_password(svc, old, new):
    from ..security.crypto import check_password
    problems = check_password(new, svc.pget("cloud_email") or "")
    if problems:
        raise ApiError(problems[0], code="weak_password")
    a = account(svc, True)
    _wrap(lambda: a.change_password(a.email, old, new))
    svc.audit("account_password_changed")
    return {"ok": True}


@api("account.recover")
def recover(svc, email, recoveryKey, newPassword):
    a = sc.Account(server_url(svc))
    _wrap(lambda: a.recover(email, recoveryKey, newPassword, device_name(svc)))
    _store(svc, a)
    svc.audit("account_recovered", email)
    return {"email": a.email}


@api("account.resetRequest")
def reset_request(svc, email):
    _wrap(lambda: sc.Account(server_url(svc)).reset_request(email))
    return {"ok": True}


@api("account.resetConfirm")
def reset_confirm(svc, email, code, newPassword, keep=False):
    a = account(svc) or sc.Account(server_url(svc))
    rk = _wrap(lambda: a.reset_confirm(email, code, newPassword, keep, device_name(svc)))
    _store(svc, a)
    svc.audit("account_reset_by_email", email)
    return {"recoveryKey": rk or ""}


@api("account.moveToCloud")
def move_to_cloud(svc):
    """One-time: bring the collection you already have (including what the GitHub repository holds) into your account.  GitHub is left as it is, as a backup."""
    a = account(svc, True)
    steps = []
    if svc.pget("github_token") and svc.pget("sync_key"):        # only a GitHub sync this profile really set up (never the PC's own GitHub sign-in)
        try:
            j = cloudapi.start_sync(svc, manual=True, publish=False, force_github=True)
            if j is not None:
                import time
                end = time.time() + 600
                while j.state == "running" and time.time() < end:    # let it finish before the account sync starts
                    time.sleep(0.5)
                steps.append("github")
        except Exception:  # noqa: BLE001 - offline / not set up: carry on with what is on this device
            pass
    svc.pset("cloud_sync_mode", "account")
    j = cloudapi.start_sync(svc, manual=True, publish=False)
    svc.audit("collection_moved_to_account")
    return {"job": j.id if j else None, "fromGithub": "github" in steps}


@api("account.watch", quiet=True)
def watch(svc):
    """Cheap check used for live sync: has another device changed anything since last time?"""
    a = account(svc)
    if not a:
        return {"changed": False}
    try:
        fp = a.fingerprint()
    except sc.CloudError:
        return {"changed": False}
    last = svc.cfg.get("_cloud_fp")
    svc.cfg["_cloud_fp"] = fp
    return {"changed": bool(last) and fp != last, "fp": fp}
