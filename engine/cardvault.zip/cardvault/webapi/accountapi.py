"""Cloud account: sign in / register with the app's own account server, devices, password and recovery, "move my collection to my account", live sync.
The account's keys are made on this device (see cloud/skycloud.py); what is kept here (encrypted with the rest of this profile's secrets) is the sign-in token and the data key."""
import base64
import datetime
import time
import platform

from ..cloud import skycloud as sc
from . import cloudapi
from .registry import ApiError, api

PLACEHOLDER = __import__("re").compile(r"user-[a-z0-9]{6}")          # the name the server gives anyone who has not chosen one yet (never derived from the email)
KEYS = ("cloud_token", "cloud_dek", "cloud_email", "cloud_username", "cloud_lsalt", "cloud_totp", "cloud_admin")


def server_url(svc):
    return (svc.pget("cloud_url") or svc.cfg.get("cloud_url") or sc.DEFAULT_URL or "").rstrip("/")


def device_name(svc):
    from ..runtime import IN_BROWSER
    if IN_BROWSER:
        return "Web browser"
    return f"{platform.node() or 'Computer'} ({platform.system() or 'desktop'})"[:60]


def account(svc, need=False):
    """The signed-in Account for this profile, or None."""
    tok, dek = svc.pget("cloud_token"), svc.pget("cloud_dek")
    if not (tok and dek):
        if need:
            raise ApiError("You're not signed in to your account yet.", code="no_account")
        return None
    return sc.Account(server_url(svc), tok, base64.b64decode(dek), svc.pget("cloud_email") or "", svc.pget("cloud_lsalt") or "")


def _adopt_name(svc):
    """The sign-in card and the top bar show the person's username, never their email: keep this device's profile name in step with it."""
    u, s = svc.pget("cloud_username"), svc.session
    if not u or s is None or s.name == u:
        return
    try:
        svc.auth.rename(s.pid, u)
        s.name = u
    except Exception:  # noqa: BLE001 - a name already used by another profile on this device just stays as it was
        pass


def _store(svc, a):
    if getattr(a, "username", ""):
        svc.pset("cloud_username", a.username)
    svc.pset("cloud_admin", True if getattr(a, "admin", False) else None)       # the owner's extra tools (hidden for everybody else); remembered so they still show offline
    svc.pset("cloud_token", a.token)
    svc.pset("cloud_dek", base64.b64encode(a.dek).decode())
    svc.pset("cloud_email", a.email)
    svc.pset("cloud_lsalt", a.lsalt or None)
    svc.pset("sync_enabled", True)
    _adopt_name(svc)


def _wrap(fn):
    try:
        return fn()
    except sc.CloudError as e:
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"), need_totp=bool(e.extra.get("need_totp")))


def _session_ok(svc, a):
    """Is the stored sign-in still valid?  Asked of the server at most every two minutes; a missing connection never counts as 'signed out'."""
    now = time.time()
    c = getattr(svc, "_me_cache", None)
    if c and now - c[0] < 120:
        return c[1]
    ok = True
    try:
        me = a.me(timeout=6)
        if "admin" in me:
            svc.pset("cloud_admin", True if me.get("admin") else None)
        if me.get("username") and me.get("username") != svc.pget("cloud_username"):
            svc.pset("cloud_username", me["username"])
            _adopt_name(svc)
    except sc.CloudError as e:
        ok = e.status != 401
    except Exception:  # noqa: BLE001 - anything unexpected (a browser quirk, a bad reply) is 'unknown', never 'signed out'
        ok = True
    svc._me_cache = (now, ok)
    return ok


def _end_session(svc):
    """The account says this device is signed out: forget the stored sign-in (the email stays, to make signing in again quick)."""
    for k in KEYS:
        if k != "cloud_email":
            svc.pset(k, None)
    svc.pset("cloud_sync_mode", None)
    svc._me_cache = None


@api("account.status", quiet=True)
def status(svc):
    a = account(svc)
    ended = False
    if a is not None and not _session_ok(svc, a):
        _end_session(svc)
        a, ended = None, True
    if a is not None:
        _adopt_name(svc)                                  # devices that signed in before this existed: the profile takes the username too
    url = server_url(svc)
    return {"configured": bool(url), "url": url, "signedIn": a is not None, "email": a.email if a else "", "username": (svc.pget("cloud_username") or "") if a else "", "twofa": bool(svc.pget("cloud_totp")), "avatar": (svc.pget("avatar") or "") if a else "", "admin": bool(a and svc.pget("cloud_admin")), "sessionEnded": ended, "needsName": bool(a and PLACEHOLDER.match(svc.pget("cloud_username") or "")), "namePrompts": int(svc.pget("username_prompts", 0) or 0), "sync": svc.pget("cloud_sync_mode") or ("account" if a else "github")}


@api("account.available", public=True, quiet=True)
def available(svc):
    """Before anyone has signed in: is there an account server to offer?"""
    return {"configured": bool(svc.cfg.get("cloud_url") or sc.DEFAULT_URL)}


@api("account.setServer")
def set_server(svc, url):
    url = (url or "").strip().rstrip("/")
    if url and not (url.startswith("https://") or url.startswith("http://127.0.0.1") or url.startswith("http://localhost")):
        raise ApiError("That address isn't valid.", code="bad_url")
    svc.pset("cloud_url", url or None)
    return {"url": server_url(svc)}


@api("account.register")
def register(svc, email, password, username="", remember=None):
    if not server_url(svc):
        raise ApiError("Accounts aren't available right now.", code="no_server")
    a = sc.Account(server_url(svc))
    if username and not sc.clean_username(username):
        raise ApiError("A username is 3-24 letters, numbers, dots, dashes or underscores.", code="bad_username")
    recovery = _wrap(lambda: a.register(email, password, device_name(svc), username, remember))
    _store(svc, a)
    svc.audit("account_created", email)
    return {"recoveryKey": recovery, "email": a.email, "username": getattr(a, "username", "")}


@api("account.twofaSetup")
def twofa_setup(svc):
    """Start two-step sign-in: returns the secret and the setup link.  The QR code is drawn on this device (nothing is sent to a QR website); the secret is never logged."""
    out = _wrap(lambda: account(svc, True).twofa_setup())
    return {"secret": out["secret"], "uri": out["uri"]}


@api("account.twofaEnable")
def twofa_enable(svc, code):
    _wrap(lambda: account(svc, True).twofa_enable(code))
    svc.pset("cloud_totp", True)
    svc.audit("two_step_on")
    return {"on": True}


@api("account.twofaDisable")
def twofa_disable(svc, password, code=""):
    a = account(svc, True)
    if not a.email:
        raise ApiError("Sign in with your email once on this device to turn this off.", code="need_email")
    _wrap(lambda: a.twofa_disable(a.email, password, code))
    svc.pset("cloud_totp", None)
    svc.audit("two_step_off")
    return {"on": False}


@api("account.nameLater")
def name_later(svc):
    """The person skipped choosing a name: it is offered again once more, later, then left alone (it stays editable in Settings)."""
    svc.pset("username_prompts", int(svc.pget("username_prompts", 0) or 0) + 1)
    return {"ok": True}


@api("account.usernameAvailable", public=True, quiet=True)
def username_available(svc, name):
    """Live check while someone types a username (no sign-in needed)."""
    if not server_url(svc):
        return {"available": True, "reason": ""}
    ok, why = _wrap(lambda: sc.Account(server_url(svc)).username_available(name))
    return {"available": ok, "reason": why}


@api("account.login")
def login(svc, email, password, totp="", remember=None):          # "email" may also be a username
    if not server_url(svc):
        raise ApiError("Accounts aren't available right now.", code="no_server")
    a = sc.Account(server_url(svc))
    out = _wrap(lambda: a.login(email, password, device_name(svc), totp, remember))
    _store(svc, a)
    svc.pset("cloud_totp", True if (out or {}).get("totp") else None)
    svc.audit("account_signed_in", email)
    return {"email": a.email, "username": getattr(a, "username", "")}


@api("account.setUsername")
def set_username(svc, username):
    """Pick (or change) the username: it is also the name shown for this account, and an alternative to the email when signing in."""
    a = account(svc, True)
    u = _wrap(lambda: a.set_username(username))
    svc.pset("cloud_username", u)
    _adopt_name(svc)
    return {"username": u}


@api("account.logout")
def logout(svc):
    a = account(svc)
    if a:
        a.logout()
    for k in KEYS:
        svc.pset(k, None)
    svc.pset("cloud_sync_mode", None)
    svc._me_cache = None
    svc.audit("account_signed_out")
    return {"ok": True}


@api("account.devices")
def devices(svc):
    return _wrap(lambda: account(svc, True).devices())


@api("account.revoke")
def revoke(svc, id):
    _wrap(lambda: account(svc, True).revoke(id))
    svc.audit("device_signed_out", id)
    return {"ok": True}


@api("account.revokeOthers")
def revoke_others(svc):
    _wrap(lambda: account(svc, True).revoke_others())
    svc.audit("other_devices_signed_out")
    return {"ok": True}


@api("account.changePassword")
def change_password(svc, old, new):
    from ..security.crypto import check_password
    problems = check_password(new, svc.pget("cloud_email") or "")
    if problems:
        raise ApiError(problems[0], code="weak_password")
    a = account(svc, True)
    _wrap(lambda: a.change_password(a.email, old, new))
    svc.audit("account_password_changed")
    return {"ok": True}


@api("account.recover")
def recover(svc, email, recoveryKey, newPassword):
    a = sc.Account(server_url(svc))
    _wrap(lambda: a.recover(email, recoveryKey, newPassword, device_name(svc)))
    _store(svc, a)
    svc.audit("account_recovered", email)
    return {"email": a.email}


@api("account.recoverTotp")
def recover_totp(svc, email, code, newPassword, understood=False):
    """Forgot password + no recovery key + 2-step on: restores the ACCOUNT but starts its cloud copy empty.  The person must have confirmed that in the screen."""
    if not understood:
        raise ApiError("Please confirm that you understand the cloud copy starts empty.", code="need_confirm")
    a = sc.Account(server_url(svc))
    rk = _wrap(lambda: a.recover_with_totp(email, code, newPassword, device_name(svc)))
    _store(svc, a)
    svc.audit("account_recovered_by_2step", email)
    return {"recoveryKey": rk}


@api("account.emailChange")
def email_change(svc, password, newEmail, code=""):
    """Step 1 of changing the account email: a 6-digit code is sent to the NEW address."""
    a = account(svc, True)
    try:
        a.change_email(password, newEmail, code)
    except sc.CloudError as e:
        if e.status == 503:
            raise ApiError("Changing your email isn't available yet.", code="email_unavailable")
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"), need_totp=bool(e.extra.get("need_totp")))
    return {"sent": True}


@api("account.emailConfirm")
def email_confirm(svc, code):
    a = account(svc, True)
    try:
        email = a.confirm_email(code)
    except sc.CloudError as e:
        if e.status == 503:
            raise ApiError("Changing your email isn't available yet.", code="email_unavailable")
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"))
    svc.pset("cloud_email", email)
    svc.audit("account_email_changed")
    return {"email": email}


@api("account.resetRequest")
def reset_request(svc, email):
    try:
        sc.Account(server_url(svc)).reset_request(email)
    except sc.CloudError as e:
        if e.status == 503:
            raise ApiError("Emailing a code isn't available yet. Use your recovery key or a 2-step code instead.", code="email_unavailable")
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"))
    return {"ok": True}


@api("account.resetConfirm")
def reset_confirm(svc, email, code, newPassword, keep=False):
    a = account(svc) or sc.Account(server_url(svc))
    rk = _wrap(lambda: a.reset_confirm(email, code, newPassword, keep, device_name(svc)))
    _store(svc, a)
    svc.audit("account_reset_by_email", email)
    return {"recoveryKey": rk or ""}


@api("account.moveToCloud")
def move_to_cloud(svc):
    """One-time: bring the collection you already have (including what the GitHub repository holds) into your account.  GitHub is left as it is, as a backup."""
    a = account(svc, True)
    steps = []
    if svc.pget("github_token") and svc.pget("sync_key"):        # only a GitHub sync this profile really set up (never the PC's own GitHub sign-in)
        try:
            j = cloudapi.start_sync(svc, manual=True, publish=False, force_github=True)
            if j is not None:
                import time
                end = time.time() + 600
                while j.state == "running" and time.time() < end:    # let it finish before the account sync starts
                    time.sleep(0.5)
                steps.append("github")
        except Exception:  # noqa: BLE001 - offline / not set up: carry on with what is on this device
            pass
    svc.pset("cloud_sync_mode", "account")
    j = cloudapi.start_sync(svc, manual=True, publish=False)
    svc.audit("collection_moved_to_account")
    return {"job": j.id if j else None, "fromGithub": "github" in steps}


@api("account.watch", quiet=True)
def watch(svc):
    """Cheap check used for live sync: has another device changed anything since last time?"""
    a = account(svc)
    if not a:
        return {"changed": False}
    try:
        fp = a.fingerprint()
    except sc.CloudError:
        return {"changed": False}
    last = svc.cfg.get("_cloud_fp")
    svc.cfg["_cloud_fp"] = fp
    return {"changed": bool(last) and fp != last, "fp": fp}
