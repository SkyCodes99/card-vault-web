"""Cloud account: sign in / register with the app's own account server, devices, password and recovery, "move my collection to my account", live sync.
The account's keys are made on this device (see cloud/skycloud.py); what is kept here (encrypted with the rest of this profile's secrets) is the sign-in token and the data key."""
import base64
import json
import os
import time
import platform

from .. import premium, runtime
from ..cloud import skycloud as sc
from ..db import game_dir
from . import cloudapi
from .registry import ApiError, api

PLACEHOLDER = __import__("re").compile(r"user-[a-z0-9]{6}")          # the name the server gives anyone who has not chosen one yet (never derived from the email)
KEYS = ("cloud_token", "cloud_dek", "cloud_email", "cloud_username", "cloud_lsalt", "cloud_totp", "cloud_admin", premium.PREF)



def _masked(who):
    """What the security log keeps of a sign-in name: a username as it is, an email only as 'j***@gmail.com' (the log never holds a full address)."""
    who = str(who or "")
    if "@" not in who:
        return who
    name, _, host = who.partition("@")
    return (name[:1] + "***@" + host) if name else "***@" + host

def server_url(svc):
    return (svc.pget("cloud_url") or svc.cfg.get("cloud_url") or sc.DEFAULT_URL or "").rstrip("/")


def device_name(svc):
    from ..runtime import IN_BROWSER
    if IN_BROWSER:
        hint = str(svc.cfg.get("device_name") or "").strip()
        hint = "".join(ch for ch in hint if ch.isalnum() or ch in " -.")[:40].strip()      # a hint from the page ("Chrome on Windows"), kept plain
        return f"Web browser ({hint})" if hint else "Web browser"
    return f"{platform.node() or 'Computer'} ({platform.system() or 'desktop'})"[:60]


def account(svc, need=False):
    """The signed-in Account for this profile, or None."""
    tok, dek = svc.pget("cloud_token"), svc.pget("cloud_dek")
    if not (tok and dek):
        if need:
            raise ApiError("You're not signed in to your account yet.", code="no_account")
        return None
    return sc.Account(server_url(svc), tok, base64.b64decode(dek), svc.pget("cloud_email") or "", svc.pget("cloud_lsalt") or "")


def _adopt_name(svc):
    """The sign-in card and the top bar show the person's username, never their email: keep this device's profile name in step with it."""
    u, s = svc.pget("cloud_username"), svc.session
    if not u or s is None or s.name == u:
        return
    try:
        svc.auth.rename(s.pid, u)
        s.name = u
    except Exception:  # noqa: BLE001 - a name already used by another profile on this device just stays as it was
        pass


def _store(svc, a, keep_sync=False):
    """keep_sync: the automatic sign-in at unlock (resume_with_password) - the person's own 'Save my changes to the cloud automatically' choice stands.  A sign-in by hand turns it on,
    except when the person chose "off" themselves (sync_off_chosen, set by cloud.setFlag): data stays on the device until THEY turn it back on (owner, 2026-11-14)."""
    if getattr(a, "username", ""):
        svc.pset("cloud_username", a.username)
    svc.pset("cloud_admin", True if getattr(a, "admin", False) else None)       # the owner's extra tools (hidden for everybody else); remembered so they still show offline
    svc.pset("cloud_token", a.token)
    svc.pset("cloud_dek", base64.b64encode(a.dek).decode())
    svc.pset("cloud_email", a.email)
    svc.pset("cloud_lsalt", a.lsalt or None)
    if not keep_sync:
        svc.pset("sync_enabled", not svc.pget("sync_off_chosen"))
    svc._me_cache = None
    if cloudapi.STATE.get("sync_status", "").startswith("Your session ended"):    # an earlier sign-in's "session ended" must not stay on screen after signing in again
        cloudapi.STATE["sync_status"], cloudapi.STATE["sync_error"] = "Signed in - saving to your account.", ""
    _adopt_name(svc)
    _share_on(svc)


def _share_on(svc):
    """Sharing is switched on for every account the moment it is signed in (best effort): anyone can then find the person by username."""
    try:
        from . import sharing
        sharing.ensure_ready(svc)
    except Exception:  # noqa: BLE001 - the background step tries again
        pass


def _wrap(fn):
    try:
        return fn()
    except sc.CloudError as e:
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"), need_totp=bool(e.extra.get("need_totp")))


def _remember(remember):
    """The Windows app is the person's own computer, locked by its own password: its account sign-in always stays (sliding, until 'Sign out').  It used to send the website's
    'Stay signed in' box, which the app never shows - so every desktop sign-in was a short 24-hour one and the app was signed out of the account the next day."""
    from ..runtime import IN_BROWSER
    return remember if IN_BROWSER else True


def _signin(fn, totp=""):
    """A sign-in the account refused, in plain words with its own code.  (As 'cloud_401' it read as 'Your sign-in has expired', which is not what happened: the password,
    or the 2-step code, was not accepted.)"""
    try:
        return fn()
    except sc.CloudError as e:
        if e.status != 401:
            raise ApiError(str(e), code="cloud_" + str(e.status or "x"), need_totp=bool(e.extra.get("need_totp")))
        if e.extra.get("need_totp"):
            if not totp:
                raise ApiError("Enter the 6-digit code from your authenticator app.", code="need_totp", need_totp=True)
            raise ApiError("That code is wrong or has expired. Check the time on your phone and try again.", code="wrong_code", need_totp=True)
        raise ApiError(sc.Account.WRONG, code="wrong_login")


def _session_ok(svc, a):
    """Is the stored sign-in still valid?  Asked of the server at most every two minutes; a missing connection never counts as 'signed out'."""
    now = time.time()
    c = getattr(svc, "_me_cache", None)
    if c and now - c[0] < 60:
        return c[1]
    from ..runtime import INLINE
    if INLINE:                                       # the website's engine has no threads: asked here, the question held every page up for its round trip (up to 6 s) once a minute while signed in.
        _check_soon(svc, a)                          # it goes as a job instead (the page sends it); until it is answered the last answer stands ('unknown' = signed in)
        return c[1] if c else True
    ok = True
    try:
        _adopt_me(svc, a.me(timeout=6))
    except sc.CloudError as e:
        ok = e.status != 401
    except Exception:  # noqa: BLE001 - anything unexpected (a browser quirk, a bad reply) is 'unknown', never 'signed out'
        ok = True
    svc._me_cache = (now, ok)
    return ok


def _adopt_me(svc, me):
    if "admin" in me:
        svc.pset("cloud_admin", True if me.get("admin") else None)
    premium.remember(svc, me)                    # (on the owner's Exempt list = premium; the server says it here every couple of minutes)
    if me.get("username") and me.get("username") != svc.pget("cloud_username"):
        svc.pset("cloud_username", me["username"])
        _adopt_name(svc)


def _check_soon(svc, a):
    """The browser: _session_ok's question to the server as a job in steps (its request is handed to the page), answered into svc._me_cache for the next account.status."""
    if svc.jobs.running("account-check"):
        return
    asked = time.time()

    def run(emit, cancel):
        try:
            me = yield from a.call_steps("GET", "/v1/me", timeout=6)
        except sc.CloudError as e:
            return e.status != 401
        except Exception:  # noqa: BLE001 - 'unknown', never 'signed out'
            return True
        try:
            _adopt_me(svc, me)
        except Exception:  # noqa: BLE001
            pass
        return True

    def done(job):
        svc._me_cache = (asked, job.result if job.state == "done" and job.result is not None else True)
    svc.jobs.start("account-check", "Checking your sign-in", run, on_done=done, quiet=True)


def _signed_in_as(svc, ident):
    """After a sign-in by hand: the name it was made with is the one the next unlock uses (resume_with_password), and an earlier 'the account has another password' is forgotten."""
    svc.pset("cloud_ident", (ident or "").strip().lower() or None)
    svc.pset("cloud_pw_differs", None)


def _ident(svc):
    return svc.pget("cloud_ident") or svc.pget("cloud_email") or svc.pget("cloud_username")


def _end_session(svc):
    """The account says this device is signed out: forget the stored sign-in (the email stays, to make signing in again quick; so does the name it was signed in with, so the next
    unlock of this device can sign in to the account again by itself - see resume_with_password)."""
    ident = _ident(svc)
    for k in KEYS:
        if k != "cloud_email":
            svc.pset(k, None)
    svc.pset("cloud_sync_mode", None)
    if ident:
        svc.pset("cloud_ident", ident)
    svc._me_cache = None


RESUME = "account-resume"


def resume_with_password(svc, password):
    """ONE sign-in (owner, 2026-11-14: "it makes me sign in twice"): this device was just unlocked with its password.  When its account sign-in has ended (the account said so earlier, or says
    so now), sign in to the account again with that same password - the way the sign-in card set it up: one password for both.  Nothing is weakened: the device's password was just
    checked by this device, and the account server checks it again; it only goes to the account this profile was signed in to.  A different account password (refused once), a 2-step code
    or no connection: nothing changes - the account asks in Settings > Account as before, and after a refusal this is not tried again until the account is signed in by hand.
    A background job (its questions go out on the job's own thread / through the page): unlocking is never held up by it."""
    url, ident = server_url(svc), _ident(svc)
    if not (url and ident and password) or svc.pget("cloud_pw_differs") or svc.jobs.running(RESUME) or svc.session is None:
        return None
    current = account(svc)
    # what this job was started for: its answer is used only while ALL of it still holds (it can take tens of seconds - meanwhile this profile may be locked and another one
    # opened, or the person may sign out of the account or sign in by hand; the answer must never land in another profile or undo what the person just did)
    pid, old_tok = svc.session.pid, svc.pget("cloud_token")
    remember = _remember(svc.pget("cloud_remember"))

    def run(emit, cancel):
        if current is not None:
            try:
                me = yield from current.call_steps("GET", "/v1/me", timeout=8)
                return ("ok", me)
            except sc.CloudError as e:
                if e.status != 401:
                    return ("unknown", None)                  # offline, a busy server: the stored sign-in stands (the usual check looks again later)
            except Exception:  # noqa: BLE001
                return ("unknown", None)
        a = sc.Account(url, email=ident if "@" in ident else "")
        try:
            out = yield from a.login_steps(ident, password, device_name(svc), "", remember)
        except sc.CloudError as e:
            return ("refused" if e.status == 401 and not e.extra.get("need_totp") else "later", None)
        except Exception:  # noqa: BLE001
            return ("later", None)
        return ("signed_in", (a, out))

    def done(job):
        what, val = job.result if job.state == "done" and job.result else ("later", None)
        if svc.session is None or svc.session.pid != pid or _ident(svc) != ident or svc.pget("cloud_token") != old_tok:
            return                                                     # (a new sign-in made here is simply not kept; it ends by itself on the server)
        if what == "ok":
            svc._me_cache = (time.time(), True)
            try:
                _adopt_me(svc, val or {})
            except Exception:  # noqa: BLE001
                pass
        elif what == "signed_in":
            a, out = val
            _store(svc, a, keep_sync=True)                             # cloud saving switched off stays off
            svc.pset("cloud_ident", ident)
            svc.pset("cloud_totp", True if (out or {}).get("totp") else None)
            if not svc.pget("cloud_sync_mode"):
                svc.pset("cloud_sync_mode", "account")
            svc._me_cache = (time.time(), True)
            svc.audit("account_signed_in", _masked(ident) + " (with this device's password)")
            if not svc.jobs.running("sync"):
                cloudapi.start_sync(svc, False, publish=False)          # the account's changes come down now (the first sync at unlock found no sign-in)
            svc.bump("sync")                                           # the screens look again: signed in
        elif what == "refused":
            svc.pset("cloud_pw_differs", True)                         # the account has another password: never sent again on unlock (signing in by hand clears this)
    return svc.jobs.start(RESUME, "Signing in to your account", run, on_done=done, quiet=True)


@api("account.status", quiet=True)
def status(svc):
    a = account(svc)
    ended = False
    if a is not None and svc.jobs.running(RESUME):
        pass                                                  # (being looked at right now, with the password that unlocked this device: no 'session ended' in between)
    elif a is not None and not _session_ok(svc, a):
        _end_session(svc)
        a, ended = None, True
    if a is not None:
        _adopt_name(svc)                                  # devices that signed in before this existed: the profile takes the username too
    url = server_url(svc)
    return {"configured": bool(url), "url": url, "signedIn": a is not None, "email": a.email if a else "", "username": (svc.pget("cloud_username") or "") if a else "", "twofa": bool(svc.pget("cloud_totp")), "avatar": (svc.pget("avatar") or "") if a else "", "admin": bool(a and svc.pget("cloud_admin")), "sessionEnded": ended, "needsName": bool(a and PLACEHOLDER.match(svc.pget("cloud_username") or "")), "namePrompts": int(svc.pget("username_prompts", 0) or 0), "sync": svc.pget("cloud_sync_mode") or ("account" if a else "github")}


@api("account.available", public=True, quiet=True)
def available(svc):
    """Before anyone has signed in: is there an account server to offer?"""
    return {"configured": bool(svc.cfg.get("cloud_url") or sc.DEFAULT_URL)}


@api("account.setServer")
def set_server(svc, url):
    url = (url or "").strip().rstrip("/")
    if url and not (url.startswith("https://") or url.startswith("http://127.0.0.1") or url.startswith("http://localhost")):
        raise ApiError("That address isn't valid.", code="bad_url")
    svc.pset("cloud_url", url or None)
    return {"url": server_url(svc)}


@api("account.register")
def register(svc, email, password, username="", remember=None):
    if not server_url(svc):
        raise ApiError("Accounts aren't available right now.", code="no_server")
    a = sc.Account(server_url(svc))
    if username and not sc.clean_username(username):
        raise ApiError("A username is 3-24 letters, numbers, dots, dashes or underscores.", code="bad_username")
    recovery = _wrap(lambda: a.register(email, password, device_name(svc), username, _remember(remember)))
    _store(svc, a)
    _signed_in_as(svc, email)
    svc.audit("account_created", _masked(email))
    return {"recoveryKey": recovery, "email": a.email, "username": getattr(a, "username", "")}


@api("account.twofaSetup")
def twofa_setup(svc):
    """Start two-step sign-in: returns the secret and the setup link.  The QR code is drawn on this device (nothing is sent to a QR website); the secret is never logged."""
    out = _wrap(lambda: account(svc, True).twofa_setup())
    return {"secret": out["secret"], "uri": out["uri"]}


@api("account.twofaEnable")
def twofa_enable(svc, code):
    _wrap(lambda: account(svc, True).twofa_enable(code))
    svc.pset("cloud_totp", True)
    svc.audit("two_step_on")
    return {"on": True}


@api("account.twofaDisable")
def twofa_disable(svc, password, code=""):
    a = account(svc, True)
    if not a.email:
        raise ApiError("Sign in with your email once on this device to turn this off.", code="need_email")
    _wrap(lambda: a.twofa_disable(a.email, password, code))
    svc.pset("cloud_totp", None)
    svc.audit("two_step_off")
    return {"on": False}


@api("account.nameLater")
def name_later(svc):
    """The person skipped choosing a name: it is offered again once more, later, then left alone (it stays editable in Settings)."""
    svc.pset("username_prompts", int(svc.pget("username_prompts", 0) or 0) + 1)
    return {"ok": True}


@api("account.usernameAvailable", public=True, quiet=True)
def username_available(svc, name):
    """Live check while someone types a username (no sign-in needed)."""
    if not server_url(svc):
        return {"available": True, "reason": ""}
    ok, why = _wrap(lambda: sc.Account(server_url(svc)).username_available(name))
    return {"available": ok, "reason": why}


@api("account.login")
def login(svc, email, password, totp="", remember=None):          # "email" may also be a username
    if not server_url(svc):
        raise ApiError("Accounts aren't available right now.", code="no_server")
    a = sc.Account(server_url(svc))
    out = _signin(lambda: a.login(email, password, device_name(svc), totp, _remember(remember)), totp)
    _store(svc, a)
    svc.pset("cloud_totp", True if (out or {}).get("totp") else None)
    _signed_in_as(svc, email)                                          # the name it signs in with (an email or a username): kept for resume_with_password
    svc.audit("account_signed_in", _masked(email))
    return {"email": a.email, "username": getattr(a, "username", "")}


@api("account.setUsername", mutates=True)
def set_username(svc, username):
    """Pick (or change) the username: it is also the name shown for this account, and an alternative to the email when signing in."""
    a = account(svc, True)
    old = svc.pget("cloud_username")
    u = _wrap(lambda: a.set_username(username))
    svc.pset("cloud_username", u)
    if old and old.strip().lower() != str(u).strip().lower():              # the names I had before: circles (and anything keyed by a username) merge them into the new one
        try:
            prev = json.loads(svc.pget("prev_usernames") or "[]")
        except ValueError:
            prev = []
        svc.pset("prev_usernames", json.dumps(([old.strip().lower()] + [x for x in prev if x != old.strip().lower()])[:6]))
    svc._me_cache = None
    _adopt_name(svc)
    _share_on(svc)
    try:                                                              # friends know me by my profile: say the new name at once, so they follow the change
        from . import friends
        svc._prof_at = 0
        if friends._mine(svc)[1]:
            friends._ensure_profile(svc, a)
    except Exception:  # noqa: BLE001 - it is republished at the next look anyway
        pass
    return {"username": u}


@api("account.merge")
def merge_account(svc, identifier, password, totp="", deleteAfter=False, deleteCode=""):
    """Merge ANOTHER account of the same person into the one signed in here: sign in to the other one for a moment (its own password), copy its collection into this one
    (nothing is lost on either side), and - only if asked - erase the other account.  The other account is never changed by the merge itself."""
    from ..cloud import engine
    me = account(svc, need=True)
    ident = (identifier or "").strip().lower()
    if not ident or not password:
        raise ApiError("Enter the email (or username) and password of the OTHER account.")
    if ident in ((me.email or "").lower(), (svc.pget("cloud_username") or "").lower()):
        raise ApiError("That is the account you are signed in to - enter the other one.")
    other = sc.Account(server_url(svc))
    try:
        other.login(ident, password, device_name(svc), totp)
    except sc.CloudError as e:
        raise (ApiError(str(e), code="need_totp") if e.extra.get("need_totp") else ApiError(str(e)))
    be = sc.SkyCloudBackend(other)
    docs = be.list_docs()
    games = sorted({n.split("/")[-1][:-5] for n in docs if n.startswith("users/") and n.endswith(".json") and n.count("/") == 2})
    upath = svc.session.db_path if svc.session is not None else None
    pulled, done = 0, []
    for g in games:
        if not os.path.exists(os.path.join(game_dir(svc.cfg["data_dir"], g), "cards.db")):
            continue                                                   # a game whose card list isn't on this device yet: merged after it is added
        pulled += engine.merge_in(svc.cfg["data_dir"], g, be, user_path=upath)
        done.append(g)
    svc.vault.invalidate_index()
    svc.pulled_rev += 1
    svc.reload_state()
    svc.bump("changed")
    try:
        cloudapi.start_sync(svc, manual=True)                                  # push the merged collection to this account
    except Exception:  # noqa: BLE001 - the normal background sync does it a moment later
        pass
    svc.audit("account_merged", f"{len(done)} games")
    deleted = False
    if deleteAfter:
        try:
            other.delete_now(ident, password, deleteCode or totp)
            deleted = True
        except sc.CloudError as e:
            return {"merged": done, "records": pulled, "deleted": False, "deleteError": str(e), "missingGames": [g for g in games if g not in done]}
    return {"merged": done, "records": pulled, "deleted": deleted, "missingGames": [g for g in games if g not in done]}


@api("account.logout")
def logout(svc):
    a = account(svc)
    if a:
        if not runtime.INLINE:                           # (the website's engine cannot wait for a request: its page sends them)
            try:
                cloudapi.flush_sync(svc)                 # the change-only sync: what is still in the outbox goes out, and the documents get it (best effort)
            except Exception:  # noqa: BLE001
                pass
        a.logout()
    for k in KEYS:
        svc.pset(k, None)
    svc.pset("cloud_sync_mode", None)
    svc.pset("cloud_ident", None)                       # signed out on purpose: unlocking never signs it in again by itself
    svc._me_cache = None
    svc.audit("account_signed_out")
    return {"ok": True}


@api("account.delete", mutates=True)
def delete_account(svc, password, code=""):
    """Erase my account for good: the account, everything saved to it (collection, friend profile, shared pages) and the username.  What is on THIS device stays (it is still yours)."""
    a = account(svc, need=True)
    ident = svc.pget("cloud_email") or getattr(a, "email", "")
    if not ident or not password:
        raise ApiError("Type your account password to confirm.")
    try:
        a.delete_now(ident, password, code)
    except sc.CloudError as e:
        raise ApiError(str(e), **({"need_totp": True} if "code" in str(e).lower() or e.status == 401 else {}))
    for k in KEYS:
        svc.pset(k, None)
    svc.pset("cloud_sync_mode", None)
    svc.pset("cloud_ident", None)
    svc._me_cache = None
    svc.audit("account_deleted")
    return {"ok": True}


# Delete with an undo window (Settings > Account): the account server's own grace-period deletion.  How long the window is comes from the
# server (SC_DELETE_GRACE_SECONDS, sent as delete_grace_seconds) - never hard-coded here.  This device stays signed in so Restore is one tap.
def _grace(me):
    g = (me or {}).get("delete_grace_seconds")
    return int(g) if isinstance(g, (int, float)) and g > 0 else None


@api("account.deletion")
def deletion(svc):
    """Is my account scheduled for deletion, and how long is the undo window?"""
    a = account(svc)
    if a is None:
        return {"pending": False, "deleteAt": None, "graceSeconds": None, "username": ""}
    me = _wrap(lambda: a.me(timeout=15))
    return {"pending": bool(me.get("delete_at")), "deleteAt": me.get("delete_at"), "graceSeconds": _grace(me), "username": me.get("username") or svc.pget("cloud_username") or ""}


def _confirm_name(svc, typed):
    want = (svc.pget("cloud_username") or "").strip().lower()
    got = (typed or "").strip().lower()
    if not got or got != (want or "delete"):
        raise ApiError("Type your username exactly as shown to confirm." if want else "Type DELETE to confirm.", code="confirm")


@api("account.scheduleDelete", mutates=True)
def schedule_delete(svc, password, confirm):
    """Delete my account after the undo window: the account and every copy on the server go for good when it ends.  What is on this device stays."""
    a = account(svc, need=True)
    _confirm_name(svc, confirm)
    ident = svc.pget("cloud_email") or getattr(a, "email", "")
    if not ident or not password:
        raise ApiError("Type your account password to confirm.")
    r = _wrap(lambda: a.schedule_delete(ident, password))
    svc.audit("account_delete_scheduled")
    return {"deleteAt": r.get("delete_at")}


@api("account.restoreDeletion", mutates=True)
def restore_deletion(svc, password):
    """Undo: cancel the scheduled deletion while the window is still open."""
    a = account(svc, need=True)
    ident = svc.pget("cloud_email") or getattr(a, "email", "")
    if not ident or not password:
        raise ApiError("Type your account password to confirm.")
    _wrap(lambda: a.restore_account(ident, password))
    svc.audit("account_delete_cancelled")
    return {"ok": True}


@api("account.devices")
def devices(svc):
    return _wrap(lambda: account(svc, True).devices())


@api("account.revoke")
def revoke(svc, id):
    _wrap(lambda: account(svc, True).revoke(id))
    svc.audit("device_signed_out", id)
    return {"ok": True}


@api("account.revokeOthers")
def revoke_others(svc):
    _wrap(lambda: account(svc, True).revoke_others())
    svc.audit("other_devices_signed_out")
    return {"ok": True}


@api("account.changePassword")
def change_password(svc, old, new):
    from ..security.crypto import check_password
    problems = check_password(new, svc.pget("cloud_email") or "")
    if problems:
        raise ApiError(problems[0], code="weak_password")
    a = account(svc, True)
    _wrap(lambda: a.change_password(a.email, old, new))
    svc.audit("account_password_changed")
    return {"ok": True}


@api("account.recover")
def recover(svc, email, recoveryKey, newPassword):
    a = sc.Account(server_url(svc))
    _wrap(lambda: a.recover(email, recoveryKey, newPassword, device_name(svc)))
    _store(svc, a)
    _signed_in_as(svc, email)
    svc.audit("account_recovered", _masked(email))
    return {"email": a.email}


@api("account.recoverTotp")
def recover_totp(svc, email, code, newPassword, understood=False):
    """Forgot password + no recovery key + 2-step on: restores the ACCOUNT but starts its cloud copy empty.  The person must have confirmed that in the screen."""
    if not understood:
        raise ApiError("Please confirm that you understand the cloud copy starts empty.", code="need_confirm")
    a = sc.Account(server_url(svc))
    rk = _wrap(lambda: a.recover_with_totp(email, code, newPassword, device_name(svc)))
    _store(svc, a)
    _signed_in_as(svc, email)
    svc.audit("account_recovered_by_2step", _masked(email))
    return {"recoveryKey": rk}


@api("account.emailChange")
def email_change(svc, password, newEmail, code=""):
    """Step 1 of changing the account email: a 6-digit code is sent to the NEW address."""
    a = account(svc, True)
    try:
        a.change_email(password, newEmail, code)
    except sc.CloudError as e:
        if e.status == 503:
            raise ApiError("Changing your email isn't available yet.", code="email_unavailable")
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"), need_totp=bool(e.extra.get("need_totp")))
    return {"sent": True}


@api("account.emailConfirm")
def email_confirm(svc, code):
    a = account(svc, True)
    try:
        email = a.confirm_email(code)
    except sc.CloudError as e:
        if e.status == 503:
            raise ApiError("Changing your email isn't available yet.", code="email_unavailable")
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"))
    svc.pset("cloud_email", email)
    if "@" in (svc.pget("cloud_ident") or "@"):                          # signed in with the old email: the next unlock signs in with the new one (a username stays as it is)
        svc.pset("cloud_ident", (email or "").strip().lower() or None)
    svc.audit("account_email_changed")
    return {"email": email}


@api("account.resetRequest")
def reset_request(svc, email):
    try:
        sc.Account(server_url(svc)).reset_request(email)
    except sc.CloudError as e:
        if e.status == 503:
            raise ApiError("Emailing a code isn't available yet. Use your recovery key or a 2-step code instead.", code="email_unavailable")
        raise ApiError(str(e), code="cloud_" + str(e.status or "x"))
    return {"ok": True}


@api("account.resetConfirm")
def reset_confirm(svc, email, code, newPassword, keep=False):
    a = account(svc) or sc.Account(server_url(svc))
    rk = _wrap(lambda: a.reset_confirm(email, code, newPassword, keep, device_name(svc)))
    _store(svc, a)
    _signed_in_as(svc, email)
    svc.audit("account_reset_by_email", _masked(email))
    return {"recoveryKey": rk or ""}


@api("account.moveToCloud")
def move_to_cloud(svc):
    """One-time: bring the collection you already have (including what the GitHub repository holds) into your account.  GitHub is left as it is, as a backup."""
    account(svc, True)
    svc.pset("cloud_sync_mode", "account")
    svc.audit("collection_moved_to_account")
    if svc.pget("github_token") and svc.pget("sync_key") and not svc.pget("github_moved"):     # only a GitHub sync this profile really set up (never the PC's own GitHub sign-in), and only once
        # the account sync follows when the GitHub one is done.  This call used to WAIT for it (up to 10 minutes) on the engine's one thread: after signing in, every screen
        # stood still until the whole GitHub copy had been read (owner, 2026-11-14: "after the second sign-in it takes 10-15 s to finish").  The follow-up is handed to the sync
        # BEFORE it starts: attached afterwards, a GitHub sync that ended at once (a bad token) had already finished without it and the collection never reached the account.
        def after(job):
            if job.state == "done":
                svc.pset("github_moved", True)
            try:
                cloudapi.start_sync(svc, manual=True, publish=False, force=False)
            except Exception:  # noqa: BLE001 - the normal background sync does it a moment later
                pass
        try:
            j = cloudapi.start_sync(svc, manual=True, publish=False, force_github=True, then=after)
        except Exception:  # noqa: BLE001 - offline / not set up: carry on with what is on this device
            j = None
        if j is not None:
            if runtime.INLINE:
                svc.jobs.finish(j)                                       # (the browser build: a sync goes in pieces, one per tick - finish it here)
            return {"job": j.id, "fromGithub": True}
    j = cloudapi.start_sync(svc, manual=True, publish=False, force=False)          # (the marks skip the games nothing changed in: a re-sign-in no longer looks at every game again)
    return {"job": j.id if j else None, "fromGithub": False}


@api("account.watchInfo", quiet=True)
def watch_info(svc):
    """For the website's page: where to ask (asynchronously, outside the engine) whether another device saved something."""
    a = account(svc)
    if not a or not svc.pget("sync_enabled", True):          # cloud saving switched off: the page does not ask the account either
        return {}
    return {"url": server_url(svc) + "/v1/docs", "token": a.token}


@api("account.watch", quiet=True)
def watch(svc):
    """Cheap check used for live sync: has another device changed anything since last time?"""
    a = account(svc)
    if not a:
        return {"changed": False}
    try:
        fp = a.fingerprint()
    except sc.CloudError:
        return {"changed": False}
    last = svc.cfg.get("_cloud_fp")
    # NOT stored here: a change counts as seen only after a sync has really pulled it (sync's `done` records the fingerprint it ended with) - otherwise a change that arrives while
    # a sync is running would be marked seen and never fetched
    return {"changed": fp != last, "fp": fp}
