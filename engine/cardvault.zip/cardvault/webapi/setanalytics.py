"""Set analytics: what a set is worth, how that changes, and what is in it - plus leaving cards out of a master set."""
import datetime
import json
import statistics

from .cards import img
from .registry import api
from .service import ApiError

BUCKETS = [("under $1", 0, 1), ("$1 - $5", 1, 5), ("$5 - $20", 5, 20), ("$20 - $50", 20, 50), ("$50 - $100", 50, 100), ("$100 and up", 100, 1e12)]


def _excluded(v, set_id):
    try:
        return set(json.loads(v.get_setting("master_excluded") or "{}").get(set_id, []))
    except ValueError:
        return set()


def _save_excluded(v, set_id, ids):
    try:
        d = json.loads(v.get_setting("master_excluded") or "{}")
    except ValueError:
        d = {}
    if ids:
        d[set_id] = sorted(ids)
    else:
        d.pop(set_id, None)
    v.set_setting("master_excluded", json.dumps(d) if d else None)


@api("set.analytics")
def analytics(svc, set_id):
    v = svc.vault
    s = next((x for x in v.sets() if x["id"] == set_id), None)
    if not s:
        raise ApiError("set not found")
    v.record_set_values()                                           # make sure today's point is in the graph
    cards = v.conn.execute("SELECT id, name, local_id, rarity, price_usd, price_kind FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,)).fetchall()
    own = svc.owned
    prices = [c["price_usd"] for c in cards if c["price_usd"] is not None]
    total = sum(prices)
    owned_cards = [c for c in cards if own.get(c["id"], 0) > 0]
    owned_value = sum((c["price_usd"] or 0) * own[c["id"]] for c in owned_cards)
    missing = [c for c in cards if own.get(c["id"], 0) == 0]
    missing_value = sum(c["price_usd"] or 0 for c in missing)
    by_rar = {}
    for c in cards:
        r = by_rar.setdefault(c["rarity"] or "Unlabelled", {"rarity": c["rarity"] or "Unlabelled", "n": 0, "value": 0.0, "owned": 0, "ownedValue": 0.0, "unpriced": 0})
        r["n"] += 1
        r["value"] += c["price_usd"] or 0
        r["unpriced"] += 1 if c["price_usd"] is None else 0
        if own.get(c["id"], 0) > 0:
            r["owned"] += 1
            r["ownedValue"] += (c["price_usd"] or 0) * own[c["id"]]
    rarities = sorted(by_rar.values(), key=lambda r: -r["value"])
    row = lambda c: {"id": c["id"], "name": c["name"], "number": c["local_id"], "rarity": c["rarity"] or "", "price": c["price_usd"], "priceKind": c["price_kind"] or "",
                     "qty": own.get(c["id"], 0), "img": img(c["id"], set_id)}
    top = [row(c) for c in sorted((c for c in cards if c["price_usd"] is not None), key=lambda c: -c["price_usd"])[:10]]
    chase_missing = [row(c) for c in sorted((c for c in missing if c["price_usd"] is not None), key=lambda c: -c["price_usd"])[:5]]
    buckets = [{"label": lab, "n": sum(1 for p in prices if lo <= p < hi)} for lab, lo, hi in BUCKETS]
    hist = v.set_value_history(set_id)
    change = {}
    if hist:
        latest = hist[-1]
        for label, d in (("day", 1), ("week", 7), ("month", 30)):
            cut = (datetime.date.fromisoformat(latest["day"]) - datetime.timedelta(days=d)).isoformat()
            older = [h for h in hist if h["day"] <= cut]
            if older and older[-1]["total"]:
                change[label] = {"from": older[-1]["day"], "usd": round(latest["total"] - older[-1]["total"], 2), "pct": round((latest["total"] / older[-1]["total"] - 1) * 100, 2)}
    return {"id": set_id, "name": s["name"], "serie": s["serie"] or "", "released": s["release_date"] or "", "logo": svc.logo_url(set_id, s),
            "cards": len(cards), "priced": len(prices), "unpriced": len(cards) - len(prices), "owned": len(owned_cards), "pct": round(100.0 * len(owned_cards) / len(cards), 1) if cards else 0,
            "totalValue": round(total, 2), "ownedValue": round(owned_value, 2), "missingValue": round(missing_value, 2),
            "avg": round(total / len(prices), 2) if prices else None, "median": round(statistics.median(prices), 2) if prices else None,
            "top": top, "chase": chase_missing, "topShare": round(100 * sum(c["price"] for c in top) / total, 1) if total else 0,
            "rarities": [{**r, "value": round(r["value"], 2), "ownedValue": round(r["ownedValue"], 2)} for r in rarities], "buckets": buckets,
            "history": hist, "change": change}


@api("master.leaveOut", mutates=True)
def leave_out(svc, set_id, ids=None, rarity=None, left=True):
    """Leave cards out of this set's master-set count (or count them again).  ids = cards; rarity = every card of that rarity in the set."""
    v = svc.vault
    cur = _excluded(v, set_id)
    pick = set(ids or [])
    if rarity is not None:
        pick |= {r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=? AND COALESCE(rarity,'Unlabelled')=?", (set_id, rarity))}
    cur = (cur | pick) if left else (cur - pick)
    _save_excluded(v, set_id, cur)
    return {"left": len(cur)}
