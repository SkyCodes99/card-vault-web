"""Set analytics: what a set is worth, how that changes, and what is in it - plus leaving cards out of a master set."""
import datetime
import json
import statistics

from .cards import img
from .registry import api
from .service import ApiError

BUCKETS = [("under $1", 0, 1), ("$1 - $5", 1, 5), ("$5 - $20", 5, 20), ("$20 - $50", 20, 50), ("$50 - $100", 50, 100), ("$100 and up", 100, 1e12)]


def _excluded(v, set_id):
    return v.excluded_cards(set_id)


def _save_excluded(v, set_id, ids):
    try:
        d = json.loads(v.get_setting("master_excluded") or "{}")
    except ValueError:
        d = {}
    if ids:
        d[set_id] = sorted(ids)
    else:
        d.pop(set_id, None)
    v.set_setting("master_excluded", json.dumps(d) if d else None)


@api("set.analytics")
def analytics(svc, set_id):
    v = svc.vault
    s = next((x for x in v.sets() if x["id"] == set_id), None)
    if not s:
        raise ApiError("set not found")
    v.record_set_values()                                           # make sure today's point is in the graph
    cards = v.conn.execute("SELECT id, name, local_id, rarity, price_usd, price_kind FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,)).fetchall()
    own = svc.owned
    prices = [c["price_usd"] for c in cards if c["price_usd"] is not None]
    total = sum(prices)
    owned_cards = [c for c in cards if own.get(c["id"], 0) > 0]
    owned_value = sum((c["price_usd"] or 0) * own[c["id"]] for c in owned_cards)
    left = _excluded(v, set_id)
    missing = [c for c in cards if own.get(c["id"], 0) == 0 and c["id"] not in left]            # cards you left out of the set are not "missing"
    missing_value = sum(c["price_usd"] or 0 for c in missing)
    by_rar = {}
    for c in cards:
        r = by_rar.setdefault(c["rarity"] or "Unlabelled", {"rarity": c["rarity"] or "Unlabelled", "n": 0, "value": 0.0, "owned": 0, "ownedValue": 0.0, "unpriced": 0})
        r["n"] += 1
        r["value"] += c["price_usd"] or 0
        r["unpriced"] += 1 if c["price_usd"] is None else 0
        if own.get(c["id"], 0) > 0:
            r["owned"] += 1
            r["ownedValue"] += (c["price_usd"] or 0) * own[c["id"]]
    rarities = sorted(by_rar.values(), key=lambda r: -r["value"])
    row = lambda c: {"id": c["id"], "name": c["name"], "number": c["local_id"], "rarity": c["rarity"] or "", "price": c["price_usd"], "priceKind": c["price_kind"] or "",
                     "qty": own.get(c["id"], 0), "img": img(c["id"], set_id)}
    top = [row(c) for c in sorted((c for c in cards if c["price_usd"] is not None), key=lambda c: -c["price_usd"])[:10]]
    chase_missing = [row(c) for c in sorted((c for c in missing if c["price_usd"] is not None), key=lambda c: -c["price_usd"])[:5]]
    buckets = [{"label": lab, "n": sum(1 for p in prices if lo <= p < hi)} for lab, lo, hi in BUCKETS]
    hist = v.set_value_history(set_id)
    change = {}
    if hist:
        latest = hist[-1]
        for label, d in (("day", 1), ("week", 7), ("month", 30)):
            cut = (datetime.date.fromisoformat(latest["day"]) - datetime.timedelta(days=d)).isoformat()
            older = [h for h in hist if h["day"] <= cut]
            if older and older[-1]["total"]:
                change[label] = {"from": older[-1]["day"], "usd": round(latest["total"] - older[-1]["total"], 2), "pct": round((latest["total"] / older[-1]["total"] - 1) * 100, 2)}
    return {"id": set_id, "name": s["name"], "serie": s["serie"] or "", "released": s["release_date"] or "", "logo": svc.logo_url(set_id, s),
            "cards": len(cards), "priced": len(prices), "unpriced": len(cards) - len(prices), "owned": len(owned_cards), "leftOut": len(left), "pct": round(100.0 * len([c for c in owned_cards if c["id"] not in left]) / max(1, len(cards) - len(left)), 1) if cards else 0,
            "totalValue": round(total, 2), "ownedValue": round(owned_value, 2), "missingValue": round(missing_value, 2),
            "avg": round(total / len(prices), 2) if prices else None, "median": round(statistics.median(prices), 2) if prices else None,
            "top": top, "chase": chase_missing, "topShare": round(100 * sum(c["price"] for c in top) / total, 1) if total else 0,
            "rarities": [{**r, "value": round(r["value"], 2), "ownedValue": round(r["ownedValue"], 2)} for r in rarities], "buckets": buckets,
            "history": hist, "change": change}


@api("master.leaveOut", mutates=True)
def leave_out(svc, set_id, ids=None, rarity=None, left=True):
    """Leave cards out of this set's master-set count (or count them again).  ids = cards; rarity = every card of that rarity in the set."""
    v = svc.vault
    cur = _excluded(v, set_id)
    pick = set(ids or [])
    if rarity is not None:
        pick |= {r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=? AND COALESCE(rarity,'Unlabelled')=?", (set_id, rarity))}
    cur = (cur | pick) if left else (cur - pick)
    _save_excluded(v, set_id, cur)
    return {"left": len(cur)}


@api("series.analytics")
def series_analytics(svc, edition=None, era=""):
    """Everything about a whole series / era (or the whole game when no series is chosen) combined from the data of all its sets."""
    v = svc.vault
    sets = [s for s in v.sets(edition) if not era or s["serie"] == era]
    if not sets:
        raise ApiError("No sets here.")
    ids = [s["id"] for s in sets]
    v.record_set_values()
    own = svc.owned
    left = v.excluded_cards()
    marks = ",".join("?" * len(ids))
    cards = v.conn.execute(f"SELECT c.id, c.set_id, c.name, c.local_id, c.rarity, c.price_usd, c.price_kind FROM cards c WHERE c.set_id IN ({marks})", ids).fetchall()
    per = {s["id"]: {"id": s["id"], "name": s["name"], "released": s["release_date"] or "", "serie": s["serie"] or "", "logo": svc.logo_url(s["id"], s), "cards": 0, "owned": 0,
                     "value": 0.0, "ownedValue": 0.0, "missingValue": 0.0, "priced": 0, "left": 0} for s in sets}
    by_rar, prices = {}, []
    for c in cards:
        p = per[c["set_id"]]
        if c["id"] in left.get(c["set_id"], ()):
            p["left"] += 1
            continue                                                     # left out of its set: not part of the counts
        q = own.get(c["id"], 0)
        pr = c["price_usd"]
        p["cards"] += 1
        p["value"] += pr or 0
        p["priced"] += 1 if pr is not None else 0
        if q > 0:
            p["owned"] += 1
            p["ownedValue"] += (pr or 0) * q
        else:
            p["missingValue"] += pr or 0
        if pr is not None:
            prices.append(pr)
        r = by_rar.setdefault(c["rarity"] or "Unlabelled", {"rarity": c["rarity"] or "Unlabelled", "n": 0, "value": 0.0, "owned": 0, "ownedValue": 0.0})
        r["n"] += 1
        r["value"] += pr or 0
        if q > 0:
            r["owned"] += 1
            r["ownedValue"] += (pr or 0) * q
    names = {s["id"]: s["name"] for s in sets}
    top = [{"id": c["id"], "name": c["name"], "number": c["local_id"], "set": names[c["set_id"]], "rarity": c["rarity"] or "", "price": c["price_usd"], "priceKind": c["price_kind"] or "",
            "qty": own.get(c["id"], 0), "img": img(c["id"], c["set_id"])}
           for c in sorted((c for c in cards if c["price_usd"] is not None and c["id"] not in left.get(c["set_id"], ())), key=lambda c: -c["price_usd"])[:10]]
    rows = sorted(per.values(), key=lambda p: (p["released"], p["name"]), reverse=True)
    for p in rows:
        p["pct"] = round(100.0 * p["owned"] / p["cards"], 1) if p["cards"] else 0
        for k in ("value", "ownedValue", "missingValue"):
            p[k] = round(p[k], 2)
    total = sum(p["value"] for p in rows)
    hist = [dict(r) for r in v.conn.execute(
        f"SELECT day, SUM(total) AS total, SUM(owned) AS owned FROM u.set_value_history WHERE game=? AND set_id IN ({marks}) GROUP BY day ORDER BY day", [v.game] + ids)]
    change = {}
    if hist:
        latest = hist[-1]
        for label, d in (("day", 1), ("week", 7), ("month", 30)):
            cut = (datetime.date.fromisoformat(latest["day"]) - datetime.timedelta(days=d)).isoformat()
            older = [h for h in hist if h["day"] <= cut]
            if older and older[-1]["total"]:
                change[label] = {"from": older[-1]["day"], "usd": round(latest["total"] - older[-1]["total"], 2), "pct": round((latest["total"] / older[-1]["total"] - 1) * 100, 2)}
    n_cards = sum(p["cards"] for p in rows)
    n_owned = sum(p["owned"] for p in rows)
    return {"name": era or "Every series", "sets": len(rows), "cards": n_cards, "owned": n_owned, "pct": round(100.0 * n_owned / n_cards, 1) if n_cards else 0,
            "priced": len(prices), "totalValue": round(total, 2), "ownedValue": round(sum(p["ownedValue"] for p in rows), 2), "missingValue": round(sum(p["missingValue"] for p in rows), 2),
            "avg": round(total / len(prices), 2) if prices else None, "median": round(statistics.median(prices), 2) if prices else None,
            "completeSets": sum(1 for p in rows if p["cards"] and p["owned"] >= p["cards"]), "startedSets": sum(1 for p in rows if p["owned"] > 0),
            "top": top, "topShare": round(100 * sum(c["price"] for c in top) / total, 1) if total else 0, "setRows": rows,
            "rarities": [{**r, "value": round(r["value"], 2), "ownedValue": round(r["ownedValue"], 2)} for r in sorted(by_rar.values(), key=lambda r: -r["value"])][:25],
            "buckets": [{"label": lab, "n": sum(1 for p in prices if lo <= p < hi)} for lab, lo, hi in BUCKETS], "history": hist, "change": change}
