"""The scanner's memory of what YOU corrected.  When a guess is changed to another card (or product) and added, the scanner keeps a small fingerprint of that picture together with the
card you chose, and next time it sees something that looks the same it puts your choice first.

Careful by design (people mistype, mis-tap, and cards have look-alikes):
  * a correction starts at 'probably right' (0.6 when the chosen card was among the scanner's own top 5 guesses, 0.4 when it was not), never certain
  * it is only used when the new picture looks almost identical (>= 0.93 similar) AND its trust is at least 0.5
  * a remembered match is always shown as 'remembered from your earlier correction' and still has to be checked (it never counts as a sure match)
  * confirming it again raises the trust (+0.15); choosing something else for the same picture lowers it (-0.35) and below 0.3 it is forgotten
  * it stays on this device (it is a few hundred small fingerprints, not pictures), and can be forgotten with one button
This file only stores and ranks; the recogniser itself runs in the page (ui/src/scanweb)."""
import base64
import json
import math
import time

from .registry import api

MAX_ENTRIES = 300
SIM_USE = 0.93          # how alike two pictures must be for a correction to apply
TRUST_USE = 0.5         # how much a correction must be trusted to apply


def _key(game, kind):
    return f"scanmem:{game}:{'sealed' if kind == 'sealed' else 'card'}"


def _load(svc, game, kind):
    raw = svc.pget(_key(game, kind))
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        v = None
    return v if isinstance(v, list) else []


def _save(svc, game, kind, items):
    items = sorted(items, key=lambda e: (e.get("trust", 0), e.get("at", 0)), reverse=True)[:MAX_ENTRIES]
    svc.pset(_key(game, kind), json.dumps(items, separators=(",", ":")) if items else None)


def _vec(b64):
    try:
        raw = base64.b64decode(b64)
    except Exception:  # noqa: BLE001
        return None
    return [(x - 256 if x > 127 else x) / 127.0 for x in raw]


def _sim(a, b):
    if not a or not b or len(a) != len(b):
        return 0.0
    d = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return d / (na * nb)


@api("scanmem.list", quiet=True)
def list_(svc, game="", kind="card"):
    """What the scanner remembers for this game: [{id, vec (base64 of 8-bit numbers), trust}] - only what it would actually use."""
    game = game or (svc.vault.game if svc.vault else "")
    return [{"id": e["id"], "vec": e["vec"], "trust": e.get("trust", 0.5)} for e in _load(svc, game, kind) if e.get("trust", 0.5) >= TRUST_USE]


@api("scanmem.status", quiet=True)
def status(svc, game="", kind="card"):
    game = game or (svc.vault.game if svc.vault else "")
    items = _load(svc, game, kind)
    return {"count": len(items), "usable": sum(1 for e in items if e.get("trust", 0) >= TRUST_USE)}


@api("scanmem.record", mutates=False)
def record(svc, id, vec, game="", kind="card", guess="", rank=0, confirmed=False):
    """A correction was added (id = what the person chose, guess = what the scanner thought first, rank = where the chosen one stood in the scanner's own list), or a remembered
    match was confirmed (confirmed=True)."""
    game = game or (svc.vault.game if svc.vault else "")
    new = _vec(vec)
    if not new or not id:
        return {"ok": False}
    now = time.time()
    items = _load(svc, game, kind)
    same, contradicted = None, False
    keep = []
    for e in items:
        s = _sim(new, _vec(e["vec"]))
        if s >= SIM_USE and e["id"] == id:
            same = e
            e["trust"] = min(1.0, e.get("trust", 0.5) + 0.15)
            e["n"] = e.get("n", 1) + 1
            e["at"] = now
        elif s >= SIM_USE and e["id"] != id:
            contradicted = True
            e["trust"] = e.get("trust", 0.5) - 0.35                       # the person chose something else for what looks the same: this one may have been a slip
            if e["trust"] < 0.3:
                continue
        keep.append(e)
    if same is None and not confirmed:
        trust = 0.6 if 0 < int(rank or 0) <= 4 else 0.4
        keep.append({"id": str(id), "vec": vec, "trust": 0.5 if contradicted else trust, "n": 1, "guess": str(guess or ""), "at": now})
    _save(svc, game, kind, keep)
    return {"ok": True, "count": len(keep)}


@api("scanmem.clear")
def clear(svc, game="", kind=""):
    """Forget what the scanner learned from your corrections (this game, or everything when no game is given)."""
    from .. import games
    n = 0
    for g in ([game] if game else [x.id for x in games.GAMES]):
        for k in ("card", "sealed"):
            n += len(_load(svc, g, k))
            svc.pset(_key(g, k), None)
    return {"forgot": n}
