"""Trade finder: "you have what Alex wants, Alex has what you want", across ALL your friends at once.

It builds nothing new between friends.  It only reads what friends already share with me (the profile rows `coll` and `wish` they switched on under "What friends see", plus the trade lists
`haves` / `wants` they published) and compares them with my own spares and wishlist.  The result opens the existing friend trade window (ftrade.*) with both sides filled in.

Rules this module keeps:
  - Only what a friend shares.  Whatever is not shared is simply absent - not shown, not counted, not hinted at beyond "they don't share their <spares|wishlist>".
  - Spares = copies beyond what the person keeps (tools.duplicates logic: more than `keep`; for a friend the keep is 1 - their own number is theirs to keep).
  - Cards I hid on a friend's list stay hidden here.  Blocked people and one-sided friendships are never read.
  - Usernames only.  Values come from MY card list and only when the price is a real market price (never an eBay asking price, a store price or an estimate); no price = shown as unpriced.
  - Zero delay: matches() reads only what is already on this device (the rows downloaded earlier) and never waits on the network.  refresh() fetches what changed in the background and
    tells the screens (event "tradefind") when it is done."""
import threading
import time

from .. import pricepick
from ..cloud import sharing as sh
from ..runtime import INLINE
from .registry import ApiError, api
from .sharing import _acct, _gk, _inn

FRIEND_KEEP = 1                                  # copies a friend is assumed to keep of each card (their collection says how many they own, not how many they keep)
SHOW = 300                                       # most cards listed per side per friend
PRESET = 8                                       # cards of each side put into the trade window when a match is opened
NOT_TRUE = ("ebay", "retail price", "your estimate", "store")


def true_price(v, cid, c):
    """A real market price for one card from my own card list, or None (never eBay, store or estimate prices)."""
    p, kind = pricepick.shown(v, cid, c.get("price_usd"), c.get("price_kind") or "")
    k = str(c.get("price_kind") or kind or "").lower()
    if p is None or p <= 0 or k.startswith(NOT_TRUE):
        return None
    return round(float(p), 2)


# ----------------------------------------------------------------------------------------------- the pure part
def _qty(d, default=1):
    try:
        return max(1, min(int(d.get("qty") or default), 999))
    except (TypeError, ValueError, OverflowError):
        return default


def friend_side(rows, game, hidden=lambda cid: False):
    """What ONE share of a friend holds for `game` (rows = {(collection, id): data} as downloaded): their profile (rows `coll` / `wish`, present only when they switched them on) or a
    trade-lists share (rows `haves` / `wants`).  -> {"spares": {card id: copies} or None, "wants": {card id} or None}; None = they don't share that."""
    spares, wants, has_s, has_w = {}, set(), False, False
    trade = any(c == "meta" and isinstance(d, dict) and d.get("kind") == "trade" and (not d.get("gameId") or d.get("gameId") == game) for (c, _), d in rows.items())
    for (coll, key), d in rows.items():
        if not isinstance(d, dict):
            continue
        if coll in ("coll", "wish"):
            cid = d.get("id")
            if d.get("gameId") != game or not isinstance(cid, str):
                continue
            if coll == "coll":
                has_s = True
                extra = _qty(d, 0) - FRIEND_KEEP if d.get("qty") else 0
                if extra > 0 and not hidden(cid):
                    spares[cid] = max(spares.get(cid, 0), extra)
            else:
                has_w = True
                if not hidden(cid):
                    wants.add(cid)
        elif coll in ("haves", "wants") and trade and isinstance(key, str):
            if not hidden(key):
                if coll == "haves":
                    spares[key] = max(spares.get(key, 0), _qty(d))
                else:
                    wants.add(key)
    if trade:
        has_s = has_w = True
    return {"spares": spares if has_s else None, "wants": wants if has_w else None}


def merge_sides(sides):
    """Several shares of one friend (profile + trade lists) as one side: what any of them shares counts; None only when none of them shares it."""
    spares, wants = None, None
    for s in sides:
        if s["spares"] is not None:
            spares = dict(spares or {})
            for c, q in s["spares"].items():
                spares[c] = max(spares.get(c, 0), q)
        if s["wants"] is not None:
            wants = set(wants or set()) | s["wants"]
    return {"spares": spares, "wants": wants}


def compare(my_spares, my_wants, side):
    """One friend: (cards I could give = my spares they want, cards they could give = their spares I want) as {card id: copies}."""
    give = {c: q for c, q in my_spares.items() if side["wants"] and c in side["wants"]}
    get = {c: q for c, q in (side["spares"] or {}).items() if c in my_wants}
    return give, get


def rank_key(r):
    """Most items both ways first (the smaller side of the swap), then the most cards in all, then the most value in all; ties by name."""
    return (-min(len(r["give"]), len(r["get"])), -(len(r["give"]) + len(r["get"])), -(r["giveTotal"] + r["getTotal"]), r["username"])


# ----------------------------------------------------------------------------------------------- reading what is on this device
def _cached(svc, gid):
    """The rows of a share already downloaded to this device ({} when none yet) - never touches the network."""
    c = svc.__dict__.get("_rowcache", {}).get(gid)
    return dict(list(c["rows"].items())) if c else None


def _friend_ids(svc):
    """[username] of every real friend (both accepted, not blocked) whose profile share I can open."""
    from .friends import _book, friend_groups
    book, groups = _book(svc), friend_groups(svc)
    return [u for u in sorted(groups) if (book.get(u) or {}).get("in") and (book.get(u) or {}).get("out") and not (book.get(u) or {}).get("blocked")]


def _shares_of(svc, u):
    """[(group id, entry)] holding what friend `u` shares with me: ordinary profile, best-friends profile (laid over it), trade lists."""
    from .friends import _norm, friend_best_groups, friend_groups
    out = []
    for f in (friend_groups(svc).get(u), friend_best_groups(svc).get(u)):
        if f:
            out.append(f)
    out += [(g, e) for g, e in _inn(svc).items() if e.get("kind") == "trade" and _norm(e.get("from")) == u]
    return out


def _my_side(svc, keep):
    """({card id: spare copies}, {wanted ids}, {card id: light dict}) for the open game, from my own lists."""
    v = svc.vault
    held = {c: q - keep for c, q in v.owned_map().items() if q > keep}
    wants = set(v.wishlist_ids())
    return held, wants, v.card_lights(list(held) + list(wants))


def _card(svc, v, cid, qty, lights):
    c = lights.get(cid) or {}
    from .cards import img
    d = {"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": true_price(v, cid, c), "qty": qty, "gameId": svc.game.id, "gameName": svc.game.name}
    try:
        d["pic"] = img(cid, c.get("set_id")) or ""
    except Exception:  # noqa: BLE001 - a missing picture never stops a match
        d["pic"] = ""
    return d


def _total(cards):
    return round(sum((c["usd"] or 0) * c["qty"] for c in cards), 2)


@api("tradefind.matches", quiet=True)
def matches(svc, keep=1):
    """Every friend I could trade with, best match first, from what is already on this device (instant).  `pending` = friends whose lists haven't been downloaded yet (refresh() fetches them)."""
    from .friends import _book
    from .safety import hidden_set, is_hidden
    try:
        keep = max(1, min(int(keep), 20))
    except (TypeError, ValueError):
        keep = 1
    v, game = svc.vault, svc.game.id
    spares, wants, lights = _my_side(svc, keep)
    hid, book = hidden_set(svc), _book(svc)
    out, pending = [], 0
    for u in _friend_ids(svc):
        profile, trades, seen = {}, [], False
        for g, e in _shares_of(svc, u):
            got = _cached(svc, g)
            if got is None:
                continue
            seen = True
            if e.get("kind") == "trade":
                trades.append(got)
            else:
                profile.update(got)                               # (a best-friends profile lays over the ordinary one; same kinds of rows, just more of them)
        if not seen:
            pending += 1
            out.append({"username": u, "nick": (book.get(u) or {}).get("nick", ""), "loaded": False, "give": [], "get": [], "giveTotal": 0, "getTotal": 0, "both": 0, "unpriced": 0,
                        "canSpares": False, "canWants": False})
            continue
        hide = lambda cid, u=u: is_hidden(hid, "card", u, f"{game}:{cid}")   # noqa: E731
        side = merge_sides([friend_side(r, game, hide) for r in [profile] + trades if r])
        give_q, get_q = compare(spares, wants, side)
        give = sorted((_card(svc, v, c, q, lights) for c, q in give_q.items()), key=lambda c: (-(c["usd"] or 0), c["name"]))
        get = sorted((_card(svc, v, c, q, lights) for c, q in get_q.items()), key=lambda c: (-(c["usd"] or 0), c["name"]))
        out.append({"username": u, "nick": (book.get(u) or {}).get("nick", ""), "loaded": True, "give": give[:SHOW], "get": get[:SHOW], "giveTotal": _total(give), "getTotal": _total(get),
                    "both": min(len(give), len(get)), "unpriced": sum(1 for c in give + get if c["usd"] is None), "canSpares": side["spares"] is not None, "canWants": side["wants"] is not None})
    done = sorted((r for r in out if r["loaded"] and (r["give"] or r["get"])), key=rank_key)
    quiet = sorted((r for r in out if r["loaded"] and not (r["give"] or r["get"])), key=lambda r: r["username"])
    wait = [r for r in out if not r["loaded"]]
    return {"game": svc.game.name, "mine": {"spares": len(spares), "wants": len(wants)}, "friends": done + quiet + wait, "pending": pending, "refreshing": bool(getattr(svc, "_tf_busy", False)),
            "keep": keep, "at": getattr(svc, "_tf_at", 0)}


@api("tradefind.refresh", quiet=True)
def refresh(svc):
    """Download what changed in my friends' shared lists, in the background, then tell the screens.  Returns at once."""
    if getattr(svc, "_tf_busy", False):
        return {"started": False}
    a = _acct(svc)
    targets = {}
    for u in _friend_ids(svc):
        for g, e in _shares_of(svc, u):
            targets[g] = e
    targets = [(g, _gk(e)) for g, e in targets.items()]
    cache = svc.__dict__.setdefault("_rowcache", {})
    svc._tf_busy = True

    def run():
        try:
            for g, key in targets:
                try:
                    sh.pull_rows_cached(a, g, key, cache)
                except Exception:  # noqa: BLE001 - one share that won't open must not stop the others (what is cached stays)
                    continue
            svc._tf_at = time.time()
        finally:
            svc._tf_busy = False
            svc.bump("tradefind", data=False)

    if INLINE:
        run()
    else:
        threading.Thread(target=run, name="tradefind-refresh", daemon=True).start()
    return {"started": True, "friends": len(targets)}
