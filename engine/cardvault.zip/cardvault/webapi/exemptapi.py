"""Dev Tools > Exempt: the owner adds or removes people (by USERNAME, never an email) who get the premium features for as long as they stay on the list.
The list lives on the account server, which enforces it (docs/server_requests.md).  Owner only here too.  An older server without the list says so plainly."""
import re

from ..cloud import skycloud as sc
from .accountapi import account
from .registry import ApiError, api

NAME = re.compile(r"^[A-Za-z0-9_.\-]{2,40}$")          # what a username looks like (no '@', so an email can never be sent or kept)
BASE = "/v1/admin/exempt"


def _owner(svc):
    if not svc.pget("cloud_admin"):
        raise ApiError("Only the owner's account can see this.")
    return account(svc, need=True)


def _name(username):
    n = str(username or "").strip().lstrip("@")
    if "@" in n or not NAME.match(n):
        raise ApiError("Type the person's username (letters and numbers), not their email.")
    return n


def _call(a, method, path, body=None):
    try:
        return a.call(method, path, body) or {}
    except sc.CloudError as e:
        if e.status == 404 and path == BASE:
            raise ApiError("The account server doesn't have the Exempt list yet - it arrives with the next server update.")
        raise ApiError(str(e))


def _rows(out):
    """Keep only the username and when it was added, whatever else the server sent."""
    rows = []
    for r in (out.get("exempt") or []):
        n = r.get("username") if isinstance(r, dict) else r
        if isinstance(n, str) and "@" not in n:
            t = r.get("added") if isinstance(r, dict) else None
            rows.append({"username": n, "added": float(t) if isinstance(t, (int, float)) else None})
    return {"exempt": rows, "total": len(rows)}


@api("dev.exempt.list", quiet=True)
def exempt_list(svc):
    return _rows(_call(_owner(svc), "GET", BASE))


@api("dev.exempt.add")
def exempt_add(svc, username=""):
    n, a = _name(username), _owner(svc)
    _call(a, "POST", BASE, {"username": n})
    return dict(_rows(_call(a, "GET", BASE)), added=n)


@api("dev.exempt.remove")
def exempt_remove(svc, username=""):
    n, a = _name(username), _owner(svc)
    _call(a, "DELETE", BASE + "/" + n)
    return dict(_rows(_call(a, "GET", BASE)), removed=n)
