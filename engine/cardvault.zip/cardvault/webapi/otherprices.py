"""The free daily prices (source_prices, filled by the daily job) as the compact list a card's detail shows under the main price.
[{source, name, url, rows:[{vendor, vendorName, finish, currency, price, day}]}] - empty when the table or the card's rows are missing (older catalogs)."""
import urllib.parse

from .. import freeprices

SOURCES = {                                   # source -> (shown name, home page, card page template or None)
    "scryfall": ("Scryfall", "https://scryfall.com", "https://scryfall.com/search?q=tcgplayer_id%3A{tcg}"),
    "ygoprodeck": ("YGOPRODeck", "https://ygoprodeck.com", "https://ygoprodeck.com/card-database/?name={name}"),
    "lorcast": ("Lorcast", "https://lorcast.com", None),
    "mtgjson": ("MTGJSON", "https://mtgjson.com", None),
}
VENDORS = {"tcgplayer": ("TCGplayer", "https://www.tcgplayer.com"), "cardmarket": ("Cardmarket", "https://www.cardmarket.com"),
           "coolstuffinc": ("CoolStuffInc", "https://www.coolstuffinc.com"), "ygoprodeck": ("YGOPRODeck", "https://ygoprodeck.com"),
           "mtgo": ("Magic Online", "https://www.mtgo.com"), "cardkingdom": ("Card Kingdom", "https://www.cardkingdom.com"),
           "manapool": ("Manapool", "https://manapool.com"), "cardhoarder": ("Cardhoarder", "https://www.cardhoarder.com")}


def for_card(conn, card_id, name="", tcg_id=""):
    groups = {}
    for r in freeprices.for_card(conn, card_id):
        if r["price"] is None:
            continue
        s = r["source"]
        if s not in groups:
            nm, home, tpl = SOURCES.get(s, (s.title(), "", None))
            url = tpl.format(tcg=urllib.parse.quote(str(tcg_id)), name=urllib.parse.quote(name or "")) if tpl and (tcg_id if "{tcg}" in tpl else name) else home
            groups[s] = {"source": s, "name": nm, "url": url or None, "rows": []}
        vn, vurl = VENDORS.get(r["vendor"], (r["vendor"], ""))
        groups[s]["rows"].append({"vendor": r["vendor"], "vendorName": vn, "vendorUrl": vurl, "finish": r["finish"], "currency": r["currency"] or "USD",
                                  "price": round(r["price"], 2), "day": r["day"] or ""})
    return list(groups.values())
