"""The sync review list's screen side: what was changed on two devices at once, and the choice to keep what is showing or switch to the other copy (cloud/conflicts.py)."""
from ..cloud import conflicts
from .registry import api

KIND_LABEL = {"lots": "Copy", "sealed": "Sealed item", "trades": "Trade", "portfolios": "Portfolio", "checklists": "Checklist", "custom_groups": "Category",
              "spending": "Spending", "dream_binders": "Binder", "grading": "Grading submission", "sold": "Sold copy", "custom_items": "Your own item", "decks": "Deck", "wishlist": "Wishlist", "tags": "Card label"}
SKIP = {"updated_at", "added", "created_at", "items", "picks"}


def _name(v, kind, rec):
    cid = rec.get("card_id")
    if cid:
        try:
            c = v.card(cid)
            if c:
                return c["name"]
        except Exception:  # noqa: BLE001 - a card no longer in the list still gets a line
            pass
        return cid
    return rec.get("name") or rec.get("label") or rec.get("partner") or rec.get("note") or KIND_LABEL.get(kind, kind)


def _short(x):
    s = "" if x is None else str(x)
    return s if len(s) <= 60 else s[:57] + "..."


@api("sync.review")
def sync_review(svc):
    """-> [{id, kind, what, name, kept, at, diff: [[field, showing, other]]}] for the open game."""
    v = svc.vault
    out = []
    for it in conflicts.pending(v.conn, v.user_id, v.game):
        shown, other = (it["mine"], it["theirs"]) if it["kept"] == "mine" else (it["theirs"], it["mine"])
        diff = [[k, _short(shown.get(k)), _short(other.get(k))] for k in sorted(set(shown) | set(other)) if k not in SKIP and shown.get(k) != other.get(k)]
        if ("items" in shown or "picks" in shown) and (shown.get("items") != other.get("items") or shown.get("picks") != other.get("picks")):
            diff.append(["cards in it", str(len(shown.get("items") or [])), str(len(other.get("items") or []))])
        out.append({"id": it["id"], "kind": it["kind"], "what": KIND_LABEL.get(it["kind"], it["kind"]), "name": _name(v, it["kind"], shown), "kept": it["kept"], "at": it["at"], "diff": diff})
    return out


@api("sync.reviewResolve", mutates=True)
def sync_review_resolve(svc, id, use="kept"):
    """use='kept': keep what is showing (the item leaves the list).  use='other': switch to the copy that lost; it is sent to your other devices at the next sync."""
    if use not in ("kept", "other"):
        use = "kept"
    ok = conflicts.resolve(svc.vault, int(id), use)
    if ok and use == "other":
        svc.vault._cl_rev += 1
        svc.reload_state()
    return {"ok": ok, "left": conflicts.count(svc.vault.conn, svc.vault.user_id)}
