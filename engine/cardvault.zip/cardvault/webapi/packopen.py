"""Open a pack or box: the cards that came out go into the collection as normal copies, an owned sealed product goes down by one, and the opening is written to the pack log
(planner.py: packs.list) - all as ONE action with ONE Undo (cardvault/rowundo.py)."""
import json

from .. import rowundo
from ..db import new_uuid, now_iso, today
from .registry import ApiError, api


def _pulls(v, pulls):
    """[{id, qty?, variant?}] (a plain card id also works) -> [{id, qty, variant}] with repeats folded together; unknown cards are refused."""
    out = {}
    for x in pulls or []:
        x = {"id": x} if isinstance(x, str) else dict(x)
        cid = x.get("id")
        if not v.card_basic(cid):
            raise ApiError("One of the cards you pulled isn't in the card list.")
        try:
            n = max(1, min(99, int(x.get("qty") or 1)))
        except (TypeError, ValueError):
            n = 1
        var = x.get("variant") or v.default_variant(cid)
        e = out.setdefault((cid, var), {"id": cid, "qty": 0, "variant": var})
        e["qty"] += n
    return list(out.values())


@api("packs.open", mutates=True)
def packs_open(svc, product="", sealed_id=None, cost=None, pulls=None, day="", note=""):
    """sealed_id = an owned sealed product (one copy is used up, and its price paid is the cost unless `cost` says otherwise); else `product` is a name you type.
    cost = the total cost in USD (optional).  pulls = [{id, qty, variant}] -> {"ok", "undo", "id", "lots"}."""
    from . import planner
    from .undoext import undoable
    v = svc.vault
    row = None
    if sealed_id:
        row = v.conn.execute("SELECT * FROM u.sealed WHERE uuid=? AND user_id=? AND game=? AND deleted=0", (sealed_id, v.user_id, v.game)).fetchone()
        if not row or (row["qty"] or 0) < 1:
            raise ApiError("That sealed product isn't in your list any more.")
        product = row["name"]
    product = (product or "").strip()
    if not product:
        raise ApiError("Say which pack or box you opened.")
    items = _pulls(v, pulls)
    if cost in (None, ""):
        cost = row["paid"] if row is not None and row["paid"] is not None else None
    else:
        try:
            cost = round(max(0.0, float(cost)), 2)
        except (TypeError, ValueError):
            raise ApiError("The cost needs to be a number.")
    day = day or today()
    entry = {"id": new_uuid(), "game": v.game, "day": day, "product": product[:120], "packs": 1, "cost": cost, "sealed": bool(row is not None),
             "pulls": [], "note": (note or "")[:200]}

    def run():
        if row is not None:
            left = (row["qty"] or 0) - 1
            v.conn.execute("UPDATE u.sealed SET qty=?, deleted=?, updated_at=? WHERE uuid=?", (max(left, 0), 1 if left <= 0 else 0, now_iso(), sealed_id))
        for it in items:
            lot = v.add_lot(it["id"], it["variant"], "Near Mint", it["qty"], price=None, purchased=day, source="Pack opening")
            entry["pulls"].append({**it, "lot": lot})
        svc.pset(planner.PACKS, json.dumps((planner._packs(svc) + [entry])[-400:]))
        v.commit()
        return {"id": entry["id"], "lots": [p["lot"] for p in entry["pulls"]]}
    return undoable(svc, f"Opened {product}", run, rows=[("sealed", [sealed_id])] if row is not None else [], keys=[planner.PACKS])
