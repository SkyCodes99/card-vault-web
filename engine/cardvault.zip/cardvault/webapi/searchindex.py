"""Search all games over the ONE shared index (tools/build_search_index.py): every card, sealed product, figure, plush, playmat ... of every game, whether or not that game's list is on this device.
The index is a small database downloaded once from Card Data (about 9 MB) and searched locally - instant and offline.  Results from a game that is not on this device open by fetching that game's list first."""
import gzip
import os
import shutil
import sqlite3
import time

import requests

from .. import games as games_mod
from .. import raritytiers
from ..db import alias_text, picture_url
from .registry import api

NATIVE = {"onepiece", "unionarena", "yugioh", "dbs", "mtg", "lorcana", "gundam", "riftbound", "palworld", "weissschwarz"}
FILE = "search.db"


def path(svc):
    return os.path.join(svc.cfg["data_dir"], FILE)


def installed(svc):
    p = path(svc)
    return os.path.exists(p) and os.path.getsize(p) > 100_000


def _base(svc):
    from .. import carddata
    return (svc.cfg.get("carddata_url") or carddata.BASE).rstrip("/")


def fetch(svc, emit=None, cancel=None):
    """Download catalog/search.db.gz (it travels with the card lists, so the same place and rules apply to it) and put it in place (kept as it was when anything looks wrong).  -> number of items."""
    base = _base(svc)
    tmp = path(svc) + ".part"
    with requests.get(f"{base}/catalog/search.db.gz", stream=True, timeout=120) as r:
        r.raise_for_status()
        raw = tmp + ".gz"
        done = 0
        with open(raw, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                if cancel is not None and cancel.is_set():
                    raise RuntimeError("cancelled")
                f.write(chunk)
                done += len(chunk)
                if emit:
                    emit("Getting the search index…", done, int(r.headers.get("Content-Length") or 0))
    with gzip.open(raw, "rb") as a, open(tmp, "wb") as b:
        shutil.copyfileobj(a, b)
    os.remove(raw)
    c = sqlite3.connect(tmp)
    try:
        n = c.execute("SELECT COUNT(*) FROM items").fetchone()[0]
    finally:
        c.close()
    if n < 1000:
        os.remove(tmp)
        raise RuntimeError("the search index looks wrong")
    os.replace(tmp, path(svc))
    return n


@api("search.index.status", quiet=True)
def status(svc):
    return {"installed": installed(svc), "mb": round(os.path.getsize(path(svc)) / 1048576, 1) if installed(svc) else 0}


@api("search.index.ensure")
def ensure(svc):
    """Start downloading the search index (once; a few MB).  -> {job}"""
    if installed(svc) and time.time() - os.path.getmtime(path(svc)) < 20 * 3600:
        return {"job": None}
    return {"job": svc.jobs.start("searchindex", "Getting the search index", lambda emit, cancel: {"items": fetch(svc, emit, cancel)}).id}


def _pic(game, gid, base, kind):
    if base:
        if game.startswith("pokemon") and base.startswith("http") and "tcgdex" in base:
            return picture_url(base, "low")
        return base
    if game in NATIVE:
        return f"https://tcgplayer-cdn.tcgplayer.com/product/{gid}_{400 if kind else 200}w.jpg"
    return ""


def query(svc, q="", games=None, rarity="", set_text="", owned="", price_min=None, price_max=None, sort="relevance", limit=120, offset=0, year_min=None, year_max=None, priced="", kinds=None, ctype="",
          pocket=False, tier=""):
    """Same answer as search.query, read from the index."""
    v = svc.vault
    names = {g.id: g for g in games_mod.GAMES}
    inst = {g.id for g in games_mod.GAMES if os.path.exists(os.path.join(svc.cfg["data_dir"], "games", g.id, "cards.db"))}
    want = [g for g in (games or []) if isinstance(g, str) and g in names]
    kinds = {k for k in (kinds or []) if k in ("cards", "sealed", "misc")} or {"cards", "sealed", "misc"}
    c = sqlite3.connect("file:" + path(svc).replace("\\", "/") + "?mode=ro", uri=True, timeout=10)
    c.row_factory = sqlite3.Row
    try:
        try:                                                                       # what you own / wishlisted, as a temporary table so "owned / not owned / wishlist" can be asked in SQL
            c.execute("CREATE TEMP TABLE mine(game TEXT, id TEXT, q INTEGER, w INTEGER, PRIMARY KEY(game, id))")
            rows = [(r[0], r[1], r[2], 0) for r in v.conn.execute("SELECT game, card_id, SUM(qty) FROM u.lots WHERE user_id=? AND deleted=0 AND qty>0 GROUP BY game, card_id", (v.user_id,))]
            rows += [(r[0], r[1], 0, 1) for r in v.conn.execute("SELECT game, card_id FROM u.wishlist WHERE user_id=?", (v.user_id,))]
            for r in rows:
                c.execute("INSERT INTO mine VALUES(?,?,?,?) ON CONFLICT(game,id) DO UPDATE SET q=q+excluded.q, w=w+excluded.w", r)
        except sqlite3.Error:
            pass
        where, args = [], {}
        for i, w in enumerate(alias_text(q).replace("#", " ").split()):
            where.append(f"(i.name LIKE :w{i} OR s.t LIKE :w{i} OR i.num LIKE :w{i})")
            args[f"w{i}"] = f"%{w}%"
        if want:
            where.append("i.game IN (" + ",".join(f":g{k}" for k in range(len(want))) + ")")
            args.update({f"g{k}": g for k, g in enumerate(want)})
        if kinds != {"cards", "sealed", "misc"}:                                   # cards = card-game cards, misc = toy / figure / plush / accessory lists, sealed = sealed products of any game
            miss = [g.id for g in games_mod.GAMES if games_mod.is_misc(g.id)]
            ph = ",".join(f":mg{k}" for k in range(len(miss))) or "''"
            args.update({f"mg{k}": g for k, g in enumerate(miss)})
            parts = []
            if "cards" in kinds:
                parts.append(f"(i.kind=0 AND i.game NOT IN ({ph}))")
            if "misc" in kinds:
                parts.append(f"(i.kind=0 AND i.game IN ({ph}))")
            if "sealed" in kinds:
                parts.append("i.kind=1")
            where.append("(" + " OR ".join(parts) + ")")
        if rarity:
            where.append("r.t LIKE :rar")
            args["rar"] = f"%{rarity.lower()}%"
        if ctype:
            where.append("t.t LIKE :ct")
            args["ct"] = f"%{ctype.lower()}%"
        if tier:                                                                   # a rarity tier that means the same in every game (see gamefacets.TIERS)
            where.append(raritytiers.tier_case("r.t") + " = :tier")
            args["tier"] = tier
        for k, tok in enumerate((set_text or "").lower().split()):
            where.append(f"s.t LIKE :st{k}")
            args[f"st{k}"] = f"%{tok}%"
        if price_min is not None:
            where.append("i.usd >= :pmin")
            args["pmin"] = float(price_min)
        if price_max is not None:
            where.append("i.usd <= :pmax")
            args["pmax"] = float(price_max)
        if year_min not in (None, ""):
            where.append("i.yr >= :y0")
            args["y0"] = int(year_min)
        if year_max not in (None, ""):
            where.append("i.yr BETWEEN 1 AND :y1")
            args["y1"] = int(year_max)
        if priced == "yes":
            where.append("i.usd > 0")
        elif priced == "no":
            where.append("(i.usd IS NULL OR i.usd <= 0)")
        if owned == "yes":
            where.append("EXISTS (SELECT 1 FROM mine m WHERE m.game=i.game AND m.id=i.id AND m.q>0)")
        elif owned == "no":
            where.append("NOT EXISTS (SELECT 1 FROM mine m WHERE m.game=i.game AND m.id=i.id AND m.q>0)")
        elif owned == "wish":
            where.append("EXISTS (SELECT 1 FROM mine m WHERE m.game=i.game AND m.id=i.id AND m.w>0)")
        if not pocket:
            where.append("i.fl=0")                                                    # TCG Pocket (digital) stays out unless it was turned on
        frm = "FROM items i LEFT JOIN strs s ON s.i=i.sid LEFT JOIN strs r ON r.i=i.rid LEFT JOIN strs t ON t.i=i.tid"
        qlow = alias_text(q).strip()
        order = {
            "relevance": "(lower(i.name)=:q) DESC, (lower(i.name) LIKE :qs) DESC, i.yr DESC, i.name",
            "newest": "i.yr DESC, i.name", "oldest": "(i.yr IS NULL), i.yr ASC, i.name",
            "price": "COALESCE(i.usd,-1) DESC, i.name", "priceasc": "(i.usd IS NULL), i.usd ASC, i.name",
            "name": "i.name COLLATE NOCASE", "namez": "i.name COLLATE NOCASE DESC", "set": "s.t COLLATE NOCASE, i.name", "rarity": "(r.t IS NULL OR r.t=''), r.t COLLATE NOCASE, i.name",
        }.get(sort or "relevance", "i.name")
        args["q"], args["qs"] = qlow, qlow + "%"
        # ONE scan of the 330,000 items (the LIKE filters are the slow part, ~150 ms each time); the count, the per-game counts and the ranked rows all read the short list of hits it leaves
        nog = [w for w in where if not w.startswith("i.game IN")]
        gw = [w for w in where if w.startswith("i.game IN")]
        c.execute("CREATE TEMP TABLE hit AS SELECT i.rowid AS rid, i.game AS game " + frm + ((" WHERE " + " AND ".join(nog)) if nog else ""),
                  {k: val for k, val in args.items() if k not in ("q", "qs") and not k.startswith("g")})
        counts = {g: n for g, n in c.execute("SELECT game, COUNT(*) FROM hit GROUP BY game")}
        total = sum(counts.get(g, 0) for g in want) if want else sum(counts.values())
        lim, off = max(1, min(400, int(limit))), max(0, int(offset))
        rows = c.execute("SELECT i.game, i.id, i.kind, i.name, s.t AS sname, i.num, r.t AS rar, i.usd, i.img FROM hit h JOIN items i ON i.rowid=h.rid LEFT JOIN strs s ON s.i=i.sid LEFT JOIN strs r ON r.i=i.rid"
                         + ((" WHERE " + " AND ".join(gw)) if gw else "") + " ORDER BY " + order + f" LIMIT {lim} OFFSET {off}", args).fetchall()
        single = want[0] if len(want) == 1 else (next(iter(counts)) if len(counts) == 1 and not want else "")
        rars, types = [], []
        if single:
            rars = [{"name": r[0], "n": r[1]} for r in c.execute("SELECT r.t, COUNT(*) FROM items i JOIN strs r ON r.i=i.rid WHERE i.game=? AND r.t!='' GROUP BY r.t ORDER BY 2 DESC LIMIT 40", (single,))]
            tc = {}
            for (tv, n) in c.execute("SELECT t.t, COUNT(*) FROM items i JOIN strs t ON t.i=i.tid WHERE i.game=? AND t.t!='' GROUP BY t.t", (single,)):
                for part in str(tv).replace(";", ",").split(","):
                    part = part.strip()
                    if part:
                        tc[part] = tc.get(part, 0) + n
            types = [{"name": k, "n": n} for k, n in sorted(tc.items(), key=lambda kv: -kv[1])[:40]]
        mine = {}
        for gid in {r["game"] for r in rows}:
            ids = [r["id"] for r in rows if r["game"] == gid]
            for cid, qty, w in c.execute(f"SELECT id, q, w FROM mine WHERE game=? AND id IN ({','.join('?' * len(ids))})", [gid, *ids]):
                mine[(gid, cid)] = (qty, w)
    finally:
        c.close()
    results = []
    for r in rows:
        qty, w = mine.get((r["game"], r["id"]), (0, 0))
        item = {"game": r["game"], "gameName": names[r["game"]].name if r["game"] in names else r["game"], "id": r["id"], "set": r["sname"] or "", "name": r["name"], "number": r["num"] or "",
                "rarity": r["rar"] or ("Sealed product" if r["kind"] else ""), "img": _pic(r["game"], r["id"], r["img"], r["kind"]), "owned": qty, "wish": bool(w), "price": r["usd"], "installed": r["game"] in inst}
        if r["kind"]:
            item["type"] = "sealed"
        results.append(item)
    return {"results": results, "total": total, "games": [{"id": g.id, "name": g.name, "n": counts.get(g.id, 0), "installed": g.id in inst, "family": g.family} for g in games_mod.GAMES if g.available],
            "rarities": rars, "capped": False, "types": types, "typeLabel": names[single].type_label if single else "Type", "single": single, "missing": [], "viaIndex": True}
