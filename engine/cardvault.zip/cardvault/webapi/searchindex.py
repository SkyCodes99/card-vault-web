"""Search all games over the ONE shared index (tools/build_search_index.py): every card, sealed product, figure, plush, playmat ... of every game, whether or not that game's list is on this device.
The index is a small database downloaded once from Card Data (about 9 MB) and searched locally - instant and offline.  Results from a game that is not on this device open by fetching that game's list first."""
import gzip
import os
import re
import shutil
import sqlite3
import threading
import time

import requests

from .. import fuzzy
from .. import games as games_mod
from .. import raritytiers, searchfold
from ..db import alias_text, picture_url
from .registry import api

from ..tcggames import NATIVE                    # the games whose picture is TCGplayer's own (the ONE table: tcggames.py)
FILE = "search.db"


def path(svc):
    return os.path.join(svc.cfg["data_dir"], FILE)


def installed(svc):
    p = path(svc)
    return os.path.exists(p) and os.path.getsize(p) > 100_000


def _base(svc):
    from .. import carddata
    return (svc.cfg.get("carddata_url") or carddata.BASE).rstrip("/")


def fetch(svc, emit=None, cancel=None):
    """Download catalog/search.db.gz (it travels with the card lists, so the same place and rules apply to it) and put it in place (kept as it was when anything looks wrong).  -> number of items."""
    base = _base(svc)
    tmp = path(svc) + ".part"
    with requests.get(f"{base}/catalog/search.db.gz", stream=True, timeout=120) as r:
        r.raise_for_status()
        raw = tmp + ".gz"
        done = 0
        with open(raw, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                if cancel is not None and cancel.is_set():
                    raise RuntimeError("cancelled")
                f.write(chunk)
                done += len(chunk)
                if emit:
                    emit("Getting the search index…", done, int(r.headers.get("Content-Length") or 0))
    with gzip.open(raw, "rb") as a, open(tmp, "wb") as b:
        shutil.copyfileobj(a, b)
    os.remove(raw)
    c = sqlite3.connect(tmp)
    try:
        n = c.execute("SELECT COUNT(*) FROM items").fetchone()[0]
    finally:
        c.close()
    if n < 1000:
        os.remove(tmp)
        raise RuntimeError("the search index looks wrong")
    with _lock:
        release()                                                                  # (Windows: a file that is open can't be replaced)
        os.replace(tmp, path(svc))
    return n


# ---- one connection to the index, kept between searches (search-as-you-type asks every few keys): what you own is copied in only when your collection changed, and a search that
#      only adds letters to the last one looks only through the last one's hits ("char" -> "chari": 5,000 rows instead of 330,000)
_lock = threading.RLock()
_open = {}


def release():
    """Close the kept connection (the index is about to be replaced, or the app is closing)."""
    with _lock:
        c = _open.get("conn")
        _open.clear()
        if c is not None:
            c.close()


def _conn(svc):
    p = path(svc)
    st = os.stat(p)
    key = (p, st.st_mtime_ns, st.st_size)
    if _open.get("key") != key:
        release()
        c = sqlite3.connect("file:" + p.replace("\\", "/") + "?mode=ro", uri=True, timeout=10, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("CREATE TEMP TABLE mine(game TEXT, id TEXT, q INTEGER, w INTEGER, PRIMARY KEY(game, id))")
        _open.update(key=key, conn=c, mine=None, last=None)
    return _open["conn"]


def _fill_mine(svc, c):
    """What you own / wishlisted, as the temporary table 'mine' (so "owned / not owned / wishlist" can be asked in SQL) - copied again only after a change to your collection."""
    v = svc.vault
    stamp = (v.user_id, id(v), getattr(svc, "rev", None))
    if _open.get("mine") == stamp:
        return
    _open["last"] = None
    mine = {}
    try:
        for g, cid, q in v.conn.execute("SELECT game, card_id, SUM(qty) FROM u.lots WHERE user_id=? AND deleted=0 AND qty>0 GROUP BY game, card_id", (v.user_id,)):
            mine[(g, cid)] = [g, cid, q, 0]
        for g, cid in v.conn.execute("SELECT game, card_id FROM u.wishlist WHERE user_id=?", (v.user_id,)):
            mine.setdefault((g, cid), [g, cid, 0, 0])[3] = 1
    except sqlite3.Error:
        mine = {}
    c.execute("DELETE FROM mine")
    c.executemany("INSERT INTO mine VALUES(?,?,?,?)", mine.values())
    _open["mine"] = stamp


def _narrows(old, new):
    """True when every item matching the words `new` also matches the words `old` (each old word is part of a new one), so the new search need only look through the old hits."""
    return old is not None and all(any(o in n for n in new) for o in old)


@api("search.index.status", quiet=True)
def status(svc):
    return {"installed": installed(svc), "mb": round(os.path.getsize(path(svc)) / 1048576, 1) if installed(svc) else 0}


@api("search.index.ensure")
def ensure(svc):
    """Start downloading the search index (once; a few MB).  -> {job}"""
    if installed(svc) and time.time() - os.path.getmtime(path(svc)) < 20 * 3600:
        return {"job": None}
    return {"job": svc.jobs.start("searchindex", "Getting the search index", lambda emit, cancel: {"items": fetch(svc, emit, cancel)}).id}


def _pic(game, gid, base, kind):
    if base:
        if game.startswith("pokemon") and base.startswith("http") and "tcgdex" in base:
            return picture_url(base, "low")
        return base
    if game in NATIVE:
        return f"https://tcgplayer-cdn.tcgplayer.com/product/{gid}_{400 if kind else 200}w.jpg"
    return ""


def query(svc, q="", games=None, rarity="", set_text="", owned="", price_min=None, price_max=None, sort="relevance", limit=120, offset=0, year_min=None, year_max=None, priced="", kinds=None, ctype="",
          pocket=False, tier=""):
    """Same answer as search.query, read from the index."""
    names = {g.id: g for g in games_mod.GAMES}
    inst = {g.id for g in games_mod.GAMES if os.path.exists(os.path.join(svc.cfg["data_dir"], "games", g.id, "cards.db"))}
    want = [g for g in (games or []) if isinstance(g, str) and g in names]
    kinds = {k for k in (kinds or []) if k in ("cards", "sealed", "misc")} or {"cards", "sealed", "misc"}
    with _lock:
        c = _conn(svc)
        _fill_mine(svc, c)
        rest = (names, inst, want, kinds, q, rarity, set_text, owned, price_min, price_max, sort, limit, offset, year_min, year_max, priced, ctype, pocket, tier)
        out = _query(c, *rest)
        if not out["total"] and (q or "").strip() and "accents" not in _open:   # nothing found while the accent list is still being read: finish it and ask once more ('pokemon' -> 'Pokémon')
            _accent_map(c)
            out = _query(c, *rest)
        if out["total"] < fuzzy.FEW and (q or "").strip():                      # few exact hits: the same search with every unknown word corrected ('charzard' -> 'charizard'), exact hits first
            fixed = fuzzy.correct_text(_vocab(c), alias_text(q).replace("#", " ").strip())
            if fixed:
                out = _query(c, *rest, fixed=fixed)
        return out


RANK_NORM_MAX = 20000


def _vocab(c):
    """The name words of every game (typo tolerance, cardvault/fuzzy.py), kept with the open index.  The index carries them in its 'words' table; one published before that is read from the names."""
    v = _open.get("vocab")
    if v is None:
        try:
            counts = dict(c.execute("SELECT w, n FROM words"))
        except sqlite3.Error:
            counts = fuzzy.count_words((r[0] for r in c.execute("SELECT DISTINCT name FROM items")))
        v = _open["vocab"] = fuzzy.Vocab(counts)
    return v


_ACCENT_MAX = 6


_ACCENT_ROWS, _ACCENT_STEP = 50000, 0.08         # the accent list is read a slice of rows at a time, ~0.08 s per search, so no keystroke waits for the whole 0.3-0.5 s scan


def _accent_map(c, budget=None):
    """{folded word: {the words of names / set names it stands for}} for every word with an accent ('pokemon' -> 'Pokémon'), kept with the open index.  SQLite's LIKE folds plain letters only.
    Built a slice of rows per call: budget = seconds this call may spend (None: finish now).  -> the map, or None while it is not complete (that search goes without accents)."""
    m = _open.get("accents")
    if m is not None:
        return m
    st = _open.setdefault("accent_build", {"m": {}, "next": 0, "top": c.execute("SELECT COALESCE(MAX(rowid), 0) FROM items").fetchone()[0]})
    end = None if budget is None else time.perf_counter() + budget

    def add(t):
        for tok in re.findall(r"\w+", t or ""):
            f = searchfold.fold(tok)
            if not tok.isascii() and f.isascii() and len(f) == len(tok) and f != tok.lower():
                st["m"].setdefault(f, set()).add(tok)
    while st["next"] <= st["top"]:
        a = st["next"]
        st["next"] = a + _ACCENT_ROWS
        for (t,) in c.execute("SELECT name FROM items WHERE rowid >= ? AND rowid < ? AND name GLOB '*[^ -~]*'", (a, a + _ACCENT_ROWS)):
            add(t)
        if end is not None and time.perf_counter() >= end and st["next"] <= st["top"]:
            return None
    for (t,) in c.execute("SELECT t FROM strs WHERE t GLOB '*[^ -~]*'"):
        add(t)
    _open.pop("accent_build", None)
    m = _open["accents"] = st["m"]
    return m


def _accented(c, w):
    """How the typed word `w` is written in names that carry an accent or a sign: 'pokemon' -> ['Pokémon', 'POKÉMON'], 'x' -> ['×'] ('Pokémon Center × Bear Walker')."""
    if w == "x":
        return ["×"]
    if not w.isascii() or len(w) < 3:
        return []
    out = []
    for f, toks in (_accent_map(c, _ACCENT_STEP) or {}).items():
        k = f.find(w)
        if k >= 0:
            out += [t[k:k + len(w)] for t in toks if t[k:k + len(w)].lower() != w]
    return list(dict.fromkeys(out))[:_ACCENT_MAX]


_WORD_END = "' ' || replace(replace(replace(replace(replace(replace(lower(i.name), '(', ' '), ')', ' '), ':', ' '), ',', ' '), '-', ' '), '/', ' ') || ' '"   # (the name with its signs as spaces)


def _whole_words(words, args, hits):
    """The ranking tier after the exact / starts-with names: things whose OWN name has every typed word as a word ('skateboard' -> 'Mew Skateboard', not a card of the set
    'ReVive Skateboards Promos'; 'bear walker' -> 'Bear Walker: ...', not 'Bitterbloom Bearer ... Planeswalker').  -> ', (...) DESC' or ''."""
    ws = [w for w in words if w.isascii() and w.isalpha() and len(w) >= 3]
    if not ws or hits > RANK_NORM_MAX:
        return ""
    for k, w in enumerate(ws):
        args[f"ww{k}"] = f"% {w} %"
    return ", (" + " AND ".join(f"{_WORD_END} LIKE :ww{k}" for k in range(len(ws))) + ") DESC"


def _query(c, names, inst, want, kinds, q, rarity, set_text, owned, price_min, price_max, sort, limit, offset, year_min, year_max, priced, ctype, pocket, tier, fixed=None):
    words = alias_text(q).replace("#", " ").split()
    where, args, exact = [], {}, []
    fwords = fixed.split() if fixed else None                                   # (typos corrected: each word may also be any of its corrections - the exact hits still come first)
    accents = False
    for i, w in enumerate(words):
        alts = [w] + [a for a in fuzzy.alternatives(fwords[i]) if a != w] if fwords else [w]
        conds = []
        for j, a in enumerate(alts):
            k = f"w{i}" if not j else f"w{i}_{j}"
            cond = f"(i.name LIKE :{k} OR i.num LIKE :{k} OR i.sid IN (SELECT i FROM strs WHERE t LIKE :{k}))" if not j else f"i.name LIKE :{k}"   # (the set names that match, found once - not a look-up per item: 0.2 s -> 0.1; a corrected word comes from the names)
            acc = _accented(c, w) if not j else []                             # the same word with its accent or sign: 'pokemon' finds 'Pokémon', 'flabebe' 'Flabébé'
            for m, t in enumerate(acc):
                ka = f"w{i}a{m}"
                cond += f" OR i.name LIKE :{ka} OR i.sid IN (SELECT i FROM strs WHERE t LIKE :{ka})"
                args[ka] = f"%{t}%"
            if acc:
                cond, accents = f"({cond})", True
            conds.append(cond)
            args[k] = f"%{a}%"
        if w.isdigit() and w.startswith("0") and len(w) > 1:                    # "025": the card number 25 too
            conds.append(f"(i.num GLOB '[0-9]*' AND CAST(i.num AS INTEGER)=:n{i})")
            args[f"n{i}"] = int(w)
        exact.append(conds[0])
        where.append(conds[0] if len(conds) == 1 else "(" + " OR ".join(conds) + ")")
    if want:
        where.append("i.game IN (" + ",".join(f":g{k}" for k in range(len(want))) + ")")
        args.update({f"g{k}": g for k, g in enumerate(want)})
    if kinds != {"cards", "sealed", "misc"}:                                   # cards = card-game cards, misc = toy / figure / plush / accessory lists, sealed = sealed products of any game
        miss = [g.id for g in games_mod.GAMES if games_mod.is_misc(g.id)]
        ph = ",".join(f":mg{k}" for k in range(len(miss))) or "''"
        args.update({f"mg{k}": g for k, g in enumerate(miss)})
        parts = []
        if "cards" in kinds:
            parts.append(f"(i.kind=0 AND i.game NOT IN ({ph}))")
        if "misc" in kinds:
            parts.append(f"(i.kind=0 AND i.game IN ({ph}))")
        if "sealed" in kinds:
            parts.append("i.kind=1")
        where.append("(" + " OR ".join(parts) + ")")
    if rarity:
        where.append("r.t LIKE :rar")
        args["rar"] = f"%{rarity.lower()}%"
    if ctype:
        where.append("t.t LIKE :ct")
        args["ct"] = f"%{ctype.lower()}%"
    if tier:                                                                   # a rarity tier that means the same in every game (see gamefacets.TIERS)
        where.append(raritytiers.tier_case("r.t") + " = :tier")
        args["tier"] = tier
    for k, tok in enumerate((set_text or "").lower().split()):
        where.append(f"i.sid IN (SELECT i FROM strs WHERE t LIKE :st{k})")
        args[f"st{k}"] = f"%{tok}%"
    if price_min is not None:
        where.append("i.usd >= :pmin")
        args["pmin"] = float(price_min)
    if price_max is not None:
        where.append("i.usd <= :pmax")
        args["pmax"] = float(price_max)
    if year_min not in (None, ""):
        where.append("i.yr >= :y0")
        args["y0"] = int(year_min)
    if year_max not in (None, ""):
        where.append("i.yr BETWEEN 1 AND :y1")
        args["y1"] = int(year_max)
    if priced == "yes":
        where.append("i.usd > 0")
    elif priced == "no":
        where.append("(i.usd IS NULL OR i.usd <= 0)")
    if owned == "yes":
        where.append("EXISTS (SELECT 1 FROM mine m WHERE m.game=i.game AND m.id=i.id AND m.q>0)")
    elif owned == "no":
        where.append("NOT EXISTS (SELECT 1 FROM mine m WHERE m.game=i.game AND m.id=i.id AND m.q>0)")
    elif owned == "wish":
        where.append("EXISTS (SELECT 1 FROM mine m WHERE m.game=i.game AND m.id=i.id AND m.w>0)")
    if not pocket:
        where.append("i.fl=0")                                                    # TCG Pocket (digital) stays out unless it was turned on
    frm = "FROM items i LEFT JOIN strs s ON s.i=i.sid LEFT JOIN strs r ON r.i=i.rid LEFT JOIN strs t ON t.i=i.tid"
    qlow = alias_text(q).strip()
    # ONE scan of the 330,000 items (the LIKE filters are the slow part, ~150 ms each time) - or of the last search's hits when this one only adds letters to it; the count, the per-game counts
    # and the ranked rows all read the short list of hits it leaves
    nog = [w for w in where if not w.startswith("i.game IN")]
    gw = [w for w in where if w.startswith("i.game IN")]
    scan = {k: val for k, val in args.items() if k not in ("q", "qs", "qn", "qns") and not k.startswith("g")}
    rest = ([w for w in nog if not w.startswith("(i.name LIKE :w")], sorted((k, str(val)) for k, val in scan.items() if not k.startswith("w")))
    low = [w.lower() for w in words] if not fixed and not accents and all(w.isascii() for w in words) else None             # (LIKE ignores capitals of plain letters only; accented spellings: always the full scan)
    last = _open.get("last")
    src = frm.replace("FROM items i", "FROM hit h JOIN items i ON i.rowid=h.rid") if low and last and last[0] == rest and _narrows(last[1], low) else frm
    c.execute("DROP TABLE IF EXISTS temp.hit_new")
    c.execute("CREATE TEMP TABLE hit_new AS SELECT i.rowid AS rid, i.game AS game " + src + ((" WHERE " + " AND ".join(nog)) if nog else ""), scan)
    c.execute("DROP TABLE IF EXISTS temp.hit")
    c.execute("ALTER TABLE temp.hit_new RENAME TO hit")
    _open["last"] = (rest, low) if low else None
    counts = {g: n for g, n in c.execute("SELECT game, COUNT(*) FROM hit GROUP BY game")}
    total = sum(counts.get(g, 0) for g in want) if want else sum(counts.values())
    ntext, nums = fuzzy.split_query(fuzzy.first_choice(fixed or qlow))                     # (corrected words are what exact names are ranked against)
    nn = fuzzy.norm_sql("lower(i.name)") if sum(counts.values()) <= RANK_NORM_MAX else "lower(i.name)"      # (made like fuzzy.norm() for the ranking: with 200,000 hits that is 0.6 s, and exact names matter little among so many)
    if nums and ntext:                                                         # 'pika 25': a Pikachu numbered 25 first, then the names starting with 'pika'
        has = "(i.num GLOB '[0-9]*' AND CAST(i.num AS INTEGER) IN (" + ",".join(str(int(n)) for n in nums) + "))"
        rel = f"({has} AND {nn}=:qn) DESC, ({has} AND {nn} LIKE :qns) DESC, ({nn} LIKE :qns) DESC"
    elif nums or not ntext:
        rel = "(lower(i.name)=:q) DESC"
    elif nn == "lower(i.name)":                                                # many hits: the same tiers without lower() (SQLite's lower() and LIKE both fold plain letters only, so
        rq0 = fuzzy.first_choice(fixed) if fixed else qlow                     #  these match exactly the same names), and once when the made-like name is the typed one - 0.15 s -> 0.09 on 90,000 hits
        one = ntext == rq0
        rel = "(i.name=:q COLLATE NOCASE" + ("" if one else " OR i.name=:qn COLLATE NOCASE") + ") DESC, (i.name LIKE :qs" + ("" if one else " OR i.name LIKE :qns") + ") DESC"
    else:
        rel = f"(lower(i.name)=:q OR {nn}=:qn) DESC, (lower(i.name) LIKE :qs OR {nn} LIKE :qns) DESC"
    lead = ("(" + " AND ".join(exact) + ") DESC, ") if fixed else ""             # (hits for the words as typed come before hits for the corrected words)
    order = {
        "relevance": lead + rel + _whole_words(words, args, sum(counts.values())) + ", i.yr DESC, i.name",
        "newest": "i.yr DESC, i.name", "oldest": "(i.yr IS NULL), i.yr ASC, i.name",
        "price": "COALESCE(i.usd,-1) DESC, i.name", "priceasc": "(i.usd IS NULL), i.usd ASC, i.name",
        "name": "i.name COLLATE NOCASE", "namez": "i.name COLLATE NOCASE DESC", "set": "s.t COLLATE NOCASE, i.name", "rarity": "(r.t IS NULL OR r.t=''), r.t COLLATE NOCASE, i.name",
    }.get(sort or "relevance", "i.name")
    rq = fuzzy.first_choice(fixed) if fixed else qlow
    args["q"], args["qs"], args["qn"], args["qns"] = rq, rq + "%", ntext, ntext + "%"
    lim, off = max(1, min(400, int(limit))), max(0, int(offset))
    joins = (" LEFT JOIN strs s ON s.i=i.sid" if "s.t" in order else "") + (" LEFT JOIN strs r ON r.i=i.rid" if "r.t" in order else "")
    rids = [x[0] for x in c.execute("SELECT h.rid FROM hit h JOIN items i ON i.rowid=h.rid" + joins + ((" WHERE " + " AND ".join(gw)) if gw else "")
                                    + " ORDER BY " + order + f" LIMIT {lim} OFFSET {off}", args)]       # (the page's rows are picked first, then only they are read in full: not set and rarity names for every hit)
    got = {x["rid"]: x for x in c.execute("SELECT i.rowid AS rid, i.game, i.id, i.kind, i.name, s.t AS sname, i.num, r.t AS rar, i.usd, i.img FROM items i LEFT JOIN strs s ON s.i=i.sid LEFT JOIN strs r ON r.i=i.rid"
                                          f" WHERE i.rowid IN ({','.join('?' * len(rids))})", rids)} if rids else {}
    rows = [got[x] for x in rids]
    single = want[0] if len(want) == 1 else (next(iter(counts)) if len(counts) == 1 and not want else "")
    rars, types = [], []
    if single:
        rars = [{"name": r[0], "n": r[1]} for r in c.execute("SELECT r.t, COUNT(*) FROM items i JOIN strs r ON r.i=i.rid WHERE i.game=? AND r.t!='' GROUP BY r.t ORDER BY 2 DESC LIMIT 40", (single,))]
        tc = {}
        for (tv, n) in c.execute("SELECT t.t, COUNT(*) FROM items i JOIN strs t ON t.i=i.tid WHERE i.game=? AND t.t!='' GROUP BY t.t", (single,)):
            for part in str(tv).replace(";", ",").split(","):
                part = part.strip()
                if part:
                    tc[part] = tc.get(part, 0) + n
        types = [{"name": k, "n": n} for k, n in sorted(tc.items(), key=lambda kv: -kv[1])[:40]]
    mine = {}
    for gid in {r["game"] for r in rows}:
        ids = [r["id"] for r in rows if r["game"] == gid]
        for cid, qty, w in c.execute(f"SELECT id, q, w FROM mine WHERE game=? AND id IN ({','.join('?' * len(ids))})", [gid, *ids]):
            mine[(gid, cid)] = (qty, w)
    results = []
    for r in rows:
        qty, w = mine.get((r["game"], r["id"]), (0, 0))
        item = {"game": r["game"], "gameName": names[r["game"]].name if r["game"] in names else r["game"], "id": r["id"], "set": r["sname"] or "", "name": r["name"], "number": r["num"] or "",
                "rarity": r["rar"] or ("Sealed product" if r["kind"] else ""), "img": _pic(r["game"], r["id"], r["img"], r["kind"]), "owned": qty, "wish": bool(w), "price": r["usd"], "installed": r["game"] in inst}
        if r["kind"]:
            item["type"] = "sealed"
        results.append(item)
    return {"results": results, "total": total, "games": [{"id": g.id, "name": g.name, "n": counts.get(g.id, 0), "installed": g.id in inst, "family": g.family} for g in games_mod.GAMES if g.available],
            "rarities": rars, "capped": False, "types": types, "typeLabel": names[single].type_label if single else "Type", "single": single, "missing": [], "viaIndex": True}
