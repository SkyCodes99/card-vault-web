"""Edit many cards at once ("Edit selected..." on the Cards screen): condition, graded / raw, language, price paid, portfolio and wishlist label.  Only the fields that are sent change.
It is ONE database transaction and ONE entry in the recent-actions log, so one Undo puts every copy (and every label) back.
The wishlist label lives in an account setting, not the database, so the action also remembers each card's earlier label (an op of type "wlabel") and undo_labels() puts them back."""
import json

from .. import wishlabels
from ..db import CONDITIONS, GRADERS
from .registry import ApiError, api

FIELDS = ("condition", "language", "graded", "company", "grade", "paid", "portfolio", "label", "location", "edition", "notes")


def _clean(svc, fields):
    """-> the checked fields (only the ones sent).  Everything is checked BEFORE anything is written."""
    from .cards import LANGUAGES
    v = svc.vault
    f = {k: val for k, val in (fields or {}).items() if k in FIELDS}
    if not f:
        raise ApiError("Choose what to change first.")
    if "condition" in f and f["condition"] not in CONDITIONS:
        raise ApiError("Pick one of the conditions in the list.")
    if "language" in f and f["language"] not in LANGUAGES:
        raise ApiError("Pick one of the languages in the list.")
    if "company" in f and f["company"] and f["company"] not in GRADERS:
        raise ApiError("Pick one of the grading companies in the list.")
    if "paid" in f:
        if f["paid"] in (None, ""):
            f["paid"] = None
        else:
            try:
                f["paid"] = round(float(f["paid"]), 4)
            except (TypeError, ValueError):
                raise ApiError("The price paid must be a number.")
            if f["paid"] < 0:
                raise ApiError("The price paid can't be below zero.")
    if "graded" in f:
        f["graded"] = bool(f["graded"])
    if "portfolio" in f:
        pid = "" if f["portfolio"] in ("main", "", None) else f["portfolio"]
        if pid and not any(p["uuid"] == pid for p in v.portfolios()):
            raise ApiError("That portfolio doesn't exist.")
        v.check_accepts(pid, v.item_kind())
        f["portfolio"] = pid
    if "label" in f:
        f["label"] = f["label"] or ""
        if f["label"] and f["label"] not in {x["id"] for x in wishlabels.load(svc)["labels"]}:
            raise ApiError("That label is gone - pick another.")
    return f


def _changes(lot, f):
    """What would change on this copy (only values that really differ)."""
    new = {}
    graded = bool(lot["graded"])
    if "graded" in f:
        graded = f["graded"]
        if graded and not lot["graded"]:
            new.update(graded=1, condition="Graded")
        elif not graded and lot["graded"]:
            new.update(graded=0, grade_company="", grade="", cert="")
            if "condition" not in f:
                new["condition"] = "Near Mint"
    if graded:
        if "company" in f:
            new["grade_company"] = f["company"] or ""
        if "grade" in f:
            new["grade"] = f["grade"] or ""
    elif "condition" in f:                                                        # (a graded copy's condition is its grade: left alone)
        new["condition"] = f["condition"]
    if "language" in f:
        new["language"] = f["language"]
    if "paid" in f:
        new["purchase_price"] = f["paid"]
    if "portfolio" in f:
        new["portfolio"] = f["portfolio"]
    for k in ("location", "edition", "notes"):
        if k in f:
            new[k] = str(f[k] or "") if k == "notes" else str(f[k] or "").strip()
    return {k: val for k, val in new.items() if not _same(lot[k], val)}


def _same(old, new):
    if old in (None, "") or new in (None, ""):
        return old in (None, "") and new in (None, "")                              # (nothing and nothing; a price of 0 is a price)
    return old == new


@api("lots.bulkEdit", mutates=True)
def lots_bulk_edit(svc, ids, fields):
    """Change the ticked details of every copy of these cards (in the portfolios being looked at) at once; the label goes on the picked cards that are on the wishlist.
    fields: any of condition, language, location (stored in), edition, notes, graded (true = graded, false = raw), company, grade, paid (each; '' clears), portfolio ('main' or an id), label (a wishlist label id; '' = none).
    -> {items: how many cards changed, copies, labelled, undo}.  One Undo puts everything back."""
    from .cards import with_undo
    v = svc.vault
    f = _clean(svc, fields)
    ids = [i for i in dict.fromkeys(ids or []) if isinstance(i, str)]
    wish = v.wishlist_ids()
    old_labels = wishlabels.of_game(svc, v.game)[1]

    def run():
        cards, copies, labelled = set(), 0, []
        n_items = len(ids)
        with v.action(f"Changed {n_items} item{'s' if n_items != 1 else ''}") as a:
            try:
                for cid in ids:
                    for lot in v.lots_for(cid):
                        new = _changes(lot, f)
                        if new:
                            v.update_lot(lot["id"], **new)
                            cards.add(cid)
                            copies += 1
                if "label" in f:
                    labelled = [c for c in ids if c in wish and (old_labels.get(c) or "") != f["label"]]
                    for c in labelled:
                        v._remember({"t": "wlabel", "card": c, "prev": old_labels.get(c) or "", "game": v.game})
                    cards.update(labelled)
                    if labelled:
                        wishlabels.assign(svc, v.game, labelled, f["label"])
            except Exception:
                v.conn.rollback()                                                   # all or nothing
                a.ops.clear()
                raise
            if cards:
                a.label = f"Changed {len(cards)} item{'s' if len(cards) != 1 else ''}"
        if labelled:
            svc._prof_at = 0                                                        # friends see the new labels with my next profile refresh
            svc._best_at = 0
        return {"items": len(cards), "copies": copies, "labelled": len(labelled)}
    return with_undo(svc, run)


def undo_labels(svc, action_id):
    """Before an action is undone: put back the wishlist labels it changed, and the settings / cloud rows other actions changed (undoext.py); the rest is undone by the database."""
    from .undoext import restore_before_undo
    restore_before_undo(svc, action_id)
    v = svc.vault
    r = v.conn.execute("SELECT ops, undone FROM u.actions WHERE id=? AND user_id=? AND game=?", (action_id, v.user_id, v.game)).fetchone()
    if not r or r["undone"]:
        return
    ops = [o for o in json.loads(r["ops"]) if o.get("t") == "wlabel"]
    by = {}
    for o in ops:
        by.setdefault(o.get("prev") or "", []).append(o["card"])
    for prev, cards in by.items():
        try:
            wishlabels.assign(svc, v.game, cards, prev)
        except LookupError:
            wishlabels.assign(svc, v.game, cards, "")                               # that label was deleted since: the cards just have none
    if by:
        svc._prof_at = 0
        svc._best_at = 0


@api("lots.bulkOptions", quiet=True)
def lots_bulk_options(svc):
    """What the "Edit selected" panel offers beyond the card options: the wishlist labels (priority order)."""
    return {"labels": wishlabels.load(svc)["labels"]}
