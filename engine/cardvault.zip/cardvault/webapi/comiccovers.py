"""Comics, for the item panel: the other covers / editions of the SAME issue (same series, same issue number) and the key-issue note.  Read from the list itself; no other list has either."""
import json

from .. import comicskeys


def key_note(raw):
    """What the source states that makes the issue a key issue ('' for an ordinary issue or another list): the item's raw `ext` 'Key issue' fact."""
    return str((raw.get("ext") or {}).get("Key issue") or "")


def covers_of(conn, card_id, set_id, number, img):
    """[{id, name, cover, img, here}] of every cover / edition of the issue the item is one of, in list order; [] when it is the only one.  `img(id, set_id)` gives a picture address."""
    if not number:
        return []
    rows = conn.execute("SELECT id, name, raw FROM cards WHERE set_id=? AND local_id=? ORDER BY sort_key", (set_id, number)).fetchall()
    if len(rows) < 2:
        return []
    out = []
    for r in rows:
        try:
            cover = str((json.loads(r["raw"] or "{}").get("ext") or {}).get("Cover") or "")
        except ValueError:
            cover = ""
        out.append({"id": r["id"], "name": r["name"], "cover": cover, "img": img(r["id"], set_id), "here": r["id"] == card_id})
    return out


def is_key_row(light):
    """True for a row of the list whose item is a key issue (the `rarity` column says so; only the Comics list writes it)."""
    return light.get("rarity") == comicskeys.KEY
