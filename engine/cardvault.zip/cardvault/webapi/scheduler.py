"""Quiet housekeeping while the app is open: safety backups, automatic price updates, update checks, and sending changes to your other devices."""
import datetime
import threading
import time

from ..runtime import INLINE
from . import cloudapi, gamesapi, scannerlearn, trendapi


class Scheduler:
    def __init__(self, svc):
        self.svc = svc
        self.stop = threading.Event()
        self.t0 = time.time()
        self.sync_mark = 0.0           # last_change value already sent
        self.backup_mark = 0.0
        self.persist_mark = 0.0
        self.next = {"periodic": 600, "prices": 1200, "poll": 300, "cloud": 15, "update": 6 * 3600, "catalogs": 60, "learn": 120}
        self.started = False
        self.pending_go = None
        self.thread = threading.Thread(target=self.loop, name="cardvault-scheduler", daemon=True)

    def start(self):
        if INLINE:                      # the browser build has no threads: its host calls tick()
            if self.svc.unlocked:
                self.after_unlock()
            else:
                self.svc.on_unlock.append(self.after_unlock)
        else:
            self.thread.start()
        return self

    def safe(self, fn):
        try:
            return self.svc.run(fn)
        except Exception:  # noqa: BLE001 - housekeeping must never break the app
            return None

    # ---- at start-up (like the classic window did)
    def startup(self):
        svc = self.svc

        def first(s):
            v = s.vault
            v.auto_backup_if_needed(60, s.pget("backup_dir"))
            if v.card_count() and not any(x["day"] == datetime.date.today().isoformat() for x in v.snapshots()):
                v.record_price_history()
                v.take_snapshot()
            from .gamesapi import art_start, start_prices
            art_start(s)
            start_prices(s, manual=False)
        self.safe(first)
        self.started = True

    def background_checks(self):
        svc = self.svc
        if svc.cfg.get("auto_updates", True):
            self.safe(lambda s: cloudapi.check_updates(s, False))
        self.safe(lambda s: cloudapi.start_sync(s, False))
        if svc.cfg.get("auto_updates", True):
            from . import scanner
            self.safe(lambda s: scanner.check_update(s))             # the scanner add-on is updated from the Card Scanner project's releases

    # ---- steady state
    def after_unlock(self):
        """Run the start-up chores once the account is open (in their own thread so signing in stays instant)."""
        def go():
            time.sleep(0 if INLINE else 0.4)
            self.startup()
            time.sleep(0 if INLINE else 3.0)
            self.background_checks()
        if INLINE:
            self.pending_go = go
        else:
            threading.Thread(target=go, name="cardvault-startup", daemon=True).start()

    def loop(self):
        if self.svc.unlocked:
            self.after_unlock()
        else:
            self.svc.on_unlock.append(self.after_unlock)
        while not self.stop.wait(2.0):
            self.tick()

    def tick(self):
        """One round of housekeeping (the browser build calls this every couple of seconds instead of running a thread)."""
        if True:
            now, svc = time.time(), self.svc
            if not svc.unlocked:
                return
            if self.pending_go:                  # inline mode: the start-up chores run on the first tick after sign-in
                go, self.pending_go = self.pending_go, None
                go()
            # auto-lock after a quiet spell (0 = never)
            mins = svc.pget("autolock_minutes", 15) if svc.session is not None else 0
            if svc.session is not None and mins and now - svc.last_activity > mins * 60 and not svc.jobs.running():
                self.safe(lambda s: s.lock("inactive"))
                return
            if now - getattr(self, "_prefs_mark", 0) >= 5:          # a choice changed on this device (currency, budget...): save it to the account record
                self._prefs_mark = now
                from .settings import prefs_touch
                self.safe(lambda s: prefs_touch(s))
            last = svc.last_change
            # a few seconds after a change: write it to disk, encrypted
            if svc.session is not None and last > self.persist_mark and now - last >= 3:
                self.persist_mark = last
                try:
                    svc.session.persist()
                except Exception:  # noqa: BLE001
                    pass
            # a few seconds after a change: send it to your other devices
            if last > self.sync_mark and now - last >= 4:
                self.sync_mark = last
                self.safe(lambda s: cloudapi.start_sync(s, False, publish=False))
            # a safety copy shortly after you stop making changes
            if last > self.backup_mark and now - last >= 15:
                self.backup_mark = last
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            elapsed = now - self.t0
            if elapsed >= self.next["periodic"]:
                self.next["periodic"] += 600
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            if elapsed >= self.next["prices"]:
                self.next["prices"] += 1200
                self.safe(lambda s: gamesapi.start_prices(s, manual=False))
            if getattr(svc, "_more_catalogs", False):
                svc._more_catalogs = False
                self.next["catalogs"] = min(self.next["catalogs"], elapsed)
            if elapsed >= self.next["catalogs"]:                  # a newer card list on the website (pictures, corrections): twice a day
                self.next["catalogs"] = elapsed + (5 if svc.jobs.running("games") else 12 * 3600)          # busy with another download: look again in a moment
                self.safe(lambda s: gamesapi.refresh_catalogs(s))
                self.safe(lambda s: trendapi.refresh(s))
            if elapsed >= self.next["learn"]:                    # only does anything when 'Help the scanner learn' is on
                self.next["learn"] = elapsed + 300
                self.safe(lambda s: scannerlearn.upload_batch(s))
            if elapsed >= self.next["update"]:
                self.next["update"] += 6 * 3600
                if svc.cfg.get("auto_updates", True):
                    self.safe(lambda s: cloudapi.check_updates(s, False))
                    from . import scanner
                    self.safe(lambda s: scanner.check_update(s))
            if elapsed >= self.next["cloud"]:                    # live sync: a change made on another device arrives within seconds
                self.next["cloud"] = elapsed + 15
                if svc.session is not None and svc.pget("cloud_token"):
                    from . import accountapi
                    self.safe(lambda s: accountapi.watch(s)["changed"] and cloudapi.start_sync(s, False, publish=False))
            if elapsed >= self.next["poll"]:
                self.next["poll"] += 300
                self.safe(lambda s: cloudapi.start_sync(s, False, publish=False))

    def shutdown(self):
        """On exit: flush unsynced changes, take the exit backup."""
        self.stop.set()

        def last(s):
            if s.vault is None:
                return
            try:
                cloudapi.flush_sync(s)
            finally:
                try:
                    s.vault.backup_now("exit", s.pget("backup_dir")) if s.vault._changes_since_backup else None
                finally:
                    s.lock("closed") if s.session is not None else s.vault.close()
        try:
            self.svc.run(last, timeout=30)
        except Exception:  # noqa: BLE001
            pass
