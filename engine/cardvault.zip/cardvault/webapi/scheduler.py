"""Quiet housekeeping while the app is open: safety backups, automatic price updates, update checks, and sending changes to your other devices."""
import datetime
import threading
import time

from .. import findfast
from ..runtime import INLINE
from . import cloudapi, dailyapi, gamesapi, graphwarm, perf, scannerlearn, trendapi, weeklyapi


class Scheduler:
    def __init__(self, svc):
        self.svc = svc
        self.stop = threading.Event()
        self.t0 = time.time()
        self.sync_mark = 0.0           # last_change value already sent
        self.backup_mark = 0.0
        self.persist_mark = 0.0
        self.next = {"periodic": 600, "prices": 1200, "poll": 300, "cloud": 2, "update": 6 * 3600, "catalogs": 240 if INLINE else 60, "learn": 120}          # the website waits a few minutes before any background download, so opening it is never slowed down
        self.started = False
        self.pending_go = None
        self.due = {}                  # browser build: chores waiting for a quiet moment, key -> (fn, since, patience)
        self.stepping = set()          # browser build: step-by-step chores under way (see steps)
        self.thread = threading.Thread(target=self.loop, name="cardvault-scheduler", daemon=True)

    def start(self):
        if INLINE:                      # the browser build has no threads: its host calls tick()
            if self.svc.unlocked:
                self.after_unlock()
            else:
                self.svc.on_unlock.append(self.after_unlock)
        else:
            self.thread.start()
            threading.Thread(target=self._watch_loop, name="cardvault-watch", daemon=True).start()
        return self

    def _watch_loop(self):
        """LIVE SYNC for the desktop app: hold a question open on the account server ("answer when the account is no longer <fp>", up to 25 s - see /v1/wait) so a change made on another device
        reaches this one within about half a second, whether the app is being used or has been left alone for hours.  The old way (looking every 2-20 seconds, see tick) stays as a slow safety net; if the
        server does not answer the question at all, that is all there is."""
        known = None
        misses = 0
        while not self.stop.is_set():
            svc = self.svc
            try:
                from . import accountapi
                a = self.safe(lambda s: accountapi.account(s) if (s.session is not None and s.pget("cloud_token") and s.pget("sync_enabled", True)) else None)
            except Exception:  # noqa: BLE001
                a = None
            if not a:
                known = None
                self.stop.wait(4)
                continue
            if known is None:
                known = svc.cfg.get("_cloud_fp") or ""
            try:
                r = a.wait(known, 25)
                misses = 0
            except Exception as e:  # noqa: BLE001 - offline, or a server that does not know the question: wait a little, and give up for a while if it keeps failing
                misses += 1
                self.stop.wait(min(60, 3 * misses))
                continue
            fp = (r or {}).get("fp") or ""
            if r and r.get("changed") and fp:
                known = fp
                for _ in range(150):                                               # fetch what the other device saved.  If a sync is running right now it cannot start another, so ask again until it has
                    res = self.safe(lambda s: cloudapi.sync_check(s, fp=fp))      # (we have already moved on to this fingerprint: giving up here would leave the change unseen until the 30 s safety net)
                    if res is None or res.get("started") or res.get("upToDate") or self.stop.wait(0.4):
                        break
                self.stop.wait(0.15)

    def safe(self, fn):
        try:
            return self.svc.run(fn)
        except Exception:  # noqa: BLE001 - housekeeping must never break the app
            return None

    def later(self, key, fn, patience=60, quiet=2.0):
        """Run a chore.  On the desktop it runs now (in its own thread).  In the browser the engine has no threads - a chore would hold up every screen while it runs - so it waits
        for a quiet moment (no click or key for `quiet` seconds; the heavy ones, like the day's price update, wait for a longer pause), at most `patience` seconds, and only
        one chore runs per tick."""
        if not INLINE:
            return self.safe(fn)
        self.due.setdefault(key, (fn, time.time(), patience, quiet))
        return None

    def chore(self, key, fn, patience=60, quiet=2.0):
        """A chore that goes through the games one at a time in the browser: fn(svc) does one and says True while there may be more, then it is queued again for the next quiet moment.
        (On the desktop it simply does them all, in its own thread.)"""
        def one(s):
            if fn(s):
                self.later(key, one, patience, quiet)
        return self.later(key, one, patience, quiet)

    def steps(self, key, make, patience=60, quiet=2.0, between=1.0, budget=0.0):
        """A long chore done in short steps in the browser: make(svc) gives a generator that yields after each step (a fraction of a second).  The first step waits for a quiet moment
        (`quiet` seconds without a click), each next one for a short pause (`between`), so a click is never held up by more than one step.  Only one run of a key at a time.
        `budget`: keep taking steps in the same quiet moment until this many seconds have gone (for a chore of many tiny steps).
        (On the desktop every step runs at once, from its own thread - one step per turn of the engine, so a click is answered between two steps there too.)"""
        if not INLINE:
            gen = []

            def step(s):
                if not gen:
                    gen.append(make(s))
                try:
                    next(gen[0])
                    return True
                except StopIteration:
                    return False
            while self.safe(step):
                pass
            return None
        if key in self.stepping:
            return None
        state = {}

        def one(s):
            try:
                gen = state.get("gen") or state.setdefault("gen", make(s))
                t0 = time.perf_counter()
                next(gen)
                while time.perf_counter() - t0 < budget:
                    next(gen)
            except StopIteration:                                  # finished
                self.stepping.discard(key)
                return
            except BaseException:                                  # failed: the next run starts afresh
                self.stepping.discard(key)
                raise
            self.later(key, one, patience, between)
        self.stepping.add(key)
        return self.later(key, one, patience, quiet)

    def run_due(self, now):
        """One chore that is due, if any.  -> whether one ran."""
        if not self.due:
            return False
        idle = now - self.svc.last_activity
        wanted = now - getattr(self.svc, "_index_wanted", 0) < 10          # a screen is waiting for the card index ("warming"): its steps need no quiet moment
        ready = [key for key, (fn, since, patience, quiet) in self.due.items() if idle >= quiet or now - since >= patience or (wanted and key == "warm")]
        if not ready:
            return False
        late = [key for key in ready if now - self.due[key][1] >= self.due[key][2]]
        key = late[0] if late else ("warm" if "warm" in ready else ready[0])          # (a chore kept waiting too long first; then the card index, which makes the next click quick)
        fn = self.due.pop(key)[0]
        self._settle(key == "findwarm")                           # (only the warm-up itself reads the sort order it asked for one step earlier)
        with perf.timed("chore", key):
            self.safe(fn)                                         # one per tick: the screens get the engine back right away
        self._settle(True)
        return True

    def _settle(self, keep_order):
        """Before and after each background step in the browser: nothing is left open on the collection's connection across a pause (see Vault.settle)."""
        v = self.svc.vault
        if v is not None:
            try:
                v.settle(drop_order=not keep_order)
            except Exception:  # noqa: BLE001 - housekeeping never breaks the app
                pass

    # ---- at start-up (like the classic window did)
    def startup(self):
        svc = self.svc

        def first(s):
            v = s.vault
            v.auto_backup_if_needed(60, s.pget("backup_dir"))
            if v.card_count() and not any(x["day"] == datetime.date.today().isoformat() for x in v.snapshots()):
                v.record_price_history()
                v.take_snapshot()
            from .gamesapi import art_start, start_prices
            art_start(s)
            start_prices(s, manual=False)
        self.safe(first)
        self.started = True

    def background_checks(self):
        svc = self.svc
        if svc.cfg.get("auto_updates", True):
            self.later("update", lambda s: cloudapi.check_updates(s, False))
        self.warm()
        from .settings import refresh_fx
        self.later("fx", lambda s: refresh_fx(s))                         # today's exchange rates (at most one download a day; the last good ones stay when offline)
        if not getattr(svc, "_sync_verified", False) and not svc.jobs.running("sync"):
            self.later("sync0", self._first_sync, patience=8)          # (the one started at sign-in did not run: no account then, or it failed)
        if svc.cfg.get("auto_updates", True):
            from . import scanner
            self.later("scanner", lambda s: scanner.check_update(s))             # the scanner add-on is updated from the Card Scanner project's releases

    @staticmethod
    def _first_sync(s):
        """The first sync of the session.  It used to wait for the start-up chores, the update check, the whole card index and the exchange rates (seconds; longer for Magic) before starting."""
        if s.session is not None and not s.jobs.running("sync"):
            cloudapi.start_sync(s, False)

    def warm(self):
        """Work out the open game's card index (cards' groups, illustrators ...) ahead of need, so the first card you click opens at once.  In the browser it goes a few short steps per quiet moment
        (the 105,000 Magic cards took seconds in one go, and nothing could be clicked meanwhile); if the game is changed half-way, the new game's is started instead."""
        def make(s):
            v = s.vault
            if v is None:
                return
            for _ in v.index_steps():
                if s.vault is not v:
                    return
                yield
            s._index_wanted = 0                          # (ready: nobody is waiting for it any more)
            if INLINE:
                self.find_warm()
        self.steps("warm", make, patience=20, quiet=0.5, between=0, budget=0.25)
        if not INLINE:
            self.find_warm()

    def find_warm(self):
        """After the card index: Find & Add's slim copy and every sort order (cardvault/findfast.py), so the first search / filter / sort of the session answers at once.
        Its own run, one step per quiet moment (a sort order is one step of ~0.3 s for Magic: never two in a row)."""
        def make(s):
            v = s.vault
            for _ in (findfast.warm_steps(v) if v is not None else ()):
                if s.vault is not v:
                    return
                yield
            from . import searchindex
            for _ in searchindex.warm_steps(s):                 # (then the all-games search index's accent list)
                yield
        self.steps("findwarm", make, patience=30, quiet=0.5, between=0)

    # ---- steady state
    def after_unlock(self):
        """Run the start-up chores once the account is open (in their own thread so signing in stays instant)."""
        def go():
            if not INLINE:
                self.safe(self._first_sync)              # the account's changes start coming down at once (it is a job: the screens never wait for it)
            time.sleep(0 if INLINE else 0.4)
            self.startup()
            time.sleep(0 if INLINE else 3.0)
            self.background_checks()
        if INLINE:
            self.pending_go = go
            self.unlocked_at = time.time()
            self.later("sync0", self._first_sync, patience=0)          # first in line at the next tick: the sync goes in short pieces, so the first screen is not held up by it
            self.warm()                                  # the card index straight away (a short step per free moment), not after the start-up chores
        else:
            threading.Thread(target=go, name="cardvault-startup", daemon=True).start()

    def loop(self):
        if self.svc.unlocked:
            self.after_unlock()
        else:
            self.svc.on_unlock.append(self.after_unlock)
        while True:
            waiting = self.svc.last_change > getattr(self.svc, "_synced_upto", 0)       # a change is waiting to be sent: look again very soon, so it goes out as soon as it has been left alone a moment
            if self.stop.wait(0.2 if waiting else 1.0):
                break
            self.tick()
            svc = self.svc
            busy = lambda: not svc.q.empty()            # (a question waiting in the engine's queue)
            while not self.stop.is_set() and graphwarm.pending(svc) and graphwarm.quiet(svc) and not busy() and self.safe(lambda s: graphwarm.step(s, busy=busy)):
                pass                                     # (short steps only while nobody is asking: a question that comes in goes before the next piece)

    def _sync_quiet(self, svc, now):
        """How long the collection must have been left alone before a change is sent (owner, 2026-11-12: "instant on their end, the app queues each change to be sent and then pushes it every 10 seconds").
        The screens never wait for sending: a change is on this device at once, and goes to the account in batches - a moment after the clicking stops, and at the latest BATCH seconds after the
        first unsent change while the changes keep coming (one sync per burst, not one per click).  In the browser the pause also grows with how long the last sync kept the engine busy."""
        first = getattr(svc, "_unsent_since", 0.0)
        if first and now - first >= self.BATCH:
            return 0.0
        if not INLINE:
            return 1.0
        return max(1.0, min(self.BATCH, getattr(svc, "_sync_cost", 0.0) * 5))

    BATCH = 10.0

    def tick(self):
        """One round of housekeeping (the browser build calls this every couple of seconds instead of running a thread)."""
        if True:
            now, svc = time.time(), self.svc
            if not svc.unlocked:
                return
            if self.pending_go and now - getattr(self, "unlocked_at", 0) >= 1.5:     # inline mode: the start-up chores are queued a moment after sign-in (each runs at a quiet moment)
                go, self.pending_go = self.pending_go, None
                go()
            # auto-lock after a quiet spell (0 = never)
            mins = svc.pget("autolock_minutes", 15) if svc.session is not None else 0
            if svc.session is not None and mins and now - svc.last_activity > mins * 60 and not svc.jobs.running():
                self.safe(lambda s: s.lock("inactive"))
                return
            v = svc.vault
            if v is not None and getattr(v, "_index", None) is not None and "findwarm" not in self.stepping and now - getattr(self, "_find_mark", 0) >= 30 and not findfast.ready(v):
                self._find_mark = now                                  # the card list changed (the day's prices): Find & Add's slim copy and sort orders are made again, in the background
                if INLINE:
                    self.find_warm()
                else:
                    threading.Thread(target=self.find_warm, name="cardvault-findwarm", daemon=True).start()
            if now - getattr(self, "_prefs_mark", 0) >= 5:          # a choice changed on this device (currency, budget...): save it to the account record
                self._prefs_mark = now
                from .settings import prefs_touch
                self.safe(lambda s: prefs_touch(s))
            last = svc.last_change
            # a few seconds after a change: write it to disk, encrypted
            if svc.session is not None and last > self.persist_mark and now - last >= 3:
                self.persist_mark = last                               # (the browser's page writes it itself a moment after each change - inline.persist moves this mark - so it is not encrypted twice)
                try:
                    svc.session.persist()
                except Exception:  # noqa: BLE001
                    pass
            # a moment after a change (1 second, so typing a note or tapping + a few times goes as one): send it to your other devices.  If a sync is already running the change
            # simply waits for the next tick - it is only marked as sent when a sync really started (it used to be marked sent anyway and then never went out)
            if last > getattr(svc, "_synced_upto", 0) and now - last >= self._sync_quiet(svc, now) and now >= getattr(svc, "_sync_backoff", 0) and not svc.jobs.running("sync"):
                job = self.safe(lambda s: cloudapi.start_sync(s, False, publish=False))
                if job is None:                                        # sync is off, or not signed in: look again in a few seconds (it goes out as soon as it can)
                    svc._sync_backoff = now + 10
            # a safety copy shortly after you stop making changes
            if last > self.backup_mark and now - last >= 15:
                self.backup_mark = last
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            # the value graphs kept last: worked out again in the background once the collection or its prices changed (after start-up, a change, a new day), so the graph is ready when asked
            if v is not None and getattr(v, "_index", None) is not None and now - getattr(self, "_graph_mark", 0) >= 5 and now - svc.last_activity >= 2:
                self._graph_mark = now
                self.safe(graphwarm.recent)
            elapsed = now - self.t0
            if INLINE and (self.started or svc.guest or now - getattr(svc, "_index_wanted", 0) < 10) and getattr(svc.vault, "_index", 0) is None and "warm" not in self.stepping:
                self.warm()                              # another game was opened, a guest is looking around (no sign-in ran the start-up), or a screen is waiting and the last run stopped: get the card index ready
            if elapsed >= self.next["periodic"]:
                self.next["periodic"] += 600
                from .settings import refresh_fx
                self.later("fx", lambda s: refresh_fx(s))              # today's exchange rates, at most one download a day (a no-op once they are in)
                self.later("weekly", lambda s: weeklyapi.maybe_send(s))      # the optional weekly email: today's note for the account server (nothing at all unless the owner of the account switched it on)
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            if time.time() >= getattr(svc, "_daily_next", 0) and "daily" not in self.stepping:            # the once-a-day price update: after 20:03 UTC, every 5 minutes until it is there, then not again until tomorrow
                svc._daily_next = time.time() + 60
                hurry, svc._daily_hurry = getattr(svc, "_daily_hurry", False), False          # ('Check now' was pressed: start straight away)
                self.steps("daily", dailyapi.check_steps, patience=900, quiet=0 if hurry else 8)          # applying the day's prices takes seconds in the browser: in short steps, starting at a real pause
            if elapsed >= self.next["prices"]:
                self.next["prices"] += 1200
                self.later("prices", lambda s: gamesapi.start_prices(s, manual=False))
            if getattr(svc, "_more_catalogs", False):
                svc._more_catalogs = False
                self.next["catalogs"] = min(self.next["catalogs"], elapsed)
            if elapsed >= self.next["catalogs"]:                  # a newer card list on the website (pictures, corrections): twice a day
                self.next["catalogs"] = elapsed + (5 if gamesapi.list_in_use(svc) else 12 * 3600)          # busy with another download / the price update / art detection: look again in a moment
                self.later("catalogs", lambda s: gamesapi.refresh_catalogs(s), patience=1800, quiet=8)
                self.chore("trends", trendapi.refresh, patience=1800, quiet=8)
                self.later("corrections", lambda s: trendapi.refresh_corrections(s), patience=1800, quiet=8)
            if elapsed >= self.next.get("archive", 90):             # the permanent price archive on Card Data: fill in the days we did not capture ourselves (twice a day)
                self.next["archive"] = elapsed + 12 * 3600
                def _arch(s):
                    from .. import pricearchive
                    n = pricearchive.backfill(s)
                    if n:
                        s.bump("synced", pulled=0)
                self.later("archive", _arch, patience=1800, quiet=8)
            if elapsed >= self.next["learn"]:                    # only does anything when 'Help the scanner learn' is on
                self.next["learn"] = elapsed + 300
                self.later("learn", lambda s: scannerlearn.upload_batch(s))
            if elapsed >= self.next["update"]:
                self.next["update"] += 6 * 3600
                if svc.cfg.get("auto_updates", True):
                    self.safe(lambda s: cloudapi.check_updates(s, False))
                    from . import scanner
                    self.safe(lambda s: scanner.check_update(s))
            if elapsed >= self.next["cloud"]:                    # live sync: a change made on another device arrives within seconds
                idle = now - svc.last_activity
                # the app is open: look every 2 seconds while it is being used and every 4 seconds for the next half hour (a change made on your phone should show up on a computer you are
                # only LOOKING at), then every 20.  The browser build: the PAGE asks the account server (see ui/src/livepoll.js) so the engine is never held up by the question.
                self.next["cloud"] = elapsed + (45 if INLINE else 30)                      # (the desktop hears about changes through _watch_loop; this is only the safety net)
                if now < getattr(svc, "_sync_backoff", 0):
                    pass                                              # the last attempt failed: wait a little before trying again
                elif svc.session is not None and svc.pget("cloud_token"):
                    if INLINE:                                        # the browser: a sync asks the account itself (its questions are sent by the page, never holding the engine) and skips games nothing changed in
                        self.later("pull", lambda s: None if s.jobs.running("sync") else (cloudapi.start_sync(s, False, publish=False) or setattr(s, "_sync_backoff", time.time() + 10)), patience=30)
                    else:
                        from . import accountapi
                        try:
                            w = accountapi.watch(svc)                 # (asked from this thread - the engine's own thread keeps answering clicks while the server answers)
                        except Exception:  # noqa: BLE001
                            w = {"changed": False}
                        if w["changed"]:
                            def pull(s):
                                if not s.jobs.running("sync"):
                                    s._fp_seen = w.get("fp")                # the sync knows the account moved on (so it checks copy photos too)
                                    j = cloudapi.start_sync(s, False, publish=False)
                                    if j is None:
                                        s._sync_backoff = time.time() + 10
                            self.safe(pull)
            if not getattr(svc, "_kp_done", False) and now >= getattr(svc, "_kp_next", 0) and svc.pget("cloud_token") and svc.pget("cloud_username"):
                svc._kp_next = now + 300
                from . import sharing
                self.later("keypair", lambda s: sharing.ensure_ready(s), patience=20, quiet=2)          # sharing is switched on for every account, so anybody can be found by username
            if elapsed >= self.next["poll"]:
                self.next["poll"] += 300
                self.later("poll", lambda s: cloudapi.start_sync(s, False, publish=False))
            return self.work(now)

    def work(self, now=None):
        """The next short piece of background work when the engine is free: a piece of a job that goes in pieces (a sync: download, merge, upload), or else one chore.
        -> how soon (seconds) the browser's host should call again: soon while the card index is being worked out or a job is part-way (back to back while nobody is
        clicking: in the once-a-second tick it took 18 s for Magic), else None (the next tick)."""
        now, svc = now or time.time(), self.svc
        if not svc.unlocked:
            return None
        if INLINE and now - getattr(svc, "last_call", 0) < 0.15 and now - getattr(svc, "_index_wanted", 0) >= 10:
            return 0.1                                                     # a screen is asking things this very moment: let it finish first (unless a screen is waiting for this work)
        graph = graphwarm.pending(svc) and not self.stepping & {"warm", "findwarm"} and graphwarm.quiet(svc, now)          # (the card index and Find & Add's warm-up go first; never while asking)
        if not (now - svc.last_activity >= 0.4 and svc.jobs.step()) and not self.run_due(now) and graph:
            self._settle(True)
            with perf.timed("chore", "graph"):
                self.safe(graphwarm.step)                                  # a short step of the value graph's background work (graphwarm.STEP)
            self._settle(True)
        if graph or self.stepping & {"warm", "findwarm"} or any(j.pieces is not None and svc.jobs.ready(j) for j in svc.jobs.running()):
            return 0.03                                                    # (a job waiting for a request the page is sending is not part-way: the page calls again when the answer is in)
        if graphwarm.pending(svc) and now - getattr(svc, "_graph_wanted", 0) < graphwarm.WANTED:
            return 0.1                                                     # (a screen waits for its graph: look again after the gap, not at the next tick)
        return None

    def shutdown(self):
        """On exit: flush unsynced changes, take the exit backup."""
        self.stop.set()

        def last(s):
            if s.vault is None:
                return
            try:
                cloudapi.flush_sync(s)
            finally:
                try:
                    s.vault.backup_now("exit", s.pget("backup_dir")) if s.vault._changes_since_backup else None
                finally:
                    s.lock("closed") if s.session is not None else s.vault.close()
        try:
            self.svc.run(last, timeout=30)
        except Exception:  # noqa: BLE001
            pass
