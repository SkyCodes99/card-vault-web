"""Quiet housekeeping while the app is open: safety backups, automatic price updates, update checks, and sending changes to your other devices."""
import datetime
import threading
import time

from ..runtime import INLINE
from . import cloudapi, dailyapi, gamesapi, perf, scannerlearn, trendapi


class Scheduler:
    def __init__(self, svc):
        self.svc = svc
        self.stop = threading.Event()
        self.t0 = time.time()
        self.sync_mark = 0.0           # last_change value already sent
        self.backup_mark = 0.0
        self.persist_mark = 0.0
        self.next = {"periodic": 600, "prices": 1200, "poll": 300, "cloud": 2, "update": 6 * 3600, "catalogs": 240 if INLINE else 60, "learn": 120}          # the website waits a few minutes before any background download, so opening it is never slowed down
        self.started = False
        self.pending_go = None
        self.due = {}                  # browser build: chores waiting for a quiet moment, key -> (fn, since, patience)
        self.thread = threading.Thread(target=self.loop, name="cardvault-scheduler", daemon=True)

    def start(self):
        if INLINE:                      # the browser build has no threads: its host calls tick()
            if self.svc.unlocked:
                self.after_unlock()
            else:
                self.svc.on_unlock.append(self.after_unlock)
        else:
            self.thread.start()
            threading.Thread(target=self._watch_loop, name="cardvault-watch", daemon=True).start()
        return self

    def _watch_loop(self):
        """LIVE SYNC for the desktop app: hold a question open on the account server ("answer when the account is no longer <fp>", up to 25 s - see /v1/wait) so a change made on another device
        reaches this one within about half a second, whether the app is being used or has been left alone for hours.  The old way (looking every 2-20 seconds, see tick) stays as a slow safety net; if the
        server does not answer the question at all, that is all there is."""
        known = None
        misses = 0
        while not self.stop.is_set():
            svc = self.svc
            try:
                from . import accountapi
                a = self.safe(lambda s: accountapi.account(s) if (s.session is not None and s.pget("cloud_token") and s.pget("sync_enabled", True)) else None)
            except Exception:  # noqa: BLE001
                a = None
            if not a:
                known = None
                self.stop.wait(4)
                continue
            if known is None:
                known = svc.cfg.get("_cloud_fp") or ""
            try:
                r = a.wait(known, 25)
                misses = 0
            except Exception as e:  # noqa: BLE001 - offline, or a server that does not know the question: wait a little, and give up for a while if it keeps failing
                misses += 1
                self.stop.wait(min(60, 3 * misses))
                continue
            fp = (r or {}).get("fp") or ""
            if r and r.get("changed") and fp:
                known = fp
                for _ in range(150):                                               # fetch what the other device saved.  If a sync is running right now it cannot start another, so ask again until it has
                    res = self.safe(lambda s: cloudapi.sync_check(s, fp=fp))      # (we have already moved on to this fingerprint: giving up here would leave the change unseen until the 30 s safety net)
                    if res is None or res.get("started") or res.get("upToDate") or self.stop.wait(0.4):
                        break
                self.stop.wait(0.15)

    def safe(self, fn):
        try:
            return self.svc.run(fn)
        except Exception:  # noqa: BLE001 - housekeeping must never break the app
            return None

    def later(self, key, fn, patience=60, quiet=2.0):
        """Run a chore.  On the desktop it runs now (in its own thread).  In the browser the engine has no threads - a chore would hold up every screen while it runs - so it waits
        for a quiet moment (no click or key for `quiet` seconds; the heavy ones, like the day's price update, wait for a longer pause), at most `patience` seconds, and only
        one chore runs per tick."""
        if not INLINE:
            return self.safe(fn)
        self.due.setdefault(key, (fn, time.time(), patience, quiet))
        return None

    def chore(self, key, fn, patience=60, quiet=2.0):
        """A chore that goes through the games one at a time in the browser: fn(svc) does one and says True while there may be more, then it is queued again for the next quiet moment.
        (On the desktop it simply does them all, in its own thread.)"""
        def one(s):
            if fn(s):
                self.later(key, one, patience, quiet)
        return self.later(key, one, patience, quiet)

    def run_due(self, now):
        if not self.due:
            return
        idle = now - self.svc.last_activity
        for key, (fn, since, patience, quiet) in list(self.due.items()):
            if idle >= quiet or now - since >= patience:
                self.due.pop(key, None)
                with perf.timed("chore", key):
                    self.safe(fn)
                return                                            # one per tick: the screens get the engine back right away

    # ---- at start-up (like the classic window did)
    def startup(self):
        svc = self.svc

        def first(s):
            v = s.vault
            v.auto_backup_if_needed(60, s.pget("backup_dir"))
            if v.card_count() and not any(x["day"] == datetime.date.today().isoformat() for x in v.snapshots()):
                v.record_price_history()
                v.take_snapshot()
            from .gamesapi import art_start, start_prices
            art_start(s)
            start_prices(s, manual=False)
        self.safe(first)
        self.started = True

    def background_checks(self):
        svc = self.svc
        if svc.cfg.get("auto_updates", True):
            self.later("update", lambda s: cloudapi.check_updates(s, False))
        self.later("warm", lambda s: s.vault.card_index() if getattr(s, "vault", None) is not None else None, patience=40, quiet=2.5)       # work out the card index (cards' groups, illustrators ...) in a quiet moment, so the first card you click opens at once
        self.later("sync0", lambda s: cloudapi.start_sync(s, False), patience=8)        # the first sync of the session soon, but not in the middle of the first screen loading
        if svc.cfg.get("auto_updates", True):
            from . import scanner
            self.later("scanner", lambda s: scanner.check_update(s))             # the scanner add-on is updated from the Card Scanner project's releases

    # ---- steady state
    def after_unlock(self):
        """Run the start-up chores once the account is open (in their own thread so signing in stays instant)."""
        def go():
            time.sleep(0 if INLINE else 0.4)
            self.startup()
            time.sleep(0 if INLINE else 3.0)
            self.background_checks()
        if INLINE:
            self.pending_go = go
            self.unlocked_at = time.time()
        else:
            threading.Thread(target=go, name="cardvault-startup", daemon=True).start()

    def loop(self):
        if self.svc.unlocked:
            self.after_unlock()
        else:
            self.svc.on_unlock.append(self.after_unlock)
        while True:
            waiting = self.svc.last_change > getattr(self.svc, "_synced_upto", 0)       # a change is waiting to be sent: look again very soon, so it goes out as soon as it has been left alone a moment
            if self.stop.wait(0.2 if waiting else 1.0):
                break
            self.tick()

    def _sync_quiet(self, svc, now):
        """How long the collection must have been left alone before a change is sent.  In the browser a sync freezes the whole engine while it runs, and a big collection takes seconds, so the pause grows
        with how long the last sync took (6x, up to 45 s): a burst of adds goes up as ONE sync, not one per click.  Never wait more than 2 minutes after the first unsent change."""
        if not INLINE:
            return 0.12
        quiet = max(0.8, min(30.0, getattr(svc, "_sync_cost", 0.0) * 5))
        first = getattr(svc, "_unsent_since", 0.0)
        if first and now - first > 120:
            return 0.0
        return quiet

    def tick(self):
        """One round of housekeeping (the browser build calls this every couple of seconds instead of running a thread)."""
        if True:
            now, svc = time.time(), self.svc
            if not svc.unlocked:
                return
            if self.pending_go and now - getattr(self, "unlocked_at", 0) >= 1.5:     # inline mode: the start-up chores are queued a moment after sign-in (each runs at a quiet moment)
                go, self.pending_go = self.pending_go, None
                go()
            # auto-lock after a quiet spell (0 = never)
            mins = svc.pget("autolock_minutes", 15) if svc.session is not None else 0
            if svc.session is not None and mins and now - svc.last_activity > mins * 60 and not svc.jobs.running():
                self.safe(lambda s: s.lock("inactive"))
                return
            if now - getattr(self, "_prefs_mark", 0) >= 5:          # a choice changed on this device (currency, budget...): save it to the account record
                self._prefs_mark = now
                from .settings import prefs_touch
                self.safe(lambda s: prefs_touch(s))
            last = svc.last_change
            # a few seconds after a change: write it to disk, encrypted
            if svc.session is not None and last > self.persist_mark and now - last >= 3:
                self.persist_mark = last
                try:
                    svc.session.persist()
                except Exception:  # noqa: BLE001
                    pass
            # a moment after a change (1 second, so typing a note or tapping + a few times goes as one): send it to your other devices.  If a sync is already running the change
            # simply waits for the next tick - it is only marked as sent when a sync really started (it used to be marked sent anyway and then never went out)
            if last > getattr(svc, "_synced_upto", 0) and now - last >= self._sync_quiet(svc, now) and now >= getattr(svc, "_sync_backoff", 0) and not svc.jobs.running("sync"):
                job = self.safe(lambda s: cloudapi.start_sync(s, False, publish=False))
                if job is None:                                        # sync is off, or not signed in: look again in a few seconds (it goes out as soon as it can)
                    svc._sync_backoff = now + 10
            # a safety copy shortly after you stop making changes
            if last > self.backup_mark and now - last >= 15:
                self.backup_mark = last
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            elapsed = now - self.t0
            if elapsed >= self.next["periodic"]:
                self.next["periodic"] += 600
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            if time.time() >= getattr(svc, "_daily_next", 0):            # the once-a-day price update: after 20:03 UTC, every 5 minutes until it is there, then not again until tomorrow
                svc._daily_next = time.time() + 60
                self.later("daily", lambda s: dailyapi.check(s), patience=900, quiet=8)          # applying the day's prices takes a few seconds in the browser: a real pause
            if elapsed >= self.next["prices"]:
                self.next["prices"] += 1200
                self.later("prices", lambda s: gamesapi.start_prices(s, manual=False))
            if getattr(svc, "_more_catalogs", False):
                svc._more_catalogs = False
                self.next["catalogs"] = min(self.next["catalogs"], elapsed)
            if elapsed >= self.next["catalogs"]:                  # a newer card list on the website (pictures, corrections): twice a day
                self.next["catalogs"] = elapsed + (5 if gamesapi.list_in_use(svc) else 12 * 3600)          # busy with another download / the price update / art detection: look again in a moment
                self.later("catalogs", lambda s: gamesapi.refresh_catalogs(s), patience=1800, quiet=8)
                self.chore("trends", trendapi.refresh, patience=1800, quiet=8)
                self.later("corrections", lambda s: trendapi.refresh_corrections(s), patience=1800, quiet=8)
            if elapsed >= self.next.get("archive", 90):             # the permanent price archive on Card Data: fill in the days we did not capture ourselves (twice a day)
                self.next["archive"] = elapsed + 12 * 3600
                def _arch(s):
                    from .. import pricearchive
                    n = pricearchive.backfill(s)
                    if n:
                        s.bump("synced", pulled=0)
                self.later("archive", _arch, patience=1800, quiet=8)
            if elapsed >= self.next["learn"]:                    # only does anything when 'Help the scanner learn' is on
                self.next["learn"] = elapsed + 300
                self.later("learn", lambda s: scannerlearn.upload_batch(s))
            if elapsed >= self.next["update"]:
                self.next["update"] += 6 * 3600
                if svc.cfg.get("auto_updates", True):
                    self.safe(lambda s: cloudapi.check_updates(s, False))
                    from . import scanner
                    self.safe(lambda s: scanner.check_update(s))
            if elapsed >= self.next["cloud"]:                    # live sync: a change made on another device arrives within seconds
                idle = now - svc.last_activity
                # the app is open: look every 2 seconds while it is being used and every 4 seconds for the next half hour (a change made on your phone should show up on a computer you are
                # only LOOKING at), then every 20.  The browser build: the PAGE asks the account server (see ui/src/livepoll.js) so the engine is never held up by the question.
                self.next["cloud"] = elapsed + (45 if INLINE else 30)                      # (the desktop hears about changes through _watch_loop; this is only the safety net)
                if now < getattr(svc, "_sync_backoff", 0):
                    pass                                              # the last attempt failed: wait a little before trying again
                elif svc.session is not None and svc.pget("cloud_token"):
                    from . import accountapi
                    def pull(s):
                        w = accountapi.watch(s)
                        if w["changed"] and not s.jobs.running("sync"):
                            s._fp_seen = w.get("fp")                        # the sync knows the account moved on (so it checks copy photos too)
                            j = cloudapi.start_sync(s, False, publish=False)
                            if j is None:
                                s._sync_backoff = time.time() + 10
                    self.safe(pull)
            if not getattr(svc, "_kp_done", False) and now >= getattr(svc, "_kp_next", 0) and svc.pget("cloud_token") and svc.pget("cloud_username"):
                svc._kp_next = now + 300
                from . import sharing
                self.later("keypair", lambda s: sharing.ensure_ready(s), patience=20, quiet=2)          # sharing is switched on for every account, so anybody can be found by username
            if elapsed >= self.next["poll"]:
                self.next["poll"] += 300
                self.later("poll", lambda s: cloudapi.start_sync(s, False, publish=False))
            self.run_due(now)

    def shutdown(self):
        """On exit: flush unsynced changes, take the exit backup."""
        self.stop.set()

        def last(s):
            if s.vault is None:
                return
            try:
                cloudapi.flush_sync(s)
            finally:
                try:
                    s.vault.backup_now("exit", s.pget("backup_dir")) if s.vault._changes_since_backup else None
                finally:
                    s.lock("closed") if s.session is not None else s.vault.close()
        try:
            self.svc.run(last, timeout=30)
        except Exception:  # noqa: BLE001
            pass
