"""Quiet housekeeping while the app is open: safety backups, automatic price updates, update checks, and sending changes to your other devices."""
import datetime
import threading
import time

from ..runtime import INLINE
from . import cloudapi, dailyapi, gamesapi, scannerlearn, trendapi


class Scheduler:
    def __init__(self, svc):
        self.svc = svc
        self.stop = threading.Event()
        self.t0 = time.time()
        self.sync_mark = 0.0           # last_change value already sent
        self.backup_mark = 0.0
        self.persist_mark = 0.0
        self.next = {"periodic": 600, "prices": 1200, "poll": 300, "cloud": 2, "update": 6 * 3600, "catalogs": 240 if INLINE else 60, "learn": 120}          # the website waits a few minutes before any background download, so opening it is never slowed down
        self.started = False
        self.pending_go = None
        self.due = {}                  # browser build: chores waiting for a quiet moment, key -> (fn, since, patience)
        self.thread = threading.Thread(target=self.loop, name="cardvault-scheduler", daemon=True)

    def start(self):
        if INLINE:                      # the browser build has no threads: its host calls tick()
            if self.svc.unlocked:
                self.after_unlock()
            else:
                self.svc.on_unlock.append(self.after_unlock)
        else:
            self.thread.start()
        return self

    def safe(self, fn):
        try:
            return self.svc.run(fn)
        except Exception:  # noqa: BLE001 - housekeeping must never break the app
            return None

    def later(self, key, fn, patience=60, quiet=2.0):
        """Run a chore.  On the desktop it runs now (in its own thread).  In the browser the engine has no threads - a chore would hold up every screen while it runs - so it waits
        for a quiet moment (no click or key for `quiet` seconds; the heavy ones, like the day's price update, wait for a longer pause), at most `patience` seconds, and only
        one chore runs per tick."""
        if not INLINE:
            return self.safe(fn)
        self.due.setdefault(key, (fn, time.time(), patience, quiet))
        return None

    def run_due(self, now):
        if not self.due:
            return
        idle = now - self.svc.last_activity
        for key, (fn, since, patience, quiet) in list(self.due.items()):
            if idle >= quiet or now - since >= patience:
                self.due.pop(key, None)
                self.safe(fn)
                return                                            # one per tick: the screens get the engine back right away

    # ---- at start-up (like the classic window did)
    def startup(self):
        svc = self.svc

        def first(s):
            v = s.vault
            v.auto_backup_if_needed(60, s.pget("backup_dir"))
            if v.card_count() and not any(x["day"] == datetime.date.today().isoformat() for x in v.snapshots()):
                v.record_price_history()
                v.take_snapshot()
            from .gamesapi import art_start, start_prices
            art_start(s)
            start_prices(s, manual=False)
        self.safe(first)
        self.started = True

    def background_checks(self):
        svc = self.svc
        if svc.cfg.get("auto_updates", True):
            self.later("update", lambda s: cloudapi.check_updates(s, False))
        self.later("sync0", lambda s: cloudapi.start_sync(s, False), patience=8)        # the first sync of the session soon, but not in the middle of the first screen loading
        if svc.cfg.get("auto_updates", True):
            from . import scanner
            self.later("scanner", lambda s: scanner.check_update(s))             # the scanner add-on is updated from the Card Scanner project's releases

    # ---- steady state
    def after_unlock(self):
        """Run the start-up chores once the account is open (in their own thread so signing in stays instant)."""
        def go():
            time.sleep(0 if INLINE else 0.4)
            self.startup()
            time.sleep(0 if INLINE else 3.0)
            self.background_checks()
        if INLINE:
            self.pending_go = go
            self.unlocked_at = time.time()
        else:
            threading.Thread(target=go, name="cardvault-startup", daemon=True).start()

    def loop(self):
        if self.svc.unlocked:
            self.after_unlock()
        else:
            self.svc.on_unlock.append(self.after_unlock)
        while not self.stop.wait(1.0):
            self.tick()

    def tick(self):
        """One round of housekeeping (the browser build calls this every couple of seconds instead of running a thread)."""
        if True:
            now, svc = time.time(), self.svc
            if not svc.unlocked:
                return
            if self.pending_go and now - getattr(self, "unlocked_at", 0) >= 1.5:     # inline mode: the start-up chores are queued a moment after sign-in (each runs at a quiet moment)
                go, self.pending_go = self.pending_go, None
                go()
            # auto-lock after a quiet spell (0 = never)
            mins = svc.pget("autolock_minutes", 15) if svc.session is not None else 0
            if svc.session is not None and mins and now - svc.last_activity > mins * 60 and not svc.jobs.running():
                self.safe(lambda s: s.lock("inactive"))
                return
            if now - getattr(self, "_prefs_mark", 0) >= 5:          # a choice changed on this device (currency, budget...): save it to the account record
                self._prefs_mark = now
                from .settings import prefs_touch
                self.safe(lambda s: prefs_touch(s))
            last = svc.last_change
            # a few seconds after a change: write it to disk, encrypted
            if svc.session is not None and last > self.persist_mark and now - last >= 3:
                self.persist_mark = last
                try:
                    svc.session.persist()
                except Exception:  # noqa: BLE001
                    pass
            # a moment after a change (1 second, so typing a note or tapping + a few times goes as one): send it to your other devices.  If a sync is already running the change
            # simply waits for the next tick - it is only marked as sent when a sync really started (it used to be marked sent anyway and then never went out)
            if last > getattr(svc, "_synced_upto", 0) and now - last >= (1.5 if INLINE else 0.6) and now >= getattr(svc, "_sync_backoff", 0) and not svc.jobs.running("sync"):
                job = self.safe(lambda s: cloudapi.start_sync(s, False, publish=False))
                if job is None:                                        # sync is off, or not signed in: look again in a few seconds (it goes out as soon as it can)
                    svc._sync_backoff = now + 10
            # a safety copy shortly after you stop making changes
            if last > self.backup_mark and now - last >= 15:
                self.backup_mark = last
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            elapsed = now - self.t0
            if elapsed >= self.next["periodic"]:
                self.next["periodic"] += 600
                self.safe(lambda s: s.vault.backup_now("auto", s.pget("backup_dir")) if s.vault._changes_since_backup else None)
            if time.time() >= getattr(svc, "_daily_next", 0):            # the once-a-day price update: after 20:03 UTC, every 5 minutes until it is there, then not again until tomorrow
                svc._daily_next = time.time() + 60
                self.later("daily", lambda s: dailyapi.check(s), patience=900, quiet=8)          # applying the day's prices takes a few seconds in the browser: a real pause
            if elapsed >= self.next["prices"]:
                self.next["prices"] += 1200
                self.later("prices", lambda s: gamesapi.start_prices(s, manual=False))
            if getattr(svc, "_more_catalogs", False):
                svc._more_catalogs = False
                self.next["catalogs"] = min(self.next["catalogs"], elapsed)
            if elapsed >= self.next["catalogs"]:                  # a newer card list on the website (pictures, corrections): twice a day
                self.next["catalogs"] = elapsed + (5 if svc.jobs.running("games") else 12 * 3600)          # busy with another download: look again in a moment
                self.later("catalogs", lambda s: gamesapi.refresh_catalogs(s), patience=1800, quiet=8)
                self.later("trends", lambda s: trendapi.refresh(s), patience=1800, quiet=8)
                self.later("corrections", lambda s: trendapi.refresh_corrections(s), patience=1800, quiet=8)
            if elapsed >= self.next.get("archive", 90):             # the permanent price archive on Card Data: fill in the days we did not capture ourselves (twice a day)
                self.next["archive"] = elapsed + 12 * 3600
                def _arch(s):
                    from .. import pricearchive
                    n = pricearchive.backfill(s)
                    if n:
                        s.bump("synced", pulled=0)
                self.later("archive", _arch, patience=1800, quiet=8)
            if elapsed >= self.next["learn"]:                    # only does anything when 'Help the scanner learn' is on
                self.next["learn"] = elapsed + 300
                self.later("learn", lambda s: scannerlearn.upload_batch(s))
            if elapsed >= self.next["update"]:
                self.next["update"] += 6 * 3600
                if svc.cfg.get("auto_updates", True):
                    self.safe(lambda s: cloudapi.check_updates(s, False))
                    from . import scanner
                    self.safe(lambda s: scanner.check_update(s))
            if elapsed >= self.next["cloud"]:                    # live sync: a change made on another device arrives within seconds
                active = now - svc.last_activity < 300               # the app is being used: look every 2 seconds; idle: every 20
                # the browser build: the PAGE asks the account server (see ui/src/livepoll.js) so the engine is never held up by the question; this is only a slow safety net there
                self.next["cloud"] = elapsed + (45 if INLINE else 2 if active else 20)
                if now < getattr(svc, "_sync_backoff", 0):
                    pass                                              # the last attempt failed: wait a little before trying again
                elif svc.session is not None and svc.pget("cloud_token"):
                    from . import accountapi
                    def pull(s):
                        w = accountapi.watch(s)
                        if w["changed"] and not s.jobs.running("sync"):
                            s._fp_seen = w.get("fp")                        # the sync knows the account moved on (so it checks copy photos too)
                            j = cloudapi.start_sync(s, False, publish=False)
                            if j is None:
                                s._sync_backoff = time.time() + 10
                    self.safe(pull)
            if elapsed >= self.next["poll"]:
                self.next["poll"] += 300
                self.later("poll", lambda s: cloudapi.start_sync(s, False, publish=False))
            self.run_due(now)

    def shutdown(self):
        """On exit: flush unsynced changes, take the exit backup."""
        self.stop.set()

        def last(s):
            if s.vault is None:
                return
            try:
                cloudapi.flush_sync(s)
            finally:
                try:
                    s.vault.backup_now("exit", s.pget("backup_dir")) if s.vault._changes_since_backup else None
                finally:
                    s.lock("closed") if s.session is not None else s.vault.close()
        try:
            self.svc.run(last, timeout=30)
        except Exception:  # noqa: BLE001
            pass
