"""'Check this app': what version the engine is really running and whether the art cards are being found - so a report like 'the art cards are missing' can be answered with numbers."""
from .. import art_promos, taxonomy
from ..version import CHANGELOG, VERSION
from .registry import api


@api("app.selfcheck", quiet=True)
def selfcheck(svc):
    v = svc.vault
    idx = v.card_index()
    by = {c["id"]: c for c in idx}
    art = [c for c in idx if "art" in c["groups"]]
    present = [i for i in sorted(art_promos.IDS) if i in by]
    flagged = [i for i in present if "art" in by[i]["groups"]]
    pocket = sum(1 for c in art if "art_pocket" in c["groups"])
    meta = {}
    try:
        meta = dict(v.conn.execute("SELECT key, value FROM meta WHERE key IN ('prices_updated','tcgsync_last')").fetchall())
    except Exception:  # noqa: BLE001
        pass
    sample = [{"id": i, "name": by[i]["name"], "set": by[i].get("set_name") or "", "art": "art" in by[i]["groups"], "ir": "ir" in by[i]["groups"], "alt": bool({"altart", "art_alt"} & by[i]["groups"])}
              for i in ("swshp-SWSH182", "svp-203", "svp-051", "mep-037", "svp-131", "mep-081") if i in by]
    return {"engine": VERSION, "rules": taxonomy.VERSION, "game": svc.game.id, "cards": len(idx), "art": len(art), "artPocket": pocket, "artPhysical": len(art) - pocket,
            "curated": {"total": len(art_promos.IDS), "inCatalog": len(present), "flagged": len(flagged), "missing": [i for i in sorted(art_promos.IDS) if i not in by][:12]},
            "sample": sample, "catalogUpdated": meta.get("prices_updated") or "", "lastSync": meta.get("tcgsync_last") or "",
            "latest": CHANGELOG[0][0]}
