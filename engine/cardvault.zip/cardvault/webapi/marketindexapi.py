"""Market indexes on screen (cardvault/marketindex.py; method: docs/market_indexes.md).  Both answers are read from the file kept on this device, never worked out here:
the whole stored line comes back (about 220 points), so the screen picks its time range without asking again.  A file still on its way answers pending=True."""
from .. import games, marketindex, marketmovers
from .registry import api


def _line(doc, scope, key):
    return [{"day": p["day"], "v": p["v"], "n": p["n"]} for p in marketindex.points(doc, scope, key)]


@api("market.index", quiet=True)
def market_index(svc, scope="set", key="", get=None):
    """The open game's lines for one set page (scope 'set', key = set id) or one era (scope 'era', key = era name): that line, its era's (for a set) and the whole game's.
    -> {"lines": [{"scope", "key", "label", "points"}], "built", "rules", "pending"}"""
    v = svc.vault
    doc, pending = marketindex.for_game(svc, v.game, get=get)
    want = [(scope, str(key or ""))] if scope in ("set", "era") and key else []
    if scope == "set" and key:
        r = v.conn.execute("SELECT serie FROM sets WHERE id=?", (str(key),)).fetchone()
        if r and r[0]:
            want.append(("era", r[0]))
    want.append(("game", ""))
    lines = []
    for sc, k in want:
        pts = _line(doc, sc, k)
        if pts:
            lines.append({"scope": sc, "key": k, "label": k if sc == "era" else "", "points": pts})
    return {"lines": lines, "built": (doc or {}).get("built", ""), "rules": marketindex.rules(), "pending": pending, "_later": pending}          # (_later: the screen asks again a second later)


@api("market.indexes", quiet=True)
def market_indexes(svc, get=None):
    """Overview: the whole-game line of every game the owner collects (sealed products aside).  -> {"games": [{"id", "name", "points"}], "rules", "pending"}"""
    names = {g.id: g.name for g in games.GAMES}
    out, pending = [], False
    for gid in marketmovers.owned_by_game(svc.vault, None):
        doc, wait = marketindex.for_game(svc, gid, get=get)
        pending = pending or wait
        pts = _line(doc, "game", "")
        if pts:
            out.append({"id": gid, "name": names.get(gid, gid), "points": pts})
    return {"games": out, "rules": marketindex.rules(), "pending": pending, "_later": pending}
