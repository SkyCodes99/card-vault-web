"""Dev Tools > Changes (owner only: every dev.* method is refused for other accounts by the engine): every change the checkers made to a list - the daily accuracy check, Mini you, and
the owner's own answers on the review list - read from the ONE fix log (cardvault/accuracy/fixlog.py), newest first, each with a Revert.

A revert goes through fixlog.undo(): the row is put back (only when it still is what the fix left, or already back as it was), and it is REMEMBERED - the checkers never make that change
again by themselves, the 'no' that led to it is forgotten, and a Mini you change taken back teaches Mini you at its next weekly retrain.
The fix log and the lists live on the PC that runs the daily update; the website and the phone have no access to them (they say so; nothing is uploaded).  Fixes and reverts change the
lists that are published nightly, so they go out with the next daily update."""
import os
import sqlite3

from .. import runtime
from ..accuracy import fixlog
from ..accuracy.result import REMOVE
from .registry import ApiError, api

DESKTOP_ONLY = "Open Dev Tools in the desktop app on the main PC to see and revert changes."
LIMIT = 300
# a list's column -> what the Changes tab calls it
FIELD = {"name": "name", "local_id": "number", "set_id": "set", "set_name": "set", "price_usd": "price", "price_kind": "priceKind", "image_base": "picture"}
_MAIN = ("set_id", "image_base", "price_usd", "name", "local_id")           # which column names the kind of a change, first match wins
BY = {fixlog.BY_CHECK: "check", fixlog.BY_MINIYOU: "miniyou", fixlog.BY_OWNER: "owner"}
_SHORT = 240                                                                # longest value shown of a removed record (its raw record can be long)


DATA_DIR = None                                                             # the lists' folder; None = the one the release tools use (a test names its own)


def _db(game):
    from ..db import game_dir
    from ..paths import release_data_dir
    return os.path.join(game_dir(DATA_DIR or release_data_dir(), game), "cards.db")


def _game_names():
    try:
        from .. import games
        return {g.id: g.name for g in games.GAMES}
    except Exception:  # noqa: BLE001
        return {}


def _pic(game, base):
    """A picture link the browser can load (a TCGdex base gets its size), or ''."""
    if not base:
        return ""
    url = base
    if game.startswith("pokemon"):
        from ..db import picture_url
        url = picture_url(base, "low")
    return url if str(url).startswith(("http://", "https://")) else ""


def kind_of(e):
    if e.get("action") == REMOVE:
        return "removed"
    cols = set(e.get("after") or {})
    return next((FIELD[c] for c in _MAIN if c in cols), "other")


def _by(e):
    return BY.get(e.get("by"), "check")


class _Lookup:
    """Per game, read once: set names and each item's current picture (read-only)."""

    def __init__(self):
        self.sets, self.pics = {}, {}

    def load(self, game, ids):
        if game in self.sets:
            return
        self.sets[game], self.pics[game] = {}, {}
        p = _db(game)
        if not os.path.exists(p):
            return
        try:
            c = sqlite3.connect("file:" + p.replace("\\", "/") + "?mode=ro", uri=True, timeout=30)
        except sqlite3.Error:
            return
        try:
            have = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "sets" in have:
                self.sets[game] = {str(i): n for i, n in c.execute("SELECT id, name FROM sets")}
            for table in ("cards", "sealed_products"):
                want = sorted({i for t, i in ids if t == table})
                if table in have:
                    for k in range(0, len(want), 500):
                        chunk = want[k:k + 500]
                        for i, img in c.execute(f"SELECT id, image_base FROM {table} WHERE id IN ({','.join('?' * len(chunk))})", chunk):
                            self.pics[game][(table, str(i))] = img
        except sqlite3.Error:
            pass
        finally:
            c.close()


def _value(game, col, v, look):
    out = {"field": FIELD.get(col, col), "value": v}
    if col == "set_id" and v:
        out["label"] = look.sets.get(game, {}).get(str(v)) or ""
    return out


def _pair(game, col, old, new, look):
    o, n = _value(game, col, old, look), _value(game, col, new, look)
    return {"field": o["field"], "old": old, "new": new, "oldLabel": o.get("label", ""), "newLabel": n.get("label", "")}


def row(e, undo, look, names):
    """One fix log line as the Changes tab shows it."""
    game, table, iid = e["game"], e["table"], str(e["item_id"])
    before, after = e.get("before") or {}, e.get("after") or {}
    kind = kind_of(e)
    out = {"id": e["id"], "when": e.get("when") or "", "day": e.get("day") or "", "by": _by(e), "game": game, "gameName": names.get(game) or game, "table": table, "itemId": iid,
           "name": e.get("name") or "", "kind": kind, "rule": e.get("rule") or "", "code": e.get("code") or "", "reason": e.get("reason") or "", "sources": list(e.get("sources") or []),
           "score": e.get("score"), "changes": [], "also": [], "removed": [], "pics": None, "pic": "", "reverted": None}
    if kind == "removed":
        out["removed"] = [[k, (str(v)[:_SHORT] + ("..." if len(str(v)) > _SHORT else "")) if v is not None else None] for k, v in before.items()]
        out["pic"] = _pic(game, before.get("image_base") or "")
    else:
        main = next((c for c in _MAIN if c in after), next(iter(after), None))
        for c in after:
            (out["changes"] if c == main else out["also"]).append(_pair(game, c, before.get(c), after.get(c), look))
        if "image_base" in after:
            out["pics"] = {"before": _pic(game, before.get("image_base") or ""), "after": _pic(game, after.get("image_base") or "")}
        else:
            out["pic"] = _pic(game, look.pics.get(game, {}).get((table, iid)) or "")
        if "stamp_before" in e:
            out["also"].append({"field": "nameMark", "old": (e["stamp_before"] or [None])[0], "new": "fix" if e.get("by") == fixlog.BY_OWNER else "acc", "oldLabel": "", "newLabel": ""})
    if undo:
        out["reverted"] = {"when": undo.get("when") or ""}
    return out


@api("dev.changes.list", quiet=True)
def changes_list(svc, day="", game="", by="", kind="", q="", limit=LIMIT):
    """Every change in the fix log, newest first, filtered -> {rows, total, days, games, kinds, bys}"""
    if runtime.IN_BROWSER:                                          # (the website and phone cannot reach that PC's fix log; nothing is uploaded)
        return {"rows": [], "total": 0, "days": [], "games": [], "kinds": [], "bys": [], "desktopOnly": DESKTOP_ONLY}
    log = fixlog.entries()
    undos = {e["undo_of"]: e for e in log if e.get("undo_of")}
    fixes = [e for e in log if not e.get("undo_of") and e.get("id")]
    names = _game_names()
    facets = {"days": sorted({e.get("day") or "" for e in fixes} - {""}, reverse=True), "games": sorted({e["game"] for e in fixes}), "kinds": sorted({kind_of(e) for e in fixes}),
              "bys": sorted({_by(e) for e in fixes})}
    qq = str(q or "").strip().lower()
    pick = [e for e in fixes if (not day or e.get("day") == day) and (not game or e["game"] == game) and (not by or _by(e) == by) and (not kind or kind_of(e) == kind)
            and (not qq or qq in str(e.get("name") or "").lower() or qq == str(e["item_id"]).lower())]
    pick.sort(key=lambda e: e.get("when") or "", reverse=True)
    total, pick = len(pick), pick[:max(1, min(int(limit or LIMIT), 2000))]
    look = _Lookup()
    for g in {e["game"] for e in pick}:
        look.load(g, {(e["table"], str(e["item_id"])) for e in pick if e["game"] == g})
    return {"rows": [row(e, undos.get(e["id"]), look, names) for e in pick], "total": total, "games": [{"id": g, "name": names.get(g) or g} for g in facets["games"]],
            "days": facets["days"], "kinds": facets["kinds"], "bys": facets["bys"]}


def _code(note):
    return "gone" if "not in the list" in note else "already" if "already undone" in note else "changed"


@api("dev.changes.revert")
def changes_revert(svc, id=""):
    """Take one change back and remember it (never made again by itself) -> {ok, note, code?, now: [{field, value, label}], row}"""
    if runtime.IN_BROWSER:
        raise ApiError(DESKTOP_ONLY, code="desktop_only")
    e = fixlog.find(str(id or ""))
    if e is None:
        raise ApiError("That change is not in the log.")
    p = _db(e["game"])
    if not os.path.exists(p):
        raise ApiError(f"The {e['game']} list is not on this PC.")
    conn = sqlite3.connect(p, timeout=60)
    try:
        ok, note = fixlog.undo(conn, e)
        now = fixlog.now_of(conn, e)
    finally:
        conn.close()
    look = _Lookup()
    look.load(e["game"], {(e["table"], str(e["item_id"]))})
    undo = next((u for u in reversed(fixlog.entries()) if u.get("undo_of") == e["id"]), None)
    out = {"ok": ok, "note": note, "now": [_value(e["game"], c, v, look) for c, v in now.items() if c != "in_list"], "inList": now.get("in_list"),
           "row": row(e, undo, look, _game_names())}
    if not ok:
        out["code"] = _code(note)
    return out


@api("dev.changes.revertAll")
def changes_revert_all(svc, day="", game="", by=""):
    """'Revert all from this night' (owner, quiz 13, 2026-11-13: 'an easy revert all if I see the first few nights are going poorly'): takes back every change the checkers
    (accuracy check, Mini you; not the owner's own review answers) made on `day`, newest first, each remembered like a single Revert.  -> {reverted, skipped, notes}"""
    if runtime.IN_BROWSER:
        raise ApiError(DESKTOP_ONLY, code="desktop_only")
    day = str(day or "").strip()
    if not day:
        raise ApiError("Pick a night first.")
    gone = fixlog.undone()
    todo = [e for e in reversed(fixlog.entries()) if not e.get("undo_of") and e.get("day") == day and e["id"] not in gone
            and e.get("by", fixlog.BY_CHECK) != fixlog.BY_OWNER and (not game or e["game"] == game) and (not by or BY.get(e.get("by", fixlog.BY_CHECK)) == by)]
    reverted, notes, conns = 0, [], {}
    try:
        for e in todo:
            p = _db(e["game"])
            if not os.path.exists(p):
                notes.append(f"{e.get('name') or e['item_id']}: the {e['game']} list is not on this PC")
                continue
            conn = conns.get(p) or conns.setdefault(p, sqlite3.connect(p, timeout=60))
            ok, note = fixlog.undo(conn, e)
            if ok:
                reverted += 1
            else:
                notes.append(f"{e.get('name') or e['item_id']}: {note}")
    finally:
        for c in conns.values():
            c.close()
    return {"reverted": reverted, "skipped": len(todo) - reverted, "notes": notes[:50]}
