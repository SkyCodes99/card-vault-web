"""Trade proposals between friends.  A proposal is one small sealed row in MY friend-profile share ("proposals"); the friend's answer is one row in THEIR profile share ("replies").
Nothing new on the server: each side only ever writes into its own share and reads the other's.  Accepting changes nothing by itself - each person presses "Update my collection"
on their own device, which applies exactly their half (the cards they give leave, the cards they get arrive) and can be undone.

Meaning of a proposal: `give` = what the person who made it hands over, `get` = what they want back."""
import json
import time

from ..cloud import sharing as sh
from .cards import lot_add, qty_adjust
from .friends import _book, _ensure_profile as _publish_profile, _gk, _mine, _norm, friend_groups
from .registry import ApiError, api
from .sharing import _acct, _call, _inn


def _applied(svc):
    try:
        d = json.loads(svc.pget("ftrade_applied") or "[]")
    except ValueError:
        d = []
    return d if isinstance(d, list) else []


def _cards(svc, items, own=False):
    v = svc.vault
    out = []
    for it in items or []:
        c = v.card_light(it.get("id"))
        if not c:
            continue
        out.append({"id": it["id"], "name": c.get("name", it["id"]), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": c.get("price_usd"), "qty": max(1, int(it.get("qty") or 1))})
    return out


def _total(cards):
    return round(sum((c.get("usd") or 0) * (c.get("qty") or 1) for c in cards), 2)


def _me(svc):
    return _norm(svc.pget("cloud_username"))


def _is_friend(svc, u):
    f = _book(svc).get(u) or {}
    return bool(f.get("in") and f.get("out") and not f.get("blocked"))


@api("ftrade.builder", quiet=True)
def builder(svc, username):
    """The two lists a proposal is built from: what I could give (my spares) and what my friend has available (their trade list), with the overlaps marked."""
    a = _acct(svc)
    u = _norm(username)
    v = svc.vault
    from .tradematch import _haves, _mine as _tmine
    mine_open = {cid: q for cid, q in _haves(svc, (_tmine(svc)[1] or {}).get("opts", {}).get("haves", "extras"))}
    my_wants = set(v.wishlist_ids())
    theirs, their_wants = {}, set()

    def go():
        for g, e in _inn(svc).items():
            if e.get("kind") == "trade" and _norm(e.get("from")) == u:
                rows = sh.pull_rows(a, g, _gk(e))
                info = rows.get(("meta", "info")) or {}
                if info.get("gameId") and info["gameId"] != svc.game.id:
                    continue
                for (c, i), d in rows.items():
                    if c == "haves":
                        theirs[i] = d
                    elif c == "wants":
                        their_wants.add(i)
    _call(go)
    give = [{**(_cards(svc, [{"id": cid, "qty": q}]) or [{"id": cid}])[0], "max": q, "wanted": cid in their_wants} for cid, q in mine_open.items() if v.card_light(cid)]
    get = [{"id": i, "name": d.get("name", i), "set": d.get("set", ""), "no": d.get("no", ""), "usd": d.get("usd"), "max": d.get("qty") or 1, "wanted": i in my_wants} for i, d in theirs.items()]
    give.sort(key=lambda c: (not c["wanted"], -(c.get("usd") or 0)))
    get.sort(key=lambda c: (not c["wanted"], -(c.get("usd") or 0)))
    return {"give": give[:300], "get": get[:300], "haveTheirList": bool(theirs)}


@api("ftrade.propose", mutates=True)
def propose(svc, username, give, get, note="", re=None):
    a = _acct(svc)
    u = _norm(username)
    if not _is_friend(svc, u):
        raise ApiError("You can only send a proposal to a friend (both of you accepted).")
    give, get = _cards(svc, give), _cards(svc, get)
    if not give and not get:
        raise ApiError("Pick at least one card.")
    pid = sh.new_id()

    def go():
        gid, e = _mine(svc)
        if not e:
            gid, e = _publish_profile(svc, a)
        sh.push_rows(a, gid, _gk(e), [("proposals", pid, {"id": pid, "from": _me(svc), "to": u, "give": give, "get": get, "giveTotal": _total(give), "getTotal": _total(get),
                                                         "note": (note or "")[:300], "at": time.time(), "game": svc.game.name, "gameId": svc.game.id, "re": re})])
        return {"id": pid}
    return _call(go)


@api("ftrade.cancel", mutates=True)
def cancel(svc, pid):
    a = _acct(svc)

    def go():
        gid, e = _mine(svc)
        if e:
            sh.push_rows(a, gid, _gk(e), [("proposals", pid, None)])
        return True
    return _call(go)


@api("ftrade.respond", mutates=True)
def respond(svc, pid, status):
    """Answer a friend's proposal: accepted or declined (a counter-offer is a new proposal plus a 'countered' answer)."""
    if status not in ("accepted", "declined", "countered"):
        raise ApiError("Unknown answer.")
    a = _acct(svc)

    def go():
        gid, e = _mine(svc)
        if not e:
            gid, e = _publish_profile(svc, a)
        sh.push_rows(a, gid, _gk(e), [("replies", pid, {"pid": pid, "status": status, "at": time.time()})])
        return True
    return _call(go)


@api("ftrade.list")
def listing(svc, _t=None):
    """My friends' proposals to me (with my answer) and mine to them (with their answer)."""
    a = _acct(svc)
    me = _me(svc)
    book = _book(svc)
    applied = set(_applied(svc))
    out = {"incoming": [], "outgoing": []}

    def go():
        gid, e = _mine(svc)
        mine_rows = sh.pull_rows(a, gid, _gk(e)) if e else {}
        my_replies = {d["pid"]: d for (c, _), d in mine_rows.items() if c == "replies"}
        their_replies = {}
        for u, (g, ge) in friend_groups(svc).items():
            f = book.get(u) or {}
            if not (f.get("in") and f.get("out")) or f.get("blocked"):
                continue
            rows = sh.pull_rows(a, g, _gk(ge))
            for (c, _), d in rows.items():
                if c == "replies":
                    their_replies[d["pid"]] = d
                if c == "proposals" and d.get("to") == me:
                    r = my_replies.get(d["id"])
                    out["incoming"].append({**d, "from": u, "nick": f.get("nick") or u, "status": (r or {}).get("status", "open"), "applied": d["id"] in applied})
        for (c, _), d in mine_rows.items():
            if c == "proposals":
                r = their_replies.get(d["id"])
                out["outgoing"].append({**d, "nick": (book.get(d["to"]) or {}).get("nick") or d["to"], "status": (r or {}).get("status", "open"), "applied": d["id"] in applied})
    _call(go)
    for k in ("incoming", "outgoing"):
        out[k].sort(key=lambda x: -(x.get("at") or 0))
    out["incoming"] = out["incoming"][:60]
    out["outgoing"] = out["outgoing"][:60]
    out["open"] = sum(1 for x in out["incoming"] if x["status"] == "open")
    return out


@api("ftrade.apply", mutates=True)
def apply(svc, pid):
    """After an accepted proposal: change MY collection by my half of it (the cards I give leave, the ones I get arrive).  Each person does their own side."""
    me = _me(svc)
    lst = listing(svc)
    p = next((x for x in lst["incoming"] + lst["outgoing"] if x["id"] == pid), None)
    if not p:
        raise ApiError("That proposal isn't there any more.")
    if p["status"] != "accepted":
        raise ApiError("It has to be accepted first.")
    if pid in _applied(svc):
        raise ApiError("You already updated your collection for this one.")
    if p.get("gameId") and p["gameId"] != svc.game.id:
        raise ApiError(f"This trade is for {p.get('game') or 'another game'} - switch to it first.")
    maker = p.get("from") == me
    gives = p["give"] if maker else p["get"]                           # what I hand over
    gets = p["get"] if maker else p["give"]                            # what I receive
    v = svc.vault
    owned = {r["card_id"]: r["q"] for r in v.conn.execute("SELECT card_id, SUM(qty) AS q FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY card_id", (v.user_id, v.game))}
    missing = [c["name"] for c in gives if owned.get(c["id"], 0) < c["qty"]]
    if missing:
        raise ApiError("You don't have enough copies of: " + ", ".join(missing[:5]) + ". Fix your collection first, then try again.")
    for c in gives:
        qty_adjust(svc, id=c["id"], delta=-c["qty"])
    for c in gets:
        lot_add(svc, id=c["id"], qty=c["qty"], condition="Near Mint")
    d = _applied(svc)
    d.append(pid)
    svc.pset("ftrade_applied", json.dumps(d[-300:]))
    return {"gave": sum(c["qty"] for c in gives), "got": sum(c["qty"] for c in gets)}
