"""Trade proposals between friends.  A proposal is one small sealed row in MY friend-profile share ("proposals"); the friend's answer is one row in THEIR profile share ("replies").
Nothing new on the server: each side only ever writes into its own share and reads the other's.  Accepting changes nothing by itself - each person presses "Update my collection"
on their own device, which applies exactly their half (the cards they give leave, the cards they get arrive) and can be undone.

Meaning of a proposal: `give` = what the person who made it hands over, `get` = what they want back."""
import json
import time

from .. import pricepick
from ..cloud import sharing as sh
from .cards import lot_add, qty_adjust
from .friends import _add_pics, _book, _ensure_profile as _publish_profile, _gk, _mine, _norm, friend_groups
from .registry import ApiError, api
from .sharing import _acct, _call, _inn, pull


def _applied(svc):
    try:
        d = json.loads(svc.pget("ftrade_applied") or "[]")
    except ValueError:
        d = []
    return d if isinstance(d, list) else []


def _https(x, n=400):
    return x if isinstance(x, str) and x.startswith("https://") and len(x) <= n else ""


def _qty(it):
    try:
        return max(1, min(int(it.get("qty") or 1), 999))
    except (TypeError, ValueError, OverflowError):
        return 1


def _cards(svc, items, own=False):
    """What goes into a proposal, worked out from MY card lists (never from what the screen sent): a card of the open game, a card of any other game (named 'game|card id' like in the Trade tab),
    or a sealed product ({"sealed": true, "id": <sealed product id>}).  Each keeps its game, price and picture address so the friend can show it whether or not they have that game."""
    from . import sealedcat, tradeany
    v, home = svc.vault, svc.game.id
    sealed = None
    out = []
    for it in items or []:
        if not isinstance(it, dict) or not isinstance(it.get("id"), (str, int)):
            continue
        if it.get("sealed"):
            if sealed is None:
                sealed = {str(r["id"]): r for r in (sealedcat._all(svc) or [])}
            r = sealed.get(str(it["id"]))
            if r:
                out.append({"id": str(r["id"]), "name": r["name"], "set": r.get("set") or "", "no": "", "usd": r.get("price"), "qty": _qty(it), "sealed": True, "gameId": home, "gameName": svc.game.name, "pic": _https(r.get("img"))})
            continue
        g, cid = tradeany.split_key(it["id"], home)
        if g == home:
            c = v.card_lights([cid]).get(cid)
            if c:
                out.append({"id": cid, "name": c.get("name", cid), "set": c.get("set_name", ""), "no": c.get("local_id", ""), "usd": pricepick.price_for(v, cid, c.get("price_usd")), "qty": _qty(it), "gameId": home, "gameName": svc.game.name})
        else:
            r = tradeany.row_of(svc, g, cid)
            if r:
                out.append({"id": cid, "name": r["name"], "set": r.get("set", ""), "no": r.get("number", ""), "usd": r.get("price"), "qty": _qty(it), "gameId": g, "gameName": r.get("gameName", g), "pic": _https(r.get("img"))})
    return out


def _text(x, n):
    return x[:n] if isinstance(x, str) else ""


def _clean(items, game_id="", game_name=""):
    """The cards of a proposal a FRIEND wrote, made safe to read and to act on: only well-formed entries, a whole number of copies from 1 to 999 (never negative, never huge), short text.
    (The person who writes a proposal is a friend, not the app: nothing in it is trusted.)  An entry without a game belongs to the game the proposal was made in."""
    out = []
    for it in (items if isinstance(items, list) else [])[:200]:
        if not isinstance(it, dict) or not isinstance(it.get("id"), str) or not it["id"] or len(it["id"]) > 80:
            continue
        try:
            qty = int(it.get("qty") or 1)
        except (TypeError, ValueError, OverflowError):
            qty = 1
        usd = it.get("usd")
        usd = float(usd) if isinstance(usd, (int, float)) and not isinstance(usd, bool) and 0 <= usd < 1e7 else None
        out.append({"id": it["id"], "name": _text(it.get("name"), 120) or it["id"], "set": _text(it.get("set"), 120), "no": _text(it.get("no"), 24), "usd": usd, "qty": max(1, min(qty, 999)),
                    "gameId": _text(it.get("gameId"), 40) or game_id, "gameName": _text(it.get("gameName"), 60) or game_name, "sealed": it.get("sealed") is True, "pic": _https(it.get("pic"))})
    return out


def _clean_proposal(d):
    gid, gname = _text(d.get("gameId"), 40), _text(d.get("game"), 60)
    d = {**d, "give": _clean(d.get("give"), gid, gname), "get": _clean(d.get("get"), gid, gname), "note": _text(d.get("note"), 300)}
    d["giveTotal"], d["getTotal"] = _total(d["give"]), _total(d["get"])
    return d


def _add_item_pics(svc, proposals):
    """Pictures for every card of the proposals shown (all games at once, the friend's own price kept so both sides see the same totals); sealed products keep the picture address they were sent with."""
    items = [c for p in proposals for c in p["give"] + p["get"] if not c["sealed"]]
    for c in items:
        c["_usd"] = c["usd"]
    _add_pics(svc, items)
    for c in items:
        c["usd"] = c.pop("_usd")


def _total(cards):
    return round(sum((c.get("usd") or 0) * (c.get("qty") or 1) for c in cards), 2)


def _me(svc):
    return _norm(svc.pget("cloud_username"))


def _is_friend(svc, u):
    f = _book(svc).get(u) or {}
    return bool(f.get("in") and f.get("out") and not f.get("blocked"))


@api("ftrade.builder", quiet=True)
def builder(svc, username):
    """The two lists a proposal is built from: what I could give (my spares) and what my friend has available (their trade list), with the overlaps marked."""
    a = _acct(svc)
    u = _norm(username)
    v = svc.vault
    from .tradematch import _haves, _mine as _tmine
    mine_open = {cid: q for cid, q in _haves(svc, (_tmine(svc)[1] or {}).get("opts", {}).get("haves", "extras"))}
    my_wants = set(v.wishlist_ids())
    theirs, their_wants = {}, set()

    def go():
        for g, e in _inn(svc).items():
            if e.get("kind") == "trade" and _norm(e.get("from")) == u:
                rows = pull(svc, a, g, _gk(e))
                info = rows.get(("meta", "info")) or {}
                if info.get("gameId") and info["gameId"] != svc.game.id:
                    continue
                for (c, i), d in rows.items():
                    if c == "haves":
                        theirs[i] = d
                    elif c == "wants":
                        their_wants.add(i)
    _call(go)
    mine_cards = {c["id"]: c for c in _cards(svc, [{"id": cid} for cid in mine_open])}
    give = [{**mine_cards[cid], "max": q, "wanted": cid in their_wants} for cid, q in mine_open.items() if cid in mine_cards]
    get = [{"id": i, "name": d.get("name", i), "set": d.get("set", ""), "no": d.get("no", ""), "usd": d.get("usd"), "max": d.get("qty") or 1, "wanted": i in my_wants, "gameId": svc.game.id, "gameName": svc.game.name} for i, d in theirs.items()]
    give.sort(key=lambda c: (not c["wanted"], -(c.get("usd") or 0)))
    get.sort(key=lambda c: (not c["wanted"], -(c.get("usd") or 0)))
    give, get = give[:300], get[:300]
    _add_pics(svc, give)
    _add_pics(svc, get)
    return {"give": give, "get": get, "haveTheirList": bool(theirs), "game": svc.game.id}


@api("ftrade.propose", mutates=True)
def propose(svc, username, give, get, note="", re=None):
    a = _acct(svc)
    u = _norm(username)
    if not _is_friend(svc, u):
        raise ApiError("You can only send a proposal to a friend (both of you accepted).")
    give, get = _cards(svc, give), _cards(svc, get)
    if not give and not get:
        raise ApiError("Pick at least one card.")
    pid = sh.new_id()

    def go():
        gid, e = _mine(svc)
        if not e:
            gid, e = _publish_profile(svc, a)
        sh.push_rows(a, gid, _gk(e), [("proposals", pid, {"id": pid, "from": _me(svc), "to": u, "give": give, "get": get, "giveTotal": _total(give), "getTotal": _total(get),
                                                         "note": (note or "")[:300], "at": time.time(), "game": svc.game.name, "gameId": svc.game.id, "re": re})])
        return {"id": pid}
    return _call(go)


@api("ftrade.cancel", mutates=True)
def cancel(svc, pid):
    """Take back a proposal I sent.  One Undo sends the very same proposal again (the row is kept in the recent-actions log)."""
    from .cards import with_undo
    a = _acct(svc)
    gone = {}

    def go():
        gid, e = _mine(svc)
        if e:
            row = sh.pull_rows(a, gid, _gk(e)).get(("proposals", pid))
            if isinstance(row, dict):
                gone["row"] = row
            sh.push_rows(a, gid, _gk(e), [("proposals", pid, None)])
        return True
    _call(go)

    def log():
        if gone.get("row"):
            with svc.vault.action("Took back a trade proposal" + (f" to {gone['row']['to']}" if gone["row"].get("to") else "")):
                svc.vault._remember({"t": "ftrade", "key": pid, "row": gone["row"]})
    return with_undo(svc, log)


def restore_proposal(svc, row):
    """Undo of cancel(): put the proposal back exactly as it was."""
    a = _acct(svc)

    def go():
        gid, e = _mine(svc)
        if not e:
            gid, e = _publish_profile(svc, a)
        sh.push_rows(a, gid, _gk(e), [("proposals", row["id"], row)])
        return True
    return _call(go)


@api("ftrade.respond", mutates=True)
def respond(svc, pid, status):
    """Answer a friend's proposal: accepted or declined (a counter-offer is a new proposal plus a 'countered' answer)."""
    if status not in ("accepted", "declined", "countered"):
        raise ApiError("Unknown answer.")
    a = _acct(svc)

    def go():
        gid, e = _mine(svc)
        if not e:
            gid, e = _publish_profile(svc, a)
        sh.push_rows(a, gid, _gk(e), [("replies", pid, {"pid": pid, "status": status, "at": time.time()})])
        return True
    return _call(go)


@api("ftrade.list")
def listing(svc, _t=None):
    """My friends' proposals to me (with my answer) and mine to them (with their answer)."""
    a = _acct(svc)
    me = _me(svc)
    book = _book(svc)
    applied = set(_applied(svc))
    out = {"incoming": [], "outgoing": []}
    from .safety import hidden_set, is_hidden
    hid = hidden_set(svc)                                           # offers I hid ("Hide" on a trade offer) are for me only

    def go():
        gid, e = _mine(svc)
        mine_rows = sh.pull_rows(a, gid, _gk(e)) if e else {}
        my_replies = {d["pid"]: d for (c, _), d in mine_rows.items() if c == "replies"}
        their_replies = {}
        for u, (g, ge) in friend_groups(svc).items():
            f = book.get(u) or {}
            if not (f.get("in") and f.get("out")) or f.get("blocked"):
                continue
            rows = pull(svc, a, g, _gk(ge))
            for (c, _), d in rows.items():
                if c == "replies" and isinstance(d, dict) and isinstance(d.get("pid"), str):
                    their_replies[d["pid"]] = d
                if c == "proposals" and isinstance(d, dict) and isinstance(d.get("id"), str) and d.get("to") == me and not is_hidden(hid, "trade", u, d["id"]):
                    d = _clean_proposal(d)
                    r = my_replies.get(d["id"])
                    out["incoming"].append({**d, "from": u, "nick": f.get("nick") or u, "status": (r or {}).get("status", "open"), "applied": d["id"] in applied})
        for (c, _), d in mine_rows.items():
            if c == "proposals" and isinstance(d, dict) and isinstance(d.get("id"), str):
                d = _clean_proposal(d)
                r = their_replies.get(d["id"])
                out["outgoing"].append({**d, "nick": (book.get(d["to"]) or {}).get("nick") or d["to"], "status": (r or {}).get("status", "open"), "applied": d["id"] in applied})
    _call(go)
    for k in ("incoming", "outgoing"):
        out[k].sort(key=lambda x: -(x.get("at") or 0))
    out["incoming"] = out["incoming"][:60]
    out["outgoing"] = out["outgoing"][:60]
    _add_item_pics(svc, out["incoming"] + out["outgoing"])
    out["open"] = sum(1 for x in out["incoming"] if x["status"] == "open")
    return out


@api("ftrade.apply", mutates=True)
def apply(svc, pid):
    """After an accepted proposal: change MY collection by my half of it (the cards I give leave, the ones I get arrive).  Each person does their own side."""
    me = _me(svc)
    lst = listing(svc)
    p = next((x for x in lst["incoming"] + lst["outgoing"] if x["id"] == pid), None)
    if not p:
        raise ApiError("That proposal isn't there any more.")
    if p["status"] != "accepted":
        raise ApiError("It has to be accepted first.")
    if pid in _applied(svc):
        raise ApiError("You already updated your collection for this one.")
    maker = p.get("from") == me
    gives = p["give"] if maker else p["get"]                           # what I hand over
    gets = p["get"] if maker else p["give"]                            # what I receive
    from . import tradeany, tradesealed
    home = svc.game.id
    sealed_in = [{"sealed": True, "name": c["name"], "qty": c["qty"], "price": c.get("usd")} for c in gets if c["sealed"]]
    sealed_out = [{"sealed": True, "name": c["name"], "qty": c["qty"], "price": c.get("usd")} for c in gives if c["sealed"]]
    tradesealed.check_give(svc, sealed_out)
    by_game = {}                                                       # cards of every game: each is checked, then changed, in its own game
    for c in gives:
        if not c["sealed"]:
            by_game.setdefault(c["gameId"] or home, ([], []))[0].append(c)
    for c in gets:
        if not c["sealed"]:
            by_game.setdefault(c["gameId"] or home, ([], []))[1].append(c)
    for g, (out_cards, in_cards) in by_game.items():                   # nothing is changed unless every game's part can be done
        with tradeany.in_game(svc, g):
            v = svc.vault
            owned = {r["card_id"]: r["q"] for r in v.conn.execute("SELECT card_id, SUM(qty) AS q FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY card_id", (v.user_id, v.game))}
            missing = [c["name"] for c in out_cards if owned.get(c["id"], 0) < c["qty"]]
            if missing:
                raise ApiError("You don't have enough copies of: " + ", ".join(missing[:5]) + ". Fix your collection first, then try again.")
            known = v.card_lights([c["id"] for c in in_cards])
            unknown = [c["name"] for c in in_cards if c["id"] not in known]
            if unknown:
                raise ApiError("These cards aren't in this game's card list on this device, so they can't be added: " + ", ".join(unknown[:5]) + ".")
    for g, (out_cards, in_cards) in by_game.items():
        with tradeany.in_game(svc, g):
            for c in out_cards:
                qty_adjust(svc, id=c["id"], delta=-c["qty"])
            for c in in_cards:
                lot_add(svc, id=c["id"], qty=c["qty"], condition="Near Mint")
    if sealed_in or sealed_out:
        tradesealed.apply_sealed(svc, sealed_out, sealed_in)
    d = _applied(svc)
    d.append(pid)
    svc.pset("ftrade_applied", json.dumps(d[-300:]))
    return {"gave": sum(c["qty"] for c in gives), "got": sum(c["qty"] for c in gets)}
