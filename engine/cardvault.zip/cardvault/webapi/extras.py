"""3.6 extras: collection health, timeline, shopping list, variant reminders, challenges, year in review, trade price ranges, quick-add by text,
sealed products (barcode), dream binders and condition photos."""
import base64
import datetime
import io
import json
import re

from .. import taxonomy, tools
from ..db import new_uuid, now_iso, today
from .cards import GENERATIONS, img
from .money import card_row
from .registry import ApiError, api


# ------------------------------------------------------------------------------------------------ collection health
@api("health.score")
def health_score(svc):
    v = svc.vault
    rows = [dict(r) for r in v.conn.execute("SELECT qty, condition, graded, purchase_price, purchased, source, location, card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game))]
    if not rows:
        return {"score": 0, "parts": [], "tips": ["Add some cards and this score fills in."], "empty": True}
    total = sum(r["qty"] for r in rows)
    frac = lambda pred: sum(r["qty"] for r in rows if pred(r)) / total
    owned = v.owned_by_set()
    sets = [(owned.get(s["id"], 0), s["n"] or 0) for s in v.sets() if owned.get(s["id"], 0)]
    completeness = (sum(min(o / n, 1) for o, n in sets if n) / len(sets)) if sets else 0
    condition = frac(lambda r: r["graded"] or r["condition"] == "Near Mint")
    documented = (frac(lambda r: r["purchase_price"] is not None) + frac(lambda r: bool(r["purchased"])) + frac(lambda r: bool(r["source"]))) / 3
    organised = frac(lambda r: bool(r["location"]))
    priced = sum(1 for r in rows if (v.card_light(r["card_id"]) or {}).get("price_usd") is not None) / len(rows)
    parts = [("Set progress", completeness, 30), ("Condition", condition, 20), ("Purchase details", documented, 25), ("Stored somewhere", organised, 15), ("Priced cards", priced, 10)]
    score = round(sum(p * w for _, p, w in parts))
    tips = []
    if frac(lambda r: r["purchase_price"] is None) > 0.3:
        tips.append(f"{sum(r['qty'] for r in rows if r['purchase_price'] is None):,} copies have no price paid - add it to see real profit.")
    if frac(lambda r: not r["purchased"]) > 0.3:
        tips.append("Add purchase dates so the Portfolio graph can go back to when you bought each card.")
    if frac(lambda r: not r["location"]) > 0.5:
        tips.append("Say where your cards are kept (binder, box, shelf) so you can find them.")
    if frac(lambda r: r["condition"] in ("Heavily Played", "Damaged")) > 0.1:
        tips.append("A lot of your copies are heavily played - upgrades are often cheap for common cards.")
    best = max(sets, key=lambda t: (t[0] / t[1]) if t[1] else 0, default=None)
    if best and best[1] and 0.7 <= best[0] / best[1] < 1:
        tips.append(f"One of your sets is {round(100 * best[0] / best[1])}% done - finishing it is the quickest win (Finish this set).")
    return {"score": score, "parts": [{"name": n, "pct": round(100 * p), "weight": w} for n, p, w in parts], "tips": tips or ["Looking good - keep your details up to date."], "empty": False}


# ------------------------------------------------------------------------------------------------ timeline
@api("timeline.list")
def timeline(svc, limit=120):
    v = svc.vault
    lots = [dict(r) for r in v.conn.execute("SELECT card_id, qty, graded, grade_company, grade, COALESCE(NULLIF(purchased,''), substr(added,1,10)) AS day FROM lots_s "
                                           "WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY day, id", (v.user_id, v.game))]
    events, seen_cards, count, month_n = [], set(), 0, {}
    marks = [1, 10, 50, 100, 250, 500, 1000, 2500, 5000, 10000]
    first_graded = False
    set_cards = {}
    for r in v.conn.execute("SELECT set_id, COUNT(*) FROM cards GROUP BY set_id"):
        set_cards[r[0]] = r[1]
    per_set = {}
    for r in lots:
        c = v.card_light(r["card_id"]) or {}
        prev = count
        count += r["qty"]
        month_n[r["day"][:7]] = month_n.get(r["day"][:7], 0) + r["qty"]
        for m in marks:
            if prev < m <= count:
                events.append({"day": r["day"], "kind": "milestone", "title": "First card added" if m == 1 else f"{m:,} cards in your collection", "detail": c.get("name", "")})
        if r["graded"] and not first_graded:
            first_graded = True
            events.append({"day": r["day"], "kind": "grade", "title": "First graded card", "detail": f"{c.get('name', '')} - {r['grade_company']} {r['grade']}".strip()})
        if r["card_id"] not in seen_cards:
            seen_cards.add(r["card_id"])
            sid = c.get("set_id")
            if sid:
                per_set[sid] = per_set.get(sid, 0) + 1
                if per_set[sid] == set_cards.get(sid) and set_cards.get(sid, 0) > 5:
                    events.append({"day": r["day"], "kind": "set", "title": f"Completed {c.get('set_name', sid)}", "detail": f"all {per_set[sid]} cards"})
    for m, n in month_n.items():
        events.append({"day": m + "-28", "kind": "month", "title": f"{n:,} card{'s' if n != 1 else ''} added in {datetime.date(int(m[:4]), int(m[5:7]), 1):%B %Y}", "detail": ""})
    for t in v.trades(60):
        events.append({"day": t["ts"][:10], "kind": "trade", "title": "Trade" + (f" with {t['partner']}" if t["partner"] else ""), "detail": ""})
    events.sort(key=lambda e: e["day"], reverse=True)
    return events[:limit]


# ------------------------------------------------------------------------------------------------ shopping list
TIERS = [("Bulk (under $1)", 0, 1), ("Budget ($1 - $5)", 1, 5), ("Mid ($5 - $20)", 5, 20), ("Chase ($20 and up)", 20, 1e12)]


@api("shop.list")
def shop_list(svc, kind="set", key=None):
    v = svc.vault
    if key is None:
        return {"tiers": [], "total": 0, "count": 0}
    ids = [r[0] for r in v.conn.execute("SELECT id FROM cards WHERE set_id=?", (key,))] if kind == "set" else list(v.checklist_members(key))
    res = tools.finish_cost(v, ids)
    tiers = [{"name": n, "lo": lo, "hi": hi, "cards": [], "sum": 0.0} for n, lo, hi in TIERS] + [{"name": "No price found", "lo": None, "hi": None, "cards": [], "sum": 0.0}]
    for m in res["missing"]:
        p = m["price"]
        t = tiers[-1] if p is None else next(t for t in tiers[:-1] if t["lo"] <= p < t["hi"])
        q = re.sub(r"\s+", "+", f"{m['name']} {m['number']}".strip())
        t["cards"].append({**m, "tcgplayer": f"https://www.tcgplayer.com/search/pokemon/product?q={q}", "ebay": f"https://www.ebay.com/sch/i.html?_nkw={q}+pokemon+card"})
        t["sum"] += p or 0
    tiers = [t for t in tiers if t["cards"]]
    return {"tiers": tiers, "total": round(res["cost"], 2), "count": len(res["missing"]), "unpriced": res["unpriced"]}


# ------------------------------------------------------------------------------------------------ variant reminders
@api("variants.missing")
def variants_missing(svc, limit=300):
    """Cards you own where another version (reverse holo, holo, 1st edition...) exists that you don't have yet."""
    from ..db import VARIANT_FLAGS, VARIANT_LABELS
    v = svc.vault
    have = v.owned_variants()
    out = []
    for cid, vs in have.items():
        row = v.conn.execute("SELECT name, local_id, set_id, variants, rarity FROM cards WHERE id=?", (cid,)).fetchone()
        if not row:
            continue
        try:
            from ..db import clean_flags
            flags = clean_flags(json.loads(row["variants"] or "{}"), row["rarity"])
        except ValueError:
            continue
        labels = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)]
        miss = [x for x in labels if x not in vs]
        if len(labels) > 1 and miss:
            out.append({"id": cid, "name": row["name"], "number": row["local_id"], "set": (v.card_light(cid) or {}).get("set_name", ""), "missing": miss, "img": img(cid, row["set_id"])})
    out.sort(key=lambda r: (r["set"], r["number"]))
    on = bool(svc.pget("variant_reminders", False))
    hunting = bool(v.get_setting("variant_hunting")) or any(c["per_variant"] for c in v.checklists())
    return {"enabled": on, "hunting": hunting, "rows": out[:limit] if on else [], "total": len(out)}


@api("variants.enable")
def variants_enable(svc, on):
    svc.pset("variant_reminders", bool(on))
    return {"ok": True}


@api("variants.noteHunting")
def variants_hunting(svc):
    svc.vault.set_setting("variant_hunting", "1")           # set when the master-set view is used, so the reminders can be offered
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ challenges
@api("challenges.list")
def challenges(svc):
    v = svc.vault
    idx = v.card_index()
    owned = svc.owned
    mine = [c for c in idx if owned.get(c["id"], 0) > 0]
    out = []

    def add(cid, title, desc, have, total):
        out.append({"id": cid, "title": title, "desc": desc, "have": have, "total": total, "done": bool(total) and have >= total})

    if svc.game.pokemon:
        types = {t.strip() for c in idx for t in (c.get("types") or "").split(",") if t.strip()}
        got = {t.strip() for c in mine for t in (c.get("types") or "").split(",") if t.strip()}
        add("types", "One of every type", "Own at least one card of each Pokémon type.", len(got & types), len(types))
        gens = 0
        for rng, _lab in GENERATIONS[1:]:
            lo, hi = (int(x) for x in rng.split("-"))
            if any(lo <= int(d) <= hi for c in mine for d in (c.get("dex") or "").split(",") if d.strip().isdigit()):
                gens += 1
        add("gens", "One from every generation", "A Pokémon from each of the nine generations.", gens, len(GENERATIONS) - 1)
        labels = {taxonomy.card_rarity_label(c, c["groups"]) for c in idx}
        mine_labels = {taxonomy.card_rarity_label(c, c["groups"]) for c in mine}
        add("ladder", "Rarity ladder", "Own a card of as many different rarities as exist.", len(mine_labels), len(labels))
        art = sum(1 for c in mine if "art" in c["groups"])
        for n in (10, 50, 100):
            add(f"art{n}", f"Art collector: {n}", f"Own {n} art cards (Illustration Rares, Alt Arts, Gallery cards...).", min(art, n), n)
        add("trainer", "Trainer & Supporter fan", "25 different Trainer cards.", min(sum(1 for c in mine if "c_trainer" in c["groups"]), 25), 25)
    series = {c.get("serie") for c in idx if c.get("serie")}
    got_series = {c.get("serie") for c in mine if c.get("serie")}
    add("series", "One from every era", "At least one card from each series / era.", len(got_series & series), len(series))
    copies = sum(owned.values())
    for n in (100, 500, 1000, 2500):
        add(f"cards{n}", f"{n:,} cards", f"Own {n:,} cards in total.", min(copies, n), n)
    done_sets = sum(1 for s in v.sets() if s["n"] and v.owned_by_set().get(s["id"], 0) >= s["n"])
    add("sets3", "Set finisher", "Complete 3 whole sets.", min(done_sets, 3), 3)
    out.sort(key=lambda c: (c["done"], -(c["have"] / c["total"] if c["total"] else 0)))
    return out


# ------------------------------------------------------------------------------------------------ year in review
@api("year.review")
def year_review(svc, year=None):
    v = svc.vault
    year = int(year or datetime.date.today().year)
    y = str(year)
    lots = [dict(r) for r in v.conn.execute(
        "SELECT card_id, qty, purchase_price, graded, COALESCE(NULLIF(purchased,''), substr(added,1,10)) AS day FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game))]
    mine = [r for r in lots if r["day"].startswith(y)]
    spent = sum((r["purchase_price"] or 0) * r["qty"] for r in mine)
    added = sum(r["qty"] for r in mine)
    now_val = 0.0
    gains, sets_touched, top = [], {}, []
    for r in mine:
        c = v.card_light(r["card_id"]) or {}
        val = (c.get("price_usd") or 0) * r["qty"]
        now_val += val
        if r["purchase_price"] is not None and c.get("price_usd") is not None:
            gains.append((val - r["purchase_price"] * r["qty"], c.get("name", ""), c.get("set_name", "")))
        sets_touched[c.get("set_name", "")] = sets_touched.get(c.get("set_name", ""), 0) + r["qty"]
        top.append((val / max(r["qty"], 1), c.get("name", ""), c.get("set_name", ""), r["card_id"]))
    top.sort(reverse=True)
    gains.sort(reverse=True)
    trades = [t for t in v.trades(500) if t["ts"].startswith(y)]
    snaps = [s for s in v.snapshots() if s["day"].startswith(y)]
    return {"year": year, "added": added, "unique": len({r["card_id"] for r in mine}), "spent": round(spent, 2), "valueNow": round(now_val, 2),
            "bestPull": [{"name": n, "set": s, "price": round(p, 2), "id": i} for p, n, s, i in top[:5]],
            "bestGain": [{"name": n, "set": s, "gain": round(g, 2)} for g, n, s in gains[:3]],
            "topSets": sorted(({"set": k, "cards": n} for k, n in sets_touched.items() if k), key=lambda x: -x["cards"])[:5],
            "graded": sum(r["qty"] for r in mine if r["graded"]), "trades": len(trades),
            "valueStart": snaps[0]["total_usd"] if snaps else None, "valueEnd": snaps[-1]["total_usd"] if snaps else None}


# ------------------------------------------------------------------------------------------------ trade fairness: recent price range
@api("trade.range")
def trade_range(svc, ids):
    v = svc.vault
    out = {}
    cutoff = (datetime.date.today() - datetime.timedelta(days=45)).isoformat()
    for cid in ids:
        pts = [usd for d, usd, _ in v.price_history(cid) if usd is not None and d >= cutoff]
        now = (v.card_light(cid) or {}).get("price_usd")
        if len(pts) >= 2:
            out[cid] = {"lo": min(pts), "hi": max(pts), "now": now, "real": True}
        elif now is not None:
            out[cid] = {"lo": round(now * 0.85, 2), "hi": round(now * 1.15, 2), "now": now, "real": False}
    return out


# ------------------------------------------------------------------------------------------------ quick add by typing / voice
_NUM = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
_FILLER = {"add", "adding", "got", "bought", "buy", "picked", "up", "pulled", "of", "the", "card", "cards", "copy", "copies", "please", "i", "new", "my", "to", "collection"}


@api("quick.parse")
def quick_parse(svc, text):
    """'add two pikachu from 151' / 'charizard 4' / '3 bulbasaur 151 001'  ->  how many + the best matching cards."""
    v = svc.vault
    t = re.sub(r"[^\w#/\s'.-]", " ", (text or "").lower())
    words = t.split()
    qty, name_words, set_hint, number = 1, [], "", ""
    i = 0
    while i < len(words):
        w = words[i]
        if w in ("from", "in", "of") and i + 1 < len(words) and name_words:
            set_hint = " ".join(words[i + 1:])
            break
        if w in _NUM and not name_words:
            qty = _NUM[w]
        elif re.fullmatch(r"x?\d{1,2}x?", w) and not name_words:
            qty = int(w.strip("x"))
        elif re.fullmatch(r"#?\d{1,4}(/\d+)?", w) and name_words:
            number = w.lstrip("#").split("/")[0]
        elif w not in _FILLER:
            name_words.append(w)
        i += 1
    name = " ".join(name_words)
    if not name:
        return {"qty": qty, "query": "", "results": []}
    sets = {s["id"]: s["name"].lower() for s in v.sets()}
    want_sets = {sid for sid, n in sets.items() if set_hint and (set_hint in n or set_hint == sid.lower())}
    rows = v.query_cards(text=name)
    if number:
        rows = [r for r in rows if str(r[3]).lstrip("0") == number.lstrip("0")] or rows
    if want_sets:
        rows = [r for r in rows if r[2] in want_sets] or rows
    return {"qty": qty, "query": name, "set": set_hint, "results": [card_row(svc, r[0]) for r in rows[:8]]}


# ------------------------------------------------------------------------------------------------ sealed products
def _sealed_row(r):
    return {"id": r["uuid"], "upc": r["upc"] or "", "name": r["name"] or "", "qty": r["qty"], "paid": r["paid"], "purchased": r["purchased"] or "", "source": r["source"] or "", "notes": r["notes"] or ""}


@api("sealed.list")
def sealed_list(svc):
    v = svc.vault
    from .sealedcat import price_for
    from ..tcgcsv import norm_name
    out, by = [], {}
    for r in v.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 ORDER BY name COLLATE NOCASE, purchased, rowid", (v.user_id, v.game)):
        if v.scope and (r["portfolio"] or "") not in v.scope:
            continue                                                  # products in a portfolio you are not looking at
        buy = _sealed_row(r)
        key = (norm_name(r["name"]), r["portfolio"] or "")
        row = by.get(key)
        if row is None:                                               # the first purchase of a product is the row people see; later purchases of it fold into it
            row = dict(buy)
            row["portfolio"] = r["portfolio"] or "main"
            pf = price_for(v, r["name"])
            row["value"], row["valueKind"] = (pf["price"], pf["kind"]) if pf else (None, "")
            row["buys"] = []
            by[key] = row
            out.append(row)
        row["buys"].append(buy)
    for row in out:                                                   # one price for the whole row = the average of what was paid, counting only copies that have a price
        bs = row["buys"]
        row["qty"] = sum(b["qty"] or 0 for b in bs)
        priced = [b for b in bs if b["paid"] is not None and (b["qty"] or 0) > 0]
        n = sum(b["qty"] for b in priced)
        row["paid"] = round(sum(b["qty"] * b["paid"] for b in priced) / n, 4) if n else None
        row["avg"] = len({b["paid"] for b in priced}) > 1                # true when the average hides different prices
        row["purchased"] = min((b["purchased"] for b in bs if b["purchased"]), default="")
    return out


def sealed_save(svc, name, qty=1, paid=None, purchased="", source="", notes="", upc="", id=None, portfolio=None):
    v = svc.vault
    pf = v.target_pf if portfolio is None else ("" if portfolio == "main" else portfolio)          # which portfolio it goes into (shown and chosen in the form)
    name = (name or "").strip()
    if not name:
        raise ApiError("Give the product a name.")
    if id:
        if portfolio is not None:
            v.check_accepts(pf, "sealed")
        old = v.conn.execute("SELECT name, portfolio FROM u.sealed WHERE uuid=? AND user_id=?", (id, v.user_id)).fetchone()
        if old and old["name"] != name:                                       # renaming a product renames every purchase of it, so they stay together
            from ..tcgcsv import norm_name
            for s2 in v.conn.execute("SELECT uuid, name FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND COALESCE(portfolio,'')=? AND uuid<>?", (v.user_id, v.game, old["portfolio"] or "", id)).fetchall():
                if norm_name(s2["name"]) == norm_name(old["name"]):
                    v.conn.execute("UPDATE u.sealed SET name=?, updated_at=? WHERE uuid=?", (name, now_iso(), s2["uuid"]))
        v.conn.execute("UPDATE u.sealed SET name=?, qty=?, paid=?, purchased=?, source=?, notes=?, upc=?, portfolio=COALESCE(?, portfolio), updated_at=? WHERE uuid=? AND user_id=?",
                       (name, int(qty), paid, purchased, source, notes, upc, None if portfolio is None else pf, now_iso(), id, v.user_id))
    else:
        v.check_accepts(pf, "sealed")
        id = new_uuid()
        v.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                       (id, v.user_id, v.game, upc, name, int(qty), paid, purchased or today(), source, notes, pf, now_iso()))
    if upc:
        v.conn.execute("INSERT OR REPLACE INTO u.upc_names VALUES(?,?)", (upc, name))
    v.commit()
    return {"id": id}


def sealed_adjust(svc, delta, id=None, name=None):
    """The + / - on a sealed product: one more or one fewer.  By row `id` (My sealed products), or by product `name` (Browse): that product in the portfolio being added to,
    made with 1 copy if it isn't there yet.  Details (price paid, date, notes) can be filled in later by opening it."""
    from ..tcgcsv import norm_name
    v = svc.vault
    delta = max(-9999, min(9999, int(delta)))                                 # +1 / -1 from the buttons, or the difference when a quantity is typed in
    if delta == 0:
        return {"qty": None}
    row = None
    if id:
        row = v.conn.execute("SELECT * FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (id, v.user_id)).fetchone()
    elif name:
        key = norm_name(name)
        pf = v.target_pf or ""
        for r in v.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)):
            if norm_name(r["name"]) == key and (r["portfolio"] or "") == pf:
                row = r
                break
        if row is None and delta < 0:                                         # nothing in this portfolio to take away - take from wherever it is
            for r in v.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (v.user_id, v.game)):
                if norm_name(r["name"]) == key:
                    row = r
                    break
        if row is None:
            if delta < 0:
                return {"qty": 0}
            v.check_accepts(pf, "sealed")
            from .sealedcat import price_for
            nid = new_uuid()
            v.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                           (nid, v.user_id, v.game, "", name, delta, None, today(), "", "", pf, now_iso()))
            v.commit()
            return {"qty": delta, "id": nid}
    if row is None:
        raise ApiError("That product isn't in your list any more.")
    q = (row["qty"] or 0) + delta
    if q <= 0:
        v.conn.execute("UPDATE u.sealed SET qty=0, deleted=1, updated_at=? WHERE uuid=?", (now_iso(), row["uuid"]))
        short = -q                                                            # taking away more than this purchase holds: the rest comes off the product's other purchases (newest first)
        if short > 0:
            for s2 in v.conn.execute("SELECT * FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0 AND uuid<>? ORDER BY purchased DESC, rowid DESC", (v.user_id, v.game, row["uuid"])).fetchall():
                if short <= 0:
                    break
                if norm_name(s2["name"]) != norm_name(row["name"]) or (s2["portfolio"] or "") != (row["portfolio"] or ""):
                    continue
                take = min(short, s2["qty"])
                if take >= s2["qty"]:
                    v.conn.execute("UPDATE u.sealed SET qty=0, deleted=1, updated_at=? WHERE uuid=?", (now_iso(), s2["uuid"]))
                else:
                    v.conn.execute("UPDATE u.sealed SET qty=qty-?, updated_at=? WHERE uuid=?", (take, now_iso(), s2["uuid"]))
                short -= take
    else:
        v.conn.execute("UPDATE u.sealed SET qty=?, updated_at=? WHERE uuid=?", (q, now_iso(), row["uuid"]))
    v.commit()
    return {"qty": max(q, 0), "id": row["uuid"]}


def sealed_delete(svc, id=None, ids=None):
    for i in (ids or [id]):                                           # one purchase, or every purchase of a product at once
        svc.vault.conn.execute("UPDATE u.sealed SET deleted=1, updated_at=? WHERE uuid=? AND user_id=?", (now_iso(), i, svc.vault.user_id))
    svc.vault.commit()
    return {"ok": True}


@api("sealed.lookup")
def sealed_lookup(svc, upc):
    """The name for a barcode: what you named it before, else a public barcode lookup (online), else nothing."""
    upc = re.sub(r"\D", "", upc or "")
    r = svc.vault.conn.execute("SELECT name FROM u.upc_names WHERE upc=?", (upc,)).fetchone()
    if r:
        return {"upc": upc, "name": r[0], "from": "you"}
    try:
        import requests
        d = requests.get("https://api.upcitemdb.com/prod/trial/lookup", params={"upc": upc}, timeout=12).json()
        item = (d.get("items") or [None])[0]
        if item and item.get("title"):
            return {"upc": upc, "name": item["title"], "from": "web"}
    except Exception:  # noqa: BLE001 - offline or rate-limited: the person types the name once
        pass
    return {"upc": upc, "name": "", "from": ""}


# ------------------------------------------------------------------------------------------------ dream binders
@api("binder.list")
def binder_list(svc):
    v = svc.vault
    out = []
    for r in v.conn.execute("SELECT * FROM u.dream_binders WHERE user_id=? AND game=? AND deleted=0 ORDER BY name COLLATE NOCASE", (v.user_id, v.game)):
        slots = json.loads(r["slots"] or "{}")
        out.append({"id": r["uuid"], "name": r["name"], "rows": r["rows"], "cols": r["cols"], "pages": r["pages"], "filled": len(slots),
                    "owned": sum(1 for c in slots.values() if svc.owned.get(c, 0) > 0), "slots": r["rows"] * r["cols"] * r["pages"]})
    return out


@api("binder.get")
def binder_get(svc, id):
    r = svc.vault.conn.execute("SELECT * FROM u.dream_binders WHERE uuid=?", (id,)).fetchone()
    if not r:
        raise ApiError("binder not found")
    slots = json.loads(r["slots"] or "{}")
    cards = {}
    for key, cid in slots.items():
        light = svc.vault.card_light(cid)
        if light:
            cards[key] = {"id": cid, "name": light["name"], "number": light["local_id"], "set": light.get("set_name", ""), "price": light.get("price_usd"),
                          "qty": svc.owned.get(cid, 0), "img": img(cid, light["set_id"])}
    return {"id": r["uuid"], "name": r["name"], "rows": r["rows"], "cols": r["cols"], "pages": r["pages"], "cards": cards}


@api("binder.save", mutates=True)
def binder_save(svc, name, rows=3, cols=3, pages=4, id=None):
    v = svc.vault
    rows, cols, pages = max(1, min(int(rows), 20)), max(1, min(int(cols), 20)), max(1, min(int(pages), 60))
    if id:
        v.conn.execute("UPDATE u.dream_binders SET name=?, rows=?, cols=?, pages=?, updated_at=? WHERE uuid=?", (name.strip() or "Dream binder", rows, cols, pages, now_iso(), id))
    else:
        id = new_uuid()
        v.conn.execute("INSERT INTO u.dream_binders(uuid,user_id,game,name,rows,cols,pages,slots,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,0)",
                       (id, v.user_id, v.game, name.strip() or "Dream binder", rows, cols, pages, "{}", now_iso()))
    v.commit()
    return {"id": id}


@api("binder.setSlot", mutates=True)
def binder_set_slot(svc, id, key, card=None):
    v = svc.vault
    r = v.conn.execute("SELECT slots FROM u.dream_binders WHERE uuid=?", (id,)).fetchone()
    if not r:
        raise ApiError("binder not found")
    slots = json.loads(r[0] or "{}")
    if card:
        slots[key] = card
    else:
        slots.pop(key, None)
    v.conn.execute("UPDATE u.dream_binders SET slots=?, updated_at=? WHERE uuid=?", (json.dumps(slots), now_iso(), id))
    v.commit()
    return {"ok": True}


@api("binder.delete", mutates=True)
def binder_delete(svc, id):
    svc.vault.conn.execute("UPDATE u.dream_binders SET deleted=1, updated_at=? WHERE uuid=?", (now_iso(), id))
    svc.vault.commit()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ condition photos
def _jpeg(data_url, max_side=900):
    from PIL import Image
    raw = base64.b64decode(data_url.split(",", 1)[-1])
    with Image.open(io.BytesIO(raw)) as im:
        im = im.convert("RGB")
        im.thumbnail((max_side, max_side))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=80)
    return buf.getvalue()


def _photo_owner(svc, lot=None, uuid=None):
    """The uuid a photo is kept under: a card copy (by its number) or a sealed purchase (by its uuid) - or None."""
    if uuid:
        c = svc.vault.conn
        ok = c.execute("SELECT 1 FROM u.sealed WHERE uuid=? AND user_id=? AND deleted=0", (uuid, svc.vault.user_id)).fetchone() or             c.execute("SELECT 1 FROM u.lots WHERE uuid=? AND user_id=? AND deleted=0", (uuid, svc.vault.user_id)).fetchone()
        return uuid if ok else None
    r = svc.vault.get_lot(lot) if lot is not None else None
    return r["uuid"] if r else None


@api("photo.list")
def photo_list(svc, lot=None, uuid=None):
    owner = _photo_owner(svc, lot, uuid)
    if not owner:
        return []
    return [{"id": p["id"], "side": p["side"], "img": "data:image/jpeg;base64," + base64.b64encode(p["data"]).decode()} for p in
            svc.vault.conn.execute("SELECT id, side, data FROM u.lot_photos WHERE lot_uuid=? ORDER BY id", (owner,))]


@api("photo.add", mutates=True)
def photo_add(svc, side, image, lot=None, uuid=None):
    owner = _photo_owner(svc, lot, uuid)
    if not owner:
        raise ApiError("copy not found")
    n = svc.vault.conn.execute("SELECT COUNT(*) FROM u.lot_photos WHERE lot_uuid=?", (owner,)).fetchone()[0]
    if n >= 8:
        raise ApiError("A copy can have up to 8 photos.")
    try:
        data = _jpeg(image)
    except Exception:  # noqa: BLE001
        raise ApiError("That isn't a picture I can read.")
    svc._photos_changed = True
    svc.vault.conn.execute("INSERT INTO u.lot_photos(lot_uuid, side, data, added) VALUES(?,?,?,?)", (owner, side if side in ("front", "back", "other") else "other", data, now_iso()))
    svc.vault.commit()
    return {"ok": True}


@api("photo.delete", mutates=True)
def photo_delete(svc, id):
    from ..cloud import photos
    row = svc.vault.conn.execute("SELECT lot_uuid, data FROM u.lot_photos WHERE id=?", (id,)).fetchone()
    if row and row["data"]:                           # remember it was removed, so a synced copy on another device doesn't bring it back
        svc.vault.conn.execute("INSERT OR IGNORE INTO u.photo_deleted VALUES(?,datetime('now'))", (photos.key_for(row["lot_uuid"], row["data"]),))
    svc.vault.conn.execute("DELETE FROM u.lot_photos WHERE id=?", (id,))
    svc._photos_changed = True
    svc.vault.commit()
    return {"ok": True}


# ---- the sealed changes are undoable (Undo in the message, and in Recent actions): each one is run through sealed_action, which remembers what the purchase rows looked like before
def _undoable(svc, label, fn):
    from .cards import with_undo
    return with_undo(svc, lambda: svc.vault.sealed_action(label, fn))


@api("sealed.save", mutates=True)
def sealed_save_api(svc, name, qty=1, paid=None, purchased="", source="", notes="", upc="", id=None, portfolio=None):
    return _undoable(svc, "Saved a sealed product", lambda: sealed_save(svc, name, qty, paid, purchased, source, notes, upc, id, portfolio))


@api("sealed.adjust", mutates=True)
def sealed_adjust_api(svc, delta, id=None, name=None):
    return _undoable(svc, "Changed how many sealed products", lambda: sealed_adjust(svc, delta, id, name))


@api("sealed.delete", mutates=True)
def sealed_delete_api(svc, id=None, ids=None):
    return _undoable(svc, "Removed a sealed product", lambda: sealed_delete(svc, id, ids))
