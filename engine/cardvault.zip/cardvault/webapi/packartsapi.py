"""Pack arts of a sleeved booster pack (cardvault/packarts.py): which arts each purchase line holds, and the count of one art."""
from .. import packarts
from ..db import now_iso
from .registry import ApiError, api


@api("sealed.packArts", quiet=True)
def pack_arts(svc, name, ids=(), _t=None):
    """The arts of one product (found by name) and how many of each every purchase line `ids` holds.  {arts: []} when the product has no arts on record.
    Each art's img is '' until a photo list gives it an allowed picture (never a Bulbagarden one: packarts.picture), with that picture's credit."""
    v = svc.vault
    e = packarts.for_name(name, v.game)
    if not e:
        return {"arts": []}
    ids = [str(i) for i in (ids or ())][:200]
    return {"arts": packarts.for_ui(e), "counts": packarts.counts(v, ids) if ids else {}}


@api("sealed.packArt", mutates=True)
def pack_art(svc, id, art, n):
    """How many of one art a purchase line holds.  The counts of a line never add up to more than its quantity."""
    v = svc.vault
    try:
        have = packarts.set_count(v, str(id), str(art), int(n), now_iso())
    except packarts.TooMany as e:
        raise ApiError(f"These counts add up to more than the {e.args[0]} you have.", code="too_many") from None
    except (KeyError, ValueError):
        raise ApiError("That pack art or purchase is not in your list any more.") from None
    v.commit()
    return {"counts": have}
