"""Extras toggles: which groups of 'not a real set' cards Find & Add shows (see cardvault/setkinds.py), and the table in Card tools to check what was sorted where."""
import json

from .. import setkinds
from .registry import api
from .service import ApiError


def _load(svc, key, default):
    raw = svc.pget(f"{key}:{svc.vault.game}")
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        v = None
    return v if isinstance(v, type(default)) else default


def hidden_kinds(svc):
    return set(_load(svc, "hidden_kinds", []))


def overrides(svc):
    return _load(svc, "kind_overrides", {})


def kind_map(svc):
    """{set id: kind} for every set of the open game (only sets that belong to a kind)."""
    ov = overrides(svc)
    out = {}
    for r in svc.vault.conn.execute("SELECT id, name, serie FROM sets"):
        k = setkinds.effective_kind(svc.vault.game, r, ov)
        if k:
            out[str(r["id"])] = k
    return out


@api("setkinds.state", quiet=True)
def state(svc):
    v = svc.vault
    ov = overrides(svc)
    hide = hidden_kinds(svc)
    counts = {r[0]: r[1] for r in v.conn.execute("SELECT set_id, COUNT(*) FROM cards GROUP BY set_id")}
    owned = v.owned_by_set()
    kinds = {}
    normal = []
    for r in v.conn.execute("SELECT id, name, serie, release_date FROM sets ORDER BY release_date DESC, name"):
        k = setkinds.effective_kind(svc.vault.game, r, ov)
        row = {"id": str(r["id"]), "name": r["name"], "serie": r["serie"] or "", "cards": counts.get(r["id"], 0), "owned": owned.get(r["id"], 0), "auto": setkinds.kind_of(svc.vault.game, r["id"], r["name"], r["serie"] or ""), "override": ov.get(str(r["id"]), "")}
        (kinds.setdefault(k, []) if k else normal).append(row)
    out = []
    for key, (label, help_) in setkinds.KINDS.items():
        sets = kinds.get(key, [])
        if not sets:
            continue
        out.append({"key": key, "label": label, "help": help_, "hidden": key in hide, "sets": sets, "setCount": len(sets), "cardCount": sum(s["cards"] for s in sets), "ownedCount": sum(s["owned"] for s in sets)})
    return {"kinds": out, "labels": {k: v_[0] for k, v_ in setkinds.KINDS.items()}, "normal": [{"id": s["id"], "name": s["name"], "cards": s["cards"]} for s in normal], "game": svc.vault.game}


@api("setkinds.setHidden", mutates=True)
def set_hidden(svc, key, hidden=True):
    if key not in setkinds.KINDS:
        raise ApiError("Unknown group.")
    cur = hidden_kinds(svc)
    (cur.add if hidden else cur.discard)(key)
    svc.pset(f"hidden_kinds:{svc.vault.game}", json.dumps(sorted(cur)))
    return state(svc)


@api("setkinds.override", mutates=True)
def override(svc, set_id, kind=""):
    """kind '' = automatic, 'main' = treat as a normal set, or any key of the groups."""
    if kind not in ("", "main") and kind not in setkinds.KINDS:
        raise ApiError("Unknown group.")
    ov = overrides(svc)
    if kind:
        ov[str(set_id)] = kind
    else:
        ov.pop(str(set_id), None)
    svc.pset(f"kind_overrides:{svc.vault.game}", json.dumps(ov))
    return state(svc)
