"""The EXTENDED master set: the extra cards that belong to a set but are not part of its normal list - stamped cards, Cosmos Holo cards, staff and pre-release promos, the cards found only in check-lane
blisters, 3-pack blisters or "Knock Out" collections.  They live in promo sets of their own in the card list, with the set they belong to named in the card's name or in the brackets after it, e.g.
"Pikachu (Prismatic Evolutions Stamp)" or "Eevee (Staff Prerelease Prismatic Evolutions)".  This reads that link; nothing is guessed from artwork."""
import re

from .sealedpromo import _promo_cards, _seq

KINDS = (("cosmos", "Cosmos Holo"), ("staff", "Staff promo"), ("prerelease", "Prerelease promo"), ("pre-release", "Prerelease promo"), ("stamp", "Stamped"), ("league", "League promo"),
         ("prize pack", "Prize Pack"), ("blister", "Blister promo"), ("check lane", "Check lane promo"), ("knock out", "Knock Out collection"), ("exclusive", "Exclusive promo"))


# what a person chooses between in the extended master set (several labels can fall under one choice)
GROUPS = (("prerelease", "Pre-release & staff promos"), ("boxes", "Box, blister & check-lane promos"), ("cosmos", "Cosmos Holo"), ("stamped", "Stamped cards"), ("league", "League & Prize Pack promos"))
_GROUP_OF = {"Prerelease promo": "prerelease", "Staff promo": "prerelease", "Blister promo": "boxes", "Check lane promo": "boxes", "Knock Out collection": "boxes", "Exclusive promo": "boxes",
             "Cosmos Holo": "cosmos", "Stamped": "stamped", "League promo": "league", "Prize Pack": "league"}


def group_of(label):
    return _GROUP_OF.get(label, "other")


def _label(text):
    low = (text or "").lower()
    for key, lab in KINDS:
        if key in low:
            return lab
    return "Promo"


_NUM = re.compile(r"-\s*(\d+)[a-z]?\s*/\s*(\d+)")


def _by_number(svc):
    """{set id: [(card id, name, number, label)]} for promos that carry their parent card's number - "Mothim - 42/100 (Prerelease)" is card 42 of the 100-card set that has a Mothim at 42.  This is
    how pre-release, staff, blister and league promos find their set when the set's name is not written on them.  Built once per card list."""
    v = svc.vault
    stamp = id(v.card_index())
    hit = getattr(svc, "_extra_num", None)
    if hit and hit[0] == stamp:
        return hit[1]
    totals = {}
    for r in v.conn.execute("SELECT id, official, total FROM sets"):
        for t in {r["official"], r["total"]}:
            if t:
                totals.setdefault(int(t), []).append(r["id"])
    out = {}
    for cid, nm, sname, no, base, parens in _promo_cards(svc):
        m = _NUM.search(nm)
        if not m or not base:
            continue
        n, t = int(m.group(1)), int(m.group(2))
        for sid in totals.get(t, []):
            ok = v.conn.execute("SELECT 1 FROM cards WHERE set_id=? AND lower(name) LIKE ? AND CAST(local_id AS INTEGER)=? LIMIT 1", (sid, base + "%", n)).fetchone()
            if ok and not cid.startswith(str(sid) + "-"):
                out.setdefault(sid, []).append((cid, nm, no, _label(" ".join(parens) + " " + nm + " " + sname)))
                break
    svc._extra_num = (stamp, out)
    return out


def extras_for_set(svc, set_row):
    """[(card id, name, number, label)] of the promo / stamped cards that name this set."""
    name_seq = _seq(set_row["name"])
    # a set name with a one-word generic remainder (e.g. "SV: Base") is too vague to match on: need a distinctive phrase
    phrase = " ".join(w for w in name_seq if w not in ("sv", "swsh", "sm", "xy", "bw", "hgss", "dp", "ex", "the", "of", "and"))
    if len(phrase) < 5:
        return []
    out = list(_by_number(svc).get(set_row["id"], []))
    have = {o[0] for o in out}
    for cid, nm, sname, no, _base, parens in _promo_cards(svc):
        if cid in have:
            continue
        if cid.startswith(str(set_row["id"]) + "-") and sname == set_row["name"]:
            continue                                                    # a card of the set itself is not an extra
        hay = " ".join(_seq(" ".join(parens))) or ""
        full = " ".join(_seq(nm))
        text = " " + hay + " | " + full + " "
        kind_word = any(k in (" ".join(parens) + " " + nm).lower() for k, _ in KINDS if k != "exclusive")
        full_name = " ".join(name_seq)
        ERA = ("sv", "swsh", "sm", "xy", "bw", "hgss", "dp", "ex", "sun", "moon", "sword", "shield", "scarlet", "violet")

        def found(ph):
            start = 0
            while True:
                i = text.find(" " + ph + " ", start)
                if i < 0:
                    return False
                before = text[:i].split()[-1:] or [""]
                if before[0] not in ERA or ph.split()[0] in ERA:
                    return True                                       # "SM Base Set" is not "Base Set"
                start = i + 1
        hit = found(full_name) or (kind_word and found(phrase))
        if hit:
            out.append((cid, nm, no, _label(" ".join(parens) + " " + nm)))
    return out
