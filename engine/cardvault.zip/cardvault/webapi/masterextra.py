"""The EXTENDED master set: the extra cards that belong to a set but are not part of its normal list - stamped cards, Cosmos Holo cards, staff and pre-release promos, the cards found only in check-lane
blisters, 3-pack blisters or "Knock Out" collections.  They live in promo sets of their own in the card list, with the set they belong to named in the card's name or in the brackets after it, e.g.
"Pikachu (Prismatic Evolutions Stamp)" or "Eevee (Staff Prerelease Prismatic Evolutions)".  This reads that link; nothing is guessed from artwork."""
import re

from .sealedpromo import _promo_cards, _seq

KINDS = (("pattern", "Pattern printing"), ("cosmos", "Cosmos Holo"), ("staff", "Staff promo"), ("prerelease", "Prerelease promo"), ("pre-release", "Prerelease promo"), ("stamp", "Stamped"), ("league", "League promo"),
         ("prize pack", "Prize Pack"), ("blister", "Blister promo"), ("check lane", "Check lane promo"), ("knock out", "Knock Out collection"), ("exclusive", "Exclusive promo"))


# what a person chooses between in the extended master set (several labels can fall under one choice)
GROUPS = (("prerelease", "Pre-release & staff promos"), ("boxes", "Box, blister & check-lane promos"), ("cosmos", "Cosmos Holo"), ("stamped", "Stamped cards"), ("league", "League & Prize Pack promos"))
PATTERNS = "patterns"                       # Poke Ball / Master Ball / Energy symbol... pattern printings: their OWN checkmark (hundreds per set), never part of 'all of them'
_GROUP_OF = {"Pattern printing": PATTERNS, "Prerelease promo": "prerelease", "Staff promo": "prerelease", "Blister promo": "boxes", "Check lane promo": "boxes", "Knock Out collection": "boxes", "Exclusive promo": "boxes",
             "Cosmos Holo": "cosmos", "Stamped": "stamped", "League promo": "league", "Prize Pack": "league"}


def group_of(label):
    return _GROUP_OF.get(label, "other")


def _label(text):
    low = (text or "").lower()
    for key, lab in KINDS:
        if key in low:
            return lab
    return "Promo"


_NUM = re.compile(r"-\s*(\d+)[a-z]?\s*/\s*(\d+)")


_UP = str.maketrans("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")


def _names_at(v, sids):
    """{(set id, number): [lower-cased names]} for the cards of these sets, read in one go (each promo asked the card list on its own: thousands of lookups, over a second)."""
    out, sids = {}, list(sids)
    for i in range(0, len(sids), 500):
        chunk = sids[i:i + 500]
        for sid, n, nm in v.conn.execute(f"SELECT set_id, CAST(local_id AS INTEGER), lower(name) FROM cards WHERE set_id IN ({','.join('?' * len(chunk))})", chunk):
            out.setdefault((sid, n), []).append(nm or "")
    return out


def _starts(names, base, v, sid, n):
    """Does one of these names begin with base - the same test as SQL's  lower(name) LIKE 'base%'  (which ignores case for A-Z only)."""
    if "%" in base or "_" in base:                             # (a wildcard in the name itself: asked the card list exactly as before)
        return v.conn.execute("SELECT 1 FROM cards WHERE set_id=? AND lower(name) LIKE ? AND CAST(local_id AS INTEGER)=? LIMIT 1", (sid, base + "%", n)).fetchone() is not None
    b = base.translate(_UP)
    return any(nm.translate(_UP).startswith(b) for nm in names)


def _by_number(svc):
    """{set id: [(card id, name, number, label)]} for promos that carry their parent card's number - "Mothim - 42/100 (Prerelease)" is card 42 of the 100-card set that has a Mothim at 42.  This is
    how pre-release, staff, blister and league promos find their set when the set's name is not written on them.  Built once per card list."""
    v = svc.vault
    stamp = id(v.card_index())
    hit = getattr(svc, "_extra_num", None)
    if hit and hit[0] == stamp:
        return hit[1]
    totals = {}
    for r in v.conn.execute("SELECT id, official, total FROM sets"):
        for t in {r["official"], r["total"]}:
            if t:
                totals.setdefault(int(t), []).append(r["id"])
    out = {}
    todo = []
    for cid, nm, sname, no, base, parens in _promo_cards(svc):
        m = _NUM.search(nm)
        if m and base:
            todo.append((cid, nm, sname, no, base, parens, int(m.group(1)), int(m.group(2))))
    names = _names_at(v, {sid for *_, t in todo for sid in totals.get(t, [])})
    for cid, nm, sname, no, base, parens, n, t in todo:
        for sid in totals.get(t, []):
            ok = _starts(names.get((sid, n), ()), base, v, sid, n)
            if ok and not cid.startswith(str(sid) + "-"):
                out.setdefault(sid, []).append((cid, nm, no, _label(" ".join(parens) + " " + nm + " " + sname)))
                break
    svc._extra_num = (stamp, out)
    return out


_GENERIC = ("sv", "swsh", "sm", "xy", "bw", "hgss", "dp", "ex", "the", "of", "and")
_ERA = ("sv", "swsh", "sm", "xy", "bw", "hgss", "dp", "ex", "sun", "moon", "sword", "shield", "scarlet", "violet")


def _all(svc):
    """{set id: [(card id, name, number, label)]} for every set at once.  Each promo card is looked up ONCE: every run of words in its name / brackets is checked against the set names, instead of every
    set scanning every promo (that took seconds).  Built once per card list and kept."""
    v = svc.vault
    stamp = id(v.card_index())
    hit = getattr(svc, "_extra_all", None)
    if hit and hit[0] == stamp:
        return hit[1]
    full_map, phrase_map = {}, {}
    for r in v.conn.execute("SELECT id, name FROM sets"):
        seq = _seq(r["name"])
        phrase = tuple(w for w in seq if w not in _GENERIC)
        if len(" ".join(phrase)) < 5:
            continue
        full_map.setdefault(tuple(seq), []).append((r["id"], r["name"]))
        phrase_map.setdefault(phrase, []).append((r["id"], r["name"]))
    out = {sid: list(items) for sid, items in _by_number(svc).items()}
    seen = {(sid, o[0]) for sid, items in out.items() for o in items}
    for cid, nm, sname, no, _base, parens in _promo_cards(svc):
        hay = _seq(" ".join(parens))
        full = _seq(nm)
        toks = hay + ["|"] + full
        kind_word = any(k in (" ".join(parens) + " " + nm).lower() for k, _ in KINDS if k != "exclusive")
        label = None
        for i in range(len(toks)):
            if toks[i] == "|":
                continue
            for n in range(1, 9):
                seg = tuple(toks[i:i + n])
                if "|" in seg:
                    break
                for table, need_kind in ((full_map, False), (phrase_map, True)):
                    for sid, sname2 in table.get(seg, ()):
                        if need_kind and not kind_word:
                            continue
                        before = toks[i - 1] if i > 0 else ""
                        if before in _ERA and seg[0] not in _ERA:
                            continue                                    # "SM Base Set" is not "Base Set"
                        if cid.startswith(str(sid) + "-") and sname == sname2:
                            continue                                    # a card of the set itself is not an extra
                        if (sid, cid) in seen:
                            continue
                        seen.add((sid, cid))
                        label = label or _label(" ".join(parens) + " " + nm)
                        out.setdefault(sid, []).append((cid, nm, no, label))
    svc._extra_all = (stamp, out)
    return out


def extras_for_set(svc, set_row):
    """[(card id, name, number, label)] of the promo / stamped cards that name this set."""
    return list(_all(svc).get(set_row["id"], []))
