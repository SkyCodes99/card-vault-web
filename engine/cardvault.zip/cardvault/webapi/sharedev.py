"""Share pages and Dev tools (categories, hand corrections, training)."""
import json

from .. import admin, share, taxonomy, training
from .cards import img, with_undo
from .registry import api
from .service import ApiError

PERM_TEXT = [
    ("show_owned", "Show which cards I own"), ("show_missing", "Show which cards I'm missing"), ("show_progress", "Show progress (owned / total / percent)"),
    ("show_images", "Include card pictures"), ("show_quantities", "Show how many copies I have"), ("show_conditions", "Show variants, conditions and grades"),
    ("show_prices", "Show market price of each card"), ("show_total_value", "Show the total market value"),
    ("show_purchase_prices", "Show what I paid  (private by default)"), ("show_notes", "Show my notes  (private by default)"),
]


# ------------------------------------------------------------------------------------------------ share
@api("share.options")
def share_options(svc):
    v = svc.vault
    return {"kinds": [[k, t] for k, t in share.KINDS.items()], "perms": PERM_TEXT, "defaults": share.DEFAULT_PERMS,
            "sets": [{"id": s["id"], "name": s["name"]} for s in v.sets()], "lists": [{"id": c["id"], "name": c["name"]} for c in v.checklists()],
            "groups": [{"id": g.id, "label": g.label} for g in taxonomy.groups()]}


@api("share.list")
def share_list(svc):
    out = []
    for s in svc.vault.shares():
        out.append({"id": s["id"], "title": s["title"], "kind": s["kind"], "kindLabel": share.KINDS.get(s["kind"], s["kind"]).split(" (")[0],
                    "scope": json.loads(s["scope"] or "{}"), "perms": share.merged_perms(json.loads(s["perms"] or "{}"))})
    return out


def _definition(d):
    k = d.get("kind", "collection")
    scope = {"set": {"set_id": d.get("setId")}, "checklist": {"checklist_id": d.get("listId")}, "group": {"group_id": d.get("groupId")}}.get(k, {})
    perms = dict(d.get("perms") or {})
    return {"title": (d.get("title") or "").strip() or "My collection", "kind": k, "scope": scope, "perms": perms, "expires_at": None}


@api("share.preview")
def share_preview(svc, definition):
    d = _definition(definition)
    try:
        payload = share.build_payload(svc.vault, d, with_images=False)
    except Exception as e:  # noqa: BLE001 - e.g. no checklist chosen yet
        return {"error": f"Nothing to preview yet ({e})."}
    perms = d["perms"]
    bits = [f"{len(payload['items']):,} card tiles"]
    if "progress" in payload:
        pr = payload["progress"]
        bits.append(f"progress {pr['percent']}% ({pr['owned']}/{pr['total']})")
    for key, text in (("show_images", "pictures"), ("show_quantities", "quantities"), ("show_conditions", "variants/conditions/grades"), ("show_prices", "card prices"),
                      ("show_total_value", f"total value (USD {payload.get('total_value_usd', 0):,.0f})"), ("show_purchase_prices", "prices you paid"), ("show_notes", "your notes")):
        if perms.get(key):
            bits.append(text)
    hidden = [t for k, t in (("show_quantities", "quantities"), ("show_prices", "prices"), ("show_purchase_prices", "prices paid"), ("show_notes", "notes")) if not perms.get(k)]
    return {"contains": bits, "hidden": hidden}


@api("share.save", mutates=True)
def share_save(svc, definition, id=None):
    d, v = _definition(definition), svc.vault
    if id:
        v.update_share(id, d["title"], d["scope"], d["perms"], d["expires_at"])
        return {"id": id}
    return {"id": v.create_share(d["title"], d["kind"], d["scope"], d["perms"], d["expires_at"])}


@api("share.delete", mutates=True)
def share_delete(svc, id):
    svc.vault.delete_share(id)
    return {"ok": True}


@api("share.exportHtml")
def share_export(svc, definition, path):
    svc.need_grant(path)
    d = _definition(definition)
    try:
        payload = share.build_payload(svc.vault, d, with_images=d["perms"].get("show_images", True))
        size = share.export_html(path, payload)
    except Exception as e:  # noqa: BLE001
        raise ApiError(f"Could not create the page: {e}")
    return {"mb": size / 1_000_000, "path": path}


# ------------------------------------------------------------------------------------------------ dev tools: categories
INDENT = {"ir": 1, "sir": 1, "gallery": 1, "tg": 2, "gg": 2, "art_alt": 1}


@api("dev.groups")
def dev_groups(svc):
    v = svc.vault
    counts = v.group_counts()
    by_section = {}
    for g in taxonomy.groups():
        sec = "art" if g.id in ("art", "ir", "sir", "gallery", "tg", "gg", "art_alt", "altart") else (g.parent or "art")
        by_section.setdefault(sec, []).append(g)
    titles = dict(taxonomy.SECTIONS)
    order = [s for s, _ in taxonomy.SECTIONS if s in by_section] + [s for s in by_section if s not in titles]
    out = []
    for sec in order:
        out.append({"section": {"art": "ART", "custom": "MY CATEGORIES"}.get(sec) or (titles.get(sec) or sec).upper(),
                    "groups": [{"id": g.id, "label": g.label, "count": counts.get(g.id, (0, 0))[1], "corrections": len(admin.overrides(v, ("group", g.id))),
                                "custom": taxonomy.custom_meta(g.id) is not None, "indent": INDENT.get(g.id, 0), "help": g.help} for g in by_section[sec]]})
    return {"sections": out, "corrections": len(admin.all_corrections(v)), "pokemon": svc.game.pokemon}


@api("dev.cards")
def dev_cards(svc, group, view="members", q="", set_id="", rarity="", sort="", edition="", series=None, set_ids=None):
    """edition ('tcg' physical / 'pocket' digital), series (eras) and set_ids narrow every list to those sets, so physical and digital cards never mix."""
    v = svc.vault
    from ..db import edition_of
    allowed = None
    if edition or series or set_ids:
        allowed = {s["id"] for s in v.sets() if (not edition or edition_of(s["serie"]) == edition) and (not series or (s["serie"] or "") in series) and (not set_ids or s["id"] in set_ids)}
    ref = ("group", group)
    over = admin.overrides(v, ref)
    members = admin.members(v, ref)
    mset = set(members)
    q = (q or "").strip()
    hint = ""
    if view == "add":
        if q or set_id or rarity or allowed is not None:
            if allowed is not None and not set_id:
                ids = [r[0] for sid in sorted(allowed) for r in v.query_cards(set_id=sid, text=q, rarity=rarity or None) if r[0] not in mset][:1500]
            else:
                ids = [r[0] for r in v.query_cards(set_id=set_id or None, text=q, rarity=rarity or None) if r[0] not in mset and (allowed is None or (v.card_light(r[0]) or {}).get("set_id") in allowed)][:1500]
            if sort == "art":                                       # cards whose picture runs to the card edge first (tools/score_promo_art.py measures promos)
                ids.sort(key=lambda i: -((v.card_light(i) or {}).get("art_score") or 0))
        else:
            ids, hint = [], "Search for a card or pick a set / rarity to find cards that are not in this category yet."
    elif view == "corr":
        ids = list(over)
        if allowed is not None:
            ids = [i for i in ids if (v.card_light(i) or {}).get("set_id") in allowed]
        if q:
            ids = [i for i in ids if q.lower() in ((v.card_light(i) or {}).get("name", "") + " " + str((v.card_light(i) or {}).get("local_id", ""))).lower()]
        if not ids:
            hint = "No hand corrections in this category yet."
    else:
        ids = members
        if allowed is not None:
            ids = [i for i in ids if (v.card_light(i) or {}).get("set_id") in allowed]
        if q:
            ids = [i for i in ids if q.lower() in (v.card_light(i)["name"] + " " + (v.card_light(i)["set_name"] or "") + " " + str(v.card_light(i)["local_id"])).lower()]
        if not ids:
            hint = "This category is empty."
    rows = []
    for cid in ids[:2500]:
        c = v.card_light(cid)
        if c:
            rows.append({"id": cid, "name": c["name"], "sub": f"{c['set_name']} · {c['local_id']}", "img": img(cid, c["set_id"]), "pill": {admin.ADD: "ADDED", admin.REMOVE: "REMOVED"}.get(over.get(cid), "")})
    return {"rows": rows, "total": len(ids), "members": len(members), "corrections": len(over), "hint": hint}


@api("dev.act", mutates=True)
def dev_act(svc, group, ids, what):
    if what not in ("add", "remove", "reset") or not ids:
        raise ApiError("Select one or more cards first.")
    v = svc.vault
    word = {"add": "Added", "remove": "Removed", "reset": "Reset"}[what]
    label = taxonomy.LABEL.get(group, group)

    def run():
        with v.action(f"{word} {len(ids)} card{'s' if len(ids) != 1 else ''} in '{label}'"):
            {"add": admin.add, "remove": admin.remove, "reset": admin.reset}[what](v, ("group", group), ids)
    out = with_undo(svc, run)
    v.invalidate_index()
    return out


@api("dev.clearAll", mutates=True)
def dev_clear(svc, group):
    v = svc.vault
    label = taxonomy.LABEL.get(group, group)

    def run():
        with v.action(f"Cleared corrections in '{label}'"):
            admin.clear_all(v, ("group", group))
    out = with_undo(svc, run)
    v.invalidate_index()
    return out


@api("dev.category.get")
def category_get(svc, key):
    r = next((x for x in svc.vault.custom_groups() if x["key"] == key), None)
    if not r:
        raise ApiError("category not found")
    return {"key": key, "name": r["label"], "section": r["section"], "help": r["help"] or "", "art": bool(r["counts_as_art"]), "rules": json.loads(r["rules"] or "{}")}


@api("dev.category.save", mutates=True)
def category_save(svc, name, section="custom", help="", art=False, rules=None, key=None):
    v = svc.vault
    if not name or not name.strip():
        raise ApiError("Please name the category.")
    rules = rules or {}

    def run():
        if key:
            v.update_custom_group(key, name.strip(), section, help.strip(), rules, bool(art))
            return {"key": key}
        return {"key": v.create_custom_group(name.strip(), section, help.strip(), rules, bool(art))}
    out = run()
    v.invalidate_index()
    return {"ok": True, **out}


@api("dev.category.delete", mutates=True)
def category_delete(svc, key):
    v = svc.vault
    name = taxonomy.LABEL.get(key, key)

    def run():
        with v.action(f"Deleted category '{name}'"):
            v.delete_custom_group(key)
    out = with_undo(svc, run)
    v.invalidate_index()
    return out


@api("dev.category.count")
def category_count(svc, rules):
    from .. import checklists
    if not (rules or {}).get("include"):
        return {"count": None}
    return {"count": len(checklists.match_ids(svc.vault, rules))}


@api("dev.file.export")
def file_export(svc, path):
    svc.need_grant(path)
    n_cat, n_cor = svc.vault.export_categories(path)
    return {"categories": n_cat, "corrected": n_cor, "game": svc.vault.game}


@api("dev.file.import", mutates=True)
def file_import(svc, path):
    svc.need_grant(path)
    try:
        n = svc.vault.import_categories(path)
    except (OSError, ValueError, KeyError) as e:
        raise ApiError(f"Could not read that file: {e}")
    svc.vault.invalidate_index()
    return {"added": n}


# ------------------------------------------------------------------------------------------------ training
@api("dev.training.summary")
def training_summary(svc):
    s = training.summary(svc.vault)
    return {**{k: v for k, v in s.items() if isinstance(v, (int, float, str, bool, type(None)))}, "corrections": len(admin.all_corrections(svc.vault)), "minEach": training.MIN_EACH}


@api("dev.training.reset", mutates=True)
def training_reset(svc):
    training.reset_threshold(svc.vault)
    return {"ok": True}

