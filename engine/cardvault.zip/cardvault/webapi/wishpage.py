"""The wishlist as a public page: view only (no script at all, nothing to click or send), grouped by label in priority order.
It holds names, numbers, pictures, the label names and - only if the owner ticks it - market prices and what each label costs to finish; never notes, quantities or what was paid, and only the
account's username (never an email).  Published through the same account-server pages as the other share links (sharepages._publish): a random link, refreshed in place, revoked at once."""
import html as H

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>%(title)s</title><style>
:root{color-scheme:light dark;--bg:#f7f3fb;--card:#fff;--ink:#241a36;--mute:#756a8c;--acc:#8a4fd1;--line:#e5dcf0}
@media(prefers-color-scheme:dark){:root{--bg:#150f22;--card:#211735;--ink:#efe9fb;--mute:#a79cc0;--line:#35294f}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}
header{padding:28px 20px;text-align:center;background:linear-gradient(135deg,#8a4fd1,#d14f9a);color:#fff}header h1{margin:0 0 4px;font-size:26px}header p{margin:0;opacity:.92}
main{max-width:1000px;margin:0 auto;padding:18px}h2{margin:22px 0 8px;font-size:18px;display:flex;flex-wrap:wrap;gap:6px 12px;align-items:baseline}h2 small{color:var(--mute);font-weight:400;font-size:13px}
.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px}.c{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px;display:flex;flex-direction:column;gap:3px}
.c img{width:100%%;aspect-ratio:63/88;object-fit:contain;border-radius:8px;background:var(--bg)}.n{font-weight:650}.s{color:var(--mute);font-size:12px}.v{font-weight:700}.k{color:var(--mute);font-size:11px}
footer{text-align:center;color:var(--mute);padding:22px;font-size:13px}.empty{color:var(--mute)}
</style></head><body><header><h1>%(title)s</h1><p>%(by)s</p></header><main>%(body)s</main><footer>View only &middot; Made with Collect Em All</footer></body></html>"""


def _money(x):
    return "$%.2f" % x


def _card(i, prices):
    e = H.escape
    pic = '<img loading="lazy" referrerpolicy="no-referrer" alt="%s" src="%s">' % (e(i["name"]), e(i["img"])) if i.get("img") else ""
    price = ""
    if prices and i["price"] is None and i["ask"]:
        price = '<div class="k">eBay asking price only - no true price yet</div>'
    elif prices and i["price"] is not None:
        price = '<div class="v">about %s</div>' % _money(i["price"]) + ('<div class="k">eBay asking price</div>' if i["ask"] else "")
    sub = e(i["set"]) + (" &middot; #" + e(i["number"]) if i["number"] else "")
    return '<div class="c">%s<div class="n">%s</div><div class="s">%s</div>%s</div>' % (pic, e(i["name"]), sub, price)


def render(view, title="", owner="", note="", prices=False):
    """`view` = wishlist.view(...) (group "label"); only the cards still wanted are shown.  -> the page as one HTML string."""
    e = H.escape
    title = (title or "").strip() or "My wishlist"
    parts, shown = [], 0
    if note:
        parts.append('<p>%s</p>' % e(note[:300]))
    for g in view["groups"]:
        its = [i for i in g["items"] if not i["owned"]]
        if not its:
            continue
        shown += len(its)
        todo = [i for i in its if i["price"] is not None]
        cost = (" &middot; about %s to finish" % _money(sum(i["price"] for i in todo))) if prices and todo else ""
        parts.append('<h2>%s <small>%d card%s%s</small></h2><div class="g">%s</div>' % (e(g["name"]), len(its), "" if len(its) == 1 else "s", cost, "".join(_card(i, prices) for i in its)))
    if not shown:
        parts.append('<p class="empty">Nothing on the wishlist right now.</p>')
    total = ""
    if prices:
        todo = [i for g in view["groups"] for i in g["items"] if not i["owned"] and i["price"] is not None]
        total = "About %s to get everything" % _money(sum(i["price"] for i in todo)) if todo else ""
    by = (e(owner) + "'s wishlist" if owner else "Wishlist") + (" &middot; " + total if total else "")
    return PAGE % {"title": e(title), "by": by, "body": "".join(parts)}
