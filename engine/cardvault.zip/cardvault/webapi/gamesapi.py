"""Games & downloads, price updates and the background art detection."""
import datetime
import os
import re
import shutil
import sqlite3

from .. import bulbapedia, catalogdb, games, runtime, sync
from ..db import game_dir
from .registry import api
from .service import ApiError


def folder_size(path):
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _db(svc, game_id):
    return os.path.join(game_dir(svc.cfg["data_dir"], game_id), "cards.db")


def _one(svc, game_id, sql):
    try:
        c = sqlite3.connect(_db(svc, game_id))
        r = c.execute(sql).fetchone()
        c.close()
        return r[0] if r else None
    except sqlite3.Error:
        return None


def refresh_after(svc):
    """The card database changed on disk: reopen the active game so every screen sees it."""
    svc.open_game(svc.vault.game)
    svc.save()


def reopen_if_closed(svc):
    """A card-list swap lets go of the open game first (a Windows file can't be replaced while it is open).  When the swap then fails, the game must come back - or the app is left without its collection
    until it is restarted."""
    v = svc.vault
    if v is not None and v.is_closed():
        svc.open_game(v.game)


# the jobs that keep the active game's card list open while they work: a swap waits for them (Windows refuses to replace a file that is in use)
HOLDS_LIST = ("games", "prices", "art")


def list_in_use(svc):
    return any(svc.jobs.running(kind) for kind in HOLDS_LIST)


def has_catalog(svc, game_id):
    return bool(_one(svc, game_id, "SELECT COUNT(*) FROM cards"))


def catalog_base(svc):
    """Where the ready-made card lists are published: next to the website (the account server), or beside the page in the browser."""
    from .. import carddata
    return carddata.bases(svc, "catalog")[0]


def install_any(svc, gdir, game_id, emit, cancel, release=None, built=""):
    """Download a game's card list from Card Data (or, only if that fails, the website's old copy).  `built`: the manifest's date for it (a new list is a new address)."""
    from .. import carddata
    last = None
    more = {"built": built} if built else {}
    for base in carddata.bases(svc, "catalog"):
        try:
            return catalogdb.install(gdir, base, game_id, emit, cancel, release=release, **more)
        except sync.Cancelled:
            raise
        except PermissionError:
            raise                                                           # the card list file is in use on this PC: another place would only meet the same wall
        except Exception as e:  # noqa: BLE001 - a place that can't answer (in the browser a refused request is not a RuntimeError) only means: try the next one
            last = e
    raise RuntimeError(str(last) if last else "The card list for this game isn't published yet.")


def ensure_job(svc, game_id, then_open=False, after=None):
    """Make sure a game's card list is on this device: downloads it from the site (seconds), or - if the site can't be reached - builds it from the source.  -> job id or None.
    after(ok): called once the download has ended (the sync uses it to bring that game's collection down)."""
    g = games.game_by_id(game_id)
    if not g.available or g.id != game_id:
        raise ApiError("That game isn't available yet.")
    if has_catalog(svc, game_id):
        return None
    gdir = game_dir(svc.cfg["data_dir"], game_id)

    def run(emit, cancel):
        try:
            n = install_any(svc, gdir, game_id, emit, cancel, release=_swapper(svc, game_id))
            return {"cards": n}
        except RuntimeError:
            provider = games.provider_for(game_id)
            if runtime.IN_BROWSER or not provider:
                raise
            provider.fetch_catalog(gdir, cancel, emit, None)             # the site doesn't have it (yet): build it from the source
            return {"cards": _one(svc, game_id, "SELECT COUNT(*) FROM cards") or 0}        # (counted from the new list's own file: the open collection's connection belongs to the engine's thread, not this one)

    def done(job):
        if job.state == "done" and (then_open or svc.vault.game == game_id):
            svc.open_game(game_id)
            svc.save()
        else:
            reopen_if_closed(svc)                                           # (a failed download may already have let go of the open game)
        if after is not None:
            try:
                after(job.state == "done")
            except Exception:  # noqa: BLE001 - never fail the download over what follows it
                pass
    return svc.jobs.start("games", f"Getting {g.name}", run, on_done=done, exclusive=False).id


def _swapper(svc, game_id):
    """The `release` for catalogdb.install.  The new card list replaces the old file ON the engine's own thread (a connection can only be closed on the thread that made it, and no screen can call in
    while the game is closed): the open game is closed, the file swapped, and the game opened again - also when the swap fails, so a refused swap never leaves the app without its collection.
    A failure is handed back as itself (the engine thread would turn it into a generic error, and 'the file is in use' must not be taken for 'this source failed')."""
    def release(swap):
        def go(s):
            active = s.vault is not None and s.vault.game == game_id
            if active:
                s.vault.close()
            try:
                swap()
                return None
            except Exception as e:  # noqa: BLE001
                return e
            finally:
                if active:
                    s.open_game(game_id)
        failed = svc.run(go)
        if failed is not None:
            raise failed
    return release


def refresh_catalogs(svc):
    """A newer card list is on the website (more pictures, corrected rarities...): fetch it for every game installed here, one at a time.
    Guests too: their collection is thrown away, but the card lists stay on the device between visits and would otherwise never change."""
    if svc.session is None and not getattr(svc, "guest", False):
        return None
    if list_in_use(svc):
        svc._more_catalogs = True                          # the price update / art detection / another download has the list open: look again at the next tick, not in twelve hours
        return None
    from .. import carddata
    base, m = carddata.first_manifest(svc, "catalog", catalogdb.manifest)
    if not m:
        return None
    svc._catalog_latest = m.get("built") or ""                 # (daily.health says so when no newer list has come for days)
    active = svc.vault.game if svc.vault is not None else ""
    from .. import runtime
    for gid, entry in sorted(m["games"].items(), key=lambda kv: kv[0] != active):          # the game you are looking at first
        if not has_catalog(svc, gid):
            continue
        if runtime.IN_BROWSER and gid != active:
            continue                                        # in the browser one big download freezes the page: only the game you are using is refreshed (others when you open them)
        gdir = game_dir(svc.cfg["data_dir"], gid)
        if (catalogdb.local_built(gdir) or "") >= entry.get("built", ""):
            continue

        def run(emit, cancel, gid=gid, gdir=gdir, built=entry.get("built", "")):
            n = install_any(svc, gdir, gid, emit, cancel, release=_swapper(svc, gid), built=built)
            return {"cards": n}

        def done(job, gid=gid):
            if job.state == "done" and svc.vault is not None and svc.vault.game == gid:
                svc.open_game(gid)
                svc.save()
            else:
                reopen_if_closed(svc)                           # (a swap that failed may already have let go of the open game: it must come back)
            if job.state == "done":                             # the next game that has a newer list follows at the next tick, not twelve hours later
                svc._more_catalogs = True
        return svc.jobs.start("games", f"Updating the {games.game_by_id(gid).name} card list", run, on_done=done).id
    return None


@api("games.ensure")
def games_ensure(svc, id):
    return {"job": ensure_job(svc, id)}


@api("games.list")
def games_list(svc):
    out = []
    for g in games.GAMES:
        gdir = game_dir(svc.cfg["data_dir"], g.id)
        installed = g.available and has_catalog(svc, g.id)
        d = {"id": g.id, "name": g.name, "source": g.source, "available": g.available and not (g.own and not installed), "note": g.note, "family": g.family, "installed": installed, "own": g.own,
             "active": g.id == svc.vault.game, "pokemon": g.pokemon, "comingSoon": g.coming_soon and not g.available}
        if installed:
            d.update(cards=_one(svc, g.id, "SELECT COUNT(*) FROM cards") or 0, gb=folder_size(gdir) / 1e9,
                     pricesUpdated=_one(svc, g.id, "SELECT value FROM meta WHERE key='prices_updated'") or "")
        out.append(d)
    return {"games": out, "credit": bulbapedia.CREDIT, "quality": svc.cfg.get("image_quality", "low"), "dataDir": svc.cfg["data_dir"]}


def _provider(game_id):
    p = games.provider_for(game_id)
    if not p:
        raise ApiError("That game can't be downloaded yet.")
    return p


@api("games.check")
def games_check(svc, id, quality="low"):
    provider, gdir = _provider(id), game_dir(svc.cfg["data_dir"], id)
    svc.cfg["image_quality"] = quality
    svc.save()

    def run(emit, cancel):
        provider.fetch_catalog(gdir, cancel, emit, None)
        return provider.estimate(gdir, quality)
    j = svc.jobs.start("games", f"Checking {games.game_by_id(id).name}", run, on_done=lambda job: refresh_after(svc) if job.state == "done" else None)
    return {"job": j.id}


@api("games.download")
def games_download(svc, id, quality="low", refresh_all=False, only_sets=None):
    provider, gdir = _provider(id), game_dir(svc.cfg["data_dir"], id)
    svc.cfg["image_quality"] = quality
    svc.save()

    def run(emit, cancel):
        if runtime.IN_BROWSER:           # the browser build uses a ready-made card list and shows pictures from the web
            n = install_any(svc, gdir, id, emit, cancel, release=_swapper(svc, id))
            return {"cards": n}
        try:                                                                    # the card list is a copy of Card Data, not something this PC builds
            install_any(svc, gdir, id, emit, cancel, release=_swapper(svc, id))
            provider.fetch_images(gdir, quality, cancel, emit)
            return provider.estimate(gdir, quality)
        except RuntimeError:
            pass                                                                # Card Data and the old copy are both unreachable: build it from the source as a last resort
        provider.fetch_catalog(gdir, cancel, emit, only_sets)
        provider.fetch_details(gdir, cancel, emit, refresh_all)
        provider.fetch_images(gdir, quality, cancel, emit)
        return provider.estimate(gdir, quality)
    j = svc.jobs.start("games", f"Downloading {games.game_by_id(id).name}", run, on_done=lambda job: refresh_after(svc))
    return {"job": j.id}


@api("games.setart")
def games_setart(svc, id="pokemon"):
    gdir = game_dir(svc.cfg["data_dir"], id)

    if runtime.IN_BROWSER:               # set pictures come straight from their web addresses
        return {"job": None, "message": "The website shows set logos and symbols straight from the web - there is nothing to download here."}

    def run(emit, cancel):
        n = sync.fetch_logos(gdir, cancel, emit)
        res = bulbapedia.fetch_set_art(gdir, cancel, emit) if id == "pokemon" else {"matched": n, "downloaded": n, "total_sets": n}
        if id.startswith("pokemon"):
            from .. import setimages
            extra = setimages.fetch_missing(gdir, cancel, emit)
            res["more"] = extra["found"]
            res["generated"] = setimages.make_all_generated(gdir)
        return res
    j = svc.jobs.start("games", "Set logos & symbols", run, on_done=lambda job: svc._exists.clear())
    return {"job": j.id}


@api("games.remove", mutates=True)
def games_remove(svc, id):
    if not isinstance(id, str) or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", id) or ".." in id:
        raise ValueError(f"not a game id: {id!r}")                  # (3.50.132) '..' or '' removed the whole data folder or every game
    was = id == svc.vault.game
    if was:
        svc.vault.close()
    shutil.rmtree(game_dir(svc.cfg["data_dir"], id), ignore_errors=True)
    if was:
        svc.open_game(id)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------ prices
def price_due(svc):
    if not svc.cfg.get("auto_prices", True):
        return False
    last = svc.vault.meta("prices_updated")
    if not last:
        return True
    try:
        t = datetime.datetime.strptime(last, "%Y-%m-%d %H:%M")
    except ValueError:
        return True
    return (datetime.datetime.now() - t).total_seconds() >= svc.cfg.get("price_interval_hours", 24) * 3600


def start_prices(svc, manual=False):
    v = svc.vault
    if svc.jobs.running("prices"):
        if manual:
            raise ApiError("Prices are already updating…")
        return None
    if v.card_count() == 0:
        if manual:
            raise ApiError("Download a game's cards first (Games tab).")
        return None
    if runtime.IN_BROWSER:                  # the browser's engine has no threads: asking for every owned card's price one by one froze every screen for minutes (4,000 cards = 229 s).  The card lists
        if manual:                          # and the once-a-day price file carry the prices - one download - so that is what the browser uses
            from . import dailyapi
            dailyapi.check_soon(svc)        # (in short steps, so the screens keep answering)
        return None
    if not manual and not price_due(svc):
        return None
    from .. import dailyprices
    if not manual and dailyprices.local_built(v.gdir):          # this game's prices come from the once-a-day update: no other price refreshing in between
        return None
    provider = games.provider_for(v.game)
    if not provider:
        return None
    gdir, prio = v.gdir, sorted(v.tracked_card_ids())
    state = {"recorded": False}

    def record(s):
        s.vault.invalidate_index()
        s.vault.record_price_history()
        s.vault.take_snapshot()
        from .dailyapi import _price_alerts
        _price_alerts(s)
        s.reload_state()
        s.bump("changed")

    def run(emit, cancel):
        def progress(text, done, total):
            emit(text, done, total)
            if total and prio and done >= len(prio) and not state["recorded"]:
                state["recorded"] = True
                svc.run(record)          # your own cards come first: save today's value as soon as they are in
        return provider.refresh_prices(gdir, cancel, progress, prio)
    return svc.jobs.start("prices", "Updating prices", run, on_done=lambda job: record(svc))


# ------------------------------------------------------------------------------------------------ art detection
def art_start(svc):
    if not svc.game.pokemon or svc.jobs.running("art") or runtime.IN_BROWSER:      # (the browser keeps no picture files to scan)
        return {"job": None}
    gdir, extra = svc.vault.gdir, list(svc.vault.card_tags().keys())

    def run(emit, cancel):
        from .. import arttools
        try:
            return arttools.compute_missing(gdir, extra_ids=extra)
        except Exception:  # noqa: BLE001 - art detection is a bonus; never break the app
            return 0

    def done(job):
        if job.result:
            svc.vault.invalidate_index()
            svc.bump("changed")
    j = svc.jobs.start("art", "Detecting art cards", run, on_done=done)
    return {"job": j.id}
