"""Search the whole catalog at once: every game that is installed on this device, in one list."""
import os
import sqlite3

from .. import games, raritytiers
from .. import games as _games_mod                         # (search_query has a 'games' argument of its own)
from ..db import eff_date_sql, game_dir, picture_url
from .registry import api


def _games(svc):
    """[(game id, name, path of its card list)] for every game that has cards here."""
    out = []
    for g in games.GAMES:
        if not g.available:
            continue
        p = os.path.join(game_dir(svc.cfg["data_dir"], g.id), "cards.db")
        if os.path.exists(p):
            out.append((g.id, g.name, p))
    return out


def _owned(svc, game_id, ids):
    if not ids:
        return {}
    v = svc.vault
    q = ",".join("?" * len(ids))
    try:
        rows = v.conn.execute(f"SELECT card_id, SUM(qty) FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND card_id IN ({q}) GROUP BY card_id", (v.user_id, game_id, *ids)).fetchall()
    except sqlite3.Error:
        return {}
    return {r[0]: int(r[1] or 0) for r in rows}


def _pocket_on(svc):
    """TCG Pocket is a digital game: its cards stay out of every search until the person turns it on (Settings > Show TCG Pocket)."""
    try:
        return bool(svc.cfg.get("show_pocket", False))
    except Exception:  # noqa: BLE001
        return False


_NO_POCKET = "(s.serie IS NULL OR lower(s.serie) NOT LIKE '%pocket%')"


def _sealed_hits(path, words, set_words=(), pmin=None, pmax=None, y0=None, y1=None, priced=""):
    """Sealed products of one game's list whose name, set or series holds every word typed.  [(id, name, set name, picture, price, released, kind, serie)]  (code cards / loose cards stay out)."""
    try:
        c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
        c.row_factory = sqlite3.Row
    except sqlite3.Error:
        return []
    try:
        where, args = ["name != ''"], {}
        for i, w in enumerate(words):
            where.append(f"(norm LIKE :w{i} OR lower(coalesce(set_name,'')) LIKE :w{i} OR lower(coalesce(serie,'')) LIKE :w{i})")
            args[f"w{i}"] = f"%{w}%"
        for i, w in enumerate(set_words):
            where.append(f"lower(coalesce(set_name,'')) LIKE :s{i}")
            args[f"s{i}"] = f"%{w}%"
        if pmin is not None:
            where.append("price_usd >= :pmin"); args["pmin"] = pmin
        if pmax is not None:
            where.append("price_usd <= :pmax"); args["pmax"] = pmax
        if y0 not in (None, ""):
            where.append("CAST(substr(released,1,4) AS INTEGER) >= :y0"); args["y0"] = int(y0)
        if y1 not in (None, ""):
            where.append("CAST(substr(released,1,4) AS INTEGER) BETWEEN 1 AND :y1"); args["y1"] = int(y1)
        if priced == "yes":
            where.append("price_usd IS NOT NULL AND price_usd > 0")
        elif priced == "no":
            where.append("(price_usd IS NULL OR price_usd <= 0)")
        where.append("coalesce(kind,'') NOT IN ('Code card','Loose card / energy')")
        return c.execute("SELECT id, name, set_name, image_base, price_usd, released, kind, serie, norm FROM sealed_products WHERE " + " AND ".join(where) + " LIMIT 1500", args).fetchall()
    except sqlite3.Error:
        return []                                                 # a game with no sealed list yet
    finally:
        c.close()


@api("search.global", quiet=True)
def search_global(svc, q="", game="", rarity="", owned="", limit=60, what=""):
    """-> {"results": [...], "games": [{id, name, n}], "missing": [names of games not downloaded here]}.  One card list per game: the whole catalog, not only the open game."""
    from .cards import img
    q = (q or "").strip()
    here = _games(svc)
    from . import searchindex
    if len(q) >= 2 and searchindex.installed(svc):                            # the shared index: every game, installed here or not
        try:
            r = searchindex.query(svc, q, [game] if game else None, rarity, "", owned, None, None, "relevance", min(400, max(30, int(limit) * 4)), 0, None, None, "",
                                  (["cards", "misc"] if what == "cards" else ["sealed"] if what == "sealed" else None), "", pocket=_pocket_on(svc))   # None = everything: cards, sealed AND the toy / figure / accessory lists ('misc')
            return {"results": r["results"], "games": [{"id": g["id"], "name": g["name"], "n": g["n"]} for g in r["games"] if g["n"] or not q], "missing": []}
        except Exception:  # noqa: BLE001
            import traceback
            traceback.print_exc()
    out = {"results": [], "games": [], "missing": [g.name for g in games.GAMES if g.available and g.id not in {x[0] for x in here}]}
    if len(q) < 2:
        out["games"] = [{"id": gid, "name": name, "n": 0} for gid, name, _ in here]
        return out
    words = [w for w in q.lower().replace("#", " ").split() if w]
    for gid, name, path in here:
        if game and gid != game:
            continue
        try:
            c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
        except sqlite3.Error:
            continue
        try:
            where, args = [], []
            for w in words:
                where.append("(lower(c.name) LIKE ? OR lower(c.local_id) LIKE ? OR lower(s.name) LIKE ? OR lower(c.name_ja) LIKE ? OR lower(c.name_en) LIKE ?)")
                args += [f"%{w}%"] * 5
            if rarity:
                where.append("lower(coalesce(c.rarity,'')) LIKE ?")
                args.append(f"%{rarity.lower()}%")
            if not _pocket_on(svc):
                where.append(_NO_POCKET)
            if what == "sealed":
                where.append("0")                                  # sealed only: no cards from this game
            rows = c.execute(
                "SELECT c.id, c.set_id, c.name, c.local_id, c.rarity, c.image_base, s.name, c.price_usd FROM cards c JOIN sets s ON s.id=c.set_id WHERE " + " AND ".join(where) +
                " ORDER BY (lower(c.name) = ?) DESC, (lower(c.name) LIKE ?) DESC, s.release_date DESC, c.sort_key LIMIT 200", (*args, q.lower(), q.lower() + "%")).fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            c.close()
        have = _owned(svc, gid, [r[0] for r in rows])
        n = 0
        for cid, sid, cname, lid, rar, base, sname, usd in rows:
            qty = have.get(cid, 0)
            if owned == "yes" and not qty:
                continue
            if owned == "no" and qty:
                continue
            n += 1
            if len([r for r in out["results"] if r["game"] == gid]) < limit:
                if gid == svc.vault.game:
                    pic = img(cid, sid)
                elif base:
                    pic = picture_url(base, "low") if gid.startswith("pokemon") else base
                else:
                    pic = ""
                out["results"].append({"game": gid, "gameName": name, "id": cid, "set": sname, "name": cname, "number": lid, "rarity": rar or "", "img": pic, "owned": qty, "price": usd})
        if what != "cards" and not rarity and owned != "yes":
            first = next((i for i, x in enumerate(out["results"]) if x["game"] == gid), len(out["results"]))          # products go at the top of their game's group (a few of them, so cards still show)
            for k, r in enumerate(_sealed_hits(path, words)):
                n += 1
                if k < 12:
                    base = r["image_base"] or ""
                    out["results"].insert(first + k, {"game": gid, "gameName": name, "id": r["id"], "type": "sealed", "set": r["set_name"] or "", "name": r["name"], "number": "", "rarity": r["kind"] or "Sealed product",
                                                      "img": base.replace("_200w", "_400w"), "owned": 0, "price": r["price_usd"]})
        out["games"].append({"id": gid, "name": name, "n": n})
    return out


# ---- the full search page: pick one game, several, or all; filter and sort the same way whichever you pick
_SORT_SQL = {
    "relevance": "(lower(c.name) = :q) DESC, (lower(c.name) LIKE :qs) DESC, {ed} DESC, c.sort_key",
    "newest": "{ed} DESC, c.sort_key",
    "oldest": "({ed} IS NULL), {ed} ASC, c.sort_key",
    "price": "COALESCE(c.price_usd, -1) DESC, c.name",
    "priceasc": "(c.price_usd IS NULL), c.price_usd ASC, c.name",
    "name": "c.name COLLATE NOCASE, s.release_date DESC",
    "namez": "c.name COLLATE NOCASE DESC, s.release_date DESC",
    "set": "s.name COLLATE NOCASE, c.sort_key",
    "rarity": "(c.rarity IS NULL OR c.rarity=''), c.rarity COLLATE NOCASE, c.name COLLATE NOCASE",
}
_PER_GAME = 3000


def _dn(d):
    try:
        return int(str(d or "0").replace("-", "")[:8] or 0)
    except ValueError:
        return 0


def _sort_key(sort):
    """The Python twin of the SQL ordering, used to merge the per-game lists into one."""
    return {
        "relevance": lambda r: (r["_rel"], -_dn(r["_date"]), r["name"].lower()),
        "newest": lambda r: (-_dn(r["_date"]), r["name"].lower()),
        "oldest": lambda r: (_dn(r["_date"]), r["name"].lower()),
        "price": lambda r: (-(r["price"] if r["price"] is not None else -1), r["name"].lower()),
        "priceasc": lambda r: (r["price"] is None, r["price"] or 0, r["name"].lower()),
        "name": lambda r: (r["name"].lower(), -_dn(r["_date"])),
        "set": lambda r: (r["set"].lower(), r["name"].lower()),
        "rarity": lambda r: (not r["rarity"], r["rarity"].lower(), r["name"].lower()),
    }.get(sort) or (lambda r: (r["name"].lower(),))


def _asks_something(filters, ranges):
    """False for a search that was given nothing to look for (no words, no filter, no range): it answers with the empty page instead of listing every card.
    `filters` are the words and choices (empty = not used), `ranges` the numbers (None / "" = not used; 0 is a real price)."""
    return any(filters) or any(r not in (None, "") for r in ranges)


@api("search.query", quiet=True)
def search_query(svc, q="", games=None, rarity="", set_text="", artist="", owned="", price_min=None, price_max=None, sort="relevance", limit=120, offset=0, year_min=None, year_max=None, priced="", kinds=None, ctype="", facets=None, tier=""):
    """Search the card lists of the games you choose (none chosen = every game on this device).  owned: '' | 'yes' | 'no' | 'wish'.  kinds: which sorts of thing to look for - "cards", "sealed" (none chosen = both).
    -> {results, total, games:[{id,name,n}], rarities:[{name,n}], capped}   (sealed products come back with type "sealed")"""
    from .cards import img
    v = svc.vault
    here = _games(svc)
    want = [g for g in (games or []) if isinstance(g, str)]
    out = {"results": [], "total": 0, "games": [{"id": gid, "name": name, "n": 0, "family": _games_mod.game_by_id(gid).family, "installed": True} for gid, name, _ in here], "rarities": [], "capped": False, "types": [], "typeLabel": "Type", "single": "",
           "missing": [g.name for g in games_mod().GAMES if g.available and g.id not in {x[0] for x in here}]}
    q = (q or "").strip()
    price_min = None if price_min in (None, "") else float(price_min)
    price_max = None if price_max in (None, "") else float(price_max)
    facets = {str(k): [str(x) for x in v if str(x).strip()] for k, v in (facets or {}).items() if isinstance(v, (list, tuple)) and v} if isinstance(facets, dict) else {}
    tier = raritytiers.valid(tier)
    if not _asks_something((q, rarity, ctype, set_text, artist, owned, priced, facets, tier), (year_min, year_max, price_min, price_max)):
        return out
    from ..db import alias_text
    q = alias_text(q)
    if not artist and not facets:                                            # (a game's own filters - attribute, trait, printing... - are read from its own list, not the shared index)
        from . import searchindex
        if searchindex.installed(svc):                                       # the shared index covers every game, installed here or not
            try:
                return searchindex.query(svc, q, games, rarity, set_text, owned, price_min, price_max, sort, limit, offset, year_min, year_max, priced, kinds, ctype, pocket=_pocket_on(svc), tier=tier)
            except Exception:  # noqa: BLE001 - a damaged index must never break search: fall back to the lists on this device
                import traceback
                traceback.print_exc()
    words = [w for w in q.lower().replace("#", " ").split() if w]
    rows_all, rar_count, per_game = [], {}, {}
    kinds = {k for k in (kinds or []) if k in ("cards", "sealed", "misc")} or {"cards", "sealed", "misc"}
    pocket = _pocket_on(svc)
    sealed_have = {}
    try:
        from .listsealed import _owned as _sealed_owned
        sealed_have = _sealed_owned(svc)
    except Exception:  # noqa: BLE001
        sealed_have = {}
    for gid, name, path in here:
        if want and gid not in want:
            continue
        if "sealed" in kinds and not rarity and not artist and not facets and owned != "wish":
            n_s = 0
            for r in _sealed_hits(path, words, (set_text or "").lower().split(), price_min, price_max, year_min, year_max, priced):
                qty = sealed_have.get(r["norm"] or "", 0) if gid == v.game else 0
                if owned == "yes" and not qty or owned == "no" and qty:
                    continue
                nm = r["name"] or ""
                rel = (0 if nm.lower() == q.lower() else 1 if nm.lower().startswith(q.lower()) else 2) if q else 2
                rows_all.append({"game": gid, "gameName": name, "id": r["id"], "type": "sealed", "set": r["set_name"] or "", "name": nm, "number": "", "rarity": r["kind"] or "Sealed product",
                                 "img": (r["image_base"] or "").replace("_200w", "_400w"), "owned": qty, "wish": False, "price": r["price_usd"], "_rel": rel, "_date": r["released"] or ""})
                n_s += 1
            per_game[gid] = per_game.get(gid, 0) + n_s
        if ("misc" if _games_mod.is_misc(gid) else "cards") not in kinds:           # a toy / figure / plush list is 'misc', every card game is 'cards'
            continue
        try:
            c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
            c.row_factory = sqlite3.Row
        except sqlite3.Error:
            continue
        try:
            where, args = [], {}
            if not pocket:
                where.append(_NO_POCKET)
            for i, w in enumerate(words):
                where.append(f"(lower(c.name) LIKE :w{i} OR lower(c.local_id) LIKE :w{i} OR lower(s.name) LIKE :w{i} OR lower(c.name_ja) LIKE :w{i} OR lower(c.name_en) LIKE :w{i} OR lower(coalesce(c.illustrator,'')) LIKE :w{i})")
                args[f"w{i}"] = f"%{w}%"
            if rarity:
                where.append("lower(coalesce(c.rarity,'')) LIKE :rar")
                args["rar"] = f"%{rarity.lower()}%"
            if ctype:
                where.append("lower(coalesce(c.types,'')) LIKE :ct")
                args["ct"] = f"%{ctype.lower()}%"
            if tier:
                where.append(raritytiers.tier_case("c.rarity") + " = :tier")
                args["tier"] = tier
            for fi, (fk, fvals) in enumerate(facets.items()):                    # the game's own ways of grouping: every chosen group must match, any of its chosen values will do
                names = ",".join(f":f{fi}_{j}" for j in range(len(fvals)))
                for j, fv in enumerate(fvals):
                    args[f"f{fi}_{j}"] = fv
                if fk == "category":
                    where.append(f"c.category IN ({names})")
                else:
                    args[f"fk{fi}"] = fk
                    where.append(f"c.id IN (SELECT card_id FROM card_facets WHERE facet=:fk{fi} AND value IN ({names}))")
            for i, tok in enumerate((set_text or "").lower().split()):
                where.append(f"lower(s.name) LIKE :st{i}")
                args[f"st{i}"] = f"%{tok}%"
            for i, tok in enumerate((artist or "").lower().split()):
                where.append(f"lower(coalesce(c.illustrator,'')) LIKE :ar{i}")
                args[f"ar{i}"] = f"%{tok}%"
            if price_min is not None:
                where.append("c.price_usd >= :pmin")
                args["pmin"] = price_min
            if price_max is not None:
                where.append("c.price_usd <= :pmax")
                args["pmax"] = price_max
            if year_min not in (None, ""):
                where.append("CAST(substr(s.release_date,1,4) AS INTEGER) >= :y0")
                args["y0"] = int(year_min)
            if year_max not in (None, ""):
                where.append("CAST(substr(s.release_date,1,4) AS INTEGER) BETWEEN 1 AND :y1")
                args["y1"] = int(year_max)
            if priced == "yes":
                where.append("c.price_usd IS NOT NULL AND c.price_usd > 0")
            elif priced == "no":
                where.append("(c.price_usd IS NULL OR c.price_usd <= 0)")
            has_era = any(r[1] == "era_hint" for r in c.execute("PRAGMA table_info(cards)"))
            order = (_SORT_SQL.get(sort) or _SORT_SQL["relevance"]).replace("{ed}", eff_date_sql(has_era))
            if (sort or "relevance") == "relevance":
                args["q"] = q.lower()
                args["qs"] = q.lower() + "%"
            sql = ("SELECT c.id, c.set_id, c.name, c.local_id, c.rarity, c.image_base, c.price_usd, s.name AS sname, s.release_date AS rdate FROM cards c JOIN sets s ON s.id=c.set_id"
                   + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY " + order + f" LIMIT {_PER_GAME + 1}")
            rows = c.execute(sql, args).fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            c.close()
        if len(rows) > _PER_GAME:
            out["capped"] = True
            rows = rows[:_PER_GAME]
        have = _owned(svc, gid, [r["id"] for r in rows])
        try:
            wish = {r[0] for r in v.conn.execute("SELECT card_id FROM u.wishlist WHERE user_id=? AND game=?", (v.user_id, gid))}
        except sqlite3.Error:
            wish = set()
        n = 0
        for r in rows:
            qty = have.get(r["id"], 0)
            if owned == "yes" and not qty:
                continue
            if owned == "no" and qty:
                continue
            if owned == "wish" and r["id"] not in wish:
                continue
            n += 1
            nm = r["name"] or ""
            rel = (0 if nm.lower() == q.lower() else 1 if nm.lower().startswith(q.lower()) else 2) if q else 2
            if gid == v.game:
                pic = img(r["id"], r["set_id"])
            elif r["image_base"]:
                pic = picture_url(r["image_base"], "low") if gid.startswith("pokemon") else r["image_base"]
            else:
                pic = ""
            rows_all.append({"game": gid, "gameName": name, "id": r["id"], "set": r["sname"] or "", "name": nm, "number": r["local_id"], "rarity": r["rarity"] or "", "img": pic,
                             "owned": qty, "wish": r["id"] in wish, "price": r["price_usd"], "_rel": rel, "_date": r["rdate"] or ""})
            if r["rarity"]:
                rar_count[r["rarity"]] = rar_count.get(r["rarity"], 0) + 1
        per_game[gid] = per_game.get(gid, 0) + n
    chosen = [g for g in here if (not want or g[0] in want)]
    if len(chosen) == 1:                                                  # ONE game chosen: its own filters (its colours / types / card types) are offered
        gid0, _n0, path0 = chosen[0]
        out["single"] = gid0
        out["typeLabel"] = games_mod().game_by_id(gid0).type_label
        try:
            cc = sqlite3.connect("file:" + path0.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
            counts = {}
            for (tv,) in cc.execute("SELECT types FROM cards WHERE types IS NOT NULL AND types != ''"):
                for part in str(tv).replace(";", ",").split(","):
                    part = part.strip()
                    if part:
                        counts[part] = counts.get(part, 0) + 1
            cc.close()
            out["types"] = [{"name": k, "n": n} for k, n in sorted(counts.items(), key=lambda kv: -kv[1])[:40]]
        except sqlite3.Error:
            pass
    rows_all.sort(key=_sort_key(sort or "relevance"))
    off, lim = max(0, int(offset)), max(1, min(400, int(limit)))
    out["results"] = [{k: val for k, val in r.items() if not k.startswith("_")} for r in rows_all[off:off + lim]]
    out["total"] = len(rows_all)
    out["games"] = [{"id": gid, "name": name, "n": per_game.get(gid, 0), "family": _games_mod.game_by_id(gid).family, "installed": True} for gid, name, _ in here]
    out["rarities"] = [{"name": k, "n": n} for k, n in sorted(rar_count.items(), key=lambda kv: -kv[1])[:40]]
    return out


def games_mod():
    from .. import games as g
    return g
