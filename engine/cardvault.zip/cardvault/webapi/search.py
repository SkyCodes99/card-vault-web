"""Search the whole catalog at once: every game that is installed on this device, in one list."""
import os
import sqlite3

from .. import games, runtime
from ..db import game_dir, picture_url
from .registry import api


def _games(svc):
    """[(game id, name, path of its card list)] for every game that has cards here."""
    out = []
    for g in games.GAMES:
        if not g.available:
            continue
        p = os.path.join(game_dir(svc.cfg["data_dir"], g.id), "cards.db")
        if os.path.exists(p):
            out.append((g.id, g.name, p))
    return out


def _owned(svc, game_id, ids):
    if not ids:
        return {}
    v = svc.vault
    q = ",".join("?" * len(ids))
    try:
        rows = v.conn.execute(f"SELECT card_id, SUM(qty) FROM u.lots WHERE user_id=? AND game=? AND deleted=0 AND card_id IN ({q}) GROUP BY card_id", (v.user_id, game_id, *ids)).fetchall()
    except sqlite3.Error:
        return {}
    return {r[0]: int(r[1] or 0) for r in rows}


@api("search.global", quiet=True)
def search_global(svc, q="", game="", rarity="", owned="", limit=60):
    """-> {"results": [...], "games": [{id, name, n}], "missing": [names of games not downloaded here]}.  One card list per game: the whole catalog, not only the open game."""
    from .cards import img
    q = (q or "").strip()
    here = _games(svc)
    out = {"results": [], "games": [], "missing": [g.name for g in games.GAMES if g.available and g.id not in {x[0] for x in here}]}
    if len(q) < 2:
        out["games"] = [{"id": gid, "name": name, "n": 0} for gid, name, _ in here]
        return out
    words = [w for w in q.lower().replace("#", " ").split() if w]
    for gid, name, path in here:
        if game and gid != game:
            continue
        try:
            c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
        except sqlite3.Error:
            continue
        try:
            where, args = [], []
            for w in words:
                where.append("(lower(c.name) LIKE ? OR lower(c.local_id) LIKE ? OR lower(s.name) LIKE ? OR lower(c.name_ja) LIKE ? OR lower(c.name_en) LIKE ?)")
                args += [f"%{w}%"] * 5
            if rarity:
                where.append("lower(coalesce(c.rarity,'')) LIKE ?")
                args.append(f"%{rarity.lower()}%")
            rows = c.execute(
                "SELECT c.id, c.set_id, c.name, c.local_id, c.rarity, c.image_base, s.name, c.price_usd FROM cards c JOIN sets s ON s.id=c.set_id WHERE " + " AND ".join(where) +
                " ORDER BY (lower(c.name) = ?) DESC, (lower(c.name) LIKE ?) DESC, s.release_date DESC, c.sort_key LIMIT 200", (*args, q.lower(), q.lower() + "%")).fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            c.close()
        have = _owned(svc, gid, [r[0] for r in rows])
        n = 0
        for cid, sid, cname, lid, rar, base, sname, usd in rows:
            qty = have.get(cid, 0)
            if owned == "yes" and not qty:
                continue
            if owned == "no" and qty:
                continue
            n += 1
            if len([r for r in out["results"] if r["game"] == gid]) < limit:
                if gid == svc.vault.game:
                    pic = img(cid, sid)
                elif base:
                    pic = picture_url(base, "low") if gid.startswith("pokemon") else base
                else:
                    pic = ""
                out["results"].append({"game": gid, "gameName": name, "id": cid, "set": sname, "name": cname, "number": lid, "rarity": rar or "", "img": pic, "owned": qty, "price": usd})
        out["games"].append({"id": gid, "name": name, "n": n})
    return out
