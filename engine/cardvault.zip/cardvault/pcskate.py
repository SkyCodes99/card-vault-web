"""Pokémon Center × Bear Walker skateboards (owner 2026-11-05: "add the bearwalker skateboards under accessories and make sure you get it correct").
Sold only through pokemoncenter.com, whose pages turn scripts away, so the daily list cannot read them: this is the shop's own list as of 2026-11-05 (51 boards, its
search for "Bear Walker"), each with its SKU, retail price, the shop's product photo and whether it was in stock that day.  Add new boards here."""

SITE = "https://www.pokemoncenter.com"
SEEN = "2026-11-05"

# (sku, address slug, photo folder/prefix, retail USD, in stock on SEEN)
BOARDS = (
    ("71-10406-101", "shiny-gyarados-skateboard-deck", "10063/P12044", 129.99, True),
    ("71-10405-101", "shiny-magikarp-skateboard", "10063/P12044", 299.99, True),
    ("71-10325-101", "mew-skateboard", "10031/P12042", 299.99, True),
    ("71-10321-101", "moltres-skateboard-deck", "10031/P12042", 129.99, True),
    ("71-10322-101", "zapdos-skateboard-deck", "10031/P12042", 129.99, True),
    ("71-10324-101", "mewtwo-skateboard", "10031/P12042", 299.99, True),
    ("710-97351", "mimikyu-skateboard", "10000/P9234", 249.99, True),
    ("71-10323-101", "articuno-skateboard-deck", "10031/P12042", 129.99, True),
    ("710-97108", "snorlax-skateboard", "10000/P8347", 249.99, True),
    ("710-95714", "mew-skateboard-pokemon-day-2022", "10000/P8345", 249.99, True),
    ("710-96758", "psyduck-skateboard", "10000/P9015", 249.99, True),
    ("720E00017", "team-rocket-skateboard-deck", "10000/P9237", 249.99, True),
    ("710-95700", "charmander-skateboard", "10000/P8346", 249.99, True),
    ("710-29647", "vaporeon-skateboard", "10000/P7528", 249.99, True),
    ("710-97349", "haunter-skateboard", "10000/P9234", 249.99, True),
    ("710-97109", "growlithe-skateboard", "10000/P8347", 249.99, True),
    ("710-95699", "cubone-skateboard", "10000/P8346", 249.99, True),
    ("710-97352", "blastoise-skateboard", "10001/P9235", 249.99, True),
    ("710-29766", "eevee-skateboard", "10000/P7528", 249.99, True),
    ("710-95701", "bulbasaur-skateboard", "10000/P8346", 249.99, True),
    ("710-96756", "slowpoke-skateboard", "10000/P9015", 249.99, True),
    ("710-95702", "squirtle-skateboard", "10000/P8346", 249.99, True),
    ("710-97353", "venusaur-skateboard", "10001/P9235", 249.99, True),
    ("710-08790", "snom-skateboard", "10000/P7256", 249.99, True),
    ("710-97110", "voltorb-skateboard", "10000/P8347", 249.99, True),
    ("710-97350", "sableye-skateboard", "10000/P9234", 249.99, True),
    ("710-96757", "magnemite-skateboard", "10000/P9015", 249.99, True),
    ("71-10046-101", "eevee-skateboard", "10011/P10973", 299.99, False),
    ("720E12815", "garchomp-skateboard", "10000/P10193", 299.99, False),
    ("71-10044-101", "umbreon-skateboard-deck", "10011/P10973", 129.99, False),
    ("71-10089-101", "gengar-skateboard", "10018/P11110", 299.99, False),
    ("710E12437", "charizard-skateboard-2024", "10000/P10191", 299.99, False),
    ("71-10045-101", "sylveon-skateboard-deck", "10011/P10973", 129.99, False),
    ("71-10043-101", "espeon-skateboard-deck", "10011/P10973", 129.99, False),
    ("710E00025", "pikachu-skateboard", "10001/P9518", 249.99, False),
    ("720E12813", "dragapult-skateboard", "10000/P10193", 299.99, False),
    ("71-10039-101", "flareon-skateboard-deck", "10011/P10973", 129.99, False),
    ("71-10042-101", "vaporeon-skateboard-deck", "10011/P10973", 129.99, False),
    ("720E12816", "dragonite-skateboard", "10000/P10193", 299.99, False),
    ("720E12814", "tyranitar-skateboard", "10000/P10193", 299.99, False),
    ("710-08386", "rayquaza-skateboard", "10000/P6951", 249.99, False),
    ("71-10038-101", "leafeon-skateboard-deck", "10011/P10973", 129.99, False),
    ("71-10041-101", "jolteon-skateboard-deck", "10011/P10973", 129.99, False),
    ("71-10040-101", "glaceon-skateboard-deck", "10011/P10973", 129.99, False),
    ("710-94578", "umbreon-skateboard", "10000/P7528", 249.99, False),
    ("710-94575", "sylveon-skateboard", "10000/P7528", 249.99, False),
    ("710-94577", "leafeon-skateboard", "10000/P7528", 249.99, False),
    ("710-09888", "piplup-skateboard", "10000/P7527", 249.99, False),
    ("710-09889", "mudkip-skateboard", "10000/P7527", 249.99, False),
    ("710-08385", "toxtricity-skateboard", "10000/P6951", 249.99, False),
    ("710-09887", "genesect-skateboard", "10000/P7527", 249.99, False),
)

def title(slug: str) -> str:
    """'shiny-gyarados-skateboard-deck' -> 'Pokémon Center × Bear Walker: Shiny Gyarados Skateboard Deck' (the shop's own product name)."""
    for k, v in (("-pokemon-day-2022", " (Pokémon Day 2022)"), ("-2024", " (2024)")):
        if slug.endswith(k):
            slug, tail = slug[: -len(k)], v
            break
    else:
        tail = ""
    return "Pokémon Center × Bear Walker: " + " ".join(w.capitalize() for w in slug.split("-")) + tail


def rows():
    """-> [(sku, name, kind, price, photo, product address, in stock)]"""
    out = []
    for sku, slug, pic, usd, stock in BOARDS:
        kind = "Skateboard decks" if slug.endswith("-deck") else "Skateboard completes"
        out.append((sku, title(slug), kind, usd, f"{SITE}/images/DAMRoot/Full-Size/{pic}_{sku}_01.jpg", f"{SITE}/product/{sku}/pokemon-center-bear-walker-{slug}", stock))
    return out
