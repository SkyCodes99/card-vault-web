"""The pictures of one of your own items: up to MAX_PICTURES, the first one is the cover (the one every list shows).

The item row keeps their fingerprints in order, comma between (a single fingerprint is the old one-picture row, so nothing needs converting).  The bytes live in u.lot_photos under the
item's uuid - the same table, the same photo limit and the same account photo sync as every other photo feature.  Every picture is shrunk to a JPEG of at most MAX_BYTES (2 MB) on the way in.
A picture taken out of the list stays in the table for a while (the newest KEEP_UNUSED) so ONE Undo of the edit can bring it back; older ones are removed and announced to the account sync."""
import base64
import hashlib
import io

from .db import now_iso

MAX_PICTURES, KEEP_UNUSED = 4, 3
MAX_BYTES = 2 * 1024 * 1024                       # what is kept (the app shrinks every picture to this or less)
MAX_INPUT_B64 = 30 * 1024 * 1024 * 4 // 3 + 64    # what is accepted: a 30 MB picture, as the base64 text of a data: address
MAX_SIDE = 900
FP = "fp:"                                           # a picture that is already kept is named by its fingerprint ("fp:<id>") when the screen sends the list back


class PictureError(ValueError):
    pass


def fingerprint(data):
    return hashlib.sha1(data).hexdigest()[:20]


def fps(pic):
    """'a,b,c' -> ['a','b','c'] (the cover first)."""
    return [x for x in str(pic or "").split(",") if x]


def cover(pic):
    f = fps(pic)
    return f[0] if f else ""


def shrink(data_url):
    """A photo the person picked (a data: address) -> a JPEG of at most MAX_SIDE px and at most MAX_BYTES, made smaller step by step until it fits."""
    if not isinstance(data_url, str):
        raise PictureError("That isn't a picture I can read.")
    if len(data_url) > MAX_INPUT_B64:
        raise PictureError("That picture is bigger than 30 MB - choose a smaller one.")
    try:
        from PIL import Image, ImageOps
        raw = base64.b64decode(data_url.split(",", 1)[-1])
        with Image.open(io.BytesIO(raw)) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")          # (a phone photo stays the way up it was taken)
            side, q = MAX_SIDE, 82
            while True:
                t = im.copy()
                t.thumbnail((side, side))
                buf = io.BytesIO()
                t.save(buf, "JPEG", quality=q)
                if buf.tell() <= MAX_BYTES or side <= 64:
                    return buf.getvalue()
                side, q = int(side * 0.75), max(40, q - 10)
    except Exception:  # noqa: BLE001 - anything that is not a picture
        raise PictureError("That isn't a picture I can read.")


def read(v, uuid, pic):
    """[(fingerprint, bytes)] for the item's pictures, in order (a picture that has not arrived from the other device yet is left out)."""
    have = {}
    for (data,) in v.conn.execute("SELECT data FROM u.lot_photos WHERE lot_uuid=? ORDER BY id DESC", (uuid,)):
        if data:
            have.setdefault(fingerprint(data), bytes(data))
    return [(f, have[f]) for f in fps(pic) if f in have]


def new_count(items):
    """How many of the pictures sent are new (a data: address, not one already kept) - what the photo limit has to allow."""
    return sum(1 for x in (items or []) if x and not str(x).startswith(FP))


def save(v, uuid, items, pic_now=""):
    """items: the wanted list, in order - each an 'fp:<id>' of a picture already kept, or a data: address.  -> the new 'a,b,c' string ('' = no pictures)."""
    items = [x for x in (items or []) if x]
    if len(items) > MAX_PICTURES:
        raise PictureError(f"An item can have up to {MAX_PICTURES} pictures.")
    kept = {f for f, _ in read(v, uuid, pic_now)}
    out = []
    for x in items:
        if str(x).startswith(FP):
            f = str(x)[len(FP):]
            if f not in kept:
                raise PictureError("One of the pictures is not there any more.")
        else:
            data = shrink(x)
            f = fingerprint(data)
            if not v.conn.execute("SELECT 1 FROM u.lot_photos WHERE lot_uuid=? AND data=?", (uuid, data)).fetchone():
                v.conn.execute("INSERT INTO u.lot_photos(lot_uuid, side, data, added) VALUES(?,?,?,?)", (uuid, "front", data, now_iso()))
                from .cloud import photos
                photos.revive(v.conn, uuid, data)         # (the same picture removed before: the next sync must not delete it again)
        if f not in out:
            out.append(f)
    _trim(v, uuid, set(out))
    return ",".join(out)


def _trim(v, uuid, wanted):
    """Keep what the item uses plus the newest few that it no longer uses (for Undo); the rest is deleted and announced to the account sync."""
    from .cloud import photos
    unused = 0
    for pid, data in v.conn.execute("SELECT id, data FROM u.lot_photos WHERE lot_uuid=? ORDER BY id DESC", (uuid,)).fetchall():
        if data and fingerprint(data) in wanted:
            continue
        unused += 1
        if unused <= KEEP_UNUSED:
            continue
        if data:
            v.conn.execute("INSERT OR IGNORE INTO u.photo_deleted VALUES(?,datetime('now'))", (photos.key_for(uuid, data),))
        v.conn.execute("DELETE FROM u.lot_photos WHERE id=?", (pid,))
