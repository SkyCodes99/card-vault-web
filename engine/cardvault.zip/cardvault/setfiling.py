"""Roadmap 2.2 "New sets filed right on every game": ONE place that gives a new set its era / series and its REAL logo, whatever the game.  Called from tcgsync (every set the daily update adds),
from tcgcsv's group writer (the full list rebuild), from setpics.fill_all (the daily logo step) and by tools/file_new_sets.py (the re-runnable backfill for sets added without them).

ERA      era_for(game, group)   the set's series.  Order: an explicit rule in cardvault/data/set_eras.json (the per-game mapping file) -> the game's own rule (tcgcsv.serie_for: what the
         group's name / code / date say) -> a date range of the mapping file -> the release year ("2026 releases") -> "Promos & Other".  Never empty (the placement gate holds a card whose set has no
         series).  Pokemon (TCGdex's own lists) keep "Miscellaneous" for a set no rule places; file_eras then lets place_set move a coded one ("ME06: ...") into its era.
LOGO     fill_logos(conn, game, getjson)   a set's REAL logo comes from a public list that names it: Scryfall (the set's icon, matched by TCGplayer group id, else name), YGOPRODeck (set image),
         TCGdex and pokemontcg.io (Pokemon).  A card or sealed-product picture NEVER counts as a logo (is_real_logo): a set none of the sources lists keeps its logo EMPTY and is counted, and a
         stand-in picture already filed for it (setpics tiers 3-5) is left alone unless a real logo turns up, which replaces it.  The address is kept in the list's setimg_urls (the screens read
         it for guests and the browser too; the daily rebuild of a TCGplayer game rewrites sets.logo, so that column is not the place).
DATE     datefix.fix_new: the new set's release date (Scryfall / YGOPRODeck / Lorcast / pokemontcg.io, else TCGplayer's group) and its products' days (roadmap 2.9).
No network here: getjson(url) -> parsed JSON or None is passed in (tests pass a fake)."""
import json
import os
import re
import sqlite3

ERA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "set_eras.json")
PLAIN = "Promos & Other"
POKEMON = ("pokemon", "pokemon_jp")

# ------------------------------------------------------------------------------------------------ era
_rules_cache = {}


def load_rules(path=None):
    """The per-game mapping file: {"games": {game: {"rules": [{"match": regex on 'name abbreviation', "era": text}], "dates": [{"from": "YYYY-MM-DD", "to": "YYYY-MM-DD", "era": text}]}}}"""
    path = path or ERA_FILE
    if path not in _rules_cache:
        try:
            with open(path, encoding="utf-8") as f:
                _rules_cache[path] = (json.load(f) or {}).get("games") or {}
        except (OSError, ValueError):
            _rules_cache[path] = {}
    return _rules_cache[path]


def era_for(game, group, rules=None):
    """-> the era / series for a set.  group: {"name", "abbreviation" (optional), "publishedOn" (optional)} - a TCGplayer group, or a set row built the same way.  Never empty."""
    from .tcgcsv import serie_for
    mine = (rules if rules is not None else load_rules()).get(game) or {}
    name, abbr, date = group.get("name") or "", group.get("abbreviation") or "", (group.get("publishedOn") or group.get("release_date") or "")[:10]
    text = f"{name} {abbr}".strip()
    for r in mine.get("rules") or []:
        if r.get("era") and re.search(r["match"], text, re.I):
            return r["era"]
    own = serie_for(game, {"name": name, "abbreviation": abbr, "publishedOn": date})
    if own:
        return own
    for r in mine.get("dates") or []:
        if r.get("era") and (r.get("from") or "0000") <= date <= (r.get("to") or "9999") and date:
            return r["era"]
    if game in POKEMON:
        return "Miscellaneous"
    return (date[:4] + " releases") if date[:4].isdigit() and int(date[:4]) > 1990 else PLAIN


def _blank(s):
    return not (s or "").strip()


def file_eras(conn, game, set_ids=None, rules=None):
    """Gives every set (or the ones named) with no series its era, then lets a coded Pokemon set take its era's (tcgsync.place_set).  Safe to run again.  -> {"sets", "had", "filled", "placed", "empty"}"""
    from .tcgsync import place_set
    ids = list(set_ids) if set_ids is not None else [r[0] for r in conn.execute("SELECT id FROM sets")]
    out = {"sets": len(ids), "had": 0, "filled": 0, "placed": 0, "empty": 0, "examples": []}
    for sid in ids:
        row = conn.execute("SELECT name, serie, release_date FROM sets WHERE id=?", (sid,)).fetchone()
        if not row:
            continue
        if _blank(row[1]):
            era = era_for(game, {"name": row[0], "publishedOn": row[2]}, rules)
            conn.execute("UPDATE sets SET serie=? WHERE id=?", (era, sid))
            out["filled"] += 1
            if len(out["examples"]) < 5:
                out["examples"].append(f"{sid} {row[0]} -> {era}")
        else:
            out["had"] += 1
        if game in POKEMON and place_set(conn, sid):
            out["placed"] += 1
    out["empty"] = conn.execute("SELECT COUNT(*) FROM sets WHERE serie IS NULL OR TRIM(serie)=''").fetchone()[0] if set_ids is None else sum(
        1 for sid in ids if (conn.execute("SELECT serie FROM sets WHERE id=?", (sid,)).fetchone() or ["x"])[0] in (None, ""))
    return out


# ------------------------------------------------------------------------------------------------ logo
_REAL = (re.compile(r"^https?://svgs\.scryfall\.io/sets/", re.I), re.compile(r"^https?://images\.ygoprodeck\.com/images/sets/", re.I),
         re.compile(r"^https?://assets\.tcgdex\.net/.+/logo(\.\w+)?(\?.*)?$", re.I), re.compile(r"/logo(\.\w+)?(\?.*)?$", re.I),      # (pokemontcg.io, scrydex: .../logo.png)
         re.compile(r"^https?://img\.yugipedia\.com/", re.I))                                             # (cardvault/logos/yugipedia.py: a set's own cover / logo file on Yugipedia)
_CARD_OR_BOX = re.compile(r"tcgplayer\.com/|/product/\d+_", re.I)


def is_real_logo(url):
    """True for an address that is a set's own logo / icon from a public set list.  A TCGplayer product picture (a card, a booster box) is never one."""
    u = (url or "").strip()
    return bool(u) and not _CARD_OR_BOX.search(u.split("?")[0]) and any(p.search(u) for p in _REAL)


def _norm(s):
    s = (s or "").lower().replace("&", " and ").replace("é", "e").replace("'", "").replace("’", "")
    s = re.sub(r"^(sv|swsh|sm|xy|bw|dp|hgss|ex|pl|me)\s*\d*\s*[:\-]\s*", "", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def _by_name(rows):
    """name -> the candidates whose name is the same after folding (_pick takes the nearest year when a name repeats)."""
    out = {}
    for r in rows:
        out.setdefault(_norm(r["name"]), []).append(r)
    return out


def _pick(cands, row):
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    y = (row.get("date") or "")[:4]
    if y.isdigit():
        near = sorted(cands, key=lambda c: abs(int((c.get("year") or "1900")[:4] or 1900) - int(y)))
        return near[0]
    return None


def scryfall_logos(getjson, rows):
    """Magic: Scryfall's set icon.  The set's TCGplayer group id is Scryfall's tcgplayer_id (exact); else the name."""
    data = (getjson("https://api.scryfall.com/sets") or {}).get("data") or []
    by_id = {str(x["tcgplayer_id"]): x for x in data if x.get("tcgplayer_id") and x.get("icon_svg_uri")}
    names = _by_name([{"name": x.get("name"), "url": x["icon_svg_uri"], "year": x.get("released_at") or ""} for x in data if x.get("icon_svg_uri")])
    out = {}
    for r in rows:
        hit = by_id.get(str(r["id"]))
        url = hit["icon_svg_uri"] if hit else (_pick(names.get(_norm(r["name"])), r) or {}).get("url")
        if url:
            out[r["id"]] = url
    return out


def ygoprodeck_logos(getjson, rows):
    """Yu-Gi-Oh!: YGOPRODeck's set image, matched by set name."""
    data = getjson("https://db.ygoprodeck.com/api/v7/cardsets.php") or []
    names = _by_name([{"name": x.get("set_name"), "url": x["set_image"], "year": x.get("tcg_date") or ""} for x in data if isinstance(x, dict) and x.get("set_image")])
    return {r["id"]: h["url"] for r in rows for h in [_pick(names.get(_norm(r["name"])), r)] if h}


def tcgdex_logos(getjson, rows):
    """Pokemon: TCGdex's English set list (logo address + '.webp'), matched by name (and card count when the name repeats)."""
    data = getjson("https://api.tcgdex.net/v2/en/sets") or []
    names = _by_name([{"name": x.get("name"), "url": x["logo"] + ".webp", "year": "", "total": (x.get("cardCount") or {}).get("total")} for x in data if isinstance(x, dict) and x.get("logo")])
    out = {}
    for r in rows:
        c = names.get(_norm(r["name"])) or []
        c = [x for x in c if not r.get("total") or x.get("total") in (None, r["total"])] or c
        if len(c) == 1:
            out[r["id"]] = c[0]["url"]
    return out


def pokemontcg_logos(getjson, rows):
    """Pokemon: pokemontcg.io's set list; the name AND the card count must agree (a same-named set with another size is another set)."""
    data = (getjson("https://api.pokemontcg.io/v2/sets?pageSize=250") or {}).get("data") or []
    names = _by_name([{"name": x.get("name"), "url": (x.get("images") or {}).get("logo"), "year": x.get("releaseDate") or "", "total": x.get("total"), "printed": x.get("printedTotal")}
                      for x in data if (x.get("images") or {}).get("logo")])
    out = {}
    for r in rows:
        c = [x for x in names.get(_norm(r["name"])) or [] if r.get("total") and r["total"] in (x.get("total"), x.get("printed"))]
        if len(c) == 1:
            out[r["id"]] = c[0]["url"]
    return out


LOGO_SOURCES = {"mtg": (scryfall_logos,), "yugioh": (ygoprodeck_logos,), "pokemon": (tcgdex_logos, pokemontcg_logos)}
# Every other game has no public list of set logos (TCGplayer's group list has none, Lorcast's has none, TCGdex's Japanese list has none): their logo stays EMPTY and is counted.  A game that gains a
# source is one entry here.


def _urls(conn):
    try:
        row = conn.execute("SELECT value FROM meta WHERE key='setimg_urls'").fetchone()
        d = json.loads(row[0]) if row and row[0] else {}
        return d if isinstance(d, dict) else {}
    except (sqlite3.Error, ValueError):
        return {}


def fill_logos(conn, game, getjson, set_ids=None, dry_run=False, review=None):
    """Finds the real logo of every set (or the ones named) that has none and files its address in setimg_urls.
    -> {"sets", "had", "found", "upgraded", "missing", "standin_only", "missing_ids"}   had = already a real logo; upgraded = found ones that replaced a stand-in picture; standin_only = missing ones that
    still show a stand-in (a card / box picture, left as it is); a dry run writes nothing.  review: a list the wider search appends the doubtful candidates to (never applied)."""
    urls = _urls(conn)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sets)")]
    ids = set(set_ids) if set_ids is not None else None
    rows = []
    for r in conn.execute("SELECT id, name, release_date, total, " + ("logo" if "logo" in cols else "NULL") + " FROM sets"):
        if ids is None or r[0] in ids:
            rows.append({"id": r[0], "name": r[1], "date": r[2], "total": r[3], "logo": r[4]})
    out = {"sets": len(rows), "had": 0, "found": 0, "upgraded": 0, "missing": 0, "standin_only": 0, "missing_ids": []}
    need = []
    for r in rows:
        if (r["logo"] or "").strip() or is_real_logo(urls.get(r["id"])):
            out["had"] += 1
        else:
            need.append(r)
    found = {}
    if need and getjson:
        for src in LOGO_SOURCES.get(game, ()):
            todo = [r for r in need if r["id"] not in found]
            if not todo:
                break
            try:
                found.update({k: v for k, v in src(getjson, todo).items() if is_real_logo(v)})
            except (KeyError, TypeError, ValueError):
                continue                                                   # a source that answers oddly fills nothing today
        todo = [r for r in need if r["id"] not in found]
        reader = getattr(getjson, "reader", None)                        # the wider search (cardvault/logos: one small module per source) needs the polite reader, not just getjson
        if todo and reader is not None:
            from . import logos
            found.update({k: v for k, v in logos.find(game, todo, reader, review).items() if is_real_logo(v)})
    for r in need:
        if r["id"] in found:
            out["found"] += 1
            out["upgraded"] += 1 if urls.get(r["id"]) else 0
            urls[r["id"]] = found[r["id"]]
        else:
            out["missing"] += 1
            out["standin_only"] += 1 if urls.get(r["id"]) else 0
            if len(out["missing_ids"]) < 50:
                out["missing_ids"].append(r["id"])
    if out["found"] and not dry_run:
        conn.execute("INSERT OR REPLACE INTO meta VALUES('setimg_urls', ?)", (json.dumps(urls),))
        conn.commit()
    return out


def default_getjson():
    """The shared polite reader (robots.txt, rate limit, cache) as a getjson(url) for the real runs."""
    from .picturecheck import Reader
    reader = Reader()

    def getjson(url):
        return reader.json(url)
    getjson.reader = reader                                # (the wider logo search in cardvault/logos reads pages and files through the same reader)
    return getjson


def file_new_sets(game, conn, set_ids=None, getjson=None, dry_run=False, rules=None):
    """THE function for a new set on any game: era first (the placement gate needs a series), then the real logo, then its release date (cardvault/datefix.py: a day a source proves, or the
    group's / the set's day for a product with none; unknown stays empty).  getjson=None skips the logo and date lookups (the sets are counted as missing).
    -> {"era": file_eras report, "logo": fill_logos report, "dates": datefix.fix_game report}"""
    from . import datefix
    era = file_eras(conn, game, set_ids, rules) if not dry_run else _era_dry(conn, game, set_ids, rules)
    logo = fill_logos(conn, game, getjson, set_ids, dry_run)
    dates = datefix.fix_new(conn, game, set_ids, getjson, dry_run)
    return {"era": era, "logo": logo, "dates": dates}


def _era_dry(conn, game, set_ids, rules):
    """The same report without writing: a rollback undoes the update."""
    conn.execute("SAVEPOINT era_dry")
    try:
        return file_eras(conn, game, set_ids, rules)
    finally:
        conn.execute("ROLLBACK TO era_dry")
        conn.execute("RELEASE era_dry")
