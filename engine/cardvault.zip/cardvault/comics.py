"""Comics list: every series is a "set", every issue (and every variant cover / edition of it) an item of its own, filed under its series.  No network at refresh.

Where the data comes from (docs/comics_data.md has the whole survey):
  * comics_import.json in the list's folder - written by tools/import_comics.py from the Grand Comics Database dump the OWNER downloads (comics.org needs a free account for the dump, so the app never
    makes one); when it exists it is the list.
  * else cardvault/comics_data.json - a small real sample (six series, eleven issues) whose facts Wikipedia articles state, each record with its own article as source.
Every fact an item shows is one its source states; one it does not state is left out (never guessed).  Each stated fact gets a provenance record (source, the item's own page, the day it was read).
KEY ISSUES come only from a stated note ("First appearance of ...", cardvault/comicskeys.py) and are saved as the item's rarity.  PRICES: none - no free source with real comic prices is allowed
(docs/comics_data.md lists what was checked), so an item shows no price rather than a guess.  PICTURES: an item has one only when its data carries a cover_url (importer option --covers).
A stable issue id (`comics:<source id>`, e.g. comics:gcd-1234) and the cover URL are kept in raw (`key`, `cover_url`) for the cover scanner."""
import json
import os
import re
import time

from . import comicskeys as keys
from . import provenance
from .db import open_cards_conn
from .tcgcsv import TcgCsvProvider

SAMPLE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "comics_data.json")
IMPORT_NAME = "comics_import.json"
NO_PICTURE = "No picture yet: no source we are allowed to read gives a cover picture we may show for this exact issue"
_MONTHS = "January February March April May June July August September October November December".split()


def load(gdir=None):
    """The list's data: the owner's import when there is one in the list's folder, else the bundled sample."""
    path = os.path.join(gdir, IMPORT_NAME) if gdir else ""
    with open(path if path and os.path.exists(path) else SAMPLE, encoding="utf-8") as f:
        return json.load(f)


def month_day(iso):
    """'1938-06' -> 'June 1938'; '1938' -> '1938'; anything else as stated."""
    m = re.fullmatch(r"(\d{4})(?:-(\d{2}))?(?:-\d{2})?", iso or "")
    if not m:
        return iso or ""
    return "%s %s" % (_MONTHS[int(m.group(2)) - 1], m.group(1)) if m.group(2) and 1 <= int(m.group(2)) <= 12 else m.group(1)


def series_labels(series):
    """{series id: the name shown}: 'The Amazing Spider-Man (1963)', else its volume ('Superman (vol. 2)'); two series that would read the same get their publisher added."""
    first = {s["id"]: s["name"] + (" (%s)" % (s.get("year_began") or s.get("volume")) if (s.get("year_began") or s.get("volume")) else "") for s in series}
    seen = {}
    for lab in first.values():
        seen[lab] = seen.get(lab, 0) + 1
    return {sid: lab if seen[lab] == 1 else "%s - %s" % (lab, next(s["publisher"] for s in series if s["id"] == sid) or "?") for sid, lab in first.items()}


def item_name(series, issue):
    return "%s #%s%s" % (series["name"], issue["number"], " - " + issue["cover"] if issue.get("cover") else "")


def _order(issue):
    m = re.match(r"\d+", issue["number"])
    return (int(m.group()) if m else 10 ** 6, issue["number"], 1 if issue.get("variant_of") else 0, issue.get("cover") or "")


def facts_of(series, issue, label):
    """{detail label: stated value} of one issue in display order (a fact the source does not state is simply not here)."""
    notes = [k["note"] for k in issue.get("key") or []]
    out = {"Publisher": series.get("publisher"), "Series": label, "Issue": issue["number"], "Cover date": month_day(issue.get("cover_date")), "On-sale date": issue.get("on_sale"),
           "Cover": issue.get("cover"), "Cover artist": issue.get("cover_artist"), "Key issue": " / ".join(notes)}
    return {k: v for k, v in out.items() if v}


def rarity_of(issue):
    return keys.KEY if issue.get("key") else keys.VARIANT if (issue.get("cover") or issue.get("variant_of")) else keys.ISSUE


def source_code(conn, sources, issue):
    """The provenance code of an issue's source ('w:<host>', the code the toy lists use), registered with the source's name."""
    src = sources[issue["source"]]
    code = "w:" + src["host"].replace("www.", "")
    conn.execute("INSERT OR REPLACE INTO sources(code,name,url_tpl) VALUES(?,?,NULL)", (code, src["name"]))
    return code, src["host"].replace("www.", "")


class ComicsProvider(TcgCsvProvider):
    def __init__(self):
        super().__init__("comics", 0, type_field="Publisher")

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        conn = open_cards_conn(gdir)
        try:
            progress("Reading the comics list…", 0, 0)
            provenance.ensure(conn)
            data = load(gdir)
            by_id = {s["id"]: s for s in data["series"]}
            labels = series_labels(data["series"])
            rows, prov, made = [], [], {}
            ordered = sorted((i for i in data["issues"] if i["series"] in by_id), key=lambda i: (i["series"],) + _order(i))
            for it in ordered:
                s = by_id[it["series"]]
                sid = "comics:" + s["id"]
                if sid not in made:
                    made[sid] = [0, set()]
                    conn.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)",
                                 (sid, labels[s["id"]], s.get("publisher") or "", s.get("year_began") or "", 0, 0))
                made[sid][0] += 1
                made[sid][1].add(it["number"])
                facts = facts_of(s, it, labels[s["id"]])
                code, host = source_code(conn, data["sources"], it)
                cid = "comics:" + it["id"]
                ext = {"Source": "%s: %s" % (data["sources"][it["source"]]["name"], it["url"]), **facts, **({} if it.get("cover_url") else {"Review": NO_PICTURE})}
                prov.append((cid, "card", code, it["read"], it["url"]))
                prov += [(cid, label, code, it["read"], it["url"]) for label in facts]
                note = facts.get("Key issue")
                rows.append((cid, sid, it["number"], made[sid][0], item_name(s, it), it.get("cover_url") or "", s.get("publisher") or "", rarity_of(it), s.get("publisher") or "",
                             "%s - %s, %s.%s" % (item_name(s, it), facts.get("Publisher", "publisher not stated"), facts.get("Cover date", "cover date not stated"), " Key issue: %s." % note if note else ""),
                             json.dumps({"normal": True}),
                             json.dumps({"source": host, "key": it["id"], "issue": "%s#%s" % (s["id"], it["number"]), "url": it["url"], "cover_url": it.get("cover_url") or "",
                                         "variant_of": ("comics:" + it["variant_of"]) if it.get("variant_of") else "", "ext": ext}, ensure_ascii=False)))
            conn.executemany("INSERT OR REPLACE INTO cards(id,set_id,local_id,sort_key,name,image_base,detailed,category,rarity,types,description,price_usd,price_kind,price_updated,variants,raw) "
                             "VALUES(?,?,?,?,?,?,1,?,?,?,?,NULL,NULL,NULL,?,?)", rows)
            keep = {r[0] for r in rows}
            gone = [(r[0],) for r in conn.execute("SELECT id FROM cards") if r[0] not in keep]          # (an issue its source no longer lists leaves the list; the owner's own copies are kept elsewhere)
            conn.executemany("DELETE FROM cards WHERE id=?", gone)
            conn.executemany("DELETE FROM provenance WHERE card_id=?", gone + [(c,) for c in keep])
            provenance.record_many(conn, prov)
            conn.executemany("UPDATE sets SET total=?, official=? WHERE id=?", [(len(nums), len(nums), sid) for sid, (_n, nums) in made.items()])
            conn.execute("DELETE FROM sets WHERE id NOT IN (SELECT DISTINCT set_id FROM cards)")
            conn.execute("INSERT OR REPLACE INTO meta VALUES('prices_updated', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
            conn.commit()
            from . import gamefacets
            gamefacets.ensure(conn, self.game_id, force=True)             # (the sidebar filters are rebuilt with the list, as the other toy lists do)
            return len(rows)
        finally:
            conn.close()

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return 0          # no free source with real comic prices is allowed (docs/comics_data.md); owners can enter what they paid
