"""Search a card's TEXT ("draw a card", "can't be blocked", "heal 30 damage ...") - one more filter in the sidebar, 'Card text', in every game that has card text.

Where the text is: cards.description (the shop's card text - Magic's oracle text, a Yu-Gi-Oh! effect, a Lorcana ability ... - or, for the games cardvault/details fills in, the source's) and, for Pokemon,
the attacks and abilities kept in the TCGdex record.  Reading all of that straight from the cards would mean going through every card's big record (a third of a second for Pokemon, more for
Magic), so the list keeps ONE small table of the folded words of each card's text:

    card_text(card_id, text)      made with the game's other filters (gamefacets.ensure); travels inside the published list

and a search is a plain LIKE over it.  Every word typed must be in the card's text (any order).  Nothing here is read until someone uses the filter."""
from .searchfold import fold

KEY, LABEL = "text", "Card text"
SCHEMA = "CREATE TABLE IF NOT EXISTS card_text(card_id TEXT PRIMARY KEY, text TEXT NOT NULL) WITHOUT ROWID"


def pokemon_text(doc):
    """The rules text of a TCGdex record: its abilities and attacks (names, effects) and its trainer / energy effect."""
    if not isinstance(doc, dict):
        return ""
    bits = []
    for a in (doc.get("abilities") or []):
        if isinstance(a, dict):
            bits += [a.get("type"), a.get("name"), a.get("effect")]
    for a in (doc.get("attacks") or []):
        if isinstance(a, dict):
            bits += [a.get("name"), a.get("effect")]
    bits.append(doc.get("effect"))
    return " | ".join(str(b) for b in bits if b and isinstance(b, (str, int)))


def row_text(description, doc=None):
    """The folded text of one card ('' when it has none)."""
    parts = [str(description or "").strip(), pokemon_text(doc)]
    return fold(" | ".join(p for p in parts if p))


def words(text):
    """What was typed -> the folded words (a list of strings or a string)."""
    if isinstance(text, (list, tuple)):
        text = " ".join(str(x) for x in text)
    return [w for w in (x.strip(".,;:!?()\"") for x in fold(text).split()) if w]


def condition(text, alias="c", prefix="tx", table=True):
    """-> (SQL, {name: value}): the cards whose text holds every typed word.  Named parameters, so it can sit inside any query on the card list ('' / {} when nothing was typed).
    table=False (a list that has no card_text yet) reads the cards' own text instead - slower, same answer for everything but Pokemon's attacks."""
    parts, args = [], {}
    for i, w in enumerate(words(text)[:8]):
        args[f"{prefix}{i}"] = f"%{w}%"
        parts.append(f"{alias}.id IN (SELECT card_id FROM card_text WHERE text LIKE :{prefix}{i})" if table else f"coalesce({alias}.description,'') LIKE :{prefix}{i}")
    return " AND ".join(parts), args


def has_table(conn):
    return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='card_text'").fetchone())


def card_ids(conn, text):
    """Ids of the cards whose text holds every typed word (nothing typed: none)."""
    sql, args = condition(text, table=has_table(conn))
    if not sql:
        return set()
    return {r[0] for r in conn.execute(f"SELECT c.id FROM cards c WHERE {sql}", args)}


def write(conn, rows):
    """Make the table again from [(card id, folded text)] (the card list's filter tables are rebuilt as a whole: gamefacets.ensure)."""
    conn.execute(SCHEMA)
    conn.execute("DELETE FROM card_text")
    conn.executemany("INSERT OR REPLACE INTO card_text(card_id, text) VALUES(?,?)", rows)


def filter_def(conn):
    """The sidebar's 'Card text' entry ({key, label, values: [], text: True}: the screen shows a box to type in, not choices), or None for a list with no card text."""
    try:
        if has_table(conn):
            has = conn.execute("SELECT 1 FROM card_text LIMIT 1").fetchone()
        else:
            has = conn.execute("SELECT 1 FROM cards WHERE description IS NOT NULL AND description != '' LIMIT 1").fetchone()
    except Exception:  # noqa: BLE001
        return None
    return {"key": KEY, "label": LABEL, "values": [], "text": True} if has else None
