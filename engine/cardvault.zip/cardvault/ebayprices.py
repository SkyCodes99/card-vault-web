"""Live asking prices from eBay for the items that have no market price anywhere else (Funko, designer toys, plush, playmats ...), through eBay's OFFICIAL Browse API.

What a price means (it is labelled in the app): the typical price of the cheapest matching NEW "Buy It Now" listings that are for sale right now - "eBay asking price (median of N)".  It is not a sold price:
eBay no longer gives sold prices to anyone but approved business partners (Marketplace Insights).  If that approval is ever granted, `sold_prices()` is the one place to change.
Keys: a free eBay developer account gives an App ID and Cert ID.  They are read from the environment (EBAY_APP_ID, EBAY_CERT_ID) or from the hub's secrets file (ebay_app_id / ebay_cert_id)
and are never printed, logged or stored anywhere else."""
import base64
import json
import os
import re
import statistics
import time

import requests

from . import askexpiry

SECRETS = os.path.join(os.path.expanduser("~"), "SkyCloud", "deploy", "azure", ".secrets.json")
TOKEN_URL = "https://api.ebay.com/identity/v1/oauth2/token"
SEARCH_URL = "https://api.ebay.com/buy/browse/v1/item_summary/search"
NEW_FILTER = "buyingOptions:{FIXED_PRICE},conditions:{NEW},priceCurrency:USD,price:[1..]"
CARD_FILTER = "buyingOptions:{FIXED_PRICE},priceCurrency:USD,price:[1..]"            # trading cards: graded and ungraded copies, any condition (cardvault/asksplit.py)
_BAD = re.compile(r"\b(lot of|lots|custom|bootleg|replica|repro|fake|sticker|box only|empty box|protector|case only|pin only|keychain|read description|damaged|opened|loose|no box|nib only|"
                  r"photo only|picture only|digital|pdf|stl|3d print(?:ed)?|proxy|inspired|unofficial|knock ?off|not authentic|you pick|u pick|you choose|choose your|pick your|sample)\b", re.I)
_STOP = {"the", "a", "an", "of", "and", "pop", "figure", "vinyl", "toy", "with", "by", "edition", "exclusive", "limited", "new", "in", "box"}


def keys():
    app, cert = os.environ.get("EBAY_APP_ID"), os.environ.get("EBAY_CERT_ID")
    if app and cert:
        return app, cert
    try:
        with open(SECRETS, encoding="utf-8-sig") as f:
            d = json.load(f)
        return d.get("ebay_app_id"), d.get("ebay_cert_id")
    except (OSError, ValueError):
        return None, None


class Ebay:
    def __init__(self, app, cert):
        self.app, self.cert, self.token, self.until, self.calls = app, cert, None, 0, 0

    def _auth(self):
        if self.token and time.time() < self.until - 60:
            return
        cred = base64.b64encode(f"{self.app}:{self.cert}".encode()).decode()
        r = requests.post(TOKEN_URL, headers={"Authorization": "Basic " + cred, "Content-Type": "application/x-www-form-urlencoded"},
                          data={"grant_type": "client_credentials", "scope": "https://api.ebay.com/oauth/api_scope"}, timeout=30)
        r.raise_for_status()
        j = r.json()
        self.token, self.until = j["access_token"], time.time() + int(j.get("expires_in", 7200))

    def search(self, query, limit=100, filt=NEW_FILTER):
        self._auth()
        self.calls += 1
        # eBay's own "best match" order, not cheapest-first: cheapest-first fills the sample with the too-good-to-be-true listings fakes are made of
        r = requests.get(SEARCH_URL, params={"q": query, "limit": limit, "filter": filt},
                         headers={"Authorization": "Bearer " + self.token, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"}, timeout=30)
        if r.status_code == 429:
            raise RuntimeError("eBay daily limit reached")
        r.raise_for_status()
        return r.json().get("itemSummaries") or []


def tokens(name):
    return [t for t in re.sub(r"[^a-z0-9]+", " ", re.sub(r"\([^)]*\)|\[[^]]*\]", " ", name.lower())).split() if t not in _STOP and len(t) > 1]


def _trusted(seller):
    """Brand-new or badly rated seller accounts are where most fake listings come from."""
    try:
        return float(seller.get("feedbackPercentage") or 0) >= 95 and int(seller.get("feedbackScore") or 0) >= 10
    except (TypeError, ValueError):
        return False


def _total(it):
    """Price + shipping: a $1 listing with $40 'shipping' is a $41 listing."""
    price = float(it["price"]["value"])
    for opt in it.get("shippingOptions") or []:
        try:
            return price + float((opt.get("shippingCost") or {}).get("value") or 0)
        except (TypeError, ValueError):
            continue
    return price


def _trim(prices):
    """Drop absurd asks and too-good-to-be-true listings: anything outside 2.5x either side of the middle price, then outside the usual spread (Tukey fences)."""
    mid = statistics.median(prices)
    keep = [p for p in prices if mid / 2.5 <= p <= mid * 2.5]
    if len(keep) >= 4:
        q1, _, q3 = statistics.quantiles(keep, n=4)
        lo, hi = q1 - 1.5 * (q3 - q1), q3 + 1.5 * (q3 - q1)
        keep = [p for p in keep if lo <= p <= hi]
    return keep


def candidates(listings, name, number="", group=None):
    """[(per-seller cheapest total price, listing)] for the listings that are really this item: its title holds most of the item's own words (and its printed number, when given), it is not a lot /
    custom / empty box / pick-a-variation listing, and its seller has a real track record.  One listing per seller (one shop can't flood the price); with `group` (a function of the listing), one per
    seller per group - a shop's PSA 10 and its raw copy are two different prices."""
    want = set(tokens(name))
    best = {}
    for it in listings:
        title = it.get("title") or ""
        if _BAD.search(title) or it.get("itemGroupType"):                      # a variation listing shows the price of its cheapest choice, not of this item
            continue
        have = set(tokens(title))
        if not want or len(want & have) < max(1, round(0.7 * len(want))) or not _number_ok(title, number):
            continue
        seller = it.get("seller") or {}
        if not _trusted(seller):
            continue
        try:
            total = _total(it)
        except (KeyError, TypeError, ValueError):
            continue
        who = (seller.get("username") or it.get("itemId"), group(it) if group else "")
        if who not in best or total < best[who][0]:
            best[who] = (total, it)
    return list(best.values())


def _number_ok(title, number):
    """True when no printed number is asked for, the title carries no card number at all (most do not), or it carries this one ("025/165", "#25" and "25/165" all count as 25)."""
    num = re.match(r"\s*#?\s*0*(\d+)", str(number or ""))
    if not num:
        return True
    found = [a or b for a, b in re.findall(r"\b0*(\d{1,4})\s*/\s*0*\d{1,4}\b|#\s*0*(\d{1,4})\b", title)]
    return not found or num.group(1) in found


def median_ask(prices, need=3):
    """(price, how many it is based on) from a list of totals, or (None, 0): outliers trimmed, then the middle of the cheaper half: what a buyer can actually get it for."""
    prices = sorted(prices)
    if len(prices) < need:
        return None, 0
    keep = _trim(prices)
    if len(keep) < need:
        return None, 0
    low = keep[: max(need, len(keep) // 2)]
    return round(statistics.median(low), 2), len(low)


def asking_price(listings, name, need=3):
    """(price, how many sellers it is based on) or (None, 0): see candidates() and median_ask()."""
    return median_ask([p for p, _it in candidates(listings, name)], need)


def steady(conn, cid, day, price, n):
    """False when a new price jumps more than 3x either way from this item's recent asking prices on thin evidence (under 8 sellers) - a wave of fake or absurd listings, not a real move.
    The old price is kept until 3 runs in a row agree on the new one (table ask_jump) - then it is a real change and is taken."""
    try:
        old = [r[0] for r in conn.execute("SELECT usd FROM ask_history WHERE card_id=? AND day < ? AND day >= date(?, '-14 day')", (cid, day, day))]
    except Exception:  # noqa: BLE001 - no history yet
        return True
    if not old or n >= 8:
        return True
    mid = statistics.median(old)
    if mid / 3 <= price <= mid * 3:
        conn.execute("DELETE FROM ask_jump WHERE card_id=?", (cid,))
        return True
    row = conn.execute("SELECT usd, seen FROM ask_jump WHERE card_id=?", (cid,)).fetchone()
    seen = row[1] + 1 if row and row[0] / 1.5 <= price <= row[0] * 1.5 else 1
    if seen >= 3:
        conn.execute("DELETE FROM ask_jump WHERE card_id=?", (cid,))
        return True
    conn.execute("INSERT OR REPLACE INTO ask_jump VALUES(?,?,?)", (cid, price, seen))
    return False


# eBay API License Agreement: copies of eBay content are kept only as long as a feature needs them.  The longest use of ask_history is the 30-day trend
# (trend.ask_rows; the jump guard reads 14 days), so points older than this are dropped - it is a working window, never an archive.  Roadmap 1.3.
ASK_KEEP_DAYS = 31


def record_ask(conn, cid, day, price, n):
    """Keep one asking-price point per item per day in the card list itself (table ask_history), so a trend can be shown for items that have no market price.  It is a trend of ASKING prices - the
    screens say so - because eBay's free API cannot give sold prices.  Points older than ASK_KEEP_DAYS are dropped (eBay's rules)."""
    conn.execute("CREATE TABLE IF NOT EXISTS ask_history(card_id TEXT NOT NULL, day TEXT NOT NULL, usd REAL NOT NULL, n INTEGER, PRIMARY KEY(card_id, day))")
    conn.execute("INSERT OR REPLACE INTO ask_history VALUES(?,?,?,?)", (cid, day, float(price), int(n or 0)))
    conn.execute("DELETE FROM ask_history WHERE day < date(?, ?)", (day, f"-{ASK_KEEP_DAYS} day"))


MAX_AGE_HOURS = askexpiry.MAX_AGE_HOURS


def expire(conn, now=None):
    """eBay API License Agreement: an eBay price is shown for at most MAX_AGE_HOURS after it was read (cardvault/askexpiry.py - the app runs the same check on open and while open).
    Its ask_history points stay for the 31-day trend.  The caller commits.  -> prices removed"""
    misses_table(conn)
    return askexpiry.expire(conn, now)


def misses_table(conn):
    """Items eBay had no good match for, and when (table ask_miss) - so the next runs move on to other items instead of searching the same misses again every day."""
    conn.execute("CREATE TABLE IF NOT EXISTS ask_miss(card_id TEXT PRIMARY KEY, day TEXT NOT NULL)")
    conn.execute("CREATE TABLE IF NOT EXISTS ask_seen(card_id TEXT PRIMARY KEY, at TEXT NOT NULL)")
    conn.execute("CREATE TABLE IF NOT EXISTS ask_priced(card_id TEXT PRIMARY KEY, at TEXT NOT NULL)")                          # when the shown eBay price was read (see expire)
    conn.execute("CREATE TABLE IF NOT EXISTS ask_jump(card_id TEXT PRIMARY KEY, usd REAL NOT NULL, seen INTEGER NOT NULL)")     # big price jumps waiting for confirmation (see steady)


def record_miss(conn, cid, day):
    conn.execute("INSERT OR REPLACE INTO ask_miss VALUES(?,?)", (cid, day))


def record_priced(conn, cid):
    """The item's eBay price was just written (to the minute): expire() takes it off MAX_AGE_HOURS later."""
    conn.execute("INSERT OR REPLACE INTO ask_priced VALUES(?, strftime('%Y-%m-%d %H:%M', 'now'))", (cid,))


def record_seen(conn, cid):
    """When this item was last searched (to the minute), so every priced item is re-checked in turn - the one checked longest ago first."""
    conn.execute("INSERT OR REPLACE INTO ask_seen VALUES(?, strftime('%Y-%m-%d %H:%M', 'now'))", (cid,))


def sold_prices(*_a, **_k):
    """Sold prices need eBay's Marketplace Insights API (approved business accounts only).  Not available - see the module note."""
    raise NotImplementedError("eBay sold prices need Marketplace Insights approval")


def count(eb, query):
    """How many live eBay listings match `query` (the `total` of a one-item Browse search): a demand signal for cardvault/popularity.py.  `eb` is an Ebay; nothing but the number is kept."""
    eb._auth()
    eb.calls += 1
    r = requests.get(SEARCH_URL, params={"q": query, "limit": 1, "filter": "priceCurrency:USD,price:[0.5..]"},
                     headers={"Authorization": "Bearer " + eb.token, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"}, timeout=30)
    if r.status_code == 429:
        raise RuntimeError("eBay daily limit reached")
    r.raise_for_status()
    return int(r.json().get("total") or 0)
