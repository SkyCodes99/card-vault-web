"""Live asking prices from eBay for the items that have no market price anywhere else (Funko, designer toys, plush, playmats ...), through eBay's OFFICIAL Browse API.

What a price means (it is labelled in the app): the typical price of the cheapest matching NEW "Buy It Now" listings that are for sale right now - "eBay asking price (median of N)".  It is not a sold price:
eBay no longer gives sold prices to anyone but approved business partners (Marketplace Insights).  If that approval is ever granted, `sold_prices()` is the one place to change.
Keys: a free eBay developer account gives an App ID and Cert ID.  They are read from the environment (EBAY_APP_ID, EBAY_CERT_ID) or from the hub's secrets file (ebay_app_id / ebay_cert_id)
and are never printed, logged or stored anywhere else."""
import base64
import json
import os
import re
import statistics
import time

import requests

SECRETS = os.path.join(os.path.expanduser("~"), "SkyCloud", "deploy", "azure", ".secrets.json")
TOKEN_URL = "https://api.ebay.com/identity/v1/oauth2/token"
SEARCH_URL = "https://api.ebay.com/buy/browse/v1/item_summary/search"
_BAD = re.compile(r"\b(lot of|lots|custom|bootleg|replica|repro|fake|sticker|box only|empty box|protector|case only|pin only|keychain|read description|damaged|opened|loose|no box|nib only)\b", re.I)
_STOP = {"the", "a", "an", "of", "and", "pop", "figure", "vinyl", "toy", "with", "by", "edition", "exclusive", "limited", "new", "in", "box"}


def keys():
    app, cert = os.environ.get("EBAY_APP_ID"), os.environ.get("EBAY_CERT_ID")
    if app and cert:
        return app, cert
    try:
        with open(SECRETS, encoding="utf-8-sig") as f:
            d = json.load(f)
        return d.get("ebay_app_id"), d.get("ebay_cert_id")
    except (OSError, ValueError):
        return None, None


class Ebay:
    def __init__(self, app, cert):
        self.app, self.cert, self.token, self.until, self.calls = app, cert, None, 0, 0

    def _auth(self):
        if self.token and time.time() < self.until - 60:
            return
        cred = base64.b64encode(f"{self.app}:{self.cert}".encode()).decode()
        r = requests.post(TOKEN_URL, headers={"Authorization": "Basic " + cred, "Content-Type": "application/x-www-form-urlencoded"},
                          data={"grant_type": "client_credentials", "scope": "https://api.ebay.com/oauth/api_scope"}, timeout=30)
        r.raise_for_status()
        j = r.json()
        self.token, self.until = j["access_token"], time.time() + int(j.get("expires_in", 7200))

    def search(self, query, limit=50):
        self._auth()
        self.calls += 1
        r = requests.get(SEARCH_URL, params={"q": query, "limit": limit, "sort": "price", "filter": "buyingOptions:{FIXED_PRICE},conditions:{NEW},priceCurrency:USD,price:[1..]"},
                         headers={"Authorization": "Bearer " + self.token, "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"}, timeout=30)
        if r.status_code == 429:
            raise RuntimeError("eBay daily limit reached")
        r.raise_for_status()
        return r.json().get("itemSummaries") or []


def tokens(name):
    return [t for t in re.sub(r"[^a-z0-9]+", " ", re.sub(r"\([^)]*\)|\[[^]]*\]", " ", name.lower())).split() if t not in _STOP and len(t) > 1]


def asking_price(listings, name, need=3):
    """(price, how many listings it is based on) or (None, 0).  A listing counts only when its title holds most of the item's own words and is not a lot, a custom piece or an empty box."""
    want = set(tokens(name))
    prices = []
    for it in listings:
        title = it.get("title") or ""
        if _BAD.search(title):
            continue
        have = set(tokens(title))
        if not want or len(want & have) < max(1, round(0.7 * len(want))):
            continue
        try:
            prices.append(float(it["price"]["value"]))
        except (KeyError, TypeError, ValueError):
            continue
    if len(prices) < need:
        return None, 0
    prices.sort()
    low = prices[: max(need, len(prices) // 2)]                      # the cheaper half: what a buyer can actually get it for
    return round(statistics.median(low), 2), len(low)


def sold_prices(*_a, **_k):
    """Sold prices need eBay's Marketplace Insights API (approved business accounts only).  Not available - see the module note."""
    raise NotImplementedError("eBay sold prices need Marketplace Insights approval")
