"""Yu-Gi-Oh! deck rules: Main Deck 40-60, Extra Deck 0-15, Side Deck 0-15, at most 3 copies of a card across the three (1 when Limited, 2 when Semi-Limited, none when Forbidden).
The ban lists are YGOPRODeck's own banlist statements for the TCG and the OCG, read with the daily update into the card list (legality.py, cardvault/deckleg.py): never fetched here.
The numbers are in cardvault/data/deck_rules.json ("yugioh")."""
from . import deckcards_tcg, deckleg, deckzones
from .deckmsg import Msg

EXTRA = "Extra Deck"
_WORD = {"banned": "Forbidden", "limited": "Limited", "semi-limited": "Semi-Limited"}
_CODE = {("banned", 0): "ygoForbidden", ("limited", 1): "ygoLimited", ("semi-limited", 2): "ygoSemi"}


def formats(rules):
    return list(((rules.get("yugioh") or {}).get("formats") or {}).items())


def size_range(rules):
    return tuple((rules.get("yugioh") or {}).get("main") or (40, 60))


def counts(zoned, info):
    """-> (main, extra, side) cards."""
    main = extra = 0
    for cid, n in zoned[deckzones.MAIN].items():
        c = info.get(cid)
        if c and c["section"] == EXTRA:
            extra += n
        else:
            main += n
    return main, extra, sum(zoned[deckzones.SIDE].values())


def _copy(n):
    return "copy" if n == 1 else "copies"


def check(v, zoned, info, fmt, rules, rows):
    data = rules.get("yugioh") or {}
    label = (data.get("formats") or {}).get(fmt, fmt.upper())
    probs, notes = [], []
    main, extra, side = counts(zoned, info)
    lo, hi = size_range(rules)
    if not lo <= main <= hi:
        probs.append(Msg("ygoMain", lo=lo, hi=hi, n=main))
    elo, ehi = (data.get("extra") or [0, 15])
    if not elo <= extra <= ehi:
        probs.append(Msg("ygoExtra", lo=elo, hi=ehi, n=extra))
    slo, shi = (data.get("side") or [0, 15])
    if not slo <= side <= shi:
        probs.append(Msg("ygoSide", lo=slo, hi=shi, n=side))
    total, names, unknown = {}, {}, set()
    for z in (deckzones.MAIN, deckzones.SIDE):
        for cid, n in zoned[z].items():
            c = info.get(cid)
            if not c:
                probs.append(Msg("gone"))
                continue
            total[c["key"]] = total.get(c["key"], 0) + n
            names[c["key"]] = deckcards_tcg.strip_tail(c["name"])
    limits, top = data.get("limits") or {}, data.get("copies", 3)
    lm = deckleg.meta(v, "ygoprodeck")
    for key, n in total.items():
        st = deckleg.status(rows, key, label)
        allowed = top
        if st in limits:
            allowed = min(top, limits[st])
        elif st == "not legal":
            probs.append(Msg("ygoPool", name=names[key], fmt=label))
        elif st is None:
            unknown.add(key)
        if n > allowed:
            if st in _WORD:
                code = _CODE.get((st, allowed))                           # (the usual limits have a sentence of their own the screen can translate)
                text = f"{names[key]} is {_WORD[st]} in the {label}: " + (f"only {allowed} {_copy(allowed)} allowed." if allowed else "none allowed.") + f" You have {n}."
                probs.append(Msg(code, name=names[key], fmt=label, n=n) if code else text)
            else:
                probs.append(Msg("ygoCopy1", name=names[key], n=n) if allowed == 1 else Msg("ygoCopies", max=allowed, name=names[key], n=n))
    if not lm["has"]:
        notes.append("The ban list hasn't been read into this card list yet (the daily update does it), so only deck sizes and copies are checked.")
    elif unknown:
        notes.append(f"{len(unknown)} card{'' if len(unknown) == 1 else 's'} not on the ban list data, so not checked against it.")
    return probs, {"dated": lm["dated"] or data.get("checked", ""), "source": data.get("source") or lm["url"], "note": " ".join([data.get("note", "")] + notes).strip()}
