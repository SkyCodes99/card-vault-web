"""Checklist options that fit the game you are in (roadmap "Checklist options that fit each game", 2026-11-10).

One place decides what the rule builder, the filters and the ready-made presets of a checklist offer, from the open game's OWN card list - never from a fixed Pokémon list:
  card games   its rarities, artists, types / colours, card kinds and sets            ("Every Secret Rare", "Every card by <artist>", "Ink: Amber", "<Set> (complete set)")
  toy lines    its editions, who a toy is exclusive to, product types, series / lines  ("Every limited edition", "Exclusive to New York Comic Con", "Product type: Plush")
  Pokémon      the Pokémon presets in checklists.PRESETS (Pokédex, Illustration Rare ... stay Pokémon-only)
It uses the same value rules as the Find & Add sidebar (gamefacets.prune / basics / values), so a checklist can never offer a value the game's own filters would not.
Worked out once per game and card list (db.catalog_fp), kept on the vault."""
import re

from . import gamefacets, taxonomy
from .db import taxonomy_rank
from .games import game_by_id, is_misc
from .toyexclusive import GENERAL

KINDS = ("pokemon", "card", "toy")
CAP = {"rarity": 14, "type": 10, "category": 8, "artist": 10, "set": 8, "facet": 12, "facets": 6}          # the most presets of each sort (a menu, not a catalogue)
CODES = {"C": "Common", "U": "Uncommon", "R": "Rare", "M": "Mythic"}                                         # a list that writes its rarities as one letter (Magic): say what the letter means
_FACET_KEYS_SKIP = {"printing", "fandom", "brand", "tag", "designer"}                                        # name columns or not a way of collecting (the sets and Browse by already cover them)


def kind_of(game_id):
    g = game_by_id(game_id)
    return "pokemon" if g.pokemon else "toy" if is_misc(game_id) else "card"


def facet_group(key, value):
    """The checklist group id of one value of a game's own filter (the same id taxonomy.dynamic_groups gives it)."""
    return f"f:{key}:{taxonomy._slug(value)}"


def _labels(game_id, kind):
    g = game_by_id(game_id)
    voc = gamefacets.vocab(game_id)
    return {"rarity": voc["rarityLabel"], "set": voc["setLabelOne"], "sets": voc["setLabel"], "type": g.type_label, "item": voc["nounOne"], "items": voc["noun"],
            "series": "Series" if kind != "toy" else "Series / group"}


def _prefix_hint(conn):
    """The letters a few card numbers start with (TG, GG, SV ...) for the example in the box; '' for a game whose numbers are plain."""
    seen = {}
    for (lid,) in conn.execute("SELECT local_id FROM cards WHERE local_id GLOB '[A-Za-z]*' LIMIT 3000"):
        m = re.match(r"[A-Za-z]+", str(lid))
        if m and len(m.group(0)) <= 4:
            seen[m.group(0).upper()] = seen.get(m.group(0).upper(), 0) + 1
    return ", ".join(p for p, _ in sorted(seen.items(), key=lambda x: -x[1])[:3])


def _build(v, game_id):
    kind = kind_of(game_id)
    g = game_by_id(game_id)
    conn = v.conn
    out = {"kind": kind, "labels": _labels(game_id, kind), "pokemon": g.pokemon}
    if kind == "pokemon":
        types, rars = list(v.distinct("types")), list(v.distinct("rarity"))
        out.update(rarities=rars, types=types, categories=["Pokemon", "Trainer", "Energy"], hasNumbers=True)
    else:
        b = gamefacets.basics(conn, game_id)
        cats = gamefacets.offered_categories(conn, game_id)
        types = gamefacets.type_names(b["types"])
        if gamefacets.same_as_categories(cats, types):
            types = []
        rars = sorted(gamefacets.type_names(b["rarities"]), key=lambda r: (taxonomy_rank(r, g.rarity_order), r))
        out.update(rarities=rars, types=types, categories=cats, hasArtist=b["hasArtist"],
                   hasNumbers=bool(conn.execute("SELECT 1 FROM cards WHERE local_id IS NOT NULL AND local_id NOT IN ('', '0') LIMIT 1").fetchone()))
    out["prefixHint"] = _prefix_hint(conn) if out.get("hasNumbers") else ""
    words = [w for r in out["rarities"][-4:] for w in [r.lower()] if len(r) < 24]
    out["rarityHint"] = ", ".join(words[-2:])
    out["series"] = [s for s in v.series_names() if s] if kind != "toy" or len(v.series_names()) > 1 else []
    facets = []
    if kind != "pokemon":
        for d in gamefacets.values(conn, game_id):
            if d["key"] in _FACET_KEYS_SKIP or d["key"] == "category":
                continue
            facets.append({"key": d["key"], "label": d["label"], "values": [x["v"] for x in d["values"] if x["v"] != "Regular"]})
    out["facets"] = facets
    return out


def options(v, game_id):
    """The game's checklist vocabulary (see module doc).  Cached per game and card list."""
    fp = v.catalog_fp()
    hit = v.__dict__.get("_listopts")
    if hit and fp is not None and hit[0] == (game_id, fp):
        return hit[1]
    out = _build(v, game_id)
    v._listopts = ((game_id, fp), out)
    return out


# ------------------------------------------------------------------------------------------------ presets
def _p(group, name, rules, mode="cards"):
    return {"group": group, "name": name, "mode": mode, "per_variant": False, "rules": {"include": [rules], "exclude": []}}


def presets(v, game_id):
    """The ready-made starting points plus one live "All sealed from <set>" for every set that has sealed products (sealedsets.py)."""
    from . import sealedsets
    return _base_presets(v, game_id) + sealedsets.presets(v.conn)


def _base_presets(v, game_id):
    """[{group, name, mode, per_variant, rules}] - the ready-made starting points for the open game.  Pokémon: checklists.PRESETS.  Every other game: made from its own card list."""
    from . import checklists
    if kind_of(game_id) == "pokemon":
        return [{"group": "", "name": k, **checklists.PRESETS[k]} for k in checklists.presets_for(game_id and game_by_id(game_id))]
    hit = v.__dict__.get("_listpresets")
    fp = v.catalog_fp()
    if hit and fp is not None and hit[0] == (game_id, fp):
        return hit[1]
    o = options(v, game_id)
    lab, out = o["labels"], []
    if o["rarities"] and o["kind"] == "card":
        out.append({"group": "Basics", "name": f"One of every {lab['rarity'].lower()} (each {lab['set'].lower()})", "mode": "rarity", "per_variant": False, "rules": {"include": [{"all_cards": True}], "exclude": []}})
    out.append(_p("Basics", f"Every {lab['item']} in the game", {"all_cards": True}))
    for r in reversed(o["rarities"][-CAP["rarity"]:]):                                  # the scarcest first
        out.append(_p(f"By {lab['rarity'].lower()}", f"Every {CODES[r]} ({r})" if r in CODES else f"Every {r}" if len(r) > 1 else f"Every {r} {lab['rarity'].lower()}", {"rarities": [r]}))
    if o["kind"] == "toy":
        for d in sorted(o["facets"], key=lambda d: (d["key"] not in ("edition", "exclusive"), 0))[:CAP["facets"]]:          # editions and who it is exclusive to first: what toy collectors ask for
            vals = [x for x in d["values"] if facet_group(d["key"], x) in taxonomy.GROUP_IDS and not (d["key"] == "exclusive" and x.lower() in GENERAL)][:CAP["facet"]]
            if d["key"] == "exclusive" and vals:
                out.append(_p(d["label"], "Every exclusive toy (any shop or show)", {"groups": [facet_group("exclusive", x) for x in d["values"] if facet_group("exclusive", x) in taxonomy.GROUP_IDS]}))
            for x in vals:
                out.append(_p(d["label"], f"{d['label']}: {x}" if d["key"] != "exclusive" else f"Exclusive to {x}", {"groups": [facet_group(d["key"], x)]}))
    for t in o["types"][:CAP["type"]]:
        out.append(_p(lab["type"], f"{lab['type']}: {t}", {"types": [t]}))
    for c in o["categories"][:CAP["category"]]:
        out.append(_p("Kinds" if o["kind"] == "card" else "Product types", f"Every {c}", {"categories": [c]}))
    if o.get("hasArtist"):
        from collections import Counter
        top = Counter({n: len(ids) for n, ids in v.facets()["illustrator"].items() if n and n not in ("None", "N/A")}).most_common(CAP["artist"])
        for n, _c in top:
            out.append(_p("Artists", f"Every card by {n}", {"illustrators": [n]}))
    sets = [s for s in v.sets() if s["n"]]                                                  # (newest first)
    for s in (sorted(sets, key=lambda s: -s["n"]) if o["kind"] == "toy" else sets)[:CAP["set"]]:
        out.append(_p(lab["sets"], f"{s['name']} - every {lab['item']}", {"sets": [s["id"]]}))
    v._listpresets = ((game_id, fp), out)
    return out
