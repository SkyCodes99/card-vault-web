"""Keeps a game's card list in step with TCGplayer's own list (tcgcsv.com): finds new sets, new cards and products, and changed details; reports every difference; applies them when asked.
Also applies the picture-link sources the owner configures (see IMAGE_SOURCES below).

Nothing here touches anyone's collection - only the card list (cards.db) that gets published.  The fetcher is injectable, so tests run without a network.

How each kind of game is treated
  native games (One Piece, Union Arena, Yu-Gi-Oh!, DBS, Magic, Lorcana, Gundam, Riftbound, Palworld): a card's id IS the TCGplayer product number and a set's id IS the TCGplayer
      group number, so tcgcsv is the source: new sets and cards are added, changed names / numbers / rarities / pictures are updated.
  Pokemon (English / Japanese): the card list comes from another source, so tcgcsv only FILLS what is missing: it links cards to their TCGplayer product, fills pictures and rarities that are
      empty, and REPORTS new sets and cards.  The daily update adds them by itself (auto_add, owner 2026-11-05: "the goal was to have the app self-add") and folds such a set into the
      source's own one once the source lists it (merge_twins).
"""
import json
import re
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

from . import games  # noqa: F401  (first: avoids a circular import with tcgcsv)
from .tcgcsv import TcgCsvProvider, _ext, norm_name, store_sealed

BASE = "https://tcgcsv.com/tcgplayer"
from .tcggames import CATEGORIES as CATS, NATIVE, TYPE_FIELDS, is_card        # (the ONE table of TCGplayer games: tcggames.py)
TYPE_FIELD = {**TYPE_FIELDS, "pokemon": "Card Type", "pokemon_jp": "Card Type", "yugioh": "Card Type"}          # what the sync reads as a card's type (Yu-Gi-Oh!'s is its Card Type, not its Attribute)
MARKS_KEY = "tcgsync_marks"                    # meta key: {groupId: modifiedOn} of the groups already in step

# ------------------------------------------------------------------------------------------------ picture-link sources
IMAGE_SOURCES = """Picture-link sources (tools/image_sources.json, or corrections/images.json in Card Data):
{
  "version": 1,
  "sources": [
    {"id": "my-source", "game": "pokemon", "enabled": true, "priority": 10,
     "match": "set_number",                  # how a card is found: tcg_id | card_id | set_number | name_set
     "url": "https://example.com/{set}/{number}.png",    # {set} {number} {number3} {id} {tcg} {name}; must end in .jpg/.jpeg/.png/.webp (or the app adds '#.jpg')
     "sets": ["sv3pt5"],                    # optional: only these set ids
     "mode": "fill",                        # fill = only cards with no picture | replace = always use this link
     "verify": true}                        # check the link answers with a picture before using it
  ],
  "overrides": {"<card id>": "https://example.com/one-card.png"}      # explicit one-card links (always win)
}"""
IMG_EXT = (".jpg", ".jpeg", ".png", ".webp")


def _fold(s):
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode()


def fetch_get(path, tries=5):
    """One tcgcsv list as a python list ([] when it can't be read).  The free feed sometimes drops a connection: wait and try again."""
    import requests
    for i in range(tries):
        try:
            r = requests.get(f"{BASE}/{path}", headers={"User-Agent": "CollectEmAll/3 (sync)"}, timeout=90)
            if r.status_code == 200:
                return r.json().get("results", [])
            if r.status_code == 404:
                return []
        except (requests.RequestException, ValueError):
            pass
        time.sleep(2 + i * 4)
    return None                                   # None = could not be read (different from an empty list)


def fetch_head(url):
    """True when the link answers with a picture."""
    import requests
    try:
        r = requests.get(url, headers={"User-Agent": "CollectEmAll/3 (sync)", "Range": "bytes=0-64"}, timeout=30, stream=True)
        ok = r.status_code in (200, 206) and r.headers.get("content-type", "").lower().startswith("image/")
        r.close()
        return ok
    except requests.RequestException:
        return False


# ------------------------------------------------------------------------------------------------ the check
def _marks(conn):
    try:
        return json.loads((conn.execute("SELECT value FROM meta WHERE key=?", (MARKS_KEY,)).fetchone() or ["{}"])[0] or "{}")
    except (ValueError, TypeError):
        return {}


def _is_card(game, p):
    return is_card(game, _ext(p), p.get("name") or "")


def _num(ext):
    return str(ext.get("Number") or "").split("/")[0].lstrip("0") or "0"


def _clean_name(n):
    import html
    return re.sub(r"\s*\(\d{1,3}\)\s*", " ", html.unescape(n or "")).strip()


def check_game(game, conn, fetch=fetch_get, deep=False, workers=6, progress=None):
    """Compares TCGplayer's list with the open card list.  -> a report dict; nothing is written.
    deep=False only re-reads the groups TCGplayer says changed since the last applied check."""
    cat = CATS[game]
    native = game in NATIVE
    groups = fetch(f"{cat}/groups")
    rep = {"game": game, "when": time.strftime("%Y-%m-%d %H:%M"), "groupsOnTcg": len(groups or []), "checked": 0, "newSets": [], "newCards": [], "changedCards": [], "newSealed": [], "changedSealed": [],
           "linked": [], "variants": [], "errors": [], "marks": {}, "native": native, "_claimed": set()}
    if groups is None:
        rep["errors"].append("TCGplayer's list of sets could not be read (no connection?).")
        rep.pop("_claimed", None)
        return rep
    marks = {} if deep else _marks(conn)
    ours = {str(r[0]): r for r in conn.execute("SELECT id, name, release_date FROM sets")}
    cards = {r["id"]: r for r in _rows(conn, "SELECT id, set_id, local_id, name, rarity, image_base, tcg_id FROM cards")}
    by_tcg = {str(r["tcg_id"]): r for r in cards.values() if r["tcg_id"]}
    sealed = {r["id"]: r for r in _rows(conn, "SELECT id, set_id, name FROM sealed_products")}
    todo = [g for g in groups if str(g["groupId"]) not in marks or marks.get(str(g["groupId"])) != g.get("modifiedOn")]
    rep["checked"] = len(todo)
    done = [0]

    def one(g):
        prod = fetch(f"{cat}/{g['groupId']}/products")
        return g, prod

    with ThreadPoolExecutor(workers) as ex:
        for g, products in ex.map(one, todo):
            done[0] += 1
            if progress:
                progress(done[0], len(todo))
            if products is None:
                rep["errors"].append(f"group {g['groupId']} ({g.get('name')}): could not be read")
                continue
            gid = str(g["groupId"])
            singles = [p for p in products if _is_card(game, p)]
            others = [p for p in products if not _is_card(game, p)]
            known_set = gid in ours if native else (any(str(p["productId"]) in by_tcg for p in singles) or gid in ours)
            if not known_set and singles:                           # a group with only sealed products (an upcoming release) is not a set yet
                rep["newSets"].append({"groupId": g["groupId"], "name": g.get("name"), "published": (g.get("publishedOn") or "")[:10], "cards": len(singles), "sealed": len(others)})
            gset = None if native else _group_set(singles, by_tcg)
            peers = {} if native else _peers(cards, gset)
            for p in singles if known_set else []:                  # the cards of a brand-new set are counted in that set's own entry
                _compare_card(rep, g, p, cards, by_tcg, native, gset, peers)
            for p in others:
                have = sealed.get(str(p["productId"]))
                if have is None:
                    rep["newSealed"].append({"groupId": g["groupId"], "set": g.get("name"), "productId": p["productId"], "name": _clean_name(p["name"])})
                elif norm_name(have["name"]) != norm_name(_clean_name(p["name"])):
                    rep["changedSealed"].append({"id": str(p["productId"]), "old": have["name"], "new": _clean_name(p["name"])})
            rep["marks"][gid] = g.get("modifiedOn")
    rep.pop("_claimed", None)
    return rep


def _rows(conn, sql):
    cur = conn.execute(sql)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _group_set(singles, by_tcg):
    """Our set a TCGplayer group belongs to: the set most of its already-linked products sit in (None when none are linked yet)."""
    seen = {}
    for p in singles:
        c = by_tcg.get(str(p["productId"]))
        if c:
            seen[c["set_id"]] = seen.get(c["set_id"], 0) + 1
    return max(seen, key=seen.get) if seen else None


def _base(name):
    return norm_name(re.sub(r"\s*[\(\-].*", "", name or ""))


def _peers(cards, gset):
    """{(number, base name): [our cards]} inside one set - used to tell 'one of our cards that has no link yet' and 'a pattern variant of a card we have' from a really new card."""
    out = {}
    for c in cards.values():
        if c["set_id"] == gset:
            out.setdefault((str(c["local_id"]).split("/")[0].lstrip("0") or "0", _base(c["name"])), []).append(c)
    return out


def _compare_card(rep, g, p, cards, by_tcg, native, gset, peers):
    pid = str(p["productId"])
    ext = _ext(p)
    name, number, rarity = _clean_name(p["name"]), str(ext.get("Number") or ""), ext.get("Rarity")
    have = cards.get(pid) if native else by_tcg.get(pid)
    if have is None:
        if not native and gset:
            near = peers.get((_num(ext), _base(name)), [])
            free = next((c for c in near if not c["tcg_id"] and c["id"] not in rep["_claimed"]), None)
            if free and name.count("(") == 0:                                        # one of our cards that just needs its TCGplayer link
                rep["_claimed"].add(free["id"])
                rep["linked"].append({"id": free["id"], "productId": pid, "name": free["name"]})
                return
            if near:                                                                  # a pattern variant (Poke Ball, Master Ball...) of a card we already have
                rep["variants"].append({"groupId": g["groupId"], "set": g.get("name"), "productId": pid, "name": name, "number": number})
                return
        rep["newCards"].append({"groupId": g["groupId"], "set": g.get("name"), "productId": pid, "name": name, "number": number, "rarity": rarity or ""})
        return
    if native:
        if norm_name(have["name"]) != norm_name(name):
            rep["changedCards"].append({"id": have["id"], "field": "name", "old": have["name"], "new": name})
        if str(have["local_id"] or "") != number:
            rep["changedCards"].append({"id": have["id"], "field": "number", "old": have["local_id"], "new": number})
        if (rarity or "") != (have["rarity"] or ""):
            rep["changedCards"].append({"id": have["id"], "field": "rarity", "old": have["rarity"], "new": rarity})
    elif not have["rarity"] and rarity:
        rep["changedCards"].append({"id": have["id"], "field": "rarity", "old": have["rarity"], "new": rarity})
    if not have["image_base"] and p.get("imageUrl"):
        rep["changedCards"].append({"id": have["id"], "field": "image", "old": "", "new": p["imageUrl"]})


# ------------------------------------------------------------------------------------------------ applying
def apply_report(game, conn, rep, fetch=fetch_get, add_new_sets=False, add_missing_cards=False, workers=6):
    """Writes what the report found.  -> {what: count}.  Pokemon: links / fills only; new sets and cards only when asked."""
    cat, native = CATS[game], game in NATIVE
    prov = TcgCsvProvider(game, cat, TYPE_FIELD[game])
    day = time.strftime("%Y-%m-%d")
    out = {"setsAdded": 0, "cardsAdded": 0, "cardsUpdated": 0, "linked": 0, "picturesFilled": 0, "sealedAdded": 0, "sealedRenamed": 0}
    groups = {str(g["groupId"]): g for g in (fetch(f"{cat}/groups") or [])}
    wanted = {str(x["groupId"]) for x in rep["newSets"]} | {str(x["groupId"]) for x in rep["newCards"]} | {str(x["groupId"]) for x in rep["newSealed"]}
    if native:
        wanted |= {gid for gid in groups if gid in rep["marks"]}                     # native games: re-store every changed group (cards, sealed, prices) as TCGplayer lists them

    def one(gid):
        return gid, fetch(f"{cat}/{gid}/products"), fetch(f"{cat}/{gid}/prices")

    with ThreadPoolExecutor(workers) as ex:
        loaded = list(ex.map(one, sorted(wanted & set(groups))))
    new_set_ids = {str(x["groupId"]) for x in rep["newSets"]}
    for gid, products, prices in loaded:
        if products is None:
            continue
        g = groups[gid]
        singles = [p for p in products if _is_card(game, p)]
        others = [p for p in products if not _is_card(game, p)]
        prices = prices or []
        if native:
            if singles:
                had = conn.execute("SELECT 1 FROM sets WHERE id=?", (gid,)).fetchone()
                n0 = conn.execute("SELECT COUNT(*) FROM cards WHERE set_id=?", (gid,)).fetchone()[0]
                prov._store_group(conn, g, singles, prices, day)
                out["setsAdded"] += 0 if had else 1
                out["cardsAdded"] += conn.execute("SELECT COUNT(*) FROM cards WHERE set_id=?", (gid,)).fetchone()[0] - n0
        elif gid in new_set_ids and add_new_sets and singles:
            prov._store_group(conn, g, singles, prices, day)
            conn.execute("UPDATE sets SET serie='Miscellaneous' WHERE id=? AND (serie IS NULL OR serie='')", (gid,))       # a TCGplayer-only set: filed with the promos and specials
            place_set(conn, gid)                                                                                          # ...unless its code says which era it is
            conn.execute("UPDATE cards SET tcg_id=id WHERE set_id=? AND tcg_id IS NULL", (gid,))
            out["setsAdded"] += 1
            out["cardsAdded"] += len(singles)
        elif add_missing_cards:
            have_ids = {str(r[0]) for r in conn.execute("SELECT id FROM cards")}
            sid = _set_of_group(conn, singles)
            miss = [p for p in singles if str(p["productId"]) not in have_ids and str(p["productId"]) in {str(x["productId"]) for x in rep["newCards"]}]
            if sid and miss:
                prov._store_group(conn, g, miss, prices, day, set_id=sid, write_set=False)
                conn.execute(f"UPDATE cards SET tcg_id=id WHERE set_id=? AND tcg_id IS NULL AND id IN ({','.join('?' * len(miss))})", [sid] + [str(p["productId"]) for p in miss])
                out["cardsAdded"] += len(miss)
        if others:
            before = conn.execute("SELECT COUNT(*) FROM sealed_products").fetchone()[0]
            store_sealed(conn, g, others, prices, day)
            out["sealedAdded"] += conn.execute("SELECT COUNT(*) FROM sealed_products").fetchone()[0] - before
    if native:                                                                       # the card id IS the product id: price history and trends find a card by that link
        conn.execute("UPDATE cards SET tcg_id=id WHERE tcg_id IS NULL")
    for x in rep["linked"]:                                                          # Pokemon cards that just needed their TCGplayer link
        conn.execute("UPDATE cards SET tcg_id=? WHERE id=? AND tcg_id IS NULL", (x["productId"], x["id"]))
        out["linked"] += 1
    if not native:
        for x in rep["changedCards"]:
            if x["field"] == "image":
                out["picturesFilled"] += conn.execute("UPDATE cards SET image_base=? WHERE id=? AND (image_base IS NULL OR image_base='')", (x["new"], x["id"])).rowcount
            elif x["field"] == "rarity":
                out["cardsUpdated"] += conn.execute("UPDATE cards SET rarity=? WHERE id=? AND (rarity IS NULL OR rarity='')", (x["new"], x["id"])).rowcount
    else:
        out["cardsUpdated"] = len(rep["changedCards"])
    for x in rep["changedSealed"]:
        out["sealedRenamed"] += conn.execute("UPDATE sealed_products SET name=?, norm=? WHERE id=?", (x["new"], norm_name(x["new"]), x["id"])).rowcount
    marks = _marks(conn)
    marks.update({k: v for k, v in rep["marks"].items() if v is not None})
    conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (MARKS_KEY, json.dumps(marks)))
    conn.execute("INSERT OR REPLACE INTO meta VALUES('tcgsync_last', ?)", (time.strftime("%Y-%m-%d %H:%M"),))
    conn.commit()
    return out


AUTO_KEY = "tcgsync_auto_sets"                 # meta key: {groupId: {"name", "added"}} of the sets the daily update added from TCGplayer alone (merge_twins only ever touches these)
_CODED = re.compile(r"^([A-Za-z]+)(\d+(?:\.\d+)?)\s*:\s*(.+)$")            # TCGplayer's "ME06: Delta Reign", "SV10: Destined Rivals"


def place_set(conn, gid):
    """File a set added from TCGplayer alone where it belongs: its code ("ME06") matches the ids of the era's other sets (me05, me04...), so it takes that era's series and its plain
    name ("Delta Reign").  A set with no code, or a code no other set shares, stays with the promos and specials.  Safe to run again.  -> True when it moved"""
    row = conn.execute("SELECT name, serie FROM sets WHERE id=?", (gid,)).fetchone()
    m = _CODED.match((row[0] or "").strip()) if row and (row[1] or "Miscellaneous") == "Miscellaneous" else None
    if not m:
        return False
    code = m.group(1).lower()
    era = conn.execute("SELECT serie, COUNT(*) n FROM sets WHERE id != ? AND lower(id) GLOB ? AND serie IS NOT NULL AND serie NOT IN ('', 'Miscellaneous') GROUP BY serie ORDER BY n DESC LIMIT 1",
                       (gid, code + "[0-9]*")).fetchone()
    if not era:
        return False
    conn.execute("UPDATE sets SET serie=?, name=?, fold=NULL WHERE id=?", (era[0], m.group(3).strip(), gid))
    return True


def auto_add(game, conn, fetch=fetch_get):
    """The daily update's step for Pokemon: a new release TCGplayer already lists (before the card list's own source has it) is added straight away - new sets, and new cards of sets we
    have.  Each set added this way is remembered, so merge_twins can fold it into the source's own set once that arrives.  -> {what: count}"""
    rep = check_game(game, conn, fetch=fetch)
    if rep["errors"] and not rep["marks"]:
        return {"error": rep["errors"][0]}
    out = apply_report(game, conn, rep, fetch=fetch, add_new_sets=True, add_missing_cards=True)
    auto = json.loads((conn.execute("SELECT value FROM meta WHERE key=?", (AUTO_KEY,)).fetchone() or ["{}"])[0] or "{}")
    for s in rep["newSets"]:
        gid = str(s["groupId"])
        if conn.execute("SELECT 1 FROM sets WHERE id=?", (gid,)).fetchone():
            auto.setdefault(gid, {"name": s.get("name") or "", "added": time.strftime("%Y-%m-%d")})
    out["setsPlaced"] = sum(place_set(conn, gid) for gid in auto)                        # also files sets added before place_set existed
    conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (AUTO_KEY, json.dumps(auto, sort_keys=True)))
    conn.commit()
    return out


def _numkey(local_id):
    return str(local_id or "").split("/")[0].lstrip("0") or "0"


def _same_set_name(group_name, set_name):
    a, b = norm_name(_fold(group_name.split(":")[-1])), norm_name(_fold(set_name))                       # "ME06: Delta Reign" vs "Delta Reign"
    return bool(a and b) and (a == b or a in b or b in a)


def merge_twins(conn, share=0.6):
    """When the card list's own source (TCGdex) adds a set that auto_add already added from TCGplayer, every card of it is listed twice.  The source's card stays (the daily refresh would
    only bring it back), takes over the TCGplayer link and price, and the TCGplayer-only id goes into meta 'id_redirects' so everyone's copies, wishlist and checklist ticks move to it.
    Only certain cases: a set auto_add added, a source set of the same name, same printed number + same name, and most of the set matching.  -> cards merged"""
    auto = json.loads((conn.execute("SELECT value FROM meta WHERE key=?", (AUTO_KEY,)).fetchone() or ["{}"])[0] or "{}")
    if not auto:
        return 0
    red = json.loads((conn.execute("SELECT value FROM meta WHERE key='id_redirects'").fetchone() or ["{}"])[0] or "{}")
    names = {r[0]: r[1] or "" for r in conn.execute("SELECT id, name FROM sets")}
    merged = 0
    for gid, info in list(auto.items()):
        rows = conn.execute("SELECT id, local_id, name, tcg_id, price_usd, price_kind, price_updated FROM cards WHERE set_id=?", (gid,)).fetchall()
        if not rows:
            continue
        for nset in [s for s in names if s != gid and not s.isdigit() and _same_set_name(info.get("name") or names.get(gid, ""), names[s])]:
            twins = {}
            for cid, lid, name in conn.execute("SELECT id, local_id, name FROM cards WHERE set_id=? AND (tcg_id IS NULL OR tcg_id='')", (nset,)):
                twins.setdefault((_numkey(lid), _base(name)), []).append(cid)
            pairs = [(r, twins[(_numkey(r[1]), _base(r[2]))].pop(0)) for r in rows if twins.get((_numkey(r[1]), _base(r[2])))]
            if len(pairs) < share * len(rows):
                continue                                                              # not certainly the same set
            for (cid, _lid, _name, tcg, pr, kind, upd), keep in pairs:
                conn.execute("UPDATE cards SET tcg_id=?, price_usd=COALESCE(price_usd, ?), price_kind=COALESCE(price_kind, ?), price_updated=COALESCE(price_updated, ?) WHERE id=?",
                             (tcg or cid, pr, kind, upd, keep))
                conn.execute("DELETE FROM cards WHERE id=?", (cid,))
                red = {k: (keep if v == cid else v) for k, v in red.items()}
                red[cid] = keep
                merged += 1
            conn.execute("UPDATE cards SET set_id=? WHERE set_id=?", (nset, gid))                      # cards the source does not list (yet) move into its set too
            conn.execute("UPDATE sealed_products SET set_id=? WHERE set_id=?", (nset, gid))
            conn.execute("DELETE FROM sets WHERE id=?", (gid,))
            del auto[gid]
            break
    conn.execute("INSERT OR REPLACE INTO meta VALUES('id_redirects', ?)", (json.dumps(red, ensure_ascii=False, sort_keys=True),))
    conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (AUTO_KEY, json.dumps(auto, sort_keys=True)))
    conn.commit()
    return merged


def _set_of_group(conn, singles):
    """Our set a TCGplayer group belongs to: the set most of its already-linked cards are in."""
    ids = [str(p["productId"]) for p in singles]
    if not ids:
        return None
    marks = ",".join("?" * len(ids))
    r = conn.execute(f"SELECT set_id, COUNT(*) FROM cards WHERE tcg_id IN ({marks}) OR id IN ({marks}) GROUP BY set_id ORDER BY 2 DESC LIMIT 1", ids + ids).fetchone()
    return r[0] if r else None


# ------------------------------------------------------------------------------------------------ picture-link sources
def validate_sources(cfg):
    """-> list of problems (empty = fine).  Checked before anything is applied."""
    bad = []
    if not isinstance(cfg, dict):
        return ["The file must be a JSON object with 'sources' and/or 'overrides'."]
    ids = set()
    for i, s in enumerate(cfg.get("sources") or []):
        tag = f"source #{i + 1} ({s.get('id', '?')})"
        if not s.get("id"):
            bad.append(f"{tag}: needs an 'id'")
        elif s["id"] in ids:
            bad.append(f"{tag}: the id is used twice")
        ids.add(s.get("id"))
        if s.get("game") not in CATS:
            bad.append(f"{tag}: 'game' must be one of {', '.join(CATS)}")
        if s.get("match", "set_number") not in ("tcg_id", "card_id", "set_number", "name_set"):
            bad.append(f"{tag}: 'match' must be tcg_id, card_id, set_number or name_set")
        if not str(s.get("url", "")).startswith("https://"):
            bad.append(f"{tag}: 'url' must be an https:// link template")
        if s.get("mode", "fill") not in ("fill", "replace"):
            bad.append(f"{tag}: 'mode' must be fill or replace")
    for cid, url in (cfg.get("overrides") or {}).items():
        if not str(url).startswith("https://"):
            bad.append(f"override {cid}: the link must start with https://")
    return bad


def _final_url(url):
    return url if url.lower().split("?")[0].endswith(IMG_EXT) else url + "#.jpg"


def plan_images(game, conn, cfg):
    """-> [{id, url, source, old}] the picture links the configured sources would set for this game's cards (nothing is written)."""
    cards = _rows(conn, "SELECT c.id, c.set_id, c.local_id, c.name, c.tcg_id, c.image_base, s.name AS set_name FROM cards c LEFT JOIN sets s ON s.id=c.set_id")
    chosen = {}                                                                      # card id -> (priority, entry): a lower number wins
    for s in sorted((x for x in (cfg.get("sources") or []) if x.get("game") == game and x.get("enabled", True)), key=lambda x: x.get("priority", 100)):
        only = set(map(str, s.get("sets") or []))
        mode = s.get("mode", "fill")
        for c in cards:
            if (only and str(c["set_id"]) not in only) or c["id"] in chosen:
                continue
            if mode == "fill" and c["image_base"]:
                continue
            number = str(c["local_id"] or "")
            vals = {"set": c["set_id"], "number": number, "number3": number.zfill(3) if number.isdigit() else number, "id": c["id"], "tcg": c["tcg_id"] or "", "name": _fold(c["name"]).replace(" ", "-").lower()}
            m = s.get("match", "set_number")
            if (m == "tcg_id" and not c["tcg_id"]) or (m in ("set_number", "name_set") and not number):
                continue
            url = s["url"]
            for k, v in vals.items():
                url = url.replace("{" + k + "}", str(v))
            chosen[c["id"]] = {"id": c["id"], "url": _final_url(url), "source": s["id"], "old": c["image_base"] or "", "verify": bool(s.get("verify", True))}
    for cid, url in (cfg.get("overrides") or {}).items():
        c = next((x for x in cards if x["id"] == cid), None)
        if c:
            chosen[cid] = {"id": cid, "url": _final_url(url), "source": "override", "old": c["image_base"] or "", "verify": False}
    return list(chosen.values())


def apply_images(conn, plan, verify=fetch_head, workers=8):
    """Writes the planned picture links (each checked first when its source asks for it).  -> {applied, rejected: [(id, url)]}."""
    def ok(x):
        return (not x["verify"]) or verify(x["url"].split("#")[0])

    with ThreadPoolExecutor(workers) as ex:
        results = list(ex.map(ok, plan))
    applied, rejected = 0, []
    for x, good in zip(plan, results):
        if good:
            conn.execute("UPDATE cards SET image_base=? WHERE id=?", (x["url"], x["id"]))
            applied += 1
        else:
            rejected.append((x["id"], x["url"]))
    conn.commit()
    return {"applied": applied, "rejected": rejected}


# ------------------------------------------------------------------------------------------------ the written report
def render_markdown(reports):
    lines = ["# TCGplayer sync report", ""]
    for r in reports:
        lines += [f"## {r['game']}  ({r['when']})", f"- groups on TCGplayer: {r['groupsOnTcg']} · re-read: {r['checked']}",
                  f"- new sets: {len(r['newSets'])} · new cards: {len(r['newCards'])} · changed cards: {len(r['changedCards'])} · linked: {len(r['linked'])}",
                  f"- pattern variants of cards we have: {len(r['variants'])} · new sealed products: {len(r['newSealed'])} · renamed sealed: {len(r['changedSealed'])}"]
        for e in r["errors"][:10]:
            lines.append(f"- problem: {e}")
        for s in r["newSets"][:40]:
            lines.append(f"  - NEW SET {s['name']} ({s['groupId']}, {s['published']}): {s['cards']} cards, {s['sealed']} sealed products")
        for c in r["newCards"][:40]:
            lines.append(f"  - new card {c['name']} #{c['number']} in {c['set']} ({c['rarity'] or 'no rarity'})")
        for c in r["changedCards"][:40]:
            lines.append(f"  - changed {c['field']} of {c['id']}: {c['old']!r} -> {c['new']!r}")
        lines.append("")
    return "\n".join(lines)
