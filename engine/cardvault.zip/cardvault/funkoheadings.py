"""Which Browse heading a Funko set sits under.

The Funko list has one set per fandom ('Marvel', 'Star Wars') - but hobbyDB also files Pops by product line ('Funko Mystery Minis', 'Wacky Wobblers'), by convention ('San Diego Comic-Con 2019') and by
store, and all of those used to land under one 'Other fandoms' heading with 280 small franchises.  The heading is worked out from the set's name: the big fandoms by exact name, the rest by the
words in it, in this order - event, store, product line, then a franchise's genre.  A name no rule recognises stays under 'Other fandoms'.  (Changing a heading moves no Pop and no one's collection.)"""
import re

OTHER = "Other fandoms"
EVENTS = "Conventions & events"
STORES = "Stores & exclusives"
LINES = "Product lines"
SIGNED = "Signed Pops"

# the fandoms the list names itself, by exact set name
_EXACT = {
    "Television": "TV & Movies", "Movies": "TV & Movies", "Movie Moments": "TV & Movies", "Star Wars": "TV & Movies", "Harry Potter": "TV & Movies", "Game of Thrones": "TV & Movies",
    "Fantastic Beasts and Where to Find Them": "TV & Movies", "Doctor Who": "TV & Movies", "Stranger Things": "TV & Movies", "Director": "TV & Movies", "Broadway": "TV & Movies", "SNL": "TV & Movies",
    "Animation": "Animation & Cartoons", "Disney": "Animation & Cartoons", "Pixar": "Animation & Cartoons", "Hello Kitty": "Animation & Cartoons", "Sanrio": "Animation & Cartoons",
    "South Park": "Animation & Cartoons", "Sesame Street": "Animation & Cartoons", "Pokemon": "Animation & Cartoons", "Asia": "Animation & Cartoons", "Monster High": "Animation & Cartoons",
    "Marvel": "Comics & Heroes", "Heroes": "Comics & Heroes", "DC": "Comics & Heroes", "Comics": "Comics & Heroes", "Comic Moments": "Comics & Heroes", "Books": "Comics & Heroes",
    "Games": "Video & Board Games", "8-Bit": "Video & Board Games", "Halo": "Video & Board Games", "Board Games": "Video & Board Games",
    "NFL": "Sports", "NBA": "Sports", "MLB": "Sports", "NHL": "Sports", "WWE": "Sports", "UFC": "Sports", "Football": "Sports", "Basketball": "Sports", "Hockey": "Sports", "Wrestling": "Sports",
    "Signed Pops": SIGNED, "Rocks": "Music", "Music": "Music", "Royals": "Music", "Drag Queens": "Music",
}

# (heading, words in the set's name), most specific first.  Matched anywhere in the name, case-insensitively.
_BY_NAME = (
    (EVENTS, r"comic[- ]?con|comikaze|\be3 \d|designercon|wondercon|fundays|convention|fan ?expo|toy fair|\bpax\b|emerald city|sdcc|nycc|eccc"),
    (STORES, r"hot topic|spencer'?s|foot locker|toy tokyo|galactic toys|gemini collectibles|grosnor|diamond comic|jollibee|^vans$|^bait$|loungefly|nerd block|boxlunch|gamestop|barnes|walmart|target\b"),
    (LINES, r"mystery (?:mini|box|keychain)|collectors?'? box|\bpez\b|wacky wobbler|^wobblers?$|pocket (?:pop|and tee)|hikari|prototype|mymoji|pint size|reaction figure|soda figure|paka paka|plush|vynl|smuggler|"
            r"shirt pack|tee pack|pint pack|^funko|funko-shop|funko'?s\b|from funko|retro freddy|spastik|fantastik|rock candy|retro toys|dorbz|vinyl (?:idolz|invaders|sugar|vixens|cubed)|^blox$|boxos|mopeez|nodniks|snapsies|"
            r"fruit bats|soup troop|yummy world|legacy collection|legion of collectors|^minis$|mini vinyl|deluxe|^rides?$|^town$|tin-tastic|keepsakes|ornament|keychain|marvel collector corps|art series|"
            r"^home$|^pets$|^monsters$|^myths$|^zodiac$|heroworld|handy dandy|savage world|^other vinyl$|peek-a-boo|cupcake"),
    ("Comics & Heroes", r"batman|\bdc\b|deadpool|marvel|spider|stan lee|infinity warps|primal age|fantastic four|venom|x-men|justice league|superman|wonder woman|suicide squad|^comic$"),
    ("TV & Movies", r"breaking bad|\bamc\b|\bhbo\b|\btbs\b|walking dead|x-files|land of the lost|ghostbusters|beetlejuice|^directors?$|hamilton|muppets|star wars|star trek|fantastic beasts|harry potter|conan|"
                    r"^horror$|^sci-fi$|warner bros|diary of a wimpy|garbage pail|^gpk$|\(film\)|\(tv channel\)|\(\d{4} film\)|walking dead"),
    ("Animation & Cartoons", r"pikachu|eevee|pokemon|bananya|demon slayer|dragon ball|fullmetal|inuyasha|my hero|my little pony|nickelodeon|pusheen|trolls|transformers|uglydoll|ugly doll|shopkins|cartoon classics|"
                            r"disney|mickey|nightmare before|haunted mansion|sleeping beauty|how to train|despicable|minions|snowflake mountain|frozen|dr\. seuss|play-doh|playmobil|anime|mulan|pixar|scribblenauts"),
    ("Video & Board Games", r"five nights|fnaf|league of legends|video games?|^magic$|munchkin|pocket god|destiny|kingdom hearts|persona|overwatch|zelda|mario|sonic|pac-?man|board game|gotham knights"),
    ("Sports", r"baseball|football|golf|tennis|nascar|^college$|^sports|aquasox|soccer|basketball|hockey|\bnfl\b|\bnba\b|\bmlb\b|\bnhl\b|wwe|ufc|boxing|olympic"),
)
_COMPILED = tuple((heading, re.compile(words, re.I)) for heading, words in _BY_NAME)


def heading_of(set_name):
    """The Browse heading for a Funko set called `set_name`."""
    name = (set_name or "").strip()
    if name in _EXACT:
        return _EXACT[name]
    for heading, rule in _COMPILED:
        if rule.search(name):
            return heading
    return OTHER
