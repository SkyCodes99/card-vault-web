"""Text and Excel exports of card lists (missing cards, owned cards...).  Works on the plain row dicts made by
checklists.missing_rows / owned_rows, so it has no GUI dependency."""
import datetime
import io
import os

from .db import image_file

COLUMNS = ["Image", "Set", "#", "Name", "Rarity", "Kind of card", "Type", "Stage", "HP", "Variant", "Illustrator", "Released", "Price (USD)", "Card ID", "Have it?"]


def _num(r):
    off = f"/{r['official']}" if r.get("official") else ""
    num = str(r["number"])
    return f"{num.zfill(3) if num.isdigit() else num}{off}"


def estimated_cost(rows):
    """Cheapest way to finish: for Pokédex-style rows only the cheapest candidate per Pokémon is counted."""
    total, seen = 0.0, {}
    for r in rows:
        p = r.get("price_usd") or 0
        if r.get("group"):
            if r["group"] not in seen or (p and p < seen[r["group"]]) or not seen[r["group"]]:
                seen[r["group"]] = p
        else:
            total += p
    return total + sum(seen.values())


def export_txt(path, title, rows, owned, total, which="missing"):
    pct = (100.0 * owned / total) if total else 0.0
    lines = [f"Collect Em All - {which} cards", f"List: {title}",
             f"Created: {datetime.datetime.now():%Y-%m-%d %H:%M}",
             f"Progress: {owned:,} / {total:,} ({pct:.1f}%)   {which.capitalize()}: {len(rows):,}", ""]
    dex_mode = any(r.get("dex_label") for r in rows)
    if dex_mode:
        groups = {}
        for r in rows:
            groups.setdefault(r["dex_label"], []).append(r)
        for label, rs in groups.items():
            lines.append(label + f"  ({len(rs)} qualifying card{'s' if len(rs) != 1 else ''})")
            for r in rs:
                price = f"  ${r['price_usd']:,.2f}" if r.get("price_usd") is not None else ""
                lines.append(f"    {r['set']} {_num(r)}  {r['name']}  [{r['rarity']}]{price}")
    else:
        groups = {}
        for r in rows:
            groups.setdefault((r["set"] or r["set_id"]), []).append(r)
        for sname, rs in groups.items():
            lines.append(f"{sname}  - {len(rs)} {which}")
            for r in rs:
                bits = [f"#{_num(r)}", r["name"]]
                if r["variant"]:
                    bits.append(f"({r['variant']})")
                if r["rarity"]:
                    bits.append(f"- {r['rarity']}")
                if r["types"]:
                    bits.append(f"- {r['types']}")
                if r["illustrator"]:
                    bits.append(f"- Illus. {r['illustrator']}")
                if r.get("price_usd") is not None:
                    bits.append(f"- ${r['price_usd']:,.2f}")
                lines.append("    " + " ".join(bits))
            lines.append("")
    if which == "missing":
        lines.append(f"Estimated market cost to complete: ${estimated_cost(rows):,.2f}")
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    return len(rows)


def _thumb_bytes(path, max_w=90, max_h=126):
    from PIL import Image
    with Image.open(path) as im:
        im = im.convert("RGB")
        im.thumbnail((max_w, max_h))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=82)
        buf.seek(0)
        return buf, im.size


def export_xlsx(path, title, rows, owned, total, gdir=None, with_images=True, which="missing", progress=None, extra=None, fetch=None):
    """extra(row) -> dict of more card facts (kind, stage, hp, released, exact rarity); fetch(row) -> picture bytes when no picture file is stored (browser build)."""
    from openpyxl import Workbook
    from openpyxl.drawing.image import Image as XLImage
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = which.capitalize()
    head_fill = PatternFill("solid", fgColor="1F3A5F")
    zebra = PatternFill("solid", fgColor="F2F5FA")
    thin = Side(style="thin", color="D0D7E2")
    border = Border(top=thin, bottom=thin, left=thin, right=thin)
    cols = COLUMNS if with_images else COLUMNS[1:]
    ws.append(cols)
    for i in range(1, len(cols) + 1):
        c = ws.cell(row=1, column=i)
        c.font = Font(bold=True, color="FFFFFF", size=11)
        c.fill = head_fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 24
    widths = [14, 24, 10, 26, 24, 14, 14, 12, 7, 14, 20, 12, 12, 16, 9]
    widths = widths if with_images else widths[1:]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    row_h = 74 if with_images else 18
    for n, r in enumerate(rows, start=2):
        x = (extra(r) if extra else {}) or {}
        vals = [r["set"] or r["set_id"], _num(r), r["name"] + (f"  [{r['dex_label']}]" if r.get("dex_label") else ""),
                x.get("rarity") or r["rarity"], x.get("kind", ""), r["types"], x.get("stage", ""), x.get("hp", ""), r["variant"], r["illustrator"], x.get("released", ""),
                r.get("price_usd"), r.get("card_id", ""), "☐"]
        ws.append(([""] if with_images else []) + vals)
        ws.row_dimensions[n].height = row_h
        for col in range(1, len(cols) + 1):
            cell = ws.cell(row=n, column=col)
            cell.border = border
            cell.alignment = Alignment(vertical="center", wrap_text=True, horizontal="center" if col in (1, 3, 9, len(cols) - 1, len(cols)) else "left")
            if n % 2 == 1:
                cell.fill = zebra
        price_col = len(cols) - 2
        ws.cell(row=n, column=price_col).number_format = '"$"#,##0.00'
        if with_images and gdir and r.get("card_id"):
            done = False
            for q in ("high", "low"):
                p = image_file(gdir, q, r["card_id"], r["set_id"])
                if os.path.exists(p):
                    try:
                        buf, (w, h) = _thumb_bytes(p)
                        img = XLImage(buf)
                        img.width, img.height = w * 0.68, h * 0.68
                        ws.add_image(img, f"A{n}")
                    except Exception:  # noqa: BLE001 - a bad picture must not break the whole export
                        pass
                    done = True
                    break
            if not done and fetch:
                try:
                    data = fetch(r)
                    if data:
                        buf, (w, h) = _thumb_bytes(io.BytesIO(data))
                        img = XLImage(buf)
                        img.width, img.height = w * 0.68, h * 0.68
                        ws.add_image(img, f"A{n}")
                except Exception:  # noqa: BLE001
                    pass
        if progress and n % 50 == 0:
            progress(n - 1, len(rows))
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{len(rows) + 1}"
    ws.sheet_view.zoomScale = 100

    s = wb.create_sheet("Summary", 0)
    pct = (100.0 * owned / total) if total else 0.0
    items = [("Collect Em All", ""), ("List", title), ("Created", f"{datetime.datetime.now():%Y-%m-%d %H:%M}"),
             ("Owned", f"{owned:,} of {total:,}"), ("Progress", pct / 100.0), (which.capitalize(), len(rows))]
    if which == "missing":
        items.append(("Est. cost to complete (market)", estimated_cost(rows)))
    for i, (k, v) in enumerate(items, 1):
        s.cell(row=i, column=1, value=k).font = Font(bold=True, size=14 if i == 1 else 11)
        c = s.cell(row=i, column=2, value=v)
        if k == "Progress":
            c.number_format = "0.0%"
        if k.startswith("Est."):
            c.number_format = '"$"#,##0.00'
        c.alignment = Alignment(horizontal="left")
    s.column_dimensions["A"].width = 32
    s.column_dimensions["B"].width = 34
    wb.active = 1
    wb.save(path)
    return len(rows)


def owned_rows(vault, progress):
    rows = []
    for t in progress.view("owned"):
        cids = t.owned_cards if t.candidates else [t.card_id]
        for cid in cids:
            c = vault.card_light(cid)
            if not c:
                continue
            rows.append({
                "card_id": cid, "set_id": c["set_id"], "set": c["set_name"], "number": c["local_id"], "official": c.get("official"),
                "name": c["name"], "rarity": c.get("rarity") or "", "types": c.get("types") or "", "illustrator": c.get("illustrator") or "",
                "variant": t.variant or "", "price_usd": c.get("price_usd"), "dex": t.dex, "group": t.key, "dex_label": t.label if t.candidates else "",
                "release": c.get("release_date") or ""})
    return rows
