"""Toys the maker's own shop does not list (any more), brought into a toy list from the shops that sold or still sell them (see collectibles.ShopifyToyProvider).

shoparchive.py reads old shop pages out of the Internet Archive and shoplive.py reads a retailer's current product feed; this module decides what to do with what they find:
  - a toy a master-list entry already stands for (same name; the same release within two months; or as many made and a word that names it) gives that entry its picture, price and shop page - it does not
    appear a second time;
  - a toy ANOTHER shop lists (or listed) is added only when that shop says it is an exclusive or a limited run (a shop selling the maker's ordinary figure adds nothing), it is not an accessory, a bundle, an
    auction, a signed, hand-painted or one-off piece, and the list does not have it already (the same name is the same toy, whatever the date: a shop lists a toy when it stocks it, not when it came out);
  - a RESALE shop (used copies) adds a toy only when its title says the toy is that shop's own exclusive and nothing on the list looks like it; it gives no release date and no price, and otherwise it only
    lends its pictures to master-list entries;
  - the maker's own old pages (they went through the same rules as the live ones) are added when the list did not have them.
Ids never change once made: the maker's own pages keep the id 'shp:<handle>' (the same as when the shop still listed them), another shop's get 'rtl:<shop>:<handle>'."""
import json
import os
import re
from collections import namedtuple

from . import shoparchive, shoplive, toymatch

Shop = namedtuple("Shop", "host pattern label resale live", defaults=(False, None))          # a retailer: the address pattern says which of its saved pages are about this toy line; the label is how its name is written;
#                                                                                              resale: it sells used copies years after they came out, so its dates mean nothing; live: what to look for in its
#                                                                                              CURRENT product list when that differs from the pattern (a title need not say 'chomp': 'Frozen Culture Godzilla ...')
SHEET_DAYS, OTHER_SHOP_DAYS, DISTINCTIVE = 60, 120, 2
JUNK = re.compile(r"protector|popshield|auction|\bsigned\b|hand[- ]?paint|\bcustom\b|\bbundle\b|\b\d+[- ]?pack\b|complete set|\bcase\b|sticker|\bprints?\b|funko shop|gift card|enamel pin|\bpins?\b|\btee\b|shirt|hoodie|trading cards?|"
                  r"\bcomics?\b(?![- ]?con)|\bmugs?\b|tankard|\bcgc\b|lottery", re.I)
LIMITED = re.compile(r"\blimited\b|\bltd\b|\ble\s*\d|/\s*\d{2,}|\d+\s*(?:pcs|pieces|made)\b|exclusive", re.I)
ONE_OFF = re.compile(r"\bone[- ]off\b|\b1\s*/\s*1\b|\bcustom(?:s|ized)?\b|hand[- ]?paint", re.I)          # an artist's single piece, not a release
BODY_LIMITED = re.compile(r"limited edition of\s*\d|edition of\s*\d|exclusive (?:release )?(?:by|to|at|from)\b", re.I)
OWN_EXCLUSIVE = re.compile(r"7\s*(?:bucks\s*a\s*pop|bap)\s+exclusive", re.I)                  # what a resale shop writes about a toy that was made for it


def cid_of(host, maker_host, handle):
    return f"shp:{handle}" if host == maker_host else f"rtl:{host.replace('www.', '').split('.')[0]}:{handle}"


def first_seen(p):
    """When a product was first known, as a sortable 14-digit stamp: the archive's first copy of the page, or the day a shop listed it."""
    return (p.get("_archive") or {}).get("first") or re.sub(r"\D", "", p.get("published_at") or "")[:8].ljust(14, "0")


def _tag(p, shop, maker_host, live):
    base = f"https://{shop.host}"
    p = dict(p, _cid=cid_of(shop.host, maker_host, p["handle"]), _base=base, _shop=shop.label, _resale=shop.resale, _live=live)
    if shop.host != maker_host:                                          # another shop's long title: the toy's own name, and who it says the toy is exclusive to
        p.update(_shop_title=p["title"], title=shoparchive.toy_title(p["title"]), _exclusive=shoparchive.exclusive_of(p["title"]))
    return p


def gather(gdir, maker_host, shops, live_handles, accessory, limit, cancel, progress, done_urls=(), rules=""):
    """The toys the maker's shop no longer lists (`live_handles` are the ones it lists) and the ones the other `shops` list now or listed before, with a few more old pages read this time (`limit`).
    `accessory(handle)` says which pages are not worth reading (`rules` says how: when that changes, pages that were skipped may be worth reading now, so the week's rest is over).
    The old pages read so far are kept in a file beside the list."""
    path = os.path.join(gdir, "archive_products.json")
    cache = shoparchive.load_cache(path)
    if cache.get("_rules") != rules:
        for kept in cache.values():
            if isinstance(kept, dict):
                kept.pop("_listed", None)
        cache["_rules"] = rules
    found, budget = [], limit
    for shop in (Shop(maker_host, None, ""),) + tuple(shops):
        mine = cache.setdefault(shop.host, {})
        before = len(mine)
        current = [] if shop.host == maker_host else [p for p in shoplive.products(shop.host, shop.live or shop.pattern, cancel=cancel, progress=progress) if not accessory(p["handle"])]
        known = set(live_handles) if shop.host == maker_host else {p["handle"] for p in current}          # (what a shop lists now is not read from the archive)
        old = shoparchive.recover(shop.host, known, mine, limit=budget, cancel=cancel, progress=progress, skip=accessory, pattern=shop.pattern)
        for live, items in ((True, current), (False, old)):
            for p in items:
                if f"https://{shop.host}/products/{p['handle']}" not in done_urls:          # (a master-list entry took its picture from this page earlier)
                    if not live:
                        p = dict(p, images=shoparchive.living(p.get("images"), cache.setdefault("_pics", {})))          # (an old page's pictures often died with its product)
                    found.append(_tag(p, shop, maker_host, live))
        budget = max(0, budget - (len(mine) - before))
    shoparchive.save_cache(path, cache)
    return found


def worth_adding(p):
    """Is another shop's listing a toy the list lacks?  Only when it says exclusive / limited (in its title, or as 'Limited Edition of 250' in its text), and is a toy (not an accessory, a bundle, an auction,
    a signed, hand-painted or one-off piece); a resale shop's own exclusives count."""
    title = p.get("_shop_title") or p["title"]
    text = re.sub(r"<[^>]+>", " ", p.get("body_html") or "")[:500]
    if JUNK.search(title) or ONE_OFF.search(title + " " + text):
        return False
    return bool(LIMITED.search(title) or BODY_LIMITED.search(text)) and (not p.get("_resale") or bool(OWN_EXCLUSIVE.search(title)))


def _count(p):
    return shoparchive.edition_of(p.get("_shop_title") or p["title"])


def _words(name):
    return set(toymatch.norm(name, toymatch.SHOP_NOISE))


def _same_count(words, count, made):
    """Does the list have a toy that as many were made of and that shares a word with `words` that names it (not a colour or a finish)?  'Plutonium Glow LE 699' is 'Plutonium Chomper' (699)."""
    return bool(count) and any(n == count and (words & other) - toymatch.COMMON for other, n in made)


def _fills(conn, retired, wanted):
    """{index into retired: id of the master-list entry without a picture that the product is the page of}: by name and release day, then by the number made."""
    sheet = [(r[0], r[1], r[2], r[3]) for r in conn.execute("SELECT id, name, json_extract(raw, '$.ext.Released'), json_extract(raw, '$.edition') FROM cards WHERE id LIKE 'sheet:%' AND (image_base IS NULL OR image_base='')")]
    with_picture = [dict(w, name=w["name"] if p.get("images") else "") for w, p in zip(wanted, retired)]          # (a page whose pictures are gone cannot give an entry one)
    fills = toymatch.pair_up(with_picture, [(sid, name, day) for sid, name, day, _n in sheet], toymatch.SHOP_NOISE, SHEET_DAYS, either_way=True, inside="existing")          # (an entry that says more than the shop is another toy)
    taken = set(fills.values())
    for i, p in enumerate(retired):
        if i in fills or not _count(p) or not p.get("images"):
            continue
        for sid, name, _day, n in sheet:
            if sid not in taken and n == _count(p) and (_words(wanted[i]["name"]) & _words(name)) - toymatch.COMMON:
                fills[i] = sid
                taken.add(sid)
                break
    return fills


def pair(conn, retired, namer, live=()):
    """-> ({cid of a shop's product: id of the master-list entry it is the page of}, {cids of other shops' products that are not to be added}).  `namer(title)` gives a toy's short name;
    `live` are the (title, published day) of the toys the maker's shop lists now - on a list's first run they are not in it yet."""
    if not retired:
        return {}, set()
    wanted = [{"name": namer(p["title"]), "date": toymatch.to_date(p["published_at"][:10]), "undated_words": DISTINCTIVE if p.get("_resale") else 0} for p in retired]
    fills = _fills(conn, retired, wanted)
    have = [(r[0], r[1], r[2]) for r in conn.execute("SELECT id, name, json_extract(raw, '$.ext.Released') FROM cards")] + [(f"live:{k}", namer(title), day) for k, (title, day) in enumerate(live)]
    names = {frozenset(_words(r[1])) for r in have}
    made = [(_words(r[1]), r[2]) for r in conn.execute("SELECT id, name, json_extract(raw, '$.edition') FROM cards") if r[2]]          # (name words, how many were made)
    skip, added = set(), []                                               # added: the other shops' toys accepted so far, so two shops' listings of one toy appear once
    for i in sorted((i for i in range(len(retired)) if i not in fills and retired[i]["_cid"].startswith("rtl:")), key=lambda i: (bool(retired[i].get("_resale")), first_seen(retired[i]))):          # (a shop with real dates and prices first)
        p = retired[i]
        key = frozenset(_words(wanted[i]["name"]))
        resale = bool(p.get("_resale"))                                   # (its dates mean nothing: a name that is wholly inside a name of the list, or has one inside it, is the same toy)
        twin = (key in names or _same_count(set(key), _count(p), made)
                or toymatch.pair_up([dict(wanted[i], undated_words=1 if resale else 0)], have + added, toymatch.SHOP_NOISE, OTHER_SHOP_DAYS, either_way=True))
        if not worth_adding(p) or twin or not key or key <= toymatch.GENERIC:
            skip.add(p["_cid"])
        else:
            added.append((p["_cid"], wanted[i]["name"], "" if resale else p["published_at"][:10]))
            names.add(key)
            if _count(p):
                made.append((set(key), _count(p)))
    return {retired[i]["_cid"]: sid for i, sid in fills.items()}, skip


def shop_facts(p, avail):
    """The 'Availability' and 'Source' lines of an entry made from another shop's product: where its facts come from."""
    where = p.get("_shop") or "The shop"
    if p.get("_archive"):
        return {"Availability": "No longer in the shop" if not p.get("_shop") else f"Listed by {where}",
                "Source": f"{where}'s own page, found in the Internet Archive (the release date is the day it was first saved there)"}
    if p.get("_resale"):
        return {"Availability": f"Used copies at {where}", "Source": f"{where}'s product list (used copies, so there is no release date or retail price here)"}
    return {"Availability": f"In stock at {where}" if avail else f"Sold out at {where}", "Source": f"{where}'s own product list (the release date is the day the shop first listed it)"}


def fill(conn, sid, p):
    """Put the picture, price and shop page of a shop's product on the master-list entry that is the same toy (a resale shop's price is not a retail price: it gives the picture only)."""
    raw = json.loads(conn.execute("SELECT raw FROM cards WHERE id=?", (sid,)).fetchone()[0] or "{}")
    urls = [i.get("src") for i in (p.get("images") or [])[:6] if i.get("src")]
    try:
        price = None if p.get("_resale") else (float(p["variants"][0]["price"]) if p["variants"][0].get("price") else None)
    except (KeyError, IndexError, ValueError):
        price = None
    where = p["_shop"] or "the shop"
    raw.update({"handle": p["handle"], "url": f"{p['_base']}/products/{p['handle']}", "images": urls})
    if p.get("_archive"):
        raw["archive"] = p["_archive"]
    ext = raw.setdefault("ext", {})
    ext["Shop page"] = raw["url"]
    ext["Listed as"] = p.get("_shop_title") or p["title"]
    found = "found in the Internet Archive" if p.get("_archive") else "from its product list"
    ext["Source"] = f"Collector's master list; the picture{'' if p.get('_resale') else ' and price'} come from {where}'s own page, {found}"
    excl = ", ".join(raw.get("exclusive") or [])
    conn.execute("UPDATE cards SET image_base=?, price_usd=COALESCE(price_usd, ?), price_kind=COALESCE(price_kind, CASE WHEN ? IS NOT NULL THEN 'retail price' END), description=?, raw=? WHERE id=?",
                 ((urls[0] if urls else "").split("?")[0], price, price, (excl + ". " if excl else "") + f"From the collector's master list; the picture{'' if p.get('_resale') else ' and price'} are from {where}'s own page, {found}.",
                  json.dumps(raw, ensure_ascii=False), sid))


def repair_pictures(conn, known):
    """An entry that took its picture from an old page: when that picture is gone from the shop's server, another picture of the same page if one still loads, else none.  A master-list entry that
    ends up with none is as it was before (a later page may give it one).  `known` keeps what was found out about each address.  -> how many entries were repaired."""
    fixed = 0
    for cid, image, raw_json, desc in conn.execute("SELECT id, image_base, raw, description FROM cards WHERE image_base IS NOT NULL AND image_base!='' AND raw LIKE '%\"archive\"%'").fetchall():
        raw = json.loads(raw_json or "{}")
        if not raw.get("archive") or shoparchive.alive(image, known):
            continue
        good = [u for u in (raw.get("images") or []) if shoparchive.alive(u, known)]
        raw["images"] = good
        if not good and cid.startswith("sheet:"):
            ext = raw.get("ext") or {}
            for gone in ("Shop page", "Listed as"):
                ext.pop(gone, None)
            ext["Source"] = "Collector's master list (not in the shop feed)"
            for gone in ("url", "handle", "archive"):
                raw.pop(gone, None)
            excl = ", ".join(raw.get("exclusive") or [])
            desc = (excl + ". " if excl else "") + "From the collector's master list - not sold through the shop feed, so there is no picture or price yet."
        conn.execute("UPDATE cards SET image_base=?, description=?, raw=? WHERE id=?", (good[0].split("?")[0] if good else "", desc, json.dumps(raw, ensure_ascii=False), cid))
        fixed += 1
    return fixed
