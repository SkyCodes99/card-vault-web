"""The rule packs and per-game settings, read from ONE data file (cardvault/data/accuracy_settings.json): defaults < the item's kind (its rule pack) < the game.
kind_of(game, table): sealed products of every game are 'sealed'; a game names its kind in the file; otherwise a toy / collectible list is 'toys' and anything else 'cards'."""
import json
import os
import re

PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "accuracy_settings.json")
_PATTERN_KEYS = ("not_official_words", "lot_words", "bundle_words")


def load(path=None):
    with open(path or PATH, encoding="utf-8") as f:
        return json.load(f)


def _is_misc(game):
    try:
        from .. import games
        return any(g.id == game for g in games.GAMES) and games.is_misc(game)
    except Exception:  # noqa: BLE001 - a game the app does not know (a test's): a card list
        return False


def kind_of(game, table="cards", data=None):
    data = data or load()
    if table == "sealed_products":
        return "sealed"
    kind = (data.get("games", {}).get(game) or {}).get("kind")
    return kind or ("toys" if _is_misc(game) else "cards")


def for_item(game, table="cards", data=None):
    """The merged settings of one game's cards (or its sealed products) -> dict, with 'kind' and the word lists compiled into one pattern each ('<key>_re', None when the list is empty)."""
    data = data or load()
    kind = kind_of(game, table, data)
    out = dict(data.get("defaults") or {})
    out.update(data.get("kinds", {}).get(kind) or {})
    if table != "sealed_products":                       # (a game's own limits are about its cards / toys; its sealed products keep the sealed pack)
        out.update({k: v for k, v in (data.get("games", {}).get(game) or {}).items() if k != "kind"})
    out["kind"] = kind
    for k in _PATTERN_KEYS:
        words = out.get(k) or []
        out[k + "_re"] = re.compile("|".join(f"(?:{w})" for w in words), re.I) if words else None
    return out
