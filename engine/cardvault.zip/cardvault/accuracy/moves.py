"""PROVEN MOVES: an item goes to another set / line only with proof, by whichever checker has it (owner, chat 2026-11-13: "between the two checkers, if a card is in the wrong set
and truly is then one or both should be able to move it or move anything else if it's truly justified in doing so").  This replaces the old lane-made "a set is never fixed by itself"
rule, which had no owner source.

  accuracy check  2+ independent sources agree on the new set, no source backs the current one, the set exists in that game, the owner did not place the item himself
  Mini you        its placer clears its threshold (and the model passed evaluate.auto_ok) AND 1+ independent source agrees; the same set / owner / backing rules
  they disagree   nothing moves: ONE review question shows both answers (kind accuracy_sources, the item's 'set' question)
  two sets        a card can rightly be in two sets (reprints, promos also sold in a set): when ANY source backs the current set it is not wrong - asked, never moved
Every move is a fix (rule 'move') in the fix log: set before / after, the sources, Mini you's score; revertible in Dev Tools > Changes.  A reverted move is never made again by
either checker (state.kept, rule 'move').  'list' (a row nobody knows the source of) is the list itself, never a source.

What a source says about the set is read as one of THIS game's sets: a set id that is one of ours, or a set name that is exactly one of ours ('?' = says something we cannot map:
then nobody can be sure, and nothing moves)."""
from . import MIN_SOURCES, claims, fixlog
from .result import fixable, review

RULE = "move"
UNKNOWN = "?"


def _sets(ctx):
    """{lower id: id}, {folded name: [ids]} of the game's sets (read once per run)."""
    if getattr(ctx, "_move_sets", None) is None:
        from .rules.sources import _fold
        ids = {str(i).lower(): str(i) for i in ctx.sets}
        names = {}
        for i, n in ctx.sets.items():
            if n and _fold(n):
                names.setdefault(_fold(n), []).append(str(i))
        ctx._move_sets = (ids, names)
    return ctx._move_sets


def set_named(ctx, value):
    """A set id or a set name -> this game's set id, '' when it names none of ours (exactly one set must carry that name)."""
    from .rules.sources import _fold
    ids, names = _sets(ctx)
    v = str(value or "").strip()
    if not v:
        return ""
    if v.lower() in ids:
        return ids[v.lower()]
    for part in {v, v.split(":")[-1]}:
        hit = names.get(_fold(part)) or []
        if len(hit) == 1:
            return hit[0]
    return ""


def stated(item, cl, ctx):
    """-> {source: the set id it states (one of ours), or UNKNOWN}; a source that states no set is left out, and so is the list itself."""
    from .rules.sources import _same_setname
    cur, cur_name = item["set_id"], item["set_name"] or ctx.set_name(item["set_id"])
    out = {}
    for src, c in cl.items():
        if src == "list":
            continue
        if c.get("set_id"):
            out[src] = set_named(ctx, c["set_id"]) or UNKNOWN
        elif c.get("set_name"):
            out[src] = cur if (cur_name and _same_setname(c["set_name"], cur_name)) else (set_named(ctx, c["set_name"]) or UNKNOWN)
    return out


def owner_placed(item, ctx):
    """Did the owner place this item himself?  His own correction (provenance 'fix'), his answer to its set question, a move he made from the review list, or his answer to
    Mini you's line question."""
    iid = item["id"]
    if ctx.prov_card.get(iid) == "fix" or iid in ctx.owner_fixed or ctx.settled("sources", item, "set"):
        return True
    if getattr(ctx, "_owner_moves", None) is None:
        moved = {(e["table"], str(e["item_id"])) for e in fixlog.entries() if e.get("game") == ctx.game and e.get("by") == fixlog.BY_OWNER and "set_id" in (e.get("after") or {})}
        try:
            from .. import reviewlist
            moved |= {("cards", str(it["item_id"])) for it in reviewlist.items("confirmed", ctx.game, "miniyou_place") if ((it.get("before") or {}).get("what") == "item")}
        except Exception:  # noqa: BLE001
            pass
        ctx._owner_moves = moved
    return (item["table"], iid) in ctx._owner_moves


def miniyou_view(item, ctx):
    """Mini you's placer on this item, when it is SURE (its score clears its threshold) -> (set id or UNKNOWN, score, its label, the model's name), else None."""
    sc = ctx.scorer
    if sc is None or not sc.available("place"):
        return None
    from ..miniyou import datasets
    lab, conf = sc.place(item["game"], "item", datasets.place_text(item["name"]))
    thr = sc.threshold("place")
    if not lab or not str(lab).startswith("line:") or thr is None or conf < thr:
        return None
    return set_named(ctx, str(lab)[5:]) or UNKNOWN, float(conf), lab, sc.label("place")


def _name(ctx, sid):
    return f"{ctx.set_name(sid) or sid}" if sid and sid != UNKNOWN else "a set that is not in this list"


def disagree(item, ctx, check_set, check_srcs, mini_set, score):
    """The two checkers disagree: ONE question with both answers; nothing moves."""
    who = ", ".join(claims.label(s) for s in check_srcs)
    return review("sources", "disagree", item, f"Which set is right for {item['name']}? The list has '{_name(ctx, item['set_id'])}'. {len(check_srcs)} source(s) ({who}) say "
                  f"'{_name(ctx, check_set)}', but Mini you says '{_name(ctx, mini_set)}' (score {score:.2f}). Nothing was moved.", {"set_id": item["set_id"]}, {},
                  [claims.label(s) for s in check_srcs] + [f"Mini you ({score:.2f})"], key="set")


def check(item, cl, ctx):
    """The accuracy check's part (called by rules/sources.py for a card's set) -> a move (fixable), ONE disagreement question, or None (not proven: the usual question)."""
    if item["table"] != "cards" or not item["set_id"]:
        return None
    said = stated(item, cl, ctx)
    cur = item["set_id"]
    if any(v == cur for v in said.values()) or UNKNOWN in said.values():
        return None                                                         # (a source backs the current set - a reprint? - or says something we cannot map: ask, never move)
    targets = {v for v in said.values()}
    if len(targets) != 1:
        return None
    target = targets.pop()
    srcs = sorted(s for s, v in said.items() if v == target)
    if len(srcs) < MIN_SOURCES or owner_placed(item, ctx):
        return None
    mini = miniyou_view(item, ctx)
    if mini and mini[0] != target:
        return disagree(item, ctx, target, srcs, mini[0], mini[1])
    names = [f"{claims.label(s)} ({_name(ctx, target)})" for s in srcs] + ([f"{mini[3]} agrees (score {mini[1]:.2f})"] if mini else [])
    return fixable(RULE, "moved", item, f"it is in '{_name(ctx, cur)}' but {len(srcs)} sources agree it belongs in '{_name(ctx, target)}', and no source says '{_name(ctx, cur)}'",
                   {"set_id": cur}, {"set_id": target}, names, need=MIN_SOURCES)


def miniyou_move(game, db, item_id, label, score, model, have=""):
    """Mini you's placer is sure an item belongs on another line (the daily update's Mini you step, 'auto' mode, a model that passed evaluate.auto_ok).
    -> ('moved', the fix log entry) | ('asked', why) | ('no', why).  'no' = not proven: the caller sends its usual question.  Every move goes through the fix log (by 'mini you')."""
    import sqlite3
    from . import engine, items, review, settings
    conn = items.open_ro(db)
    try:
        ctx = engine.Context(game, db, conn)
        it = next(iter(items.read(conn, game, items.CARDS, ids=[str(item_id)])), None)
        if it is None:
            return "no", "the item is not in the list"
        target, cur = set_named(ctx, str(label)[5:]) if str(label).startswith("line:") else "", it["set_id"]
        if not target or target == cur:
            return "no", "Mini you's line is not a line of this list" if not target else "already there"
        if (RULE, it["table"], it["id"]) in ctx.kept:
            return "no", "you reverted this move before"
        if owner_placed(it, ctx):
            return "no", "you placed it yourself"
        said = stated(it, claims.for_item(it, ctx.prov_card.get(it["id"]), ctx.side), ctx)
        if any(v == cur for v in said.values()):
            return "no", "a source backs the line it is on"
        agree = sorted(s for s, v in said.items() if v == target)
        other = {}
        for s, v in said.items():
            if v not in (target, cur):
                other.setdefault(v, []).append(s)
        check_set, check_srcs = next(((v, sorted(s)) for v, s in other.items() if len(s) >= MIN_SOURCES and v != UNKNOWN), (None, None))
        if check_set:
            f = disagree(it, ctx, check_set, check_srcs, target, score)
            listed, _ = review.queue([f], lambda f: settings.for_item(game, it["table"]).get("review_cap", 5))
            return "asked", "the accuracy check's sources say another line" + ("" if listed else " (the question waits for a free place)")
        if not agree or other:
            return "no", "no source agrees" if not agree else "the sources do not agree"
        f = fixable(RULE, "moved", it, f"Mini you is sure it belongs on '{_name(ctx, target)}' (score {score:.2f}), not '{_name(ctx, cur)}', and {', '.join(claims.label(s) for s in agree)} agree(s)",
                    {"set_id": cur}, {"set_id": target}, [f"{model} (score {score:.2f})"] + [f"{claims.label(s)} ({_name(ctx, target)})" for s in agree])
    finally:
        conn.close()
    from ..miniyou import datasets
    w = sqlite3.connect(db, timeout=60)
    try:
        entry, why = fixlog.apply(w, f, by=fixlog.BY_MINIYOU, extra={"score": round(float(score), 4), "miniyou": {"task": "place", "text": datasets.place_text(it["name"]), "label": label,
                                                                                                                      "what": "item", "name": it["name"], "right": have or ("line:" + (ctx.set_name(cur) or cur))}})
    finally:
        w.close()
    return ("moved", entry) if entry else ("no", why)
