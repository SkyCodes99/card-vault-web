"""Second sources: what another, independent place says about an item becomes a claim (claims.record), so the SOURCES rule can compare it with the list.
Every function here is pure: it gets what a source said (already read, by the daily update or by feedrun.py through the shared polite reader) and returns claim rows.

tcgplayer(game, group, products)   TCGplayer's own record of each card of a set (group), handed over by cardvault/tcgsync.check_game (and by feedrun's Pokemon pass) for the games
                                   whose list is built from ANOTHER source (Pokemon: TCGdex).  For a game whose list IS TCGplayer's it would be the same source twice: nothing is kept.
scryfall_rows(lines)               Magic: Scryfall's bulk default_cards, keyed by TCGplayer product (Scryfall states each printing's TCGplayer id).
ygoprodeck_rows(cards, ours)       Yu-Gi-Oh!: YGOPRODeck's card list; a printing is found by its set code (our number), so its NAME and SET are what it confirms.
lorcast_rows(cards)                Lorcana: Lorcast's card lists, keyed by TCGplayer product.
funko_rows(pops, ours)             Funko: the Funko fandom wiki's Pop tables (read from the list's weekly wiki copy) against the hobbyDB / TCGplayer entries of the list.
A new feed is one small function here + one entry in feedrun.FEEDS."""
import html
import re

from . import claims

OLD_MTG = "1999-01-01"
SCRY, YGOP, LORC, FANDOM_FUNKO = "scry", "ygop", "lorc", "n:funko.fandom.com"      # (a Funko row taken from the wiki carries the same code as its origin: never counted twice)


def tcgplayer(game, group, products):
    """-> claims written.  Keyed by the TCGplayer product, so it meets our card through its link (cards.tcg_id)."""
    return claims.record(game, tcgplayer_rows(game, group, products))


def tcgplayer_rows(game, group, products):
    from ..tcgsync import _clean_name, _is_card                               # (tcgsync first: it loads tcgcsv / tcggames in the order they need)
    from ..tcgcsv import _ext
    from ..tcggames import NATIVE
    if game in NATIVE:
        return []
    rows = []
    for p in products or ():
        if not _is_card(game, p):
            continue
        ext = _ext(p)
        rows.append({"ref_kind": claims.TCG, "ref": p.get("productId"), "source": "tcgp", "name": _clean_name(p.get("name")), "number": ext.get("Number"),
                     "set_name": (group or {}).get("name"), "url": p.get("url")})
    return rows


def group_sets(rows, set_of, share=0.6):
    """TCGplayer files a card in a group (its set, named in English even for a Japanese list).  When most of a group's linked cards are in ONE of our sets, the group IS that set,
    and a card of that set filed there has its set confirmed by TCGplayer (set_id).  A card filed elsewhere keeps only the group's name (a name never disagrees)."""
    from collections import Counter
    sets = Counter(set_of[str(r["ref"])] for r in rows if str(r["ref"]) in set_of)
    if sets:
        top, n = sets.most_common(1)[0]
        if n >= share * sum(sets.values()):
            for r in rows:
                if set_of.get(str(r["ref"])) == top:
                    r["set_id"] = top
    return rows


# ------------------------------------------------------------------------------------------------ Magic: Scryfall bulk default_cards
def scryfall_rows(cards):
    """Scryfall card objects -> claim rows keyed by TCGplayer product (an etched printing has its own product: it gets the same statement).  Written the way TCGplayer writes it:
    the front face of a two-faced card, 'Morgul-Knife - Shadowspear' for a card printed under another name, '264' for Scryfall's promo-pack / prerelease '264p' / '264s'."""
    for c in cards:
        name = (c.get("name") or "").split(" // ")[0]
        if c.get("flavor_name"):
            name = f"{c['flavor_name']} - {name}"
        if c.get("layout") in ("token", "double_faced_token") and "token" not in name.lower():
            name += " Token"                                                   # (TCGplayer calls a token 'Goblin Token')
        number = re.sub(r"(?<=\d)[psz★†]$", "", re.sub(r"^[A-Z]{2,4}-(?=\d)", "", str(c.get("collector_number") or "")))
        if (c.get("released_at") or "9999") < OLD_MTG:
            number = ""                                                        # (cards printed before collector numbers: each site numbers them its own way)
        for tid in (c.get("tcgplayer_id"), c.get("tcgplayer_etched_id")):
            if tid:
                yield {"ref_kind": claims.TCG, "ref": tid, "source": SCRY, "name": name, "number": number, "set_name": c.get("set_name"),
                       "url": c.get("scryfall_uri")}


# ------------------------------------------------------------------------------------------------ Yu-Gi-Oh!: YGOPRODeck cardinfo
def ygoprodeck_rows(cards, ours):
    """cards: cardinfo's 'data' list; ours: [(tcg_id, number, rarity)] of the list.  A printing is found by its set code + rarity (the free-price reader's own match), so the
    code itself is never what it proves: the source states the NAME and the SET of that printing (the number only when the code is written exactly as ours)."""
    from ..freeprices_ygo import norm_code, norm_rarity
    exact, by_code = {}, {}
    for c in cards or ():
        for s in c.get("card_sets") or ():
            code = (s.get("set_code") or "").strip().upper()
            if code:
                e = (c.get("name") or "", s.get("set_name") or "", norm_rarity(s.get("set_rarity")), code)
                exact.setdefault((code, norm_rarity(s.get("set_rarity"))), []).append(e)
                by_code.setdefault(norm_code(code), []).append(e)
    for tcg_id, number, rarity in ours:
        code, nr = (number or "").strip().upper(), norm_rarity(rarity)
        cands = exact.get((code, nr)) or [e for e in by_code.get(norm_code(code), ()) if e[2] == nr] or by_code.get(norm_code(code), [])
        names = {claims_key(e[0]) for e in cands}
        if not cands or len(names) != 1:
            continue                                                           # (not there, or two different cards on one code: nothing to state)
        e = cands[0]
        yield {"ref_kind": claims.TCG, "ref": tcg_id, "source": YGOP, "name": e[0], "number": e[3] if e[3] == code else None, "set_name": e[1]}


def claims_key(name):
    return re.sub(r"[^a-z0-9]+", "", (name or "").lower())


# ------------------------------------------------------------------------------------------------ Lorcana: Lorcast
def lorcast_rows(cards):
    """Lorcast card objects -> claim rows keyed by TCGplayer product.  TCGplayer writes 'Elsa - Spirit of Winter': name + ' - ' + version."""
    for c in cards or ():
        tid = c.get("tcgplayer_id")
        if not tid:
            continue
        name = c.get("name") or ""
        if c.get("version"):
            name = f"{name} - {c['version']}"
        number = re.sub(r"(?<=\d)[a-z]+$", "", str(c.get("collector_number") or ""))           # (Lorcast's '1f' / '25ja' printings are TCGplayer's '1/204' / '25')
        yield {"ref_kind": claims.TCG, "ref": tid, "source": LORC, "name": name, "number": number, "set_name": (c.get("set") or {}).get("name")}


# ------------------------------------------------------------------------------------------------ Funko: the fandom wiki's Pop tables
def _line(s):
    return claims_key(re.sub(r"^\s*pop!?\s*", "", html.unescape(s or ""), flags=re.I))


def funko_rows(pops, ours):
    """pops: funkowiki.parse_pops rows ({page, number, name, ...}); ours: [(id, number, name, set name)] of the list's entries that did NOT come from the wiki.
    A numbered entry is found by its line + number (a line's numbers are unique; where the wiki has two Pops on one number, only the one that shares a word with ours speaks);
    an unnumbered one (the hobbyDB list) by line + plain name, else by its whole name (brackets included) when exactly one Pop of the wiki has it.  -> claim rows keyed by our id."""
    from ..funkowiki import core
    by_num, by_name, by_full = {}, {}, {}
    for p in pops or ():
        p = dict(p, name=re.sub(r"\[https?://\S+\s+([^\]]+)\]", r"\1", p["name"]))          # ('[https://... Evie Frye]' is 'Evie Frye')
        line = _line(p.get("page"))
        by_num.setdefault((line, int(p["number"])), []).append(p)
        by_name.setdefault((line, core(p["name"])), []).append(p)
        by_full.setdefault(claims_key(html.unescape(p["name"])), []).append(p)
    for iid, number, name, set_name in ours:
        line, digits = _line(set_name), re.sub(r"\D", "", number or "")
        mine = set(core(name).split())
        if digits:
            cands = [p for p in by_num.get((line, int(digits)), []) if mine & set(core(p["name"]).split())]       # (no word in common: the wiki numbers that line another way)
            if len({core(p["name"]) for p in cands}) != 1:
                continue
            p = cands[0]
            yield {"ref_kind": claims.ID, "ref": iid, "source": FANDOM_FUNKO, "name": p["name"], "number": str(p["number"]), "set_name": p["page"]}
        else:
            cands = by_name.get((line, core(name)), []) or by_full.get(claims_key(html.unescape(name)), [])
            if cands and len({(p["page"], p["number"]) for p in cands}) == 1:
                yield {"ref_kind": claims.ID, "ref": iid, "source": FANDOM_FUNKO, "name": cands[0]["name"], "set_name": cands[0]["page"]}
