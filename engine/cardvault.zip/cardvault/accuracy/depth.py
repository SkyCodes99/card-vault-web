"""The toy database depth check: how deep are our Funko and toy lists compared with what is publicly known outside them?  REPORT ONLY - nothing here ever adds or changes an item.

Funko: the Funko Fandom wiki lists every Pop per line ('Pop! Animation' ...) with number, name and series.  Its Pop tables are read from the list's own weekly copy
(games/funko/funkowiki, written by the daily update, so no request is made here) and compared with the list line by line: which wiki lines we do not have at all, which wiki Pops
(number + name, or the same number in the line) we do not have, and which series (franchises) inside a line they fall in.
hobbyDB: its site is 'links only' (cardvault/sources/rules.py: robots.txt turns AI readers away by name, terms forbid copying; docs/hotwheels_sources.md), so only its published
headline total is quoted (HOBBYDB_FUNKO_TOTAL) and the open hobbyDB-based list we already carry is counted as it is; nothing is read from hobbydb.com.
Other toy lines: our own counts per line, and the allowed outside reference where one exists (a Fandom wiki's own category count); where none is allowed or available it says so.

funko_depth(conn, pops) -> dict;  toy_lines(data_dir, game) -> dict;  render(...) -> markdown."""
import re
from collections import Counter, defaultdict

HOBBYDB_FUNKO_TOTAL = 74188          # "hobbyDB lists 74,188 Funko items" (public headline on hobbydb.com/home/funko, quoted in docs/gap_check_20261117.md; not read by this tool)


def slug(name):
    return re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")


def line_name(page):
    return re.sub(r"^Pop!\s*", "", page or "").strip()


def funko_depth(conn, pops, core, is_known):
    """conn: the Funko list; pops: funkowiki.parse_pops rows (every year); core / is_known: funkowiki's own name and number matching.
    -> {lines: [{line, wiki, ours, have, missing}], missing_lines: [{line, wiki}], series: [{line, series, wiki, missing}], totals}"""
    from ..funkowiki import Known
    known = Known(conn)
    sets = {r[0]: r[1] for r in conn.execute("SELECT id, name FROM sets")}
    names, all_names = defaultdict(set), set()
    ours = Counter()
    origin = Counter()
    for cid, set_id, name, raw in conn.execute("SELECT id, set_id, name, raw FROM cards"):
        names[set_id].add(core(name))
        all_names.add(core(name))
        ours[set_id] += 1
        origin["hobbyDB" if str(cid).startswith("hdb:") else "Funko wiki" if "funko.fandom.com" in (raw or "") else "TCGplayer"] += 1
    seen, uniq = set(), []
    for p in pops:
        key = (p["page"], p["number"], core(p["name"]), (p.get("series") or "").lower())
        if key not in seen:
            seen.add(key)
            uniq.append(p)
    by_line = defaultdict(list)
    for p in uniq:
        by_line[p["page"]].append(p)
    lines, missing_lines, series = [], [], defaultdict(lambda: [0, 0])
    for page, items in sorted(by_line.items()):
        name = line_name(page)
        set_id = "fd:" + slug(name)
        has_line = set_id in sets or any(slug(n) == slug(name) for n in sets.values())
        miss = [p for p in items if not (is_known(p, set_id, known) or core(p["name"]) in names.get(set_id, ()))]
        miss_ids = {id(p) for p in miss}
        for p in items:
            s = series[(name, p.get("series") or "(no series)")]
            s[0] += 1
            s[1] += id(p) in miss_ids
        if not has_line:
            elsewhere = sum(1 for p in items if core(p["name"]) in all_names)            # (our list may file the line's Pops under a bigger fandom: Wreck-It Ralph under Disney)
            missing_lines.append({"line": name, "wiki": len(items), "elsewhere": elsewhere})
        else:
            lines.append({"line": name, "wiki": len(items), "ours": ours.get(set_id, 0), "have": len(items) - len(miss), "missing": len(miss)})
    wiki_sets = {slug(line_name(pg)) for pg in by_line}
    only_ours = sorted(((n, ours.get(i, 0)) for i, n in sets.items() if slug(n) not in wiki_sets and ours.get(i, 0)), key=lambda x: -x[1])
    ser = [{"line": k[0], "series": k[1], "wiki": v[0], "missing": v[1]} for k, v in series.items() if v[1]]
    return {"lines": lines, "missing_lines": missing_lines, "series": ser, "only_ours": only_ours, "origin": dict(origin),
            "totals": {"ours": sum(ours.values()), "sets": len(sets), "wiki": len(uniq), "wiki_lines": len(by_line),
                       "wiki_missing": sum(x["missing"] for x in lines) + sum(x["wiki"] for x in missing_lines)}}


def toy_lines(conn):
    """-> {items, sets, per_set: [(set name, items)]} of one toy list"""
    per = [(n or "(no set)", c) for n, c in conn.execute("SELECT s.name, COUNT(*) FROM cards c LEFT JOIN sets s ON s.id = c.set_id GROUP BY c.set_id ORDER BY 2 DESC")]
    return {"items": sum(c for _n, c in per), "sets": len(per), "per_set": per}


def _row(*cells):
    return "| " + " | ".join(str(c) for c in cells) + " |"


def render(day, funko, others, refs, notes):
    """-> the report's markdown.  others: {game: toy_lines}; refs: {game: (text, how it was read)}; notes: [str]"""
    t = funko["totals"]
    out = [f"# Toy database depth check ({day})", "",
           "REPORT ONLY.  Nothing was added to any catalog; adding is the owner's call after reading this.  Written by `tools/toy_depth_check.py` (re-run it to refresh).", "",
           "## Headline", "",
           f"- **Funko**: our list has {t['ours']:,} items in {t['sets']} lines.  hobbyDB's published headline is {HOBBYDB_FUNKO_TOTAL:,} Funko items (not read by this tool, see Sources), so on its own count we hold about "
           f"{100 * t['ours'] / HOBBYDB_FUNKO_TOTAL:.0f} %.  The Funko wiki's Pop tables name {t['wiki']:,} Pops in {t['wiki_lines']} lines: we do not have **{t['wiki_missing']:,}** of them "
           f"({len(funko['missing_lines'])} wiki lines are not in our list at all; {len([x for x in funko['lines'] if x['missing']])} of our {len(funko['lines'])} shared lines miss some Pops).",
           f"- Where our Funko items come from: " + ", ".join(f"{k} {v:,}" for k, v in sorted(funko["origin"].items(), key=lambda kv: -kv[1])) + ".", ""]
    for g, v in others.items():
        out.append(f"- **{g}**: {v['items']:,} items in {v['sets']} lines/sets" + (f"; {refs[g][0]}" if g in refs else "; no outside count is allowed or available (see below)") + ".")
    out += ["", "## Funko: lines the wiki has and we do not have at all", "", _row("Wiki line", "Pops on the wiki", "Of those, same name found elsewhere in our list"), _row("---", "---:", "---:")]
    out += [_row(x["line"], x["wiki"], x["elsewhere"]) for x in sorted(funko["missing_lines"], key=lambda x: -x["wiki"])] or [_row("(none)", 0)]
    out += ["", "## Funko: shared lines where Pops are missing (biggest gaps first)", "", _row("Line", "Wiki Pops", "We have", "Missing", "Our items in the line"), _row("---", "---:", "---:", "---:", "---:")]
    out += [_row(x["line"], x["wiki"], x["have"], x["missing"], x["ours"]) for x in sorted(funko["lines"], key=lambda x: -x["missing"]) if x["missing"]][:60]
    out += ["", "## Funko: series (franchises) with Pops missing, largest first (top 60)", "", _row("Line", "Series", "Wiki Pops", "Missing"), _row("---", "---", "---:", "---:")]
    out += [_row(x["line"], x["series"], x["wiki"], x["missing"]) for x in sorted(funko["series"], key=lambda x: -x["missing"])[:60]]
    out += ["", "## Funko: lines only we have (hobbyDB / TCGplayer lines the wiki has no table for), largest first (top 25)", "", _row("Our line", "Items"), _row("---", "---:")]
    out += [_row(n, c) for n, c in funko["only_ours"][:25]]
    out += ["", "## Other toy lines", "", _row("List", "Items", "Lines / sets", "Largest lines", "Outside reference"), _row("---", "---:", "---:", "---", "---")]
    for g, v in others.items():
        out.append(_row(g, f"{v['items']:,}", v["sets"], "; ".join(f"{n} {c}" for n, c in v["per_set"][:4]), refs[g][0] + f" ({refs[g][1]})" if g in refs else "none allowed / available"))
    out += ["", "## Sources and what was NOT read", ""] + [f"- {n}" for n in notes] + [""]
    return "\n".join(out)
