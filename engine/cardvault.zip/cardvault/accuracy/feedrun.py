"""Reads the second sources (feeds.py) for the lists and stores what they say as claims - night by night, through the shared polite reader (cardvault/sources: robots.txt, rate
limits, cache).  The big files are the ones the daily update already reads the same night (Scryfall bulk, YGOPRODeck, Lorcast for the free prices), so they come from the cache;
the Pokemon pass reads TCGplayer's groups through tcgcsv at most once a week; the Funko pass reads only the list's own weekly copy of the wiki (no request at all).

run(names, data_dir, fetcher=None) -> {feed: {game, rows (claims written), items (in the list), matched (items that now have the source's statement), notes}}
A feed that cannot be read is noted and skipped; the claims it stored before stay."""
import gzip
import io
import json
import os
import threading

from . import claims, feeds, items

WEEK = 6 * 24 * 3600                       # (a little under a week, so a weekly pass always reads fresh)
DAY = 20 * 3600


def _cards(db, sql):
    conn = items.open_ro(db)
    try:
        return list(conn.execute(sql))
    finally:
        conn.close()


def _db(data_dir, game):
    return os.path.join(data_dir, "games", game, "cards.db")


def _keep(game, rows, ours, whole=True):
    """Only the statements about items of this list are kept; a whole pass replaces what the source said before.  -> (rows written, items matched)"""
    rows = [r for r in rows if str(r["ref"]) in ours]
    return claims.record(game, rows, whole=whole), len({str(r["ref"]) for r in rows})


# ------------------------------------------------------------------------------------------------ the feeds
def pokemon(data_dir, fetcher, game="pokemon"):
    """TCGplayer's own record of every Pokemon card linked to a TCGplayer product (the list itself is built from TCGdex)."""
    from ..sources import TcgCsv
    from ..tcggames import CATEGORIES
    tc, cat = TcgCsv(fetcher), CATEGORIES[game]
    set_of = {str(t): s for t, s in _cards(_db(data_dir, game), "SELECT tcg_id, set_id FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''")}
    ours = set(set_of)
    rows, notes = [], []
    for g in tc.results(tc.get(f"{tc.BASE}/{cat}/groups", WEEK)):
        got = tc.get(f"{tc.BASE}/{cat}/{g['groupId']}/products", WEEK)
        if got.status != 200:
            notes.append(f"group {g['groupId']}: HTTP {got.status}")
            continue
        rows += feeds.group_sets(feeds.tcgplayer_rows(game, g, tc.results(got)), set_of)
    n, matched = _keep(game, rows, ours, whole=not notes)           # (a group that could not be read keeps what TCGplayer said of it before)
    return {"game": game, "rows": n, "items": len(ours), "matched": matched, "notes": notes[:5]}


def pokemon_jp(data_dir, fetcher):
    return pokemon(data_dir, fetcher, "pokemon_jp")


def _jsonl(body):
    """Scryfall's bulk file (jsonl, .gz or not) -> card objects, one line at a time."""
    raw = gzip.GzipFile(fileobj=io.BytesIO(body)) if body[:2] == b"\x1f\x8b" else io.BytesIO(body)
    for line in io.TextIOWrapper(raw, encoding="utf-8"):
        line = line.strip().rstrip(",")
        if line.startswith("{"):
            try:
                yield json.loads(line)
            except ValueError:
                continue


def mtg(data_dir, fetcher):
    from ..sources import Scryfall
    got, _updated = Scryfall(fetcher).bulk("default_cards")
    if got is None or got.status != 200:
        return {"game": "mtg", "rows": 0, "items": 0, "matched": 0, "notes": ["Scryfall default_cards not available"]}
    ours = {str(r[0]) for r in _cards(_db(data_dir, "mtg"), "SELECT tcg_id FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''")}
    n, matched = _keep("mtg", feeds.scryfall_rows(_jsonl(got.body)), ours)
    return {"game": "mtg", "rows": n, "items": len(ours), "matched": matched, "notes": ["from cache"] if got.from_cache else []}


def yugioh(data_dir, fetcher):
    from ..freeprices_ygo import DAY_AGE, URL
    got = fetcher.get(URL, max_age=DAY_AGE)
    data = got.json() if got.status == 200 else None
    cards = data.get("data") if isinstance(data, dict) else None
    if not cards:
        return {"game": "yugioh", "rows": 0, "items": 0, "matched": 0, "notes": [f"YGOPRODeck cardinfo not available (HTTP {got.status})"]}
    ours = _cards(_db(data_dir, "yugioh"), "SELECT tcg_id, local_id, rarity FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''")
    n, matched = _keep("yugioh", feeds.ygoprodeck_rows(cards, [(str(a), b, c) for a, b, c in ours]), {str(r[0]) for r in ours})
    return {"game": "yugioh", "rows": n, "items": len(ours), "matched": matched, "notes": ["from cache"] if got.from_cache else []}


def lorcana(data_dir, fetcher):
    from ..freeprices_lorcana import read_all
    try:
        cards, _at, cached, _stale = read_all(fetcher)
    except Exception as e:  # noqa: BLE001 - SourceError / ValueError: one missing set means no pass tonight
        return {"game": "lorcana", "rows": 0, "items": 0, "matched": 0, "notes": [f"Lorcast not read: {str(e)[:120]}"]}
    ours = {str(r[0]) for r in _cards(_db(data_dir, "lorcana"), "SELECT tcg_id FROM cards WHERE tcg_id IS NOT NULL AND tcg_id != ''")}
    n, matched = _keep("lorcana", feeds.lorcast_rows(cards), ours)
    return {"game": "lorcana", "rows": n, "items": len(ours), "matched": matched, "notes": ["from cache"] if cached else []}


def funko(data_dir, fetcher):
    """The Funko wiki's Pop tables from the list's own weekly copy (games/funko/funkowiki, written by the daily update): no request is made here."""
    from .. import funkowiki
    folder = os.path.join(data_dir, "games", "funko", "funkowiki")
    stop = threading.Event()
    stop.set()                                                          # (a set 'cancel' makes funkowiki answer from its copy only, never from the wiki)
    pops = [p for t in funkowiki.category_titles(folder, stop) for p in funkowiki.parse_pops(t, funkowiki.page_text(folder, t, stop))]
    rows = _cards(_db(data_dir, "funko"), "SELECT c.id, c.local_id, c.name, s.name FROM cards c LEFT JOIN sets s ON s.id = c.set_id WHERE c.raw NOT LIKE '%funko.fandom.com%'")
    if not pops:
        return {"game": "funko", "rows": 0, "items": len(rows), "matched": 0, "notes": ["no copy of the Funko wiki in the list's folder yet"]}
    ours = {str(r[0]) for r in rows}
    n, matched = _keep("funko", feeds.funko_rows(pops, [(str(a), b, c, d) for a, b, c, d in rows]), ours)
    return {"game": "funko", "rows": n, "items": len(ours), "matched": matched, "notes": [f"wiki Pops read: {len(pops)}"]}


FEEDS = {"pokemon": pokemon, "pokemon_jp": pokemon_jp, "mtg": mtg, "yugioh": yugioh, "lorcana": lorcana, "funko": funko}
from . import feedrun_more  # noqa: E402 - (reads feedrun's helpers only when it runs, so the two import in either order)
FEEDS.update(feedrun_more.FEEDS)
from . import feedrun_fandom  # noqa: E402 - Fandom wikis for the small TCGs (Weiss Schwarz, Vanguard, Buddyfight, WIXOSS, Union Arena, MetaZoo)
FEEDS.update(feedrun_fandom.FEEDS)


def run(names, data_dir, fetcher=None, log=print):
    if fetcher is None:
        from .. import sources
        fetcher = sources.default()
    out = {}
    for name in names or FEEDS:
        if not os.path.exists(_db(data_dir, name)):
            continue
        try:
            out[name] = FEEDS[name](data_dir, fetcher)
        except Exception as e:  # noqa: BLE001 - one feed that fails never stops the others
            out[name] = {"game": name, "rows": 0, "items": 0, "matched": 0, "notes": [f"{type(e).__name__}: {str(e)[:150]}"]}
        r = out[name]
        log(f"{name}: {r['matched']} of {r['items']} items have the second source's statement ({r['rows']} claims written)" + (f" | {'; '.join(r['notes'])}" if r["notes"] else ""))
    return out
