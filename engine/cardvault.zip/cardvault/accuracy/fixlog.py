"""THE FIX LOG: every change the accuracy check makes to a list, one line each in accuracy/fixes.jsonl (next to the daily update log), with before, after, the sources that
prove it and the rule.  Nothing is changed any other way, and every change can be taken back from its line:

  apply(conn, finding)   writes the fix - only when the row still is what the check saw (else it is skipped and says so) - and logs it BEFORE the commit, so a line never goes missing
  revert(conn, entry)    puts `before` back - only when the row still is what the fix left (else it refuses: somebody changed it since) - and logs the undo

A 'set' fix writes columns of one row; a 'remove' fix takes the row out and keeps the WHOLE row in the log, so undo puts it back exactly.  A corrected name is stamped in the list's
provenance (source 'acc', or 'fix' for the owner's own answer) so the nightly re-sync from a bulk source does not undo it (cardvault/keepfixes.py); undo restores the old stamp."""
import json
import os
import uuid

from .. import dailylog, provenance
from . import store
from .result import REMOVE, SET

TABLES = ("cards", "sealed_products")


def path():
    return os.path.join(store.folder(), "fixes.jsonl")


def entries():
    """Every line of the log, oldest first."""
    try:
        with open(path(), encoding="utf-8") as f:
            return [json.loads(line) for line in f if line.strip()]
    except OSError:
        return []


def _write(entry):
    os.makedirs(store.folder(), exist_ok=True)
    with open(path(), "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")
        f.flush()
        os.fsync(f.fileno())


def _row(conn, table, item_id):
    cur = conn.execute(f"SELECT * FROM {table} WHERE id=?", (str(item_id),))
    r = cur.fetchone()
    return dict(zip([d[0] for d in cur.description], r)) if r else None


def _stamp(conn, item_id):
    r = conn.execute("SELECT source, day, ref FROM provenance WHERE card_id=? AND field='name'", (str(item_id),)).fetchone()
    return list(r) if r else None


BY_CHECK, BY_MINIYOU, BY_OWNER = "daily accuracy check", "mini you", "your answer on the review list"       # who made a fix (Dev Tools > Changes shows it)


def apply(conn, f, by=BY_CHECK, stamp="acc", extra=None):
    """One finding's fix on an open (writable) list.  -> (the log entry, '') or (None, why it was skipped).  Commits.
    extra: more facts kept on the log line (Mini you's score and what it saw, so a revert can teach it)."""
    if f.table not in TABLES or not f.sources:
        return None, "not a fix this log can make (unknown table, or no proof)"
    row = _row(conn, f.table, f.item_id)
    if row is None:
        return None, "the item is not in the list any more"
    entry = {"id": uuid.uuid4().hex[:12], "when": dailylog.now(), "day": provenance.today(), "game": f.game, "table": f.table, "item_id": f.item_id, "name": f.name, "rule": f.rule, "code": f.code, "action": f.action,
             "reason": f.reason, "sources": list(f.sources), "by": by, **(extra or {})}
    if f.action == REMOVE:
        entry.update(before=row, after=None)
        conn.execute(f"DELETE FROM {f.table} WHERE id=?", (f.item_id,))
    elif f.action == SET:
        cols = [c for c in f.after if c in row]
        if not cols or len(cols) != len(f.after):
            return None, "the list has no such column"
        if any(row[c] != f.before.get(c, row[c]) for c in cols):
            return None, "the item changed since it was checked"
        entry.update(before={c: row[c] for c in cols}, after={c: f.after[c] for c in cols})
        conn.execute(f"UPDATE {f.table} SET {', '.join(c + '=?' for c in cols)} WHERE id=?", [*(f.after[c] for c in cols), f.item_id])
        if "name" in cols and f.table == "cards":
            provenance.ensure(conn)
            entry["stamp_before"] = _stamp(conn, f.item_id)
            provenance.record(conn, f.item_id, "name", stamp, provenance.today())
    else:
        return None, f"unknown action {f.action}"
    _write(entry)
    conn.commit()
    return entry, ""


def undone():
    """The ids of the fixes already taken back."""
    return {e["undo_of"] for e in entries() if e.get("undo_of")}


def find(fix_id):
    """One fix of the log by its id (not an undo line), or None."""
    return next((e for e in entries() if e.get("id") == fix_id and not e.get("undo_of")), None)


def now_of(conn, entry):
    """What the item is now: {column: value} of the columns the fix wrote, or {'in_list': bool} for a removal ({} when the item is gone)."""
    row = _row(conn, entry["table"], entry["item_id"])
    if entry["action"] == REMOVE:
        return {"in_list": row is not None}
    return {c: row.get(c) for c in (entry.get("after") or {})} if row else {}


def revert(conn, entry):
    """Take one logged fix back.  -> (True, note) or (False, why not).  Commits.
    When the item already is as it was before the fix (a rebuild put the removed item or the old value back), that counts as taken back: the undo is logged all the same,
    so the fix is never made again."""
    if entry.get("undo_of"):
        return False, "that line is an undo, not a fix"
    if entry["id"] in undone():
        return False, "already undone"
    table, iid = entry["table"], entry["item_id"]
    row = _row(conn, table, iid)
    note = "put back as it was"
    if entry["action"] == REMOVE:
        if row is not None:
            note = "it was already back in the list"
        else:
            have = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
            cols = [c for c in entry["before"] if c in have]
            conn.execute(f"INSERT INTO {table}({', '.join(cols)}) VALUES({', '.join('?' * len(cols))})", [entry["before"][c] for c in cols])
    else:
        if row is None:
            return False, "the item is not in the list any more"
        if all(row.get(c) == v for c, v in entry["before"].items()):
            note = "it was already back as it was"
        elif any(row.get(c) != v for c, v in entry["after"].items()):
            return False, "the item changed since the fix"
        else:
            cols = list(entry["before"])
            conn.execute(f"UPDATE {table} SET {', '.join(c + '=?' for c in cols)} WHERE id=?", [*(entry["before"][c] for c in cols), iid])
        if "stamp_before" in entry:
            conn.execute("DELETE FROM provenance WHERE card_id=? AND field='name'", (iid,))
            if entry["stamp_before"]:
                conn.execute("INSERT INTO provenance(card_id, field, source, day, ref) VALUES(?, 'name', ?, ?, ?)", (iid, *entry["stamp_before"]))
    _write({"id": uuid.uuid4().hex[:12], "when": dailylog.now(), "undo_of": entry["id"], "game": entry["game"], "table": table, "item_id": iid, "rule": entry["rule"]})
    conn.commit()
    return True, note


def undo(conn, entry):
    """revert() + the MEMORY of it, so no checker makes that change again by itself, whatever the next rebuild brings back (a removed item, a picture, a price, a move):
      * kept (state.py): the check skips every fix of that rule on that item from now on (a move's rule is 'move', for the accuracy check and Mini you alike)
      * the owner's earlier 'no' that led to the fix is forgotten (it was not right)
      * a Mini you change taken back counts as a 'no' to Mini you: its next weekly retrain learns from it (miniyou/feedback.py)
    -> (True, note) or (False, why not).  Used by tools/accuracy_check.py --undo and Dev Tools > Changes (webapi/changesapi.py)."""
    ok, note = revert(conn, entry)
    if not ok:
        return ok, note
    from . import state
    state.keep(entry["game"], entry["table"], entry["item_id"], entry["rule"], entry.get("day") or provenance.today())
    for rule, tbl, iid, key in list(state.owner_no(entry["game"])):
        if (rule, tbl, iid) == (entry["rule"], entry["table"], entry["item_id"]):
            state.take_back(entry["game"], tbl, iid, rule, key)
    if entry.get("by") == BY_MINIYOU:
        try:
            from ..miniyou import feedback
            feedback.revert_answer(entry)
        except Exception as e:  # noqa: BLE001 - the revert itself is done; only the lesson for the retrain is lost
            note += f" (Mini you's lesson not saved: {str(e)[:80]})"
    return ok, note
