"""'Logs everything': the daily report of one accuracy run, written next to the daily update log.
  accuracy/<day>.json   everything: per game and rule how many were checked, passed and found (by case), every fix made (and every proven fix NOT made in check-only mode),
                        every review finding that can be listed, examples of the ones that are only counted, what went on the review list and what still waits
  accuracy/<day>.txt    the same as one plain page
and one 'Accuracy check' line per game in that day's Daily log (Dev Tools > Daily log), so the owner sees it where he already looks."""
import json
import os

from .. import dailylog
from . import RULES, store

KEEP_FINDINGS = 2000                     # listable findings written out one by one per game (the count of the rest is kept)


def game_part(res, applied, skipped):
    """One game's share of the report from engine.check_game()'s result."""
    rules = {r: {"checked": res["checked"].get(r, 0), "passed": res["passed"].get(r, 0), "found": dict(sorted(res["counts"].get(r, {}).items()))} for r in RULES if res["checked"].get(r)}
    fl = [f.as_dict() for f in res["findings"]]
    return {"items": res["items"], "first_run": res["first_run"], "rules": rules, "notes": res["notes"], "fixed": applied, "not_fixed": skipped,
            "findings": fl[:KEEP_FINDINGS], "findings_more": max(0, len(fl) - KEEP_FINDINGS), "examples": res["examples"]}


def totals(games):
    out = {}
    for g in games.values():
        for r, v in (g.get("rules") or {}).items():
            t = out.setdefault(r, {"checked": 0, "passed": 0, "found": {}})
            t["checked"] += v["checked"]
            t["passed"] += v["passed"]
            for code, n in v["found"].items():
                t["found"][code] = t["found"].get(code, 0) + n
    return out


def build(day, mode, games, errors, listed, waiting, seconds):
    """-> the whole report (a dict)"""
    wait = {}
    for f in waiting:
        wait[f.rule] = wait.get(f.rule, 0) + 1
    return {"day": day, "when": dailylog.now(), "mode": mode, "seconds": round(seconds, 1), "totals": totals(games), "review": {"listed": listed, "waiting": wait, "solved": sum(g.get("solved", 0) for g in games.values())},
            "fixes": sum(len(g["fixed"]) for g in games.values()), "provable_not_fixed": sum(len(g["not_fixed"]) for g in games.values()), "errors": errors, "games": games}


def text(rep):
    """The report as one plain page."""
    lines = [f"Accuracy check {rep['day']} ({rep['mode']}, {rep['seconds']} s, {len(rep['games'])} lists)", ""]
    for r in RULES:
        t = rep["totals"].get(r)
        if t:
            found = ", ".join(f"{n} {code}" for code, n in sorted(t["found"].items())) or "nothing found"
            lines.append(f"  {r:9} checked {t['checked']:>7}   passed {t['passed']:>7}   {found}")
    lines += ["", f"  fixes made: {rep['fixes']}   proven but not made (check-only, or skipped): {rep['provable_not_fixed']}",
              f"  questions closed as solved: {rep['review'].get('solved', 0)}   put on your review list this run: {rep['review']['listed']}   still waiting for a free place: {sum(rep['review']['waiting'].values())} {rep['review']['waiting'] or ''}", ""]
    for g, v in sorted(rep["games"].items()):
        parts = [f"{r}: " + ", ".join(f"{n} {c}" for c, n in rv["found"].items()) for r, rv in v["rules"].items() if rv["found"]]
        one = sum((v.get("one_source") or {}).values())
        lines.append(f"  {g:16} {sum(v['items'].values()):>7} items{' (first run: baseline)' if v['first_run'] else ''}   " + ("; ".join(parts) or "all passed") + (f"   [{one} shown as 'only one source so far']" if one else ""))
        lines += [f"      FIXED {e['table']} {e['item_id']} ({e['rule']}/{e['code']}): {e['before']} -> {e['after']}   sources: {'; '.join(e['sources'])}   [undo id {e['id']}]" for e in v["fixed"]]
    lines += [f"  ERROR {g}: {e}" for g, e in sorted(rep["errors"].items())]
    return "\n".join(lines) + "\n"


def save(rep):
    """-> (json path, text path)"""
    os.makedirs(store.folder(), exist_ok=True)
    pj, pt = os.path.join(store.folder(), rep["day"] + ".json"), os.path.join(store.folder(), rep["day"] + ".txt")
    with open(pj, "w", encoding="utf-8") as f:
        json.dump(rep, f, indent=1, ensure_ascii=False, default=str)
    with open(pt, "w", encoding="utf-8") as f:
        f.write(text(rep))
    return pj, pt


def to_daily_log(rep):
    """One 'accuracy' event per game that had findings (and one per fix) in the day's Daily log; a second run on the same day replaces the first run's lines.  -> events written"""
    day = rep["day"]
    path = os.path.join(dailylog.log_dir(), day + ".json")
    try:
        with open(path, encoding="utf-8") as f:
            daily = json.load(f)
    except (OSError, ValueError):
        daily = {"day": day, "games": {}, "events": []}
    events = [e for e in daily.get("events") or dailylog.events_of(daily) if e.get("kind") != "accuracy"]
    mine = []
    for g, v in sorted(rep["games"].items()):
        for r, rv in v["rules"].items():
            if rv["found"]:
                mine.append(dailylog.event(g, "accuracy", "Daily accuracy check", count=sum(rv["found"].values()), note=f"{r}: " + ", ".join(f"{n} {c}" for c, n in rv["found"].items())))
        mine += [dailylog.event(g, "accuracy", "; ".join(e["sources"]), e["name"], e["item_id"], 1, f"fixed ({e['rule']}/{e['code']}): {e['before']} -> {e['after']} [undo id {e['id']}]")
                 for e in v["fixed"]]
    daily["events"] = events + mine
    dailylog.save(day, daily)
    return len(mine)
