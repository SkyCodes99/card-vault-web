"""Closing the gap on the review list: after each run, every open question the checkers asked is closed when the problem is gone, with the reason shown next to it
(Dev Tools > Review list, status 'solved').  A question is only closed on proof that it was looked at again:
  - the item is no longer in its list;
  - a fix with proof was made to it this run for the same rule (undo in Dev Tools > Changes);
  - the rule looked at it again in full this run (open questions are always re-checked as if new) and asked nothing - for a Mini you part (look-alike / same-file
    picture), only when that model actually ran on it.
A question the run could not look at again stays open.  The same problem coming back reopens it (reviewlist.add_item).
Mini you's own questions close when the item is gone or a proven move/fix settled it."""
from .. import reviewlist
from . import RULES
from .items import SEALED
from .engine import BATCH_KIND, KIND, open_questions

BATCH_CODES = {"picture": ("lookalike", "same_file"), "official": ("model_only",)}
MINIYOU_KINDS = ("miniyou_real", "miniyou_place", "miniyou_photo")
PASSES = {"sources": "checked again: the sources agree with the list now",
          "picture": "checked again: the picture passes now",
          "prices": "checked again: the price looks right now",
          "official": "checked again: it looks like an official release now"}


def why_solved(q, rule, res, seen, fixed):
    """-> the reason this open question is solved, or '' (still open / could not be looked at again)."""
    b = q.get("before") or {}
    table, iid, code = b.get("_table"), str(b.get("_id")), b.get("_code") or ""
    if (table, iid) not in seen:
        return "solved: the item is no longer in the list"
    if rule == "sources" and code == "single" and (table, iid) in res.get("examined", {}).get(rule, ()):
        return "solved: no longer asked (owner, quiz 14): shown as 'Only one source so far' while the checkers look for a second source"
    if (rule, table, iid) in fixed:
        return f"solved: fixed with proof by the daily check (fix {fixed[(rule, table, iid)]}; undo in Dev Tools > Changes)"
    if (table, iid) not in res.get("examined", {}).get(rule, ()):
        return ""
    if rule in BATCH_KIND and code in BATCH_CODES.get(rule, ()) and (table, iid) not in res.get("batch_done", {}).get(rule, ()):
        return ""                                                     # (that model did not run on it this time)
    key = q["item_id"].split("@", 1)[1] if "@" in q["item_id"] else ""
    asked = {k for (r, t, i, k) in res.get("still", ()) if (r, t, i) == (rule, table, iid)}
    if key in asked:
        return ""
    if asked:
        return "solved: what it asked about changed since; the new value is checked on its own"
    return "solved: " + PASSES.get(rule, "checked again and it passes now")


def close_solved(game, res, applied):
    """After one game's run.  -> how many questions were closed"""
    seen = {(t, str(i)) for t, i, *_ in res.get("seen", ())}
    if not seen:
        return 0                                                      # (the list could not be read: nothing is closed)
    fixed = {(e["rule"], e["table"], str(e["item_id"])): e["id"] for e in applied or () if e and e.get("id")}
    n = 0
    for qs in open_questions(game).values():
        for q in qs:
            why = why_solved(q, q["kind"][len(KIND):], res, seen, fixed)
            if why and q["kind"][len(KIND):] in RULES and reviewlist.solve(q["id"], why):
                n += 1
    moved = {str(e["item_id"]): e["id"] for e in applied or () if e and e.get("id") and e.get("table") == "cards" and e.get("code") == "moved"}
    for kind in MINIYOU_KINDS:
        for q in reviewlist.items("", game, kind):
            iid = str(q["item_id"])
            why = ("solved: the item is no longer in the list" if ("cards", iid) not in seen and (SEALED, iid) not in seen
                   else f"solved: settled with proof by the daily check (fix {moved[iid]}; undo in Dev Tools > Changes)" if kind == "miniyou_place" and iid in moved else "")
            if why and reviewlist.solve(q["id"], why):
                n += 1
    return n
