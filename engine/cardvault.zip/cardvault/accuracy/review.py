"""'Sends the rest to you': what the check cannot prove goes on the owner's ONE review list (cardvault/reviewlist.py, Dev Tools > Review list), kinds accuracy_sources,
accuracy_picture, accuracy_prices and accuracy_official.  Never a flood: at most `review_cap` open questions per game and rule and OPEN_MAX open accuracy questions in all at
any time, the clearest cases first (ORDER); the rest are counted in the daily report and move up as the owner answers.

What an answer does (applied at once, through the fix log, so it can be undone):
  sources   yes to a proposed value writes it; a typed value writes that; yes to a plain question keeps the item as listed (never asked again)
  picture   yes keeps the picture; no clears it ('No picture yet') and remembers it, so the same picture is cleared again if a rebuild brings it back
  prices    yes keeps the price; no clears it (shows 'no price') and remembers it
  official  yes keeps the item; no takes it out of the list and remembers it"""
import os
import sqlite3

from .. import dailylog, reviewlist
from . import REVIEW, RULES, fixlog, state
from .engine import KIND, review_id
from .result import FIXABLE, REMOVE, SET, Finding

SOURCE = "Daily accuracy check"
OPEN_MAX = 40                            # open accuracy questions on the review list at any time, over all games and rules
ORDER = ("disagree", "currency", "absurd", "spike", "zero", "differs", "not_toy", "custom", "lot", "bundle", "standin", "same_file", "not_own", "lookalike", "shared", "single")     # which cases are asked first
_META = ("_table", "_id", "_code", "_key", "_name")


def queue(findings, cap_of, open_max=OPEN_MAX):
    """Put the listable review findings on the review list.  cap_of(finding) -> that game and pack's 'review_cap'.  -> (questions newly listed, [findings left waiting])"""
    rank = lambda f: ORDER.index(f.code) if f.code in ORDER else len(ORDER)  # noqa: E731
    todo = sorted((f for f in findings if f.status == REVIEW and f.listable), key=lambda f: (rank(f), f.game, f.table, f.item_id, f.key))
    open_now, listed, waiting = {}, 0, []
    open_all = sum(len(reviewlist.items("", "", KIND + r)) for r in RULES)
    for f in todo:
        kind = KIND + f.rule
        if (f.game, kind) not in open_now:
            open_now[(f.game, kind)] = {it["item_id"] for it in reviewlist.items("", f.game, kind)}
        mine = open_now[(f.game, kind)]
        rid = review_id(f.table, f.item_id, f.key)
        if rid in mine:
            continue                                                    # (already asked and still waiting)
        if len(mine) >= cap_of(f) or open_all + listed >= open_max:
            waiting.append(f)
            continue
        before = dict(f.before, _table=f.table, _id=f.item_id, _code=f.code, _key=f.key, _name=f.name)
        src = SOURCE + (": " + ", ".join(f.sources) if f.sources else "")
        if reviewlist.add_item(kind, f.game, rid, f.reason, before=before, after=f.after or None, source=src):
            mine.add(rid)
            listed += 1
    return listed, waiting


def _db(item, ctx):
    from ..db import game_dir
    from ..paths import release_data_dir
    return os.path.join(game_dir((ctx or {}).get("data_dir") or release_data_dir(), item["game"]), "cards.db")


def _fix(item, ctx, rule, action, before, after, why):
    """The owner's answer as a logged, undoable fix.  -> the note shown next to the answered item"""
    b = item["before"] or {}
    f = Finding(rule, b.get("_code") or "answer", FIXABLE, item["game"], b.get("_table") or "cards", str(b.get("_id")), b.get("_name") or "", item["question"] or "", before, after,
                ["your answer on the review list", why], action)
    conn = sqlite3.connect(_db(item, ctx), timeout=60)
    try:
        entry, skipped = fixlog.apply(conn, f, by="your answer on the review list", stamp="fix")
    finally:
        conn.close()
    return f"done (fix {entry['id']}; undo: tools/accuracy_check.py --undo={entry['id']})" if entry else f"nothing changed: {skipped}"


def _cols(item):
    return {k: v for k, v in (item["before"] or {}).items() if k not in _META and k != "was"}


def _remember(item, rule):
    b = item["before"] or {}
    state.say_no(item["game"], b.get("_table") or "cards", b.get("_id"), rule, b.get("_key") or "", (item["question"] or "")[:200], dailylog.now()[:10])


def _sources(item, ans, value, ctx):
    cols = _cols(item)
    if ans == "yes" and item["after"]:
        return _fix(item, ctx, "sources", SET, cols, item["after"], item["source"] or SOURCE)
    if ans == "value" and len(cols) == 1:
        return _fix(item, ctx, "sources", SET, cols, {next(iter(cols)): value}, "the value you typed")
    return "kept as listed: you confirmed it" if ans == "yes" else "noted: not right as listed; nothing was changed (no proven value)"


def _picture(item, ans, value, ctx):
    if ans != "no":
        return "kept: you confirmed the picture"
    _remember(item, "picture")
    return "picture cleared ('No picture yet'): " + _fix(item, ctx, "picture", SET, _cols(item), {"image_base": None}, "not its picture")


def _prices(item, ans, value, ctx):
    if ans != "no":
        return "kept: you confirmed the price"
    _remember(item, "prices")
    return "price cleared: " + _fix(item, ctx, "prices", SET, _cols(item), {"price_usd": None, "price_kind": None}, "not its price")


def _official(item, ans, value, ctx):
    if ans != "no":
        return "kept: you confirmed it is an official release"
    _remember(item, "official")
    return "taken out of the list: " + _fix(item, ctx, "official", REMOVE, {}, {}, "not an official release")


for _rule, _fn in (("sources", _sources), ("picture", _picture), ("prices", _prices), ("official", _official)):
    reviewlist.register(KIND + _rule, apply=_fn)
