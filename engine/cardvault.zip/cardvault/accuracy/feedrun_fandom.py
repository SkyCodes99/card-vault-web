"""Reads the Fandom wikis (feeds_fandom.py) for the lists that had no second source, through the shared polite reader (fandom.py: api.php only, cached a week, one request every 2 s
across every wiki), and stores what the wikis say as claims (same contract as feedrun.py; feedrun.FEEDS includes these).

A big wiki is read over several nights: at most BUDGET requests really go to a wiki in one run (the reader's cache keeps what was read, so the next night carries on); claims are replaced only
when the whole list was read, so a half-read wiki never drops what an earlier complete pass stated.  Hot Wheels' wiki is not here (separate permission).
docs/accuracy_sources.md has each wiki's size, what it states and what it allows."""
from . import fandom, feeds_fandom as F

BUDGET = 120                                       # (requests per wiki per run; the whole of Vanguard is about 550, so it fills over five nights)

# game -> (wiki sub-domain, categories (None = every page), extractor, number key, set name must match)
CONFIG = {
    "weissschwarz": ("weissschwarz", ("Side/Schwarz/Cards", "Side/Weiß/Cards"), F.weiss_entries, F.number_key, False),
    "vanguard": ("cardfight", ("Cards",), F.slash_entries, F.english_key, False),
    "buddyfight": ("buddyfight", ("Monster Card", "Spell Card", "Item Card"), F.slash_entries, F.english_key, False),
    "wixoss": ("wixoss", ("WIXOSS Card",), F.wixoss_entries, F.number_key, False),
    "unionarena": ("unionarena-tcg", (None,), F.union_entries, F.after_slash_key, False),            # (name only: see fandom_rows)
    "metazoo": ("metazoo", ("Playable Pages", "Beastie Pages"), F.metazoo_entries, F.metazoo_key, True),
}


def _h():
    from . import feedrun_more
    return feedrun_more


def read(game, fetcher, budget=BUDGET):
    """-> (entries or None, notes): None while the wiki is only partly read."""
    host, cats, extract, _key, _must = CONFIG[game]
    notes, spent, seen, got = [], [], set(), []
    for cat in cats:
        pg, complete = fandom.pages(fetcher, host, cat, note=notes, budget=budget, spent=spent)
        for title, text in pg:
            if title not in seen:
                seen.add(title)
                got.append((title, text))
        if not complete:
            return None, notes + [f"{game}: {len(got)} pages read so far"]
    return extract(got), notes + [f"{len(got)} pages read" + (" (from cache)" if not spent else "")]


def make(game):
    def feed(data_dir, fetcher):
        m = _h()
        host, _cats, _extract, key, must = CONFIG[game]
        entries, notes = read(game, fetcher, BUDGET if budget_override is None else budget_override)
        if entries is None:
            return m._nothing(game, "; ".join(notes)[:300])
        ours = m._ours(data_dir, game, "c.tcg_id, c.local_id, s.name, c.name", m.SET_JOIN)
        return m._done(game, F.fandom_rows(entries, ours, key, F.source_code(host), must, state_number=(game != "unionarena"), close_names=(game == "wixoss")), [o[0] for o in ours], notes)
    feed.__name__ = game
    return feed


budget_override = None                              # (tools/accuracy_sources.py --fandom-budget=N, for a one-off full read)

FEEDS = {game: make(game) for game in CONFIG}
