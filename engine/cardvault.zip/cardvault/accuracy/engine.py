"""THE ENGINE: one game's list through its rule packs.  check_game() opens the list READ-ONLY, gives every card / toy and every sealed product to the rules of its pack, runs the
rules' batch parts (the Mini you models) and returns what was found.  It changes nothing: fixes are applied by fixlog.py, review items written by review.py, the report by report.py."""
import datetime
import os
import sqlite3
import statistics

from . import FIXABLE, REVIEW, RULES, claims, items, packs, settings, state
from .. import reviewlist

KIND = "accuracy_"                       # + the rule's name = the review list's kind of item


BATCH_KIND = {"picture": "photo", "official": "real"}    # rules with a Mini you part run after the list was read, and the model each needs


def open_questions(game):
    """{(table, item id): [its open accuracy questions]} for one game."""
    out = {}
    for r in RULES:
        for q in reviewlist.items("", game, KIND + r):
            b = q.get("before") or {}
            if b.get("_table") and b.get("_id") is not None:
                out.setdefault((b["_table"], str(b["_id"])), []).append(q)
    return out


def review_id(table, item_id, key=""):
    """The id of an item's question on the review list: the item (sealed products marked 's:') + what makes the question a new one (a field, a price, a picture)."""
    return ("s:" if table == items.SEALED else "") + str(item_id) + (("@" + key) if key else "")


class Context:
    """Everything the rules look up about one game, read once."""

    def __init__(self, game, db, conn, everything=False, scorer=None, today=None):
        self.game, self.db, self.conn, self.everything, self._scorer, self.today = game, db, conn, everything, scorer, today or datetime.date.today().isoformat()
        self.gdir = os.path.dirname(db)
        have = items.tables(conn)
        self.sets = dict(conn.execute("SELECT id, name FROM sets")) if "sets" in have else {}
        self.prov_card, self.owner_fixed = {}, set()
        if "provenance" in have:
            for cid, field, src in conn.execute("SELECT card_id, field, source FROM provenance WHERE field IN ('card','name')"):
                if field == "card":
                    self.prov_card[cid] = src
                elif src == "fix":
                    self.owner_fixed.add(cid)
        self.msrp = {r[0]: (r[1], r[2]) for r in conn.execute("SELECT card_id, amount, currency FROM msrp")} if "msrp" in have else {}
        self.side = claims.side(game)
        self.seen = state.load(game)
        self.owner_no = state.owner_no(game)
        self.kept = state.kept(game)
        self._settled, self._gates, self._trend, self._ask, self._names, self._cached = {}, False, None, None, None, None
        self.deferred, self.notes = {}, {}
        self.sourced, self.one_source = set(), set()                    # (table, id) the sources rule looked at / found only one source for (saved into the list: cardvault/onesource.py)
        self.open_q = open_questions(game)                          # items with a question still waiting: looked at again in full every run, as if new

    # ---- what the rules ask
    def set_name(self, set_id):
        return self.sets.get(set_id) or ""

    def name_of(self, item_id):
        if self._names is None:
            self._names = dict(self.conn.execute("SELECT id, name FROM cards"))
        return self._names.get(item_id) or ""

    def is_new(self, item, rule=""):
        """New or edited since the last run.  On a game's first run nothing is new: that run is the baseline.  An item with an open question from `rule` counts as new for that
        rule only, so the question is looked at again in full (and closed if solved) without other rules asking new questions about it."""
        if rule and any(q["kind"] == KIND + rule for q in self.open_q.get((item["table"], str(item["id"])), ())):
            return True
        if not self.seen:
            return False
        was = self.seen.get((item["table"], item["id"]))
        return was is None or was[0] != items.fingerprint(item)

    def settled(self, rule, item, key=""):
        """Did the owner already answer this very question on the review list (confirmed = locked)?"""
        if rule not in self._settled:
            self._settled[rule] = {it["item_id"] for it in reviewlist.items("confirmed", self.game, KIND + rule)}
        return review_id(item["table"], item["id"], key) in self._settled[rule]

    def said_no(self, rule, item, key=""):
        """The owner's earlier 'no' to this very thing (-> what he was asked, the proof for doing the same again), or None."""
        return self.owner_no.get((rule, item["table"], item["id"], key))

    def _trend_fresh(self, max_age_days):
        try:
            built = datetime.date.fromisoformat(self._trend.built[:10])
            return (datetime.date.fromisoformat(self.today) - built).days <= max_age_days
        except (TypeError, ValueError):
            return False                                          # (no date on the saved prices: not trusted as a 'before')

    def price_before(self, item, max_age_days=60):
        """What the item cost before -> (price, 'at the last check' | 'its 7-day typical price' ...) or (None, '')."""
        was = self.seen.get((item["table"], item["id"]))
        if was and was[1]:
            return was[1], "at the last check"
        if self._trend is None:
            from .. import trend
            self._trend = trend.Trend(self.gdir)
        for key in (item["tcg_id"], item["id"]) if self._trend_fresh(max_age_days) else ():
            r = self._trend.rows.get(key) if key else None
            if r:
                for v, when in ((r[1], "its 7-day typical price"), (r[2], "its 30-day typical price")):
                    if v:
                        return v, when + (f", saved {self._trend.built}" if self._trend.built else "")
        if self._ask is None:
            self._ask = {}
            if "ask_history" in items.tables(self.conn):
                for cid, usd in self.conn.execute("SELECT card_id, usd FROM ask_history ORDER BY card_id, day"):
                    self._ask.setdefault(cid, []).append(usd)
        past = self._ask.get(item["id"], [])[:-1]                 # (the newest day is today's price itself)
        if len(past) >= 3:
            return statistics.median(past), f"its usual asking price over {len(past)} days"
        return None, ""

    @property
    def gates(self):
        """The owner's picture rule's own look-ups (which links are set logos, who uses which picture); None for a list without the columns it reads."""
        if self._gates is False:
            from .. import gates
            try:
                self._gates = gates.Context(self.conn, self.game)
            except sqlite3.Error:
                self._gates = None
        return self._gates

    @property
    def scorer(self):
        """Mini you's models (cardvault/miniyou), loaded on first use; None when they cannot be loaded here (the check then runs without their scores)."""
        if self._scorer is None:
            try:
                from ..miniyou.score import Scorer
                self._scorer = Scorer()
            except Exception:  # noqa: BLE001 - no numpy / no models on this machine: the plain rules still run
                self._scorer = False
        return self._scorer or None

    def has_cached_picture(self, item):
        """Is the item's product picture in the list's own picture cache (and is there a photo model to look at it)?  Only those can be compared; nothing is ever fetched for this."""
        if self._cached is None:
            self._cached = set()
            if self.scorer is not None and self.scorer.available("photo"):
                try:
                    from ..miniyou import datasets
                    self._cached = {i for _s, i in datasets.picture_index(self.gdir)}
                except Exception:  # noqa: BLE001
                    pass
        return item["id"] in self._cached

    def defer(self, rule, item, cfg):
        self.deferred.setdefault(rule, []).append((item, cfg))

    def note(self, key, n=1):
        self.notes[key] = self.notes.get(key, 0) + n


EXAMPLES = 5                             # findings that are only counted (never listed) are kept as this many examples per rule and case, not one by one


def check_game(game, db, everything=False, scorer=None, data=None, today=None):
    """-> {game, items: {table: n}, findings: [Finding] (every fix and every listable review item), counts: {rule: {code: n}}, examples: {"rule.code": [Finding dicts]},
    passed: {rule: n}, checked: {rule: n}, notes, seen: [(table, id, fingerprint, price)], first_run,
    sourced / one_source: {(table, id)} the sources rule looked at / found only ONE source for (every such item, whatever the pack lists)}"""
    data = data or settings.load()
    conn = items.open_ro(db)
    try:
        ctx = Context(game, db, conn, everything, scorer, today)
        found, seen, n_items, checked, hit, counts, examples = [], [], {}, {}, {}, {}, {}
        examined, still = {}, set()                                  # (for closing solved questions) open items each rule looked at; every question asked this run

        def take(findings):
            for f in findings:
                if f.status == FIXABLE and (f.rule, f.table, f.item_id) in ctx.kept:
                    ctx.note(f"{f.rule}.kept_after_undo")            # (a fix that was undone is not made again by itself)
                    continue
                if f.status == REVIEW:
                    still.add((f.rule, f.table, str(f.item_id), f.key))
                counts.setdefault(f.rule, {})[f.code] = counts.setdefault(f.rule, {}).get(f.code, 0) + 1
                hit.setdefault(f.rule, set()).add((f.table, f.item_id))
                if f.status == FIXABLE or f.listable:
                    found.append(f)
                elif len(examples.setdefault(f"{f.rule}.{f.code}", [])) < EXAMPLES:
                    examples[f"{f.rule}.{f.code}"].append(f.as_dict())

        for table in (items.CARDS, items.SEALED):
            cfg = settings.for_item(game, table, data)
            rules = packs.rules_of(cfg)
            for it in items.read(conn, game, table):
                n_items[table] = n_items.get(table, 0) + 1
                seen.append((table, it["id"], items.fingerprint(it), it["price"]))
                for rule in rules:
                    checked[rule.RULE] = checked.get(rule.RULE, 0) + 1
                    if (table, str(it["id"])) in ctx.open_q:
                        examined.setdefault(rule.RULE, set()).add((table, str(it["id"])))
                    take(rule.check(it, cfg, ctx))
        for name, rule in packs.RULES.items():
            if hasattr(rule, "batch") and ctx.deferred.get(name):
                take(rule.batch(ctx.deferred[name], ctx, found) if name == "official" else rule.batch(ctx.deferred[name], ctx))
        sc = ctx._scorer or None                                     # (only loaded when something was handed to a batch part)
        batch_done = {name: ({(it["table"], str(it["id"])) for it, _ in ctx.deferred.get(name, ())} if sc is not None and sc.available(kind) else set()) for name, kind in BATCH_KIND.items()}
        passed = {r: n - len(hit.get(r, ())) for r, n in checked.items()}
        return {"game": game, "items": n_items, "findings": found, "counts": counts, "examples": examples, "passed": passed, "checked": checked, "notes": ctx.notes, "seen": seen,
                "first_run": not ctx.seen, "examined": examined, "still": still, "batch_done": batch_done,
                "sourced": ctx.sourced, "one_source": ctx.one_source}
    finally:
        conn.close()


def fixes(result):
    return [f for f in result["findings"] if f.status == FIXABLE]


def reviews(result):
    return [f for f in result["findings"] if f.status == REVIEW]
