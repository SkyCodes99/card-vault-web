"""Reads Fandom wikis (MediaWiki API only) through the shared polite reader, for the accuracy check's second sources and the toy depth check.

Rules kept here, the same for every wiki:
  - the owner allows Fandom (CHECKPOINT / docs/accuracy_sources.md); one site rule ("fandom-wikis") covers every wiki host listed in WIKIS, so ONE rate limit (2 s) is shared by all of them;
  - only api.php is read, never the web pages (those answer a bot check, which is never worked around); the answers are cached by the reader (max_age) so a night asks a wiki at most once a week;
  - robots.txt goes through the reader's RFC 9309 gate: Fandom answers a plain client's robots.txt request with its bot-check page (HTTP 403 = "no robots file" in RFC 9309), so the gate cannot
    list rules; docs/accuracy_sources.md says so.  Hot Wheels' wiki is NOT in WIKIS (it waits on a separate permission).
  - the text is CC BY-SA (credits rows in ui/src/legal/sources.json): only facts (name / number / set) are kept, as claims; no wording, no pictures.

api(fetcher, host, **params) -> decoded json or None;  pages(fetcher, host, ...) -> [(title, wikitext)];  template_params(wikitext, names) -> {param: value} of the first matching template."""
import re
from urllib.parse import urlencode

from ..sources import rules

DAY = 20 * 3600
WEEK = 6 * 24 * 3600

# host key (the sub-domain) -> (wiki name, credit url).  Only wikis the accuracy feeds / depth check read.
WIKIS = {
    "funko": "Funko Wiki",
    "weissschwarz": "Weiss Schwarz Wiki",
    "cardfight": "Cardfight!! Vanguard Wiki",
    "buddyfight": "Future Card Buddyfight Wiki",
    "wixoss": "WIXOSS Wiki",
    "battle-spirits": "Battle Spirits Wiki",
    "unionarena-tcg": "Union Arena TCG Wiki",
    "metazoo": "MetaZoo Wiki",
    "shadowverse": "Shadowverse Wiki",
    "beyblade": "Beyblade Wiki",
    "bakugan": "Bakugan Wiki",
    "needoh": "NeeDoh Wiki",
    "transformers": "Teletraan I: The Transformers Wiki",
}

rules.add(rules.SiteRule("fandom-wikis", "Fandom wikis (CC BY-SA)", tuple(f"{k}.fandom.com" for k in WIKIS), 2.0, "data",
                         "Owner allows Fandom.  api.php only (the web pages sit behind a bot check, never worked around); cached up to a week; one request every 2 s across all wikis; "
                         "robots.txt is answered with a bot-check page (HTTP 403 = no robots file, RFC 9309).  Text is CC BY-SA: facts only, credited.  Hot Wheels' wiki is not read "
                         "(separate permission pending).", "https://www.fandom.com/terms-of-use"))


def url(host, **params):
    return f"https://{host}.fandom.com/api.php?" + urlencode(dict(params, format="json"))


def api(fetcher, host, max_age=WEEK, spent=None, **params):
    """One API call -> decoded json, or None when the wiki cannot be read (the reader's refusal, a block, a bad answer).  spent (a list) gets one entry per call that really went to the wiki."""
    from ..sources import SourceError
    try:
        got = fetcher.get(url(host, **params), max_age=max_age)
    except SourceError:
        return None
    if spent is not None and not getattr(got, "from_cache", False):
        spent.append(1)
    if got.status != 200 or not got.body:
        return None
    try:
        d = got.json()
    except ValueError:
        return None
    return d if isinstance(d, dict) and "error" not in d else None


def statistics(fetcher, host):
    d = api(fetcher, host, action="query", meta="siteinfo", siprop="statistics")
    return ((d or {}).get("query") or {}).get("statistics")


def category_size(fetcher, host, category):
    """-> {pages, subcats, files, size} of one category (the wiki's own count) or None."""
    d = api(fetcher, host, action="query", prop="categoryinfo", titles="Category:" + category)
    for p in (((d or {}).get("query") or {}).get("pages") or {}).values():
        if p.get("categoryinfo"):
            return p["categoryinfo"]
    return None


def pages(fetcher, host, category=None, limit=None, max_age=WEEK, note=None, budget=None, spent=None):
    """([(title, wikitext)], complete) of every page of a category (or of the whole main namespace when category is None), 50 at a time (the wiki's cap for page text).
    A call that fails ends the list there (complete False) and appends the reason to `note` (a list): the caller decides whether half a list is enough.
    budget: at most this many calls really go to the wiki in one go; the pages read so far stay in the reader's cache, so the next run carries on where this one stopped."""
    out, cont = [], {}
    spent = [] if spent is None else spent
    while True:
        if budget is not None and len(spent) >= budget:
            if note is not None:
                note.append(f"{host}: read {len(out)} pages tonight, the rest follows on the next runs")
            return out, False
        params = dict(action="query", prop="revisions", rvprop="content", rvslots="main", **cont)
        if category:
            params.update(generator="categorymembers", gcmtitle="Category:" + category, gcmnamespace=0, gcmlimit=50, gcmtype="page")
        else:
            params.update(generator="allpages", gapnamespace=0, gaplimit=50, gapfilterredir="nonredirects")
        d = api(fetcher, host, max_age=max_age, spent=spent, **params)
        if d is None:
            if note is not None:
                note.append(f"{host}: a page of the list could not be read after {len(out)} pages")
            return out, False
        for p in sorted(((d.get("query") or {}).get("pages") or {}).values(), key=lambda p: p.get("title", "")):
            revs = p.get("revisions") or []
            text = ((revs[0].get("slots") or {}).get("main") or {}).get("*") if revs else None
            if text:
                out.append((p["title"], text))
        cont = d.get("continue") or {}
        if not cont or (limit and len(out) >= limit):
            break
    return out, True


# ------------------------------------------------------------------------------------------------ wikitext
def _split_top(body):
    """The top-level '|' separated parts of a template body (nested {{ }} and [[ ]] stay whole)."""
    parts, depth, cur, i = [], 0, [], 0
    while i < len(body):
        two = body[i:i + 2]
        if two in ("{{", "[["):
            depth += 1
            cur.append(two)
            i += 2
        elif two in ("}}", "]]"):
            depth -= 1
            cur.append(two)
            i += 2
        elif body[i] == "|" and depth == 0:
            parts.append("".join(cur))
            cur, i = [], i + 1
        else:
            cur.append(body[i])
            i += 1
    parts.append("".join(cur))
    return parts


def template_params(text, names):
    """The parameters of the first template whose name (case-insensitive) is one of `names` -> {lower-case param: value}; {} when there is none.  Unnamed parts are dropped."""
    wanted = {n.lower() for n in names}
    for m in re.finditer(r"\{\{\s*([^|{}\n]+?)\s*(?=\|)", text or ""):
        if m.group(1).strip().lower() not in wanted:
            continue
        depth, i = 0, m.start()
        while i < len(text):
            two = text[i:i + 2]
            if two == "{{":
                depth += 1
                i += 2
            elif two == "}}":
                depth -= 1
                i += 2
                if depth == 0:
                    break
            else:
                i += 1
        body = text[m.end():i - 2]
        out = {}
        for part in _split_top(body)[0:]:
            if "=" in part:
                k, v = part.split("=", 1)
                out[k.strip().lower()] = v.strip()
        return out
    return {}


def plain(value):
    """Wikitext of a parameter -> plain text (links / templates / html dropped)."""
    s = re.sub(r"<ref[^>]*?/>|<ref[^>]*>.*?</ref>|<!--.*?-->", "", value or "", flags=re.S)
    s = re.sub(r"\{\{(?:Ruby|ruby)\|([^|}]*)\|[^}]*\}\}", r"\1", s)
    s = re.sub(r"\[\[(?:File|Image):[^\]]*\]\]", "", s, flags=re.I)
    s = re.sub(r"\[\[(?:[^\]|]*\|)?([^\]]*)\]\]", r"\1", s)
    s = re.sub(r"<br\s*/?>", " ", s, flags=re.I)
    s = re.sub(r"\{\{[^{}]*\}\}|<[^>]+>|'{2,5}", "", s)
    return re.sub(r"\s+", " ", s).strip()
