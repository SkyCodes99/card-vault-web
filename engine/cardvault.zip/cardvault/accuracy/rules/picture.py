"""THE PICTURE MATCHES THE ITEM.  Nothing here is fetched: the link is judged with the owner's picture rule (cardvault/gates.py: stand-in links, the item's own product record, a
picture shared with other items) and, for new or edited items whose product picture is in the list's own picture cache, with Mini you's photo matcher (cardvault/miniyou): a picture
that looks like ANOTHER item's picture of the same set may be a stand-in.

  standin    REVIEW: the link looks like a stand-in (logo, set symbol, sample, 'no image'), or - in a card list - is a set's logo
  not_own    REVIEW: (card lists) the link is not from the item's own product record (the TCGplayer picture of another product, TCGdex's picture of another card ...)
  shared     REVIEW: the very same picture link is used by other items
  same_file  REVIEW: its cached product picture is byte for byte the cached picture of another item of its set that has a different name
  lookalike  REVIEW (listed when the pack sets 'photo_list' AND the model in use passed the hard look-alike test, else only counted): Mini you's photo matcher scores it
             as the same picture as another item's with a different name.  On the first real run (2026-11-13) an older model scored 1.00 for different cards with the same
             frame (Clefable / Wigglytuff); the model trained with those hard pairs (artwork window) holds 99.7 % on them, and against up to 30 other-name items of its set
             flags about 2.5 % of new items wrongly (docs/miniyou_report.md).  Product pictures only, never anybody's own photos; nothing leaves this PC.

Never a fix by itself: a wrong picture cannot be PROVEN from a link, and the right one is not known.  The owner's 'no' on the review list clears the picture ('No picture yet');
only that answer is proof, so only the very picture he refused is cleared again if a rebuild brings it back (not_its_picture, FIXABLE).
An item with no picture passes: the owner's rule lets it go live with 'No picture yet'."""
import hashlib
import os
import re

from ..result import fixable, review
from ... import gates

RULE = "picture"


def url_key(url):
    """What makes the question a new one: the picture itself (a changed picture is asked about again)."""
    return hashlib.sha1(url.encode("utf-8")).hexdigest()[:10]


def check(item, cfg, ctx):
    url = item["image"].strip()
    if not url:
        return []
    said_no = ctx.said_no(RULE, item, url_key(url))
    if said_no:
        return [fixable(RULE, "not_its_picture", item, "you said this is not its picture, and a rebuild brought it back", {"image_base": url}, {"image_base": None},
                        ["your answer on the review list: " + said_no])]
    if ctx.settled(RULE, item, url_key(url)):
        return []
    cards = item["table"] == "cards"
    g = ctx.gates
    why = []
    if gates.PLACEHOLDER.search(url.split("#")[0].split("?")[0]):
        why.append(("standin", "its picture link looks like a stand-in (a logo, set symbol, sample or 'no image'), not the item"))
    elif cards and cfg.get("picture_own_record") and g is not None and url in g.logos:
        why.append(("standin", "its picture is a set's logo, not the card"))
    if cards and cfg.get("picture_own_record"):
        w = gates.own_record(item["game"], {"id": item["id"], "tcg_id": item["tcg_id"], "set_id": item["set_id"], "number": item["number"], "raw": item["raw"]}, url)
        if w:
            why.append(("not_own", "its picture is " + w))
    if cards and cfg.get("picture_shared") and g is not None:
        others = g.users().get(url, set()) - {str(item["tcg_id"] or item["id"])}
        if others:
            why.append(("shared", f"its picture is also the picture of {len(others)} other item(s) ({', '.join(sorted(others)[:3])})"))
    if cards and (ctx.everything or ctx.is_new(item, RULE)) and len(ctx.deferred.get(RULE, ())) < cfg.get("photo_max", 200) and ctx.has_cached_picture(item):
        ctx.defer(RULE, item, cfg)                                   # the photo matcher looks at it after the list was read (batch)
    if not why:
        return []
    return [review(RULE, why[0][0], item, f"Is this the right picture of {item['name']}? {'; '.join(w for _, w in why).capitalize()}.", {"image_base": url}, key=url_key(url))]


def _base(name):
    """A name without its variant tail: 'Lunalight Masquerade (Secret Rare)' and 'Unown [A]' are the cards they are printings of."""
    return re.sub(r"\s*[\(\[].*", "", name or "").strip().lower()


def _sha1(path, memo):
    if path not in memo:
        with open(path, "rb") as f:
            memo[path] = hashlib.sha1(f.read()).hexdigest()
    return memo[path]


def same_file(pics, item_id, memo):
    """The other item of the set whose cached picture FILE is identical (same size first, then the same bytes), or ''."""
    try:
        size = os.path.getsize(pics[item_id])
        for other in sorted(pics):
            if other != item_id and os.path.getsize(pics[other]) == size and _sha1(pics[other], memo) == _sha1(pics[item_id], memo):
                return other
    except OSError:
        pass
    return ""


def batch(deferred, ctx):
    """The cached product pictures of the new / edited items (at most the pack's photo_max per game): identical files, then Mini you's photo matcher."""
    scorer = ctx.scorer
    if not deferred or scorer is None or not scorer.available("photo"):
        return []
    from ...miniyou import hook
    by_id = {it["id"]: (it, cfg) for it, cfg in deferred}
    ctx.note("picture.photo_scored", len(by_id))
    out, memo = [], {}
    for i, best, who, pics in hook.lookalikes(scorer, ctx.gdir, list(by_id)):
        it, cfg = by_id[i]
        twin = same_file(pics, i, memo)
        if twin and _base(ctx.name_of(twin)) != _base(it["name"]):
            out.append(review(RULE, "same_file", it, f"Is this the right picture of {it['name']}? Its saved picture is exactly the same file as the picture of {ctx.name_of(twin) or twin}.",
                              {"image_base": it["image"]}, sources=["the list's own picture cache"], key=url_key(it["image"])))
        elif scorer.lookalike(best) == "review" and _base(ctx.name_of(who)) != _base(it["name"]):
            out.append(review(RULE, "lookalike", it, f"Is this the right picture of {it['name']}? It looks like the picture of {ctx.name_of(who) or who} (photo score {best:.2f}).",
                              {"image_base": it["image"]}, sources=[scorer.label("photo")], listable=bool(cfg.get("photo_list")) and scorer.hard_tested(), key=url_key(it["image"])))
    return out
