"""PRICES MAKE SENSE.  A price is checked on its own and against what the item cost before:

  negative  FIXABLE (cleared to 'no price'): a price below $0 is not a price
  zero      FIXABLE (cleared) for a market / asking price of $0.00 - nothing sold or is offered for nothing; a RETAIL price of $0 may be a real giveaway, so that one is REVIEW
  absurd    REVIEW: above the pack's ceiling or below its floor
  currency  REVIEW: the amount is its source's price in another currency (yen, pounds, euros) stored as dollars
  spike     REVIEW: 10x up or down (and by at least the pack's minimum) against the last check, else the saved 7 / 30 day typical price (when that file is not older than
            the pack's history_max_age_days), else its usual asking price

Not here on purpose: a listing-only price of $20,000 or more is dropped where prices are read (cardvault/listingcap.py, the owner's decision); such a price is skipped, not judged twice.
A cleared price shows as 'no price' until the source states a real one.  A price the owner confirmed on the review list is not asked about again."""
import math
import re

from ..result import fixable, review
from ... import listingcap

RULE = "prices"
_FOREIGN = re.compile(r"(¥|£|€|\bJPY\b|\bGBP\b|\bEUR\b|\bCAD\b|\bAUD\b)\s*([\d][\d,]*(?:\.\d+)?)|([\d][\d,]*(?:\.\d+)?)\s*(¥|£|€|\bJPY\b|\bGBP\b|\bEUR\b|\bCAD\b|\bAUD\b|\byen\b)", re.I)
_CLEARED = {"price_usd": None, "price_kind": None}


def _money(v):
    return f"${v:,.2f}"


def foreign_amount(item, msrp):
    """The source's price in another currency when it equals the stored dollar amount -> 'JPY 16,800' or ''.  msrp: (amount, currency) of the item's row in the list's msrp table."""
    p = item["price"]
    if msrp and msrp[1] and msrp[1].upper() != "USD" and abs(float(msrp[0]) - p) < 0.005:
        return f"{msrp[1].upper()} {msrp[0]:,.0f}"
    text = str((item["raw"].get("ext") or {}).get("Retail price") or "") if isinstance(item["raw"].get("ext"), dict) else ""
    for m in _FOREIGN.finditer(text):
        num, cur = (m.group(2), m.group(1)) if m.group(1) else (m.group(3), m.group(4))
        try:
            if abs(float(num.replace(",", "")) - p) < 0.005:
                return f"{cur} {num}"
        except ValueError:
            continue
    return ""


def check(item, cfg, ctx):
    p, kind = item["price"], item["price_kind"] or ""
    if p is None:
        return []
    now = {"price_usd": p, "price_kind": item["price_kind"]}
    if not isinstance(p, (int, float)) or math.isnan(p) or p < 0:
        return [fixable(RULE, "negative", item, f"its price is {p}", now, _CLEARED, ["rule: a price below $0 is not a price"])]
    if p == 0:
        if cfg.get("zero_fix") and kind != "retail price":
            return [fixable(RULE, "zero", item, "its price is $0.00", now, _CLEARED, ["rule: a market or asking price of $0.00 is not a price"])]
        return [] if ctx.settled(RULE, item, "0") else [review(RULE, "zero", item, f"Its {kind or 'price'} is $0.00. Is it really free?", now, key="0")]
    if listingcap.is_placeholder(p, kind):
        return []
    said_no = ctx.said_no(RULE, item, f"{p:g}")
    if said_no:
        return [fixable(RULE, "not_its_price", item, f"you said {_money(p)} is not right, and it came back", now, _CLEARED, ["your answer on the review list: " + said_no])]
    if ctx.settled(RULE, item, f"{p:g}"):
        return []
    label = kind or "market price"
    if p > cfg["absurd_max_usd"] or p < cfg["absurd_min_usd"]:
        return [review(RULE, "absurd", item, f"Its {label} is {_money(p)}. Is that right?", now, key=f"{p:g}")]
    other = foreign_amount(item, ctx.msrp.get(item["id"]))
    if other:
        return [review(RULE, "currency", item, f"Its {label} is {_money(p)}, but its source states {other}: the amount looks stored in the wrong currency. Is {_money(p)} right?", now, key=f"{p:g}")]
    ref, when = ctx.price_before(item, cfg.get("history_max_age_days", 60))
    if ref and ref > 0:
        big, small = max(p, ref), min(p, ref)
        if big / small >= cfg["spike_ratio"] and big - small >= cfg["spike_min_usd"]:
            return [review(RULE, "spike", item, f"Its {label} went from {_money(ref)} ({when}) to {_money(p)}. Is {_money(p)} right?", dict(now, was=ref), key=f"{p:g}")]
    return []
