"""SOURCES AGREE: two or more independent sources must state an item's name, number and set (claims.py says who states what).

  pass       every field the pack checks is stated the same way by 2+ sources
  single     a field has fewer than 2 sources: counted, never fixed and NEVER put on the review list (owner, quiz 14 Q1, 2026-11-13: "try to find a 2nd source, but they can be displayed on the
             site with a disclaimer"): the item is flagged 'only one source so far' in the published list (cardvault/onesource.py) and the next run clears the flag when a 2nd source agrees
  corrected  FIXABLE: the list says X, but 2+ sources agree on Y, nobody states X, and the source the list is built from is one of them (so Y is written the way the list writes it).
             Only for the fields the pack lets it fix ('fix_fields', name and number).
  moved      FIXABLE (rule 'move', ../moves.py): a card's SET, proven - 2+ independent sources agree on another set of this game, no source backs the current one, the owner did
             not place it himself.  When Mini you is sure of a third set: disagree (ONE question, nothing moves).  (Owner, chat 2026-11-13; replaces the old lane-made
             'a set is never moved by itself' rule, which had no owner source.)
  differs    REVIEW, with the other value as a proposal: one source disagrees, or sources disagree among themselves
A name the owner corrected himself (provenance 'fix') and an item he already settled on the review list are left alone."""
import re
import unicodedata

from .. import MIN_SOURCES, claims, moves
from ..result import fixable, review
from ... import gates

RULE = "sources"
_COL = {"name": "name", "number": "local_id", "set": "set_id"}


def _plain(s):
    """Lower case, accents dropped ('Mamá' is 'mama', 'Kā' is 'ka'), any script kept (a Japanese name is not folded away to nothing)."""
    s = unicodedata.normalize("NFKD", str(s or ""))
    return "".join(ch for ch in s if not unicodedata.combining(ch)).lower()


def _fold(s):
    return re.sub(r"[\W_]+", "", _plain(s))


_BRACKETS = re.compile(r"\s*[\(\[（【].*?[\)\]）】]")
_SIZE = re.compile(r"\s*\d+\s*(?:\"|”|-?inch\b|in\b)")
_LEAD = re.compile(r"^(?:the|basic|token)\s+")


def _variants(s):
    """The ways sources write one name: as is, without brackets / a size / a ' - 022' number tail, and the part after a franchise prefix ('Star Wars: Nalan Cheel')."""
    base = _SIZE.sub("", _BRACKETS.sub("", _plain(s)))
    base = re.sub(r"\s+-\s+\d+\s*$", "", base).strip()
    out = {base}
    if ": " in base:
        out.add(base.split(": ")[-1])
    return {_LEAD.sub("", v.strip()) for v in out if v.strip()}


def _tok_in(t, words):
    return t in words or (len(t) == 1 and any(w.startswith(t) for w in words))     # ('Red-Eyes B. Dragon' is 'Red-Eyes Black Dragon')


def _same_name(a, b):
    """Same name, or one carries a tail the other leaves out ('Charcadet - 022 (Pokemon Center Exclusive)'), or every word of the shorter is in the longer
    ('Kuriboh Token' / 'Token: Kuriboh', 'Cliff the Trap Remover' / 'Dark Scorpion - Cliff the Trap Remover').  Two names with no word in common are different names."""
    fa, fb = _fold(a), _fold(b)
    if not (fa and fb):
        return False
    if fa == fb or fa.startswith(fb) or fb.startswith(fa):
        return True
    for x in _variants(a):
        for y in _variants(b):
            if _fold(x) and (_fold(x) == _fold(y) or _fold(x).startswith(_fold(y)) or _fold(y).startswith(_fold(x))):
                return True
            tx, ty = re.findall(r"[^\W_]+", x), re.findall(r"[^\W_]+", y)
            for small, big in ((tx, ty), (ty, tx)):
                if small and len(small) <= len(big) and any(len(t) >= 3 for t in small) and all(_tok_in(t, big) for t in small):
                    return True
    return False


def _latin(s):
    """Is the name written in Latin letters (else Japanese, Chinese, Korean ...)?"""
    letters = [ch for ch in str(s or "") if ch.isalpha()]
    return bool(letters) and sum(ord(ch) < 0x250 for ch in letters) * 2 >= len(letters)


def _same_number(a, b):
    return gates.numkey(a) == gates.numkey(b)


def _same_setname(a, b):
    """('ME06: Delta Reign' is 'Delta Reign'; 'Commander: Reality Fracture' is 'Reality Fracture Commander')"""
    for x in {str(a), str(a).split(":")[-1]}:
        for y in {str(b), str(b).split(":")[-1]}:
            fx, fy = _fold(x), _fold(y)
            if fx and fy and (fx == fy or fx in fy or fy in fx):
                return True
    tx, ty = set(re.findall(r"[^\W_]+", _plain(a))), set(re.findall(r"[^\W_]+", _plain(b)))
    small, big = (tx, ty) if len(tx) <= len(ty) else (ty, tx)
    return len(small) >= 2 and small <= big


def _stated(field, item, cl, ctx):
    """-> ({source: the value it states}, {source: True when it agrees with the list})"""
    said, agrees = {}, {}
    for src, c in cl.items():
        if field == "name" and c.get("name"):
            ours = [n for n in (item["name"], item["name_en"], item["name_ja"]) if n]
            if ours and not any(_latin(n) == _latin(c["name"]) for n in ours):
                continue                                                           # (an English name next to only Japanese ones: nothing to compare, not a disagreement)
            said[src] = c["name"]
            agrees[src] = any(_same_name(c["name"], n) for n in ours)
        elif field == "number" and c.get("number"):
            said[src] = c["number"]
            agrees[src] = _same_number(c["number"], item["number"])
        elif field == "set" and c.get("set_id"):
            said[src] = c["set_id"]
            agrees[src] = c["set_id"].lower() == item["set_id"].lower()
        elif field == "set" and c.get("set_name") and _same_setname(c["set_name"], item["set_name"] or ctx.set_name(item["set_id"])):
            said[src], agrees[src] = c["set_name"], True            # (a set's NAME can confirm; a different name is no disagreement: sources name the same set differently)
    return said, agrees


def _groups(field, said, agrees):
    """The sources that disagree with the list, grouped by what they say -> [[source, ...]] biggest first."""
    same = {"name": _same_name, "number": _same_number}.get(field, lambda a, b: _fold(a) == _fold(b))
    groups = []
    for src in sorted(s for s in said if not agrees[s]):
        for g in groups:
            if same(said[g[0]], said[src]):
                g.append(src)
                break
        else:
            groups.append([src])
    return sorted(groups, key=len, reverse=True)


def check(item, cfg, ctx):
    cl = claims.for_item(item, ctx.prov_card.get(item["id"]), ctx.side)
    org = claims.origin(item, ctx.prov_card.get(item["id"]))
    out, single = [], []
    ctx.sourced.add((item["table"], item["id"]))
    for field in cfg["fields"]:
        ours = item["set_id"] if field == "set" else item[field]
        said, agrees = _stated(field, item, cl, ctx)
        if not ours and not said:
            continue                                                               # (a toy has no number: nothing to state)
        if (field == "name" and item["id"] in ctx.owner_fixed) or ctx.settled(RULE, item, field):
            continue
        if field == "set":
            mv = moves.check(item, cl, ctx)                                        # a proven move, or ONE question when the checkers disagree (None: the usual checks below)
            if mv is not None:
                out.append(mv)
                continue
        if len(said) < MIN_SOURCES:
            single.append(field)
            continue
        groups = _groups(field, said, agrees)
        if not groups:
            continue
        top, backers = groups[0], sorted(s for s in said if agrees[s])
        names = [f"{claims.label(s)} ({said[s]})" for s in top]
        col = _COL[field]
        if len(top) >= MIN_SOURCES and not backers and len(groups) == 1 and org in top and field in cfg.get("fix_fields", ("name", "number")) and item["table"] == "cards":
            out.append(fixable(RULE, "corrected", item, f"the {field} is '{ours}' but {len(top)} sources agree it is '{said[org]}'", {col: ours}, {col: said[org]}, names, need=MIN_SOURCES))
        else:
            others = "; ".join(f"{claims.label(s)} says '{said[s]}'" for g in groups for s in g)
            back = f" ({', '.join(claims.label(s) for s in backers)} agree with the list)" if backers else ""
            prop = {col: said[org if org in top else top[0]]} if len(groups) == 1 and field != "set" else {}
            out.append(review(RULE, "differs", item, f"Its {field} is '{ours}' in the list, but {others}{back}. Which is right?", {col: ours}, prop, names, key=field))
    if single:
        ctx.one_source.add((item["table"], item["id"]))                            # (flagged in the published list, whatever the owner answered: the item still has one source)
    if single and not ctx.settled(RULE, item, "single"):
        who = ", ".join(claims.label(s) for s in sorted(cl)) or "no source"
        out.append(review(RULE, "single", item, f"Only one source ({who}) states its {' / '.join(single)}; the daily check keeps looking for a second.", sources=[claims.label(s) for s in sorted(cl)], listable=False, key="single"))
    return out
