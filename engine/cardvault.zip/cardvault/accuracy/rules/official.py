"""NO CUSTOMS, BUNDLES OR LOTS: every entry of a list is one official release.

  not_official  FIXABLE (the entry is taken out; the whole row is kept in the fix log): it is on toyrules.NOT_OFFICIAL, or the owner said 'no' to it on the review list before
                (a daily rebuild brought it back)
  not_toy       REVIEW: the toy list's own leave-out rules (cardvault/toyrules.py) say it is an accessory / merchandise / a nameless mystery listing.  Those rules read a shop's
                OWN title, so they are asked only of rows that kept one (a handle such as 'not-a-sticker-2' or a name such as 'Pumpkin Patch Mini' would fool them)
  custom        REVIEW: its name says custom, proxy, fan-made, unofficial, bootleg, replica, repack
  lot           REVIEW: its name says it is a lot ('lot of 12', 'bulk lot')
  bundle        REVIEW: its name says bundle, in a pack where a bundle is not a product of its own (in the sealed pack a Booster Bundle is one: no bundle words there)
  model_only    counted, not listed: only Mini you's real-release model doubts it.  That model only SCORES (docs/miniyou_report.md: it may not act alone), so its doubt alone
                never reaches the review list; when a rule above fires too, the score is added to the question.

The word lists are per pack and per game (settings).  A 'yes' on the review list keeps the entry for good; a 'no' takes it out and remembers it."""
from ..result import REMOVE, fixable, review
from ... import toyrules

RULE = "official"


def title_of(item):
    """The shop's own title, where the row kept it ('' otherwise)."""
    return str(item["raw"].get("title") or item["raw"].get("_shop_title") or "")


def words_of(item):
    """Everything the row says the item is called, for the word lists: its name, the shop's title, and its shop handle as words ('...-vinyl-figure-bundle-by-sket-one')."""
    return " | ".join(x for x in (item["name"], title_of(item), str(item["raw"].get("handle") or "").replace("-", " ")) if x)


def check(item, cfg, ctx):
    said_no = ctx.said_no(RULE, item)
    if said_no:
        return [fixable(RULE, "not_official", item, "you said it is not an official release, and a rebuild brought it back", {"id": item["id"]}, {}, ["your answer on the review list: " + said_no], REMOVE)]
    if ctx.settled(RULE, item):
        return []
    title = title_of(item)
    what, why = toyrules.not_a_release(item["game"], item["id"], title, item["raw"].get("tags") or ()) if item["table"] == "cards" else ("", "")
    if what == "listed":
        return [fixable(RULE, "not_official", item, why, {"id": item["id"]}, {}, ["toyrules.NOT_OFFICIAL (collector feedback, kept in cardvault/toyrules.py)"], REMOVE)]
    text = words_of(item)
    code = "not_toy" if what else ""
    for c, key in (("custom", "not_official_words_re"), ("lot", "lot_words_re"), ("bundle", "bundle_words_re")):
        m = None if code else (cfg.get(key).search(text) if cfg.get(key) else None)
        if m:
            code, why = c, f"its name says '{m.group(0)}'"
    if cfg.get("model_real") and (ctx.everything or ctx.is_new(item, RULE) or code):
        ctx.defer(RULE, item, cfg)                                   # scored by the real-release model after the list was read (batch)
    if not code:
        return []
    return [review(RULE, code, item, f'Is "{item["name"]}" an official release of its own (not a custom, a bundle or a lot)? {why[0].upper() + why[1:]}.', {"id": item["id"], "name": item["name"]})]


def batch(deferred, ctx, found=()):
    """Mini you's real-release score for the deferred items.  A low score alone is only counted (model_only); on an item a rule already listed, the score joins the question."""
    scorer = ctx.scorer
    if not deferred or scorer is None or not scorer.available("real"):
        return []
    from ...miniyou import textfeat
    items = [it for it, _ in deferred]
    listed = {(f.table, f.item_id): f for f in found if f.rule == RULE and f.listable}
    ctx.note("official.model_scored", len(items))
    out = []
    for it, (p, d) in zip(items, scorer.real([textfeat.norm(it["name"]) for it in items])):
        if d != "review" or p is None:
            continue
        f = listed.get((it["table"], it["id"]))
        if f is not None:
            f.reason += f" {scorer.label('real')} agrees it may not be one (score {p:.2f})."
            f.sources.append(scorer.label("real"))
        else:
            out.append(review(RULE, "model_only", it, f"{scorer.label('real')} scores it {p:.2f}: it may not be an official release (score only, not listed)", sources=[scorer.label("real")], listable=False))
    return out
