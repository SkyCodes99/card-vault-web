"""The rules.  Each module has RULE (its name), check(item, cfg, ctx) -> [Finding] ([] = the item passes) and, when part of it runs over many items at once (a Mini you model),
batch(deferred, ctx[, found]) -> [Finding] for the items its check() handed to ctx.defer()."""
