"""Reads the more second sources (feeds_more.py) for the lists, through the shared polite reader, and stores what they say as claims (same contract as feedrun.py; feedrun.FEEDS
includes these).  Every site's terms were read before it was listed here: docs/accuracy_sources.md has what each one allows, its rate limit and its credit.
A site whose terms forbid it or are unclear is NOT listed (swu-db.com, swuapi.com, Grand Archive's API: docs/accuracy_sources.md)."""
from .. import provenance
from ..sources import rules

DAY = 20 * 3600
SORCERY_REGISTRY = "https://raw.githubusercontent.com/sadkinglabs/sorcery-registry/main/export/registry.json"     # the registry's own GitHub mirror (its docs: "every release is mirrored on GitHub")
BATCH = 120                                     # (card numbers per digimoncard.io search: a short URL)

rules.add(rules.SiteRule("optcgapi", "OPTCG API", ("optcgapi.com", "www.optcgapi.com"), 2.0, "data",
                         "Free, no key, consumption only; asks for no 'insane amount' of calls: we read three list files a day (checked 2026-11-13).  Its data is the official card ids with "
                         "TCGplayer-style variant names, so only base name + number + set are taken.", "https://optcgapi.com/documentation"))
rules.add(rules.SiteRule("digimoncard", "DigimonCard.io", ("digimoncard.io", "www.digimoncard.io"), 1.0, "data",
                         "Public API: 15 requests per 10 s (a breach blocks an hour); build tools with it, do not mirror or resell the dataset, never hot-link images, credit DigimonCard.io where "
                         "practical.  robots.txt: Allow for '*', training crawlers by name refused (we are not one; checked 2026-11-13).", "https://digimoncard.io/api-documentation"))
rules.add(rules.SiteRule("fabcube", "The FaB Cube data set", ("raw.githubusercontent.com",), 2.0, "data",
                         "Open data set; its README invites anyone to use it for whatever project, and asks for contributions and credit (checked 2026-11-13).  We read card.json + set.json, "
                         "conditionally (the reader sends If-None-Match), at most once a day.  The same host also serves the Sorcery Card Registry's GitHub mirror (kairosarchive.net/usage: "
                         "bulk download of registry.json invited, cache it, credit Erik's Curiosa for the card data; one 6.8 MB file a day).", "https://github.com/the-fab-cube/flesh-and-blood-cards"))
rules.add(rules.SiteRule("riftcodex", "Riftcodex", ("api.riftcodex.com", "riftcodex.com"), 0.7, "data",
                         "Public, no key; 100 requests per minute per IP; unofficial fan project under Riot's fan content policy (checked 2026-11-13).", "https://riftcodex.com/faq"))
# (api.sorcerytcg.com is no longer read: its robots.txt question was settled by the registry mirror below; see docs/accuracy_sources.md)
for _code, _name, _url in (("optc", "OPTCG API", "https://optcgapi.com"),
                           ("digi", "DigimonCard.io", "https://digimoncard.io"),
                           ("fabc", "The FaB Cube", "https://github.com/the-fab-cube/flesh-and-blood-cards"),
                           ("rift", "Riftcodex", "https://riftcodex.com"),
                           ("sorc", "Sorcery Card Registry (Kairos Archive)", "https://kairosarchive.net"),):
    provenance.SOURCES.setdefault(_code, (_name, _url))


def _h():
    from . import feedrun
    return feedrun


def _json(fetcher, url, age=DAY):
    """-> (decoded json | None, note)"""
    got = fetcher.get(url, max_age=age)
    if got.status != 200 or not got.body:
        return None, f"{url.split('?')[0]}: HTTP {got.status}"
    try:
        return got.json(), ("from cache" if got.from_cache else "")
    except ValueError:
        return None, f"{url.split('?')[0]}: not JSON"


SET_JOIN = "LEFT JOIN sets s ON s.id = c.set_id"


def _ours(data_dir, game, cols, join=""):
    """The list's linked items: the columns asked (c = cards, s = sets when join=SET_JOIN) as text."""
    sql = f"SELECT {cols} FROM cards c {join} WHERE c.tcg_id IS NOT NULL AND c.tcg_id != ''"
    return [tuple("" if v is None else str(v) for v in r) for r in _h()._cards(_h()._db(data_dir, game), sql)]


def _done(game, rows, ours_ids, notes):
    n, matched = _h()._keep(game, rows, set(ours_ids))
    return {"game": game, "rows": n, "items": len(ours_ids), "matched": matched, "notes": [x for x in notes if x][:5]}


def _nothing(game, note):
    return {"game": game, "rows": 0, "items": 0, "matched": 0, "notes": [note]}


# ------------------------------------------------------------------------------------------------ the feeds
def onepiece(data_dir, fetcher):
    from . import feeds_more
    cards, notes = [], []
    for part in ("allSetCards", "allSTCards", "allPromos"):
        d, note = _json(fetcher, f"https://optcgapi.com/api/{part}/")
        if isinstance(d, list):
            cards += d
        elif note:
            notes.append(note)
    if not cards:
        return _nothing("onepiece", "OPTCG API not available: " + "; ".join(notes))
    ours = _ours(data_dir, "onepiece", "c.tcg_id, c.local_id, s.name", SET_JOIN)
    return _done("onepiece", feeds_more.onepiece_rows(cards, ours), [o[0] for o in ours], notes)


def digimon(data_dir, fetcher):
    from . import feeds_more
    from urllib.parse import quote
    allc, note = _json(fetcher, "https://digimoncard.io/api-public/getAllCards?series=Digimon%20Card%20Game")
    if not isinstance(allc, list):
        return _nothing("digimon", f"digimoncard.io getAllCards not available ({note})")
    ours = _ours(data_dir, "digimon", "c.tcg_id, c.local_id, s.name", SET_JOIN)
    want, packs, notes = feeds_more.digimon_wanted(allc, [o[1] for o in ours]), {}, []
    for i in range(0, len(want), BATCH):
        d, n = _json(fetcher, "https://digimoncard.io/api-public/search?limit=1000&card=" + quote(",".join(want[i:i + BATCH]), safe=","))
        if isinstance(d, list):
            for c in d:
                packs.setdefault(c.get("id"), list(c.get("set_name") or ()))
        elif n:
            notes.append(n)
    return _done("digimon", feeds_more.digimon_rows(allc, packs, ours), [o[0] for o in ours], notes)


def fab(data_dir, fetcher):
    from . import feeds_more
    base = "https://raw.githubusercontent.com/the-fab-cube/flesh-and-blood-cards/develop/json/english/"
    cards, n1 = _json(fetcher, base + "card.json")
    sets, n2 = _json(fetcher, base + "set.json")
    if not isinstance(cards, list) or not isinstance(sets, list):
        return _nothing("fab", f"the FaB Cube files not available ({n1}; {n2})")
    ours = _ours(data_dir, "fab", "c.tcg_id")
    return _done("fab", feeds_more.fab_rows(cards, sets), [o[0] for o in ours], [n1])


def riftbound(data_dir, fetcher):
    from . import feeds_more
    cards, notes, page = [], [], 1
    while page < 60:
        d, note = _json(fetcher, f"https://api.riftcodex.com/cards?size=100&page={page}")
        if not isinstance(d, dict) or not isinstance(d.get("items"), list):
            notes.append(note or f"page {page} not readable")
            break
        cards += d["items"]
        if page >= int(d.get("pages") or 1):
            break
        page += 1
    if not cards or notes:
        return _nothing("riftbound", "Riftcodex not fully read, nothing kept tonight: " + "; ".join(notes or ["no cards"]))      # (a half list would drop claims of the cards it never reached)
    ours = _ours(data_dir, "riftbound", "c.tcg_id")
    return _done("riftbound", feeds_more.riftbound_rows(cards), [o[0] for o in ours], [])


def sorcery(data_dir, fetcher):
    from . import feeds_more
    registry, note = _json(fetcher, SORCERY_REGISTRY)
    if not isinstance(registry, dict) or not isinstance(registry.get("cards"), list) or not isinstance(registry.get("printings"), list):
        return _nothing("sorcery", f"Sorcery Card Registry not available ({note})")
    ours = _ours(data_dir, "sorcery", "c.tcg_id, c.name, s.name", SET_JOIN)
    return _done("sorcery", feeds_more.sorcery_rows(feeds_more.registry_cards(registry), ours), [o[0] for o in ours], [note])


FEEDS = {"onepiece": onepiece, "digimon": digimon, "fab": fab, "riftbound": riftbound, "sorcery": sorcery}
