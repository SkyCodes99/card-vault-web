"""Who says what about an item.  A CLAIM is one source's statement of an item's name, number and set; sources are independent when they are different places
(TCGdex, TCGplayer, a wiki, a shop).  The row of a list is NOT a source of its own: it was copied from one (its origin), so the row and its origin's record count once.

Claims come from:
  * the records a row carries (its TCGdex record, its TCGplayer record: `raw`) - read here, no network;
  * the side store (store.py, table claims): what a second source said when a daily step read it anyway (feeds.py), keyed by the item's id or its TCGplayer product.
for_item() -> {source code: {name, number, set_id, set_name, url}} (only the fields that source states)."""
from .. import provenance
from . import store

ID, TCG = "id", "tcg"
_FIELDS = ("name", "number", "set_id", "set_name", "url")
LABELS = {"tdx": "TCGdex", "tcgp": "TCGplayer", "scry": "Scryfall", "mtgj": "MTGJSON", "ygop": "YGOPRODeck", "lorc": "Lorcast", "optc": "OPTCG API", "digi": "DigimonCard.io", "fabc": "The FaB Cube", "rift": "Riftcodex", "sorc": "Sorcery Card Registry", "fix": "your correction"}


def label(code):
    """'tdx' -> 'TCGdex', 'w:abominabletoys.com' -> 'abominabletoys.com', 'n:wiki' -> 'wiki'."""
    return LABELS.get(code) or (code.split(":", 1)[1] if code[:2] in ("w:", "n:", "i:") else code)


def record(game, rows, day=None, whole=False):
    """A daily step hands over what a source said: rows of {ref_kind ('id' | 'tcg'), ref, source, name?, number?, set_id?, set_name?, url?}.  The newest statement of a source replaces
    its older one.  whole=True: the rows are EVERYTHING those sources say about this list (a full pass), so their older statements about other items go.  -> rows written"""
    rows = [r for r in rows if r.get("ref") and r.get("source")]
    if not rows:
        return 0
    day = day or provenance.today()
    c = store.connect()
    try:
        if whole:
            c.executemany("DELETE FROM claims WHERE game=? AND source=?", [(game, s) for s in {r["source"] for r in rows}])
        c.executemany("INSERT OR REPLACE INTO claims(game, ref_kind, ref, source, name, number, set_id, set_name, url, day) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      [(game, r.get("ref_kind") or ID, str(r["ref"]), r["source"], *(None if r.get(k) in (None, "") else str(r[k]) for k in _FIELDS), day) for r in rows])
        c.commit()
    finally:
        c.close()
    return len(rows)


def side(game):
    """Every stored claim of one game -> {(ref_kind, ref): {source: {field: value}}}"""
    c = store.connect()
    try:
        out = {}
        for kind, ref, src, *vals in c.execute("SELECT ref_kind, ref, source, name, number, set_id, set_name, url FROM claims WHERE game=?", (game,)):
            out.setdefault((kind, ref), {})[src] = {k: v for k, v in zip(_FIELDS, vals) if v}
        return out
    finally:
        c.close()


def origin(item, prov_card=None):
    """The source a row was copied from: its provenance record, else what the row itself shows."""
    if prov_card:
        return prov_card
    raw = item["raw"]
    if raw.get("localId") is not None and isinstance(raw.get("set"), dict):
        return "tdx"
    if raw.get("productId") or item["id"].isdigit():
        return "tcgp"
    if str(raw.get("url") or "").startswith("http"):
        return "w:" + provenance.host_of(raw["url"])
    if isinstance(raw.get("source"), str) and raw["source"].strip():
        return "n:" + raw["source"].strip()[:80]
    return "list"                                         # (nothing says where it came from: the list itself is all there is)


def for_item(item, prov_card=None, side_claims=None):
    """Every source's statement about the item.  The origin states the row's own values unless the row carries the origin's record (then the record speaks: a row that drifted from
    its own source shows up as a difference)."""
    raw, out = item["raw"], {}
    org = origin(item, prov_card)
    if raw.get("localId") is not None and isinstance(raw.get("set"), dict):               # its TCGdex record
        out["tdx"] = {"name": raw.get("name"), "number": raw.get("localId"), "set_id": raw["set"].get("id"), "set_name": raw["set"].get("name")}
    if isinstance(raw.get("ext"), dict) and raw["ext"].get("Number") and (raw.get("productId") or item["tcg_id"]):       # its TCGplayer record (the number it prints)
        out["tcgp"] = {"number": raw["ext"]["Number"], "url": raw.get("url")}
    if org not in out:
        out[org] = {}
    for k in ("name", "number", "set_id", "set_name"):                                    # what the origin's record does not state, the row (its copy) does
        if not out[org].get(k) and item.get(k):
            out[org][k] = item[k]
    for key in ((ID, item["id"]), (TCG, item["tcg_id"])):
        if key[1]:
            for src, vals in ((side_claims or {}).get(key) or {}).items():
                merged = dict(out.get(src) or {})
                merged.update(vals)                                                       # (a fresh statement read from the source beats what the row kept of it)
                out[src] = merged
    return {s: {k: str(v) for k, v in vals.items() if v not in (None, "")} for s, vals in out.items()}
