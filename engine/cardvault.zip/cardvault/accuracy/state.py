"""What the last run saw of each item (store.py, table seen): its fingerprint and its price.  That is how a run knows which items are NEW or EDITED since yesterday (only those are
scored by the slow checks and asked about one by one) and what an item cost at the last run (the first thing a price jump is measured against).
A game's very first run has nothing to compare with: nothing counts as new (it is the baseline), so a first run never floods the review list."""
from . import store


def load(game):
    """-> {(table, id): (fingerprint, price)}; {} = this game was never checked"""
    c = store.connect()
    try:
        return {(t, i): (fp, pr) for t, i, fp, pr in c.execute("SELECT tbl, id, fp, price FROM seen WHERE game=?", (game,))}
    finally:
        c.close()


def save(game, rows, day):
    """Remember this run's items - rows of (table, id, fingerprint, price); the whole game is replaced: an item that left the list is forgotten."""
    c = store.connect()
    try:
        c.execute("DELETE FROM seen WHERE game=?", (game,))
        c.executemany("INSERT OR REPLACE INTO seen(game, tbl, id, fp, price, day) VALUES(?,?,?,?,?,?)", [(game, t, i, fp, pr, day) for t, i, fp, pr in rows])
        c.commit()
    finally:
        c.close()


def owner_no(game):
    """{(rule, table, id, key): why} of what the owner said 'no' to (an item that is not an official release, a picture that is not the item's, a price that is not right)."""
    c = store.connect()
    try:
        return {(r, t, i, k): w for r, t, i, k, w in c.execute("SELECT rule, tbl, id, key, why FROM owner_no WHERE game=?", (game,))}
    finally:
        c.close()


def say_no(game, table, item_id, rule, key, why, day):
    c = store.connect()
    try:
        c.execute("INSERT OR REPLACE INTO owner_no(game, tbl, id, rule, key, why, day) VALUES(?,?,?,?,?,?,?)", (game, table, str(item_id), rule, key or "", why, day))
        c.commit()
    finally:
        c.close()


def take_back(game, table, item_id, rule, key=""):
    """Forget a 'no' (the fix it led to was undone)."""
    c = store.connect()
    try:
        c.execute("DELETE FROM owner_no WHERE game=? AND tbl=? AND id=? AND rule=? AND key=?", (game, table, str(item_id), rule, key or ""))
        c.commit()
    finally:
        c.close()


def kept(game):
    """{(rule, table, id)} of the fixes that were undone: never made again by the check itself."""
    c = store.connect()
    try:
        return {(r, t, i) for r, t, i in c.execute("SELECT rule, tbl, id FROM kept WHERE game=?", (game,))}
    finally:
        c.close()


def keep(game, table, item_id, rule, day):
    c = store.connect()
    try:
        c.execute("INSERT OR REPLACE INTO kept(game, tbl, id, rule, day) VALUES(?,?,?,?,?)", (game, table, str(item_id), rule, day))
        c.commit()
    finally:
        c.close()
