"""The accuracy check's own small memory: ONE SQLite file, accuracy/accuracy.db next to the daily update log (never inside a card list, never in the collection).
  claims    what a second source says about an item (claims.py)
  seen      what the last run saw of each item: its fingerprint and price (state.py)
  owner_no  what the owner said 'no' to on the review list (review.py): not an official release / not its picture / not its price.  That answer is the proof for doing the same
            again when a daily rebuild brings the item, picture or price back
  kept      fixes that were undone (tools/accuracy_check.py --undo): the check never makes that fix again by itself"""
import os
import sqlite3

from .. import dailylog

_SCHEMA = """
CREATE TABLE IF NOT EXISTS claims(game TEXT NOT NULL, ref_kind TEXT NOT NULL, ref TEXT NOT NULL, source TEXT NOT NULL, name TEXT, number TEXT, set_id TEXT, set_name TEXT, url TEXT, day TEXT,
    PRIMARY KEY(game, ref_kind, ref, source)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS seen(game TEXT NOT NULL, tbl TEXT NOT NULL, id TEXT NOT NULL, fp TEXT, price REAL, day TEXT, PRIMARY KEY(game, tbl, id)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS owner_no(game TEXT NOT NULL, tbl TEXT NOT NULL, id TEXT NOT NULL, rule TEXT NOT NULL, key TEXT NOT NULL, why TEXT, day TEXT,
    PRIMARY KEY(game, tbl, id, rule, key)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS kept(game TEXT NOT NULL, tbl TEXT NOT NULL, id TEXT NOT NULL, rule TEXT NOT NULL, day TEXT, PRIMARY KEY(game, tbl, id, rule)) WITHOUT ROWID;
"""


def folder():
    return os.path.join(dailylog.log_dir(), "accuracy")


def path():
    return os.path.join(folder(), "accuracy.db")


def connect():
    os.makedirs(folder(), exist_ok=True)
    c = sqlite3.connect(path(), timeout=60)
    c.executescript(_SCHEMA)
    return c
