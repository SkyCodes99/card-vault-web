"""Reads one game's list (games/<game>/cards.db) READ-ONLY and hands out its cards and sealed products as plain items, whatever columns that list happens to have.
An item: {game, table, id, name, number, set_id, set_name, image, tcg_id, raw (dict), price, price_kind, price_updated, name_en, name_ja}."""
import hashlib
import json
import sqlite3

CARDS, SEALED = "cards", "sealed_products"
# item key -> column, per table (what a fix writes back: fixlog.py)
COLUMNS = {CARDS: {"id": "id", "name": "name", "number": "local_id", "set_id": "set_id", "image": "image_base", "tcg_id": "tcg_id", "raw": "raw",
                   "price": "price_usd", "price_kind": "price_kind", "price_updated": "price_updated", "name_en": "name_en", "name_ja": "name_ja"},
           SEALED: {"id": "id", "name": "name", "set_id": "set_id", "set_name": "set_name", "image": "image_base", "price": "price_usd", "price_kind": "price_kind",
                    "price_updated": "price_updated"}}


def open_ro(db):
    return sqlite3.connect("file:" + db.replace("\\", "/") + "?mode=ro", uri=True, timeout=60)


def tables(conn):
    return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def cols(conn, table):
    return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]


def _raw(text):
    if not text:
        return {}
    try:
        r = json.loads(text)
    except ValueError:
        return {}
    return r if isinstance(r, dict) else {}


def read(conn, game, table, ids=None):
    """Yield every item of one table (nothing when the list has no such table); ids: only those items."""
    if table not in tables(conn):
        return
    have = set(cols(conn, table))
    keys = [(k, c) for k, c in COLUMNS[table].items() if c in have]
    if not any(k == "id" for k, _ in keys):
        return
    sql, args = f"SELECT {', '.join(c for _, c in keys)} FROM {table}", []
    if ids is not None:
        args = [str(i) for i in ids][:900]
        sql += f" WHERE {COLUMNS[table]['id']} IN ({','.join('?' * len(args)) or 'NULL'})"
    for row in conn.execute(sql, args):
        it = {"game": game, "table": table, "number": "", "set_id": "", "set_name": "", "image": "", "tcg_id": "", "raw": {}, "price": None, "price_kind": None, "price_updated": "", "name_en": "", "name_ja": ""}
        it.update({k: v for (k, _), v in zip(keys, row)})
        it["id"] = str(it["id"])
        it["raw"] = _raw(it["raw"]) if isinstance(it["raw"], str) else {}
        for k in ("name", "number", "set_id", "set_name", "image", "tcg_id", "price_updated", "name_en", "name_ja"):
            it[k] = "" if it[k] is None else str(it[k])
        if table == SEALED and not it["tcg_id"] and it["id"].isdigit():
            it["tcg_id"] = it["id"]                          # (a sealed product's id is its TCGplayer product)
        yield it


def fingerprint(it):
    """Changes when a fact or the picture of the item changes (not its price): how the next run knows the item is new or was edited."""
    return hashlib.sha1("\x1f".join((it["name"], it["number"], it["set_id"], it["image"])).encode("utf-8")).hexdigest()[:16]
