"""A RULE PACK is the list of rules one kind of item gets (trading cards, sealed, Funko, designer toys, plush, consoles, diecast ...) with that kind's limits; the packs themselves
are data (cardvault/data/accuracy_settings.json, read by settings.py).  This module only turns a pack's rule names into the rule modules, so a typo in the data file fails loudly."""
from .rules import official, picture, prices, sources

RULES = {m.RULE: m for m in (sources, picture, prices, official)}


def rules_of(cfg):
    """The rule modules of a pack, in the order the pack names them."""
    unknown = [r for r in cfg.get("rules", ()) if r not in RULES]
    if unknown:
        raise ValueError(f"accuracy_settings.json names unknown rule(s) {unknown} for the '{cfg.get('kind')}' pack")
    return [RULES[r] for r in cfg.get("rules", ())]
