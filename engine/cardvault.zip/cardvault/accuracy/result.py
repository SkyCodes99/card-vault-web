"""What a rule returns for one item: nothing (it passes), or findings.  A finding is FIXABLE (a change + the proof for it) or REVIEW (a reason, for the owner).
fixable() refuses a change that has no proof: the rule 'never fix without proof' is enforced here, not left to each rule."""
from dataclasses import asdict, dataclass, field

from . import FIXABLE, REVIEW

SET, REMOVE = "set", "remove"            # what a fix does: write columns of the item's row / take the whole row out of the list


@dataclass
class Finding:
    rule: str                            # sources | picture | prices | official
    code: str                            # which case of the rule (single, differs, corrected, zero, spike ...): what the report counts
    status: str                          # fixable | review
    game: str
    table: str                           # cards | sealed_products
    item_id: str
    name: str = ""
    reason: str = ""                     # one plain sentence: what is wrong / what the owner is asked
    before: dict = field(default_factory=dict)       # {column: value now}        (for a remove: the whole row)
    after: dict = field(default_factory=dict)        # {column: proven / proposed value}
    sources: list = field(default_factory=list)      # who states `after` (the proof of a fix; the evidence of a review)
    action: str = SET
    listable: bool = True                # False: counted in the report only, never put on the review list (a score-only model's doubt, a single-source fact of an old item)
    key: str = ""                        # what makes the question a new one (a price: the price asked about); '' = one question per item and case

    def as_dict(self):
        return asdict(self)


def fixable(rule, code, item, reason, before, after, sources, action=SET, need=1):
    """A change the rule can PROVE.  `sources` is the proof (need: how many there must be); a fix with no proof, or one that changes nothing, is a bug in the rule."""
    sources = [s for s in (sources or []) if s]
    if len(sources) < need:
        raise ValueError(f"{rule}/{code}: a fix needs {need} source(s) as proof, got {len(sources)}")
    if action == SET and (not after or before == after):
        raise ValueError(f"{rule}/{code}: a fix must change something")
    return Finding(rule, code, FIXABLE, item["game"], item["table"], item["id"], item.get("name") or "", reason, dict(before or {}), dict(after or {}), sources, action)


def review(rule, code, item, reason, before=None, after=None, sources=(), listable=True, key=""):
    """Not provable: the owner decides.  `after` may carry a proposal (what one source says)."""
    if not (reason or "").strip():
        raise ValueError(f"{rule}/{code}: a review item needs a reason")
    return Finding(rule, code, REVIEW, item["game"], item["table"], item["id"], item.get("name") or "", reason, dict(before or {}), dict(after or {}), [s for s in sources if s],
                   listable=listable, key=str(key or ""))
