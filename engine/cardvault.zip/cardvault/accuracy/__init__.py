"""THE DAILY ACCURACY CHECK (roadmap: "Daily accuracy checker"; one engine + rule packs, not 60 programs).  Runs after each daily update (tools/accuracy_check.py) over every list:

  sources   two or more independent sources must agree on an item's name, number and set          (rules/sources.py)
  picture   the picture must be the item's own                                                     (rules/picture.py: the owner's picture rule in gates.py + Mini you's photo matcher)
  prices    a price must make sense: not $0, not absurd, not another currency, no wild jump         (rules/prices.py)
  official  no customs, bundles or lots in a list                                                   (rules/official.py: toyrules + word rules + Mini you's real-release score)

Each rule answers per item: pass (nothing is returned), FIXABLE (a change with its PROOF: the sources that state it) or REVIEW (a reason; it goes to the owner's ONE review list,
cardvault/reviewlist.py).  Nothing is fixed without proof; by default nothing is fixed at all (check + log + review only; --fix turns the proven fixes on).  Every fix is written to
the fix log with before, after, sources and rule, and can be taken back from that log (fixlog.py).

Modules: result (what a rule returns), settings (the rule packs per kind of item and the per-game settings: cardvault/data/accuracy_settings.json), items (reads one list, read-only),
claims (who says what about an item), state (what the last run saw: what is new, yesterday's price), packs (kind -> its rules), engine (one game, all rules), fixlog, review, report."""

PASS, FIXABLE, REVIEW = "pass", "fixable", "review"
RULES = ("sources", "picture", "prices", "official")
MIN_SOURCES = 2                  # a fact is proven when at least this many independent sources state it
