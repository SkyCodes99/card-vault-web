"""Second sources from Fandom wikis (same contract as feeds.py / feeds_more.py: pure functions, what a wiki's pages said -> claim rows; the reading is feedrun_fandom.py).

Each extractor gets [(page title, wikitext)] and returns entries {numbers, name, sets} - only what the page's own card table states:
  weiss_entries     Weiss Schwarz Wiki: {{CardTableEnglish}} - EngCardNo (and the gallery's other printings), EngName
  slash_entries     Cardfight!! Vanguard Wiki / Future Card Buddyfight Wiki: the card numbers in the set1 / set2 ... fields (CODE/NUMBER); the English page title is the name
  wixoss_entries    WIXOSS Wiki: {{Cardtable}} setnumN (+ setN, the set's name); the page title is the name
  union_entries     Union Arena TCG Wiki: {{CardTable}} name + set1 (UA01BT/CGH-1-083)
  metazoo_entries   MetaZoo Wiki: {{Beastie_Page}} pagename + setnumber + set
fandom_rows(entries, ours, keyfn, source) matches the entries to our items by the card number (keyfn makes both sides' numbers comparable) and states name, number and (where the wiki's set
name matches ours) set.  A number two pages name differently states nothing.  Wording and pictures are never taken (CC BY-SA: facts only)."""
import re

from . import claims, fandom
from .feeds import claims_key

SLASH_CODE = re.compile(r"[A-Za-z][A-Za-z0-9-]*/[A-Za-z]*\d+[A-Za-z]{0,3}")
WEISS_NO = re.compile(r"EngCardNo\s*=\s*([^\s|}]+)")


def source_code(host):
    return f"n:{host}.fandom.com"


# ------------------------------------------------------------------------------------------------ the number each side writes
def number_key(number):
    """'KGL/S79-E056 U' / 'AZL/S119-E039RR' -> ('KGL/S79-E', 56) / ('AZL/S119-E', 39); 'DZ-BT02/SR14EN' -> ('DZ-BT02/SR', 14); 'WXDi-P06-008R[EN]' -> ('WXDI-P06-', 8).
    Only the first word counts; a [EN] tail, the zero padding and the letters the number ends in (rarity, a language) are each site's own."""
    s = re.sub(r"\[[^\]]*\]", "", str(number or "").strip().split()[0] if str(number or "").strip() else "")
    m = re.match(r"^(.*?)0*(\d+)[A-Za-z]*$", s)
    return (m.group(1).upper(), int(m.group(2))) if m and m.group(1) is not None else None


def english_key(number):
    """Vanguard / Buddyfight: the English printing has its OWN numbering in many sets ('BT16/033EN' is Locus Liberator, the Japanese 'BT16/033' is Metalborg), so a code ending in EN only
    ever meets a wiki code ending in EN -> ('BT16/', 33, 'EN').  A code without it is the Japanese one ('')."""
    s = str(number or "").strip().split()[0] if str(number or "").strip() else ""
    m = re.match(r"^(.*?)0*(\d+)([A-Za-z]*)$", s)
    if not m:
        return None
    return (m.group(1).upper(), int(m.group(2)), "EN" if m.group(3).upper() == "EN" else "")


def after_slash_key(number):
    """Union Arena: 'UE24BT/REZ-1-052' and the wiki's 'UA01BT/CGH-1-083' print the set differently; the franchise / volume / number after the slash is the card ('CGH-1-', 83)."""
    return number_key(str(number or "").split("/", 1)[-1])


def metazoo_key(number):
    """'003/165' / '3/165' / '50' -> (3, 165) / (3, 165) / (50,)"""
    parts = re.findall(r"\d+", str(number or ""))
    return tuple(int(p) for p in parts[:2]) or None


def words_close(a, b, ratio=0.85):
    """WIXOSS Wiki's page titles are often its own translation of a Japanese name ('Yuzuki Two, Flaming Swimmer' for the release's 'Yuzuki Soaker, Surflame'), so a title is stated as a name
    only when it is the same name or a typo-sized difference from it (letters alike by at least 85 %: 'Eldora X Mark v' / 'Eldora x Mark nu', 'Baron Samedi' / 'Baron Samadi'); two translations of
    one card are not a difference worth asking the owner about."""
    import difflib

    def fold(s):
        return "".join(re.findall(r"[^\W_]+", re.sub(r"\s*[\(\[（【].*?[\)\]）】]", "", str(s or "")).lower()))
    fa, fb = fold(a), fold(b)
    return bool(fa and fb) and difflib.SequenceMatcher(None, fa, fb).ratio() >= ratio


def _set_match(a, b):
    from .rules.sources import _same_setname
    return bool(a and b and _same_setname(a, b))


# ------------------------------------------------------------------------------------------------ extractors
def _codes(numbers):
    """The set codes in front of the slash ('DZ-BT12/EX04' -> 'DZ-BT12'): the wiki says the card is printed in that set, and our set's name ('DZ-BT12: Dynamic ...') carries the same code."""
    return list(dict.fromkeys(n.split("/")[0] for n in numbers if "/" in n))


def weiss_entries(pages):
    out = []
    for title, text in pages:
        p = fandom.template_params(text, ("CardTableEnglish",))
        name = fandom.plain(p.get("engname"))
        numbers = list(dict.fromkeys(WEISS_NO.findall(text)))
        if name and numbers:
            out.append({"numbers": numbers, "name": name, "sets": []})
    return out


def slash_entries(pages):
    """A card page's set fields hold its printings ('DZ-SS05/028EN (C) 2024<br>DZ-SS04/028 (C)'); only a page with a code of the form CODE/NUMBER states a number."""
    out = []
    for title, text in pages:
        fields = re.findall(r"(?m)^\s*\|\s*set\d*\s*=\s*(.*)$", text)
        numbers = list(dict.fromkeys(c for f in fields for c in SLASH_CODE.findall(fandom.plain(f.replace("<br>", " ")))))
        name = fandom.plain(title)
        if name and numbers:
            out.append({"numbers": numbers, "name": name, "sets": _codes(numbers)})
    return out


def wixoss_entries(pages):
    out = []
    for title, text in pages:
        p = fandom.template_params(text, ("Cardtable",))
        numbers = [fandom.plain(v) for k, v in p.items() if re.fullmatch(r"setnum\d*", k) and fandom.plain(v)]
        sets = [fandom.plain(v) for k, v in p.items() if re.fullmatch(r"set\d*", k) and fandom.plain(v)]
        name = fandom.plain(title)
        if name and numbers:
            out.append({"numbers": list(dict.fromkeys(numbers)), "name": name, "sets": sets})
    return out


def union_entries(pages):
    out = []
    for title, text in pages:
        p = fandom.template_params(text, ("CardTable",))
        numbers = [m.group(0) for f in (v for k, v in p.items() if re.fullmatch(r"set\d*", k)) for m in re.finditer(r"[A-Za-z0-9]+/[A-Za-z0-9]+-\d+-\d+", fandom.plain(f))]
        name = fandom.plain(p.get("name"))
        if name and numbers:
            out.append({"numbers": list(dict.fromkeys(numbers)), "name": name, "sets": _codes(numbers)})
    return out


def metazoo_entries(pages):
    out = []
    for title, text in pages:
        p = fandom.template_params(text, ("Beastie_Page", "Beastie Page"))
        number, name, set_name = fandom.plain(p.get("setnumber")), fandom.plain(p.get("pagename")), fandom.plain(p.get("set"))
        if name and number and set_name:
            out.append({"numbers": [number], "name": name, "sets": [set_name]})
    return out


# ------------------------------------------------------------------------------------------------ claims
def fandom_rows(entries, ours, keyfn, source, set_must_match=False, state_number=True, close_names=False):
    """entries: from an extractor; ours: [(tcg_id, number, set name)].  Found by the card number.  Two pages with one number but different names state nothing (a reprint under another
    name stays unasked); with set_must_match (MetaZoo: a number repeats in every set) only the entry whose set name matches ours counts.
    state_number=False (Union Arena): the wiki writes the Japanese set code in front of the number (UA03BT/HTR-1-070 for our UE02ST/HTR-1-070), so it finds the card by franchise + number but
    states only its name.  The number is written the way OUR list writes it: the wiki and the list both name the same card number (the match key), only a rarity letter, a [EN] tail or the zero padding
    differ, and the check compares numbers letter for letter.  close_names (WIXOSS): see words_close.  An ours tuple may carry the item's name as a 4th value."""
    by = {}
    for e in entries or ():
        for n in e["numbers"]:
            k = keyfn(n)
            if k:
                by.setdefault(k, []).append((n, e))
    for o in ours:
        tid, number, set_name = o[0], o[1], o[2]
        k = keyfn(number)
        got = by.get(k) if k else None
        if not got:
            continue
        if set_must_match:
            got = [(n, e) for n, e in got if any(_set_match(s, set_name) for s in e["sets"])]
            if not got:
                continue
        if len({claims_key(e["name"]) for _n, e in got}) != 1:
            continue
        n, e = got[0]
        if close_names and len(o) > 3 and not words_close(e["name"], o[3]):
            continue
        same_set = next((s for _n, e2 in got for s in e2["sets"] if _set_match(s, set_name)), None)
        row = {"ref_kind": claims.TCG, "ref": tid, "source": source, "name": e["name"], "number": number if state_number else None, "set_name": same_set}
        yield {k: v for k, v in row.items() if v not in (None, "")}
