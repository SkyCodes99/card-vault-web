"""More second sources (same contract as feeds.py: pure functions, what a source said -> claim rows; the reading is feedrun_more.py).

onepiece_rows(cards, ours)       One Piece: optcgapi.com's card lists (OP / EB / PRB sets, starter decks, promos).  States name (without the variant tail), number, set name.
digimon_rows(all_cards, packs, ours)   Digimon: digimoncard.io - getAllCards (name + number) and the pack names of a search by card number.
fab_rows(cards, sets)            Flesh and Blood: the-fab-cube's card.json + set.json; each printing names its TCGplayer product, so it is keyed by that product.
riftbound_rows(cards)            Riftbound: Riftcodex cards (they carry the TCGplayer id).
sorcery_rows(cards, ours)        Sorcery: the maker's own public card list (api.sorcerytcg.com), found by name + set.
Each states only what the source itself states; a field it cannot match to our item's own is left out (a set NAME a source writes differently is no disagreement: sources.py)."""
import re

from . import claims
from .feeds import claims_key

OPTC, DIGI, FABC, RIFT, SORC = "optc", "digi", "fabc", "rift", "sorc"
_TAIL = re.compile(r"\s*[(\[][^()\[\]]*[)\]]")


def _base(name):
    """'Perona (Parallel)' / 'Roronoa Zoro - OP14-015 (Alternate Art)' / 'Shanks (020)' -> 'Perona' / 'Roronoa Zoro' / 'Shanks'"""
    return re.sub(r"\s+-\s+[A-Z]{1,4}\d*-\d+\s*$", "", _TAIL.sub("", name or "")).strip()


def _set_match(a, b):
    from .rules.sources import _same_setname
    return bool(a and b and _same_setname(a, b))


def _row(game_ref, source, **kw):
    return dict({"ref_kind": claims.TCG, "ref": game_ref, "source": source}, **{k: v for k, v in kw.items() if v not in (None, "")})


# ------------------------------------------------------------------------------------------------ One Piece: optcgapi.com
def onepiece_rows(cards, ours):
    """cards: optcgapi card objects; ours: [(tcg_id, number, set name)].  Found by the card number (OP01-077); the source's variant names ('Perona (Box Topper)') are TCGplayer's own
    wording, so only the name without the tail is stated, and only when every entry of that number says the same one."""
    by = {}
    for c in cards or ():
        if c.get("card_set_id") and c.get("card_name"):
            by.setdefault(c["card_set_id"].strip().upper(), []).append(c)
    for tid, number, set_name in ours:
        got = by.get((number or "").strip().upper())
        if not got:
            continue
        names = {claims_key(_base(c["card_name"])) for c in got}
        if len(names) != 1:
            continue
        same_set = [c for c in got if _set_match(c.get("set_name"), set_name)]
        yield _row(tid, OPTC, name=_base(got[0]["card_name"]), number=number, set_name=(same_set[0]["set_name"] if same_set else None))


# ------------------------------------------------------------------------------------------------ Digimon: digimoncard.io
def digimon_key(number):
    """'BT26-052 C' / 'BT23-047SR' / 'P - 214 P' / 'ST23-09' -> ('BT26', 52) / ('BT23', 47) / ('P', 214) / ('ST23', 9): the rarity and the zero padding are each site's own."""
    m = re.match(r"^([A-Za-z]+\d*)-0*(\d+)", re.sub(r"\s+", "", number or ""))
    return (m.group(1).upper(), int(m.group(2))) if m else None


def digimon_wanted(all_cards, ours_numbers):
    """The numbers (as digimoncard.io writes them) of its cards that our list also has -> sorted list, to ask the search for their packs."""
    ours = {digimon_key(n) for n in ours_numbers} - {None}
    return sorted({c["cardnumber"] for c in all_cards or () if c.get("cardnumber") and digimon_key(c["cardnumber"]) in ours})


def digimon_rows(all_cards, packs, ours):
    """all_cards: getAllCards [{name, cardnumber}]; packs: {cardnumber: [pack names]} from the search; ours: [(tcg_id, number, set name)]."""
    by = {}
    for c in all_cards or ():
        k = digimon_key(c.get("cardnumber"))
        if k and c.get("name"):
            by.setdefault(k, []).append(c)
    for tid, number, set_name in ours:
        got = by.get(digimon_key(number))
        if not got or len({claims_key(c["name"]) for c in got}) != 1:
            continue
        pack = next((p for c in got for p in packs.get(c["cardnumber"], ()) if _set_match(p, set_name)), None)
        yield _row(tid, DIGI, name=got[0]["name"], number=number, set_name=pack)


# ------------------------------------------------------------------------------------------------ Flesh and Blood: the-fab-cube
def fab_rows(cards, sets):
    """Every printing of the data set names its TCGplayer product.  A product that holds two cards (a double-faced / split card) states both names; one that holds several numbers states
    none (a number is stated only when the product has exactly one)."""
    names = {s.get("id"): s.get("name") for s in sets or ()}
    got = {}
    for c in cards or ():
        for p in c.get("printings") or ():
            if p.get("tcgplayer_product_id"):
                e = got.setdefault(str(p["tcgplayer_product_id"]), {"name": [], "id": set(), "set": set()})
                if c.get("name") and c["name"] not in e["name"]:
                    e["name"].append(c["name"])
                e["id"].add(p.get("id"))
                e["set"].add(names.get(p.get("set_id")))
    for tid, e in got.items():
        yield _row(tid, FABC, name=" // ".join(e["name"]), number=next(iter(e["id"])) if len(e["id"]) == 1 else None, set_name=next(iter(e["set"])) if len(e["set"]) == 1 else None)


# ------------------------------------------------------------------------------------------------ Riftbound: Riftcodex
def riftbound_number(riftbound_id):
    """'ogn-179-298' -> '179/298', 'unl-229*-219' -> '229*/219' (the way the cards print it; TCGplayer writes the same)"""
    m = re.match(r"^[a-z0-9]+-(.+)-(\d+)$", riftbound_id or "")
    return f"{m.group(1)}/{m.group(2)}" if m else None


def riftbound_rows(cards):
    for c in cards or ():
        if c.get("tcgplayer_id"):
            yield _row(c["tcgplayer_id"], RIFT, name=c.get("name"), number=riftbound_number(c.get("riftbound_id")), set_name=(c.get("set") or {}).get("label"))


# ------------------------------------------------------------------------------------------------ Sorcery: the maker's own list
def sorcery_rows(cards, ours):
    """cards: api.sorcerytcg.com /api/cards (a card, its printings with their set); ours: [(tcg_id, name, set name)].  Our names carry a finish or product tail ('(Foil)', '(Box Topper)')
    and the list has no numbers: the source states the name and the set of the printing it finds by name + set."""
    by = {}
    for c in cards or ():
        for p in c.get("printings") or ():
            s = (p.get("set") or {}).get("name")
            if s and c.get("name"):
                by.setdefault(claims_key(c["name"]), []).append((c["name"], s))
    for tid, name, set_name in ours:
        got = [(n, s) for n, s in by.get(claims_key(_base(name)), ()) if _set_match(s, set_name)]
        if got:
            yield _row(tid, SORC, name=got[0][0], set_name=got[0][1])


def registry_cards(registry):
    """The Sorcery Card Registry (Kairos Archive, registry.json: cards + printings) in the shape sorcery_rows reads: [{name, printings: [{set: {name}}]}]."""
    sets = {}
    for p in (registry or {}).get("printings") or ():
        if p.get("codex_id") and p.get("set_name"):
            sets.setdefault(p["codex_id"], set()).add(p["set_name"])
    return [{"name": c["name"], "printings": [{"set": {"name": s}} for s in sorted(sets.get(c.get("codex_id"), ()))]}
            for c in (registry or {}).get("cards") or () if c.get("name")]
