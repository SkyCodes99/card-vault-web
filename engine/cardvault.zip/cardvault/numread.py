"""Read the printed set code + collector number ("sv4a 337/190", "012/073") from the bottom-left of a straightened card picture, OFFLINE, and say which cards in a candidate list it agrees with.

The browser scanner (ui/src/scanweb/numread.js) does the same steps with the same model file (ui/public/numread/numread.onnx, ~0.4 MB, lazy-loaded); this module is the reference
implementation the tools use (tools/numread_train.py trains the model, tools/scan_number_eval.py measures it) - keep the two in step: same band, same input scaling, same decoding, same rules.

The model is a small convolutional reader (CTC): it sees the bottom-left band of the card (BAND, as fractions of the straightened card) at W x H grey pixels and writes the characters it
finds ("0-9", "/", "a-z", space).  Cards print the number there: modern Japanese cards "[set box] 337/190 SSR", modern English cards "231/264".  Older cards print it bottom-right: not read (the
answer is then simply 'nothing read', which changes nothing).  The reading is never taken as the answer: it only (1) agrees with a candidate the picture already found, which lifts it, or
(2) disagrees with every candidate, which makes the scanner ask - see `judge`."""
import re

W, H = 320, 96
BAND = (0.0, 0.52, 0.90, 1.02)                           # x0, x1, y0, y1 of the straightened card
ALPHABET = " 0123456789/abcdefghijklmnopqrstuvwxyz"     # CTC class i+1 = ALPHABET[i]; class 0 = blank


def band(img):
    """PIL RGB card picture (straightened, upright) -> float32 (1, H, W) in 0..1, grey."""
    import numpy as np
    from PIL import Image
    w, h = img.size
    box = (int(BAND[0] * w), int(BAND[2] * h), int(BAND[1] * w), int(BAND[3] * h))
    g = np.asarray(img.convert("L"), np.float32)
    if box[3] > h:                                                                       # the band reaches past the card's bottom edge: that row repeats (as the page's sampler does)
        g = np.pad(g, ((0, box[3] - h), (0, 0)), mode="edge")
    g = Image.fromarray(g[box[1]:box[3], box[0]:box[2]]).resize((W, H), Image.BILINEAR if (box[2] - box[0]) < 2 * W else Image.BOX)
    return (np.asarray(g, np.float32) / 255.0)[None]


def decode(logits):
    """logits (T, C) -> (text, per-character confidences) by greedy CTC."""
    import numpy as np
    e = np.exp(logits - logits.max(1, keepdims=True))
    p = e / e.sum(1, keepdims=True)
    ids, prob = p.argmax(1), p.max(1)
    out, conf, prev = [], [], 0
    for t, i in enumerate(ids):
        if i != prev and i != 0:
            out.append(ALPHABET[i - 1])
            conf.append(float(prob[t]))
        prev = i
    return "".join(out), conf


_NUM = re.compile(r"(\d{1,3})\s*/\s*(\d{2,3})")


def parse(text, conf=None):
    """'sv4a 337/190' -> {code:'sv4a', n:337, d:190, conf}.  None when there is no 'number/size' in the text.  conf = the weakest character of the number part (0..1)."""
    m = _NUM.search(text or "")
    if not m:
        return None
    code = re.sub(r"[^a-z0-9]", "", text[:m.start()].lower())
    c = min(conf[m.start():m.end()]) if conf and len(conf) == len(text) else 1.0
    return {"code": code, "n": int(m.group(1)), "d": int(m.group(2)), "conf": c}


class Reader:
    """The model on onnxruntime (the tools and tests; the page runs the same file with onnxruntime-web)."""

    def __init__(self, path):
        import onnxruntime as ort
        self.sess = ort.InferenceSession(path, providers=["CPUExecutionProvider"])

    def read(self, img):
        """PIL RGB straightened card -> parse() of what is printed at its bottom-left, or None."""
        lg = self.sess.run(None, {"band": band(img)[None]})[0][0]
        text, conf = decode(lg)
        return parse(text, conf)


def _near(a, b):
    """one character apart (a substitution, a drop or an extra one): the box is read small, '0' and '9' look alike"""
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    s, l = sorted((a, b), key=len)
    return any(l[:i] + l[i + 1:] == s for i in range(len(l)))


def code_fit(code, set_id):
    """2 = the same, 1 = one character apart, 0 = different (or one is missing)"""
    s = re.sub(r"[^a-z0-9]", "", str(set_id or "").lower())
    if not code or not s:
        return 0
    return 2 if code == s else 1 if len(code) >= 2 and _near(code, s) else 0


def agrees(read, cand):
    """How a reading fits one candidate card {local_id, official (printed set size), set_id, lang}: 3 = number and size agree, and the set code too (or there is none to compare), 2 = the same but
    the set code is one character off, 1 = the number agrees and the size is not known, 0 = no information, -1 = disagrees (a different number, size or set code)."""
    lid = str(cand.get("local_id") or "")
    if not re.fullmatch(r"\d+", lid):
        return 0                                                                        # letters in the number (promos, 'TG01'): not comparable
    if read["n"] != int(lid):
        return -1
    d = cand.get("official")
    if not d:
        return 1
    if read["d"] != int(d):
        return -1
    if read["code"] and cand.get("set_id") and cand.get("lang") == "ja":
        fit = code_fit(read["code"], cand["set_id"])
        return 3 if fit == 2 else 2 if fit == 1 else -1
    return 3


# ---- how the reading is used on a scan's answer.  matches = [{game, id, sim}] best first (the scanner's top 5 over the searched lists), info(match) -> {local_id, official, set_id, lang}
AGREE_MIN = 0.5   # a reading that AGREES with a candidate counts when its weakest character is at least this sure (0..1): the picture, the number, the size and the code must all fit anyway
FOUND_MIN = 0.5   # a card found by the number alone (its own picture must be close too)
ASK_MIN = 0.9     # a reading that DISAGREES with every candidate makes the scanner ask only when it is this sure of it
PROMOTE_MARGIN = 0.06    # a candidate the number agrees with comes first when its picture similarity is within this of the best one
AGREE_CONF = 0.97        # ... and the answer is then this sure (the scanner's own cap for a card)
SIM_FLOOR = 0.75         # but never for a picture that does not look like it at all
ASK_CONF = 0.5           # a confident reading that agrees with NO candidate: the answer is asked, never guessed


EXTRA_FLOOR = 0.80       # a card found by its printed number alone (not among the picture's matches) must still look this much like the photo ...
EXTRA_MARGIN = 0.10      # ... and be within this of the best picture match


def judge(read, matches, conf, info, ask_cap=ASK_CONF, extra=()):
    """-> (matches, conf, verdict).  verdict: 'none' (nothing read / not usable), 'agree' (the first answer's number agrees), 'promoted' (another candidate's number agrees: it is now first),
    'found' (no candidate fits but `extra` - cards the printed code + number + size name, each {game, id, sim} - has one whose picture is close: it comes first),
    'asked' (the reading disagrees with every candidate: the person is asked), 'unclear' (some candidates cannot be compared)."""
    if not read or read["conf"] < AGREE_MIN or not matches:
        return matches, conf, "none"
    ag = [agrees(read, info(m)) for m in matches]
    ok = [i for i, a in enumerate(ag) if a >= 2 and matches[i]["sim"] >= SIM_FLOOR and matches[i]["sim"] >= matches[0]["sim"] - PROMOTE_MARGIN]
    best = max(ok, key=lambda i: (ag[i], -i), default=None)                              # the exact set code wins over a near one, then the closer picture
    if best == 0:
        return matches, max(conf, AGREE_CONF), "agree"
    if best is not None:
        return [matches[best]] + matches[:best] + matches[best + 1:], max(conf, AGREE_CONF), "promoted"
    found = max((e for e in extra if read["conf"] >= FOUND_MIN and e["sim"] >= EXTRA_FLOOR and e["sim"] >= matches[0]["sim"] - EXTRA_MARGIN), key=lambda e: e["sim"], default=None)
    if found:                                                                            # the card the printed set code + number + size name, and its picture is close: it comes first
        return [found] + [m for m in matches if (m["game"], m["id"]) != (found["game"], found["id"])], max(conf, AGREE_CONF), "found"
    if read["conf"] >= ASK_MIN and all(a == -1 for a in ag[:3]):
        return matches, min(conf, ask_cap), "asked"
    return matches, conf, "unclear"
