"""A binder as one standalone web page: page flipping, pocket layouts, and a view switch (everything / only what is owned / only what is missing).
Colour = owned, grey = on the list but not owned yet, blank = no card exists for that spot.  The page carries only what the owner chose to show (never prices, copies, notes);
pictures are links to the public card pictures, so the file stays small."""
import html
import json

SCHEMA = 1

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>
:root{--bg:#f1f4f9;--surface:#fff;--s2:#e4eaf4;--ink:#182033;--mute:#657087;--line:#d3dbe9;--accent:#2a78d6;--ok:#1baf7a}
@media(prefers-color-scheme:dark){:root{--bg:#0e1220;--surface:#161c2e;--s2:#1e2640;--ink:#e9edf7;--mute:#9aa5bd;--line:#2a3351;--accent:#4d93ec}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px system-ui,Segoe UI,sans-serif;padding:14px 16px 28px}
.wrap{max-width:1100px;margin:0 auto;display:flex;flex-direction:column;gap:12px}h1{margin:0;font-size:22px}.mute{color:var(--mute);font-size:13px}
.bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center}select,button{font:inherit;color:var(--ink);background:var(--surface);border:1px solid var(--line);border-radius:9px;padding:6px 10px;cursor:pointer}
button:disabled{opacity:.4;cursor:default}.grow{flex:1}.prog{height:8px;background:var(--s2);border-radius:99px;overflow:hidden}.prog div{height:100%;background:var(--ok)}
.binder{background:var(--s2);border-radius:14px;padding:12px;display:grid;gap:7px;justify-content:center}
.pocket{position:relative;aspect-ratio:63/88;border-radius:6px;overflow:hidden;background:var(--surface);border:1px solid var(--line)}
.pocket img{width:100%;height:100%;object-fit:cover;display:block}.pocket.miss img{opacity:.22;filter:grayscale(1)}
.pocket .n{position:absolute;left:0;right:0;bottom:3px;text-align:center;font-size:10px;color:var(--mute)}
.pocket.none{background:transparent;border:1px dashed var(--mute);opacity:.5}.pocket.empty{background:transparent;border:0}
.q{position:absolute;top:3px;right:3px;background:var(--ok);color:#fff;border-radius:99px;font-size:10px;padding:0 5px}
</style></head><body><div class="wrap"><div><h1 id="t"></h1><div class="mute" id="by"></div></div>
<div class="prog"><div id="pg"></div></div><div class="mute" id="stat"></div>
<div class="bar"><label>Show <select id="view"><option value="all">Everything on the list</option><option value="own">Only what is owned</option><option value="miss">Only what is missing</option></select></label>
<label>Pockets <select id="lay"><option value="3x3">3 × 3</option><option value="4x3">4 × 3</option><option value="4x4">4 × 4</option><option value="9x9">9 × 9</option><option value="12x12">12 × 12</option></select></label>
<label id="nl"><input type="checkbox" id="none" checked> Blank spots where no card exists</label><span class="grow"></span>
<button id="prev" aria-label="Previous page">◀</button><span id="pn" class="mute"></span><button id="next" aria-label="Next page">▶</button></div>
<div class="binder" id="b"></div><div class="mute">Colour = owned · grey = still needed · blank = no card exists for that spot.</div></div>
<script>var D=__DATA__;
(function(){var $=function(i){return document.getElementById(i)},s=D.slots,page=0;
$("t").textContent=D.title;$("by").textContent=(D.owner?"by "+D.owner+" · ":"")+D.subtitle;
var real=s.filter(function(x){return x.state!=="none"}),have=real.filter(function(x){return x.state==="owned"}).length;
$("stat").textContent=have+" of "+real.length+" owned"+(real.length?" ("+Math.round(100*have/real.length)+"%)":"");$("pg").style.width=(real.length?100*have/real.length:0)+"%";
if(!s.some(function(x){return x.state==="none"}))$("nl").style.display="none";
var lv=D.layout||"3x3";if(![].some.call($("lay").options,function(o){return o.value===lv})){var oo=document.createElement("option");oo.value=lv;oo.textContent=lv.replace("x"," × ");$("lay").appendChild(oo)}$("lay").value=lv;
function list(){var v=$("view").value,n=$("none").checked;return s.filter(function(x){if(x.state==="none")return v==="all"&&n;if(v==="own")return x.state==="owned";if(v==="miss")return x.state==="missing";return true})}
function draw(){var L=list(),m=$("lay").value.split("x"),c=+m[0],r=+m[1],per=c*r,pages=Math.max(1,Math.ceil(L.length/per));page=Math.min(page,pages-1);
var b=$("b"),w=Math.min(b.parentNode.clientWidth-24,1100),cw=Math.max(24,Math.min(c<=4?200:100,Math.floor((w-7*(c-1))/c)));b.style.gridTemplateColumns="repeat("+c+","+cw+"px)";b.innerHTML="";
for(var i=0;i<per;i++){var x=L[page*per+i],d=document.createElement("div");
if(!x){d.className="pocket empty"}else if(x.state==="none"){d.className="pocket none";d.title=x.name||"No card exists"}
else{d.className="pocket"+(x.state==="owned"?"":" miss");d.title=x.name+" #"+x.number;if(x.img){var im=document.createElement("img");im.loading="lazy";im.alt=x.name;im.src=x.img;d.appendChild(im)}
if(x.state!=="owned"&&cw>40){var n=document.createElement("span");n.className="n";n.textContent="#"+x.number;d.appendChild(n)}}b.appendChild(d)}
$("pn").textContent="Page "+(page+1)+" of "+pages;$("prev").disabled=page===0;$("next").disabled=page>=pages-1}
["view","lay","none"].forEach(function(i){$(i).onchange=function(){page=0;draw()}});
$("prev").onclick=function(){page--;draw()};$("next").onclick=function(){page++;draw()};
document.onkeydown=function(e){if(e.key==="ArrowLeft"&&page>0){page--;draw()}if(e.key==="ArrowRight"){page++;draw()}};window.onresize=draw;draw()})();
</script></body></html>"""


def page_html(payload):
    data = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    return PAGE.replace("__TITLE__", html.escape(payload.get("title") or "Binder")).replace("__DATA__", data)
