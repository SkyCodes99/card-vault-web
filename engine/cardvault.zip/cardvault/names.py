"""English names for the Japanese card list.  The list ships with both: `name` / `name_ja` hold the Japanese name, `name_en` the English one (made by tools/translate_jp.py from TCGplayer's
English names and the Pokedex numbers - never machine-translated).  The card list keeps ONE of them in `name` (the column every screen, search and export reads) and the other in
`name_ja`; this swaps them to match the person's choice.  Searching always finds both."""


def _meta(conn, key):
    r = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return r[0] if r else ""


def apply(conn, mode):
    """mode 'english' | 'japanese'.  -> True when the names in the list were swapped just now (a list without English names is left alone)."""
    try:
        has = conn.execute("SELECT COUNT(*) FROM cards WHERE name_en IS NOT NULL AND name_en<>''").fetchone()[0]
    except Exception:  # noqa: BLE001 - an older list without the columns
        return False
    if not has:
        return False
    want = "ja" if mode == "japanese" else "en"
    if (_meta(conn, "names_shown") or "ja") == want:
        return False
    for table in ("cards", "sets"):
        if want == "en":
            conn.execute(f"UPDATE {table} SET name=name_en WHERE name_en IS NOT NULL AND name_en<>'' AND name_ja IS NOT NULL")
        else:
            conn.execute(f"UPDATE {table} SET name=name_ja WHERE name_ja IS NOT NULL AND name_ja<>''")
    conn.execute("INSERT OR REPLACE INTO meta VALUES('names_shown', ?)", (want,))
    conn.commit()
    return True
