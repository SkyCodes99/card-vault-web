"""Card and set names in the app's language.  Owner's rule (quiz 13, 2026-11-13): a name is shown in its OFFICIAL form in the language the app is set to, otherwise in English - never machine-translated.

  * Japanese list (pokemon_jp): `name_ja` is the printed Japanese name, `name_en` the official English one (tools/translate_jp.py).  English app -> English, Japanese app -> Japanese.
  * Pokemon (English list): `name_es` / `name_fr` / `name_de` / `name_it` / `name_pt` are the official names TCGdex prints on the card in that language (tools/fetch_local_names.py).
    The app in one of those languages shows them; a card TCGdex has no name for in that language keeps its English name.  `name_en` keeps the English name while another one is shown.
  * Everything else: the catalog's own (English) name, as before.

The list keeps ONE name in `name` (the column every screen, search and export reads); this module swaps it when the language changes.  Searching finds every name a card has.
The ONE place the rule lives: the UI only tells the engine its language (settings.cardLang)."""
import os

from . import searchfold

LOCAL = ("es", "fr", "de", "it", "pt")                     # the languages the English Pokemon list has official names in (TCGdex)
LANGS = ("ja",) + LOCAL
COLUMNS = {code: "name_" + code for code in LOCAL}


def clean(lang):
    """The language code the rule works with: ja / es / fr / de / it / pt; anything else (en, a language we have no names in) is English."""
    lang = str(lang or "en").lower()
    return lang if lang in LANGS else "en"


def _meta(conn, key):
    r = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return r[0] if r else ""


def _has(conn, where):
    try:
        return conn.execute(f"SELECT 1 FROM cards WHERE {where} LIMIT 1").fetchone() is not None
    except Exception:  # noqa: BLE001 - an older list without the columns
        return False


def is_japanese_list(conn):
    return _has(conn, "name_ja IS NOT NULL")


def want_for(conn, lang, jp=None):
    """The name the app in `lang` shows for this list: 'ja' / 'en' (Japanese list), or 'en' / one of LOCAL (English Pokemon list; English when the list carries none in that language)."""
    lang = clean(lang)
    if is_japanese_list(conn) if jp is None else jp:
        return "ja" if lang == "ja" else "en"
    if lang in COLUMNS and _has(conn, f"{COLUMNS[lang]} IS NOT NULL AND {COLUMNS[lang]}<>''"):
        return lang
    return "en"


def apply(conn, lang):
    """Show the names in the app's language `lang`.  -> True when the names in the list were swapped just now (a list without names in that language is left alone)."""
    jp = is_japanese_list(conn)
    want = want_for(conn, lang, jp)
    shown = _meta(conn, "names_shown") or ("ja" if jp else "en")
    before = conn.total_changes
    if jp:
        if shown == want or not _has(conn, "name_en IS NOT NULL AND name_en<>''"):         # (the index cards_name_en answers at once)
            return False
        for table in ("cards", "sets"):
            if want == "en":
                conn.execute(f"UPDATE {table} SET name=name_en WHERE name_en IS NOT NULL AND name_en<>'' AND name_ja IS NOT NULL AND name<>name_en")
            else:
                conn.execute(f"UPDATE {table} SET name=name_ja WHERE name_ja IS NOT NULL AND name_ja<>'' AND name<>name_ja")
    else:
        if shown == "en" and want == "en":
            return False
        conn.execute("UPDATE cards SET name_en=name WHERE name_en IS NULL OR name_en=''")           # remember the English name (a card added meanwhile arrives in English)
        if want == "en":
            conn.execute("UPDATE cards SET name=name_en WHERE name<>name_en")
        else:
            col = COLUMNS[want]
            pick = f"CASE WHEN {col} IS NOT NULL AND {col}<>'' THEN {col} ELSE name_en END"
            conn.execute(f"UPDATE cards SET name={pick} WHERE name<>{pick}")
    conn.execute("INSERT OR REPLACE INTO meta VALUES('names_shown', ?)", (want,))
    swapped = conn.total_changes - before > 1
    if swapped:
        conn.execute("UPDATE cards SET fold=NULL")                                                  # the words search looks in begin with the shown name: made again
        conn.execute("UPDATE sets SET fold=NULL")
        searchfold.fill(conn)
    conn.commit()
    return swapped or shown != want


def shipped_state(conn):
    """Put the list back to the names it is published with (English Pokemon in English, the Japanese list in Japanese), so one person's language is never everybody's."""
    return apply(conn, "ja" if is_japanese_list(conn) else "en")


def ship_db(db_path):
    """shipped_state() for one list file: the nightly update and the accuracy check call it first, because on the main PC they read the same lists the app shows - a list left in
    French by the app would otherwise look like thousands of wrong names to them.  The app puts its language back the next time it opens the list.  -> True when names were put back"""
    import sqlite3
    if not os.path.exists(db_path):
        return False
    conn = sqlite3.connect(db_path, timeout=60)
    try:
        if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='meta'").fetchone():
            return False
        if not _meta(conn, "names_shown"):
            return False                                                                       # (never swapped: as published)
        return shipped_state(conn)
    finally:
        conn.close()
