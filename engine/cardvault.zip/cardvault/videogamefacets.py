"""Video games (physical): the sidebar filters, read from each item's stated facts (raw ext written by cardvault/videogames.py).  Pure text rules, used by cardvault/gamefacets.py.

A filter value is always a word Wikidata states: the platform's maker and physical format, the publisher, developer, series, genre, the release region, and the release year (from the stated date).  An item whose
source states none of them has no value in that filter."""
import re


def _year(e):
    m = re.search(r"\b(\d{4})\b", str(e.get("Release date") or e.get("First released (the game, platform not stated)") or ""))
    return m.group(1) if m else ""


def year(e, c):
    return [_year(e)] if _year(e) else []


def decade(e, c):
    return ["%s0s" % _year(e)[:3]] if _year(e) else []


def _many(key):
    """Every value of a fact that lists several ('A / B'), once each."""
    return lambda e, c: list(dict.fromkeys(v.strip() for v in str(e.get(key) or "").split(" / ") if v.strip()))


def _one(key):
    return lambda e, c: [str(e[key]).strip()] if e.get(key) else []


FACETS = [("maker", "Console maker", _one("Maker")), ("format", "Format", _one("Format")), ("decade", "Decade", decade), ("year", "Release year", year), ("series", "Series", _many("Series")),
          ("genre", "Genre", _many("Genre")), ("publisher", "Publisher", _many("Publisher")), ("developer", "Developer", _many("Developer")), ("region", "Release region", _many("Regions"))]
