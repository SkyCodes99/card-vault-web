"""Grading tracker: cards sent to PSA / BGS / CGC (or another company), what was paid, and what came back.

Each card sent is ONE row of u.grading (uuid, lot_id, card_id, company, service, sent date, cost for this card, submission number, status, received date, grade, cert, graded date).
    status  sent -> received -> graded.  The copy sent is split off its stack into its own 1-copy lot, so a stack of 3 can send just 1.
    Grade came back (graded()): the lot becomes a graded copy (company, grade, cert).  Its value then uses that grade's price (pricepick.sql(v, lot=...) on every value screen) when the card list has one - a price row in source_prices
    whose finish is the company and grade written together in lower case ('psa10', 'bgs9.5', 'cgc10'), in dollars or euros.  No such row: "no graded price yet" and the raw price stays.  Nothing is ever made up.
    Cost basis: the grading cost of a card is added to what was paid for the copy (card_costs()), in profit and in the holdings split.
Every change is ONE undoable action through rowundo.track (lots + grading rows).  Prices are dollars here; the screens show them with money()."""
import datetime
import re

from . import pricepick, rowundo
from .db import new_uuid, now_iso

STATUSES = ("sent", "received", "graded")
COMPANIES = {"PSA": ["Value", "Regular", "Express", "Super Express", "Walk-Through"], "BGS": ["Base", "Standard", "Express", "Premium"], "CGC": ["Economy", "Standard", "Express", "WalkThrough"],
             "SGC": ["Standard", "Express"], "TAG": ["Standard", "Express"], "Other": []}
rowundo.TABLES.setdefault("grading", "uuid")

SCHEMA = ("CREATE TABLE IF NOT EXISTS u.grading("
          "uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, lot_id INTEGER, card_id TEXT, company TEXT, service TEXT, sent TEXT, cost REAL, submission TEXT, "
          "status TEXT, received TEXT, grade TEXT, cert TEXT, graded_on TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0)",
          "CREATE INDEX IF NOT EXISTS u.grading_lot ON grading(lot_id)")


class GradingError(ValueError):
    pass


def ensure(v):
    for sql in SCHEMA:
        v.conn.execute(sql)


def _has(v):
    return v.conn.execute("SELECT 1 FROM u.sqlite_master WHERE type='table' AND name='grading'").fetchone() is not None


def _day(x):
    s = str(x or "").strip()[:10]
    if not s:
        return datetime.date.today().isoformat()
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        raise GradingError("Type the date as year-month-day, like 2026-11-10.")


def _cost(x):
    if x in (None, ""):
        return 0.0
    try:
        c = float(x)
    except (TypeError, ValueError):
        raise GradingError("The cost has to be a number.")
    if c < 0:
        raise GradingError("The cost cannot be below zero.")
    return round(c, 2)


# ------------------------------------------------------------------------------------------------ graded prices
# The rule lives in pricepick (one place for every value screen): graded_price(v, card, company, grade) -> (usd, source) | None, and pricepick.sql(v, lot="l") for queries.
finish_key = pricepick.finish_key
graded_price = pricepick.graded_price


# ------------------------------------------------------------------------------------------------ profit hooks
def card_costs(v):
    """{card_id: grading cost of its copies that have a price paid (their cost basis grows by it)}."""
    if not _has(v):
        return {}
    out = {}
    for r in v.conn.execute("SELECT g.card_id, SUM(g.cost) FROM u.grading g JOIN lots_s l ON l.id=g.lot_id WHERE g.user_id=? AND g.game=? AND g.deleted=0 AND l.deleted=0 AND l.qty>0 "
                            "AND l.purchase_price IS NOT NULL GROUP BY g.card_id", (v.user_id, v.game)):
        out[r[0]] = r[1] or 0.0
    return out


def lot_costs(v):
    """{lot id: grading cost paid for that copy}; {} before anything was ever sent."""
    if not _has(v):
        return {}
    return {lot: c or 0.0 for lot, c in v.conn.execute("SELECT lot_id, SUM(cost) FROM u.grading WHERE user_id=? AND game=? AND deleted=0 GROUP BY lot_id", (v.user_id, v.game))}


# ------------------------------------------------------------------------------------------------ the actions
def _pick_lots(v, lots, cards):
    """The raw lots to send: the ones named, plus the first raw copy of each named card."""
    out = {x[0] for x in v.conn.execute("SELECT lot_id FROM u.grading WHERE user_id=? AND game=? AND deleted=0 AND status!='graded'", (v.user_id, v.game))}      # (already away: not sent twice)
    got, seen = [], set(out)
    for lid in lots or []:
        r = v.get_lot(int(lid))
        if r and not r["deleted"] and r["qty"] > 0 and not r["graded"] and r["id"] not in seen:
            got.append(r)
            seen.add(r["id"])
    for cid in cards or []:
        for r in v.lots_for(cid):
            if r["qty"] > 0 and not r["graded"] and r["id"] not in seen:
                got.append(r)
                seen.add(r["id"])
                break
    return got


def send(v, lots=(), cards=(), company="PSA", service="", sent="", cost=0, submission=""):
    """Send one copy of each lot / card to a grading company.  cost is per card.  -> {sent: cards sent, skipped: named ones with no raw copy}.  ONE undo."""
    company = (company or "").strip()
    if not company:
        raise GradingError("Pick the grading company.")
    ensure(v)
    day, cost = _day(sent), _cost(cost)
    picks = _pick_lots(v, lots, cards)
    if not picks:
        raise GradingError("There is no ungraded copy to send - graded copies and cards you do not own cannot be sent.")
    skipped = len(set(cards or [])) + len(set(lots or [])) - len(picks)
    ids = sorted({r["card_id"] for r in picks})
    marks = ",".join("?" * len(ids))
    n = len(picks)

    def run():
        ts = now_iso()
        for r in picks:
            lot = r["id"]
            if r["qty"] > 1:                                                      # split one copy off the stack
                row = {k: r[k] for k in r.keys() if k != "id"}
                row.update(uuid=new_uuid(), qty=1, updated_at=ts)
                v.conn.execute("UPDATE u.lots SET qty=qty-1, updated_at=? WHERE id=?", (ts, lot))
                lot = v.conn.execute(f"INSERT INTO u.lots({','.join(row)}) VALUES({','.join('?' * len(row))})", list(row.values())).lastrowid
            v.conn.execute("INSERT INTO u.grading(uuid,user_id,game,lot_id,card_id,company,service,sent,cost,submission,status,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                           (new_uuid(), v.user_id, v.game, lot, r["card_id"], company, service or "", day, cost, submission or "", "sent", ts))
    rowundo.track(v, f"Sent {n} card{'s' if n != 1 else ''} to {company}", [("lots", f"user_id=? AND game=? AND card_id IN ({marks})", (v.user_id, v.game, *ids)),
                                                                          ("grading", "user_id=? AND game=?", (v.user_id, v.game))], run)
    return {"sent": n, "skipped": max(0, skipped)}


def _rows(v, uuids):
    out = []
    for u in dict.fromkeys(uuids or []):
        r = v.conn.execute("SELECT * FROM u.grading WHERE uuid=? AND user_id=? AND game=? AND deleted=0", (u, v.user_id, v.game)).fetchone()
        if r:
            out.append(r)
    return out


def received(v, ids, day=""):
    """The company has the cards back (not graded yet is fine: this just marks them received).  ONE undo."""
    rows = [r for r in _rows(v, ids) if r["status"] == "sent"]
    if not rows:
        raise GradingError("Nothing to mark - these are not waiting to come back.")
    d = _day(day)

    def run():
        for r in rows:
            v.conn.execute("UPDATE u.grading SET status='received', received=?, updated_at=? WHERE uuid=?", (d, now_iso(), r["uuid"]))
    rowundo.track(v, f"Marked {len(rows)} card{'s' if len(rows) != 1 else ''} received from grading", [("grading", [r["uuid"] for r in rows])], run)
    return {"changed": len(rows)}


def graded(v, uuid, grade, cert="", day=""):
    """Grade came back: the copy becomes graded (company, grade, cert) and its value uses that grade's price if there is one.  -> {price: {usd, source} | None}.  ONE undo."""
    rows = _rows(v, [uuid])
    grade = str(grade or "").strip()
    if not rows:
        raise GradingError("That submission was not found.")
    if not grade:
        raise GradingError("Type the grade that came back.")
    r = rows[0]
    if r["status"] == "graded":
        raise GradingError("This card already has its grade.")
    d = _day(day)
    cert = str(cert or "").strip()

    def run():
        ts = now_iso()
        v.conn.execute("UPDATE u.lots SET graded=1, condition='Graded', grade_company=?, grade=?, cert=?, updated_at=? WHERE id=?", (r["company"], grade, cert, ts, r["lot_id"]))
        v.conn.execute("UPDATE u.grading SET status='graded', grade=?, cert=?, graded_on=?, received=COALESCE(received, ?), updated_at=? WHERE uuid=?", (grade, cert, d, d, ts, uuid))
    rowundo.track(v, f"{r['company']} {grade} came back", [("lots", [r["lot_id"]]), ("grading", [uuid])], run)
    gp = graded_price(v, r["card_id"], r["company"], grade)
    return {"price": None if gp is None else {"usd": gp[0], "source": gp[1]}}


# ------------------------------------------------------------------------------------------------ the page
def _days(r, today):
    try:
        start = datetime.date.fromisoformat(r["sent"])
        end = today
        if r["status"] == "graded" and r["graded_on"]:
            end = datetime.date.fromisoformat(r["graded_on"])
        elif r["status"] == "received" and r["received"]:
            end = datetime.date.fromisoformat(r["received"])
        return max(0, (end - start).days)
    except (TypeError, ValueError):
        return None


def listing(v):
    """{rows, totals, companies} for the Grading page: every submission with its card, status, days out, cost and graded price (None -> 'no graded price yet')."""
    ensure(v)
    today = datetime.date.today()
    rows = []
    for r in v.conn.execute("SELECT g.*, c.name AS cname, c.local_id AS cno FROM u.grading g LEFT JOIN cards c ON c.id=g.card_id "
                            "WHERE g.user_id=? AND g.game=? AND g.deleted=0 AND NOT EXISTS(SELECT 1 FROM u.lots l WHERE l.id=g.lot_id AND l.deleted=1) "          # (a copy that was sold or removed is no longer out for grading)
                            "ORDER BY g.sent DESC, g.rowid DESC", (v.user_id, v.game)).fetchall():
        done = r["status"] == "graded"
        gp = graded_price(v, r["card_id"], r["company"], r["grade"]) if done else None
        raw = pricepick.price_for(v, r["card_id"])
        rows.append({"id": r["uuid"], "card_id": r["card_id"], "name": r["cname"] or r["card_id"], "number": r["cno"], "company": r["company"], "service": r["service"], "sent": r["sent"],
                     "cost": r["cost"] or 0.0, "submission": r["submission"], "status": r["status"], "received": r["received"], "grade": r["grade"], "cert": r["cert"],
                     "days": _days(r, today), "raw": raw, "graded_price": None if gp is None else gp[0], "price_source": None if gp is None else gp[1],
                     "no_graded_price": done and gp is None, "value": (gp[0] if gp else raw) if done else raw})
    open_ = [x for x in rows if x["status"] != "graded"]
    totals = {"count": len(rows), "cost": round(sum(x["cost"] for x in rows), 2), **{s: sum(1 for x in rows if x["status"] == s) for s in STATUSES},
              "longest": max([x["days"] or 0 for x in open_] or [0])}
    return {"rows": rows, "totals": totals, "companies": COMPANIES}
