"""Which goal (Standard / Master / Extra, see completion.py) a person picked for each set.  Kept per person and game in the user settings, each with the time it was chosen, and carried by
the sync snapshot (newest choice per set wins) so the choice follows the account to every device.  An empty goal means "back to the default" and is kept as the newest word on that set."""
import json

from .completion import GOALS
from .db import now_iso

KEY = "set_goals"


def raw(v):
    """{set id: {"goal": ..., "updated_at": ...}} as stored (a reset set keeps an entry with an empty goal)."""
    try:
        d = json.loads(v.get_setting(KEY) or "{}")
    except ValueError:
        d = {}
    return {k: x for k, x in d.items() if isinstance(x, dict)} if isinstance(d, dict) else {}


def load(v):
    """{set id: goal} for the sets that have a goal picked."""
    return {k: x["goal"] for k, x in raw(v).items() if x.get("goal") in GOALS}


def save(v, set_id, goal):
    """Pick the goal of one set (None / "" = back to the default)."""
    d = raw(v)
    d[set_id] = {"goal": goal if goal in GOALS else "", "updated_at": now_iso()}
    v.set_setting(KEY, json.dumps(d, sort_keys=True))


def merge(a, b):
    """Two devices' picks -> the newest word on every set (the local one on an exact tie)."""
    out = dict(b or {})
    for k, x in (a or {}).items():
        y = out.get(k)
        if y is None or (x.get("updated_at") or "") >= (y.get("updated_at") or ""):
            out[k] = x
    return out


def apply(v, merged):
    """Write merged picks into this device; returns how many sets changed."""
    have, changed = raw(v), 0
    for k, x in (merged or {}).items():
        if (have.get(k) or {}) != x and (x.get("updated_at") or "") >= ((have.get(k) or {}).get("updated_at") or ""):
            have[k] = x
            changed += 1
    if changed:
        v.set_setting(KEY, json.dumps(have, sort_keys=True))
    return changed
