"""Deck lists as plain text, the way deck sites and the game apps share them.
    Pokémon   the Pokémon TCG Live export: section headers ("Pokémon: 12"), then "4 Pikachu ex SVI 57" lines, then "Total Cards: 60"
    One Piece one "4xOP01-001" line per card (the Leader first, 1x) - the form OPTCGSim and the deck sites use
    Yu-Gi-Oh!  the .ydk file (decklist_ygo.py);  Magic  Arena / MTGO text (decklist_mtg.py)
parse() reads any of them (plain "4 Card name" lines too) and matches every line to a card of the open game; the lines it can't match come back as they were so they can be fixed."""
import re

from . import deckcards, decklist_mtg, decklist_ua, decklist_ygo, decklookup, deckrules

_OP_CODE = r"([A-Z]{1,4}\d{0,3}-\d{2,3}[A-Z]?)"
_OP_LINE = (re.compile(r"^\s*(\d{1,2})\s*[xX×]?\s*" + _OP_CODE + r"\b"), re.compile(r"^\s*" + _OP_CODE + r"\s*[xX×]\s*(\d{1,2})\b"))
_PK_LINE = re.compile(r"^\s*[*•-]?\s*(\d{1,2})\s*[xX]?\s+(.+?)\s*$")
_PK_TAIL = re.compile(r"^(.*?)\s+([A-Z][A-Za-z0-9-]{1,7})\s+([A-Za-z]{0,6}\d{1,4}[a-z]?)$")


def _codes():
    return (deckrules.rules().get("pokemon") or {}).get("ptcgl_codes") or {}


# ------------------------------------------------------------------------------------------------ export
def export(game, deck, info, v=None):
    if game == "yugioh":
        return decklist_ygo.export(deck, info, v)
    if game == "mtg":
        return decklist_mtg.export(deck, info)
    if game == "unionarena":
        return decklist_ua.export(deck, info)
    if game == "onepiece":
        rows = sorted(((info[cid], n) for cid, n in deck.items() if cid in info and info[cid]["section"] != "DON!!"),
                      key=lambda x: (x[0]["section"] != "Leader", x[0].get("cost") if x[0].get("cost") is not None else 99, x[0]["key"]))
        merged = {}                                                        # (a parallel print is the same card number: one line)
        for c, n in rows:
            merged[c["key"]] = merged.get(c["key"], 0) + n
        return "\n".join(f"{n}x{k}" for k, n in merged.items()) + "\n"
    back = {}
    for code, sid in _codes().items():
        back.setdefault(sid, code)
    parts, total = [], 0
    for sec in deckcards.sections(game):
        rows = sorted(((info[cid], n) for cid, n in deck.items() if cid in info and info[cid]["section"] == sec), key=lambda x: (-x[1], x[0]["name"]))
        if not rows:
            continue
        n_sec = sum(n for _, n in rows)
        total += n_sec
        head = "Trainer" if sec == "Trainer" else "Energy" if sec == "Energy" else "Pokémon" if sec == "Pokémon" else "Other"
        parts.append(f"{head}: {n_sec}\n" + "\n".join(f"{n} {c['name']} {back.get(c['set_id'], c['set_id'].upper())} {c['number']}" for c, n in rows))
    return "\n\n".join(parts) + f"\n\nTotal Cards: {total}\n"


# ------------------------------------------------------------------------------------------------ import
def _lines(text):
    for raw in (text or "").splitlines():
        line = raw.strip()
        if line:
            yield line


_pick, _SELECT = decklookup.pick, decklookup.SELECT


def _onepiece_line(v, line):
    for i, pat in enumerate(_OP_LINE):
        m = pat.match(line.upper())
        if m:
            n, code = (m.group(1), m.group(2)) if i == 0 else (m.group(2), m.group(1))
            return int(n), _pick(v.conn.execute(_SELECT + "WHERE UPPER(c.local_id)=?", (code,)).fetchall())
    return None, None


def _pokemon_by_name(v, name, number=""):
    nm = re.sub(r"^basic\s+", "", name.strip(), flags=re.I)
    tries = (name.strip(), nm, f"Basic {nm}")
    for t in tries:
        rows = v.conn.execute(_SELECT + "WHERE c.name=? COLLATE NOCASE OR c.name_en=? COLLATE NOCASE", (t, t)).fetchall()          # name_en: an English list while names are shown in another language
        if rows:
            same = [r for r in rows if number and str(r["local_id"] or "").lstrip("0") == number.lstrip("0")]
            if same:
                return _pick(same)
            return _pick(rows)
    return None


def _pokemon_line(v, line, set_ids):
    m = _PK_LINE.match(line)
    if not m:
        return None, None
    n, rest = int(m.group(1)), m.group(2)
    t = _PK_TAIL.match(rest)
    if t:
        name, code, num = t.group(1), t.group(2), t.group(3)
        sid = _codes().get(code.upper()) or set_ids.get(code.lower())
        if sid:
            r = v.conn.execute("SELECT id FROM cards WHERE set_id=? AND LTRIM(local_id,'0')=LTRIM(?,'0')", (sid, num)).fetchone()
            if r:
                return n, r[0]
        cid = _pokemon_by_name(v, name, num)
        if cid:
            return n, cid
    return n, _pokemon_by_name(v, rest)


def parse(v, text):
    """-> {cards: {card_id: copies}, unmatched: [line], lines: how many card lines}.  Headers ('Pokémon: 12', 'Total Cards: 60', 'Leader') are skipped."""
    if v.game == "yugioh":
        return decklist_ygo.parse(v, text)
    if v.game == "mtg":
        return decklist_mtg.parse(v, text)
    if v.game == "unionarena":
        return decklist_ua.parse(v, text)
    cards, unmatched, count = {}, [], 0
    set_ids = {r[0].lower(): r[0] for r in v.conn.execute("SELECT id FROM sets")} if v.game != "onepiece" else {}
    for line in _lines(text):
        n, cid = _onepiece_line(v, line) if v.game == "onepiece" else _pokemon_line(v, line, set_ids)
        if n is None:
            continue                                                       # a header or a note, not a card line
        count += 1
        if cid:
            cards[cid] = cards.get(cid, 0) + n
        else:
            unmatched.append(line)
    return {"cards": cards, "unmatched": unmatched, "lines": count}
