"""What a search means, not only which words it has (owner 2026-11-05: "if I type yugioh funko or pokemon card or charizard card 1st edition then it would pull things that relate").

understand("yugioh funko")                -> the Funko list, looking for Yu-Gi-Oh! Pops  (a toy list named with a card game = that toy list, the game is the fandom)
understand("pokemon card")                -> Pokémon, cards only
understand("charizard card 1st edition")  -> cards called Charizard from the years 1st Edition Pokémon cards were printed (1999-2002)
Words that name a game, a kind of thing or a printing become filters; everything else is searched as before.  Pure function: no database."""
import re
import unicodedata

from . import games as games_mod

_KIND_WORDS = {"card": "cards", "cards": "cards", "sealed": "sealed"}
_EXTRA = {"mtg": "mtg", "ygo": "yugioh", "pkmn": "pokemon", "pokemontcg": "pokemon", "funkopop": "funko", "funkopops": "funko", "pop": None, "pops": None}   # (None: a word that only goes with the next one)
_FIRST_PRINT_LAST_YEAR = 2002                                    # the last Pokémon sets with 1st Edition prints (Neo Destiny, Legendary Collection era)
_FIRST = re.compile(r"\b(?:1st|first)\s*(?:ed(?:ition)?\.?)\b|\b1st\s*ed\b", re.I)


def _fold(s):
    return "".join(ch for ch in unicodedata.normalize("NFKD", s or "") if not unicodedata.combining(ch)).lower()


def _key(s):
    return re.sub(r"[^a-z0-9]+", "", _fold(s))


def _names():
    """{folded name: game id} for every game: its id, its name ('Yu-Gi-Oh!' -> 'yugioh') and a few ways people write them."""
    out = {}
    for g in games_mod.GAMES:
        for n in (g.id, g.name):
            k = _key(n)
            if len(k) >= 4:
                out.setdefault(k, g.id)
    out.update({k: v for k, v in _EXTRA.items() if v})
    return out


def _fandom_word(gid):
    """How a card game is written inside a toy's name or line ('Yu-Gi-Oh!' Pops, 'Pokémon' plush)."""
    if gid.startswith("pokemon"):
        return "pok"                                                   # (Pokémon / Pokemon / POKÉMON, whichever way the toy's page wrote it)
    n = re.sub(r"\([^)]*\)|\b(?:trading card game|card game|tcg)\b", " ", games_mod.game_by_id(gid).name.lower())
    return re.sub(r"[!:.]+$", "", n.split(":")[0].strip())


def understand(q):
    """-> {"q": the words still to search for, "games": [game ids] or [], "kinds": [...] or [], "year_max": int | None}.  Nothing understood: q comes back as it was."""
    out = {"q": q or "", "games": [], "kinds": [], "year_max": None}
    text = _fold(q)
    first = bool(_FIRST.search(text))
    text = _FIRST.sub(" ", text)
    names = _names()
    toks = re.findall(r"[a-z0-9][a-z0-9'&.-]*", text)
    found, kinds, rest, i = [], [], [], 0
    while i < len(toks):
        hit = None
        for n in (3, 2, 1):                                            # 'one piece', 'magic the gathering', 'yu gi oh'
            if i + n <= len(toks) and _key("".join(toks[i:i + n])) in names:
                hit = (names[_key("".join(toks[i:i + n]))], n)
                break
        if hit:
            found.append(hit[0])
            i += hit[1]
            continue
        t = toks[i]
        if t in _KIND_WORDS:
            kinds.append(_KIND_WORDS[t])
        elif t not in _EXTRA:
            rest.append(t)
        i += 1
    if not found and not kinds and not first:
        return out
    toys = [g for g in found if games_mod.is_misc(g)]
    if toys:                                                           # 'yugioh funko': the Funko list, Yu-Gi-Oh! is what the Pop is of
        rest += [_fandom_word(g) for g in found if g not in toys]
        found = toys
    out["games"] = list(dict.fromkeys(found))
    out["kinds"] = list(dict.fromkeys(kinds))
    if first and (not out["games"] or set(out["games"]) <= {"pokemon", "pokemon_jp"}):
        out["year_max"] = _FIRST_PRINT_LAST_YEAR
    out["q"] = " ".join(rest)
    return out
