"""The DAILY UPDATE LOG: what each run of tools/daily_update.py added or changed, from which source and when (owner-only, Dev Tools > Daily log).
One file per day (daily_update_log/<day>.json, the run's report) carries a list of `events`; this module writes that file and reads the days back, filtered by game and kind.
Reports written before events existed are read too: their per-game counts and examples become events."""
import datetime
import json
import os
import re

KINDS = {                      # kind -> what the owner sees
    "new_card": "New card", "new_sealed": "New sealed product", "prices": "Prices updated", "tcgplayer": "Added from TCGplayer",
    "promo": "Promo printings", "review": "Sent to your review list", "error": "Kept the old list", "publish": "Published to Card Data",
    "held": "Waiting for you (big change)", "site_off": "Site switched off", "site_on": "Site back on", "price_history": "Price history",
}
_DAY = re.compile(r"^\d{4}-\d{2}-\d{2}\.json$")
PER_KIND_CAP = 200             # events listed per game and kind in one run (the count of the rest is kept in a "more" note)


def log_dir():
    """Where the daily runs write: COLLECT_DAILY_LOG, else the folder next to the app's project folder (C:\\Users\\<owner>\\daily_update_log)."""
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.environ.get("COLLECT_DAILY_LOG") or os.path.join(os.path.dirname(here), "daily_update_log")


def now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def event(game, kind, source, name="", item_id="", count=1, note=""):
    return {"when": now(), "game": game, "kind": kind, "source": source, "name": name, "id": str(item_id or ""), "count": count, "note": note}


def items_events(game, kind, source, rows):
    """Events for a list of (id, name): one each up to PER_KIND_CAP, then one 'more' event with the rest of the count."""
    rows = list(rows)
    out = [event(game, kind, source, name, i) for i, name in rows[:PER_KIND_CAP]]
    if len(rows) > PER_KIND_CAP:
        out.append(event(game, kind, source, "", "", len(rows) - PER_KIND_CAP, "more not listed one by one"))
    return out


def save(day, report):
    """Write the day's report (with its events) -> the path."""
    os.makedirs(log_dir(), exist_ok=True)
    path = os.path.join(log_dir(), f"{day}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1, ensure_ascii=False)
    return path


def events_of(report):
    """The events of one report; an older report (no events) gives one per example item plus one per count."""
    if "events" in report:
        return list(report["events"])
    day, out = report.get("day", ""), []
    for g, v in (report.get("games") or {}).items():
        if "error" in v:
            out.append({"when": day, "game": g, "kind": "error", "source": "", "name": "", "id": "", "count": 1, "note": v["error"]})
            continue
        out += [{"when": day, "game": g, "kind": "new_card", "source": "", "name": n, "id": "", "count": 1, "note": ""} for n in v.get("examples") or []]
        if v.get("pricesUpdated"):
            out.append({"when": day, "game": g, "kind": "prices", "source": "", "name": "", "id": "", "count": v["pricesUpdated"], "note": ""})
    return out


def read(game="", kind="", days=30, limit=500):
    """The last `days` days of events, newest first, optionally one game and/or kind -> {events, total, games, kinds, days}"""
    folder = log_dir()
    files = sorted((f for f in (os.listdir(folder) if os.path.isdir(folder) else []) if _DAY.match(f)), reverse=True)[:max(1, int(days))]
    allev, per_day = [], []
    for fn in files:
        try:
            with open(os.path.join(folder, fn), encoding="utf-8") as f:
                rep = json.load(f)
        except (OSError, ValueError):
            continue
        evs = [dict(e, day=fn[:10]) for e in events_of(rep)]
        allev += evs
        per_day.append({"day": fn[:10], "events": len(evs), "publish": rep.get("publish", ""), "games": len(rep.get("games") or {})})
    shown = [e for e in allev if (not game or e.get("game") == game) and (not kind or e.get("kind") == kind)]
    shown.sort(key=lambda e: (e.get("when") or "", e.get("name") or ""), reverse=True)
    return {"events": shown[:max(1, int(limit))], "total": len(shown), "games": sorted({e.get("game") for e in allev if e.get("game")}),
            "kinds": [{"id": k, "label": v} for k, v in KINDS.items()], "days": per_day}
