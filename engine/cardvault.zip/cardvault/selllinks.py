"""Where to sell an item: the "Where to sell" list in the item panel (under Shop).  Links only - the app never buys or sells.  Plain links, no affiliate or tracking parameters (owner, 2026-11-10).

`for_item(game, name, set_name, number, offers=None)` returns [{site, url, offer: usd|None, checked: "YYYY-MM-DD"|None}] for the buylists of that game.
  * A site is listed only if its robots.txt/terms allow it.  BLOCKED sites are never linked and never read (checked 2026-11-10):
      Star City Games - robots.txt names ClaudeBot/Claude-Web.   TCGplayer - no public buylist to link.   Troll and Toad - its buylist pages are behind a store password (no public page), and Card Kingdom has no buylist for any game but Magic.
  * Added 2026-11-11: CoolStuffInc (robots.txt allows everything except /user, /checkout, /admin, /ajax, /main_view_cart; Conditions of Use do not forbid linking; the buylist page answered 200 for each game below).
    Never used at all: eBay, PriceCharting, Collectr, CardTrader, Cardmarket.
  * Offer: only from `offers` ({site: {"usd": 1.5, "checked": "2026-11-10"}}, stored by the weekly check).  No site's offer is read today (refresh_offers, weekly), only where one exact card matches; otherwise it shows as unknown and the link is shown alone.
"""
from urllib.parse import quote_plus

from . import linkstore
from .shoplinks import clean_url

# site -> (games it buys for, search-url template with {q}).  Only sites whose search link was opened and answered 200.
SITES = {
    "Card Kingdom": (("mtg",), "https://www.cardkingdom.com/purchasing/mtg_singles?filter%5Bsearch%5D=mtg_advanced&filter%5Bname%5D={q}"),
    "CoolStuffInc": (("mtg", "pokemon", "yugioh", "lorcana", "onepiece", "swu", "riftbound"), "https://www.coolstuffinc.com/main_selllist.php?name={q}&s={g}"),
}
GAME_CODE = {"onepiece": "optcg"}      # the game's name in a site's own address, where it differs from ours
BLOCKED = {"Star City Games": "robots.txt names ClaudeBot/Claude-Web", "TCGplayer": "no public buylist"}


def _query(name, set_name="", number=""):
    return quote_plus(str(name or "").strip())


def for_item(game, name, set_name="", number="", offers=None):
    offers = offers if isinstance(offers, dict) else None
    if not str(name or "").strip():
        return []
    out = []
    for site, (games, tpl) in SITES.items():
        if site in BLOCKED or game not in games:
            continue
        url = clean_url(tpl.format(q=_query(name, set_name, number), g=GAME_CODE.get(game, game)))
        if not url:
            continue
        o = (offers.get(site) if offers is not None else linkstore.offer_for(game, name, set_name, site)) or {}
        o = o if isinstance(o, dict) else {}
        usd = o.get("usd") if isinstance(o.get("usd"), (int, float)) and o.get("usd") > 0 else None
        out.append({"site": site, "url": url, "offer": usd, "checked": o.get("checked") if usd is not None else None,
                    "checkedText": linkstore.pretty(o.get("checked")) if usd is not None else ""})
    return out


def refresh_offers(items, **kw):
    """The weekly check's offer step (cardvault/weeklylinks.py): re-read public buylist offers for `items` ([(game, name, set_name)]) where robots.txt allows and the page states a price; stores them with their date."""
    from . import weeklylinks
    return weeklylinks.refresh_offers(items, **kw)
