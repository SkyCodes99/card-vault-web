"""Roadmap 2.1 "Delta Reign done properly": a set's real card pictures and its logo, then a check of every other auto-added set for wrong pictures.  Everything is read through the shared,
polite source reader (cardvault/sources: robots.txt, rate limits, cache); the owner's picture rule (cardvault/gates.py) decides what may be written.

fix_set(conn, game, set_id, reader, gdir, dry_run)    for each card with no picture (or one that fails gates.check_picture), its OWN product record is looked up:
    1. the TCGplayer product the card is linked to (cards.tcg_id), read from the set's TCGplayer group (tcgcsv): the record must agree with the card on number and name and list a picture;
    2. else the card's TCGdex record (TCGdex's set record lists each card's own picture).
  The picture then goes through gates.screen_picture (bytes read through the reader: real size, not another item's): a confirmed one is written with its provenance stamp; anything unsure
  waits on the owner's review list.  A record that disagrees with the card is never written: it waits on the review list as well.
  The set logo comes from the set's own record: TCGdex's set (as for the other Pokemon sets), else the pokemontcg.io set with the same name and card count (as cardvault/setimages.py does).
  A card picture or a generated banner never counts as a logo.
sweep(data_dir, games, reader=None, dry_run)           read-only: in every auto-added set, the cards whose picture fails gates.check_picture go on the review list (kind 'picture_check';
  yes = keep it, no = remove it so the card shows "No picture yet").  Nothing in the catalog is changed by the sweep itself."""
import json
import os
import re
import sqlite3

from . import gates, provenance, reviewlist
from .bulbapedia import art_path
from .db import picture_url
from .tcggames import CATEGORIES, NATIVE

KIND = "picture_check"
SOURCE_TCG = "TCGplayer product record via tcgcsv.com"
SOURCE_TDX = "TCGdex card record"
SWEEP_SOURCE = "picture sweep of the auto-added sets (roadmap 2.1)"
AUTO_SINCE = "2026-11-05"           # the daily update adds new sets by itself from this day (owner 2026-11-05); a TCGplayer game's set dated from here on was added by it
TCGCSV = "https://tcgcsv.com/tcgplayer"
TCGDEX = "https://api.tcgdex.net/v2/en"
PTCG = "https://api.pokemontcg.io/v2/sets?q=name:%22{}%22"
DAY = 12 * 3600
MIN_LOGO_SIDE = 40


# ------------------------------------------------------------------------------------------------ the reader (the shared polite Fetcher; tests pass one with a fake network)
class Reader:
    def __init__(self, fetcher=None):
        if fetcher is None:
            from . import sources
            fetcher = sources.default()
        self.fetcher, self.notes = fetcher, []

    def _get(self, url, max_age):
        from .sources import SourceError
        try:
            got = self.fetcher.get(url, max_age=max_age)
        except SourceError as e:
            self.notes.append(f"{url[:80]}: {e}")
            return None
        return got.body if got.status == 200 and got.body else None

    def json(self, url, max_age=DAY):
        b = self._get(url, max_age)
        try:
            return json.loads(b) if b else None
        except ValueError:
            return None

    def bytes(self, url, max_age=30 * 24 * 3600):
        return self._get(url, max_age)


# ------------------------------------------------------------------------------------------------ the card's own records
def _base(name):
    from .tcgsync import _base as b
    return b(name)


def _ext(p):
    return {e.get("name"): e.get("value") for e in p.get("extendedData") or []}


def tcg_group(reader, game, set_row, tcg_ids):
    """-> (group, {product id: product}) of the TCGplayer group that holds most of the set's linked cards (its name must match the set's), or (None, {})."""
    from .tcgsync import _same_set_name
    cat = CATEGORIES.get(game)
    if not cat:
        return None, {}
    groups = (reader.json(f"{TCGCSV}/{cat}/groups") or {}).get("results") or []
    best, best_n, best_p = None, 0, {}
    for g in groups:
        if not _same_set_name(g.get("name") or "", set_row["name"] or ""):
            continue
        prods = {str(p["productId"]): p for p in (reader.json(f"{TCGCSV}/{cat}/{g['groupId']}/products") or {}).get("results") or []}
        n = len(tcg_ids & set(prods))
        if n > best_n:
            best, best_n, best_p = g, n, prods
    return best, best_p


def record_disagrees(card, product):
    """'' when the TCGplayer product record is this card's (same number, same name, lists a picture), else why not."""
    num = _ext(product).get("Number") or ""
    if gates._numkey(num) != gates._numkey(card["local_id"]):
        return f"TCGplayer's record says number {num or 'none'}, the card is #{card['local_id']}"
    if _base(product.get("name")) != _base(card["name"]):
        return f"TCGplayer's record is named {product.get('name')!r}, the card is {card['name']!r}"
    return ""


def tcgdex_set(reader, set_id):
    return reader.json(f"{TCGDEX}/sets/{set_id}", 6 * 3600) or {}


# ------------------------------------------------------------------------------------------------ one set: pictures + logo
def _screen(game, conn, cid, url, source, ctx, dry_run):
    """gates.screen_picture; a dry run asks the same question without putting anything on the review list."""
    if not dry_run:
        return gates.screen_picture(game, conn, cid, url, source, ctx)
    row = dict(zip(gates._cols(conn), conn.execute("SELECT * FROM cards WHERE id=?", (cid,)).fetchone()))
    item = dict(gates.item_from_row(row), image=url)
    done = ctx.said(gates.PICTURE).get(str(cid))
    if (done and done["answer"] == "yes" and (done["final"] or {}).get("picture") == url) or not gates.check_picture(game, item, ctx):
        ctx.claim(url, gates._key(item))
        return True
    return False


def _ask(game, card, url, why, source, dry_run):
    if not dry_run:
        reviewlist.add_item(gates.PICTURE, game, card["id"], f"Is this the picture of {card['name']} #{card['local_id']} ({card['set_id']})? Not used yet: {why[:300]}.",
                            before={"picture": card["image_base"] or "No picture yet"}, after={"picture": url, "from": source}, source=source)


def fix_pictures(conn, game, set_id, reader, dry_run=False, fetch_image=True):
    """-> {cards, had, confirmed, waiting, none, examples}"""
    cols = gates._cols(conn)
    cards = [dict(zip(cols, r)) for r in conn.execute("SELECT * FROM cards WHERE set_id=? ORDER BY sort_key, local_id", (set_id,))]
    set_row = dict(zip([d[0] for d in conn.execute("SELECT * FROM sets LIMIT 0").description], conn.execute("SELECT * FROM sets WHERE id=?", (set_id,)).fetchone() or ()))
    ctx = gates.Context(conn, game, (lambda u: reader.bytes(picture_url(u.split("#")[0]))) if fetch_image else None)      # (a TCGdex link is a base: its picture is <base>/low.webp)
    plain = gates.Context(conn, game)                                   # (the URL checks only, for the report and for pictures the card already has)
    out = {"cards": len(cards), "had": 0, "confirmed": 0, "waiting": 0, "none": 0, "examples": []}
    group, products = tcg_group(reader, game, set_row, {str(c["tcg_id"]) for c in cards if c.get("tcg_id")}) if cards else (None, {})
    out["group"] = group and {"id": group.get("groupId"), "name": group.get("name"), "published": (group.get("publishedOn") or "")[:10]}
    tdx = None
    written = []
    for c in cards:
        if (c.get("image_base") or "").strip() and not gates.check_picture(game, gates.item_from_row(c), plain):
            out["had"] += 1
            continue
        url, source, why = None, None, ""
        p = products.get(str(c.get("tcg_id") or ""))
        if p and p.get("imageUrl") and p.get("imageCount", 1):
            url, source, why = p["imageUrl"], SOURCE_TCG, record_disagrees(c, p)
        else:
            if tdx is None:
                tdx = {str(x.get("localId")): x for x in tcgdex_set(reader, set_id).get("cards") or []}
            x = tdx.get(str(c["local_id"]))
            if x and x.get("image") and _base(x.get("name")) == _base(c["name"]):
                url, source = x["image"], SOURCE_TDX
        if not url:
            out["none"] += 1
            continue
        if why:
            _ask(game, c, url, why, source, dry_run)
            out["waiting"] += 1
            out["examples"].append(f"{c['id']}: {why}")
            continue
        if _screen(game, conn, c["id"], url, source, ctx, dry_run):
            written.append((url, c["id"]))
            out["confirmed"] += 1
        else:
            out["waiting"] += 1
            if len(out["examples"]) < 5:
                out["examples"].append(f"{c['id']}: {'; '.join(f['why'] for f in gates.check_picture(game, dict(gates.item_from_row(c), image=url), plain))[:120] or 'the picture does not load or is too small'}")
    if written and not dry_run:
        conn.executemany("UPDATE cards SET image_base=? WHERE id=?", written)
        for u, cid in written:
            provenance.record_image(conn, cid, u)
    return out


def _logo_ok(b):
    d = gates._dims(b or b"")
    return bool(d) and min(d) >= MIN_LOGO_SIDE


def _norm(s):
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower().replace("é", "e"))


def find_logo(reader, set_row):
    """-> (logo address, bytes, where from) from the set's own record, or (None, None, why not)."""
    rec = tcgdex_set(reader, set_row["id"])
    if rec.get("logo") and _norm(rec.get("name")) == _norm(set_row["name"]):
        b = reader.bytes(rec["logo"] + ".webp")
        if _logo_ok(b):
            return rec["logo"], b, "TCGdex set record"
    from urllib.parse import quote
    for s in (reader.json(PTCG.format(quote(set_row["name"] or ""))) or {}).get("data") or []:
        same_count = (s.get("total") and s.get("total") == set_row.get("total")) or (s.get("printedTotal") and s.get("printedTotal") == set_row.get("official"))
        url = (s.get("images") or {}).get("logo")
        if _norm(s.get("name")) == _norm(set_row["name"]) and same_count and url:
            b = reader.bytes(url)
            if _logo_ok(b):
                return url, b, "pokemontcg.io set record"
    return None, None, "no source lists this set's logo yet"


def fix_logo(conn, gdir, set_id, reader, dry_run=False):
    """-> {logo: 'had' | 'found' | 'none', from, url}.  TCGdex: sets.logo + images/logos/<id>.webp (as the other sets); pokemontcg.io: setart/<id>_logo.png + meta setimg_urls."""
    from .db import logo_file
    srow = dict(zip([d[0] for d in conn.execute("SELECT * FROM sets LIMIT 0").description], conn.execute("SELECT * FROM sets WHERE id=?", (set_id,)).fetchone()))
    have = [p for p in (logo_file(gdir, set_id), art_path(gdir, set_id, "logo")) if gdir and os.path.exists(p) and os.path.getsize(p) > 0]
    if have:
        return {"logo": "had", "from": have[0], "url": srow.get("logo") or ""}
    url, b, src = find_logo(reader, srow)
    if not url:
        return {"logo": "none", "from": src, "url": ""}
    if not dry_run:
        tdx = src.startswith("TCGdex")
        dest = logo_file(gdir, set_id) if tdx else art_path(gdir, set_id, "logo")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest + ".part", "wb") as f:
            f.write(b)
        os.replace(dest + ".part", dest)
        if tdx:
            conn.execute("UPDATE sets SET logo=? WHERE id=?", (url, set_id))
        else:
            old = conn.execute("SELECT value FROM meta WHERE key='setimg_urls'").fetchone()
            urls = json.loads(old[0]) if old and old[0] else {}
            urls[set_id] = url
            conn.execute("INSERT OR REPLACE INTO meta VALUES('setimg_urls', ?)", (json.dumps(urls),))
    return {"logo": "found", "from": src, "url": url}


def newest(conn, game, set_id):
    """Is the set the newest one people see first (sort by newest)?  Pokemon's special groups (Miscellaneous) sort by era, so they do not count (webapi/browse._is_special)."""
    q = "SELECT id FROM sets WHERE release_date IS NOT NULL AND release_date != ''" + (" AND COALESCE(serie,'') != 'Miscellaneous'" if game.startswith("pokemon") else "")
    top = conn.execute(q + " ORDER BY release_date DESC, name DESC LIMIT 1").fetchone()
    return bool(top) and top[0] == set_id


def fix_set(conn, game, set_id, reader, gdir=None, dry_run=False, fetch_image=True):
    """Pictures + logo + the release date (from the TCGplayer group when the set has none).  The caller commits.  -> the report"""
    if not conn.execute("SELECT 1 FROM sets WHERE id=?", (set_id,)).fetchone():
        raise ValueError(f"{game} has no set {set_id}")
    rep = fix_pictures(conn, game, set_id, reader, dry_run, fetch_image)
    rep.update(fix_logo(conn, gdir, set_id, reader, dry_run))
    pub = (rep.get("group") or {}).get("published")
    date = conn.execute("SELECT release_date FROM sets WHERE id=?", (set_id,)).fetchone()[0]
    if pub and not date and not dry_run:
        conn.execute("UPDATE sets SET release_date=? WHERE id=?", (pub, set_id))
    rep["date"] = date or pub or ""
    rep["date_agrees"] = (not pub) or (date or pub) == pub
    rep["newest"] = newest(conn, game, set_id)
    rep["notes"] = reader.notes[:5]
    return rep


# ------------------------------------------------------------------------------------------------ the sweep: every other auto-added set, read-only
def auto_sets(conn, game, since=AUTO_SINCE):
    """{set id: None (every card) or {card ids}} of what the daily update added by itself: the sets tcgsync.auto_add remembers, the cards merge_twins folded into a set (their TCGplayer twin
    was auto-added), and for a TCGplayer game every set dated from `since` on."""
    def meta(k):
        r = conn.execute("SELECT value FROM meta WHERE key=?", (k,)).fetchone()
        try:
            return json.loads(r[0]) if r and r[0] else {}
        except ValueError:
            return {}
    if game not in CATEGORIES:
        return {}                                                  # (only the TCGplayer games are auto-added by tcgsync; a toy list's redirects come from its own sheet merges)
    out = {str(s): None for s in meta("tcgsync_auto_sets")}
    for cid in set(meta("id_redirects").values()):
        r = conn.execute("SELECT set_id FROM cards WHERE id=?", (str(cid),)).fetchone()
        if r and out.get(r[0], set()) is not None:
            out.setdefault(r[0], set()).add(str(cid))
    if game in NATIVE:
        out.update({r[0]: None for r in conn.execute("SELECT id FROM sets WHERE release_date >= ?", (since,))})
    return out


def sweep_game(conn, game, skip=(), dry_run=False):
    """-> {set id: {name, checked, doubtful, none, listed}} for the auto-added sets of one game (conn may be read-only: only the review list is written)."""
    ctx = gates.Context(conn, game)
    cols = gates._cols(conn)
    kept = {k for kind in (gates.PICTURE, KIND) for k, v in ctx.said(kind).items() if v["answer"] == "yes"}          # (pictures the owner already said yes to)
    rep = {}
    for sid, only in sorted(auto_sets(conn, game).items()):
        if sid in skip:
            continue
        name = (conn.execute("SELECT name FROM sets WHERE id=?", (sid,)).fetchone() or [""])[0]
        r = rep[sid] = {"name": name, "checked": 0, "doubtful": 0, "none": 0, "listed": 0}
        for row in conn.execute("SELECT * FROM cards WHERE set_id=?", (sid,)).fetchall():
            c = dict(zip(cols, row))
            if only is not None and c["id"] not in only:
                continue
            r["checked"] += 1
            if not (c.get("image_base") or "").strip():
                r["none"] += 1
                continue
            fails = gates.check_picture(game, gates.item_from_row(c), ctx)
            if not fails or c["id"] in kept:
                continue
            r["doubtful"] += 1
            if not dry_run and reviewlist.add_item(KIND, game, c["id"], f"Is this the picture of {c['name']} #{c['local_id']} ({name or sid})? It is shown now but failed the picture check: "
                                                   f"{'; '.join(f['why'] for f in fails)[:300]}. Yes keeps it; No removes it (the card shows 'No picture yet').",
                                                   before={"picture": c["image_base"], "set": f"{name} ({sid})", "TCGplayer product": c.get("tcg_id")}, source=SWEEP_SOURCE):
                r["listed"] += 1
    return rep


def sweep(data_dir, games=None, skip=(), dry_run=False):
    """Every game's catalog under data_dir/games (read-only).  skip: {(game, set id)} already done.  -> {game: {set id: counts}}"""
    root = os.path.join(data_dir, "games")
    out = {}
    for game in sorted(games or os.listdir(root)):
        path = os.path.join(root, game, "cards.db")
        if not os.path.exists(path):
            continue
        conn = sqlite3.connect("file:" + os.path.abspath(path).replace("\\", "/") + "?mode=ro", uri=True, timeout=60)
        try:
            rep = sweep_game(conn, game, {s for g, s in skip if g == game}, dry_run)
        except sqlite3.OperationalError:
            rep = {}                                               # (a list without cards / meta tables: nothing auto-added)
        finally:
            conn.close()
        if rep:
            out[game] = rep
    return out


# ------------------------------------------------------------------------------------------------ the owner's answer to a 'picture_check' item
def _apply(item, ans, value, ctx):
    url = (item.get("before") or {}).get("picture")
    conn = sqlite3.connect(gates._db(item, ctx), timeout=60)
    try:
        if ans == "yes":
            if conn.execute("SELECT 1 FROM cards WHERE id=? AND image_base=?", (item["item_id"], url)).fetchone():
                provenance.record_image(conn, item["item_id"], url)
            conn.commit()
            return "picture kept"
        n = conn.execute("UPDATE cards SET image_base=NULL WHERE id=? AND image_base=?", (item["item_id"], url)).rowcount
        if n:
            try:
                conn.execute("DELETE FROM provenance WHERE card_id=? AND field='image'", (item["item_id"],))
            except sqlite3.OperationalError:
                pass
        conn.commit()
        return "picture removed: the card shows 'No picture yet'" if n else "the card no longer shows that picture"
    finally:
        conn.close()


reviewlist.register(KIND, apply=_apply)
