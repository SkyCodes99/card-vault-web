"""Custom checklists, master sets and progress.

A checklist has
  mode 'cards' - every card in the list is wanted (a classic master set / custom set list)
  mode 'dex'   - ONE qualifying card per Pokédex number is enough ("collect the Pokédex")
  per_variant  - in 'cards' mode each variant (normal / reverse holo / holo / 1st edition...) is wanted separately
and rules:  {"include": [clause, ...], "exclude": [clause, ...]}
A card is in the list when it matches ANY include clause and NO exclude clause; manual add/exclude overrides come on top.
A clause is a dict of conditions that must ALL hold (see CLAUSE_FIELDS).
"""
import json
import re
from collections import Counter

from . import taxonomy
from .db import VARIANT_FLAGS, VARIANT_LABELS

CLAUSE_FIELDS = {
    "editions": "belongs to the physical TCG or to TCG Pocket (tcg / pocket)",
    "all_cards": "every card (no other conditions)",
    "illustrators": "card was illustrated by one of these artists (exact names)",
    "pokemon": "card shows one of these Pokémon (Pokédex numbers)",
    "groups": "card belongs to one of these card groups (Art cards, Illustration Rare, Gallery, Alt Art, rarity groups...)",
    "sets": "card is in one of these sets (set ids)",
    "series": "set belongs to one of these series",
    "rarities": "rarity is exactly one of these",
    "rarity_contains": "rarity text contains one of these words",
    "local_id_prefix": "card number starts with one of these (e.g. TG, GG)",
    "categories": "category is one of these (Pokemon, Trainer, Energy)",
    "types": "has one of these energy types",
    "name_contains": "name contains this text",
    "illustrator_contains": "illustrator contains this text",
    "has_dex": "is a Pokémon with a Pokédex number",
    "dex_min": "Pokédex number at least",
    "dex_max": "Pokédex number at most",
    "beyond_official": "card number is higher than the printed set size (secret / alt-art numbering)",
    "min_price": "market price at least (USD)",
}

# Starting points the user can edit.  "Art" cards are defined in taxonomy.py.
PRESETS = {
    "One of every rarity (each set)": {
        "mode": "rarity", "per_variant": False,
        "rules": {"include": [{"all_cards": True}], "exclude": []},
    },
    "Art cards (Pokédex)": {
        "mode": "dex", "per_variant": False,
        "rules": {"include": [{"groups": ["art"], "has_dex": True}], "exclude": []},
    },
    "Every Art card": {
        "mode": "cards", "per_variant": False,
        "rules": {"include": [{"groups": ["art"]}], "exclude": []},
    },
    "Illustration Rares + Special Illustration Rares": {
        "mode": "cards", "per_variant": False,
        "rules": {"include": [{"groups": ["ir", "sir"]}], "exclude": []},
    },
    "Gallery cards (Trainer + Galarian)": {
        "mode": "cards", "per_variant": False,
        "rules": {"include": [{"groups": ["gallery"]}], "exclude": []},
    },
    "Alt Arts (full illustration)": {
        "mode": "cards", "per_variant": False,
        "rules": {"include": [{"groups": ["art_alt"]}], "exclude": []},
    },
    "Full Pokédex (any card)": {
        "mode": "dex", "per_variant": False,
        "rules": {"include": [{"has_dex": True}], "exclude": []},
    },
}


def _load_rules(cl):
    try:
        r = json.loads(cl["rules"] or "{}")
    except (ValueError, TypeError):
        r = {}
    r.setdefault("include", [])
    r.setdefault("exclude", [])
    return r


def _dex_list(c):
    return [int(x) for x in (c.get("dex") or "").split(",") if x.strip().isdigit()]


def clause_matches(c, cl):
    if not cl:
        return False
    if cl.get("all_cards"):
        return True
    if cl.get("groups") and not (set(cl["groups"]) & c.get("groups", frozenset())):
        return False
    if cl.get("sets") and c["set_id"] not in cl["sets"]:
        return False
    if cl.get("editions") and c.get("edition", "tcg") not in cl["editions"]:
        return False
    if cl.get("illustrators") and (c.get("illustrator") or "") not in cl["illustrators"]:
        return False
    if cl.get("pokemon") and not (set(cl["pokemon"]) & set(_dex_list(c))):
        return False
    if cl.get("series") and c.get("serie") not in cl["series"]:
        return False
    rar = (c.get("rarity") or "")
    if cl.get("rarities") and rar not in cl["rarities"]:
        return False
    if cl.get("rarity_contains") and not any(w.lower() in rar.lower() for w in cl["rarity_contains"]):
        return False
    if cl.get("local_id_prefix") and not any(str(c["local_id"]).upper().startswith(p.upper()) for p in cl["local_id_prefix"]):
        return False
    if cl.get("categories") and (c.get("category") or "") not in cl["categories"]:
        return False
    if cl.get("types"):
        have = {t.strip() for t in (c.get("types") or "").split(",")}
        if not have & set(cl["types"]):
            return False
    if cl.get("name_contains") and cl["name_contains"].lower() not in (c.get("name") or "").lower():
        return False
    if cl.get("illustrator_contains") and cl["illustrator_contains"].lower() not in (c.get("illustrator") or "").lower():
        return False
    dex = _dex_list(c)
    if cl.get("has_dex") and not dex:
        return False
    if cl.get("dex_min") is not None and not any(d >= cl["dex_min"] for d in dex):
        return False
    if cl.get("dex_max") is not None and not any(d <= cl["dex_max"] for d in dex):
        return False
    if cl.get("beyond_official"):
        m = re.fullmatch(r"\d+", str(c["local_id"]))
        if not m or not c.get("official") or int(c["local_id"]) <= c["official"]:
            return False
    if cl.get("min_price") is not None and (c.get("price_usd") or 0) < cl["min_price"]:
        return False
    return True


def members(vault, cl):
    """Ordered card ids that belong to checklist row `cl`."""
    if cl is None:
        return []
    key = (cl["id"], vault._cl_rev)
    hit = vault._members_cache.get(cl["id"])
    if hit and hit[0] == key:
        return list(hit[1])
    rules = _load_rules(cl)
    manual = vault.checklist_manual(cl["id"])
    out = []
    for c in vault.card_index():
        cid = c["id"]
        if cid in manual["excluded"]:
            continue
        if cid in manual["manual"]:
            out.append(cid)
            continue
        if any(clause_matches(c, cl_) for cl_ in rules["include"]) and not any(clause_matches(c, ex) for ex in rules["exclude"]):
            out.append(cid)
    vault._members_cache[cl["id"]] = (key, out)
    return list(out)


_SUFFIX = re.compile(r"\s+(ex|EX|GX|V|VMAX|VSTAR|V-UNION|BREAK|LV\.X|Lv\.X|Prime|PRIME|LEGEND|δ|☆|Star|\*)$")
_PREFIX = re.compile(r"^(Mega|M|Radiant|Dark|Light|Shining|Team Rocket's|Rocket's|Alolan|Galarian|Hisuian|Paldean|Origin|Primal)\s+")


def clean_pokemon_name(name):
    n = name or ""
    for _ in range(3):
        n2 = _SUFFIX.sub("", n)
        if n2 == n:
            break
        n = n2
    n = re.sub(r"\s+(ex|EX|GX|V|VMAX|VSTAR)\b.*$", "", n)
    n = re.sub(r"^.+?'s\s+", "", n) if re.match(r"^[A-Z][a-z]+'s\s+", n) else n
    n = _PREFIX.sub("", n)
    return n.strip() or (name or "")


def dex_names(vault):
    """{dex number: best-guess Pokémon name} from the card names that share the number."""
    votes = {}
    for c in vault.card_index():
        dl = _dex_list(c)
        if len(dl) == 1:
            votes.setdefault(dl[0], Counter())[clean_pokemon_name(c["name"])] += 1
    return {d: cnt.most_common(1)[0][0] for d, cnt in votes.items()}


class Tile:
    """One row of a progress view."""
    __slots__ = ("card_id", "variant", "owned", "qty", "label", "dex", "candidates", "owned_cards", "key")

    def __init__(self, card_id, variant=None, owned=False, qty=0, label="", dex=None, candidates=None, owned_cards=None, key=None):
        self.key = key
        self.card_id, self.variant, self.owned, self.qty = card_id, variant, owned, qty
        self.label, self.dex = label, dex
        self.candidates = candidates or []
        self.owned_cards = owned_cards or []


class Progress:
    def __init__(self, tiles, name=""):
        self.tiles = tiles
        self.name = name
        self.total = len(tiles)
        self.owned = sum(1 for t in tiles if t.owned)
        self.pct = (100.0 * self.owned / self.total) if self.total else 0.0

    def view(self, which):
        if which == "owned":
            return [t for t in self.tiles if t.owned]
        if which == "missing":
            return [t for t in self.tiles if not t.owned]
        return list(self.tiles)


def card_variants(c):
    try:
        flags = json.loads(c.get("variants") or "{}")
    except ValueError:
        flags = {}
    names = [VARIANT_LABELS[k] for k in VARIANT_FLAGS if flags.get(k)]
    return names or ["Normal"]


def _variant_owned(owned_variants, cid, variant):
    have = owned_variants.get(cid, set())
    if variant in have:
        return True
    # a lot saved as "Other" or with an unknown label still counts when the card has a single variant
    return False


DEX_MAX = 1025


def progress_for_cards(vault, card_ids, mode="cards", per_variant=False, name="", dex_all=False, picks=None):
    owned_map = vault.owned_map()
    ids = list(card_ids)
    if mode == "dex":
        names = dex_names(vault)
        groups = {}
        for cid in ids:
            c = vault.card_light(cid)
            for d in _dex_list(c):
                groups.setdefault(d, []).append(cid)
        tiles = []
        numbers = range(1, DEX_MAX + 1) if dex_all else sorted(groups)
        for d in numbers:
            if d not in groups:
                tiles.append(Tile(None, None, False, 0, f"#{d:04d} {names.get(d, 'Unknown')}", d, [], [], f"dex:{d}"))
                continue
            cands = groups[d]
            have = [cid for cid in cands if owned_map.get(cid, 0) > 0]
            pick = (picks or {}).get(f"dex:{d}")
            rep = pick if pick in cands else (have[0] if have else cands[0])
            tiles.append(Tile(rep, None, bool(have), sum(owned_map.get(c, 0) for c in have),
                              f"#{d:04d} {names.get(d, '?')}", d, cands, have, f"dex:{d}"))
        return Progress(tiles, name)
    if mode == "rarity":
        by_set, order = {}, []
        for cid in ids:
            c = vault.card_light(cid)
            if c is None:
                continue
            if c["set_id"] not in by_set:
                by_set[c["set_id"]] = {}
                order.append(c["set_id"])
            by_set[c["set_id"]].setdefault(c.get("rarity") or "Unlabelled", []).append(cid)
        multi = len(order) > 1
        tiles = []
        for sid in order:
            for rar in sorted(by_set[sid], key=lambda r: (taxonomy.rarity_rank(r), r)):
                cands = by_set[sid][rar]
                have = [x for x in cands if owned_map.get(x, 0) > 0]
                pick = (picks or {}).get(f"rar:{sid}|{rar}")
                rep = pick if pick in cands else (have[0] if have else cands[0])
                sname = vault.card_light(cands[0])["set_name"]
                tiles.append(Tile(rep, None, bool(have), sum(owned_map.get(x, 0) for x in have), f"{sname} · {rar}" if multi else rar, None, cands, have, f"rar:{sid}|{rar}"))
        return Progress(tiles, name)
    tiles = []
    if per_variant:
        ov = vault.owned_variants()
        for cid in ids:
            c = vault.card_light(cid)
            for v in card_variants(c):
                owned = _variant_owned(ov, cid, v)
                tiles.append(Tile(cid, v, owned, owned_map.get(cid, 0) if owned else 0, f"{c['name']} ({v})"))
    else:
        for cid in ids:
            c = vault.card_light(cid)
            q = owned_map.get(cid, 0)
            tiles.append(Tile(cid, None, q > 0, q, c["name"] if c else cid))
    return Progress(tiles, name)


def progress_for_checklist(vault, cl):
    return progress_for_cards(vault, members(vault, cl), cl["mode"], bool(cl["per_variant"]), cl["name"], bool(_load_rules(cl).get("dex_all")),
                              vault.picks(cl["id"]) if cl["mode"] in ("dex", "rarity") else None)


def progress_for_set(vault, set_id, per_variant=False, mode="cards"):
    left = vault.excluded_cards(set_id)
    ids = [c["id"] for c in vault.card_index() if c["set_id"] == set_id and c["id"] not in left]
    return progress_for_cards(vault, ids, mode, per_variant)


def all_set_progress(vault, per_variant=False):
    """[(set_row, owned, total, pct)] for every set, newest first - one pass over the data."""
    owned_map = vault.owned_map()
    ov = vault.owned_variants() if per_variant else None
    totals, owned = {}, {}
    left = vault.excluded_cards()
    for c in vault.card_index():
        sid = c["set_id"]
        if c["id"] in left.get(sid, ()):
            continue                                     # left out of this set by the person
        if per_variant:
            for v in card_variants(c):
                totals[sid] = totals.get(sid, 0) + 1
                if v in ov.get(c["id"], set()):
                    owned[sid] = owned.get(sid, 0) + 1
        else:
            totals[sid] = totals.get(sid, 0) + 1
            if owned_map.get(c["id"], 0) > 0:
                owned[sid] = owned.get(sid, 0) + 1
    out = []
    for s in vault.sets():
        t = totals.get(s["id"], 0)
        o = owned.get(s["id"], 0)
        out.append((s, o, t, (100.0 * o / t) if t else 0.0))
    return out


# ------------------------------------------------------------------ rows for exports
def missing_rows(vault, progress):
    """Flat rows describing everything still missing - used by the .txt/.xlsx exports and share pages."""
    rows = []
    for t in progress.view("missing"):
        if t.key and not t.candidates:
            rows.append({"card_id": None, "set_id": "", "set": "", "number": "", "official": None, "name": t.label, "rarity": "No Card Exists",
                         "types": "", "illustrator": "", "variant": "", "price_usd": None, "dex": t.dex, "group": t.key, "dex_label": t.label, "release": ""})
            continue
        cands = t.candidates or [t.card_id]
        for cid in cands:
            c = vault.card_light(cid)
            if not c:
                continue
            rows.append({
                "card_id": cid, "set_id": c["set_id"], "set": c["set_name"], "number": c["local_id"],
                "official": c.get("official"), "name": c["name"], "rarity": c.get("rarity") or "",
                "types": c.get("types") or "", "illustrator": c.get("illustrator") or "", "variant": t.variant or "",
                "price_usd": c.get("price_usd"), "dex": t.dex, "group": t.key, "dex_label": t.label if t.candidates else "",
                "release": c.get("release_date") or "",
            })
    return rows


def match_ids(vault, rules):
    """Card ids matching a rules dict (no manual overrides) - used for the live preview in the editor."""
    inc, exc = rules.get("include", []), rules.get("exclude", [])
    return [c["id"] for c in vault.card_index()
            if any(clause_matches(c, x) for x in inc) and not any(clause_matches(c, x) for x in exc)]


def presets_for(game):
    """Names of the starting points that make sense for a game (Pokédex / Art presets are Pokémon-only)."""
    return [k for k, p in PRESETS.items() if game.pokemon or p["mode"] == "rarity"]


for _p in PRESETS.values():                     # presets collect the physical card game; TCG Pocket has its own spot
    for _cl in _p["rules"]["include"]:
        _cl.setdefault("editions", ["tcg"])
