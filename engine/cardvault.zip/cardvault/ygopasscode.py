"""Yu-Gi-Oh! card passcodes (the 8-digit number printed on a card; what a .ydk deck file lists), read from YGOPRODeck's card list with the daily update (freeprices_ygo.run) into a small table of
the game's cards.db:  ygo_passcodes(passcode, name_key, name, main)   main = 1 for the card's own passcode, 0 for an alternate-art passcode of the same card.
The deck builder turns a passcode into a card by its name key (deckcards.play_key), and a card into its passcode the same way - nothing is fetched when a deck is opened or pasted."""
import sqlite3

from . import deckcards

SCHEMA = ("CREATE TABLE IF NOT EXISTS ygo_passcodes(passcode TEXT PRIMARY KEY, name_key TEXT NOT NULL, name TEXT, main INTEGER NOT NULL DEFAULT 1) WITHOUT ROWID",
          "CREATE INDEX IF NOT EXISTS ygo_passcodes_name ON ygo_passcodes(name_key, main)")
MIN_ROWS = 1000                                  # a real list has ten thousand cards; fewer means a bad download and the old rows stay


def ensure(conn):
    for s in SCHEMA:
        conn.execute(s)


def rows_of(cards):
    """cardinfo 'data' list -> [(passcode, name_key, name, main)]."""
    out = {}
    for c in cards or ():
        name = (c.get("name") or "").strip()
        if not name:
            continue
        key = deckcards.play_key("yugioh", name, "")
        ids = [(str(c["id"]), 1)] if c.get("id") else []
        ids += [(str(i["id"]), 0) for i in c.get("card_images") or () if i.get("id")]
        for pc, main in ids:
            out.setdefault(pc, (pc, key, name, main))
    return list(out.values())


def write(conn, cards, min_rows=None):
    """-> {rows, written}.  The old rows are replaced only when the new list is a real one."""
    ensure(conn)
    rows = rows_of(cards)
    if len(rows) < (MIN_ROWS if min_rows is None else min_rows):
        return {"rows": len(rows), "written": False}
    with conn:
        conn.execute("DELETE FROM ygo_passcodes")
        conn.executemany("INSERT OR REPLACE INTO ygo_passcodes(passcode, name_key, name, main) VALUES(?,?,?,?)", rows)
    return {"rows": len(rows), "written": True}


def for_keys(conn, keys):
    """{name_key: passcode} for these card name keys (the card's own passcode)."""
    keys = list(keys)
    out = {}
    try:
        for i in range(0, len(keys), 400):
            part = keys[i:i + 400]
            for k, pc in conn.execute(f"SELECT name_key, passcode FROM ygo_passcodes WHERE main=1 AND name_key IN ({','.join('?' * len(part))})", part):
                out[k] = pc
    except sqlite3.Error:
        return {}
    return out


def keys_for(conn, passcodes):
    """{passcode: (name_key, name)}; a passcode with no entry is left out."""
    codes = [str(p) for p in passcodes]
    out = {}
    try:
        for i in range(0, len(codes), 400):
            part = codes[i:i + 400]
            for pc, k, nm in conn.execute(f"SELECT passcode, name_key, name FROM ygo_passcodes WHERE passcode IN ({','.join('?' * len(part))})", part):
                out[pc] = (k, nm)
    except sqlite3.Error:
        return {}
    return out
