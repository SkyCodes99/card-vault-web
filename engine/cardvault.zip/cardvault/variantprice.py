"""The price of ONE printing of a card (Normal, Holo, Reverse Holo, 1st Edition ...).

TCGplayer lists a card once, with a separate price for every printing it comes in.  The card list keeps one headline price per card (cards.price_usd); the daily price
update also stores every printing's price in cards.variant_prices as {"Holofoil": 57.96, "1st Edition Holofoil": 187.08, ...} (market price), and this module picks the
right one for the printing a tile or checklist row is about.  When a printing has no price of its own the headline price is used and the row says so."""
import json

# the app's printing names -> the printing names TCGplayer uses, best match first
WANT = {
    "Normal": ("Normal", "Unlimited", "Unlimited Normal"),
    "Holo": ("Holofoil", "Unlimited Holofoil"),
    "Reverse Holo": ("Reverse Holofoil",),
    "W Promo": ("Normal",),
}
FIRST = ("1st Edition", "1st Edition Normal", "1st Edition Holofoil")


def prices_of(card):
    raw = card.get("variant_prices") if hasattr(card, "get") else None
    if not raw:
        return {}
    try:
        d = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        return {}
    return d if isinstance(d, dict) else {}


def _flags(card):
    try:
        return json.loads(card.get("variants") or "{}")
    except ValueError:
        return {}


def price_for(card, variant):
    """-> (usd or None, exact).  exact is False when the printing has no price of its own and the card's headline price stands in."""
    vp = prices_of(card)
    names = ()
    if variant == "1st Edition":
        f = _flags(card)
        # a holo-only 1st Edition card (the rare holo of Jungle, Fossil...) is TCGplayer's '1st Edition Holofoil'; a plain one is '1st Edition'
        names = ("1st Edition Holofoil", "1st Edition", "1st Edition Normal") if (f.get("holo") and not f.get("normal")) else ("1st Edition", "1st Edition Normal", "1st Edition Holofoil")
    else:
        names = WANT.get(variant or "Normal", ())
    for n in names:
        v = vp.get(n)
        if isinstance(v, (int, float)) and v > 0:
            return float(v), True
    if variant == "Holo" and not vp.get("Holofoil"):
        pass
    return card.get("price_usd"), False
