"""Tells whether a card's artwork runs to the edges of the card (a "full illustration").

Normal cards have a plain, uniform border all the way round, so the pixels along the four edges barely vary.  When the artwork
covers the whole card the edge pixels vary a lot.  edge_score() is the average per-channel standard deviation along the outer
3.5% strip of the picture: ordinary cards score about 10, full illustrations 45-80.  Only cards that could be Alt Arts
(Pokémon with secret numbering) are scored.  Nothing here uses the internet.
"""
import os

from .db import image_file, open_cards_conn


def edge_score(path):
    from PIL import Image, ImageStat
    with Image.open(path) as im:
        im = im.convert("RGB")
        w, h = im.size
        b = max(3, int(w * 0.035))
        strips = [im.crop((0, 0, w, b)), im.crop((0, h - b, w, h)), im.crop((0, 0, b, h)), im.crop((w - b, 0, w, h))]
        return sum(sum(ImageStat.Stat(s).stddev) / 3 for s in strips) / 4


_CANDIDATE_RARITIES = ("Secret Rare", "Ultra Rare", "Holo Rare V", "Holo Rare VMAX", "Holo Rare VSTAR", "Hyper rare", "Double rare",
                       "Illustration rare", "Special illustration rare")


def pending(gdir, extra_ids=()):
    """Cards that could be Alt Arts (secret-numbered Pokémon, or any Pokémon with a V / ultra / secret style rarity) plus any
    card the user has labelled, that have a picture but no score yet."""
    conn = open_cards_conn(gdir)
    try:
        marks = ",".join("?" * len(_CANDIDATE_RARITIES))
        rows = conn.execute(
            "SELECT c.id, c.set_id FROM cards c JOIN sets s ON s.id=c.set_id "
            "WHERE c.art_score IS NULL AND c.detailed=1 AND c.category='Pokemon' AND ("
            "(c.local_id GLOB '[0-9]*' AND CAST(c.local_id AS INTEGER) > COALESCE(s.official, 0) AND COALESCE(s.official, 0) > 0) "
            f"OR c.rarity IN ({marks}))", _CANDIDATE_RARITIES).fetchall()
        if extra_ids:
            have = {r[0] for r in rows}
            for cid in extra_ids:
                r = conn.execute("SELECT id, set_id FROM cards WHERE id=? AND art_score IS NULL AND detailed=1", (cid,)).fetchone()
                if r and r[0] not in have:
                    rows.append((r[0], r[1]))
    finally:
        conn.close()
    out = []
    for cid, sid in rows:
        for q in ("high", "low"):
            p = image_file(gdir, q, cid, sid)
            if os.path.exists(p):
                out.append((cid, p))
                break
    return out


def compute_missing(gdir, cancel=None, progress=None, extra_ids=()):
    """Score every candidate card that has a picture and no score yet.  Returns how many were scored."""
    todo = pending(gdir, extra_ids)
    if not todo:
        return 0
    conn = open_cards_conn(gdir)
    n = 0
    try:
        for i, (cid, path) in enumerate(todo, 1):
            if cancel is not None and cancel.is_set():
                break
            try:
                conn.execute("UPDATE cards SET art_score=? WHERE id=?", (round(edge_score(path), 2), cid))
                n += 1
            except Exception:  # noqa: BLE001 - a damaged picture just stays unscored
                continue
            if progress and i % 50 == 0:
                progress("Checking artwork...", i, len(todo))
        conn.commit()
    finally:
        conn.close()
    return n
