"""Keep Python's garbage collector off the big long-lived card index (click-speed pass, 2026-11-13).
A worked-out card index is ~900,000 small objects (Magic).  Python 3.14's collector looks through everything reachable from what it checks, so one of its rounds could stop a click for
0.25-0.3 s (and a full round 0.75 s) - at random, whichever question happened to be running.  settle() moves everything alive now out of the collector's way (gc.freeze); release() hands it
back (gc.unfreeze) before anything that counts on the collector to let go of an old connection, and when a game is closed."""
import gc


def settle():
    """After a big build (the card index, Find & Add's sort orders): what is alive now is kept, not looked through again by every collection."""
    gc.collect(0)                                   # (the newest garbage first: cheap, and it is not kept frozen)
    gc.freeze()


def release():
    """Everything frozen goes back to the collector (a connection kept alive by an old traceback can then be freed, and a closed game's index)."""
    gc.unfreeze()
