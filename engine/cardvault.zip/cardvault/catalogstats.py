"""Catalog stats (roadmap 1.9): per game, how many items (cards + sealed) and how many have no picture, no price or no source record.
Only COUNT queries on each game's cards.db (read-only), cached in memory; refresh=True recounts.  'changed' = the newest of the file's saved date and the newest provenance day."""
import datetime
import os
import sqlite3
import threading

_cache = {}
_lock = threading.Lock()


def _one(c, sql):
    try:
        return c.execute(sql).fetchone()[0] or 0
    except sqlite3.Error:
        return 0


def _count_game(path):
    row = {"cards": 0, "sealed": 0, "items": 0, "noPicture": 0, "noPrice": 0, "noSource": 0, "changed": ""}
    if not os.path.exists(path):
        return row
    c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
    try:
        row["cards"] = _one(c, "SELECT COUNT(*) FROM cards")
        row["sealed"] = _one(c, "SELECT COUNT(*) FROM sealed_products")
        row["noPicture"] = _one(c, "SELECT COUNT(*) FROM cards WHERE image_base IS NULL OR image_base=''") + _one(c, "SELECT COUNT(*) FROM sealed_products WHERE image_base IS NULL OR image_base=''")
        row["noPrice"] = _one(c, "SELECT COUNT(*) FROM cards WHERE price_usd IS NULL") + _one(c, "SELECT COUNT(*) FROM sealed_products WHERE price_usd IS NULL")
        row["noSource"] = _one(c, "SELECT COUNT(*) FROM cards k WHERE NOT EXISTS(SELECT 1 FROM provenance p WHERE p.card_id=k.id)")
        if _one(c, "SELECT COUNT(*) FROM sqlite_master WHERE name='provenance'") == 0:
            row["noSource"] = row["cards"]                                   # no records at all yet
        day = c.execute("SELECT MAX(day) FROM provenance").fetchone()[0] if row["cards"] and _one(c, "SELECT COUNT(*) FROM sqlite_master WHERE name='provenance'") else ""
    except sqlite3.Error:
        day = ""
    finally:
        c.close()
    row["items"] = row["cards"] + row["sealed"]
    saved = datetime.date.fromtimestamp(os.path.getmtime(path)).isoformat()
    row["changed"] = max(saved, day or "")
    return row


def stats(data_dir, refresh=False):
    from . import games
    from .db import game_dir
    with _lock:
        hit = _cache.get(data_dir)
        if hit and not refresh:
            return hit
    out = []
    for g in games.GAMES:
        if not g.available:
            continue
        try:
            r = _count_game(os.path.join(game_dir(data_dir, g.id), "cards.db"))
        except sqlite3.Error:
            r = {"cards": 0, "sealed": 0, "items": 0, "noPicture": 0, "noPrice": 0, "noSource": 0, "changed": ""}
        r.update(id=g.id, name=g.name)
        out.append(r)
    tot = {k: sum(r[k] for r in out) for k in ("cards", "sealed", "items", "noPicture", "noPrice", "noSource")}
    res = {"games": out, "total": tot, "gameCount": len(out), "counted": datetime.datetime.now().isoformat(timespec="seconds"), "changed": max([r["changed"] for r in out] or [""])}
    with _lock:
        _cache[data_dir] = res
    return res
