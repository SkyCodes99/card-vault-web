"""Catalog stats (roadmap 1.9): per game, how many items (cards + sealed) and how many have no picture, no price, no source record or no release date.
Only COUNT queries on each game's cards.db (read-only), cached in memory; refresh=True recounts.  'changed' = the newest of the file's saved date and the newest provenance day.
The daily update (save=True) saves each night's counts as that day's row in <data>/catalog_stats.json (the last HISTORY_DAYS days are kept); the panel only reads it, so each game shows its trend: the change in
items since the last earlier day on file ('trend', None when there is none)."""
import datetime
import json
import os
import sqlite3
import threading

_cache = {}
_lock = threading.Lock()
FIELDS = ("cards", "sealed", "items", "noPicture", "noPrice", "noSource", "noDate")
HISTORY = "catalog_stats.json"
HISTORY_DAYS = 90


def _one(c, sql):
    try:
        return c.execute(sql).fetchone()[0] or 0
    except sqlite3.Error:
        return 0


def _count_game(path):
    row = dict.fromkeys(FIELDS, 0) | {"changed": ""}
    if not os.path.exists(path):
        return row
    c = sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True, timeout=5)
    try:
        row["cards"] = _one(c, "SELECT COUNT(*) FROM cards")
        row["sealed"] = _one(c, "SELECT COUNT(*) FROM sealed_products")
        row["noPicture"] = _one(c, "SELECT COUNT(*) FROM cards WHERE image_base IS NULL OR image_base=''") + _one(c, "SELECT COUNT(*) FROM sealed_products WHERE image_base IS NULL OR image_base=''")
        row["noPrice"] = _one(c, "SELECT COUNT(*) FROM cards WHERE price_usd IS NULL") + _one(c, "SELECT COUNT(*) FROM sealed_products WHERE price_usd IS NULL")
        row["noSource"] = _one(c, "SELECT COUNT(*) FROM cards k WHERE NOT EXISTS(SELECT 1 FROM provenance p WHERE p.card_id=k.id)")
        row["noDate"] = (_one(c, "SELECT COUNT(*) FROM cards k LEFT JOIN sets s ON s.id=k.set_id WHERE COALESCE(s.release_date,'') NOT GLOB '[1-9][0-9][0-9][0-9]*'")      # (a card shows its set's day)
                         + _one(c, "SELECT COUNT(*) FROM sealed_products WHERE COALESCE(released,'') NOT GLOB '[1-9][0-9][0-9][0-9]*'"))
        if _one(c, "SELECT COUNT(*) FROM sqlite_master WHERE name='provenance'") == 0:
            row["noSource"] = row["cards"]                                   # no records at all yet
        day = c.execute("SELECT MAX(day) FROM provenance").fetchone()[0] if row["cards"] and _one(c, "SELECT COUNT(*) FROM sqlite_master WHERE name='provenance'") else ""
    except sqlite3.Error:
        day = ""
    finally:
        c.close()
    row["items"] = row["cards"] + row["sealed"]
    saved = datetime.date.fromtimestamp(os.path.getmtime(path)).isoformat()
    row["changed"] = max(saved, day or "")
    return row


def stats(data_dir, refresh=False, save=False):
    from . import games
    from .db import game_dir
    with _lock:
        hit = _cache.get(data_dir)
        if hit and not refresh:
            return hit
    out = []
    for g in games.GAMES:
        if not g.available:
            continue
        try:
            r = _count_game(os.path.join(game_dir(data_dir, g.id), "cards.db"))
        except sqlite3.Error:
            r = dict.fromkeys(FIELDS, 0) | {"changed": ""}
        r.update(id=g.id, name=g.name)
        out.append(r)
    tot = {k: sum(r[k] for r in out) for k in FIELDS}
    res = {"games": out, "total": tot, "gameCount": len(out), "counted": datetime.datetime.now().isoformat(timespec="seconds"), "changed": max([r["changed"] for r in out] or [""])}
    days = _save_day(data_dir, res, save)
    res["history"] = [{"day": d["day"], **{k: (d.get("total") or {}).get(k, 0) for k in FIELDS}} for d in days]      # (the totals per day: the panel draws the trend)
    prev = days[-2]["games"] if len(days) > 1 else {}
    for r in out:
        r["trend"] = r["items"] - prev[r["id"]].get("items", 0) if isinstance(prev.get(r["id"]), dict) else None
    with _lock:
        _cache[data_dir] = res
    return res


def _save_day(data_dir, res, write=True):
    """Today's counts merged into the history (today's row is replaced, the oldest past HISTORY_DAYS dropped); write=False: only in memory (a UI request never writes the data folder).  -> the rows, oldest first: [{day, total, games: {id: {field: n}}}]."""
    path = os.path.join(data_dir, HISTORY)
    try:
        with open(path, encoding="utf-8") as f:
            days = [d for d in json.load(f).get("days", []) if isinstance(d, dict) and d.get("day")]
    except (OSError, ValueError, AttributeError):
        days = []
    today = res["counted"][:10]
    row = {"day": today, "total": res["total"], "games": {r["id"]: {k: r[k] for k in FIELDS} for r in res["games"]}}
    days = sorted([d for d in days if d["day"] != today] + [row], key=lambda d: d["day"])[-HISTORY_DAYS:]
    if not write:
        return days
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"days": days}, f)
        os.replace(tmp, path)
    except OSError:
        pass                                                     # (a read-only folder: the counts are still shown)
    return days
