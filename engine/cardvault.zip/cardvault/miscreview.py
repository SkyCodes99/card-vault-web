"""The owner's side of Misc listings: what players asked to list under Misc waits on the ONE review list (reviewlist.py, kind "misc_listing") until the owner says yes or no.

The listings live on the account server (nothing is public until approved there); the owner's computer pulls the pending ones (GET /v1/misc/pending, owner account only), puts each on the review list,
and the owner's answer is sent back (POST /v1/misc/listings/<id>/review).  Answering "yes" publishes it; "no" rejects it (the player sees "not approved").  Never raises into the screen."""
import time

from . import reviewlist

KIND = "misc_listing"
EVERY = 60                                           # seconds between looks at the server while the review list is open
_last = {"at": 0.0}


def pull(svc, force=False):
    """Add every pending listing to the review list (add_item never lists one twice).  -> how many are on it."""
    if not force and time.time() - _last["at"] < EVERY:
        return 0
    _last["at"] = time.time()
    try:
        from .webapi import miscshare
        if not miscshare.available(svc):
            return 0
        rows = miscshare._call(svc, "GET", "/v1/misc/pending").get("listings") or []
    except Exception:  # noqa: BLE001 - not the owner, offline, an older server: the review list simply has nothing new
        return 0
    n = 0
    for x in rows:
        lid = str(x.get("id") or "")
        if not lid:
            continue
        before = {k: x.get(k) for k in ("id", "username", "name", "set_name", "series", "number", "category", "labels", "thumb", "pictures_n")}
        q = f"{x.get('username') or 'A player'} wants to list \"{x.get('name')}\" under Misc for everyone ({x.get('pictures_n') or 0} picture(s)). Show it?"
        if reviewlist.add_item(KIND, "misc", lid, q, before=before, source="player listing"):
            n += 1
    return n


def _apply(item, ans, value, ctx):
    """yes -> approve (public), no -> reject.  Needs the owner's signed-in account (ctx['svc'])."""
    svc = (ctx or {}).get("svc")
    if svc is None:
        raise reviewlist.ReviewError("Open this in the app, signed in to the owner account.")
    from .webapi import miscshare
    from .webapi.registry import ApiError
    try:
        miscshare._call(svc, "POST", f"/v1/misc/listings/{item['item_id']}/review", {"decision": "approve" if ans == "yes" else "reject"})
    except ApiError as e:
        raise reviewlist.ReviewError(str(e))
    return "listed for everyone" if ans == "yes" else "not approved"


reviewlist.register(KIND, apply=_apply)
