"""The owner's standing rule (roadmap 1.6 + 1.7, 2026-11-09): "true photo, exact facts, right place".  Anything code adds to a catalog passes three gates before it is published:

  picture    confirmed to be that exact item: it comes from the item's OWN product record (its TCGplayer product picture, its TCGdex card picture), is not a known placeholder (logo, set symbol,
             "no image", sample, card back), is not the picture of another item (same link or same bytes), and - when the bytes are fetched - has real dimensions.  A link alone is no proof.
  facts      name, number, set and date are there and agree with each other and with every source the item carries (TCGdex record, TCGplayer record, the number in a TCGplayer name).
  placement  a known game, a set that exists and has a series, a number that fits the set's range, and the game's kind rules (a card is not a sealed product).

check_item(game, item, conn) -> the failures ([] = passes).  Every add path calls ONE of these instead of copying the checks:
  screen_new(game, conn, ids, ...)        cards just written: a card that fails FACTS or PLACEMENT is taken back out and waits on the owner's review list (kind 'gate_card'); yes puts it back as it was.
                                          A card whose ONLY failures are PICTURE failures is NOT held (owner's decision, quiz 3, 2026-11-10: "add them now with a 'No picture yet' tile; the picture
                                          fills in later"): with no picture it simply goes live (the app shows "No picture yet"); with a doubtful picture (stand-in, another item's, wrong product, bad
                                          dimensions) the card goes live with the picture cleared and the picture waits on the review list (kind 'gate_picture'), exactly like screen_picture; a yes writes it.
  screen_picture(game, conn, id, url)     a picture about to be written: True = write it; False = it waits on the review list (kind 'gate_picture', before / after) and the card keeps what it had
check_picture() itself stays strict (audit_gates and screen_picture use it as is).  Held cards are kept whole in review_list.db (table gate_held), never in the published cards.db."""
import datetime
import hashlib
import json
import re
import sqlite3
import struct

from . import provenance, reviewlist

CARD, PICTURE = "gate_card", "gate_picture"
GATES = ("picture", "facts", "placement")
PLACEHOLDER = re.compile(r"placeholder|no[-_]?image|image[-_]?not|not[-_]?available|coming[-_]?soon|sample|card[-_]?back|default[-_]?(image|card)|/logo(\.\w+)?$|/symbol(\.\w+)?$", re.I)
PLACEHOLDER_SHA1 = frozenset()                     # the bytes of pictures known to be stand-ins (add a hash here when one is found)
MIN_SIDE = 100                                     # a real card picture is at least this many pixels on each side
_TCGP = re.compile(r"/product/(\d+)_")
_NAME_NUM = re.compile(r"\s-\s(\d{1,3})(?:/\d+)?(?:\s|$|\()")      # TCGplayer's "Charcadet - 022 (Pokemon Center Exclusive)"
_CARD_COLS = None
# Hand-checked lists that ship with the app (cardvault/worldsmerch.py, cardvault/consoles.py): their harvester confirms each picture against its own source page and writes the page and licence
# as 'Photo credit' (an unconfirmed one is left out and named in the entry's 'Review' note), so that picture counts as the item's own record.
KEPT_LISTS = frozenset({"worldsmerch", "wikipedia.org"})
_YEAR = re.compile(r"\d{4}")


def fail(gate, why):
    return {"gate": gate, "why": why}


def _fold(s):
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower().replace("♀", "f").replace("♂", "m").replace("é", "e"))


def _numkey(n):
    """'016/101' -> '16', 'SWSH241' -> 'swsh241'."""
    n = str(n or "").split("/")[0].strip().lower()
    return n.lstrip("0") or ("0" if n else "")


def _misc(game):
    """A toy / accessory list (Funko, Chomps, accessories, consoles ...), where the card rules (a number, a dated set, 'not a sealed product') do not apply."""
    from . import games
    return any(g.id == game for g in games.GAMES) and games.is_misc(game)


def _raw(item):
    r = item.get("raw")
    if isinstance(r, str):
        try:
            r = json.loads(r)
        except ValueError:
            r = None
    return r if isinstance(r, dict) else {}


class Context:
    """What the checks look up, read once per run: the sets, which item uses which picture link, the picture bytes seen so far."""
    def __init__(self, conn, game, fetch_image=None):
        self.conn, self.game, self.fetch_image = conn, game, fetch_image
        self.sets = {r[0]: {"name": r[1], "serie": r[2], "date": r[3], "total": r[4] or 0, "official": r[5] or 0, "logo": r[6]}
                     for r in conn.execute("SELECT id, name, serie, release_date, total, official, logo FROM sets")}
        self.logos = {s["logo"] for s in self.sets.values() if s["logo"]}
        self._users = None
        self.hashes = {}
        self._said = {}
        self.pictures_waiting = []                 # ids of cards screen_new put live with no picture because theirs is doubtful (on the review list)
        self.pictures_missing = []                 # ids of cards screen_new put live that have no picture at all yet

    def said(self, kind):
        """{item_id: {answer, final}} of the review items of this kind the owner already settled (read once per run)."""
        if kind not in self._said:
            self._said[kind] = {it["item_id"]: it for it in reviewlist.items("confirmed", self.game, kind)}
        return self._said[kind]

    def users(self):
        """{picture link: {item keys using it}} - an item's key is its TCGplayer product (two of our cards for ONE product may share a picture) or else its id."""
        if self._users is None:
            self._users = {}
            for cid, url, tcg in self.conn.execute("SELECT id, image_base, tcg_id FROM cards WHERE image_base IS NOT NULL AND image_base != ''"):
                self._users.setdefault(url, set()).add(str(tcg or cid))
        return self._users

    def claim(self, url, key):
        self.users().setdefault(url, set()).add(key)


def _key(item):
    return str(item.get("tcg_id") or item.get("id"))


def _own_record(game, item, url):
    """Does the link come from the item's own product record?  -> '' when it does, else why not."""
    host = provenance.host_of(url)
    tcg = str(item.get("tcg_id") or (item.get("id") if str(item.get("id", "")).isdigit() else ""))
    if host in ("tcgplayer-cdn.tcgplayer.com", "product-images.tcgplayer.com"):
        m = _TCGP.search(url)
        if not tcg:
            return "a TCGplayer picture, but the item is not linked to a TCGplayer product, so it is not proven to be this item"
        if not m or m.group(1) != tcg:
            return f"the TCGplayer picture of product {m.group(1) if m else '?'}, not of this item's product {tcg}"
        return ""
    if host == "assets.tcgdex.net":
        sid, lid = str(item.get("set_id") or ""), str(item.get("number") or "")
        tail = "/".join(url.split("#")[0].rstrip("/").split("/")[-2:]).lower()
        return "" if tail == f"{sid}/{lid}".lower() else f"the TCGdex picture of {tail}, not of {sid}/{lid}"
    if host in ("cards.scryfall.io", "c1.scryfall.com") and game == "mtg" and tcg:
        return ""                                   # (Scryfall's card is looked up by its TCGplayer product)
    raw = _raw(item)
    if raw.get("source") in KEPT_LISTS and (raw.get("ext") or {}).get("Photo credit"):
        return ""                                   # (a kept list: its harvester confirmed this very picture and kept its page and credit)
    return f"a link from {host or 'nowhere'}, which is not the item's own product record"


def _dims(b):
    """(width, height) of PNG / JPEG / WEBP / GIF bytes, or None."""
    try:
        if b[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", b[16:24])
        if b[:6] in (b"GIF87a", b"GIF89a"):
            return struct.unpack("<HH", b[6:10])
        if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
            k = b[12:16]
            if k == b"VP8 ":
                w, h = struct.unpack("<HH", b[26:30])
                return w & 0x3FFF, h & 0x3FFF
            if k == b"VP8L":
                v = int.from_bytes(b[21:25], "little")
                return (v & 0x3FFF) + 1, ((v >> 14) & 0x3FFF) + 1
            if k == b"VP8X":
                return int.from_bytes(b[24:27], "little") + 1, int.from_bytes(b[27:30], "little") + 1
        if b[:2] == b"\xff\xd8":
            i = 2
            while i + 9 < len(b):
                if b[i] != 0xFF:
                    i += 1
                    continue
                m, ln = b[i + 1], int.from_bytes(b[i + 2:i + 4], "big")
                if 0xC0 <= m <= 0xCF and m not in (0xC4, 0xC8, 0xCC):
                    h, w = struct.unpack(">HH", b[i + 5:i + 9])
                    return w, h
                i += 2 + ln
    except (struct.error, IndexError):
        return None
    return None


def http_image(url):
    """The picture's bytes (at most 4 MB), or None.  Only the real add paths use it; tests pass their own."""
    import requests
    from .db import picture_url
    try:
        r = requests.get(picture_url(url.split("#")[0]), headers={"User-Agent": "CollectEmAll/3 (picture gate)"}, timeout=30, stream=True)
        if r.status_code != 200 or not r.headers.get("content-type", "").lower().startswith("image/"):
            return None
        return r.raw.read(4 << 20, decode_content=True)
    except Exception:  # noqa: BLE001 - an unreachable picture is simply not confirmed
        return None


def check_picture(game, item, ctx):
    url = (item.get("image") or "").strip()
    if not url:
        return [fail("picture", "no picture")]
    out = []
    if PLACEHOLDER.search(url.split("#")[0].split("?")[0]) or url in ctx.logos:
        out.append(fail("picture", "a stand-in picture (logo, set symbol, sample or 'no image'), not the item"))
    why = _own_record(game, item, url)
    if why:
        out.append(fail("picture", why))
    others = ctx.users().get(url, set()) - {_key(item)}
    if others:
        out.append(fail("picture", f"the same picture as {len(others)} other item(s) ({', '.join(sorted(others)[:3])})"))
    if ctx.fetch_image and not out:
        b = ctx.fetch_image(url)
        if not b:
            out.append(fail("picture", "the picture does not load"))
        else:
            h = hashlib.sha1(b).hexdigest()
            d = _dims(b)
            if h in PLACEHOLDER_SHA1:
                out.append(fail("picture", "a known stand-in picture"))
            elif ctx.hashes.get(h, _key(item)) != _key(item):
                out.append(fail("picture", f"the same picture bytes as item {ctx.hashes[h]}"))
            if not d or min(d) < MIN_SIDE:
                out.append(fail("picture", f"not a real picture ({'x'.join(map(str, d)) if d else 'unreadable'})"))
            ctx.hashes.setdefault(h, _key(item))
    return out


def check_facts(game, item, ctx):
    from .tcggames import LEGACY
    out = []
    name, num, sid = (item.get("name") or "").strip(), str(item.get("number") or "").strip(), str(item.get("set_id") or "")
    if not name:
        out.append(fail("facts", "no name"))
    if not num and game in LEGACY:
        out.append(fail("facts", "no number"))
    m = _NAME_NUM.search(name)
    if m and num and _numkey(m.group(1)) != re.sub(r"^[a-z]+0*", "", _numkey(num)):            # ('SWSH299' is #299)
        out.append(fail("facts", f"the name says #{m.group(1)} but the number is {num}"))
    s = ctx.sets.get(sid)
    date = str(item.get("date") or (s or {}).get("date") or "")
    try:
        d = datetime.date(int(date), 1, 1) if _YEAR.fullmatch(date) else datetime.date.fromisoformat(date[:10])     # (a source that states only the year: '2017')
        if not (datetime.date(1993, 1, 1) <= d <= datetime.date.today() + datetime.timedelta(days=180)):
            out.append(fail("facts", f"an impossible date ({date[:10]})"))
    except ValueError:
        if date or not _misc(game):                  # (a toy line's sets carry no release day: no date is not a wrong fact there)
            out.append(fail("facts", f"no valid date ({date or 'none'})"))
    raw = _raw(item)
    srcs = dict(item.get("facts") or {})
    if raw.get("localId") is not None and isinstance(raw.get("set"), dict):        # a TCGdex record
        srcs.setdefault("TCGdex", {"name": raw.get("name"), "number": raw.get("localId"), "set": raw["set"].get("id")})
    if isinstance(raw.get("ext"), dict) and raw["ext"].get("Number"):              # a TCGplayer record
        srcs.setdefault("TCGplayer", {"number": raw["ext"]["Number"]})
    for src, f in srcs.items():
        if f.get("name") and name and _fold(f["name"]) != _fold(name) and not _fold(name).startswith(_fold(f["name"])):
            out.append(fail("facts", f"{src} names it '{f['name']}', we say '{name}'"))
        if f.get("number") and num and _numkey(f["number"]) != _numkey(num):
            out.append(fail("facts", f"{src} numbers it {f['number']}, we say {num}"))
        if f.get("set") and sid and str(f["set"]).lower() != sid.lower():
            out.append(fail("facts", f"{src} puts it in set {f['set']}, we say {sid}"))
    return out


def sources_of(item):
    """How many independent sources speak for the item (its TCGdex record, its TCGplayer record or link, anything the add path passed)."""
    raw = _raw(item)
    n = set(item.get("facts") or {})
    if raw.get("localId") is not None:
        n.add("TCGdex")
    if raw.get("ext") or item.get("tcg_id"):
        n.add("TCGplayer")
    return len(n)


def check_placement(game, item, ctx):
    from . import games
    from .tcggames import looks_sealed
    out = []
    if not any(g.id == game for g in games.GAMES):
        return [fail("placement", f"no game called {game}")]
    sid = str(item.get("set_id") or "")
    s = ctx.sets.get(sid)
    if not s:
        return [fail("placement", f"its set {sid or '(none)'} does not exist")]
    if not (s["serie"] or "").strip():
        out.append(fail("placement", f"its set {s['name']} has no series"))
    num = str(item.get("number") or "").strip()
    printed = str((_raw(item).get("ext") or {}).get("Number") or num)
    m = re.fullmatch(r"0*(\d+)(?:\s*/\s*0*(\d+))?", num) if num else None
    if m:
        n, top = int(m.group(1)), int(m.group(2) or (re.fullmatch(r"\s*\d+\s*/\s*0*(\d+)\s*", printed) or [0, 0])[1] or 0)
        limit = max(0 if sid.isdigit() else max(s["total"], s["official"]), 2 * top)    # (a set made from a TCGplayer group counts only the cards listed so far: there the printed
        #                                                                                      size is the range, secret rares ('124/123') included)
        if limit and n > limit:
            out.append(fail("placement", f"#{n} is beyond its set's range (1-{limit})"))
    if not num and not _misc(game) and looks_sealed(item.get("name")):            # (a product with a collector number is a card: 'Iron Bundle', 'Booster Energy Capsule'; a toy or accessory list has no cards)
        out.append(fail("placement", "its name says it is a sealed product, not a card"))
    return out


def check_item(game, item, conn, ctx=None):
    """-> [{gate, why}] the gates the item fails ([] = it may be published).  item: {id, name, number, set_id, image, tcg_id, raw, date?, facts?: {source: {name, number, set}}}"""
    ctx = ctx or Context(conn, game)
    return check_picture(game, item, ctx) + check_facts(game, item, ctx) + check_placement(game, item, ctx)


# ------------------------------------------------------------------------------------------------ the add paths: screen what was just written, hold what fails
def _cols(conn):
    return [r[1] for r in conn.execute("PRAGMA table_info(cards)")]


def item_from_row(row):
    """A cards row (as a dict) -> the item check_item reads."""
    return {"id": row["id"], "name": row.get("name"), "number": row.get("local_id"), "set_id": row.get("set_id"), "image": row.get("image_base"), "tcg_id": row.get("tcg_id"), "raw": row.get("raw")}


def _held_conn():
    c = reviewlist._conn()
    c.execute("CREATE TABLE IF NOT EXISTS gate_held(game TEXT NOT NULL, item_id TEXT NOT NULL, row TEXT, set_row TEXT, PRIMARY KEY(game, item_id))")
    return c


def _summary(row, s, fails):
    return {"name": row.get("name"), "number": row.get("local_id"), "set": f"{(s or {}).get('name') or ''} ({row.get('set_id')})", "date": (s or {}).get("date"),
            "picture": row.get("image_base") or "none", "TCGplayer product": row.get("tcg_id"), "problems": "; ".join(f"{f['gate']}: {f['why']}" for f in fails)}


def _doubt_picture(game, conn, row, fails, source, ctx):
    """A new card that is fine except for its picture: it stays live with NO picture ("No picture yet") and the doubtful picture waits on the review list, as screen_picture does."""
    url = row.get("image_base")
    conn.execute("UPDATE cards SET image_base=NULL WHERE id=?", (row["id"],))
    try:
        conn.execute("DELETE FROM provenance WHERE card_id=? AND field='image'", (row["id"],))
    except sqlite3.OperationalError:
        pass                                                         # (no provenance table, or another layout: nothing to clear)
    reviewlist.add_item(PICTURE, game, row["id"], f"Is this the picture of {row.get('name')} #{row.get('local_id')} ({row.get('set_id')})? Not used yet: {'; '.join(f['why'] for f in fails)[:300]}.",
                        before={"picture": "No picture yet"}, after={"picture": url, "from": source}, source=source)
    ctx.pictures_waiting.append(row["id"])


def screen_new(game, conn, ids, source="", new_sets=(), ctx=None):
    """Cards that were just written (ids): a card that fails the facts or placement gate is taken back out and waits on the review list.  A card that fails ONLY the picture gate stays live: with no
    picture it shows "No picture yet"; with a doubtful one the picture is cleared and waits on the review list (ctx.pictures_waiting / ctx.pictures_missing list those cards).  A set in new_sets left
    with no card is taken out too (it comes back with its card).  A card the owner already said yes to stays.  The caller commits.  -> the ids that were held"""
    ids = [str(i) for i in ids]
    if not ids:
        return []
    ctx = ctx or Context(conn, game)
    cols = _cols(conn)
    said = {k: v["answer"] for k, v in ctx.said(CARD).items()}
    held, emptied = [], set()
    for cid in ids:
        r = conn.execute("SELECT * FROM cards WHERE id=?", (cid,)).fetchone()
        if r is None:
            continue
        row = dict(zip(cols, r))
        if said.get(cid) == "yes":
            continue
        fails = check_item(game, item_from_row(row), conn, ctx)
        if not fails:
            continue
        if all(f["gate"] == "picture" for f in fails):                # only the picture is in doubt: the card goes live, the picture fills in later
            if not (row.get("image_base") or "").strip():
                ctx.pictures_missing.append(cid)
                continue
            done = ctx.said(PICTURE).get(cid)
            if done and done["answer"] == "yes" and (done["final"] or {}).get("picture") == row.get("image_base"):
                continue                                                # (the owner already confirmed this very picture)
            _doubt_picture(game, conn, row, fails, source, ctx)
            continue
        s = conn.execute("SELECT * FROM sets WHERE id=?", (row["set_id"],)).fetchone()
        srow = dict(zip([d[0] for d in conn.execute("SELECT * FROM sets LIMIT 0").description], s)) if s else None
        hc = _held_conn()
        try:
            hc.execute("INSERT OR REPLACE INTO gate_held(game, item_id, row, set_row) VALUES(?,?,?,?)", (game, cid, json.dumps(row, ensure_ascii=False), json.dumps(srow, ensure_ascii=False)))
            hc.commit()
        finally:
            hc.close()
        for sql in ("DELETE FROM cards WHERE id=?", "DELETE FROM card_facets WHERE card_id=?", "DELETE FROM provenance WHERE card_id=?"):
            try:
                conn.execute(sql, (cid,))
            except sqlite3.OperationalError:
                pass                                                 # (a list without that table)
        if cid not in said:                                          # a "no" stays out without asking again
            reviewlist.add_item(CARD, game, cid, f"Not published: it failed the checks ({'; '.join(f['why'] for f in fails)[:300]}). Add this card to the catalog as shown?",
                                before=_summary(row, ctx.sets.get(row["set_id"]), fails), source=source)
        held.append(cid)
        emptied.add(str(row["set_id"]))
    for sid in new_sets:
        if not conn.execute("SELECT 1 FROM cards WHERE set_id=? LIMIT 1", (str(sid),)).fetchone():
            conn.execute("DELETE FROM sets WHERE id=?", (str(sid),))
    for sid in emptied - {str(s) for s in new_sets}:                   # a set whose every card is held shows as an empty set: it waits with them (and comes back with them)
        if conn.execute("SELECT 1 FROM cards WHERE set_id=? LIMIT 1", (sid,)).fetchone():
            continue
        try:
            if conn.execute("SELECT 1 FROM sealed_products WHERE set_id=? LIMIT 1", (sid,)).fetchone():
                continue
        except sqlite3.OperationalError:
            pass                                                     # (a list with no sealed table)
        conn.execute("DELETE FROM sets WHERE id=?", (sid,))
    return held


def screen_picture(game, conn, card_id, url, source="", ctx=None):
    """A picture about to be written for an existing card.  -> True: write it.  False: it waits on the review list (before / after) and the card keeps what it has."""
    ctx = ctx or Context(conn, game)
    r = conn.execute("SELECT * FROM cards WHERE id=?", (str(card_id),)).fetchone()
    if r is None:
        return False
    row = dict(zip(_cols(conn), r))
    item = dict(item_from_row(row), image=url)
    done = ctx.said(PICTURE).get(str(card_id))
    fails = [] if (done and done["answer"] == "yes" and (done["final"] or {}).get("picture") == url) else check_picture(game, item, ctx)
    if not fails:
        ctx.claim(url, _key(item))
        return True
    reviewlist.add_item(PICTURE, game, card_id, f"Is this the picture of {row.get('name')} #{row.get('local_id')} ({row.get('set_id')})? Not used yet: {'; '.join(f['why'] for f in fails)[:300]}.",
                        before={"picture": row.get("image_base") or "No picture yet"}, after={"picture": url, "from": source}, source=source)
    return False


# ------------------------------------------------------------------------------------------------ the owner's answers
def _db(item, ctx):
    import os
    from .db import game_dir
    from .paths import release_data_dir
    ctx = ctx or {}
    return os.path.join(game_dir(ctx.get("data_dir") or release_data_dir(), item["game"]), "cards.db")


def _apply_card(item, ans, value, ctx):
    if ans != "yes":
        return "kept out of the catalog"
    hc = _held_conn()
    try:
        got = hc.execute("SELECT row, set_row FROM gate_held WHERE game=? AND item_id=?", (item["game"], item["item_id"])).fetchone()
    finally:
        hc.close()
    if not got:
        return "nothing to add: the held card was not found"
    row, srow = json.loads(got[0]), json.loads(got[1] or "null")
    conn = sqlite3.connect(_db(item, ctx), timeout=60)
    try:
        if srow:
            scols = [d[0] for d in conn.execute("SELECT * FROM sets LIMIT 0").description]
            srow = {k: v for k, v in srow.items() if k in scols}
            conn.execute(f"INSERT OR IGNORE INTO sets({','.join(srow)}) VALUES({','.join('?' * len(srow))})", list(srow.values()))
        row = {k: v for k, v in row.items() if k in _cols(conn)}
        n = conn.execute(f"INSERT OR IGNORE INTO cards({','.join(row)}) VALUES({','.join('?' * len(row))})", list(row.values())).rowcount
        conn.commit()
    finally:
        conn.close()
    return "added to the catalog" if n else "already in the catalog"


def _apply_picture(item, ans, value, ctx):
    if ans not in ("yes", "value"):
        return "picture not used"
    url = value if ans == "value" else (value or {}).get("picture")
    if not url:
        return "no picture to use"
    conn = sqlite3.connect(_db(item, ctx), timeout=60)
    try:
        n = conn.execute("UPDATE cards SET image_base=? WHERE id=?", (url, item["item_id"])).rowcount
        if n:
            provenance.record_image(conn, item["item_id"], url)
        conn.commit()
    finally:
        conn.close()
    return "picture set" if n else "the card is not in the catalog"


reviewlist.register(CARD, apply=_apply_card)
reviewlist.register(PICTURE, apply=_apply_picture)
