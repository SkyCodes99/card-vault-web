"""The readers' memory on disk: every link fetched (with its source, date, ETag and Last-Modified), the cached body,
and one row per site (its rules, its live robots.txt, and any cool-down after errors).  One SQLite file plus a folder of
bodies named by a hash of the link."""
import hashlib
import os
import sqlite3
import threading

_SCHEMA = """
CREATE TABLE IF NOT EXISTS pages(url TEXT PRIMARY KEY, site TEXT, status INTEGER, etag TEXT, last_modified TEXT,
    fetched_at TEXT, checked_at TEXT, body_file TEXT, sha1 TEXT, size INTEGER);
CREATE INDEX IF NOT EXISTS pages_site ON pages(site);
CREATE TABLE IF NOT EXISTS sites(site TEXT PRIMARY KEY, name TEXT, use TEXT, min_interval REAL, terms TEXT, terms_url TEXT,
    robots_txt TEXT, robots_status INTEGER, robots_at REAL, crawl_delay REAL, fails INTEGER DEFAULT 0, cool_until REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS site_runs(site TEXT PRIMARY KEY, failed_runs INTEGER DEFAULT 0, times_off INTEGER DEFAULT 0, off_until REAL DEFAULT 0,
    last_error TEXT, last_run TEXT);
"""
_PAGE_COLS = ("url", "site", "status", "etag", "last_modified", "fetched_at", "checked_at", "body_file", "sha1", "size")


class Store:
    def __init__(self, root):
        self.root = root
        self.bodies = os.path.join(root, "bodies")
        os.makedirs(self.bodies, exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(os.path.join(root, "sources.db"), check_same_thread=False)
        self._db.executescript(_SCHEMA)

    def close(self):
        self._db.close()

    # ------------------------------------------------------------------------------------------------------- pages
    def page(self, url):
        with self._lock:
            row = self._db.execute(f"SELECT {','.join(_PAGE_COLS)} FROM pages WHERE url=?", (url,)).fetchone()
        return dict(zip(_PAGE_COLS, row)) if row else None

    def body(self, page):
        if not page or not page.get("body_file"):
            return None
        try:
            with open(os.path.join(self.bodies, page["body_file"]), "rb") as f:
                return f.read()
        except OSError:
            return None

    def save_page(self, url, site, status, headers, body, when):
        name = sha = None
        if body is not None:
            name = hashlib.sha1(url.encode("utf-8")).hexdigest()
            sha = hashlib.sha1(body).hexdigest()
            tmp = os.path.join(self.bodies, name + ".part")
            with open(tmp, "wb") as f:
                f.write(body)
            os.replace(tmp, os.path.join(self.bodies, name))
        with self._lock, self._db:
            self._db.execute("INSERT OR REPLACE INTO pages VALUES(?,?,?,?,?,?,?,?,?,?)",
                             (url, site, status, headers.get("etag"), headers.get("last-modified"), when, when, name, sha,
                              len(body) if body is not None else 0))

    def touch(self, url, when):
        """A 304: the cached copy is still current as of now."""
        with self._lock, self._db:
            self._db.execute("UPDATE pages SET checked_at=? WHERE url=?", (when, url))

    def seen(self, url):
        return self.page(url) is not None

    def pages(self, site=None):
        """Provenance of everything fetched: [{url, site, status, fetched_at, checked_at, sha1}], oldest first."""
        sql = "SELECT url, site, status, fetched_at, checked_at, sha1 FROM pages" + (" WHERE site=?" if site else "") + " ORDER BY fetched_at"
        with self._lock:
            rows = self._db.execute(sql, (site,) if site else ()).fetchall()
        return [dict(zip(("url", "site", "status", "fetched_at", "checked_at", "sha1"), r)) for r in rows]

    # ------------------------------------------------------------------------------------------------------- sites
    def site(self, site_id):
        with self._lock:
            cur = self._db.execute("SELECT * FROM sites WHERE site=?", (site_id,))
            row = cur.fetchone()
            return dict(zip([d[0] for d in cur.description], row)) if row else None

    def save_rule(self, rule):
        """Write the rule's row (keeps any robots / cool-down already recorded)."""
        with self._lock, self._db:
            self._db.execute("INSERT INTO sites(site,name,use,min_interval,terms,terms_url) VALUES(?,?,?,?,?,?) "
                             "ON CONFLICT(site) DO UPDATE SET name=excluded.name, use=excluded.use, min_interval=excluded.min_interval, "
                             "terms=excluded.terms, terms_url=excluded.terms_url",
                             (rule.id, rule.name, rule.use, rule.min_interval, rule.terms, rule.terms_url))

    def save_robots(self, site_id, text, status, when, delay):
        with self._lock, self._db:
            self._db.execute("UPDATE sites SET robots_txt=?, robots_status=?, robots_at=?, crawl_delay=? WHERE site=?",
                             (text, status, when, delay, site_id))

    def set_health(self, site_id, fails, cool_until):
        with self._lock, self._db:
            self._db.execute("UPDATE sites SET fails=?, cool_until=? WHERE site=?", (fails, cool_until, site_id))

    # ------------------------------------------------------------------------------------------------------- daily runs per site
    _RUN_COLS = ("site", "failed_runs", "times_off", "off_until", "last_error", "last_run")

    def run_health(self, site_id):
        """How the daily runs went for one site (cardvault/safetynet.py): failed runs in a row, times switched off, off until when."""
        with self._lock:
            row = self._db.execute(f"SELECT {','.join(self._RUN_COLS)} FROM site_runs WHERE site=?", (site_id,)).fetchone()
        return dict(zip(self._RUN_COLS, row)) if row else {"site": site_id, "failed_runs": 0, "times_off": 0, "off_until": 0.0, "last_error": None, "last_run": None}

    def save_run_health(self, h):
        with self._lock, self._db:
            self._db.execute("INSERT OR REPLACE INTO site_runs VALUES(?,?,?,?,?,?)", tuple(h.get(k) for k in self._RUN_COLS))

    def run_healths(self):
        with self._lock:
            rows = self._db.execute(f"SELECT {','.join(self._RUN_COLS)} FROM site_runs ORDER BY site").fetchall()
        return [dict(zip(self._RUN_COLS, r)) for r in rows]
