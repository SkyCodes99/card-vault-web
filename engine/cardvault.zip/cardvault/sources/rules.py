"""The per-site rules table: which sites we read, how fast, and on what terms.  One row per source site; a site that is
not listed (a maker's own shop, say) gets the careful MAKER default.  The live robots.txt of every site is fetched and
kept beside these rows by the store (sites table), so the two together are the full record of what each site allows."""
from dataclasses import dataclass, replace
from urllib.parse import urlsplit


@dataclass(frozen=True)
class SiteRule:
    id: str
    name: str
    hosts: tuple = ()
    min_interval: float = 2.0         # seconds between two requests to this site (robots.txt Crawl-delay wins when larger)
    use: str = "data"                 # data = may read and keep facts | links = link out only, never read, until permission is granted
    terms: str = ""                   # our note on the site's terms (check terms_url before widening what we take)
    terms_url: str = ""
    robots: bool = True               # obey robots.txt


SITES = {r.id: r for r in (
    SiteRule("tcgdex", "TCGdex", ("api.tcgdex.net", "assets.tcgdex.net"), 0.2, "data",
             "Open card-data API; keep the request rate modest and credit TCGdex.", "https://tcgdex.dev"),
    SiteRule("tcgcsv", "TCGplayer via tcgcsv", ("tcgcsv.com",), 0.5, "data",
             "Free daily mirror of TCGplayer's catalog and prices; it changes once a day, so read it at most daily.", "https://tcgcsv.com"),
    SiteRule("tcgplayer-img", "TCGplayer pictures", ("tcgplayer-cdn.tcgplayer.com", "product-images.tcgplayer.com"), 0.5, "data",
             "Product pictures named by tcgcsv; link or fetch one picture per product.", "https://www.tcgplayer.com"),
    SiteRule("pokecottage", "PokeCottage card-list library", ("pokecottage.com", "www.pokecottage.com"), 3.0, "data",
             "Fan checklists; read slowly and credit the source on every fact taken.", "https://pokecottage.com"),
    SiteRule("hobbybin", "The Hobby Bin", ("thehobbybin.com", "www.thehobbybin.com"), 3.0, "data",
             "Shop and checklist pages; read slowly and credit the source.  2026-11-13: Cloudflare answered this program's reader with a bot check (HTTP 429 'Verifying your connection', every page) while "
             "it had read the Lorcana / Magic pages before; a bot check is never worked around, so nothing more is read until a plain fetch answers 200 again (Japanese Pokemon was NOT read).", "https://thehobbybin.com"),
    SiteRule("scryfall-api", "Scryfall", ("api.scryfall.com",), 0.2, "data",
             "Scryfall asks for 50-100 ms between API calls, a descriptive User-Agent and an Accept header; we only read the bulk-data list (one call a day).", "https://scryfall.com/docs/api"),
    SiteRule("scryfall-data", "Scryfall bulk data", ("data.scryfall.io",), 2.0, "data",
             "Daily bulk card files (prices, ids).  Download each file once a day at most; prices are refreshed about every 24 hours; credit Scryfall.", "https://scryfall.com/docs/api/bulk-data"),
    SiteRule("mtgjson", "MTGJSON", ("mtgjson.com", "www.mtgjson.com"), 2.0, "data",
             "Free daily price and id files (compressed .gz).  Its robots.txt says Disallow: /api/v5/*.json; read the RFC 9309 way (wildcard, prefix match) that covers "
             "AllPricesToday.json.gz and TcgplayerSkus.json.gz, so the fetcher REFUSES MTGJSON (checked 2026-11-10 against the real robots.txt).  Scryfall covers Magic prices; "
             "ask MTGJSON for permission before ever reading it.", "https://mtgjson.com/faq/"),
    SiteRule("yugipedia", "Yugipedia", ("yugipedia.com", "www.yugipedia.com", "img.yugipedia.com", "ms.yugipedia.com"), 2.0, "data",
             "Yu-Gi-Oh! wiki; its robots.txt allows api.php and pages (checked 2026-11-10).  Set cover pictures are hot-linked, never copied; credit Yugipedia.", "https://yugipedia.com/wiki/Yugipedia:Copyrights"),
    SiteRule("scrydex", "Scrydex", ("scrydex.com", "images.scrydex.com"), 2.0, "data",
             "Card database with a logo for every expansion; robots.txt allows everything for '*' (checked 2026-11-10).  Logos are hot-linked, never copied; credit Scrydex.", "https://scrydex.com"),
    SiteRule("hobbydb", "hobbyDB", ("hobbydb.com", "www.hobbydb.com"), 10.0, "links",
             "Read-only: link out only until hobbyDB grants permission (owner rule).", "https://www.hobbydb.com"),
    # ---- Hot Wheels (docs/hotwheels_sources.md has the whole survey, checked 2026-11-13)
    SiteRule("hwtreasure", "HWtreasure.com", ("hwtreasure.com", "www.hwtreasure.com"), 3.0, "data",
             "A collector's own site: every Treasure Hunt and Super Treasure Hunt since 1995.  robots.txt allows its pages and it has no terms against reading them (checked 2026-11-13).  "
             "Facts only - never its wording or its photos; every car credits and links its own page.", "https://www.hwtreasure.com/copyright/"),
    SiteRule("hwrlc", "HWRLC.com", ("hwrlc.com", "www.hwrlc.com"), 3.0, "data",
             "Same author as HWtreasure.com: every Red Line Club car.  robots.txt allows everything, no terms against reading (checked 2026-11-13).  Facts only, credited and linked.", "https://hwrlc.com/copyright/"),
    SiteRule("hwredline", "HWredline.com", ("hwredline.com", "www.hwredline.com"), 3.0, "data",
             "Same author as HWtreasure.com: the Redline years 1968-1977.  robots.txt allows everything, no terms against reading (checked 2026-11-13).  Facts only, credited and linked.", "https://hwredline.com/copyright/"),
    SiteRule("hotwheels-wiki", "Hot Wheels Wiki (Fandom)", ("hotwheels.fandom.com",), 10.0, "links",
             "Answers a plain client with a bot check (HTTP 403 on every page, robots.txt included; checked 2026-11-13).  A bot check is never worked around: link out only.", "https://www.fandom.com/terms-of-use"),
    SiteRule("hwcollectorsnews", "Hot Wheels Newsletter", ("hwcollectorsnews.com", "www.hwcollectorsnews.com"), 10.0, "links",
             "Its terms allow personal viewing only; any other use needs written consent (terms of 2025-01-01, read 2026-11-13): link out only.",
             "https://hwcollectorsnews.com/wp-content/uploads/2025/03/Terms-and-Conditions-of-Website-Use.pdf"),
    SiteRule("collecthw", "Collect HW", ("collecthw.com", "www.collecthw.com"), 10.0, "links",
             "robots.txt turns AI readers away by name (checked 2026-11-13): link out only.", "https://collecthw.com"),
    # ---- Comics (docs/comics_data.md has the whole survey, checked 2026-11-13)
    SiteRule("gcd", "Grand Comics Database", ("comics.org", "www.comics.org", "docs.comics.org", "files1.comics.org"), 10.0, "links",
             "Answers a plain client with a bot check (HTTP 403 on every page, robots.txt included; checked 2026-11-13), and its data dump needs a free account the app never makes.  "
             "A bot check is never worked around: link out only; the owner downloads the dump (docs/comics_data.md).", "https://docs.comics.org/wiki/Data_Distribution"),
    # ---- Video games (docs/video_games_data.md has the whole survey, checked 2026-11-13)
    SiteRule("wikidata", "Wikidata", ("query.wikidata.org", "www.wikidata.org", "wikidata.org"), 2.0, "data",
             "CC0 data.  The owner named Wikidata as a fact source for Video games (roadmap row, 2026-11-10); the SPARQL endpoint came from the lead's brief, NOT from the owner, and its use is waiting on the owner's answer (quiz 16): small queries, one request per 2 s, a descriptive User-Agent without an email (tools/wikidata_sparql.py).  "
             "NOTE: its robots.txt lists /sparql as disallowed for crawlers, so the app's polite reader (which obeys robots.txt) would refuse it; only that tool asks it, as the documented API use it is.",
             "https://www.wikidata.org/wiki/Wikidata:Licensing"),
    SiteRule("commons", "Wikimedia Commons", ("commons.wikimedia.org", "upload.wikimedia.org"), 1.0, "data",
             "Free-licence files only; the licence is read per file from the Commons API (the same one the consoles photos use) and a file with no free licence on record is never shown.", "https://commons.wikimedia.org/wiki/Commons:Reuse"),
)}
MAKER = SiteRule("maker", "Maker shop", (), 5.0, "data",
                 "Public shop feed of a maker's own store; slow and polite (abominabletoys.com blocked us once).")

_GRANTED = set()                      # site ids whose 'links' rule has been lifted by permission (grant())


def host_of(url):
    return (urlsplit(url).hostname or "").lower()


def rule_for(url):
    """The rule for a link: the listed site that owns its host, else a MAKER rule named after the host."""
    host = host_of(url)
    for r in SITES.values():
        if host in r.hosts:
            return r
    return replace(MAKER, id=host or "unknown", hosts=(host,))


def add(rule):
    """List one more site (a maker shop an adapter knows by name).  Returns the rule."""
    SITES[rule.id] = rule
    return rule


def grant(site_id):
    """Record that a 'links only' site has given permission to read it."""
    _GRANTED.add(site_id)


def may_read(rule):
    return rule.use == "data" or rule.id in _GRANTED
