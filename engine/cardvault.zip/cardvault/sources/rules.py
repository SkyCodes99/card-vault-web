"""The per-site rules table: which sites we read, how fast, and on what terms.  One row per source site; a site that is
not listed (a maker's own shop, say) gets the careful MAKER default.  The live robots.txt of every site is fetched and
kept beside these rows by the store (sites table), so the two together are the full record of what each site allows."""
from dataclasses import dataclass, replace
from urllib.parse import urlsplit


@dataclass(frozen=True)
class SiteRule:
    id: str
    name: str
    hosts: tuple = ()
    min_interval: float = 2.0         # seconds between two requests to this site (robots.txt Crawl-delay wins when larger)
    use: str = "data"                 # data = may read and keep facts | links = link out only, never read, until permission is granted
    terms: str = ""                   # our note on the site's terms (check terms_url before widening what we take)
    terms_url: str = ""
    robots: bool = True               # obey robots.txt


SITES = {r.id: r for r in (
    SiteRule("tcgdex", "TCGdex", ("api.tcgdex.net", "assets.tcgdex.net"), 0.2, "data",
             "Open card-data API; keep the request rate modest and credit TCGdex.", "https://tcgdex.dev"),
    SiteRule("tcgcsv", "TCGplayer via tcgcsv", ("tcgcsv.com",), 0.5, "data",
             "Free daily mirror of TCGplayer's catalog and prices; it changes once a day, so read it at most daily.", "https://tcgcsv.com"),
    SiteRule("tcgplayer-img", "TCGplayer pictures", ("tcgplayer-cdn.tcgplayer.com", "product-images.tcgplayer.com"), 0.5, "data",
             "Product pictures named by tcgcsv; link or fetch one picture per product.", "https://www.tcgplayer.com"),
    SiteRule("pokecottage", "PokeCottage card-list library", ("pokecottage.com", "www.pokecottage.com"), 3.0, "data",
             "Fan checklists; read slowly and credit the source on every fact taken.", "https://pokecottage.com"),
    SiteRule("hobbybin", "The Hobby Bin", ("thehobbybin.com", "www.thehobbybin.com"), 3.0, "data",
             "Shop and checklist pages; read slowly and credit the source.", "https://thehobbybin.com"),
    SiteRule("scryfall-api", "Scryfall", ("api.scryfall.com",), 0.2, "data",
             "Scryfall asks for 50-100 ms between API calls, a descriptive User-Agent and an Accept header; we only read the bulk-data list (one call a day).", "https://scryfall.com/docs/api"),
    SiteRule("scryfall-data", "Scryfall bulk data", ("data.scryfall.io",), 2.0, "data",
             "Daily bulk card files (prices, ids).  Download each file once a day at most; prices are refreshed about every 24 hours; credit Scryfall.", "https://scryfall.com/docs/api/bulk-data"),
    SiteRule("mtgjson", "MTGJSON", ("mtgjson.com", "www.mtgjson.com"), 2.0, "data",
             "Free daily price and id files (compressed .gz).  Its robots.txt says Disallow: /api/v5/*.json; read the RFC 9309 way (wildcard, prefix match) that covers "
             "AllPricesToday.json.gz and TcgplayerSkus.json.gz, so the fetcher REFUSES MTGJSON (checked 2026-11-10 against the real robots.txt).  Scryfall covers Magic prices; "
             "ask MTGJSON for permission before ever reading it.", "https://mtgjson.com/faq/"),
    SiteRule("yugipedia", "Yugipedia", ("yugipedia.com", "www.yugipedia.com", "img.yugipedia.com", "ms.yugipedia.com"), 2.0, "data",
             "Yu-Gi-Oh! wiki; its robots.txt allows api.php and pages (checked 2026-11-10).  Set cover pictures are hot-linked, never copied; credit Yugipedia.", "https://yugipedia.com/wiki/Yugipedia:Copyrights"),
    SiteRule("scrydex", "Scrydex", ("scrydex.com", "images.scrydex.com"), 2.0, "data",
             "Card database with a logo for every expansion; robots.txt allows everything for '*' (checked 2026-11-10).  Logos are hot-linked, never copied; credit Scrydex.", "https://scrydex.com"),
    SiteRule("hobbydb", "hobbyDB", ("hobbydb.com", "www.hobbydb.com"), 10.0, "links",
             "Read-only: link out only until hobbyDB grants permission (owner rule).", "https://www.hobbydb.com"),
)}
MAKER = SiteRule("maker", "Maker shop", (), 5.0, "data",
                 "Public shop feed of a maker's own store; slow and polite (abominabletoys.com blocked us once).")

_GRANTED = set()                      # site ids whose 'links' rule has been lifted by permission (grant())


def host_of(url):
    return (urlsplit(url).hostname or "").lower()


def rule_for(url):
    """The rule for a link: the listed site that owns its host, else a MAKER rule named after the host."""
    host = host_of(url)
    for r in SITES.values():
        if host in r.hosts:
            return r
    return replace(MAKER, id=host or "unknown", hosts=(host,))


def add(rule):
    """List one more site (a maker shop an adapter knows by name).  Returns the rule."""
    SITES[rule.id] = rule
    return rule


def grant(site_id):
    """Record that a 'links only' site has given permission to read it."""
    _GRANTED.add(site_id)


def may_read(rule):
    return rule.use == "data" or rule.id in _GRANTED
