"""Per-site rate limit: no two requests to one site closer together than its interval (thread-safe)."""
import threading


class Throttle:
    def __init__(self, clock, sleep):
        self.clock, self.sleep = clock, sleep
        self._next = {}
        self._lock = threading.Lock()

    def wait(self, site, interval):
        with self._lock:                                   # book the next slot, then sleep outside the lock
            now = self.clock()
            slot = max(now, self._next.get(site, 0.0))
            self._next[site] = slot + interval
        if slot > now:
            self.sleep(slot - now)
