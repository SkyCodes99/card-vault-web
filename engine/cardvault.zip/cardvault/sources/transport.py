"""The one place the readers touch the network.  A transport is any callable (url, headers) -> Response; tests pass a
fake one, so nothing in cardvault.sources needs the network to be tested."""
from collections import namedtuple

Response = namedtuple("Response", "status headers body")          # headers: dict with lower-case names; body: bytes

USER_AGENT = "CollectEmAll/3 (+personal collection app; polite reader)"


class RequestsTransport:
    def __init__(self, timeout=60):
        self.timeout = timeout
        self._session = None

    def __call__(self, url, headers):
        import requests
        if self._session is None:
            self._session = requests.Session()
        r = self._session.get(url, headers=headers, timeout=self.timeout)
        return Response(r.status_code, {k.lower(): v for k, v in r.headers.items()}, r.content)
