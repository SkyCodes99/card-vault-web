"""PokeCottage set pages -> plain facts.  Every set page carries a schema.org JSON-LD ItemList (one entry per card: name, number,
rarity, picture) plus a "Thing" with the set's description.  Nothing here touches the network: pass the page text in
(cardvault.sources.PokeCottage(fetcher).page("sets/<slug>-card-list").text()).  Credit PokeCottage on every fact taken."""
import html
import json
import re

SITEMAP = "sitemap.xml"
_LD = re.compile(r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>', re.S)
_NUM = re.compile(r"^\s*([A-Za-z]*\d+[A-Za-z]*)\s*(?:/\s*([A-Za-z]*\d+))?\s*$")
_RARITY = re.compile(r"Rarity:\s*([^.]+?)\.?\s*$")


def set_slugs(sitemap_text):
    """English set pages named in the sitemap -> ['sun-moon-card-list', ...] (Chinese sets live under /chinese-sets/, skipped)."""
    return sorted(set(re.findall(r"<loc>https://pokecottage\.com/sets/([a-z0-9\-]+-card-list)</loc>", sitemap_text)))


def _blocks(page_text):
    for m in _LD.finditer(page_text):
        try:
            d = json.loads(m.group(1))
        except ValueError:
            continue
        for b in (d.get("@graph", [d]) if isinstance(d, dict) else d):
            if isinstance(b, dict):
                yield b


def parse_set_page(page_text):
    """-> {"title", "expected": numbered-card count the page claims, "cards": [{"number","total","name","rarity","image","image_lang","promo"}]}.
    Entries whose identifier is not a plain number (promos, related MEP cards) are kept with promo=True so the caller can leave them out."""
    out = {"title": "", "expected": None, "cards": []}
    for b in _blocks(page_text):
        if b.get("@type") == "CollectionPage":
            out["title"] = html.unescape(b.get("name", ""))
        if b.get("@type") != "ItemList":
            continue
        desc = b.get("description", "")
        m = re.search(r"with (\d+) numbered cards", desc)
        out["expected"] = int(m.group(1)) if m else None
        for el in b.get("itemListElement", []):
            it = el.get("item", {}) if isinstance(el, dict) else {}
            ident = str(it.get("identifier") or "")
            nm = _NUM.match(ident)
            r = _RARITY.search(it.get("description", ""))
            img = it.get("image") or {}
            name = html.unescape(str(it.get("name", "")))
            name = re.sub(r"\s+" + re.escape(ident) + r"$", "", name).strip() if ident else name
            out["cards"].append({
                "number": nm.group(1) if nm else ident, "total": nm.group(2) if nm else None, "name": name,
                "rarity": html.unescape(r.group(1)).strip() if r else "", "image": img.get("contentUrl", ""),
                "image_lang": img.get("inLanguage", ""), "promo": not (nm and nm.group(2))})
    return out


_DIV = re.compile(r'<div class="card ([a-z0-9\- ]*)">\s*<a href="([^"]*)"[^>]*>\s*<img src="([^"]*)"[^>]*?alt="([^"]*)"', re.S)
_ALT = re.compile(r"^\s*(\d+[A-Za-z]?)\s*/\s*(\d+)\s+(.*?)\s*$")
_PRODUCT = re.compile(r"tcgplayer\.com/product/(\d+)")
# words that end the alt text before the generic tail ("... Pokemon Card", "... Pokemon 30th Anniversary Card List Celebration")
_RARITIES = ("Special Illustration Rare", "Mega Hyper Rare", "Hyper Rare", "Illustration Rare", "Ultra Rare", "Double Rare", "Rainbow Rare", "Secret Rare", "Shiny Rare",
             "Holo Rare", "Uncommon", "Common", "Rare", "Promo", "ACE SPEC Rare", "Amazing Rare", "Radiant Rare", "Prism Star", "Full Art", "Alternate Art", "Trainer Gallery")


def parse_div_cards(page_text):
    """Older pages: <div class="card rare"><a href=...product/ID><img alt="118/181 Dragonite Holo Rare Pokemon Card">.  -> same dicts as parse_set_page
    plus "product" (TCGplayer product id or ""), "css" (the rarity class).  An alt without a number (promo, art-only block) is skipped."""
    out = []
    for css, href, src, alt in _DIV.findall(page_text):
        a = _ALT.match(html.unescape(alt))
        if not a:
            continue
        rest = re.sub(r"\s+Pokemon\b.*$", "", a.group(3)).strip()
        if "Classic" in rest or rest.endswith(" Promos"):       # a Classic Collection card belongs to that set; a "Promos" entry is a promo, not a numbered card
            continue
        rarity = next((r for r in _RARITIES if rest.endswith(" " + r)), "")
        name = rest[:-len(rarity)].strip() if rarity else rest
        name = "" if name == "from" or name.startswith("from ") else re.split(r"\s+from\s+", name)[0].strip()      # "Caterpie from Sun & Moon Base"; some pages give no name at all ("001/264 from Fusion Strike")
        pm = _PRODUCT.search(href)
        out.append({"number": a.group(1), "total": a.group(2), "name": name, "rarity": rarity, "image": src, "image_lang": "en", "promo": False,
                    "product": pm.group(1) if pm else "", "css": css.strip()})
    return out


def cards_of(page_text):
    """Every numbered card a set page lists, whichever layout the page uses -> (cards, expected_count_or_None)."""
    d = parse_set_page(page_text)
    cards = [c for c in d["cards"] if not c["promo"]] or parse_div_cards(page_text)
    return cards, d["expected"]
