"""Reads The Hobby Bin's pages into plain facts (no network here: the caller fetches through the shared Fetcher).

  parse_index(html)        -> [slug]            the sets a game's index page lists (its '/collections/<slug>-card-list' links)
  parse_price_guide(html)  -> {"set": name, "cards": [{"num", "name", "rarity", "img", "url"}]}
                              one set's full card table: number, name, rarity code, the picture and the card's own page.
Only text facts and picture links are taken; the price column is ignored.  Credit: The Hobby Bin (thehobbybin.com)."""
import html as _html
import re

_ROW = re.compile(r'<tr data-name="([^"]*)"\s+data-num="([^"]*)"\s+data-rar="([^"]*)"[^>]*>(.*?)</tr>', re.S)
_BIG = re.compile(r'data-big="(https://cdn\.shopify\.com/[^"]+)"')
_URL = re.compile(r'class="ca-link" href="(/products/[^"]+)"')
_ZOOM_NAME = re.compile(r'data-ca-name="([^"]*)"')
_TITLE = re.compile(r"<title>\s*(.*?)\s*(?:&ndash;|–|-)\s*The Hobby Bin\s*</title>", re.S)


_MAIN = re.compile(r"<main[\s>]")


def parse_index(html):
    """The page's own sets only: the menu at the top lists every game's sets, so only the <main> part is read."""
    html = html or ""
    m = _MAIN.search(html)
    body = html[m.start():] if m else html
    body = body[:body.find("<footer")] if "<footer" in body else body
    return list(dict.fromkeys(re.findall(r'href="/collections/([a-z0-9-]+)-card-list"', body)))


def clean_image(url):
    """The picture address without Shopify's cache-busting '?v=' (the card list wants a plain .jpg / .png address)."""
    return (url or "").split("?")[0]


def parse_price_guide(html):
    html = html or ""
    m = _TITLE.search(html)
    title = _html.unescape(m.group(1)) if m else ""
    set_name = re.sub(r"\s+Price Guide.*$", "", title).strip()
    cards = []
    for _slug, num, rar, body in _ROW.findall(html):
        big, url, name = _BIG.search(body), _URL.search(body), _ZOOM_NAME.search(body)
        if not (name and num.strip()):
            continue
        cards.append({"num": num.strip(), "name": _html.unescape(name.group(1)).strip(), "rarity": _html.unescape(rar).strip(),
                      "img": clean_image(big.group(1)) if big else "", "url": url.group(1) if url else ""})
    return {"set": set_name, "cards": cards}
