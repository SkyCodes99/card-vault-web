"""The one polite reader every source site goes through.

For each link it: looks up the site's rule (rules.py), refuses 'links only' sites, reads and obeys the site's robots.txt
(kept a day), waits out the site's rate limit, sends If-None-Match / If-Modified-Since from the cache, backs off on 429
and 5xx (Retry-After first), cools a site down after repeated failures or a 403 block instead of hammering it, and
records source + link + date for every item so later steps can stamp provenance on each card, picture and price."""
import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from urllib.parse import urlsplit

from . import robots, rules
from .store import Store
from .throttle import Throttle
from .transport import USER_AGENT, RequestsTransport

ROBOTS_MAX_AGE = 24 * 3600            # re-read robots.txt once a day
BACKOFF_BASE, BACKOFF_CAP = 2.0, 120.0
COOL_BASE, COOL_CAP = 60.0, 6 * 3600.0   # a failing site rests 1 min, 2 min, 4 min ... up to 6 h


class SourceError(Exception):
    """Base for every refusal / failure of the reader."""


class LinksOnly(SourceError):
    """The site may only be linked to (no permission to read it)."""


class Disallowed(SourceError):
    """robots.txt says no (or could not be read)."""


class Cooling(SourceError):
    """The site is resting after errors or a block; try again later."""


class FetchFailed(SourceError):
    """The link could not be read after all tries."""


@dataclass
class Fetched:
    url: str
    site: str                 # rule id, e.g. "tcgcsv"
    source: str               # human name, e.g. "TCGplayer via tcgcsv"
    status: int
    body: bytes
    fetched_at: str           # ISO-8601 UTC time the body was last read from the site
    from_cache: bool = False
    stale: bool = False       # served from cache because the site could not be reached

    def text(self):
        return (self.body or b"").decode("utf-8", "replace")

    def json(self):
        return json.loads(self.body) if self.body else None

    def provenance(self):
        return {"source": self.site, "source_name": self.source, "url": self.url, "fetched_at": self.fetched_at}


def _iso(t):
    return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_iso(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc).timestamp()


def _retry_after(headers):
    v = (headers or {}).get("retry-after")
    try:
        return max(0.0, float(v)) if v is not None else None
    except ValueError:
        return None                                       # an HTTP-date: fall back to our own backoff


class Fetcher:
    def __init__(self, root, transport=None, clock=time.time, sleep=time.sleep, user_agent=USER_AGENT, tries=4):
        self.store = Store(root)
        self.transport = transport or RequestsTransport()
        self.clock, self.sleep = clock, sleep
        self.user_agent = user_agent
        self.tries = tries
        self.throttle = Throttle(clock, sleep)

    # ----------------------------------------------------------------------------------------------- public
    def get(self, url, max_age=None, headers=None):
        """Read one link.  max_age (seconds): a cached copy younger than this is returned without asking the site.
        headers: extra request headers (e.g. Accept) for sites that ask for them.
        Returns a Fetched (status 404/410 = the site says it is gone; body None).  Raises a SourceError otherwise."""
        rule = rules.rule_for(url)
        if not rules.may_read(rule):
            raise LinksOnly(f"{rule.name} is links-only until permission is granted")
        self.store.save_rule(rule)
        page = self.store.page(url)
        if page and max_age is not None and page["status"] == 200 and self.clock() - _parse_iso(page["checked_at"]) < max_age:
            return self._cached(rule, page)
        if self._cool_until(rule) > self.clock():
            return self._stale_or_raise(rule, page, Cooling(f"{rule.name} is resting after errors"))
        interval = max(rule.min_interval, self._robots_gate(rule, url))
        headers = {"User-Agent": self.user_agent, **(headers or {})}
        if page and page["status"] == 200:
            if page["etag"]:
                headers["If-None-Match"] = page["etag"]
            if page["last_modified"]:
                headers["If-Modified-Since"] = page["last_modified"]
        return self._fetch(rule, url, headers, interval, page)

    def seen(self, url):
        return self.store.seen(url)

    def history(self, site=None):
        return self.store.pages(site)

    # ----------------------------------------------------------------------------------------------- the request loop
    def _fetch(self, rule, url, headers, interval, page):
        last = None
        for i in range(self.tries):
            self.throttle.wait(rule.id, interval)
            try:
                r = self.transport(url, headers)
            except Exception as e:                       # network error: back off like a 5xx
                last = repr(e)
                self.sleep(min(BACKOFF_CAP, BACKOFF_BASE * 2 ** i))
                continue
            now = _iso(self.clock())
            if r.status == 304 and page:
                self.store.touch(url, now)
                self._healthy(rule)
                return self._cached(rule, self.store.page(url))
            if r.status == 200:
                self.store.save_page(url, rule.id, 200, r.headers, r.body, now)
                self._healthy(rule)
                return Fetched(url, rule.id, rule.name, 200, r.body, now)
            if r.status in (404, 410):
                self.store.save_page(url, rule.id, r.status, r.headers, None, now)
                self._healthy(rule)
                return Fetched(url, rule.id, rule.name, r.status, None, now)
            if r.status == 403:                          # a block: stop at once and let the site rest
                self._failed(rule)
                return self._stale_or_raise(rule, page, Cooling(f"{rule.name} answered 403 (blocked); resting"))
            if r.status == 429 or r.status >= 500:
                last = f"HTTP {r.status}"
                wait = _retry_after(r.headers)
                self.sleep(min(COOL_CAP, wait) if wait is not None else min(BACKOFF_CAP, BACKOFF_BASE * 2 ** i))
                continue
            raise FetchFailed(f"{url}: HTTP {r.status}")
        self._failed(rule)
        return self._stale_or_raise(rule, page, FetchFailed(f"{url}: {last}"))

    def _cached(self, rule, page, stale=False):
        return Fetched(page["url"], rule.id, rule.name, page["status"], self.store.body(page), page["fetched_at"], True, stale)

    def _stale_or_raise(self, rule, page, err):
        if page and page["status"] == 200:
            return self._cached(rule, page, stale=True)
        raise err

    # ----------------------------------------------------------------------------------------------- site health
    def _cool_until(self, rule):
        row = self.store.site(rule.id)
        return (row or {}).get("cool_until") or 0.0

    def _healthy(self, rule):
        row = self.store.site(rule.id)
        if row and (row["fails"] or row["cool_until"]):
            self.store.set_health(rule.id, 0, 0.0)

    def _failed(self, rule):
        fails = ((self.store.site(rule.id) or {}).get("fails") or 0) + 1
        self.store.set_health(rule.id, fails, self.clock() + min(COOL_CAP, COOL_BASE * 2 ** (fails - 1)))

    # ----------------------------------------------------------------------------------------------- robots.txt
    def _robots_gate(self, rule, url):
        """Raise Disallowed when robots.txt forbids the link; return the site's Crawl-delay (0 when none)."""
        if not rule.robots:
            return 0.0
        row = self.store.site(rule.id) or {}
        if row.get("robots_at") is None or self.clock() - row["robots_at"] > ROBOTS_MAX_AGE:
            row = self._read_robots(rule, url)
        if row["robots_status"] >= 500:
            self._failed(rule)
            raise Disallowed(f"{rule.name}: robots.txt could not be read (HTTP {row['robots_status']}); not reading for now")
        if not robots.allowed(row["robots_txt"] or "", self.user_agent, url):
            raise Disallowed(f"{rule.name}: robots.txt disallows {url}")
        return row["crawl_delay"] or 0.0

    def _read_robots(self, rule, url):
        parts = urlsplit(url)
        robots_url = f"{parts.scheme}://{parts.netloc}/robots.txt"
        self.throttle.wait(rule.id, rule.min_interval)
        try:
            r = self.transport(robots_url, {"User-Agent": self.user_agent})
            status, text = r.status, (r.body or b"").decode("utf-8", "replace") if r.status == 200 else ""
        except Exception:
            status, text = 599, ""
        if status == 429:
            status = 503                                  # RFC 9309: treat like unreachable
        when = self.clock()
        if status >= 500:                                 # unreachable: refuse for now, ask again next time
            when = None
        self.store.save_robots(rule.id, text, status, when, robots.crawl_delay(text, self.user_agent))
        return self.store.site(rule.id)
