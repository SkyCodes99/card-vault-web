"""robots.txt reading (RFC 9309).  The text itself is kept per site by the store; this only answers 'may we read this link?'.
Own parser because the stdlib one treats '*' literally: here '*' matches any run of characters and a trailing '$' anchors the end;
the longest matching rule wins and Allow beats Disallow at equal length; the group of the most specific matching user-agent is used, else '*'."""
import re
from urllib.parse import urlsplit


def parse(text):
    """-> [(agents, rules, crawl_delay)] where rules = [(allow, pattern)]; consecutive User-agent lines share one group."""
    groups, agents, rules, delay, in_rules = [], [], [], None, False
    for raw in (text or "").splitlines():
        line = raw.split("#", 1)[0].strip()
        if ":" not in line:
            continue
        key, val = (s.strip() for s in line.split(":", 1))
        key = key.lower()
        if key == "user-agent":
            if in_rules:
                groups.append((agents, rules, delay))
                agents, rules, delay, in_rules = [], [], None, False
            agents.append(val.lower())
        elif key in ("allow", "disallow") and agents:
            in_rules = True
            if val:                                          # an empty Disallow allows everything: no rule
                rules.append((key == "allow", val))
        elif key == "crawl-delay" and agents:
            in_rules = True
            try:
                delay = float(val)
            except ValueError:
                pass
    if agents:
        groups.append((agents, rules, delay))
    return groups


def _group(groups, user_agent):
    """Merge every group whose agent is the longest product-token match of user_agent (else '*') -> (rules, delay)."""
    ua = (user_agent or "").lower()
    best, hits = -1, []
    for g in groups:
        for a in g[0]:
            if a == "*":
                score = 0
            elif a and a in ua:
                score = len(a)
            else:
                continue
            if score > best:
                best, hits = score, [g]
            elif score == best and g not in hits:
                hits.append(g)
    rules = [r for g in hits for r in g[1]]
    delays = [g[2] for g in hits if g[2] is not None]
    return rules, (delays[0] if delays else None)


def _matches(pattern, path):
    end = pattern.endswith("$")
    body = pattern[:-1] if end else pattern
    rx = ".*".join(re.escape(p) for p in body.split("*")) + ("$" if end else "")
    return re.match(rx, path) is not None


def allowed(text, user_agent, url):
    parts = urlsplit(url)
    path = (parts.path or "/") + ("?" + parts.query if parts.query else "")
    if path == "/robots.txt":
        return True
    rules, _ = _group(parse(text), user_agent)
    best_len, best_allow = -1, True
    for allow, pat in rules:
        if _matches(pat, path):
            n = len(pat)
            if n > best_len or (n == best_len and allow):
                best_len, best_allow = n, allow
    return best_allow


def crawl_delay(text, user_agent):
    try:
        d = _group(parse(text), user_agent)[1]
        return float(d) if d is not None else 0.0
    except (TypeError, ValueError):
        return 0.0
