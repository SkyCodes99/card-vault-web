"""Small per-site adapters: each one only knows its site's links and the shape of its answer.  All reading goes through
the shared Fetcher (politeness, cache, provenance).  Parsing of HTML pages into cards comes in later roadmap steps."""
from urllib.parse import quote_plus

from . import rules


class Adapter:
    def __init__(self, fetcher):
        self.fetcher = fetcher

    def get(self, url, max_age=None):
        return self.fetcher.get(url, max_age=max_age)


class Tcgdex(Adapter):
    BASE = "https://api.tcgdex.net/v2/{lang}"

    def __init__(self, fetcher, lang="en"):
        super().__init__(fetcher)
        self.base = self.BASE.format(lang=lang)

    def sets(self):
        return self.get(f"{self.base}/sets", max_age=6 * 3600)

    def set(self, set_id):
        return self.get(f"{self.base}/sets/{set_id}", max_age=6 * 3600)

    def card(self, card_id):
        return self.get(f"{self.base}/cards/{card_id}", max_age=24 * 3600)


class TcgCsv(Adapter):
    """TCGplayer catalog and prices via the tcgcsv daily mirror.  results() unwraps its {"results": [...]} envelope."""
    BASE = "https://tcgcsv.com/tcgplayer"
    DAY = 12 * 3600                                       # the mirror refreshes once a day

    @staticmethod
    def results(fetched):
        data = fetched.json() if fetched.status == 200 else None
        return (data or {}).get("results", []) if isinstance(data, dict) else []

    def categories(self):
        return self.get(f"{self.BASE}/categories", self.DAY)

    def groups(self, category):
        return self.get(f"{self.BASE}/{category}/groups", self.DAY)

    def products(self, category, group):
        return self.get(f"{self.BASE}/{category}/{group}/products", self.DAY)

    def prices(self, category, group):
        return self.get(f"{self.BASE}/{category}/{group}/prices", self.DAY)


class Scryfall(Adapter):
    """Scryfall bulk data (prices usd / usd_foil / usd_etched / eur / eur_foil / tix, ids).  Bulk files only, never per-card calls."""
    BULK = "https://api.scryfall.com/bulk-data"
    ACCEPT = {"Accept": "application/json;q=0.9,*/*;q=0.8"}
    DAY = 20 * 3600

    def bulk_list(self):
        return self.fetcher.get(self.BULK, max_age=3600, headers=self.ACCEPT)

    def bulk(self, kind="default_cards"):
        """-> (Fetched of the newest jsonl.gz file of that kind, its updated_at) or (None, None) when Scryfall does not list it."""
        got = self.bulk_list()
        entries = (got.json() or {}).get("data", []) if got.status == 200 else []
        e = next((x for x in entries if x.get("type") == kind), None)
        uri = e and (e.get("jsonl_download_uri") or e.get("download_uri"))
        return (self.fetcher.get(uri, max_age=self.DAY), e.get("updated_at")) if uri else (None, None)


class MtgJson(Adapter):
    """MTGJSON daily files (compressed): prices of today and the TCGplayer product id of every card."""
    BASE = "https://mtgjson.com/api/v5"
    DAY = 20 * 3600

    def meta(self):
        return self.get(f"{self.BASE}/Meta.json", max_age=3600)

    def prices_today(self):
        return self.get(f"{self.BASE}/AllPricesToday.json.gz", self.DAY)

    def tcgplayer_skus(self):
        return self.get(f"{self.BASE}/TcgplayerSkus.json.gz", self.DAY)


class PokeCottage(Adapter):
    BASE = "https://pokecottage.com"
    LIBRARY = BASE + "/card-list-library"                 # TODO(1.x): confirm the exact library path on the live site

    def library(self):
        return self.get(self.LIBRARY, max_age=7 * 24 * 3600)

    def page(self, path):
        return self.get(self.BASE + "/" + path.lstrip("/"), max_age=7 * 24 * 3600)


class HobbyBin(Adapter):
    BASE = "https://thehobbybin.com"

    def page(self, path):
        return self.get(self.BASE + "/" + path.lstrip("/"), max_age=7 * 24 * 3600)

    INDEX = {"lorcana": "pages/all-disney-lorcana-sets", "mtg": "pages/all-magic-sets"}       # each game's list of sets

    def index(self, game):
        return self.page(self.INDEX[game])

    def price_guide(self, slug):
        """One set's full card table (number, name, rarity, picture): parsed by hobbybin_pages.parse_price_guide."""
        return self.page(f"pages/{slug}-price-guide")


class MakerShop(Adapter):
    """A maker's own shop with the public Shopify feed (products.json).  Registers a careful rule for its host."""

    def __init__(self, fetcher, shop_id, name, base, min_interval=5.0):
        super().__init__(fetcher)
        self.base = base.rstrip("/")
        host = rules.host_of(self.base)
        hosts = (host, host[4:]) if host.startswith("www.") else (host, "www." + host)
        self.rule = rules.add(rules.SiteRule(shop_id, name, hosts, min_interval, "data", rules.MAKER.terms, self.base))

    def products(self, page=1, limit=250):
        return self.get(f"{self.base}/products.json?limit={limit}&page={page}", max_age=24 * 3600)

    @staticmethod
    def items(fetched):
        data = fetched.json() if fetched.status == 200 else None
        return (data or {}).get("products", []) if isinstance(data, dict) else []


class HobbyDb(Adapter):
    """Links only: builds hobbyDB links for the Shop / reference sections.  get() raises LinksOnly until rules.grant('hobbydb')."""
    BASE = "https://www.hobbydb.com"

    def search_link(self, query):                         # TODO(1.x): confirm the search link shape on the live site
        return f"{self.BASE}/marketplaces/hobbydb/catalog_items?filters[q][0]={quote_plus(query)}"
