"""One reader for every source site (roadmap step 1.1).

    from cardvault import sources
    f = sources.default()                       # shared polite Fetcher (cache under %LOCALAPPDATA%\\Collect Em All\\sources)
    got = sources.TcgCsv(f).groups(3)            # -> Fetched; got.provenance() = {source, source_name, url, fetched_at}

Modules: rules (per-site rules table), transport (the only network call), throttle (rate limit), robots (robots.txt),
store (on-disk cache + what was fetched, when, from where), fetcher (the polite loop), adapters (per-site links).

TODO(1.1 follow-up): cardvault/sync._get and cardvault/tcgsync.fetch_get still call requests directly; they feed the
live daily job (tools/daily_update.py), so they move onto this Fetcher in a separate, tested change."""
import os
import threading

from .adapters import HobbyBin, HobbyDb, MakerShop, MtgJson, PokeCottage, Scryfall, TcgCsv, Tcgdex  # noqa: F401
from .fetcher import Cooling, Disallowed, FetchFailed, Fetched, Fetcher, LinksOnly, SourceError  # noqa: F401
from .rules import SITES, SiteRule, grant, rule_for  # noqa: F401

_default = None
_lock = threading.Lock()


def cache_dir():
    if os.environ.get("CEA_SOURCES_CACHE"):                       # a lane or test keeps its pages in its own folder
        return os.environ["CEA_SOURCES_CACHE"]
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("XDG_CACHE_HOME") or os.path.join(os.path.expanduser("~"), ".cache")
    return os.path.join(base, "Collect Em All", "sources")


def default():
    """The shared Fetcher for this process (one rate limit per site across every caller)."""
    global _default
    with _lock:
        if _default is None:
            _default = Fetcher(cache_dir())
        return _default
