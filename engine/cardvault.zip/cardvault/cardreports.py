"""PLAYER REPORTS OF A PROBLEM WITH A CARD: "no picture", "wrong info", ... so the checker looks at that item first.
The rules (owner 2026-11-13) are kept in ONE place, here; the server (docs/skycloud_request_card_reports.md) repeats them and is the one that counts across players:
  - one report per item per person;  - at most MAX_PER_PERIOD reports per person per PERIOD_HOURS;
  - once an item has ITEM_CAP reports between two checker runs, more are silently ignored (the reporter still sees "Thanks, reported").
This module is the device half: what I already reported (shows "Reported"), a local copy of the limits (so nobody waits for the server to be told no), and an outbox - a report made offline, or while
the server lacks the endpoint, waits as "pending" and is sent when it can be.  Kept as one account setting (so it follows the account), never an email: the server knows the username from the token."""
import json
import time

MAX_PER_PERIOD = 20                   # reports one person may send per PERIOD_HOURS (any items)
PERIOD_HOURS = 24
ITEM_CAP = 5                          # reports of one item counted between two checker runs; the rest are ignored by the server without telling anybody
NOTE_MAX = 200
REASONS = {"no_picture": "No picture", "wrong_picture": "Wrong picture", "wrong_info": "Wrong name, number or set", "wrong_price": "Wrong price",
           "duplicate": "Duplicate of another item", "fake": "Doesn't exist or is fake", "other": "Something else"}
KEY = "card_reports"


def load(svc):
    try:
        d = json.loads(svc.pget(KEY) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _save(svc, d):
    svc.pset(KEY, json.dumps(d, ensure_ascii=False))


def _k(game, item_id):
    return f"{game}:{item_id}"


def reported(svc, game):
    """The item ids of this game that I already reported."""
    return sorted(r["id"] for r in load(svc).values() if r.get("game") == game)


def left(svc, now=None):
    now = now or time.time()
    used = sum(1 for r in load(svc).values() if now - r.get("at", 0) < PERIOD_HOURS * 3600)
    return max(0, MAX_PER_PERIOD - used)


def add(svc, game, item_id, reason, note="", name="", now=None):
    """Remember a report (state 'pending' until the server has it).  -> "new" | "already".  Raises ValueError (a sentence for the person) over the limit / for a bad reason."""
    if reason not in REASONS:
        raise ValueError("Pick what is wrong with it.")
    d = load(svc)
    k = _k(game, item_id)
    if k in d:
        return "already"
    if left(svc, now) <= 0:
        raise ValueError(f"You have sent {MAX_PER_PERIOD} reports in the last day - thank you. Please try again tomorrow.")
    d[k] = {"game": game, "id": str(item_id), "reason": reason, "note": (note or "").strip()[:NOTE_MAX], "name": (name or "")[:120], "at": now or time.time(), "state": "pending"}
    _save(svc, d)
    return "new"


def flush(svc, a):
    """Send the pending reports, oldest first, through the signed-in account `a`.  -> {"available": True | False | None (not reachable now), "sent": n}.
    404 = the server has no such endpoint yet (they stay pending); 429 / no connection = try again later; a refusal of the report itself (400) drops the wait: sending it again would never help."""
    from .cloud import skycloud as sc
    d = load(svc)
    todo = sorted((r for r in d.values() if r.get("state") == "pending"), key=lambda r: r.get("at", 0))
    sent, avail = 0, True
    for r in todo:
        try:
            a.call("POST", "/v1/reports", {"game": r["game"], "item_id": r["id"], "reason": r["reason"], "note": r["note"], "name": r["name"]}, timeout=20)
        except sc.CloudError as e:
            if e.status in (400, 409, 422):                    # refused for good: do not keep sending it
                r["state"] = "sent"
                continue
            avail = False if e.status == 404 else None
            break
        r["state"] = "sent"
        sent += 1
    if todo:
        _save(svc, d)
    return {"available": avail, "sent": sent}


def probe(a):
    """Does the server take reports?  -> True | False (404) | None (cannot tell now)."""
    from .cloud import skycloud as sc
    try:
        a.call("GET", "/v1/reports/mine", None, timeout=15)
        return True
    except sc.CloudError as e:
        return False if e.status == 404 else None
