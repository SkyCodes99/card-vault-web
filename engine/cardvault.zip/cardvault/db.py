"""Local storage.

Data folder layout:
  collection.db                  YOUR data for every game and every local user. Saved after every single change
                                 (WAL + synchronous FULL), with an append-only change journal and automatic backups.
  games/<game>/cards.db          the downloaded card catalogue of one game (rebuildable; updates only touch this)
  games/<game>/images/<q>/...    card pictures
  backups/                       rolling copies of collection.db

Every user record carries user_id + uuid + updated_at + deleted so the same data can later be synced to an online service
and shared between several accounts.
"""
import contextlib
import csv
import datetime
import json
import os
import re
import shutil
import sqlite3
import uuid as _uuid
from urllib.parse import quote

from . import taxonomy

CONDITIONS = ["Near Mint", "Lightly Played", "Moderately Played", "Heavily Played", "Damaged"]
GRADERS = ["PSA", "BGS", "CGC", "SGC", "TAG", "ACE", "AGS", "Other"]
VARIANT_FLAGS = ("normal", "reverse", "holo", "firstEdition", "wPromo")
VARIANT_LABELS = {
    "normal": "Normal",
    "reverse": "Reverse Holo",
    "holo": "Holo",
    "firstEdition": "1st Edition",
    "wPromo": "W Promo",
}
LOCAL_USER = "local"
USER_SCHEMA_VERSION = 3

CARDS_SCHEMA = """
CREATE TABLE IF NOT EXISTS sets(
    id TEXT PRIMARY KEY, name TEXT, serie TEXT, release_date TEXT,
    total INTEGER, official INTEGER, logo TEXT);
CREATE TABLE IF NOT EXISTS cards(
    id TEXT PRIMARY KEY, set_id TEXT, local_id TEXT, sort_key INTEGER, name TEXT,
    image_base TEXT, detailed INTEGER DEFAULT 0,
    category TEXT, rarity TEXT, hp INTEGER, types TEXT, illustrator TEXT,
    stage TEXT, evolve_from TEXT, description TEXT,
    price_usd REAL, price_eur REAL, variants TEXT, raw TEXT, dex TEXT, price_updated TEXT);
CREATE INDEX IF NOT EXISTS cards_set ON cards(set_id, sort_key);
CREATE INDEX IF NOT EXISTS cards_name ON cards(name);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS sealed_products(
    id TEXT PRIMARY KEY, set_id TEXT, set_name TEXT, name TEXT, norm TEXT, image_base TEXT, price_usd REAL, price_kind TEXT, price_updated TEXT, released TEXT);
CREATE INDEX IF NOT EXISTS sealed_norm ON sealed_products(norm);
"""


def now_iso():
    """UTC with microseconds ('2026-10-10T01:02:03.123456Z'): sortable as text, comparable between devices in different time zones."""
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def today():
    return datetime.date.today().isoformat()


def new_uuid():
    return _uuid.uuid4().hex


def game_dir(data_dir, game):
    return os.path.join(data_dir, "games", game)


def migrate_layout(data_dir):
    """v1.0.0 kept cards.db + images directly in the data folder; move them under games/pokemon."""
    old_db = os.path.join(data_dir, "cards.db")
    gdir = game_dir(data_dir, "pokemon")
    if os.path.exists(old_db) and not os.path.exists(os.path.join(gdir, "cards.db")):
        os.makedirs(gdir, exist_ok=True)
        for suffix in ("", "-wal", "-shm"):
            src = old_db + suffix
            if os.path.exists(src):
                shutil.move(src, os.path.join(gdir, "cards.db" + suffix))
        old_img = os.path.join(data_dir, "images")
        if os.path.isdir(old_img) and not os.path.exists(os.path.join(gdir, "images")):
            shutil.move(old_img, os.path.join(gdir, "images"))


def _ensure_column(conn, table, name, ddl):
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
    if name not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")


def init_cards_schema(conn):
    conn.executescript(CARDS_SCHEMA)
    _ensure_column(conn, "cards", "dex", "TEXT")
    _ensure_column(conn, "cards", "price_updated", "TEXT")
    _ensure_column(conn, "cards", "price_kind", "TEXT")
    _ensure_column(conn, "sealed_products", "released", "TEXT")
    _ensure_column(conn, "cards", "tcg_id", "TEXT")
    conn.execute("CREATE INDEX IF NOT EXISTS cards_tcg ON cards(tcg_id)")
    _ensure_column(conn, "cards", "art_score", "REAL")
    conn.commit()


def open_cards_conn(gdir):
    os.makedirs(gdir, exist_ok=True)
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    init_cards_schema(conn)
    return conn


def sort_key(local_id):
    m = re.search(r"\d+", local_id or "")
    return int(m.group()) if m else 100000


def fix_text(s):
    """TCGdex has a few mojibake strings (e.g. 'Ã—2' for '×2')."""
    if not isinstance(s, str):
        return s
    if "Ã" in s or "â" in s:
        try:
            return s.encode("cp1252").decode("utf-8")
        except (UnicodeError, ValueError):
            return s
    return s


def image_file(gdir, quality, card_id, set_id):
    return os.path.join(gdir, "images", quality, set_id, quote(card_id, safe="-._") + ".webp")


_NUMTOK = re.compile(r"^(#)?(\d{1,4})(?:/(\d{1,4}))?$")


def _fold(s):
    """Lower case, no accents, straight apostrophes: what search compares (so 'pokemon' finds 'Pokémon' and "farfetchd" finds "Farfetch'd")."""
    import unicodedata
    s = unicodedata.normalize("NFKD", str(s if s is not None else "")).encode("ascii", "ignore").decode().lower()
    return s.replace("’", "'")


def picture_url(base, quality="low"):
    """The web address of a card picture from what the card list stores: a TCGdex base (the size is appended) or a TCGplayer picture address (a finished address)."""
    if not base:
        return ""
    if base.startswith("https://tcgplayer-cdn.tcgplayer.com/"):
        return base.replace("_200w", "_400w") if quality == "high" else base
    if base.endswith((".jpg", ".png", ".jpeg", ".webp")):
        return base
    return f"{base}/{quality}.webp"


def logo_file(gdir, set_id):
    return os.path.join(gdir, "images", "logos", quote(set_id, safe="-._") + ".webp")


def dex_from_raw(raw_json):
    try:
        d = json.loads(raw_json or "{}").get("dexId")
    except ValueError:
        return None
    if isinstance(d, list) and d:
        return ",".join(str(int(x)) for x in d)
    return None


def edition_of(serie):
    """Which spot a set lives in: the digital TCG Pocket sets are kept apart from the physical card game."""
    return "pocket" if "pocket" in (serie or "").lower() else "tcg"


def taxonomy_rank(rarity, order):
    low = (rarity or "").lower()
    o = [x.lower() for x in order]
    for i, x in enumerate(o):
        if low == x or low.startswith(x + " "):
            return i
    return len(o)


class _Action:
    """Everything one user action changed, with the inverse of each change - so it can be undone."""

    def __init__(self, label=None):
        self.label, self.ops, self.id = label, [], None


class Vault:
    """One game's catalogue plus the current local user's collection."""

    def __init__(self, data_dir, game="pokemon", user_id=LOCAL_USER, user_path=None, secure=None):
        self.data_dir = data_dir
        self.secure = secure          # an unlocked account (cardvault.security): backups are then always encrypted
        self.game = game
        self.user_id = user_id
        self._defer = False
        self._index = None
        self._cl_rev = 0
        self._members_cache = {}
        self._changes_since_backup = 0
        self._act = None
        self._suppress = False
        os.makedirs(data_dir, exist_ok=True)
        migrate_layout(data_dir)
        self.gdir = game_dir(data_dir, game)
        self.conn = open_cards_conn(self.gdir)
        self.user_path = user_path or os.path.join(data_dir, "collection.db")
        self.conn.execute("ATTACH DATABASE ? AS u", (self.user_path,))
        self.conn.execute("PRAGMA u.journal_mode=WAL")
        self.conn.execute("PRAGMA u.synchronous=FULL")
        self._user_migrate()
        self.scope = None                 # None = every portfolio; else the portfolio ids (''=Main) that are currently shown
        self.target_pf = ""               # where new copies go
        self._init_scope()
        self._backfill_dex()
        self._register_taxonomy()
        self._auto_import_categories()
        self._index = None
        self._cl_rev = 0
        self._members_cache = {}
        self._changes_since_backup = 0

    def _init_scope(self):
        c = self.conn
        c.execute("CREATE TEMP TABLE IF NOT EXISTS scope(pf TEXT PRIMARY KEY)")
        c.execute("DROP VIEW IF EXISTS temp.lots_s")
        c.execute("CREATE TEMP VIEW lots_s AS SELECT * FROM u.lots l WHERE NOT EXISTS(SELECT 1 FROM temp.scope) OR COALESCE(l.portfolio,'') IN (SELECT pf FROM temp.scope)")
        c.commit()

    def set_scope(self, ids):
        """Show only these portfolios (list of ids, '' = Main); None / empty = everything."""
        ids = [i for i in (ids or [])]
        self.scope = ids or None
        self.conn.execute("DELETE FROM temp.scope")
        for i in ids:
            self.conn.execute("INSERT OR IGNORE INTO temp.scope VALUES(?)", (i,))
        self._commit()            # writing the temp table opens a transaction; ending it keeps later reads from seeing an old snapshot of the collection
        self.target_pf = ids[0] if len(ids) == 1 else (self.target_pf if self.target_pf in ids else (ids[0] if ids else self.target_pf))

    # ---- portfolios
    def portfolios(self):
        rows = [dict(r) for r in self.conn.execute("SELECT * FROM u.portfolios WHERE user_id=? AND deleted=0 ORDER BY created_at, name", (self.user_id,))]
        return rows

    def create_portfolio(self, name, color=""):
        u = new_uuid()
        self.conn.execute("INSERT INTO u.portfolios(uuid,user_id,name,color,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,0)",
                          (u, self.user_id, name.strip(), color, now_iso(), now_iso()))
        self.log("portfolio.add", "portfolio", u, {"name": name})
        self._commit()
        return u

    def update_portfolio(self, uuid, name=None, color=None):
        r = self.conn.execute("SELECT * FROM u.portfolios WHERE uuid=? AND user_id=?", (uuid, self.user_id)).fetchone()
        if not r:
            return
        self.conn.execute("UPDATE u.portfolios SET name=?, color=?, updated_at=? WHERE uuid=?",
                          (r["name"] if name is None else name.strip(), r["color"] if color is None else color, now_iso(), uuid))
        self._commit()

    def delete_portfolio(self, uuid, move_to=""):
        """Removes the portfolio; its copies move to another one (Main by default) - nothing you own is ever deleted."""
        self.conn.execute("UPDATE u.lots SET portfolio=?, updated_at=? WHERE user_id=? AND portfolio=?", (move_to, now_iso(), self.user_id, uuid))
        self.conn.execute("UPDATE u.portfolios SET deleted=1, updated_at=? WHERE uuid=? AND user_id=?", (now_iso(), uuid, self.user_id))
        self.log("portfolio.delete", "portfolio", uuid, {})
        self._commit()

    # ---- trade log
    def log_trade(self, partner, notes, data):
        u = new_uuid()
        self.conn.execute("INSERT INTO u.trades(uuid,user_id,game,ts,partner,notes,data,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,0)",
                          (u, self.user_id, self.game, now_iso(), partner or "", notes or "", json.dumps(data, default=str), now_iso()))
        self.log("trade.add", "trade", u, {"partner": partner})
        self._commit()
        return u

    def trades(self, limit=200):
        out = []
        for r in self.conn.execute("SELECT * FROM u.trades WHERE user_id=? AND game=? AND deleted=0 ORDER BY ts DESC LIMIT ?", (self.user_id, self.game, limit)):
            d = dict(r)
            try:
                d["data"] = json.loads(d["data"] or "{}")
            except ValueError:
                d["data"] = {}
            out.append(d)
        return out

    def delete_trade(self, uuid):
        self.conn.execute("UPDATE u.trades SET deleted=1, updated_at=? WHERE uuid=? AND user_id=?", (now_iso(), uuid, self.user_id))
        self._commit()

    def portfolio_stats(self):
        """{portfolio id: {copies, unique, value, spent}} across ALL portfolios (ignores the current view)."""
        out = {}
        for pid, copies, unique, value, spent in self.conn.execute(
                "SELECT COALESCE(l.portfolio,''), SUM(l.qty), COUNT(DISTINCT l.card_id), SUM(l.qty*COALESCE(c.price_usd,0)), "
                "SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty*l.purchase_price ELSE 0 END) FROM u.lots l JOIN cards c ON c.id=l.card_id "
                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY COALESCE(l.portfolio,'')", (self.user_id, self.game)):
            out[pid] = {"copies": copies or 0, "unique": unique or 0, "value": value or 0, "spent": spent or 0}
        return out

    def close(self):
        try:
            self._commit()
            self.conn.close()
        except sqlite3.Error:
            pass

    # ------------------------------------------------------------------ schema / migration
    def _user_migrate(self):
        c = self.conn
        existing = {r[0] for r in c.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}
        ver = c.execute("PRAGMA u.user_version").fetchone()[0]
        if "lots" in existing and ver < 2:
            # v1.0.0 layout: single user, single game.  Add the multi-user / sync columns in place.
            cols = {r[1] for r in c.execute("PRAGMA u.table_info(lots)")}
            for name, ddl in (("uuid", "TEXT"), ("user_id", f"TEXT DEFAULT '{LOCAL_USER}'"), ("game", "TEXT DEFAULT 'pokemon'"),
                              ("updated_at", "TEXT"), ("deleted", "INTEGER DEFAULT 0")):
                if name not in cols:
                    c.execute(f"ALTER TABLE u.lots ADD COLUMN {name} {ddl}")
            for (lid,) in c.execute("SELECT id FROM u.lots WHERE uuid IS NULL").fetchall():
                c.execute("UPDATE u.lots SET uuid=?, updated_at=COALESCE(added, ?) WHERE id=?", (new_uuid(), now_iso(), lid))
        if "wishlist" in existing and ver < 2:
            cols = {r[1] for r in c.execute("PRAGMA u.table_info(wishlist)")}
            if "user_id" not in cols:
                c.execute("ALTER TABLE u.wishlist RENAME TO wishlist_v1")
                existing.discard("wishlist")
        c.executescript(f"""
CREATE TABLE IF NOT EXISTS u.users(id TEXT PRIMARY KEY, name TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS u.lots(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT DEFAULT '{LOCAL_USER}', game TEXT DEFAULT 'pokemon',
    card_id TEXT NOT NULL, variant TEXT, condition TEXT, language TEXT DEFAULT 'English', qty INTEGER NOT NULL,
    graded INTEGER DEFAULT 0, grade_company TEXT, grade TEXT, purchase_price REAL, notes TEXT, added TEXT,
    updated_at TEXT, deleted INTEGER DEFAULT 0, cert TEXT, location TEXT, edition TEXT);
CREATE INDEX IF NOT EXISTS u.lots_card ON lots(user_id, game, card_id);
CREATE TABLE IF NOT EXISTS u.wishlist(
    user_id TEXT, game TEXT, card_id TEXT, note TEXT, added TEXT, PRIMARY KEY(user_id, game, card_id));
CREATE TABLE IF NOT EXISTS u.checklists(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT, game TEXT, name TEXT, mode TEXT DEFAULT 'cards',
    per_variant INTEGER DEFAULT 0, rules TEXT, notes TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.checklist_items(
    checklist_id INTEGER, card_id TEXT, source TEXT, PRIMARY KEY(checklist_id, card_id));
CREATE TABLE IF NOT EXISTS u.journal(
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, user_id TEXT, game TEXT, action TEXT, entity TEXT, entity_uuid TEXT, details TEXT);
CREATE TABLE IF NOT EXISTS u.price_history(
    game TEXT, card_id TEXT, day TEXT, usd REAL, eur REAL, PRIMARY KEY(game, card_id, day));
CREATE TABLE IF NOT EXISTS u.snapshots(
    user_id TEXT, game TEXT, day TEXT, ts TEXT, total_usd REAL, total_eur REAL, copies INTEGER, unique_cards INTEGER,
    breakdown TEXT, PRIMARY KEY(user_id, game, day));
CREATE TABLE IF NOT EXISTS u.settings(
    user_id TEXT, game TEXT, key TEXT, value TEXT, PRIMARY KEY(user_id, game, key));
CREATE TABLE IF NOT EXISTS u.custom_groups(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT, game TEXT, key TEXT, label TEXT, section TEXT, help TEXT, rules TEXT,
    counts_as_art INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.checklist_picks(
    checklist_id INTEGER, slot_key TEXT, card_id TEXT, PRIMARY KEY(checklist_id, slot_key));
CREATE TABLE IF NOT EXISTS u.tombstones(
    user_id TEXT, game TEXT, kind TEXT, key TEXT, deleted_at TEXT, PRIMARY KEY(user_id, game, kind, key));
CREATE TABLE IF NOT EXISTS u.actions(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, game TEXT, ts TEXT, label TEXT, count INTEGER, ops TEXT, undone INTEGER DEFAULT 0, undone_at TEXT);
CREATE TABLE IF NOT EXISTS u.spending(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT, game TEXT, day TEXT, amount_usd REAL, category TEXT, note TEXT,
    deleted INTEGER DEFAULT 0, updated_at TEXT);
CREATE TABLE IF NOT EXISTS u.card_tags(
    user_id TEXT, game TEXT, card_id TEXT, tag TEXT, value TEXT, updated_at TEXT, PRIMARY KEY(user_id, game, card_id, tag));
CREATE TABLE IF NOT EXISTS u.portfolios(
    uuid TEXT PRIMARY KEY, user_id TEXT, name TEXT, color TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.trades(
    uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, ts TEXT, partner TEXT, notes TEXT, data TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.lot_photos(
    id INTEGER PRIMARY KEY AUTOINCREMENT, lot_uuid TEXT, side TEXT, data BLOB, added TEXT);
CREATE INDEX IF NOT EXISTS u.photos_lot ON lot_photos(lot_uuid);
CREATE TABLE IF NOT EXISTS u.photo_deleted(key TEXT PRIMARY KEY, at TEXT);
CREATE TABLE IF NOT EXISTS u.set_value_history(game TEXT, set_id TEXT, day TEXT, total REAL, owned REAL, priced INTEGER, n INTEGER, PRIMARY KEY(game, set_id, day));
CREATE TABLE IF NOT EXISTS u.sealed(
    uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, upc TEXT, name TEXT, qty INTEGER, paid REAL, purchased TEXT, source TEXT, notes TEXT, portfolio TEXT,
    updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.upc_names(upc TEXT PRIMARY KEY, name TEXT);
CREATE TABLE IF NOT EXISTS u.dream_binders(
    uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, name TEXT, rows INTEGER, cols INTEGER, pages INTEGER, slots TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.shares(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, token TEXT, user_id TEXT, game TEXT, title TEXT, kind TEXT, scope TEXT,
    perms TEXT, expires_at TEXT, created_at TEXT, updated_at TEXT, revoked INTEGER DEFAULT 0, published_url TEXT);
""")
        lot_cols = {r[1] for r in c.execute("PRAGMA u.table_info(lots)")}
        for col in ("cert", "location", "edition", "purchased", "source", "portfolio"):
            if col not in lot_cols:
                c.execute(f"ALTER TABLE u.lots ADD COLUMN {col} TEXT")
        if "wishlist_v1" in {r[0] for r in c.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}:
            c.execute(f"INSERT OR IGNORE INTO u.wishlist(user_id,game,card_id,note,added) "
                      f"SELECT '{LOCAL_USER}','pokemon',card_id,note,added FROM u.wishlist_v1")
            c.execute("DROP TABLE u.wishlist_v1")
        c.execute("INSERT OR IGNORE INTO u.users VALUES(?,?,?)", (LOCAL_USER, "Me", now_iso()))
        c.execute(f"PRAGMA u.user_version={USER_SCHEMA_VERSION}")
        c.commit()

    def _backfill_dex(self):
        rows = self.conn.execute("SELECT id, raw FROM cards WHERE detailed=1 AND dex IS NULL AND raw IS NOT NULL").fetchall()
        if not rows:
            return
        for r in rows:
            self.conn.execute("UPDATE cards SET dex=? WHERE id=?", (dex_from_raw(r["raw"]) or "", r["id"]))
        self._commit()

    # ------------------------------------------------------------------ journal / backups
    def log(self, action, entity, entity_uuid="", details=None):
        self.conn.execute("INSERT INTO u.journal(ts,user_id,game,action,entity,entity_uuid,details) VALUES(?,?,?,?,?,?,?)",
                          (now_iso(), self.user_id, self.game, action, entity, entity_uuid, json.dumps(details or {}, default=str)))
        self._changes_since_backup += 1

    def _commit(self):
        if not self._defer:
            self.conn.commit()

    def commit(self):
        self.conn.commit()

    def backup_dir(self):
        d = self.secure.backup_dir() if self.secure else os.path.join(self.data_dir, "backups")
        os.makedirs(d, exist_ok=True)
        return d

    def backup_now(self, reason="auto", extra_dir=None):
        """Consistent copy of collection.db (SQLite online-backup API).  Returns the file path."""
        self._commit()
        name = f"collection-{datetime.datetime.now():%Y%m%d-%H%M%S}-{reason}.db"
        paths = []
        plain = None
        if self.secure:                        # one readable copy, in the private working folder only, encrypted into every backup folder
            import tempfile
            from .security import crypto
            fd, plain = tempfile.mkstemp(suffix=".db", dir=os.path.dirname(self.user_path))
            os.close(fd)
            src = sqlite3.connect(self.user_path)
            dest = sqlite3.connect(plain)
            try:
                src.backup(dest)
            finally:
                dest.close()
                src.close()
        try:
            for d in filter(None, (self.backup_dir(), extra_dir)):
                try:
                    os.makedirs(d, exist_ok=True)
                    if self.secure:
                        paths.append(self.secure.write_backup(plain, d, name))
                        continue
                    dest_path = os.path.join(d, name)
                    src = sqlite3.connect(self.user_path)
                    dest = sqlite3.connect(dest_path)
                    try:
                        src.backup(dest)
                    finally:
                        dest.close()
                        src.close()
                    paths.append(dest_path)
                except (OSError, sqlite3.Error):
                    continue
        finally:
            if plain:
                crypto.wipe_file(plain)
        self._changes_since_backup = 0
        self.prune_backups()
        return paths[0] if paths else None

    def list_backups(self):
        d = self.backup_dir()
        ext = ".db.enc" if self.secure else ".db"
        files = [os.path.join(d, f) for f in os.listdir(d) if f.startswith("collection-") and f.endswith(ext)]
        return sorted(files, reverse=True)

    def prune_backups(self, keep=60):
        for f in self.list_backups()[keep:]:
            try:
                os.remove(f)
            except OSError:
                pass

    def auto_backup_if_needed(self, max_age_minutes=60, extra_dir=None):
        files = self.list_backups()
        if files:
            age = datetime.datetime.now().timestamp() - os.path.getmtime(files[0])
            if age < max_age_minutes * 60:
                return None
        return self.backup_now("auto", extra_dir)

    def integrity_ok(self):
        try:
            return self.conn.execute("PRAGMA u.integrity_check").fetchone()[0] == "ok"
        except sqlite3.Error:
            return False

    # ------------------------------------------------------------------ catalogue
    def card_count(self):
        return self.conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]

    def meta(self, key, default=""):
        r = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return r[0] if r else default

    def set_meta(self, key, value):
        self.conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (key, value))
        self._commit()

    def invalidate_index(self):
        self._index = None
        self._cl_rev += 1

    def sets(self, edition=None):
        rows = self.conn.execute(
            "SELECT s.*, (SELECT COUNT(*) FROM cards c WHERE c.set_id=s.id) AS n "
            "FROM sets s ORDER BY release_date DESC, name").fetchall()
        return [r for r in rows if edition_of(r["serie"]) == edition] if edition else rows

    def card(self, card_id):
        return self.conn.execute(
            "SELECT c.*, s.name AS set_name, s.official AS set_official, s.total AS set_total, s.serie AS serie, "
            "s.release_date AS release_date FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id=?", (card_id,)).fetchone()

    # ---- the classification of every card is saved, so opening a set doesn't redo ~24,000 rule checks every time the app starts
    def _class_key(self, tags, thr):
        import hashlib
        n, art = self.conn.execute("SELECT COUNT(*), COALESCE(SUM(art_score),0) FROM cards").fetchone()
        return hashlib.sha1(f"{taxonomy.VERSION}|{n}|{round(art, 3)}|{thr}|{json.dumps(tags, sort_keys=True)}".encode()).hexdigest()

    def _load_class_cache(self, tags, thr):
        try:
            key = self._class_key(tags, thr)
            r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game=? AND key='class_cache'", (self.user_id, self.game)).fetchone()
            if not r:
                return None
            data = json.loads(r[0])
            if data.get("key") != key:
                return None
            vocab = data["vocab"]
            return {cid: frozenset(vocab[i] for i in idxs) for cid, idxs in data["cards"].items()}
        except (ValueError, KeyError, sqlite3.Error):
            return None

    def _save_class_cache(self, tags, thr):
        try:
            vocab, pos, cards = [], {}, {}
            for c in self._index:
                ids = []
                for g in c["groups"]:
                    if g not in pos:
                        pos[g] = len(vocab)
                        vocab.append(g)
                    ids.append(pos[g])
                cards[c["id"]] = ids
            self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)",
                              (self.user_id, self.game, "class_cache", json.dumps({"key": self._class_key(tags, thr), "vocab": vocab, "cards": cards}, separators=(",", ":"))))
            self._commit()
        except sqlite3.Error:
            pass

    def card_index(self):
        """Every card as a light dict; used by checklist rules, progress and exports."""
        if self._index is None:
            rows = self.conn.execute(
                "SELECT c.id, c.set_id, c.local_id, c.sort_key, c.name, c.rarity, c.category, c.types, c.dex, c.illustrator, "
                "c.price_usd, c.price_kind, c.tcg_id, c.price_eur, c.variants, c.hp, c.art_score, s.name AS set_name, s.serie, s.release_date, s.official "
                "FROM cards c LEFT JOIN sets s ON s.id=c.set_id ORDER BY s.release_date DESC, c.set_id, c.sort_key, c.local_id")
            self._index = [dict(r) for r in rows]
            self._index_by_id = {c["id"]: c for c in self._index}
            self._register_taxonomy()
            tags = self.card_tags()
            thr = self.art_threshold()
            pokemon = taxonomy.is_pokemon()
            cached = self._load_class_cache(tags, thr) if pokemon else None
            if cached is None:
                ancient = {r[0] for r in self.conn.execute("SELECT id FROM cards WHERE INSTR(raw, 'Ancient Trait') > 0")} if pokemon else set()
            for c in self._index:
                if cached is not None and c["id"] in cached:
                    c["groups"] = cached[c["id"]]
                else:
                    c["ancient"] = c["id"] in ancient if cached is None else False
                    c["groups"] = taxonomy.classify(c, tags.get(c["id"]), thr) if pokemon else taxonomy.classify_generic(c)
                c["edition"] = edition_of(c.get("serie"))
            if pokemon and cached is None:
                self._save_class_cache(tags, thr)
            self._apply_custom_groups(tags)
            self._group_ids = {}
            ill, dex = {}, {}
            for c in self._index:
                if c.get("illustrator"):
                    ill.setdefault(c["illustrator"], []).append(c["id"])
                for d in (c.get("dex") or "").split(","):
                    if d.strip().isdigit():
                        dex.setdefault(int(d), []).append(c["id"])
            self._facets = {"illustrator": ill, "dex": dex}
            self._facets_ed = {}
        return self._index

    # ---- card groups (taxonomy) and the user's per-card overrides
    def get_setting(self, key, default=None):
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game=? AND key=?", (self.user_id, self.game, key)).fetchone()
        return r[0] if r else default

    def excluded_cards(self, set_id=None):
        """Cards the person left out of a set (their own custom master set): {set id: {card ids}}, or just one set's ids."""
        try:
            d = json.loads(self.get_setting("master_excluded") or "{}")
        except ValueError:
            d = {}
        d = {k: set(v) for k, v in d.items() if isinstance(v, list)}
        return d.get(set_id, set()) if set_id is not None else d

    def look_get(self):
        """The look (theme, accent...) that follows the account to every device.  Stored once per person, not per game ('*')."""
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game='*' AND key='look'", (self.user_id,)).fetchone()
        try:
            d = json.loads(r[0]) if r else {}
        except ValueError:
            d = {}
        return d if isinstance(d, dict) else {}

    def look_set(self, look):
        self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, "*", "look", json.dumps(look, sort_keys=True)))
        self._commit()

    def set_setting(self, key, value):
        if value is None:
            self.conn.execute("DELETE FROM u.settings WHERE user_id=? AND game=? AND key=?", (self.user_id, self.game, key))
        else:
            self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, self.game, key, str(value)))
        self._commit()

    def art_threshold(self):
        try:
            return float(self.get_setting("art_threshold", taxonomy.ART_STD_THRESHOLD))
        except (TypeError, ValueError):
            return taxonomy.ART_STD_THRESHOLD

    def card_tags(self):
        out = {}
        for cid, tag, val in self.conn.execute("SELECT card_id, tag, value FROM u.card_tags WHERE user_id=? AND game=?", (self.user_id, self.game)):
            out.setdefault(cid, {})[tag] = val
        return out

    def set_card_tag(self, card_id, tag, value):
        """tag 'art' / 'altart', value 'yes' / 'no' / None (back to automatic)."""
        old = self.conn.execute("SELECT value FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (self.user_id, self.game, card_id, tag)).fetchone()
        self._remember({"t": "tag", "card": card_id, "tag": tag, "prev": old[0] if old else None})
        self.conn.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (self.user_id, self.game, card_id, tag))
        if value:
            self.conn.execute("INSERT INTO u.card_tags VALUES(?,?,?,?,?,?)", (self.user_id, self.game, card_id, tag, value, now_iso()))
            self._untomb("tag", f"{card_id}|{tag}")
        else:
            self._tomb("tag", f"{card_id}|{tag}")
        self.log("card.tag", "card", "", {"card_id": card_id, "tag": tag, "value": value})
        self._commit()
        self.invalidate_index()

    def group_ids(self, group_id, edition=None):
        self.card_index()
        key = (group_id, edition)
        if key not in self._group_ids:
            self._group_ids[key] = [c["id"] for c in self._index if group_id in c["groups"] and (not edition or c["edition"] == edition)]
        return self._group_ids[key]

    def group_counts(self, edition=None):
        """{group id: (owned, total)} over the whole catalogue (or one edition of it)."""
        owned = self.owned_map()
        tot, own = {}, {}
        for c in self.card_index():
            if edition and c["edition"] != edition:
                continue
            have = owned.get(c["id"], 0) > 0
            for g in c["groups"]:
                tot[g] = tot.get(g, 0) + 1
                if have:
                    own[g] = own.get(g, 0) + 1
        return {g: (own.get(g, 0), t) for g, t in tot.items()}

    def facets(self, edition=None):
        """{'illustrator': {name: [card ids]}, 'dex': {number: [card ids]}} over the whole catalogue (or one edition of it)."""
        self.card_index()
        if not edition:
            return self._facets
        if edition not in self._facets_ed:
            ids = {c["id"] for c in self._index if c["edition"] == edition}
            self._facets_ed[edition] = {k: {n: [i for i in lst if i in ids] for n, lst in d.items() if any(i in ids for i in lst)} for k, d in self._facets.items()}
        return self._facets_ed[edition]

    # ---- your own categories (dev tools) - saved in collection.db, so they survive catalogue and program updates
    def custom_groups(self):
        return self.conn.execute("SELECT * FROM u.custom_groups WHERE user_id=? AND game=? AND deleted=0 ORDER BY label COLLATE NOCASE",
                                 (self.user_id, self.game)).fetchall()

    def _register_taxonomy(self):
        from . import games
        g = games.game_by_id(self.game)
        dynamic = []
        if not g.pokemon:
            q = lambda col: [r[0] for r in self.conn.execute(f"SELECT DISTINCT {col} FROM cards WHERE {col} IS NOT NULL AND {col}!=''")]
            order = {r.lower(): i for i, r in enumerate(g.rarity_order)}
            rars = sorted(q("rarity"), key=lambda r: (taxonomy_rank(r, g.rarity_order), r))
            colours = sorted({p.strip() for v in q("types") for p in v.split(",") if p.strip()})
            dynamic = taxonomy.dynamic_groups(rars, sorted(q("category")), colours, g.type_label)
        customs, meta = [], {}
        for r in self.custom_groups():
            customs.append(taxonomy.Group(r["key"], r["label"], r["section"] or "custom", r["help"] or ""))
            try:
                rules = json.loads(r["rules"] or "{}")
            except ValueError:
                rules = {}
            meta[r["key"]] = {"rules": rules, "counts_as_art": bool(r["counts_as_art"])}
        taxonomy.configure(g.pokemon, dynamic, customs, meta, g.type_label, g.rarity_order)

    def _apply_custom_groups(self, tags):
        """Add each user category to the cards that match its rules / were added by hand, minus the ones removed by hand."""
        dyn = {g.id for g in taxonomy._state["dynamic"]}
        if dyn:                                            # hand corrections on a non-Pokémon game's rarity / type / colour groups
            for c in self._index:
                t = tags.get(c["id"])
                if t and dyn & set(t):
                    gs = set(c["groups"])
                    for gid, val in t.items():
                        if gid in dyn:
                            (gs.add if val == "yes" else gs.discard)(gid)
                    c["groups"] = frozenset(gs)
        customs = [(g.id, taxonomy.custom_meta(g.id)) for g in taxonomy._state["custom"]]
        if not customs:
            return
        from . import checklists
        for c in self._index:
            t = tags.get(c["id"], {})
            groups = set(c["groups"])
            c["groups"] = groups
            for key, meta in customs:
                rules = meta["rules"]
                m = bool(rules.get("include")) and any(checklists.clause_matches(c, cl) for cl in rules["include"]) \
                    and not any(checklists.clause_matches(c, cl) for cl in rules.get("exclude", []))
                forced = t.get(key)
                m = True if forced == "yes" else (False if forced == "no" else m)
                if m:
                    groups.add(key)
                    if meta["counts_as_art"] and t.get("art") != "no":
                        groups.add("art")
            c["groups"] = frozenset(groups)

    def create_custom_group(self, label, section="custom", help="", rules=None, counts_as_art=False):
        base = "c_" + (taxonomy._slug(label) or "category")
        key, n = base, 2
        existing = {r[0] for r in self.conn.execute("SELECT key FROM u.custom_groups WHERE user_id=? AND game=?", (self.user_id, self.game))}
        while key in existing:
            key, n = f"{base}-{n}", n + 1
        u = new_uuid()
        self.conn.execute("INSERT INTO u.custom_groups(uuid,user_id,game,key,label,section,help,rules,counts_as_art,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
                          (u, self.user_id, self.game, key, label, section, help, json.dumps(rules or {"include": [], "exclude": []}), 1 if counts_as_art else 0, now_iso(), now_iso()))
        self._remember({"t": "grp", "key": key, "prev": {"deleted": 1}, "name": label})
        self.log("category.create", "category", u, {"key": key, "label": label})
        self._commit()
        self.invalidate_index()
        self._register_taxonomy()
        return key

    def update_custom_group(self, key, label, section, help, rules, counts_as_art):
        old = next((r for r in self.custom_groups() if r["key"] == key), None)
        if old:
            self._remember({"t": "grp", "key": key, "name": old["label"], "prev": {k: old[k] for k in ("label", "section", "help", "rules", "counts_as_art")}})
        self.conn.execute("UPDATE u.custom_groups SET label=?, section=?, help=?, rules=?, counts_as_art=?, updated_at=? WHERE user_id=? AND game=? AND key=?",
                          (label, section, help, json.dumps(rules), 1 if counts_as_art else 0, now_iso(), self.user_id, self.game, key))
        self.log("category.update", "category", "", {"key": key, "label": label})
        self._commit()
        self.invalidate_index()
        self._register_taxonomy()

    def delete_custom_group(self, key):
        old = next((r for r in self.custom_groups() if r["key"] == key), None)
        if old:
            self._remember({"t": "grp", "key": key, "name": old["label"], "prev": {"deleted": 0}})
        self.conn.execute("UPDATE u.custom_groups SET deleted=1, updated_at=? WHERE user_id=? AND game=? AND key=?", (now_iso(), self.user_id, self.game, key))
        for (cid, val) in self.conn.execute("SELECT card_id, value FROM u.card_tags WHERE user_id=? AND game=? AND tag=?", (self.user_id, self.game, key)).fetchall():
            self._remember({"t": "tag", "card": cid, "tag": key, "prev": val})
            self._tomb("tag", f"{cid}|{key}")
        self.conn.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND tag=?", (self.user_id, self.game, key))
        self.log("category.delete", "category", "", {"key": key})
        self._commit()
        self.invalidate_index()
        self._register_taxonomy()

    def export_categories(self, path):
        """All your own categories + every hand correction as JSON - the way to carry them into a future update or another PC."""
        cats = [{"key": r["key"], "label": r["label"], "section": r["section"], "help": r["help"], "counts_as_art": bool(r["counts_as_art"]),
                 "rules": json.loads(r["rules"] or "{}")} for r in self.custom_groups()]
        data = {"format": 1, "game": self.game, "exported": now_iso(), "categories": cats, "corrections": self.card_tags(),
                "art_threshold": self.get_setting("art_threshold")}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=1, ensure_ascii=False)
        return len(cats), len(data["corrections"])

    def import_categories(self, path):
        """Merge a categories file: adds missing categories and corrections, never overwrites what you already set."""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        have = {r["key"] for r in self.custom_groups()}
        added = 0
        self._defer = True
        try:
            for c in data.get("categories", []):
                if c["key"] in have:
                    continue
                u = new_uuid()
                self.conn.execute("INSERT INTO u.custom_groups(uuid,user_id,game,key,label,section,help,rules,counts_as_art,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
                                  (u, self.user_id, self.game, c["key"], c["label"], c.get("section") or "custom", c.get("help") or "", json.dumps(c.get("rules") or {}),
                                   1 if c.get("counts_as_art") else 0, now_iso(), now_iso()))
                added += 1
            for cid, tags in (data.get("corrections") or {}).items():
                for tag, val in tags.items():
                    self.conn.execute("INSERT OR IGNORE INTO u.card_tags VALUES(?,?,?,?,?,?)", (self.user_id, self.game, cid, tag, val, now_iso()))
            self.log("category.import", "category", "", {"added": added, "file": os.path.basename(path)})
        finally:
            self._defer = False
            self.conn.commit()
        self.invalidate_index()
        self._register_taxonomy()
        return added

    def _auto_import_categories(self):
        """A dev_categories_<game>.json dropped into the data folder (e.g. shipped with an update) is merged once per change."""
        import hashlib
        p = os.path.join(self.data_dir, f"dev_categories_{self.game}.json")
        if not os.path.exists(p):
            return
        try:
            digest = hashlib.sha1(open(p, "rb").read()).hexdigest()
            if self.get_setting("dev_categories_hash") != digest:
                self.import_categories(p)
                self.set_setting("dev_categories_hash", digest)
        except (OSError, ValueError, KeyError):
            pass

    def best_card(self, ids):
        """The most striking card among these ids (see taxonomy.cool_score), preferring one that has a picture address."""
        self.card_index()
        best, key = None, (-1, -1.0)
        for i in ids:
            c = self._index_by_id.get(i)
            if not c:
                continue
            k = (taxonomy.cool_score(c), min(c.get("price_usd") or 0, 400))
            if k > key:
                best, key = c, k
        return best

    def card_light(self, card_id):
        self.card_index()
        return self._index_by_id.get(card_id)

    def distinct(self, column):
        vals = set()
        for (v,) in self.conn.execute(f"SELECT DISTINCT {column} FROM cards WHERE {column} IS NOT NULL AND {column}!=''"):
            for part in str(v).split(","):
                if part.strip():
                    vals.add(part.strip())
        return sorted(vals)

    def series_names(self):
        return [r[0] for r in self.conn.execute("SELECT DISTINCT serie FROM sets WHERE serie IS NOT NULL ORDER BY serie")]

    def _own_exists(self):
        return ("EXISTS(SELECT 1 FROM lots_s l WHERE l.card_id=c.id AND l.user_id=? AND l.game=? AND l.deleted=0)",
                [self.user_id, self.game])

    def query_cards(self, set_id=None, serie=None, text="", show="all", ctype=None, rarity=None, sort="default", only_ids=None, edition=None):
        sql = ("SELECT c.id, c.name, c.set_id, c.local_id FROM cards c "
               "LEFT JOIN sets s ON s.id=c.set_id")
        where, args = [], []
        if set_id:
            where.append("c.set_id=?")
            args.append(set_id)
        if serie:
            where.append("s.serie=?")
            args.append(serie)
        if edition == "pocket":
            where.append("s.serie LIKE '%pocket%'")
        elif edition == "tcg":
            where.append("(s.serie IS NULL OR s.serie NOT LIKE '%pocket%')")
        self.conn.create_function("fold", 1, _fold, deterministic=True)
        for tok in text.split():
            m = _NUMTOK.match(tok)
            if m and (m.group(1) or m.group(3)):                                        # "#4", "004/165" or "4/102": that card number (and, with a slash, in a set of that size)
                where.append("(c.local_id GLOB '[0-9]*' AND CAST(c.local_id AS INTEGER)=?" + (" AND (s.official=? OR s.total=?))" if m.group(3) else ")"))
                args += [int(m.group(2))] + ([int(m.group(3))] * 2 if m.group(3) else [])
                continue
            like = f"%{_fold(tok)}%"                     # ignores capitals, accents (Pokémon = pokemon) and curly apostrophes
            where.append("(fold(c.name) LIKE ? OR fold(c.local_id) LIKE ? OR fold(c.illustrator) LIKE ? OR fold(s.name) LIKE ? OR fold(c.rarity) LIKE ?)")
            args += [like] * 5
        own_sql, own_args = self._own_exists()
        if show == "owned":
            where.append(own_sql)
            args += own_args
        elif show == "missing":
            where.append("NOT " + own_sql)
            args += own_args
        elif show == "wishlist":
            where.append("c.id IN (SELECT card_id FROM u.wishlist WHERE user_id=? AND game=?)")
            args += [self.user_id, self.game]
        if ctype:
            where.append("c.types LIKE ?")
            args.append(f"%{ctype}%")
        if rarity:
            where.append("c.rarity=?")
            args.append(rarity)
        if where:
            sql += " WHERE " + " AND ".join(where)
        first = ""
        if text.strip() and sort == "default":           # a card whose NAME is what you typed comes first, then names that start with it, then the rest
            first = "CASE WHEN fold(c.name)=? THEN 0 WHEN fold(c.name) LIKE ? THEN 1 ELSE 2 END, "
            args += [_fold(text.strip()), _fold(text.strip()) + "%"]
        order = {
            "default": first + "s.release_date DESC, c.set_id, c.sort_key, c.local_id",
            "oldest": "s.release_date ASC, c.set_id, c.sort_key, c.local_id",
            "name": "c.name COLLATE NOCASE, s.release_date",
            "price": "COALESCE(c.price_usd, -1) DESC, c.name",
        }[sort]
        sql += " ORDER BY " + order
        rows = [tuple(r) for r in self.conn.execute(sql, args)]
        if only_ids is not None:
            keep = set(only_ids)
            rows = [r for r in rows if r[0] in keep]
        return rows

    # ------------------------------------------------------------------ recent actions (undo)
    @contextlib.contextmanager
    def action(self, label=None):
        """Group everything done inside the block into ONE entry of the recent-actions log (e.g. 'Removed 25 cards')."""
        if self._act is not None:
            yield self._act
            return
        a = _Action(label)
        self._act = a
        prev_defer = self._defer
        self._defer = True
        try:
            yield a
        finally:
            self._act = None
            self._defer = prev_defer
            if a.ops:
                self._save_action(a)
            self.conn.commit()

    def _remember(self, op):
        if self._suppress:
            return
        if self._act is not None:
            self._act.ops.append(op)
            return
        a = _Action()
        a.ops.append(op)
        self._save_action(a)

    def _describe(self, ops):
        lots = [o for o in ops if o["t"] == "lot"]
        if lots:
            cards = {o["card"] for o in lots}
            first = self.card_light(next(iter(cards)))
            subject = (first["name"] if first else "a card") if len(cards) == 1 else f"{len(cards)} cards"
            whats = {o["what"] for o in lots}
            if whats == {"remove"}:
                return f"Removed {subject} from your collection"
            if whats == {"add"}:
                return f"Added {subject} to your collection"
            return f"Changed copies of {subject}"
        w = [o for o in ops if o["t"] == "wish"]
        if w:
            return f"{'Removed from' if w[0]['prev'] else 'Added to'} the wishlist" + (f": {len(w)} cards" if len(w) > 1 else "")
        cl = [o for o in ops if o["t"] == "cl"]
        if cl:
            kind = "Deleted" if cl[0]["prev"].get("deleted") == 0 else ("Created" if cl[0]["prev"].get("deleted") == 1 else "Edited")
            return f"{kind} checklist '{cl[0].get('name', '')}'"
        g = [o for o in ops if o["t"] == "grp"]
        if g:
            kind = "Deleted" if g[0]["prev"].get("deleted") == 0 else ("Created" if g[0]["prev"].get("deleted") == 1 else "Edited")
            return f"{kind} category '{g[0].get('name', '')}'"
        if any(o["t"] == "tag" for o in ops):
            return f"Changed the categories of {len({o['card'] for o in ops if o['t'] == 'tag'})} card(s)"
        if any(o["t"] in ("cli", "pick") for o in ops):
            return "Changed a checklist"
        return f"Changed {len(ops)} item(s)"

    def _save_action(self, a):
        label = a.label or self._describe(a.ops)
        count = len({o.get("card") or o.get("id") or o.get("key") for o in a.ops})
        cur = self.conn.execute("INSERT INTO u.actions(user_id,game,ts,label,count,ops,undone) VALUES(?,?,?,?,?,?,0)",
                                (self.user_id, self.game, now_iso(), label, count, json.dumps(a.ops)))
        a.id = cur.lastrowid
        a.label = label
        self.conn.execute("DELETE FROM u.actions WHERE user_id=? AND game=? AND id NOT IN "
                          "(SELECT id FROM u.actions WHERE user_id=? AND game=? ORDER BY id DESC LIMIT 300)", (self.user_id, self.game) * 2)

    def recent_actions(self, limit=100):
        return self.conn.execute("SELECT * FROM u.actions WHERE user_id=? AND game=? ORDER BY id DESC LIMIT ?", (self.user_id, self.game, limit)).fetchall()

    def last_undoable(self):
        return self.conn.execute("SELECT * FROM u.actions WHERE user_id=? AND game=? AND undone=0 ORDER BY id DESC LIMIT 1", (self.user_id, self.game)).fetchone()

    def undo_action(self, action_id):
        """Reverse one logged action.  Returns how many changes were reversed (0 if it was already undone)."""
        r = self.conn.execute("SELECT * FROM u.actions WHERE id=? AND user_id=? AND game=?", (action_id, self.user_id, self.game)).fetchone()
        if not r or r["undone"]:
            return 0
        ops = json.loads(r["ops"])
        self._suppress = True
        self._defer = True
        try:
            for op in reversed(ops):
                self._apply_inverse(op)
        finally:
            self._suppress = False
            self._defer = False
        self.conn.execute("UPDATE u.actions SET undone=1, undone_at=? WHERE id=?", (now_iso(), action_id))
        self.log("action.undo", "action", "", {"id": action_id, "label": r["label"]})
        self.conn.commit()
        self._cl_rev += 1
        self.invalidate_index()
        self._register_taxonomy()
        return len(ops)

    def _apply_inverse(self, op):
        t, c, ts = op["t"], self.conn, now_iso()
        if t == "lot":
            prev = op["prev"]
            c.execute("UPDATE u.lots SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE id=?", (*prev.values(), ts, op["id"]))
        elif t == "tag":
            self.set_card_tag(op["card"], op["tag"], op["prev"])
        elif t == "wish":
            if (op["card"] in self.wishlist_ids()) != bool(op["prev"]):
                self.toggle_wishlist(op["card"])
        elif t == "cl":
            prev = op["prev"]
            c.execute("UPDATE u.checklists SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE id=?", (*prev.values(), ts, op["id"]))
        elif t == "cli":
            self.set_checklist_card(op["id"], op["card"], op["prev"])
        elif t == "pick":
            self.set_pick(op["id"], op["slot"], op["prev"])
        elif t == "spend":
            prev = op["prev"]
            c.execute("UPDATE u.spending SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE id=?", (*prev.values(), ts, op["id"]))
        elif t == "grp":
            prev = op["prev"]
            c.execute("UPDATE u.custom_groups SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE user_id=? AND game=? AND key=?",
                      (*prev.values(), ts, self.user_id, self.game, op["key"]))

    # ------------------------------------------------------------------ collection
    def owned_map(self):
        return {r[0]: r[1] for r in self.conn.execute(
            "SELECT card_id, SUM(qty) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 GROUP BY card_id",
            (self.user_id, self.game))}

    def owned_variants(self):
        """{card_id: set of variant labels owned}"""
        out = {}
        for cid, var in self.conn.execute(
                "SELECT card_id, variant FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (self.user_id, self.game)):
            out.setdefault(cid, set()).add(var)
        return out

    def owned_by_set(self):
        return {r[0]: r[1] for r in self.conn.execute(
            "SELECT c.set_id, COUNT(DISTINCT c.id) FROM cards c JOIN lots_s l ON l.card_id=c.id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.set_id", (self.user_id, self.game))}

    def wishlist_ids(self):
        return {r[0] for r in self.conn.execute("SELECT card_id FROM u.wishlist WHERE user_id=? AND game=?", (self.user_id, self.game))}

    def lots_for(self, card_id):
        return self.conn.execute(
            "SELECT * FROM lots_s WHERE card_id=? AND user_id=? AND game=? AND deleted=0 ORDER BY id",
            (card_id, self.user_id, self.game)).fetchall()

    def add_lot(self, card_id, variant="Normal", condition="Near Mint", qty=1, graded=False,
                company="", grade="", price=None, notes="", language="English", cert="", location="", edition="", purchased="", source="", portfolio=None):
        portfolio = self.target_pf if portfolio is None else portfolio
        if not graded and not notes:
            r = self.conn.execute(
                "SELECT id, uuid, qty FROM u.lots WHERE card_id=? AND user_id=? AND game=? AND deleted=0 AND variant=? AND condition=? "
                "AND language=? AND graded=0 AND COALESCE(notes,'')='' AND purchase_price IS ? "
                "AND COALESCE(location,'')=? AND COALESCE(edition,'')=? AND COALESCE(portfolio,'')=? AND COALESCE(purchased,'')=? AND COALESCE(source,'')=?",
                (card_id, self.user_id, self.game, variant, condition, language, price, location or "", edition or "", portfolio or "", purchased or "", source or "")).fetchone()
            if r:
                self._remember({"t": "lot", "id": r[0], "prev": {"qty": r[2]}, "card": card_id, "what": "add"})
                self.conn.execute("UPDATE u.lots SET qty=qty+?, updated_at=? WHERE id=?", (qty, now_iso(), r[0]))
                self.log("lot.qty", "lot", r[1], {"card_id": card_id, "delta": qty})
                self._commit()
                return r[0]
        u = new_uuid()
        cur = self.conn.execute(
            "INSERT INTO u.lots(uuid,user_id,game,card_id,variant,condition,language,qty,graded,grade_company,grade,"
            "purchase_price,notes,cert,location,edition,purchased,source,portfolio,added,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
            (u, self.user_id, self.game, card_id, variant, condition, language, qty, 1 if graded else 0, company, grade,
             price, notes, cert, location or "", edition or "", purchased or "", source or "", portfolio or "", now_iso(), now_iso()))
        self._remember({"t": "lot", "id": cur.lastrowid, "prev": {"deleted": 1}, "card": card_id, "what": "add"})
        self.log("lot.add", "lot", u, {"card_id": card_id, "variant": variant, "condition": condition, "qty": qty,
                                       "graded": graded, "grade": f"{company} {grade}".strip(), "price": price})
        self._commit()
        return cur.lastrowid

    LOT_FIELDS = ("variant", "condition", "language", "qty", "graded", "grade_company", "grade", "cert", "purchase_price", "notes", "location", "edition", "purchased", "source", "portfolio")

    def get_lot(self, lot_id):
        return self.conn.execute("SELECT * FROM u.lots WHERE id=?", (lot_id,)).fetchone()

    def update_lot(self, lot_id, **fields):
        """Edit any detail of one copy / stack: condition, grading company + grade + cert number, price paid, notes..."""
        bad = set(fields) - set(self.LOT_FIELDS)
        if bad:
            raise ValueError(f"unknown lot fields: {bad}")
        if not fields:
            return
        old = self.get_lot(lot_id)
        if old:
            self._remember({"t": "lot", "id": lot_id, "prev": {k: old[k] for k in fields}, "card": old["card_id"], "what": "edit"})
        sets = ", ".join(f"{k}=?" for k in fields)
        self.conn.execute(f"UPDATE u.lots SET {sets}, updated_at=? WHERE id=?", (*fields.values(), now_iso(), lot_id))
        r = self.get_lot(lot_id)
        self.log("lot.edit", "lot", r["uuid"] if r else "", {"fields": {k: v for k, v in fields.items()}})
        self._commit()

    def change_lot_qty(self, lot_id, delta):
        r = self.conn.execute("SELECT uuid, qty, card_id, deleted FROM u.lots WHERE id=?", (lot_id,)).fetchone()
        if not r:
            return
        new_qty = r["qty"] + delta
        self._remember({"t": "lot", "id": lot_id, "prev": {"qty": r["qty"], "deleted": r["deleted"]}, "card": r["card_id"], "what": "remove" if new_qty <= 0 else "qty"})
        if new_qty <= 0:
            self.conn.execute("UPDATE u.lots SET qty=0, deleted=1, updated_at=? WHERE id=?", (now_iso(), lot_id))
            self.log("lot.delete", "lot", r["uuid"], {"card_id": r["card_id"], "prev_qty": r["qty"]})
        else:
            self.conn.execute("UPDATE u.lots SET qty=?, updated_at=? WHERE id=?", (new_qty, now_iso(), lot_id))
            self.log("lot.qty", "lot", r["uuid"], {"card_id": r["card_id"], "delta": delta})
        self._commit()

    def delete_lot(self, lot_id):
        r = self.conn.execute("SELECT uuid, qty, card_id FROM u.lots WHERE id=?", (lot_id,)).fetchone()
        if r:
            self._remember({"t": "lot", "id": lot_id, "prev": {"deleted": 0, "qty": r["qty"]}, "card": r["card_id"], "what": "remove"})
            self.conn.execute("UPDATE u.lots SET deleted=1, updated_at=? WHERE id=?", (now_iso(), lot_id))
            self.log("lot.delete", "lot", r["uuid"], {"card_id": r["card_id"], "prev_qty": r["qty"]})
            self._commit()

    def undelete_lots(self, lot_ids):
        for lid in lot_ids:
            row = self.get_lot(lid)
            if row:
                self._remember({"t": "lot", "id": lid, "prev": {"deleted": row["deleted"], "qty": row["qty"]}, "card": row["card_id"], "what": "add"})
            self.conn.execute("UPDATE u.lots SET deleted=0, qty=MAX(qty,1), updated_at=? WHERE id=?", (now_iso(), lid))
        self.log("lot.undelete", "lot", "", {"ids": list(lot_ids)})
        self._commit()

    def remove_one(self, card_id):
        r = self.conn.execute(
            "SELECT id FROM lots_s WHERE card_id=? AND user_id=? AND game=? AND deleted=0 ORDER BY id DESC LIMIT 1",
            (card_id, self.user_id, self.game)).fetchone()
        if r:
            self.change_lot_qty(r[0], -1)

    def default_variant(self, card_id):
        c = self.card_light(card_id)
        try:
            flags = json.loads((c or {}).get("variants") or "{}")
        except ValueError:
            flags = {}
        for k in VARIANT_FLAGS:
            if flags.get(k):
                return VARIANT_LABELS[k]
        return "Normal"

    def set_owned(self, card_id, owned, variant=None, condition="Near Mint"):
        """The quick checkbox.  Returns ('added', [lot_id]) / ('removed', [lot_ids]) / ('unchanged', [])."""
        lots = self.lots_for(card_id)
        if owned and not lots:
            lid = self.add_lot(card_id, variant or self.default_variant(card_id), condition, 1)
            return "added", [lid]
        if not owned and lots:
            ids = [l["id"] for l in lots]
            for lid in ids:
                self.delete_lot(lid)
            return "removed", ids
        return "unchanged", []

    def set_variant_owned(self, card_id, variant, owned, condition="Near Mint"):
        lots = [l for l in self.lots_for(card_id) if l["variant"] == variant]
        if owned and not lots:
            return "added", [self.add_lot(card_id, variant, condition, 1)]
        if not owned and lots:
            ids = [l["id"] for l in lots]
            for lid in ids:
                self.delete_lot(lid)
            return "removed", ids
        return "unchanged", []

    def mark_many(self, card_ids, owned):
        added, removed = [], []
        with self.action():          # one disk sync and one undo entry for the whole batch
            for cid in card_ids:
                what, ids = self.set_owned(cid, owned)
                (added if what == "added" else removed).extend(ids)
        return added, removed

    def needs_remove_confirmation(self, card_id):
        """True when removing the card would throw away more than one plain NM copy (price paid, notes, grading...)."""
        lots = self.lots_for(card_id)
        if len(lots) > 1:
            return True
        return any(l["qty"] > 1 or l["graded"] or l["purchase_price"] is not None or (l["notes"] or "") for l in lots)

    def _tomb(self, kind, key):
        """Remember that something was deleted, so a sync on another device deletes it too instead of bringing it back."""
        self.conn.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (self.user_id, self.game, kind, key, now_iso()))

    def _untomb(self, kind, key):
        self.conn.execute("DELETE FROM u.tombstones WHERE user_id=? AND game=? AND kind=? AND key=?", (self.user_id, self.game, kind, key))

    def toggle_wishlist(self, card_id):
        was = card_id in self.wishlist_ids()
        self._remember({"t": "wish", "card": card_id, "prev": was})
        if was:
            self.conn.execute("DELETE FROM u.wishlist WHERE card_id=? AND user_id=? AND game=?", (card_id, self.user_id, self.game))
            self._tomb("wishlist", card_id)
            self.log("wishlist.remove", "wishlist", "", {"card_id": card_id})
        else:
            self.conn.execute("INSERT INTO u.wishlist VALUES(?,?,?,?,?)", (self.user_id, self.game, card_id, "", now_iso()))
            self._untomb("wishlist", card_id)
            self.log("wishlist.add", "wishlist", "", {"card_id": card_id})
        self._commit()

    def stats(self):
        a = (self.user_id, self.game)
        copies, unique = self.conn.execute(
            "SELECT COALESCE(SUM(qty),0), COUNT(DISTINCT card_id) FROM lots_s WHERE user_id=? AND game=? AND deleted=0", a).fetchone()
        value, eur = self.conn.execute(
            "SELECT COALESCE(SUM(l.qty*c.price_usd),0), COALESCE(SUM(l.qty*c.price_eur),0) FROM lots_s l JOIN cards c ON c.id=l.card_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0", a).fetchone()
        spent = self.conn.execute(
            "SELECT COALESCE(SUM(qty*purchase_price),0) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND purchase_price IS NOT NULL",
            a).fetchone()[0]
        return {"copies": copies, "unique": unique, "value": value, "value_eur": eur, "spent": spent}

    # ------------------------------------------------------------------ prices / value history
    def tracked_card_ids(self):
        owned = {r[0] for r in self.conn.execute("SELECT DISTINCT card_id FROM u.lots WHERE user_id=? AND game=? AND deleted=0", (self.user_id, self.game))}
        return owned | self.wishlist_ids()          # every portfolio, whatever is currently shown

    def record_price_history(self, card_ids=None, day=None):
        day = day or today()
        ids = card_ids if card_ids is not None else self.tracked_card_ids()
        for cid in ids:
            r = self.conn.execute("SELECT price_usd, price_eur FROM cards WHERE id=?", (cid,)).fetchone()
            if r and (r[0] is not None or r[1] is not None):
                self.conn.execute("INSERT OR REPLACE INTO u.price_history VALUES(?,?,?,?,?)", (self.game, cid, day, r[0], r[1]))
        self._commit()

    def price_history(self, card_id):
        return [tuple(r) for r in self.conn.execute(
            "SELECT day, usd, eur FROM u.price_history WHERE game=? AND card_id=? ORDER BY day", (self.game, card_id))]

    def value_breakdown(self):
        """Current value of the collection split several ways (used for charts and stored in each snapshot)."""
        rows = self.conn.execute(
            "SELECT l.card_id, l.qty, c.price_usd, c.price_eur, c.set_id, c.rarity, s.name AS set_name, s.serie "
            "FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0", (self.user_id, self.game)).fetchall()
        by_set, by_serie, by_rarity, by_card = {}, {}, {}, {}
        for r in rows:
            v = (r["price_usd"] or 0) * r["qty"]
            by_set[r["set_name"] or r["set_id"]] = by_set.get(r["set_name"] or r["set_id"], 0) + v
            by_serie[r["serie"] or "Other"] = by_serie.get(r["serie"] or "Other", 0) + v
            by_rarity[r["rarity"] or "Unknown"] = by_rarity.get(r["rarity"] or "Unknown", 0) + v
            by_card[r["card_id"]] = by_card.get(r["card_id"], 0) + v
        return {"set": by_set, "serie": by_serie, "rarity": by_rarity, "card": by_card}

    def checklist_values(self):
        out = {}
        owned = self.owned_map()
        for cl in self.checklists():
            total = 0.0
            for cid in self.checklist_members(cl["id"]):
                q = owned.get(cid, 0)
                if q:
                    c = self.card_light(cid)
                    total += (c["price_usd"] or 0) * q if c else 0
            out[cl["name"]] = total
        return out

    def take_snapshot(self):
        saved = self.scope
        self.set_scope(None)                       # the saved history is always for the whole collection
        try:
            self._take_snapshot()
        finally:
            self.set_scope(saved)

    def record_set_values(self, day=None):
        """Today's value of every set (all its cards, and the copies you own) - the history behind the set analytics graph.  One point per set per day."""
        day = day or today()
        owned = {r[0]: r[1] for r in self.conn.execute(
            "SELECT c.set_id, SUM(l.qty*COALESCE(c.price_usd,0)) FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.set_id",
            (self.user_id, self.game))}
        rows = [(self.game, sid, day, tot or 0.0, owned.get(sid, 0.0) or 0.0, priced, n) for sid, tot, priced, n in self.conn.execute(
            "SELECT set_id, SUM(price_usd), COUNT(price_usd), COUNT(*) FROM cards GROUP BY set_id")]
        self.conn.executemany("INSERT OR REPLACE INTO u.set_value_history VALUES(?,?,?,?,?,?,?)", rows)
        self._commit()

    def set_value_history(self, set_id):
        return [dict(r) for r in self.conn.execute("SELECT day, total, owned, priced, n FROM u.set_value_history WHERE game=? AND set_id=? ORDER BY day", (self.game, set_id))]

    def _take_snapshot(self):
        self.record_set_values()
        st = self.stats()
        bd = self.value_breakdown()
        bd["card"] = dict(sorted(bd["card"].items(), key=lambda kv: -kv[1])[:50])
        bd["checklist"] = self.checklist_values()
        day = today()
        self.conn.execute("INSERT OR REPLACE INTO u.snapshots VALUES(?,?,?,?,?,?,?,?,?)",
                          (self.user_id, self.game, day, now_iso(), st["value"], st["value_eur"], st["copies"], st["unique"], json.dumps(bd)))
        self._commit()

    def snapshots(self):
        rows = self.conn.execute("SELECT * FROM u.snapshots WHERE user_id=? AND game=? ORDER BY day", (self.user_id, self.game)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["breakdown"] = json.loads(d["breakdown"] or "{}")
            except ValueError:
                d["breakdown"] = {}
            out.append(d)
        return out

    def top_cards(self, n=25):
        return self.conn.execute(
            "SELECT c.id, c.name, c.set_id, c.local_id, c.rarity, c.price_usd, SUM(l.qty) AS qty, SUM(l.qty*c.price_usd) AS value, s.name AS set_name "
            "FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.id ORDER BY value DESC LIMIT ?",
            (self.user_id, self.game, n)).fetchall()

    # ------------------------------------------------------------------ checklists
    def checklists(self):
        return self.conn.execute(
            "SELECT * FROM u.checklists WHERE user_id=? AND game=? AND deleted=0 ORDER BY name COLLATE NOCASE",
            (self.user_id, self.game)).fetchall()

    def checklist(self, cl_id):
        return self.conn.execute("SELECT * FROM u.checklists WHERE id=?", (cl_id,)).fetchone()

    def create_checklist(self, name, mode="cards", per_variant=False, rules=None, notes=""):
        u = new_uuid()
        cur = self.conn.execute(
            "INSERT INTO u.checklists(uuid,user_id,game,name,mode,per_variant,rules,notes,created_at,updated_at,deleted) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,0)",
            (u, self.user_id, self.game, name, mode, 1 if per_variant else 0, json.dumps(rules or {"include": [], "exclude": []}),
             notes, now_iso(), now_iso()))
        self._remember({"t": "cl", "id": cur.lastrowid, "prev": {"deleted": 1}, "name": name})
        self._cl_rev += 1
        self.log("checklist.create", "checklist", u, {"name": name, "mode": mode})
        self._commit()
        return cur.lastrowid

    def update_checklist(self, cl_id, name, mode, per_variant, rules, notes=""):
        old = self.checklist(cl_id)
        if old:
            self._remember({"t": "cl", "id": cl_id, "name": old["name"], "prev": {k: old[k] for k in ("name", "mode", "per_variant", "rules", "notes")}})
        self._cl_rev += 1
        self.conn.execute("UPDATE u.checklists SET name=?, mode=?, per_variant=?, rules=?, notes=?, updated_at=? WHERE id=?",
                          (name, mode, 1 if per_variant else 0, json.dumps(rules), notes, now_iso(), cl_id))
        self.log("checklist.update", "checklist", (self.checklist(cl_id) or {"uuid": ""})["uuid"], {"name": name})
        self._commit()

    def delete_checklist(self, cl_id):
        self._cl_rev += 1
        r = self.checklist(cl_id)
        if r:
            self._remember({"t": "cl", "id": cl_id, "name": r["name"], "prev": {"deleted": 0}})
        self.conn.execute("UPDATE u.checklists SET deleted=1, updated_at=? WHERE id=?", (now_iso(), cl_id))
        self.log("checklist.delete", "checklist", r["uuid"] if r else "", {"name": r["name"] if r else ""})
        self._commit()

    def checklist_manual(self, cl_id):
        out = {"manual": set(), "excluded": set()}
        for cid, src in self.conn.execute("SELECT card_id, source FROM u.checklist_items WHERE checklist_id=?", (cl_id,)):
            out[src].add(cid)
        return out

    def set_checklist_card(self, cl_id, card_id, state):
        """state: 'manual' (force in), 'excluded' (force out) or None (follow the rules)."""
        self._cl_rev += 1
        old = self.conn.execute("SELECT source FROM u.checklist_items WHERE checklist_id=? AND card_id=?", (cl_id, card_id)).fetchone()
        self._remember({"t": "cli", "id": cl_id, "card": card_id, "prev": old[0] if old else None})
        self.conn.execute("UPDATE u.checklists SET updated_at=? WHERE id=?", (now_iso(), cl_id))
        self.conn.execute("DELETE FROM u.checklist_items WHERE checklist_id=? AND card_id=?", (cl_id, card_id))
        if state:
            self.conn.execute("INSERT INTO u.checklist_items VALUES(?,?,?)", (cl_id, card_id, state))
        self.log("checklist.card", "checklist", "", {"id": cl_id, "card_id": card_id, "state": state})
        self._commit()

    def picks(self, cl_id):
        """{slot key: card id} - the card chosen to be shown on each slot of a Pokédex / rarity style checklist."""
        return {k: c for k, c in self.conn.execute("SELECT slot_key, card_id FROM u.checklist_picks WHERE checklist_id=?", (cl_id,))}

    def set_pick(self, cl_id, slot_key, card_id):
        old = self.conn.execute("SELECT card_id FROM u.checklist_picks WHERE checklist_id=? AND slot_key=?", (cl_id, slot_key)).fetchone()
        self._remember({"t": "pick", "id": cl_id, "slot": slot_key, "prev": old[0] if old else None})
        self.conn.execute("UPDATE u.checklists SET updated_at=? WHERE id=?", (now_iso(), cl_id))
        self.conn.execute("DELETE FROM u.checklist_picks WHERE checklist_id=? AND slot_key=?", (cl_id, slot_key))
        if card_id:
            self.conn.execute("INSERT INTO u.checklist_picks VALUES(?,?,?)", (cl_id, slot_key, card_id))
        self.log("checklist.pick", "checklist", "", {"id": cl_id, "slot": slot_key, "card_id": card_id})
        self._commit()

    def checklist_members(self, cl_id):
        from .checklists import members
        return members(self, self.checklist(cl_id))

    # ------------------------------------------------------------------ shares (structure for the online service)
    def shares(self):
        return self.conn.execute("SELECT * FROM u.shares WHERE user_id=? AND game=? ORDER BY id DESC", (self.user_id, self.game)).fetchall()

    def create_share(self, title, kind, scope, perms, expires_at=None):
        u = new_uuid()
        token = _uuid.uuid4().hex[:22]
        cur = self.conn.execute(
            "INSERT INTO u.shares(uuid,token,user_id,game,title,kind,scope,perms,expires_at,created_at,updated_at,revoked) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
            (u, token, self.user_id, self.game, title, kind, json.dumps(scope), json.dumps(perms), expires_at, now_iso(), now_iso()))
        self.log("share.create", "share", u, {"title": title, "kind": kind})
        self._commit()
        return cur.lastrowid

    def update_share(self, share_id, title, scope, perms, expires_at=None):
        self.conn.execute("UPDATE u.shares SET title=?, scope=?, perms=?, expires_at=?, updated_at=? WHERE id=?",
                          (title, json.dumps(scope), json.dumps(perms), expires_at, now_iso(), share_id))
        self.log("share.update", "share", "", {"id": share_id})
        self._commit()

    def delete_share(self, share_id):
        self.conn.execute("DELETE FROM u.shares WHERE id=?", (share_id,))
        self.log("share.delete", "share", "", {"id": share_id})
        self._commit()

    # ------------------------------------------------------------------ spending log
    def add_spending(self, amount_usd, category="Cards", note="", day=None):
        u = new_uuid()
        cur = self.conn.execute("INSERT INTO u.spending(uuid,user_id,game,day,amount_usd,category,note,deleted,updated_at) VALUES(?,?,?,?,?,?,?,0,?)",
                                (u, self.user_id, self.game, day or today(), float(amount_usd), category, note, now_iso()))
        self._remember({"t": "spend", "id": cur.lastrowid, "prev": {"deleted": 1}, "card": f"spend{cur.lastrowid}", "what": "add"})
        self.log("spend.add", "spending", u, {"amount": amount_usd, "category": category})
        self._commit()
        return cur.lastrowid

    def delete_spending(self, spend_id):
        r = self.conn.execute("SELECT uuid FROM u.spending WHERE id=?", (spend_id,)).fetchone()
        if r:
            self._remember({"t": "spend", "id": spend_id, "prev": {"deleted": 0}, "card": f"spend{spend_id}", "what": "remove"})
            self.conn.execute("UPDATE u.spending SET deleted=1, updated_at=? WHERE id=?", (now_iso(), spend_id))
            self._commit()

    def spending_rows(self):
        return self.conn.execute("SELECT * FROM u.spending WHERE user_id=? AND game=? AND deleted=0 ORDER BY day DESC, id DESC",
                                 (self.user_id, self.game)).fetchall()

    def spending_by_month(self):
        """{'2026-10': total_usd} for the spending log."""
        out = {}
        for r in self.spending_rows():
            out[r["day"][:7]] = out.get(r["day"][:7], 0.0) + (r["amount_usd"] or 0)
        return out

    # ------------------------------------------------------------------ bulk edit
    def bulk_update_lots(self, card_ids, **fields):
        """Change the same detail (condition, location, edition, language, notes...) on every copy of many cards at once."""
        bad = set(fields) - set(self.LOT_FIELDS) - {"qty"}
        if bad or "qty" in fields:
            raise ValueError(f"cannot bulk edit: {bad or 'qty'}")
        n = 0
        with self.action(f"Edited {len(set(card_ids))} cards"):
            for cid in set(card_ids):
                for lot in self.lots_for(cid):
                    self.update_lot(lot["id"], **fields)
                    n += 1
        return n

    # ------------------------------------------------------------------ CSV
    CSV_COLUMNS = ["card_id", "name", "set", "number", "variant", "condition", "language", "qty",
                   "graded", "grade_company", "grade", "cert", "purchase_price", "notes", "location", "edition", "purchased", "source", "portfolio"]

    def _pf_name(self, pid):
        if not pid:
            return ""
        r = self.conn.execute("SELECT name FROM u.portfolios WHERE uuid=?", (pid,)).fetchone()
        return r[0] if r else ""

    def export_csv(self, path):
        rows = self.conn.execute(
            "SELECT l.*, c.name, c.local_id, s.name AS set_name FROM lots_s l "
            "LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 ORDER BY l.id", (self.user_id, self.game)).fetchall()
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(self.CSV_COLUMNS)
            for r in rows:
                w.writerow([r["card_id"], r["name"], r["set_name"], r["local_id"], r["variant"], r["condition"],
                            r["language"], r["qty"], r["graded"], r["grade_company"], r["grade"], r["cert"] or "",
                            "" if r["purchase_price"] is None else r["purchase_price"], r["notes"], r["location"] or "", r["edition"] or "",
                            r["purchased"] or "", r["source"] or "", self._pf_name(r["portfolio"])])
        return len(rows)

    def _pf_by_name(self, name):
        name = (name or "").strip()
        if not name:
            return None
        r = self.conn.execute("SELECT uuid FROM u.portfolios WHERE user_id=? AND deleted=0 AND lower(name)=lower(?)", (self.user_id, name)).fetchone()
        return r[0] if r else self.create_portfolio(name)

    def import_csv(self, path):
        added = skipped = 0
        known = {r[0] for r in self.conn.execute("SELECT id FROM cards")}
        with open(path, newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                cid = (row.get("card_id") or "").strip()
                if cid not in known:
                    skipped += 1
                    continue
                try:
                    qty = int(float(row.get("qty") or 1))
                except ValueError:
                    qty = 1
                try:
                    price = float(row["purchase_price"]) if row.get("purchase_price") not in (None, "") else None
                except ValueError:
                    price = None
                graded = str(row.get("graded", "")).strip().lower() in ("1", "true", "yes")
                self.add_lot(cid, row.get("variant") or "Normal", row.get("condition") or "Near Mint", max(qty, 1),
                             graded, row.get("grade_company") or "", row.get("grade") or "", price,
                             row.get("notes") or "", row.get("language") or "English", cert=row.get("cert") or "",
                             location=row.get("location") or "", edition=row.get("edition") or "", purchased=row.get("purchased") or "",
                             source=row.get("source") or "", portfolio=self._pf_by_name(row.get("portfolio")))
                added += 1
        return added, skipped

    def backup_collection(self, dest_path):
        self._commit()
        if self.secure:
            self.backup_now("manual")
            return
        src = sqlite3.connect(self.user_path)
        dest = sqlite3.connect(dest_path)
        try:
            src.backup(dest)
        finally:
            dest.close()
            src.close()

    def restore_collection(self, backup_path):
        """Replace collection.db with a backup.  A safety copy of the current file is kept first."""
        self.backup_now("before-restore")
        self._commit()
        self.conn.execute("DETACH DATABASE u")
        for suffix in ("-wal", "-shm"):
            try:
                os.remove(self.user_path + suffix)
            except OSError:
                pass
        if self.secure and backup_path.endswith(".enc"):
            from .security import crypto
            plain = self.secure.read_backup(backup_path)
            try:
                shutil.copyfile(plain, self.user_path)
            finally:
                crypto.wipe_file(plain)
        else:
            shutil.copyfile(backup_path, self.user_path)
        self.conn.execute("ATTACH DATABASE ? AS u", (self.user_path,))
        self.conn.execute("PRAGMA u.journal_mode=WAL")
        self.conn.execute("PRAGMA u.synchronous=FULL")
        self._user_migrate()
