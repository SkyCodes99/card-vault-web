"""Local storage.

Data folder layout:
  collection.db                  YOUR data for every game and every local user. Saved after every single change
                                 (WAL + synchronous FULL), with an append-only change journal and automatic backups.
  games/<game>/cards.db          the downloaded card catalogue of one game (rebuildable; updates only touch this)
  games/<game>/images/<q>/...    card pictures
  backups/                       rolling copies of collection.db

Every user record carries user_id + uuid + updated_at + deleted so the same data can later be synced to an online service
and shared between several accounts.
"""
import contextlib
import csv
import datetime
import json
import os
import re
import shutil
import sqlite3
import uuid as _uuid
from urllib.parse import quote

from . import classcache, findfast, fuzzy as fuzzy_mod, gamefacets, provenance, searchfold, taxonomy
from .steps import run
from . import pricepick

INDEX_COLUMNS = ("c.id, c.set_id, c.local_id, c.sort_key, c.name, c.rarity, c.category, c.types, c.dex, c.illustrator, c.price_usd, c.price_kind, c.tcg_id, c.price_eur, c.variants, c.variant_prices, "
                 "c.hp, c.art_score, c.era_hint, s.name AS set_name, s.serie, s.release_date, s.official")          # what each card of the card index holds (see Vault.card_index)

# WHEN A CARD CAME OUT, for sorting.  Most sets have one real release date.  The catch-all promo groups (serie "Miscellaneous": Nintendo Promos, Blister Exclusives, Jumbo Cards...) do not - their
# "date" is when a shop imported them - so each of their cards is dated by the ERA it belongs to (cards.era_hint, worked out by tools/classify_promo_eras.py) and a card whose era is
# unknown sorts last, whichever way you sort.
ERA_START = {"e_wotc": "1999-01-09", "e_ex": "2003-07-01", "e_dp": "2007-05-01", "e_bw": "2011-04-25", "e_xy": "2014-02-05", "e_sm": "2017-02-03", "e_swsh": "2020-02-07", "e_sv": "2023-03-31", "e_mega": "2025-09-26"}


def _query_key(set_id=None, serie=None, edition=None, text="", ctype=None, rarity=None, sort="default", price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None,
               priced="", letter=""):
    """What a kept card order is filed under (see Vault.query_cards)."""
    return (set_id, serie, edition, text, ctype, rarity, sort, price_min, price_max, set_text, artist, year_min, year_max, priced, letter)


def _rank_sql(text, name, nname):
    """-> (SQL, args): 0 = the card's name IS the words typed ('blue eyes' = Blue-Eyes), 1 = it starts with them, 2 = the rest.  With a number among the words ('pika 25'): 0 = the name starts with the
    name words AND the card has that number (0 = its name IS the words), 1 = the name starts with them, 2 = the rest.  name = SQL for the folded name, nname = SQL for the same made like fuzzy.norm().  A text with typos corrected
    ('charizard|charmander') is ranked by its first choice."""
    typed = fuzzy_mod.first_choice(_fold(text.strip())) if "|" in text else _fold(text.strip())
    words, nums = fuzzy_mod.split_query(typed)
    if nums and words:
        has = "(c.local_id GLOB '[0-9]*' AND CAST(c.local_id AS INTEGER) IN (%s))" % ",".join("?" * len(nums))
        return (f"CASE WHEN {has} AND {nname}=? THEN 0 WHEN {has} AND {nname} LIKE ? THEN 1 WHEN {nname} LIKE ? THEN 2 ELSE 3 END", [*nums, words, *nums, words + "%", words + "%"])
    if nums or not words:
        return "2", []
    return (f"CASE WHEN {name}=? OR {nname}=? THEN 0 WHEN {name} LIKE ? OR {nname} LIKE ? THEN 1 ELSE 2 END", [typed, words, typed + "%", words + "%"])


def _sql_order(x):
    """A sort key that puts values in the order SQLite's ORDER BY does: empty (NULL) first, then numbers, then text (by character), then bytes."""
    if x is None:
        return (0, 0)
    if isinstance(x, (int, float)):
        return (1, x)
    return (2, x) if isinstance(x, str) else (3, x)


def eff_date_sql(has_era=True, c="c", s="s"):
    """The date a card sorts by.  An unknown date is NULL here (an empty text is turned into NULL), so it sorts LAST both ways: ORDER BY d DESC puts NULL last, and 'oldest' adds (d IS NULL) first (roadmap 2.9)."""
    if not has_era:
        return f"NULLIF({s}.release_date, '')"
    whens = " ".join(f"WHEN '{k}' THEN '{v}'" for k, v in ERA_START.items())
    return f"NULLIF(CASE WHEN {s}.serie='Miscellaneous' THEN (CASE {c}.era_hint {whens} ELSE NULL END) ELSE {s}.release_date END, '')"


TCG_TYPES = ["Grass", "Fire", "Water", "Lightning", "Psychic", "Fighting", "Darkness", "Metal", "Dragon", "Fairy", "Colorless"]       # the eleven types printed on Pokemon TCG cards
CONDITIONS = ["Near Mint", "Lightly Played", "Moderately Played", "Heavily Played", "Damaged"]
GRADERS = ["PSA", "BGS", "CGC", "SGC", "TAG", "ACE", "AGS", "Other"]
VARIANT_FLAGS = ("normal", "reverse", "holo", "firstEdition", "wPromo")


def clean_flags(flags, rarity=""):
    """A card is printed as Normal + Reverse Holo, or as Holo + Reverse Holo - never all three (the card list sometimes says all three).  When it does, a Common / Uncommon keeps Normal + Reverse
    and anything else keeps Holo + Reverse."""
    f = dict(flags or {})
    if f.get("normal") and f.get("holo"):                                # Normal and Holo never go together (a card is one or the other, plus Reverse Holo)
        if str(rarity or "").strip().lower() in ("common", "uncommon", "c", "u", ""):
            f.pop("holo", None)
        else:
            f.pop("normal", None)
    return f
VARIANT_LABELS = {
    "normal": "Normal",
    "reverse": "Reverse Holo",
    "holo": "Holo",
    "firstEdition": "1st Edition",
    "wPromo": "W Promo",
}
LOCAL_USER = "local"
USER_SCHEMA_VERSION = 3

CARDS_SCHEMA = """
CREATE TABLE IF NOT EXISTS sets(
    id TEXT PRIMARY KEY, name TEXT, serie TEXT, release_date TEXT,
    total INTEGER, official INTEGER, logo TEXT);
CREATE TABLE IF NOT EXISTS cards(
    id TEXT PRIMARY KEY, set_id TEXT, local_id TEXT, sort_key INTEGER, name TEXT,
    image_base TEXT, detailed INTEGER DEFAULT 0,
    category TEXT, rarity TEXT, hp INTEGER, types TEXT, illustrator TEXT,
    stage TEXT, evolve_from TEXT, description TEXT,
    price_usd REAL, price_eur REAL, variants TEXT, raw TEXT, dex TEXT, price_updated TEXT);
CREATE INDEX IF NOT EXISTS cards_set ON cards(set_id, sort_key);
CREATE INDEX IF NOT EXISTS cards_name ON cards(name);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS sealed_products(
    id TEXT PRIMARY KEY, set_id TEXT, set_name TEXT, name TEXT, norm TEXT, image_base TEXT, price_usd REAL, price_kind TEXT, price_updated TEXT, released TEXT, kind TEXT, serie TEXT);
CREATE INDEX IF NOT EXISTS sealed_norm ON sealed_products(norm);
"""


def now_iso():
    """UTC with microseconds ('2026-10-10T01:02:03.123456Z'): sortable as text, comparable between devices in different time zones."""
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def today():
    return datetime.date.today().isoformat()


def new_uuid():
    return _uuid.uuid4().hex


def game_dir(data_dir, game):
    return os.path.join(data_dir, "games", game)


def migrate_layout(data_dir):
    """v1.0.0 kept cards.db + images directly in the data folder; move them under games/pokemon."""
    old_db = os.path.join(data_dir, "cards.db")
    gdir = game_dir(data_dir, "pokemon")
    if os.path.exists(old_db) and not os.path.exists(os.path.join(gdir, "cards.db")):
        os.makedirs(gdir, exist_ok=True)
        for suffix in ("", "-wal", "-shm"):
            src = old_db + suffix
            if os.path.exists(src):
                shutil.move(src, os.path.join(gdir, "cards.db" + suffix))
        old_img = os.path.join(data_dir, "images")
        if os.path.isdir(old_img) and not os.path.exists(os.path.join(gdir, "images")):
            shutil.move(old_img, os.path.join(gdir, "images"))


def _ensure_column(conn, table, name, ddl):
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
    if name not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")


def init_cards_schema(conn):
    conn.executescript(CARDS_SCHEMA)
    _ensure_column(conn, "cards", "dex", "TEXT")
    _ensure_column(conn, "cards", "price_updated", "TEXT")
    _ensure_column(conn, "cards", "price_kind", "TEXT")
    _ensure_column(conn, "sealed_products", "released", "TEXT")
    _ensure_column(conn, "sealed_products", "kind", "TEXT")
    _ensure_column(conn, "sealed_products", "serie", "TEXT")
    _ensure_column(conn, "sealed_products", "also", "TEXT")               # other product types it is also listed under (a Mini tin display is also a Mini tin)
    _ensure_column(conn, "sealed_products", "multi", "INTEGER")           # 1 = a case / display holding several of the product
    _ensure_column(conn, "sealed_products", "contents", "TEXT")           # what is inside, one line each (sealedcontents.py); NULL = no source states it
    _ensure_column(conn, "cards", "tcg_id", "TEXT")
    conn.execute("CREATE INDEX IF NOT EXISTS cards_tcg ON cards(tcg_id)")
    _ensure_column(conn, "cards", "art_score", "REAL")
    _ensure_column(conn, "cards", "variant_prices", "TEXT")               # {"Holofoil": 57.96, "1st Edition Holofoil": 187.08...}: the market price of every printing (daily price update)
    for t_ in ("cards", "sets"):                                           # the Japanese list: English names beside the Japanese ones (see names.py)
        _ensure_column(conn, t_, "name_en", "TEXT")
        _ensure_column(conn, t_, "name_ja", "TEXT")
    _ensure_column(conn, "cards", "era_hint", "TEXT")                    # for the special groups (Burger King promos, blister exclusives...): the era group the card really belongs to
    for t_ in ("cards", "sets"):                                           # the words search looks in, folded once (cardvault/searchfold.py): a search is one LIKE per card, not nine Python calls
        _ensure_column(conn, t_, "fold", "TEXT")
    for name, cols in (("cards_rarity", "rarity"), ("cards_category", "category"), ("cards_types", "types")):   # the browse modes and the game's groups list what each holds: a quick look at
        conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON cards({cols})")                                  # an index instead of reading all of Magic's 132 MB (0.28 s each, every opening)
    conn.execute("CREATE INDEX IF NOT EXISTS cards_nofold ON cards(id) WHERE fold IS NULL")                   # (empty once every card is folded: 'is any card missing its words?' is instant)
    provenance.ensure(conn)                                               # where every card / picture / price came from (cardvault/provenance.py)
    conn.commit()


def open_cards_conn(gdir):
    os.makedirs(gdir, exist_ok=True)
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    init_cards_schema(conn)
    return conn


def sort_key(local_id):
    m = re.search(r"\d+", local_id or "")
    return int(m.group()) if m else 100000


_ALIASES = (("nee-doh", "needoh"), ("nee doh", "needoh"), ("needohs", "needoh"), ("neatos", "needoh"), ("neato", "needoh"), ("nee-dohs", "needoh"),
            ("pokeball", "poke ball"), ("sitting cutie", "sitting cuties"), ("pokemon fit", "pokemon fit"), ("pokémon", "pokemon"), ("funko pop", "funko"), ("funkos", "funko"), ("abominable", "abominable"))


_SUFFIX_HYPHEN = re.compile(r"(?<=[a-z0-9])-(ex|gx|v|vmax|vstar|vunion|break|lv\.x)\b")


def alias_text(s):
    """What people type is not always how a thing is named: 'Neatos', 'Needohs' and 'Nee-Doh' all mean NeeDoh.  Applied to every search box."""
    low = (s or "").lower()
    for a, b in _ALIASES:
        if a in low and a != b:
            low = low.replace(a, b)
    return _SUFFIX_HYPHEN.sub(r" \1", low)                       # 'Jolteon-EX' = 'Jolteon EX' (TCGplayer spells it without the hyphen): both words must match, so both spellings are found


def fix_text(s):
    """TCGdex has a few mojibake strings (e.g. 'Ã—2' for '×2')."""
    if not isinstance(s, str):
        return s
    if "Ã" in s or "â" in s:
        try:
            return s.encode("cp1252").decode("utf-8")
        except (UnicodeError, ValueError):
            return s
    return s


def image_file(gdir, quality, card_id, set_id):
    return os.path.join(gdir, "images", quality, quote(set_id, safe="-._"), quote(card_id, safe="-._") + ".webp")      # a set id like 'beyblade:basic-line-bx' is not a legal folder name on Windows as it stands


_NUMTOK = re.compile(r"^(#)?(\d{1,4})(?:/(\d{1,4}))?$")


_fold = searchfold.fold                                              # lower case, no accents, straight apostrophes: what search compares (cardvault/searchfold.py)


def picture_url(base, quality="low"):
    """The web address of a card picture from what the card list stores: a TCGdex base (the size is appended) or a TCGplayer picture address (a finished address)."""
    if not base:
        return ""
    if base.startswith("https://tcgplayer-cdn.tcgplayer.com/"):
        return base.replace("_200w", "_400w") if quality == "high" else base
    if base.endswith((".jpg", ".png", ".jpeg", ".webp")):
        return base
    return f"{base}/{quality}.webp"


def logo_file(gdir, set_id):
    return os.path.join(gdir, "images", "logos", quote(set_id, safe="-._") + ".webp")


def dex_from_raw(raw_json):
    try:
        d = json.loads(raw_json or "{}").get("dexId")
    except ValueError:
        return None
    if isinstance(d, list) and d:
        return ",".join(str(int(x)) for x in d)
    return None


def edition_of(serie):
    """Which spot a set lives in: the digital TCG Pocket sets are kept apart from the physical card game."""
    return "pocket" if "pocket" in (serie or "").lower() else "tcg"


def taxonomy_rank(rarity, order):
    low = (rarity or "").lower()
    o = [x.lower() for x in order]
    for i, x in enumerate(o):
        if low == x or low.startswith(x + " "):
            return i
    return len(o)


class _Action:
    """Everything one user action changed, with the inverse of each change - so it can be undone."""

    def __init__(self, label=None):
        self.label, self.ops, self.id = label, [], None


class BlockedPortfolio(Exception):
    """A portfolio set to hold only cards (or only sealed products) was asked to take the other kind."""


class IndexNotReady(Exception):
    """card_index() was asked for while it is still being worked out in the background and the caller said not to wait (Vault._no_wait, set for the browser's screens: building it there
    in one go froze every click for seconds - the screen asks again a moment later instead)."""


class Vault:
    """One game's catalogue plus the current local user's collection."""

    def __init__(self, data_dir, game="pokemon", user_id=LOCAL_USER, user_path=None, secure=None):
        self.data_dir = data_dir
        self.secure = secure          # an unlocked account (cardvault.security): backups are then always encrypted
        self.game = game
        self.user_id = user_id
        self._defer = False
        self._no_wait = False
        self._index = None
        self._cl_rev = 0
        self._members_cache = {}
        self._changes_since_backup = 0
        self._act = None
        self._suppress = False
        os.makedirs(data_dir, exist_ok=True)
        migrate_layout(data_dir)
        self.gdir = game_dir(data_dir, game)
        self.conn = open_cards_conn(self.gdir)
        self._fold_use()                                                       # (a list made before the folded search words existed gets them now - once)
        self.user_path = user_path or os.path.join(data_dir, "collection.db")
        self.conn.execute("ATTACH DATABASE ? AS u", (self.user_path,))
        self.conn.execute("PRAGMA u.journal_mode=WAL")
        self.conn.execute("PRAGMA u.synchronous=FULL")
        self._user_migrate()
        self.scope = None                 # None = every portfolio; else the portfolio ids (''=Main) that are currently shown
        self.target_pf = ""               # where new copies go
        self._init_scope()
        self._apply_id_redirects()
        self._own_items()
        self._backfill_dex()
        self._register_taxonomy()
        self._auto_import_categories()
        self._index = None
        self._cl_rev = 0
        self._members_cache = {}
        self._changes_since_backup = 0

    def _own_items(self):
        """Your own items (cardvault/customitems.py) are cards in this game's list: put them back at every open (a new card list is a fresh copy of Card Data)."""
        try:
            from . import customitems
            customitems.materialize(self)
        except Exception:  # noqa: BLE001 - never stop a collection from opening
            import traceback
            traceback.print_exc()

    def _apply_id_redirects(self):
        """The card list can retire a duplicate (the same card once listed twice): its meta 'id_redirects' says {old id: the id that stays}.  Anything of yours that still points at an
        old id - copies you own, wishlist, checklist ticks and picks, tags, binder slots, trades - is moved to the card that stays, so nothing you own is ever lost or orphaned.
        Safe to run every time: it only touches ids that are really gone from the list."""
        try:
            red = json.loads(self.meta("id_redirects", "") or "{}")
        except (ValueError, TypeError):
            return
        if not red:
            return
        c = self.conn
        ts = now_iso()
        gone = [(o, n) for o, n in red.items() if o != n and not c.execute("SELECT 1 FROM main.cards WHERE id=?", (o,)).fetchone() and c.execute("SELECT 1 FROM main.cards WHERE id=?", (n,)).fetchone()]
        if not gone:
            return
        for old, new in gone:
            c.execute("UPDATE u.lots SET card_id=?, updated_at=? WHERE game=? AND card_id=?", (new, ts, self.game, old))
            c.execute("UPDATE OR IGNORE u.wishlist SET card_id=? WHERE game=? AND card_id=?", (new, self.game, old))
            c.execute("DELETE FROM u.wishlist WHERE game=? AND card_id=?", (self.game, old))
            mine = "checklist_id IN (SELECT id FROM u.checklists WHERE game=?)"
            c.execute(f"UPDATE OR IGNORE u.checklist_items SET card_id=? WHERE card_id=? AND {mine}", (new, old, self.game))
            c.execute(f"DELETE FROM u.checklist_items WHERE card_id=? AND {mine}", (old, self.game))
            c.execute(f"UPDATE OR IGNORE u.checklist_picks SET card_id=? WHERE card_id=? AND {mine}", (new, old, self.game))
            c.execute(f"DELETE FROM u.checklist_picks WHERE card_id=? AND {mine}", (old, self.game))
            c.execute("UPDATE OR IGNORE u.card_tags SET card_id=?, updated_at=? WHERE game=? AND card_id=?", (new, ts, self.game, old))
            c.execute("DELETE FROM u.card_tags WHERE game=? AND card_id=?", (self.game, old))
            c.execute("UPDATE u.dream_binders SET slots=replace(slots, ?, ?), updated_at=? WHERE game=? AND slots LIKE ?", (json.dumps(old), json.dumps(new), ts, self.game, f"%{json.dumps(old)}%"))
            c.execute("UPDATE u.trades SET data=replace(data, ?, ?), updated_at=? WHERE game=? AND data LIKE ?", (json.dumps(old), json.dumps(new), ts, self.game, f"%{json.dumps(old)}%"))
        c.commit()

    def _init_scope(self):
        c = self.conn
        c.execute("CREATE TEMP TABLE IF NOT EXISTS scope(pf TEXT PRIMARY KEY)")
        c.execute("DROP VIEW IF EXISTS temp.lots_s")
        c.execute("CREATE TEMP VIEW lots_s AS SELECT * FROM u.lots l WHERE NOT EXISTS(SELECT 1 FROM temp.scope) OR COALESCE(l.portfolio,'') IN (SELECT pf FROM temp.scope)")
        c.commit()

    def set_scope(self, ids):
        """Show only these portfolios (list of ids, '' = Main); None / empty = everything."""
        ids = [i for i in (ids or [])]
        self.scope = ids or None
        self.conn.execute("DELETE FROM temp.scope")
        for i in ids:
            self.conn.execute("INSERT OR IGNORE INTO temp.scope VALUES(?)", (i,))
        self._commit()            # writing the temp table opens a transaction; ending it keeps later reads from seeing an old snapshot of the collection
        self.target_pf = ids[0] if len(ids) == 1 else (self.target_pf if self.target_pf in ids else (ids[0] if ids else self.target_pf))

    # ---- portfolios
    def accepts_of(self, pf):
        """'cards' / 'sealed' when the portfolio was set to hold only that, else '' (everything).  Main holds everything."""
        if not pf or pf == "main":
            return ""
        r = self.conn.execute("SELECT meta FROM u.portfolios WHERE uuid=? AND user_id=?", (pf, self.user_id)).fetchone()
        try:
            return (json.loads(r[0] or "{}") or {}).get("accepts", "") if r else ""
        except (ValueError, TypeError):
            return ""

    KIND_NOUN = {"cards": "cards", "sealed": "sealed products", "misc": "misc items"}

    def item_kind(self):
        """What the things you own in the open game are: 'cards' for a card game, 'misc' for toys, figures, plush, accessories ... (sealed products are 'sealed')."""
        from . import games as _games
        return "misc" if _games.is_misc(self.game) else "cards"

    def check_accepts(self, pf, kind):
        """Raise BlockedPortfolio if `pf` is limited to another kind of item (kind = 'cards' | 'sealed' | 'misc')."""
        a = self.accepts_of(pf)
        if a and a != kind:
            r = self.conn.execute("SELECT name FROM u.portfolios WHERE uuid=?", (pf,)).fetchone()
            nm = r[0] if r else "That portfolio"
            if a == "none":
                raise BlockedPortfolio(f"'{nm}' is a category (a folder for other portfolios), so {self.KIND_NOUN.get(kind, 'items')} can't be added to it directly. Pick a portfolio inside it, or change it in Portfolios.")
            raise BlockedPortfolio(f"'{nm}' only holds {self.KIND_NOUN.get(a, 'cards')}, so {self.KIND_NOUN.get(kind, 'items')} can't be added to it. Pick another portfolio (or change this one in Portfolios).")

    def portfolios(self):
        rows = [dict(r) for r in self.conn.execute("SELECT * FROM u.portfolios WHERE user_id=? AND deleted=0 ORDER BY created_at, name", (self.user_id,))]
        return rows

    def create_portfolio(self, name, color="", meta=None):
        u = new_uuid()
        self.conn.execute("INSERT INTO u.portfolios(uuid,user_id,name,color,created_at,updated_at,deleted,meta) VALUES(?,?,?,?,?,?,0,?)",
                          (u, self.user_id, name.strip(), color, now_iso(), now_iso(), json.dumps(meta) if meta else None))
        self.log("portfolio.add", "portfolio", u, {"name": name})
        self._commit()
        return u

    def update_portfolio(self, uuid, name=None, color=None, meta=None):
        r = self.conn.execute("SELECT * FROM u.portfolios WHERE uuid=? AND user_id=?", (uuid, self.user_id)).fetchone()
        if not r:
            return
        self.conn.execute("UPDATE u.portfolios SET name=?, color=?, meta=?, updated_at=? WHERE uuid=?",
                          (r["name"] if name is None else name.strip(), r["color"] if color is None else color, r["meta"] if meta is None else json.dumps(meta), now_iso(), uuid))
        self._commit()

    def delete_portfolio(self, uuid, move_to=""):
        """Removes the portfolio; its copies move to another one (Main by default) - nothing you own is ever deleted."""
        self.conn.execute("UPDATE u.lots SET portfolio=?, updated_at=? WHERE user_id=? AND portfolio=?", (move_to, now_iso(), self.user_id, uuid))
        self.conn.execute("UPDATE u.portfolios SET deleted=1, updated_at=? WHERE uuid=? AND user_id=?", (now_iso(), uuid, self.user_id))
        self.log("portfolio.delete", "portfolio", uuid, {})
        self._commit()

    # ---- trade log
    def log_trade(self, partner, notes, data):
        u = new_uuid()
        self.conn.execute("INSERT INTO u.trades(uuid,user_id,game,ts,partner,notes,data,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,0)",
                          (u, self.user_id, self.game, now_iso(), partner or "", notes or "", json.dumps(data, default=str), now_iso()))
        self.log("trade.add", "trade", u, {"partner": partner})
        if self._act is not None:                                              # (inside a trade: Undo takes the log entry away too)
            self._remember({"t": "row", "table": "trades", "id": u, "gone": 1})
        self._commit()
        return u

    def trades(self, limit=200):
        out = []
        for r in self.conn.execute("SELECT * FROM u.trades WHERE user_id=? AND game=? AND deleted=0 ORDER BY ts DESC LIMIT ?", (self.user_id, self.game, limit)):
            d = dict(r)
            try:
                d["data"] = json.loads(d["data"] or "{}")
            except ValueError:
                d["data"] = {}
            out.append(d)
        return out

    def update_trade(self, uuid, partner=None, notes=None, data=None):
        r = self.conn.execute("SELECT partner, notes, data FROM u.trades WHERE uuid=? AND user_id=?", (uuid, self.user_id)).fetchone()
        if not r:
            return
        self.conn.execute("UPDATE u.trades SET partner=?, notes=?, data=?, updated_at=? WHERE uuid=?",
                          (r["partner"] if partner is None else partner, r["notes"] if notes is None else notes, r["data"] if data is None else json.dumps(data, default=str), now_iso(), uuid))
        self._commit()

    def delete_trade(self, uuid):
        self.conn.execute("UPDATE u.trades SET deleted=1, updated_at=? WHERE uuid=? AND user_id=?", (now_iso(), uuid, self.user_id))
        self._commit()

    def sealed_totals(self):
        """{portfolio id: {copies, value, spent}} for the sealed products held (all portfolios)."""
        from . import sealedprice
        out = {}
        for r in self.conn.execute("SELECT name, qty, paid, COALESCE(portfolio,'') AS pf FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (self.user_id, self.game)):
            p = sealedprice.price_for(self, r["name"])
            o = out.setdefault(r["pf"], {"copies": 0, "value": 0.0, "spent": 0.0, "unpriced": 0})
            o["copies"] += r["qty"]
            if p and p["price"]:
                o["value"] += p["price"] * r["qty"]
            else:
                o["unpriced"] += r["qty"]
            if r["paid"] is not None:
                o["spent"] += r["paid"] * r["qty"]
        return out

    def sealed_in_view(self):
        """Sealed totals for the portfolios being looked at: {copies, value, spent, unpriced}."""
        scope = list(self.scope or [])
        tot = {"copies": 0, "value": 0.0, "spent": 0.0, "unpriced": 0}
        try:
            for pf, s in self.sealed_totals().items():
                if scope and pf not in scope:
                    continue
                for k in tot:
                    tot[k] += s[k]
        except Exception:  # noqa: BLE001 - a game with no sealed list
            pass
        return tot

    def portfolio_stats(self):
        """{portfolio id: {copies, unique, value, spent}} across ALL portfolios (ignores the current view).  Value and spent include the sealed products held there."""
        out = {}
        for pid, copies, unique, value, spent in self.conn.execute(
                "SELECT COALESCE(l.portfolio,''), SUM(l.qty), COUNT(DISTINCT l.card_id), SUM(l.qty*COALESCE(c.price_usd,0)), "
                "SUM(CASE WHEN l.purchase_price IS NOT NULL THEN l.qty*l.purchase_price ELSE 0 END) FROM u.lots l JOIN cards c ON c.id=l.card_id "
                "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY COALESCE(l.portfolio,'')", (self.user_id, self.game)):
            out[pid] = {"copies": copies or 0, "unique": unique or 0, "value": value or 0, "spent": spent or 0}
        try:
            for pid, s in self.sealed_totals().items():
                o = out.setdefault(pid, {"copies": 0, "unique": 0, "value": 0, "spent": 0})
                o["value"] += s["value"]; o["spent"] += s["spent"]; o["sealed"] = s["copies"]
        except Exception:  # noqa: BLE001 - a game with no sealed list
            pass
        return out

    def close(self):
        w = self.__dict__.pop("_cat_watch", None)
        if w:
            try:
                w.close()
            except sqlite3.Error:
                pass
        try:
            self._commit()
            self.conn.close()
        except sqlite3.Error:
            pass

    def is_closed(self):
        """True once close() has let go of the database (a card-list swap does that to the open game)."""
        try:
            self.conn.execute("SELECT 1")
            return False
        except sqlite3.ProgrammingError:
            return True

    # ------------------------------------------------------------------ schema / migration
    def _user_migrate(self):
        c = self.conn
        existing = {r[0] for r in c.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}
        ver = c.execute("PRAGMA u.user_version").fetchone()[0]
        if "lots" in existing and ver < 2:
            # v1.0.0 layout: single user, single game.  Add the multi-user / sync columns in place.
            cols = {r[1] for r in c.execute("PRAGMA u.table_info(lots)")}
            for name, ddl in (("uuid", "TEXT"), ("user_id", f"TEXT DEFAULT '{LOCAL_USER}'"), ("game", "TEXT DEFAULT 'pokemon'"),
                              ("updated_at", "TEXT"), ("deleted", "INTEGER DEFAULT 0")):
                if name not in cols:
                    c.execute(f"ALTER TABLE u.lots ADD COLUMN {name} {ddl}")
            for (lid,) in c.execute("SELECT id FROM u.lots WHERE uuid IS NULL").fetchall():
                c.execute("UPDATE u.lots SET uuid=?, updated_at=COALESCE(added, ?) WHERE id=?", (new_uuid(), now_iso(), lid))
        if "wishlist" in existing and ver < 2:
            cols = {r[1] for r in c.execute("PRAGMA u.table_info(wishlist)")}
            if "user_id" not in cols:
                c.execute("ALTER TABLE u.wishlist RENAME TO wishlist_v1")
                existing.discard("wishlist")
        c.executescript(f"""
CREATE TABLE IF NOT EXISTS u.users(id TEXT PRIMARY KEY, name TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS u.lots(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT DEFAULT '{LOCAL_USER}', game TEXT DEFAULT 'pokemon',
    card_id TEXT NOT NULL, variant TEXT, condition TEXT, language TEXT DEFAULT 'English', qty INTEGER NOT NULL,
    graded INTEGER DEFAULT 0, grade_company TEXT, grade TEXT, purchase_price REAL, notes TEXT, added TEXT,
    updated_at TEXT, deleted INTEGER DEFAULT 0, cert TEXT, location TEXT, edition TEXT);
CREATE INDEX IF NOT EXISTS u.lots_card ON lots(user_id, game, card_id);
CREATE TABLE IF NOT EXISTS u.wishlist(
    user_id TEXT, game TEXT, card_id TEXT, note TEXT, added TEXT, PRIMARY KEY(user_id, game, card_id));
CREATE TABLE IF NOT EXISTS u.checklists(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT, game TEXT, name TEXT, mode TEXT DEFAULT 'cards',
    per_variant INTEGER DEFAULT 0, rules TEXT, notes TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.checklist_items(
    checklist_id INTEGER, card_id TEXT, source TEXT, PRIMARY KEY(checklist_id, card_id));
CREATE TABLE IF NOT EXISTS u.journal(
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, user_id TEXT, game TEXT, action TEXT, entity TEXT, entity_uuid TEXT, details TEXT);
CREATE TABLE IF NOT EXISTS u.price_history(
    game TEXT, card_id TEXT, day TEXT, usd REAL, eur REAL, PRIMARY KEY(game, card_id, day));
CREATE TABLE IF NOT EXISTS u.snapshots(
    user_id TEXT, game TEXT, day TEXT, ts TEXT, total_usd REAL, total_eur REAL, copies INTEGER, unique_cards INTEGER,
    breakdown TEXT, PRIMARY KEY(user_id, game, day));
CREATE TABLE IF NOT EXISTS u.settings(
    user_id TEXT, game TEXT, key TEXT, value TEXT, PRIMARY KEY(user_id, game, key));
CREATE TABLE IF NOT EXISTS u.custom_groups(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT, game TEXT, key TEXT, label TEXT, section TEXT, help TEXT, rules TEXT,
    counts_as_art INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.checklist_picks(
    checklist_id INTEGER, slot_key TEXT, card_id TEXT, PRIMARY KEY(checklist_id, slot_key));
CREATE TABLE IF NOT EXISTS u.tombstones(
    user_id TEXT, game TEXT, kind TEXT, key TEXT, deleted_at TEXT, PRIMARY KEY(user_id, game, kind, key));
CREATE TABLE IF NOT EXISTS u.actions(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, game TEXT, ts TEXT, label TEXT, count INTEGER, ops TEXT, undone INTEGER DEFAULT 0, undone_at TEXT);
CREATE TABLE IF NOT EXISTS u.spending(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, user_id TEXT, game TEXT, day TEXT, amount_usd REAL, category TEXT, note TEXT,
    deleted INTEGER DEFAULT 0, updated_at TEXT);
CREATE TABLE IF NOT EXISTS u.card_tags(
    user_id TEXT, game TEXT, card_id TEXT, tag TEXT, value TEXT, updated_at TEXT, PRIMARY KEY(user_id, game, card_id, tag));
CREATE TABLE IF NOT EXISTS u.portfolios(
    uuid TEXT PRIMARY KEY, user_id TEXT, name TEXT, color TEXT, created_at TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.trades(
    uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, ts TEXT, partner TEXT, notes TEXT, data TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.lot_photos(
    id INTEGER PRIMARY KEY AUTOINCREMENT, lot_uuid TEXT, side TEXT, data BLOB, added TEXT);
CREATE INDEX IF NOT EXISTS u.photos_lot ON lot_photos(lot_uuid);
CREATE TABLE IF NOT EXISTS u.photo_deleted(key TEXT PRIMARY KEY, at TEXT);
CREATE TABLE IF NOT EXISTS u.set_value_history(game TEXT, set_id TEXT, day TEXT, total REAL, owned REAL, priced INTEGER, n INTEGER, PRIMARY KEY(game, set_id, day));
CREATE TABLE IF NOT EXISTS u.sealed(
    uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, upc TEXT, name TEXT, qty INTEGER, paid REAL, purchased TEXT, source TEXT, notes TEXT, portfolio TEXT,
    updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.upc_names(upc TEXT PRIMARY KEY, name TEXT);
CREATE TABLE IF NOT EXISTS u.dream_binders(
    uuid TEXT PRIMARY KEY, user_id TEXT, game TEXT, name TEXT, rows INTEGER, cols INTEGER, pages INTEGER, slots TEXT, updated_at TEXT, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u.shares(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, token TEXT, user_id TEXT, game TEXT, title TEXT, kind TEXT, scope TEXT,
    perms TEXT, expires_at TEXT, created_at TEXT, updated_at TEXT, revoked INTEGER DEFAULT 0, published_url TEXT);
""")
        lot_cols = {r[1] for r in c.execute("PRAGMA u.table_info(lots)")}
        for col in ("cert", "location", "edition", "purchased", "source", "portfolio"):
            if col not in lot_cols:
                c.execute(f"ALTER TABLE u.lots ADD COLUMN {col} TEXT")
        if "placed" not in lot_cols:
            c.execute("ALTER TABLE u.lots ADD COLUMN placed INTEGER")          # NULL = not looked at yet, 0 = came from a checklist and still needs a portfolio, 1 = placed
        if "meta" not in {r[1] for r in c.execute("PRAGMA u.table_info(portfolios)")}:
            c.execute("ALTER TABLE u.portfolios ADD COLUMN meta TEXT")          # how a portfolio is arranged: parent, linked checklists, options (JSON)
        if "wishlist_v1" in {r[0] for r in c.execute("SELECT name FROM u.sqlite_master WHERE type='table'")}:
            c.execute(f"INSERT OR IGNORE INTO u.wishlist(user_id,game,card_id,note,added) "
                      f"SELECT '{LOCAL_USER}','pokemon',card_id,note,added FROM u.wishlist_v1")
            c.execute("DROP TABLE u.wishlist_v1")
        from . import grading
        grading.ensure(self)                                                   # (the grading tracker's table: always there, so the sync stamp can count it)
        from . import sold
        sold.ensure(self)                                                      # (so is the sold history: cardvault/sold.py)
        from . import customitems
        customitems.ensure(self)                                               # (and your own items: cardvault/customitems.py)
        c.execute("INSERT OR IGNORE INTO u.users VALUES(?,?,?)", (LOCAL_USER, "Me", now_iso()))
        c.execute(f"PRAGMA u.user_version={USER_SCHEMA_VERSION}")
        c.commit()

    def _backfill_dex(self):
        rows = self.conn.execute("SELECT id, raw FROM cards WHERE detailed=1 AND dex IS NULL AND raw IS NOT NULL").fetchall()
        if not rows:
            return
        for r in rows:
            self.conn.execute("UPDATE cards SET dex=? WHERE id=?", (dex_from_raw(r["raw"]) or "", r["id"]))
        self._commit()

    # ------------------------------------------------------------------ journal / backups
    def log(self, action, entity, entity_uuid="", details=None):
        self.conn.execute("INSERT INTO u.journal(ts,user_id,game,action,entity,entity_uuid,details) VALUES(?,?,?,?,?,?,?)",
                          (now_iso(), self.user_id, self.game, action, entity, entity_uuid, json.dumps(details or {}, default=str)))
        self._changes_since_backup += 1

    def _commit(self):
        if not self._defer:
            self.conn.commit()

    def commit(self):
        self.conn.commit()

    def backup_dir(self):
        d = self.secure.backup_dir() if self.secure else os.path.join(self.data_dir, "backups")
        os.makedirs(d, exist_ok=True)
        return d

    def backup_now(self, reason="auto", extra_dir=None):
        """Consistent copy of collection.db (SQLite online-backup API).  Returns the file path."""
        self._commit()
        name = f"collection-{datetime.datetime.now():%Y%m%d-%H%M%S}-{reason}.db"
        paths = []
        plain = None
        if self.secure:                        # one readable copy, in the private working folder only, encrypted into every backup folder
            import tempfile
            from .security import crypto
            fd, plain = tempfile.mkstemp(suffix=".db", dir=os.path.dirname(self.user_path))
            os.close(fd)
            src = sqlite3.connect(self.user_path)
            dest = sqlite3.connect(plain)
            try:
                src.backup(dest)
            finally:
                dest.close()
                src.close()
        try:
            for d in filter(None, (self.backup_dir(), extra_dir)):
                try:
                    os.makedirs(d, exist_ok=True)
                    if self.secure:
                        paths.append(self.secure.write_backup(plain, d, name))
                        continue
                    dest_path = os.path.join(d, name)
                    src = sqlite3.connect(self.user_path)
                    dest = sqlite3.connect(dest_path)
                    try:
                        src.backup(dest)
                    finally:
                        dest.close()
                        src.close()
                    paths.append(dest_path)
                except (OSError, sqlite3.Error):
                    continue
        finally:
            if plain:
                crypto.wipe_file(plain)
        self._changes_since_backup = 0
        self.prune_backups()
        return paths[0] if paths else None

    def list_backups(self):
        d = self.backup_dir()
        ext = ".db.enc" if self.secure else ".db"
        files = [os.path.join(d, f) for f in os.listdir(d) if f.startswith("collection-") and f.endswith(ext)]
        return sorted(files, reverse=True)

    def prune_backups(self, keep=60):
        for f in self.list_backups()[keep:]:
            try:
                os.remove(f)
            except OSError:
                pass

    def auto_backup_if_needed(self, max_age_minutes=60, extra_dir=None):
        files = self.list_backups()
        if files:
            age = datetime.datetime.now().timestamp() - os.path.getmtime(files[0])
            if age < max_age_minutes * 60:
                return None
        return self.backup_now("auto", extra_dir)

    def integrity_ok(self):
        try:
            return self.conn.execute("PRAGMA u.integrity_check").fetchone()[0] == "ok"
        except sqlite3.Error:
            return False

    # ------------------------------------------------------------------ catalogue
    def card_count(self):
        return self.conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]

    def meta(self, key, default=""):
        r = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return r[0] if r else default

    def set_meta(self, key, value):
        self.conn.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (key, value))
        self._commit()

    def invalidate_index(self):
        self._index = None
        self._cl_rev += 1

    def sets(self, edition=None):
        rows = self.conn.execute(
            "SELECT s.*, (SELECT COUNT(*) FROM cards c WHERE c.set_id=s.id) AS n "
            "FROM sets s ORDER BY release_date DESC, name").fetchall()
        return [r for r in rows if edition_of(r["serie"]) == edition] if edition else rows

    def card(self, card_id):
        return self.conn.execute(
            "SELECT c.*, s.name AS set_name, s.official AS set_official, s.total AS set_total, s.serie AS serie, "
            "s.release_date AS release_date FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id=?", (card_id,)).fetchone()

    def canon_rarities(self):
        """The card lists spell some rarities two ways ('Illustration rare' / 'Illustration Rare', 'Double rare' / 'Double Rare'), so a checklist or filter for one spelling
        silently missed the other.  Every spelling is rewritten to the most common one (ties: the one with capitals)."""
        try:
            total = self.conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
            done = self.conn.execute("SELECT value FROM meta WHERE key='rarity_canon'").fetchone()
            if done and done[0] == str(total):
                return                                              # already tidied for this card list (a refresh that adds cards makes it run again)
            groups = {}
            for rar, n in self.conn.execute("SELECT rarity, COUNT(*) FROM cards WHERE rarity IS NOT NULL AND rarity<>'' GROUP BY rarity"):
                groups.setdefault(rar.strip().lower(), []).append((rar, n))
            changed = 0
            for variants in groups.values():
                if len({r for r, _ in variants}) < 2:
                    continue
                best = max(variants, key=lambda t: (sum(ch.isupper() for ch in t[0]), t[1]))[0]
                for rar, _ in variants:
                    if rar != best:
                        changed += self.conn.execute("UPDATE cards SET rarity=? WHERE rarity=?", (best, rar)).rowcount
            self.conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('rarity_canon', ?)", (str(total),))
            self._commit()
        except sqlite3.Error:
            pass

    def canon_categories(self):
        """Pokémon lists name a card's kind many ways ('Supporter', 'Trainer - Item', 'Basic Fire Energy', 'Water'...), so those cards fell out of the Pokémon / Trainer / Energy groups.  Rewritten to the
        three kinds, once per card list."""
        try:
            from . import games
            if not games.game_by_id(self.game).pokemon:
                return
            total = self.conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
            done = self.conn.execute("SELECT value FROM meta WHERE key='category_canon'").fetchone()
            if done and done[0] == f"{total}:2":                                     # (:2 = Pokémon Tools / machines / an Energy known only by its name are recognised too)
                return
            upd = []
            for cid, cat, types, name in self.conn.execute("SELECT id, category, types, name FROM cards").fetchall():
                new = taxonomy.canon_category(cat, types, name)
                if new != cat:
                    upd.append((new, cid))
            if upd:
                self.conn.executemany("UPDATE cards SET category=? WHERE id=?", upd)
            self.conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('category_canon', ?)", (f"{total}:2",))
            self._commit()
        except sqlite3.Error:
            pass

    def card_index(self):
        """Every card as a light dict; used by checklist rules, progress and exports.  Worked out once per card list (and kept in a file beside it, see classcache)."""
        if self._index is None:
            building = self.__dict__.get("_building")
            if building is not None and building.gi_running:
                return self.__dict__.get("_partial") or []            # (asked from inside the build itself: what there is so far, as before)
            if self._no_wait:
                raise IndexNotReady()
            run(self.index_steps())
        return self._index

    def index_steps(self):
        """card_index() in short steps, for the browser build: it has one thread, and working the index out for the 105,000 Magic cards takes seconds there, so it is done a step per quiet moment
        (see scheduler 'warm') and a click in between is answered at once.  Nothing shows until the last step; a card_index() call meanwhile finishes the same build instead of starting another."""
        if self._index is None:
            if self.__dict__.get("_building") is None:
                self._building = self._build_index()
            yield from self._building

    def _build_index(self):
        try:
            while True:
                rev = self._cl_rev
                self.canon_rarities()
                yield
                self.canon_categories()
                yield
                index = yield from self._read_index_steps()
                by_id = {c["id"]: c for c in index}
                self._partial = index
                yield
                tags, thr = self.card_tags(), self.art_threshold()
                saved = yield from classcache.load_steps(self, tags, thr)        # what the last opening worked out, when it still fits
                dex = self._fill_dex(index, by_id, saved)
                yield
                yield from self._register_taxonomy_steps()
                yield from self._assign_groups_steps(index, saved, tags, thr)
                if saved is None:
                    classcache.save(self, index, tags, thr, dex or {})
                    yield
                self._apply_custom_groups(index, tags)
                if rev == self._cl_rev:
                    break
                yield                                                           # (the card list changed while this was under way - the day's prices: start over)
            self._index, self._index_by_id = index, by_id
            self._group_ids = {}
            self._facets, self._facets_ed = None, {}                           # (the illustrator / Pokédex lookups are made when something first asks - see facets())
        finally:
            self._building = self._partial = None

    def card_lights(self, ids):
        """{card id: light dict} for just these cards - from the card index when it is worked out already, otherwise read straight from the card list (so the first page of a 100,000-card game
        does not first wait for the whole index).  Read that way a card has its price, number, rarity and set, but no groups or edition: ask card_light() for those."""
        ids = list(dict.fromkeys(ids))
        if self._index is not None:
            return {cid: self._index_by_id[cid] for cid in ids if cid in self._index_by_id}
        out = {}
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for r in self.conn.execute(f"SELECT {INDEX_COLUMNS} FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id IN ({','.join('?' * len(chunk))})", chunk):
                out[r["id"]] = dict(r)
        return out

    def card_set_ids(self):
        """[(card id, set id)] for every card - from the card index when it is worked out, otherwise one quick read of the card list (enough for counting sets)."""
        if self._index is not None:
            return [(c["id"], c["set_id"]) for c in self._index]
        return self.conn.execute("SELECT id, set_id FROM cards").fetchall()

    def _read_index_steps(self, step=10000):
        """Every card of the list as a dict (with its set's name and date), when it came out for sorting (see ERA_START), and ONE spelling of each illustrator.
        Read a slice of the table per step and put in order afterwards - the same order as ORDER BY s.release_date DESC, c.set_id, c.sort_key, c.local_id (one ORDER BY over all of Magic was a
        step of 0.7 s here, longer in the browser)."""
        top = self.conn.execute("SELECT MAX(rowid) FROM cards").fetchone()[0] or 0
        index, within, day = [], [], []                                             # (each card's place within its day, and its day - worked out as it is read)
        for lo in range(0, top, step):
            for r in self.conn.execute(f"SELECT {INDEX_COLUMNS} FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.rowid>? AND c.rowid<=?", (lo, lo + step)):
                c = dict(r)
                index.append(c)
                within.append((_sql_order(c["set_id"]), _sql_order(c["sort_key"]), _sql_order(c["local_id"])))
                day.append(_sql_order(c["release_date"]))
            yield
        order = sorted(range(len(index)), key=within.__getitem__)
        order.sort(key=day.__getitem__, reverse=True)                              # (newest first; a sort keeps the order above among cards of the same day, reversed or not)
        index = [index[i] for i in order]
        yield
        spelled = {}
        for c in index:
            c["eff_date"] = (ERA_START.get(c.get("era_hint") or "", "") if c.get("serie") == "Miscellaneous" else (c.get("release_date") or ""))
            name = (c.get("illustrator") or "").strip()
            if name:
                spelled[name] = spelled.get(name, 0) + 1
        taxonomy.set_illustrator_aliases(spelled)
        yield
        canon = {}                                                                  # (a few thousand distinct names across a hundred thousand cards: each is worked out once)
        for c in index:
            raw = c.get("illustrator")
            if raw not in canon:
                canon[raw] = taxonomy.canon_illustrator(raw)                       # ("N/A" is no illustrator)
            c["illustrator"] = canon[raw]
        yield
        return index

    def _fill_dex(self, index, by_id, saved):
        """Pokémon cards with no Pokédex number (promos, prize packs...) get the number of the Pokémon named in their title, so a checklist for that Pokémon counts them.
        -> {card id: numbers} that were filled in (None for a game that is not Pokémon)."""
        from . import checklists, games
        if not games.game_by_id(self.game).pokemon:
            return None
        if saved is not None:
            for cid, dex in saved.dex.items():
                c = by_id.get(cid)
                if c is not None and not c.get("dex"):
                    c["dex"] = dex
            return saved.dex
        missing = {c["id"] for c in index if not c.get("dex")}
        try:
            checklists.infer_missing_dex(index)
        except Exception:  # noqa: BLE001 - never let a naming quirk stop the collection from loading
            return {}
        return {c["id"]: c["dex"] for c in index if c["id"] in missing and c.get("dex")}

    def _assign_groups_steps(self, index, saved, tags, thr):
        """Give every card its groups (rarity, kind, colour, trait ...): the saved ones where there are some, else worked out now."""
        pokemon = taxonomy.is_pokemon()
        fresh = saved is None
        if fresh and not pokemon:
            self._attach_facets(index)
            yield
        ancient = self._ancient_ids(None if fresh else set(tags)) if pokemon else set()          # (when the groups come from the saved answer only the cards the person corrected are worked out again)
        known = saved.groups if saved else {}
        editions = {}
        step = 5000 if fresh else 50000
        for n, c in enumerate(index, 1):
            groups = known.get(c["id"])
            if groups is None:
                c["ancient"] = c["id"] in ancient
                groups = taxonomy.classify(c, tags.get(c["id"]), thr) if pokemon else taxonomy.classify_generic(c)
            c["groups"] = groups
            serie = c.get("serie")
            if serie not in editions:
                editions[serie] = edition_of(serie)
            c["edition"] = editions[serie]
            if n % step == 0:
                yield

    def _attach_facets(self, index):
        """Each card's own filter values (attribute, traits, special printing...), which the other games' groups are made from (see gamefacets)."""
        try:
            facets = gamefacets.card_map(self.conn)
        except Exception:  # noqa: BLE001 - a list without them still has its other groups
            return
        for c in index:
            c["facets"] = facets.get(c["id"], {})

    def _ancient_ids(self, only=None):
        """The cards with the Ancient trait (all of them, or just those among `only`)."""
        if only is None:
            return {r[0] for r in self.conn.execute("SELECT id FROM cards WHERE INSTR(raw, 'Ancient Trait') > 0")}
        found, ids = set(), list(only)
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            found |= {r[0] for r in self.conn.execute(f"SELECT id FROM cards WHERE INSTR(raw, 'Ancient Trait') > 0 AND id IN ({','.join('?' * len(chunk))})", chunk)}
        return found

    def _lookups(self):
        """{'illustrator': {name: [card ids]}, 'dex': {Pokédex number: [card ids]}} for the open list."""
        illustrators, dex = {}, {}
        for c in self._index:
            if c.get("illustrator"):
                illustrators.setdefault(c["illustrator"], []).append(c["id"])
            for d in (c.get("dex") or "").split(","):
                if d.strip().isdigit():
                    dex.setdefault(int(d), []).append(c["id"])
        return {"illustrator": illustrators, "dex": dex}

    # ---- card groups (taxonomy) and the user's per-card overrides
    def get_setting(self, key, default=None):
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game=? AND key=?", (self.user_id, self.game, key)).fetchone()
        return r[0] if r else default

    def excluded_cards(self, set_id=None):
        """Cards the person left out of a set (their own custom master set): {set id: {card ids}}, or just one set's ids."""
        try:
            d = json.loads(self.get_setting("master_excluded") or "{}")
        except ValueError:
            d = {}
        d = {k: set(v) for k, v in d.items() if isinstance(v, list)}
        return d.get(set_id, set()) if set_id is not None else d

    def look_get(self):
        """The look (theme, accent...) that follows the account to every device.  Stored once per person, not per game ('*')."""
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game='*' AND key='look'", (self.user_id,)).fetchone()
        try:
            d = json.loads(r[0]) if r else {}
        except ValueError:
            d = {}
        return d if isinstance(d, dict) else {}

    def look_set(self, look):
        self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, "*", "look", json.dumps(look, sort_keys=True)))
        self._commit()

    def here_get(self):
        """"Where I was" (page, game, that game's filters, the item open) - one per account, not per game ('*'); synced so another device can offer to carry on there (webapi/hereapi.py)."""
        r = self.conn.execute("SELECT value FROM u.settings WHERE user_id=? AND game='*' AND key='here'", (self.user_id,)).fetchone()
        try:
            d = json.loads(r[0]) if r else {}
        except ValueError:
            d = {}
        return d if isinstance(d, dict) else {}

    def here_set(self, here):
        self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, "*", "here", json.dumps(here, sort_keys=True)))
        self._commit()

    def set_setting(self, key, value):
        if value is None:
            self.conn.execute("DELETE FROM u.settings WHERE user_id=? AND game=? AND key=?", (self.user_id, self.game, key))
        else:
            self.conn.execute("INSERT OR REPLACE INTO u.settings VALUES(?,?,?,?)", (self.user_id, self.game, key, str(value)))
        self._commit()

    def art_threshold(self):
        try:
            return float(self.get_setting("art_threshold", taxonomy.ART_STD_THRESHOLD))
        except (TypeError, ValueError):
            return taxonomy.ART_STD_THRESHOLD

    def card_tags(self):
        out = {}
        try:                                         # the owner's published corrections (Card Data) first; this person's own edits below win on this device
            from . import corrections
            data_dir = os.path.dirname(os.path.dirname(self.gdir))
            pub = (corrections.load(data_dir).get("games") or {}).get(self.game)
            if pub:
                by_tcg = {str(t): i for i, t in self.conn.execute("SELECT id, tcg_id FROM cards WHERE tcg_id IS NOT NULL")}
                for cid, tags in corrections.tags_for(data_dir, self.game, by_tcg).items():
                    out.setdefault(cid, {}).update(tags)
        except Exception:  # noqa: BLE001 - a damaged cache must never break the app
            pass
        for cid, tag, val in self.conn.execute("SELECT card_id, tag, value FROM u.card_tags WHERE user_id=? AND game=?", (self.user_id, self.game)):
            out.setdefault(cid, {})[tag] = val
        return out

    def set_card_tag(self, card_id, tag, value):
        """tag 'art' / 'altart', value 'yes' / 'no' / None (back to automatic)."""
        old = self.conn.execute("SELECT value FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (self.user_id, self.game, card_id, tag)).fetchone()
        self._remember({"t": "tag", "card": card_id, "tag": tag, "prev": old[0] if old else None})
        self.conn.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND card_id=? AND tag=?", (self.user_id, self.game, card_id, tag))
        if value:
            self.conn.execute("INSERT INTO u.card_tags VALUES(?,?,?,?,?,?)", (self.user_id, self.game, card_id, tag, value, now_iso()))
            self._untomb("tag", f"{card_id}|{tag}")
        else:
            self._tomb("tag", f"{card_id}|{tag}")
        self.log("card.tag", "card", "", {"card_id": card_id, "tag": tag, "value": value})
        self._commit()
        self.invalidate_index()

    def _members(self, edition=None):
        """{group id: [card ids]} - made for every group in ONE pass over the card list (a game with 800 traits used to scan the whole list 800 times), kept until the card list changes."""
        idx = self.card_index()
        hit = getattr(self, "_gm", None)
        if hit is None or hit[0] is not idx:
            hit = self._gm = (idx, {})
        m = hit[1].get(edition)
        if m is None:
            m = {}
            for c in idx:
                if edition and c["edition"] != edition:
                    continue
                for g in c["groups"]:
                    m.setdefault(g, []).append(c["id"])
            hit[1][edition] = m
        return m

    def group_ids(self, group_id, edition=None):
        return self._members(edition).get(group_id, [])

    def set_covers(self):
        """{set id: card id}: the card whose picture stands for a set that has no logo of its own (the most striking one that has a picture; for a toy list the first / priciest)."""
        key = self.catalog_fp()                                           # (the card list itself - no need to build the whole card index for this)
        hit = getattr(self, "_covers", None)
        if hit and key is not None and hit[0] == key:
            return hit[1]
        best = {}
        for cid, sid, art, price in self.conn.execute("SELECT id, set_id, art_score, price_usd FROM cards WHERE image_base IS NOT NULL AND image_base!=''"):
            k = (art or 0, min(price or 0, 400))
            if sid not in best or k > best[sid][0]:
                best[sid] = (k, cid)
        out = {sid: cid for sid, (_k, cid) in best.items()}
        self._covers = (key, out)
        return out

    def group_counts(self, edition=None):
        """{group id: (owned, total)} over the whole catalogue (or one edition of it).  The totals are worked out once per card list; only what you own is counted again."""
        owned = self.owned_map()
        idx = self.card_index()
        cache = getattr(self, "_gc_tot", None)
        if cache is None or cache[0] is not idx:
            cache = (idx, {})
            self._gc_tot = cache
        tot = cache[1].get(edition)
        if tot is None:
            tot = {}
            for c in idx:
                if edition and c["edition"] != edition:
                    continue
                for g in c["groups"]:
                    tot[g] = tot.get(g, 0) + 1
            cache[1][edition] = tot
        own = {}
        for cid, q in owned.items():
            c = self._index_by_id.get(cid) if q else None
            if c is None or (edition and c["edition"] != edition):
                continue
            for g in c["groups"]:
                own[g] = own.get(g, 0) + 1
        return {g: (own.get(g, 0), t) for g, t in tot.items()}

    def facets(self, edition=None):
        """{'illustrator': {name: [card ids]}, 'dex': {number: [card ids]}} over the whole catalogue (or one edition of it)."""
        self.card_index()
        if self._facets is None:
            self._facets = self._lookups()
        if not edition:
            return self._facets
        if edition not in self._facets_ed:
            ids = {c["id"] for c in self._index if c["edition"] == edition}
            self._facets_ed[edition] = {k: {n: [i for i in lst if i in ids] for n, lst in d.items() if any(i in ids for i in lst)} for k, d in self._facets.items()}
        return self._facets_ed[edition]

    # ---- your own categories (dev tools) - saved in collection.db, so they survive catalogue and program updates
    def custom_groups(self):
        return self.conn.execute("SELECT * FROM u.custom_groups WHERE user_id=? AND game=? AND deleted=0 ORDER BY label COLLATE NOCASE",
                                 (self.user_id, self.game)).fetchall()

    def _register_taxonomy(self):
        run(self._register_taxonomy_steps())

    def _register_taxonomy_steps(self):
        from . import games
        g = games.game_by_id(self.game)
        dynamic = []
        if not g.pokemon:
            q = lambda col: [r[0] for r in self.conn.execute(f"SELECT DISTINCT {col} FROM cards WHERE {col} IS NOT NULL AND {col}!=''")]          # (each a pass over the whole card list: a step of its own)
            rars = sorted(q("rarity"), key=lambda r: (taxonomy_rank(r, g.rarity_order), r))
            yield
            colours = sorted({p.strip() for v in q("types") for p in v.split(",") if p.strip()})
            yield
            cats = sorted(q("category"))
            yield
            from . import gamefacets as _gfx
            rars, cats_ok, colours = _gfx.dimension_values(g.id, rars, cats, colours)          # only what is worth grouping by for THIS game (no edition sizes as rarities, no duplicate product types)
            facets, fsec = [], []
            try:                                               # the game's own ways of grouping: attributes, traits, special printings...
                from . import gamefacets
                gamefacets.ensure(self.conn, g.id)
                for d in gamefacets.values(self.conn, g.id):
                    vals = [x["v"] for x in d["values"] if x["v"] != "Regular"]
                    if vals:
                        facets.append((d["key"], d["label"], vals))
                        fsec.append(("f_" + d["key"], "By " + d["label"][0].lower() + d["label"][1:]))
            except Exception:  # noqa: BLE001 - a list without them still works
                facets, fsec = [], []
            dynamic = taxonomy.dynamic_groups(rars, cats_ok, colours, g.type_label, facets)
        customs, meta = [], {}
        for r in self.custom_groups():
            customs.append(taxonomy.Group(r["key"], r["label"], r["section"] or "custom", r["help"] or ""))
            try:
                rules = json.loads(r["rules"] or "{}")
            except ValueError:
                rules = {}
            meta[r["key"]] = {"rules": rules, "counts_as_art": bool(r["counts_as_art"])}
        taxonomy.configure(g.pokemon, dynamic, customs, meta, g.type_label, g.rarity_order, fsec if not g.pokemon else ())

    def _apply_custom_groups(self, index, tags):
        """Add each user category to the cards that match its rules / were added by hand, minus the ones removed by hand."""
        dyn = {g.id for g in taxonomy._state["dynamic"]}
        if dyn:                                            # hand corrections on a non-Pokémon game's rarity / type / colour groups
            for c in index:
                t = tags.get(c["id"])
                if t and dyn & set(t):
                    gs = set(c["groups"])
                    for gid, val in t.items():
                        if gid in dyn:
                            (gs.add if val == "yes" else gs.discard)(gid)
                    c["groups"] = frozenset(gs)
        customs = [(g.id, taxonomy.custom_meta(g.id)) for g in taxonomy._state["custom"]]
        if not customs:
            return
        from . import checklists
        for c in index:
            t = tags.get(c["id"], {})
            groups = set(c["groups"])
            c["groups"] = groups
            for key, meta in customs:
                rules = meta["rules"]
                m = bool(rules.get("include")) and any(checklists.clause_matches(c, cl) for cl in rules["include"]) \
                    and not any(checklists.clause_matches(c, cl) for cl in rules.get("exclude", []))
                forced = t.get(key)
                m = True if forced == "yes" else (False if forced == "no" else m)
                if m:
                    groups.add(key)
                    if meta["counts_as_art"] and t.get("art") != "no":
                        groups.add("art")
            c["groups"] = frozenset(groups)

    def create_custom_group(self, label, section="custom", help="", rules=None, counts_as_art=False):
        base = "c_" + (taxonomy._slug(label) or "category")
        key, n = base, 2
        existing = {r[0] for r in self.conn.execute("SELECT key FROM u.custom_groups WHERE user_id=? AND game=?", (self.user_id, self.game))}
        while key in existing:
            key, n = f"{base}-{n}", n + 1
        u = new_uuid()
        self.conn.execute("INSERT INTO u.custom_groups(uuid,user_id,game,key,label,section,help,rules,counts_as_art,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
                          (u, self.user_id, self.game, key, label, section, help, json.dumps(rules or {"include": [], "exclude": []}), 1 if counts_as_art else 0, now_iso(), now_iso()))
        self._remember({"t": "grp", "key": key, "prev": {"deleted": 1}, "name": label})
        self.log("category.create", "category", u, {"key": key, "label": label})
        self._commit()
        self.invalidate_index()
        self._register_taxonomy()
        return key

    def update_custom_group(self, key, label, section, help, rules, counts_as_art):
        old = next((r for r in self.custom_groups() if r["key"] == key), None)
        if old:
            self._remember({"t": "grp", "key": key, "name": old["label"], "prev": {k: old[k] for k in ("label", "section", "help", "rules", "counts_as_art")}})
        self.conn.execute("UPDATE u.custom_groups SET label=?, section=?, help=?, rules=?, counts_as_art=?, updated_at=? WHERE user_id=? AND game=? AND key=?",
                          (label, section, help, json.dumps(rules), 1 if counts_as_art else 0, now_iso(), self.user_id, self.game, key))
        self.log("category.update", "category", "", {"key": key, "label": label})
        self._commit()
        self.invalidate_index()
        self._register_taxonomy()

    def delete_custom_group(self, key):
        old = next((r for r in self.custom_groups() if r["key"] == key), None)
        if old:
            self._remember({"t": "grp", "key": key, "name": old["label"], "prev": {"deleted": 0}})
        self.conn.execute("UPDATE u.custom_groups SET deleted=1, updated_at=? WHERE user_id=? AND game=? AND key=?", (now_iso(), self.user_id, self.game, key))
        for (cid, val) in self.conn.execute("SELECT card_id, value FROM u.card_tags WHERE user_id=? AND game=? AND tag=?", (self.user_id, self.game, key)).fetchall():
            self._remember({"t": "tag", "card": cid, "tag": key, "prev": val})
            self._tomb("tag", f"{cid}|{key}")
        self.conn.execute("DELETE FROM u.card_tags WHERE user_id=? AND game=? AND tag=?", (self.user_id, self.game, key))
        self.log("category.delete", "category", "", {"key": key})
        self._commit()
        self.invalidate_index()
        self._register_taxonomy()

    def export_categories(self, path):
        """All your own categories + every hand correction as JSON - the way to carry them into a future update or another PC."""
        cats = [{"key": r["key"], "label": r["label"], "section": r["section"], "help": r["help"], "counts_as_art": bool(r["counts_as_art"]),
                 "rules": json.loads(r["rules"] or "{}")} for r in self.custom_groups()]
        data = {"format": 1, "game": self.game, "exported": now_iso(), "categories": cats, "corrections": self.card_tags(),
                "art_threshold": self.get_setting("art_threshold")}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=1, ensure_ascii=False)
        return len(cats), len(data["corrections"])

    def import_categories(self, path):
        """Merge a categories file: adds missing categories and corrections, never overwrites what you already set."""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        have = {r["key"] for r in self.custom_groups()}
        added = 0
        self._defer = True
        try:
            for c in data.get("categories", []):
                if c["key"] in have:
                    continue
                u = new_uuid()
                self.conn.execute("INSERT INTO u.custom_groups(uuid,user_id,game,key,label,section,help,rules,counts_as_art,created_at,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
                                  (u, self.user_id, self.game, c["key"], c["label"], c.get("section") or "custom", c.get("help") or "", json.dumps(c.get("rules") or {}),
                                   1 if c.get("counts_as_art") else 0, now_iso(), now_iso()))
                added += 1
            for cid, tags in (data.get("corrections") or {}).items():
                for tag, val in tags.items():
                    self.conn.execute("INSERT OR IGNORE INTO u.card_tags VALUES(?,?,?,?,?,?)", (self.user_id, self.game, cid, tag, val, now_iso()))
            self.log("category.import", "category", "", {"added": added, "file": os.path.basename(path)})
        finally:
            self._defer = False
            self.conn.commit()
        self.invalidate_index()
        self._register_taxonomy()
        return added

    def _auto_import_categories(self):
        """A dev_categories_<game>.json dropped into the data folder (e.g. shipped with an update) is merged once per change."""
        import hashlib
        p = os.path.join(self.data_dir, f"dev_categories_{self.game}.json")
        if not os.path.exists(p):
            return
        try:
            digest = hashlib.sha1(open(p, "rb").read()).hexdigest()
            if self.get_setting("dev_categories_hash") != digest:
                self.import_categories(p)
                self.set_setting("dev_categories_hash", digest)
        except (OSError, ValueError, KeyError):
            pass

    def best_card(self, ids):
        """The most striking card among these ids (see taxonomy.cool_score), preferring one that has a picture address."""
        self.card_index()
        best, key = None, (-1, -1.0)
        for i in ids:
            c = self._index_by_id.get(i)
            if not c:
                continue
            k = (taxonomy.cool_score(c), min(c.get("price_usd") or 0, 400))
            if k > key:
                best, key = c, k
        return best

    def card_light(self, card_id):
        self.card_index()
        return self._index_by_id.get(card_id)

    def card_basic(self, card_id):
        """One card's name, set, number, rarity and price without waiting for the card index (see card_lights) - enough for a line about it.  card_light() also has its groups."""
        return self.card_lights([card_id]).get(card_id)

    def distinct(self, column):
        vals = set()
        for (v,) in self.conn.execute(f"SELECT DISTINCT {column} FROM cards WHERE {column} IS NOT NULL AND {column}!=''"):
            for part in str(v).split(","):
                if part.strip():
                    vals.add(part.strip())
        return sorted(vals)

    def series_names(self):
        return [r[0] for r in self.conn.execute("SELECT DISTINCT serie FROM sets WHERE serie IS NOT NULL ORDER BY serie")]

    def _has_era(self):
        if getattr(self, "_era_col", None) is None:
            self._era_col = any(r[1] == "era_hint" for r in self.conn.execute("PRAGMA table_info(cards)"))
        return self._era_col

    def _fold_use(self):
        """True when every card and set of the open list carries its folded search words (cardvault/searchfold.py).  A list made before they existed gets them the first time it is opened; a few that
        are missing (a list just edited) are filled in on the spot.  Looked at again whenever the card list's file changed; a list that can't be written to is searched the slow way."""
        fp = self.catalog_fp()
        if fp is None or self.__dict__.get("_fold_fp") != fp:
            try:
                self.conn.execute("PRAGMA busy_timeout=1500")                    # (never make the app wait half a minute for a file another job holds)
                if not searchfold.complete(self.conn):
                    searchfold.fill(self.conn)
                self._fold_ok = searchfold.complete(self.conn)
            except sqlite3.Error:
                self._fold_ok = False
            finally:
                try:
                    self.conn.execute("PRAGMA busy_timeout=30000")
                except sqlite3.Error:
                    pass
            self._fold_fp = self.catalog_fp()
        return self._fold_ok

    def _own_exists(self):
        return ("EXISTS(SELECT 1 FROM lots_s l WHERE l.card_id=c.id AND l.user_id=? AND l.game=? AND l.deleted=0)",
                [self.user_id, self.game])

    def catalog_fp(self):
        """A fingerprint of the open game's card list: it changes whenever anything is written to the card list's file - by this connection or any other (a price refresh, a correction, a new list) -
        and NOT when your collection changes (that lives in another file).  Worked out with a second, read-only connection that only watches SQLite's own change counter: microseconds.
        When a list worked out from the card list alone has the same fingerprint as last time it is still right.  None = can't tell, so nothing is kept."""
        w = self.__dict__.get("_cat_watch")
        if w is None:
            try:
                w = sqlite3.connect("file:" + os.path.join(self.gdir, "cards.db").replace("\\", "/") + "?mode=ro", uri=True, timeout=5, check_same_thread=False)
            except sqlite3.Error:
                w = False
            self._cat_watch = w
        if not w:
            return None
        try:
            return (self.game, w.execute("PRAGMA data_version").fetchone()[0])
        except sqlite3.Error:
            return None

    def query_cards(self, set_id=None, serie=None, text="", show="all", ctype=None, rarity=None, sort="default", only_ids=None, edition=None,
                    price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None, priced="", letter="", fuzzy=False):
        """The cards matching the filters, in order: [(id, name, set id, number)].  With fuzzy=True (the search boxes, not lookups by name): when few cards match the words as typed, the cards
        that match them with typos corrected ('charzard' -> Charizard) follow the exact ones (cardvault/fuzzy.py)."""
        kw = dict(set_id=set_id, serie=serie, show=show, ctype=ctype, rarity=rarity, sort=sort, only_ids=only_ids, edition=edition, price_min=price_min, price_max=price_max, set_text=set_text,
                  artist=artist, year_min=year_min, year_max=year_max, priced=priced, letter=letter)
        out = self._query_cards_exact(text=text, **kw)
        if fuzzy and len(out) < fuzzy_mod.FEW and (text or "").strip():
            fixed = fuzzy_mod.correct_text(self.fuzzy_vocab(), alias_text(text).strip())
            if fixed:
                have = {r[0] for r in out}
                out = list(out) + [r for r in self._query_cards_exact(text=fixed, **kw) if r[0] not in have]
        return out

    def fuzzy_vocab(self):
        """The name words of this card list (cardvault/fuzzy.py), kept per card-list fingerprint; findfast.warm_steps makes it ahead of need."""
        fp = self.catalog_fp()
        kept = self.__dict__.get("_fuzzy")
        if kept is None or fp is None or kept[0] != fp:
            counts = {}
            have = {r[1] for r in self.conn.execute("PRAGMA main.table_info(cards)")}
            for col in ("name", "name_en"):
                if col in have:
                    fuzzy_mod.count_words((r[0] for r in self.conn.execute(f"SELECT DISTINCT {col} FROM main.cards")), counts)
            kept = self._fuzzy = (fp, fuzzy_mod.Vocab(counts))
        return kept[1]

    def fuzzy_vocab_steps(self, chunk=6000):
        """fuzzy_vocab() made in short steps (a yield between parts) for the background warm-up (findfast.warm_steps): one go held the engine ~0.4 s on Magic."""
        fp = self.catalog_fp()
        kept = self.__dict__.get("_fuzzy")
        if fp is None or (kept is not None and kept[0] == fp):
            return
        counts = {}
        have = {r[1] for r in self.conn.execute("PRAGMA main.table_info(cards)")}
        for col in ("name", "name_en"):
            if col not in have:
                continue
            names = [r[0] for r in self.conn.execute(f"SELECT DISTINCT {col} FROM main.cards")]
            yield
            for i in range(0, len(names), chunk):
                fuzzy_mod.count_words(names[i:i + chunk], counts)
                yield
        if self.catalog_fp() == fp:                                  # (the list changed meanwhile: fuzzy_vocab() makes it again when asked)
            self._fuzzy = (fp, fuzzy_mod.Vocab(counts))

    def _query_cards_exact(self, set_id=None, serie=None, text="", show="all", ctype=None, rarity=None, sort="default", only_ids=None, edition=None,
                           price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None, priced="", letter=""):
        """query_cards without typo tolerance.
        The order and the filters that come from the card list alone (text, set, type, rarity, price, year ...) are worked out once per card-list fingerprint and kept; what depends on YOUR collection
        (owned / missing / wishlist / spares, and the 'owned first' sorts) is applied on top in Python - so adding a card never re-sorts the whole list."""
        import collections
        owned_sort = sort in ("owned", "unowned")
        base_sort = "number" if owned_sort else sort                          # ('owned first' = the default newest-first order, with the owned ones moved to the front)
        if base_sort == "number" and not (text or "").strip():
            base_sort = "default"                                             # (with no search words the two orders are the same: one kept list for both)
        key = _query_key(set_id, serie, edition, text, ctype, rarity, base_sort, price_min, price_max, set_text, artist, year_min, year_max, priced, letter)
        fp = self.catalog_fp()
        qc = self.__dict__.get("_qcache")
        if qc is None or fp is None or qc["fp"] != fp:
            qc = self._qcache = {"fp": fp, "d": collections.OrderedDict(), "n": 0}
        rows = qc["d"].get(key) if fp is not None else None
        if rows is None and show in ("owned", "wishlist", "spares") and not owned_sort and only_ids is None:
            # the whole order is not kept yet (right after signing in): just YOUR cards straight from the list, in the same order - Magic's 3,000 of 105,000 in 0.04 s instead of 0.6 s for
            # putting all 105,000 in order first.  (Not kept: it depends on your collection; the whole order is still worked out the first time a full list is shown.)
            return self._query_cards_sql(set_id=set_id, serie=serie, text=text, show=show, ctype=ctype, rarity=rarity, sort=base_sort, only_ids=None, edition=edition, price_min=price_min,
                                         price_max=price_max, set_text=set_text, artist=artist, year_min=year_min, year_max=year_max, priced=priced, letter=letter)
        if rows is None:
            filters = dict(text=text, ctype=ctype, rarity=rarity, price_min=price_min, price_max=price_max, set_text=set_text, artist=artist, year_min=year_min, year_max=year_max,
                           priced=priced, letter=letter)
            rows = self._cut_from_order(qc, base_sort, edition, filters) if fp is not None and not set_id and not serie else None
            shared = qc.get("by_id")                                              # (every kept order holds the SAME row tuples: ten orders of Magic cost ten lists of pointers, not ten copies)
            if rows is None and fp is not None and not set_id and not serie and not any(v not in (None, "") for v in filters.values()) and findfast.ready(self):
                rows = self._whole_order(shared, base_sort, edition)
            if rows is None:
                rows = self._query_cards_sql(set_id=set_id, serie=serie, show="all", sort=base_sort, only_ids=None, edition=edition, **filters)
            if not isinstance(rows, tuple):
                rows = tuple(shared.get(r[0], r) for r in rows) if shared else tuple(rows)
            if fp is not None and len(rows) <= 200000:                           # (a huge list is not kept: memory matters more than speed there)
                qc["d"][key] = rows
                if shared is None and not any(filters.values()) and not set_id and not serie and not edition:
                    qc["by_id"] = shared = {r[0]: r for r in rows}                 # (the first whole order: its rows are the ones every other order shares)
                cost = qc.setdefault("cost", {})[key] = len(rows) * (1 if shared else 8)   # (a list of shared rows is pointers only; one with rows of its own costs ~8x as much)
                qc["n"] += cost
                while qc["n"] > 2000000 and len(qc["d"]) > 1:
                    old, _rows = qc["d"].popitem(last=False)
                    qc["n"] -= qc["cost"].pop(old, 0)
        else:
            qc["d"].move_to_end(key)
        out = rows
        if show == "owned" or show == "missing":
            have = self.owned_map()
            out = [r for r in out if (r[0] in have) == (show == "owned")]
        elif show == "wishlist":
            want = self.wishlist_ids()
            out = [r for r in out if r[0] in want]
        elif show == "spares":
            two = {r[0] for r in self.conn.execute("SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 GROUP BY card_id HAVING SUM(qty)>=2", (self.user_id, self.game))}
            out = [r for r in out if r[0] in two]
        if owned_sort:
            have = self.owned_map()
            mine = [r for r in out if r[0] in have]
            rest = [r for r in out if r[0] not in have]
            out = mine + rest if sort == "owned" else rest + mine
        if only_ids is not None:
            keep = set(only_ids)
            out = [r for r in out if r[0] in keep]
        return list(out)

    def _whole_order(self, shared, sort, edition):
        """Every card in the order of `sort`, read from the slim copy - just the ids when the rows are at hand already (Magic: ~0.2 s instead of ~0.5).
        Uses the order findfast.warm_steps asked SQLite for one step earlier (whole_cursor) when there is one, so the sort and the reading are two short steps, not one long one."""
        pre, self._pre_order = self.__dict__.get("_pre_order"), None
        cur = pre[2] if pre and pre[:2] == (self.catalog_fp(), sort) and not edition and (shared or pre[3]) else None
        try:
            if cur is None:
                cur = self.whole_cursor(sort, edition, full=not shared)
            rows = cur.fetchall()
            return tuple(shared[r[0]] for r in rows) if shared else rows
        except (KeyError, sqlite3.Error):
            return None

    def whole_cursor(self, sort, edition=None, full=None):
        """SQLite's answer for the whole order of `sort`, sorted but not read yet (the sort happens in execute; reading 100,000 rows is the other half of the time)."""
        if full is None:
            full = not (self.__dict__.get("_qcache") or {}).get("by_id")
        return self._query_cards_sql(sort=sort, edition=edition, slim=True, ids_only=False if full else "order", cursor=True)

    def _cut_from_order(self, qc, sort, edition, filters):
        """The cards matching `filters`, cut out of the whole order of `sort` (kept) - see cardvault/findfast.py.  None when that can't be done here (no filter, or no slim copy): ask SQL."""
        if not any(v not in (None, "") for v in filters.values()) or not findfast.ready(self) or not self._fold_use():
            return None                                                          # (no slim copy yet - made in the background, see webapi/scheduler.find_warm - SQL answers meanwhile)
        whole = self.query_cards(sort="default" if sort == "number" else sort, edition=edition)       # ('number' IS the default order before the search words move exact names up)
        try:
            hits = dict(self._query_cards_sql(sort=sort, edition=edition, ids_only="rank", **filters))
        except sqlite3.Error:
            return None
        rows = [r for r in whole if r[0] in hits]
        if sort == "default" and (filters.get("text") or "").strip():
            rows.sort(key=lambda r: hits[r[0]])                                  # a name that IS the words typed first, then names starting with them (the rest stay in the default order)
        return tuple(rows)                                                       # (rows of the kept order: shared already)

    def whole_order_kept(self, edition=None):
        """True when query_cards has the whole list's default order at hand already (or can't tell: then it is asked)."""
        qc, fp = self.__dict__.get("_qcache"), self.catalog_fp()
        return bool(edition or fp is None or (qc is not None and qc["fp"] == fp and _query_key(edition=edition) in qc["d"]))

    def newest_cards(self, limit, edition=None):
        """The first `limit` cards of the whole list in the default order (newest first), without putting all of it in order - the first look at a game's Cards page (Magic: 0.2 s instead of 0.4).
        None when the whole order is kept already (query_cards is quicker then).  `edition` only says how that kept order is filed ('' or None: no edition)."""
        if self.whole_order_kept(edition):
            return None
        cur = self.conn.cursor()
        cur.row_factory = None
        return cur.execute(f"SELECT c.id, c.name, c.set_id, c.local_id FROM cards c LEFT JOIN sets s ON s.id=c.set_id ORDER BY {eff_date_sql(self._has_era())} DESC, c.set_id, c.sort_key, c.local_id LIMIT ?",
                           (int(limit),)).fetchall()

    def _query_cards_sql(self, set_id=None, serie=None, text="", show="all", ctype=None, rarity=None, sort="default", only_ids=None, edition=None,
                         price_min=None, price_max=None, set_text="", artist="", year_min=None, year_max=None, priced="", letter="", ids_only=False, slim=False, cursor=False):
        """The SQL behind query_cards.  Read from the slim copy (cardvault/findfast.py) with slim=True or ids_only:
        ids_only="rank": [(card id, rank)] of the matching cards in no order - rank 0 = the name IS the words typed, 1 = the name starts with them, 2 = the rest (what the default order puts first);
        ids_only="order": [(card id,)] in order."""
        sql = (f"SELECT c.id, c.name, c.set_id, c.local_id FROM {findfast.TABLE if ids_only or slim else 'cards'} c "
               "LEFT JOIN sets s ON s.id=c.set_id")
        where, args = [], []
        if set_id:
            where.append("c.set_id=?")
            args.append(set_id)
        if serie:
            where.append("s.serie=?")
            args.append(serie)
        if edition == "pocket":
            where.append("s.serie LIKE '%pocket%'")
        elif edition == "tcg":
            where.append("(s.serie IS NULL OR s.serie NOT LIKE '%pocket%')")
        self.conn.create_function("fold", 1, _fold, deterministic=True)
        text = alias_text(text)
        quick = self._fold_use()                                                    # (the words are folded in the list already: cardvault/searchfold.py)
        for tok in text.split():
            m = _NUMTOK.match(tok)
            if m and (m.group(1) or m.group(3)):                                        # "#4", "004/165" or "4/102": that card number (and, with a slash, in a set of that size)
                where.append("(c.local_id GLOB '[0-9]*' AND CAST(c.local_id AS INTEGER)=?" + (" AND (s.official=? OR s.total=?))" if m.group(3) else ")"))
                args += [int(m.group(2))] + ([int(m.group(3))] * 2 if m.group(3) else [])
                continue
            alts = fuzzy_mod.alternatives(tok) if "|" in tok else [tok]                 # ('charizard|charmander': a typo corrected to its closest words - cardvault/fuzzy.py)
            likes = [f"%{_fold(a)}%" for a in alts]
            plain = bool(m) and not m.group(1) and not m.group(3) and tok.startswith("0") and len(tok) > 1   # "025": also the card NUMBER 25 (a typed "25" is found inside "025" as it always was)
            num = " OR (c.local_id GLOB '[0-9]*' AND CAST(c.local_id AS INTEGER)=?)" if plain else ""
            if quick:                                    # one LIKE per card and per set instead of nine Python calls per card (a Magic search: 3.7 s in the browser -> a fraction of a second)
                if len(likes) > 1:                       # a typo corrected to its closest words: they come from the card names
                    where.append("(" + " OR ".join("c.fold LIKE ?" for _ in likes) + ")")
                    args += likes
                    continue
                where.append("(c.fold LIKE ? OR c.set_id IN (SELECT id FROM sets WHERE fold LIKE ?)" + num + ")")      # (the sets that match are found once - not the set's words looked at again for every card: 70 ms -> 35 ms on Magic)
                args += [likes[0], likes[0]] + ([int(m.group(2))] if plain else [])
                continue
            where.append("(" + " OR ".join("fold(c.name) LIKE ? OR fold(c.local_id) LIKE ? OR fold(c.illustrator) LIKE ? OR fold(s.name) LIKE ? OR fold(c.rarity) LIKE ? OR fold(c.name_ja) LIKE ? OR fold(c.name_en) LIKE ?"
                                           " OR fold(s.name_ja) LIKE ? OR fold(s.name_en) LIKE ?" for _ in likes) + num + ")")
            args += [x for like in likes for x in [like] * 9] + ([int(m.group(2))] if plain else [])
        own_sql, own_args = self._own_exists()
        if show == "owned":                                                         # (IN, not EXISTS: SQLite then starts from your cards instead of checking all of the list's, 0.04 s vs 0.3 s)
            where.append("c.id IN (SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0)")
            args += own_args
        elif show == "missing":
            where.append("NOT " + own_sql)
            args += own_args
        elif show == "wishlist":
            where.append("c.id IN (SELECT card_id FROM u.wishlist WHERE user_id=? AND game=?)")
            args += [self.user_id, self.game]
        elif show == "spares":                                                      # cards I hold two or more copies of
            where.append("c.id IN (SELECT card_id FROM lots_s WHERE user_id=? AND game=? AND deleted=0 GROUP BY card_id HAVING SUM(qty)>=2)")
            args += [self.user_id, self.game]
        if year_min not in (None, ""):                                              # the set came out in this year or later / earlier
            where.append("CAST(substr(s.release_date,1,4) AS INTEGER) >= ?")
            args.append(int(year_min))
        if year_max not in (None, ""):
            where.append("CAST(substr(s.release_date,1,4) AS INTEGER) BETWEEN 1 AND ?")
            args.append(int(year_max))
        if priced == "yes":
            where.append("c.price_usd IS NOT NULL AND c.price_usd > 0")
        elif priced == "no":
            where.append("(c.price_usd IS NULL OR c.price_usd <= 0)")
        if letter:                                                                  # the name starts with this letter ("#" = a digit or symbol)
            col = "c.fold" if quick else "fold(c.name)"                              # (the folded words of a card begin with its folded name)
            if letter == "#":
                where.append(f"{col} NOT GLOB '[a-z]*'")
            else:
                where.append(f"{col} LIKE ?")
                args.append(_fold(letter)[:1] + "%")
        if ctype and taxonomy.is_pokemon() and ctype in TCG_TYPES:               # a Pokemon type: the card HAS that type (alone or with another - a Delta Species Grass/Metal card is both), never just a word inside a name
            toks = ["Darkness", "Dark"] if ctype == "Darkness" else [ctype]
            where.append("(" + " OR ".join("(',' || REPLACE(REPLACE(c.types, ', ', ','), '/', ',') || ',') LIKE ?" for _ in toks) + ")")
            args += [f"%,{t},%" for t in toks]
        elif ctype:
            where.append("c.types LIKE ?")
            args.append(f"%{ctype}%")
        if rarity:
            where.append("c.rarity=?")
            args.append(rarity)
        if price_min is not None:
            where.append("c.price_usd >= ?")
            args.append(float(price_min))
        if price_max is not None:
            where.append("c.price_usd <= ?")
            args.append(float(price_max))
        for tok in (set_text or "").split():                                       # the set's name contains these words
            where.append("s.fold LIKE ?" if quick else "fold(s.name) LIKE ?")
            args.append(f"%{_fold(tok)}%")
        for tok in (artist or "").split():                                         # the illustrator's name contains these words
            where.append("fold(c.illustrator) LIKE ?")
            args.append(f"%{_fold(tok)}%")
        if where:
            sql += " WHERE " + " AND ".join(where)
        if ids_only == "rank":
            rank, rargs = _rank_sql(text, "c.fname", "c.nname")
            args = rargs + args
            cur = self.conn.cursor()
            cur.row_factory = None
            return cur.execute(sql.replace("SELECT c.id, c.name, c.set_id, c.local_id", f"SELECT c.id, {rank}", 1), args).fetchall()
        first = ""
        if text.strip() and sort == "default":           # a card whose NAME is what you typed comes first, then names that start with it (or 'name + number'), then the rest
            expr, rargs = _rank_sql(text, "fold(c.name)", fuzzy_mod.norm_sql("fold(c.name)"))
            first = expr + ", "
            args += rargs
        if sort in ("owned", "unowned"):                  # what you own first, or what you do NOT own first (then newest sets first)
            first = f"CASE WHEN {own_sql} THEN {0 if sort == 'owned' else 1} ELSE {1 if sort == 'owned' else 0} END, "
            args += own_args
        ed = eff_date_sql(self._has_era())
        order = {
            "owned": first + ed + " DESC, c.set_id, c.sort_key, c.local_id",
            "unowned": first + ed + " DESC, c.set_id, c.sort_key, c.local_id",
            "default": first + ed + " DESC, c.set_id, c.sort_key, c.local_id",
            "oldest": f"({ed} IS NULL), {ed} ASC, c.set_id, c.sort_key, c.local_id",
            "name": "c.name COLLATE NOCASE, s.release_date",
            "price": "COALESCE(c.price_usd, -1) DESC, c.name",
            "priceasc": "(c.price_usd IS NULL), c.price_usd ASC, c.name",
            "namez": "c.name COLLATE NOCASE DESC, s.release_date",
            "dex": "(c.dex IS NULL OR c.dex=''), CAST(c.dex AS INTEGER), c.name COLLATE NOCASE, s.release_date",
            "number": ed + " DESC, c.set_id, c.sort_key, c.local_id",
            "numasc": "c.set_id, c.sort_key, c.local_id",
            "set": "s.name COLLATE NOCASE, c.sort_key, c.local_id",
            "rarity": "(c.rarity IS NULL OR c.rarity=''), c.rarity COLLATE NOCASE, c.name COLLATE NOCASE",
            "artist": "(c.illustrator IS NULL OR c.illustrator=''), c.illustrator COLLATE NOCASE, c.name COLLATE NOCASE",
        }.get(sort) or ed + " DESC, c.set_id, c.sort_key, c.local_id"
        sql += " ORDER BY " + order
        if ids_only == "order":
            sql = sql.replace("SELECT c.id, c.name, c.set_id, c.local_id", "SELECT c.id", 1)
        cur = self.conn.cursor()
        cur.row_factory = None                                                       # (plain tuples straight from SQLite: making a Row and then a tuple of each of 100,000 cards was a third of the time)
        if cursor:
            return cur.execute(sql, args)                                            # (sorted, not read yet - see whole_cursor)
        rows = cur.execute(sql, args).fetchall()
        if only_ids is not None:
            keep = set(only_ids)
            rows = [r for r in rows if r[0] in keep]
        return rows

    # ------------------------------------------------------------------ recent actions (undo)
    @contextlib.contextmanager
    def action(self, label=None):
        """Group everything done inside the block into ONE entry of the recent-actions log (e.g. 'Removed 25 cards')."""
        if self._act is not None:
            yield self._act
            return
        a = _Action(label)
        self._act = a
        prev_defer = self._defer
        self._defer = True
        try:
            yield a
        finally:
            self._act = None
            self._defer = prev_defer
            if a.ops:
                self._save_action(a)
            self.conn.commit()

    SEALED_COLS = ("name", "qty", "paid", "purchased", "source", "notes", "upc", "portfolio", "deleted")

    def _sealed_state(self):
        return {r["uuid"]: {k: r[k] for k in self.SEALED_COLS} for r in self.conn.execute(
            "SELECT uuid, " + ",".join(self.SEALED_COLS) + " FROM u.sealed WHERE user_id=? AND game=?", (self.user_id, self.game))}

    def sealed_action(self, label, fn):
        """Run a change to the sealed products as ONE undoable entry: what each purchase row looked like before is kept (new rows come back as deleted), so Undo restores it all."""
        before = self._sealed_state()
        with self.action(label):
            out = fn()
            after = self._sealed_state()
            for u, prev in before.items():
                if after.get(u) != prev:
                    self._remember({"t": "sealed", "id": u, "prev": prev})
            for u in after:
                if u not in before:
                    self._remember({"t": "sealed", "id": u, "prev": {"deleted": 1, "qty": 0}})
        return out

    def _remember(self, op):
        if self._suppress:
            return
        if self._act is not None:
            self._act.ops.append(op)
            return
        a = _Action()
        a.ops.append(op)
        self._save_action(a)

    def _describe(self, ops):
        lots = [o for o in ops if o["t"] == "lot"]
        if lots:
            cards = {o["card"] for o in lots}
            first = self.card_basic(next(iter(cards)))                  # (a name: no need to wait for the card index)
            subject = (first["name"] if first else "a card") if len(cards) == 1 else f"{len(cards)} cards"
            whats = {o["what"] for o in lots}
            if whats == {"remove"}:
                return f"Removed {subject} from your collection"
            if whats == {"add"}:
                return f"Added {subject} to your collection"
            return f"Changed copies of {subject}"
        w = [o for o in ops if o["t"] == "wish"]
        if w:
            return f"{'Removed from' if w[0]['prev'] else 'Added to'} the wishlist" + (f": {len(w)} cards" if len(w) > 1 else "")
        cl = [o for o in ops if o["t"] == "cl"]
        if cl:
            kind = "Deleted" if cl[0]["prev"].get("deleted") == 0 else ("Created" if cl[0]["prev"].get("deleted") == 1 else "Edited")
            return f"{kind} checklist '{cl[0].get('name', '')}'"
        g = [o for o in ops if o["t"] == "grp"]
        if g:
            kind = "Deleted" if g[0]["prev"].get("deleted") == 0 else ("Created" if g[0]["prev"].get("deleted") == 1 else "Edited")
            return f"{kind} category '{g[0].get('name', '')}'"
        if any(o["t"] == "sealed" for o in ops):
            return "Changed sealed products"
        if any(o["t"] == "tag" for o in ops):
            return f"Changed the categories of {len({o['card'] for o in ops if o['t'] == 'tag'})} card(s)"
        if any(o["t"] in ("cli", "pick") for o in ops):
            return "Changed a checklist"
        return f"Changed {len(ops)} item(s)"

    def _save_action(self, a):
        label = a.label or self._describe(a.ops)
        count = len({o.get("card") or o.get("id") or o.get("key") for o in a.ops})
        cur = self.conn.execute("INSERT INTO u.actions(user_id,game,ts,label,count,ops,undone) VALUES(?,?,?,?,?,?,0)",
                                (self.user_id, self.game, now_iso(), label, count, json.dumps(a.ops)))
        a.id = cur.lastrowid
        a.label = label
        self.conn.execute("DELETE FROM u.actions WHERE user_id=? AND game=? AND id NOT IN "
                          "(SELECT id FROM u.actions WHERE user_id=? AND game=? ORDER BY id DESC LIMIT 1000)", (self.user_id, self.game) * 2)

    def recent_actions(self, limit=100, offset=0, text=""):
        like = "%" + (text or "").strip().replace("%", "").replace("_", "") + "%"
        return self.conn.execute("SELECT * FROM u.actions WHERE user_id=? AND game=? AND label LIKE ? ORDER BY id DESC LIMIT ? OFFSET ?",
                                 (self.user_id, self.game, like, limit, offset)).fetchall()

    def last_undoable(self):
        return self.conn.execute("SELECT * FROM u.actions WHERE user_id=? AND game=? AND undone=0 ORDER BY id DESC LIMIT 1", (self.user_id, self.game)).fetchone()

    def undo_action(self, action_id):
        """Reverse one logged action.  Returns how many changes were reversed (0 if it was already undone)."""
        r = self.conn.execute("SELECT * FROM u.actions WHERE id=? AND user_id=? AND game=?", (action_id, self.user_id, self.game)).fetchone()
        if not r or r["undone"]:
            return 0
        ops = json.loads(r["ops"])
        self._suppress = True
        self._defer = True
        try:
            for op in reversed(ops):
                self._apply_inverse(op)
        finally:
            self._suppress = False
            self._defer = False
        self.conn.execute("UPDATE u.actions SET undone=1, undone_at=? WHERE id=?", (now_iso(), action_id))
        self.log("action.undo", "action", "", {"id": action_id, "label": r["label"]})
        self.conn.commit()
        self._cl_rev += 1
        self.invalidate_index()
        self._register_taxonomy()
        return len(ops)

    def _apply_inverse(self, op):
        t, c, ts = op["t"], self.conn, now_iso()
        if t == "lot":
            prev = op["prev"]
            c.execute("UPDATE u.lots SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE id=?", (*prev.values(), ts, op["id"]))
        elif t == "tag":
            self.set_card_tag(op["card"], op["tag"], op["prev"])
        elif t == "wish":
            if (op["card"] in self.wishlist_ids()) != bool(op["prev"]):
                self.toggle_wishlist(op["card"])
        elif t == "cl":
            prev = op["prev"]
            c.execute("UPDATE u.checklists SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE id=?", (*prev.values(), ts, op["id"]))
        elif t == "cli":
            self.set_checklist_card(op["id"], op["card"], op["prev"])
        elif t == "pick":
            self.set_pick(op["id"], op["slot"], op["prev"])
        elif t == "spend":
            prev = op["prev"]
            c.execute("UPDATE u.spending SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE id=?", (*prev.values(), ts, op["id"]))
        elif t == "sealed":
            prev = op["prev"]
            c.execute("UPDATE u.sealed SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE uuid=? AND user_id=?", (*prev.values(), ts, op["id"], self.user_id))
        elif t == "row":                                      # rows changed with plain SQL (cardvault/rowundo.py)
            from . import rowundo
            rowundo.restore(self, op, ts)
            if op.get("table") == "custom_items":                # an item of your own came or went: its card in the list follows
                from . import customitems
                customitems.materialize(self)
        elif t == "grp":
            prev = op["prev"]
            c.execute("UPDATE u.custom_groups SET " + ",".join(f"{k}=?" for k in prev) + ", updated_at=? WHERE user_id=? AND game=? AND key=?",
                      (*prev.values(), ts, self.user_id, self.game, op["key"]))

    # ------------------------------------------------------------------ collection
    def owned_map(self):
        return {r[0]: r[1] for r in self.conn.execute(
            "SELECT card_id, SUM(qty) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 GROUP BY card_id",
            (self.user_id, self.game))}

    def owned_where(self, card_id):
        """[(portfolio id or '', copies)] - where this card is held, in EVERY portfolio (not just the ones being looked at)."""
        return [(r[0], r[1]) for r in self.conn.execute(
            "SELECT COALESCE(portfolio,''), SUM(qty) FROM u.lots WHERE user_id=? AND game=? AND card_id=? AND deleted=0 AND qty>0 GROUP BY COALESCE(portfolio,'')",
            (self.user_id, self.game, card_id))]

    def owned_variants(self):
        """{card_id: set of variant labels owned}"""
        out = {}
        for cid, var in self.conn.execute(
                "SELECT card_id, variant FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0", (self.user_id, self.game)):
            out.setdefault(cid, set()).add(var)
        return out

    COND_ABBR = {"Near Mint": "NM", "Lightly Played": "LP", "Moderately Played": "MP", "Heavily Played": "HP", "Damaged": "D"}

    def owned_conditions(self):
        """{card_id: {variant: 'NM' | 'NM/LP' | 'PSA 10'}} - the condition of the copies held (graded copies show their company and grade)."""
        out = {}
        for cid, var, cond, graded, comp, grade in self.conn.execute(
                "SELECT card_id, variant, condition, graded, grade_company, grade FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 ORDER BY id", (self.user_id, self.game)):
            ab = (f"{comp or ''} {grade or ''}".strip() or "Graded") if graded else self.COND_ABBR.get(cond or "", cond or "")
            lst = out.setdefault(cid, {}).setdefault(var, [])
            if ab and ab not in lst:
                lst.append(ab)
        return {c: {v: "/".join(l) for v, l in vs.items()} for c, vs in out.items()}

    def owned_variant_qty(self):
        """{(card_id, variant label): copies} - how many of each printing are held."""
        out = {}
        for cid, var, q in self.conn.execute("SELECT card_id, variant, SUM(qty) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND qty>0 GROUP BY card_id, variant", (self.user_id, self.game)):
            out[(cid, var)] = q or 0
        return out

    def owned_by_set(self):
        return {r[0]: r[1] for r in self.conn.execute(
            "SELECT c.set_id, COUNT(DISTINCT c.id) FROM cards c JOIN lots_s l ON l.card_id=c.id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.set_id", (self.user_id, self.game))}

    def wishlist_ids(self):
        return {r[0] for r in self.conn.execute("SELECT card_id FROM u.wishlist WHERE user_id=? AND game=?", (self.user_id, self.game))}

    def lots_for(self, card_id):
        return self.conn.execute(
            "SELECT * FROM lots_s WHERE card_id=? AND user_id=? AND game=? AND deleted=0 ORDER BY id",
            (card_id, self.user_id, self.game)).fetchall()

    def add_lot(self, card_id, variant="Normal", condition="Near Mint", qty=1, graded=False,
                company="", grade="", price=None, notes="", language="English", cert="", location="", edition="", purchased="", source="", portfolio=None):
        portfolio = self.target_pf if portfolio is None else portfolio
        self.check_accepts(portfolio, self.item_kind())
        if not graded and not notes:
            r = self.conn.execute(
                "SELECT id, uuid, qty FROM u.lots WHERE card_id=? AND user_id=? AND game=? AND deleted=0 AND variant=? AND condition=? "
                "AND language=? AND graded=0 AND COALESCE(notes,'')='' AND purchase_price IS ? "
                "AND COALESCE(location,'')=? AND COALESCE(edition,'')=? AND COALESCE(portfolio,'')=? AND COALESCE(purchased,'')=? AND COALESCE(source,'')=?",
                (card_id, self.user_id, self.game, variant, condition, language, price, location or "", edition or "", portfolio or "", purchased or "", source or "")).fetchone()
            if r:
                self._remember({"t": "lot", "id": r[0], "prev": {"qty": r[2]}, "card": card_id, "what": "add"})
                self.conn.execute("UPDATE u.lots SET qty=qty+?, updated_at=? WHERE id=?", (qty, now_iso(), r[0]))
                self.log("lot.qty", "lot", r[1], {"card_id": card_id, "delta": qty})
                self._commit()
                return r[0]
        u = new_uuid()
        cur = self.conn.execute(
            "INSERT INTO u.lots(uuid,user_id,game,card_id,variant,condition,language,qty,graded,grade_company,grade,"
            "purchase_price,notes,cert,location,edition,purchased,source,portfolio,added,updated_at,deleted,placed) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?)",
            (u, self.user_id, self.game, card_id, variant, condition, language, qty, 1 if graded else 0, company, grade,
             price, notes, cert, location or "", edition or "", purchased or "", source or "", portfolio or "", now_iso(), now_iso(), 0 if (getattr(self, "_from_list", False) and not portfolio) else 1))
        self._remember({"t": "lot", "id": cur.lastrowid, "prev": {"deleted": 1}, "card": card_id, "what": "add"})
        self.log("lot.add", "lot", u, {"card_id": card_id, "variant": variant, "condition": condition, "qty": qty,
                                       "graded": graded, "grade": f"{company} {grade}".strip(), "price": price})
        self._commit()
        return cur.lastrowid

    LOT_FIELDS = ("variant", "condition", "language", "qty", "graded", "grade_company", "grade", "cert", "purchase_price", "notes", "location", "edition", "purchased", "source", "portfolio")

    def get_lot(self, lot_id):
        return self.conn.execute("SELECT * FROM u.lots WHERE id=?", (lot_id,)).fetchone()

    def update_lot(self, lot_id, **fields):
        """Edit any detail of one copy / stack: condition, grading company + grade + cert number, price paid, notes..."""
        bad = set(fields) - set(self.LOT_FIELDS)
        if bad:
            raise ValueError(f"unknown lot fields: {bad}")
        if not fields:
            return
        if fields.get("portfolio"):
            self.check_accepts(fields["portfolio"], self.item_kind())
        old = self.get_lot(lot_id)
        if old:
            self._remember({"t": "lot", "id": lot_id, "prev": {k: old[k] for k in fields}, "card": old["card_id"], "what": "edit"})
        sets = ", ".join(f"{k}=?" for k in fields)
        self.conn.execute(f"UPDATE u.lots SET {sets}, updated_at=? WHERE id=?", (*fields.values(), now_iso(), lot_id))
        r = self.get_lot(lot_id)
        self.log("lot.edit", "lot", r["uuid"] if r else "", {"fields": {k: v for k, v in fields.items()}})
        self._commit()

    def change_lot_qty(self, lot_id, delta):
        r = self.conn.execute("SELECT uuid, qty, card_id, deleted FROM u.lots WHERE id=?", (lot_id,)).fetchone()
        if not r:
            return
        new_qty = r["qty"] + delta
        self._remember({"t": "lot", "id": lot_id, "prev": {"qty": r["qty"], "deleted": r["deleted"]}, "card": r["card_id"], "what": "remove" if new_qty <= 0 else "qty"})
        if new_qty <= 0:
            self.conn.execute("UPDATE u.lots SET qty=0, deleted=1, updated_at=? WHERE id=?", (now_iso(), lot_id))
            self.log("lot.delete", "lot", r["uuid"], {"card_id": r["card_id"], "prev_qty": r["qty"]})
        else:
            self.conn.execute("UPDATE u.lots SET qty=?, updated_at=? WHERE id=?", (new_qty, now_iso(), lot_id))
            self.log("lot.qty", "lot", r["uuid"], {"card_id": r["card_id"], "delta": delta})
        self._commit()

    def delete_lot(self, lot_id):
        r = self.conn.execute("SELECT uuid, qty, card_id FROM u.lots WHERE id=?", (lot_id,)).fetchone()
        if r:
            self._remember({"t": "lot", "id": lot_id, "prev": {"deleted": 0, "qty": r["qty"]}, "card": r["card_id"], "what": "remove"})
            self.conn.execute("UPDATE u.lots SET deleted=1, updated_at=? WHERE id=?", (now_iso(), lot_id))
            self.log("lot.delete", "lot", r["uuid"], {"card_id": r["card_id"], "prev_qty": r["qty"]})
            self._commit()

    def undelete_lots(self, lot_ids):
        for lid in lot_ids:
            row = self.get_lot(lid)
            if row:
                self._remember({"t": "lot", "id": lid, "prev": {"deleted": row["deleted"], "qty": row["qty"]}, "card": row["card_id"], "what": "add"})
            self.conn.execute("UPDATE u.lots SET deleted=0, qty=MAX(qty,1), updated_at=? WHERE id=?", (now_iso(), lid))
        self.log("lot.undelete", "lot", "", {"ids": list(lot_ids)})
        self._commit()

    def remove_one(self, card_id, variant=None):
        r = self.conn.execute(
            "SELECT id FROM lots_s WHERE card_id=? AND user_id=? AND game=? AND deleted=0 AND (? IS NULL OR variant=?) ORDER BY id DESC LIMIT 1",
            (card_id, self.user_id, self.game, variant, variant)).fetchone()
        if r:
            self.change_lot_qty(r[0], -1)

    def default_variant(self, card_id):
        c = self.card_basic(card_id)                                        # (its variants and rarity: no need to wait for the card index)
        try:
            flags = clean_flags(json.loads((c or {}).get("variants") or "{}"), (c or {}).get("rarity"))
        except ValueError:
            flags = {}
        for k in VARIANT_FLAGS:
            if flags.get(k):
                return VARIANT_LABELS[k]
        return "Normal"

    def set_owned(self, card_id, owned, variant=None, condition="Near Mint"):
        """The quick checkbox.  Returns ('added', [lot_id]) / ('removed', [lot_ids]) / ('unchanged', [])."""
        lots = self.lots_for(card_id)
        if owned and not lots:
            lid = self.add_lot(card_id, variant or self.default_variant(card_id), condition, 1)
            return "added", [lid]
        if not owned and lots:
            ids = [l["id"] for l in lots]
            for lid in ids:
                self.delete_lot(lid)
            return "removed", ids
        return "unchanged", []

    def set_variant_owned(self, card_id, variant, owned, condition="Near Mint"):
        lots = [l for l in self.lots_for(card_id) if l["variant"] == variant]
        if owned and not lots:
            return "added", [self.add_lot(card_id, variant, condition, 1)]
        if not owned and lots:
            ids = [l["id"] for l in lots]
            for lid in ids:
                self.delete_lot(lid)
            return "removed", ids
        return "unchanged", []

    def mark_many(self, card_ids, owned):
        added, removed = [], []
        with self.action():          # one disk sync and one undo entry for the whole batch
            for cid in card_ids:
                what, ids = self.set_owned(cid, owned)
                (added if what == "added" else removed).extend(ids)
        return added, removed

    def needs_remove_confirmation(self, card_id):
        """True when removing the card would throw away more than one plain NM copy (price paid, notes, grading...)."""
        lots = self.lots_for(card_id)
        if len(lots) > 1:
            return True
        return any(l["qty"] > 1 or l["graded"] or l["purchase_price"] is not None or (l["notes"] or "") for l in lots)

    def _tomb(self, kind, key):
        """Remember that something was deleted, so a sync on another device deletes it too instead of bringing it back."""
        self.conn.execute("INSERT OR REPLACE INTO u.tombstones VALUES(?,?,?,?,?)", (self.user_id, self.game, kind, key, now_iso()))

    def _untomb(self, kind, key):
        self.conn.execute("DELETE FROM u.tombstones WHERE user_id=? AND game=? AND kind=? AND key=?", (self.user_id, self.game, kind, key))

    def toggle_wishlist(self, card_id):
        was = card_id in self.wishlist_ids()
        self._remember({"t": "wish", "card": card_id, "prev": was})
        if was:
            self.conn.execute("DELETE FROM u.wishlist WHERE card_id=? AND user_id=? AND game=?", (card_id, self.user_id, self.game))
            self._tomb("wishlist", card_id)
            self.log("wishlist.remove", "wishlist", "", {"card_id": card_id})
        else:
            self.conn.execute("INSERT INTO u.wishlist VALUES(?,?,?,?,?)", (self.user_id, self.game, card_id, "", now_iso()))
            self._untomb("wishlist", card_id)
            self.log("wishlist.add", "wishlist", "", {"card_id": card_id})
        self._commit()

    def stats(self):
        a = (self.user_id, self.game)
        copies, unique = self.conn.execute(
            "SELECT COALESCE(SUM(qty),0), COUNT(DISTINCT card_id) FROM lots_s WHERE user_id=? AND game=? AND deleted=0", a).fetchone()
        value, eur = self.conn.execute(
            f"SELECT COALESCE(SUM(l.qty*{pricepick.sql(self, lot='l')}),0), COALESCE(SUM(l.qty*c.price_eur),0) FROM lots_s l JOIN cards c ON c.id=l.card_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0", a).fetchone()
        spent = self.conn.execute(
            "SELECT COALESCE(SUM(qty*purchase_price),0) FROM lots_s WHERE user_id=? AND game=? AND deleted=0 AND purchase_price IS NOT NULL",
            a).fetchone()[0]
        return {"copies": copies, "unique": unique, "value": value, "value_eur": eur, "spent": spent}

    # ------------------------------------------------------------------ prices / value history
    def tracked_card_ids(self):
        owned = {r[0] for r in self.conn.execute("SELECT DISTINCT card_id FROM u.lots WHERE user_id=? AND game=? AND deleted=0", (self.user_id, self.game))}
        return owned | self.wishlist_ids()          # every portfolio, whatever is currently shown

    def record_price_history(self, card_ids=None, day=None):
        day = day or today()
        ids = card_ids if card_ids is not None else self.tracked_card_ids()
        for cid in ids:
            r = self.conn.execute("SELECT price_usd, price_eur, price_kind FROM cards WHERE id=?", (cid,)).fetchone()
            if r and str(r[2] or "").lower().startswith("your estimate"):
                continue                                                    # (your own estimate is not market data: it never enters price history, trends or models)
            if r and (r[0] is not None or r[1] is not None):
                self.conn.execute("INSERT OR REPLACE INTO u.price_history VALUES(?,?,?,?,?)", (self.game, cid, day, r[0], r[1]))
        if card_ids is None:
            self.record_sealed_history(day)
        self._commit()

    def record_sealed_history(self, day=None):
        """Today's market price of every sealed product you own, kept forever like card prices (key 'sealed:<name letters>'), so a portfolio's graph can include sealed products."""
        from .tcgcsv import norm_name
        day = day or today()
        try:
            for (name,) in self.conn.execute("SELECT DISTINCT name FROM u.sealed WHERE user_id=? AND game=? AND deleted=0", (self.user_id, self.game)).fetchall():
                r = self.conn.execute("SELECT price_usd FROM sealed_products WHERE norm=? AND price_usd IS NOT NULL ORDER BY price_updated DESC LIMIT 1", (norm_name(name),)).fetchone()
                if r:
                    self.conn.execute("INSERT OR REPLACE INTO u.price_history VALUES(?,?,?,?,?)", (self.game, "sealed:" + norm_name(name), day, r[0], None))
        except sqlite3.Error:
            pass                                                            # this game has no sealed list

    def price_history(self, card_id):
        return [tuple(r) for r in self.conn.execute(
            "SELECT day, usd, eur FROM u.price_history WHERE game=? AND card_id=? ORDER BY day", (self.game, card_id))]

    def value_breakdown(self):
        """Current value of the collection split several ways (used for charts and stored in each snapshot)."""
        rows = self.conn.execute(
            f"SELECT l.card_id, l.qty, {pricepick.sql(self, lot='l')} AS price_usd, c.price_eur, c.set_id, c.rarity, s.name AS set_name, s.serie "
            "FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0", (self.user_id, self.game)).fetchall()
        by_set, by_serie, by_rarity, by_card = {}, {}, {}, {}
        for r in rows:
            v = (r["price_usd"] or 0) * r["qty"]
            by_set[r["set_name"] or r["set_id"]] = by_set.get(r["set_name"] or r["set_id"], 0) + v
            by_serie[r["serie"] or "Other"] = by_serie.get(r["serie"] or "Other", 0) + v
            by_rarity[r["rarity"] or "Unknown"] = by_rarity.get(r["rarity"] or "Unknown", 0) + v
            by_card[r["card_id"]] = by_card.get(r["card_id"], 0) + v
        return {"set": by_set, "serie": by_serie, "rarity": by_rarity, "card": by_card}

    def checklist_values(self):
        out = {}
        owned = self.owned_map()
        for cl in self.checklists():
            total = 0.0
            for cid in self.checklist_members(cl["id"]):
                q = owned.get(cid, 0)
                if q:
                    c = self.card_light(cid)
                    total += (pricepick.price_for(self, cid, c["price_usd"]) or 0) * q if c else 0
            out[cl["name"]] = total
        return out

    def take_snapshot(self):
        saved = self.scope
        self.set_scope(None)                       # the saved history is always for the whole collection
        try:
            self._take_snapshot()
        finally:
            self.set_scope(saved)

    def record_set_values(self, day=None):
        """Today's value of every set (all its cards, and the copies you own) - the history behind the set analytics graph.  One point per set per day."""
        day = day or today()
        owned = {r[0]: r[1] for r in self.conn.execute(
            f"SELECT c.set_id, SUM(l.qty*COALESCE({pricepick.sql(self, lot='l')},0)) FROM lots_s l JOIN cards c ON c.id=l.card_id WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.set_id",
            (self.user_id, self.game))}
        rows = [(self.game, sid, day, tot or 0.0, owned.get(sid, 0.0) or 0.0, priced, n) for sid, tot, priced, n in self.conn.execute(
            f"SELECT c.set_id, SUM({pricepick.sql(self)}), COUNT({pricepick.sql(self)}), COUNT(*) FROM cards c GROUP BY c.set_id")]
        self.conn.executemany("INSERT OR REPLACE INTO u.set_value_history VALUES(?,?,?,?,?,?,?)", rows)
        self._commit()

    def set_value_history(self, set_id):
        return [dict(r) for r in self.conn.execute("SELECT day, total, owned, priced, n FROM u.set_value_history WHERE game=? AND set_id=? ORDER BY day", (self.game, set_id))]

    def _take_snapshot(self):
        self.record_set_values()
        st = self.stats()
        bd = self.value_breakdown()
        bd["card"] = dict(sorted(bd["card"].items(), key=lambda kv: -kv[1])[:50])
        bd["checklist"] = self.checklist_values()
        day = today()
        self.conn.execute("INSERT OR REPLACE INTO u.snapshots VALUES(?,?,?,?,?,?,?,?,?)",
                          (self.user_id, self.game, day, now_iso(), st["value"], st["value_eur"], st["copies"], st["unique"], json.dumps(bd)))
        self._commit()

    def snapshots(self):
        rows = self.conn.execute("SELECT * FROM u.snapshots WHERE user_id=? AND game=? ORDER BY day", (self.user_id, self.game)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["breakdown"] = json.loads(d["breakdown"] or "{}")
            except ValueError:
                d["breakdown"] = {}
            out.append(d)
        return out

    def top_cards(self, n=25):
        return self.conn.execute(
            f"SELECT c.id, c.name, c.set_id, c.local_id, c.rarity, {pricepick.sql(self)} AS price_usd, SUM(l.qty) AS qty, SUM(l.qty*{pricepick.sql(self, lot='l')}) AS value, s.name AS set_name "
            "FROM lots_s l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 GROUP BY c.id ORDER BY value DESC LIMIT ?",
            (self.user_id, self.game, n)).fetchall()

    # ------------------------------------------------------------------ checklists
    def checklists(self):
        return self.conn.execute(
            "SELECT * FROM u.checklists WHERE user_id=? AND game=? AND deleted=0 ORDER BY name COLLATE NOCASE",
            (self.user_id, self.game)).fetchall()

    def checklist(self, cl_id):
        return self.conn.execute("SELECT * FROM u.checklists WHERE id=?", (cl_id,)).fetchone()

    def create_checklist(self, name, mode="cards", per_variant=False, rules=None, notes=""):
        u = new_uuid()
        if isinstance(rules, dict) and "sources" not in rules:
            rules = {**rules, "sources": {"mode": "all", "ids": []}}          # a new checklist counts everything you own, until you choose otherwise
        cur = self.conn.execute(
            "INSERT INTO u.checklists(uuid,user_id,game,name,mode,per_variant,rules,notes,created_at,updated_at,deleted) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,0)",
            (u, self.user_id, self.game, name, mode, 1 if per_variant else 0, json.dumps(rules or {"include": [], "exclude": []}),
             notes, now_iso(), now_iso()))
        self._remember({"t": "cl", "id": cur.lastrowid, "prev": {"deleted": 1}, "name": name})
        self._cl_rev += 1
        self.log("checklist.create", "checklist", u, {"name": name, "mode": mode})
        self._commit()
        return cur.lastrowid

    def update_checklist(self, cl_id, name, mode, per_variant, rules, notes=""):
        old = self.checklist(cl_id)
        if old:
            self._remember({"t": "cl", "id": cl_id, "name": old["name"], "prev": {k: old[k] for k in ("name", "mode", "per_variant", "rules", "notes")}})
        self._cl_rev += 1
        self.conn.execute("UPDATE u.checklists SET name=?, mode=?, per_variant=?, rules=?, notes=?, updated_at=? WHERE id=?",
                          (name, mode, 1 if per_variant else 0, json.dumps(rules), notes, now_iso(), cl_id))
        self.log("checklist.update", "checklist", (self.checklist(cl_id) or {"uuid": ""})["uuid"], {"name": name})
        self._commit()

    def delete_checklist(self, cl_id):
        self._cl_rev += 1
        r = self.checklist(cl_id)
        if r:
            self._remember({"t": "cl", "id": cl_id, "name": r["name"], "prev": {"deleted": 0}})
        self.conn.execute("UPDATE u.checklists SET deleted=1, updated_at=? WHERE id=?", (now_iso(), cl_id))
        self.log("checklist.delete", "checklist", r["uuid"] if r else "", {"name": r["name"] if r else ""})
        self._commit()

    def checklist_manual(self, cl_id):
        out = {"manual": set(), "excluded": set()}
        for cid, src in self.conn.execute("SELECT card_id, source FROM u.checklist_items WHERE checklist_id=?", (cl_id,)):
            out[src].add(cid)
        return out

    def set_checklist_card(self, cl_id, card_id, state):
        """state: 'manual' (force in), 'excluded' (force out) or None (follow the rules)."""
        self._cl_rev += 1
        old = self.conn.execute("SELECT source FROM u.checklist_items WHERE checklist_id=? AND card_id=?", (cl_id, card_id)).fetchone()
        self._remember({"t": "cli", "id": cl_id, "card": card_id, "prev": old[0] if old else None})
        self.conn.execute("UPDATE u.checklists SET updated_at=? WHERE id=?", (now_iso(), cl_id))
        self.conn.execute("DELETE FROM u.checklist_items WHERE checklist_id=? AND card_id=?", (cl_id, card_id))
        if state:
            self.conn.execute("INSERT INTO u.checklist_items VALUES(?,?,?)", (cl_id, card_id, state))
        self.log("checklist.card", "checklist", "", {"id": cl_id, "card_id": card_id, "state": state})
        self._commit()

    def picks(self, cl_id):
        """{slot key: card id} - the card chosen to be shown on each slot of a Pokédex / rarity style checklist."""
        return {k: c for k, c in self.conn.execute("SELECT slot_key, card_id FROM u.checklist_picks WHERE checklist_id=?", (cl_id,))}

    def set_pick(self, cl_id, slot_key, card_id):
        old = self.conn.execute("SELECT card_id FROM u.checklist_picks WHERE checklist_id=? AND slot_key=?", (cl_id, slot_key)).fetchone()
        self._remember({"t": "pick", "id": cl_id, "slot": slot_key, "prev": old[0] if old else None})
        self.conn.execute("UPDATE u.checklists SET updated_at=? WHERE id=?", (now_iso(), cl_id))
        self.conn.execute("DELETE FROM u.checklist_picks WHERE checklist_id=? AND slot_key=?", (cl_id, slot_key))
        if card_id:
            self.conn.execute("INSERT INTO u.checklist_picks VALUES(?,?,?)", (cl_id, slot_key, card_id))
        self.log("checklist.pick", "checklist", "", {"id": cl_id, "slot": slot_key, "card_id": card_id})
        self._commit()

    def checklist_members(self, cl_id):
        from .checklists import members
        return members(self, self.checklist(cl_id))

    # ------------------------------------------------------------------ shares (structure for the online service)
    def shares(self):
        return self.conn.execute("SELECT * FROM u.shares WHERE user_id=? AND game=? ORDER BY id DESC", (self.user_id, self.game)).fetchall()

    def create_share(self, title, kind, scope, perms, expires_at=None):
        u = new_uuid()
        token = _uuid.uuid4().hex[:22]
        cur = self.conn.execute(
            "INSERT INTO u.shares(uuid,token,user_id,game,title,kind,scope,perms,expires_at,created_at,updated_at,revoked) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
            (u, token, self.user_id, self.game, title, kind, json.dumps(scope), json.dumps(perms), expires_at, now_iso(), now_iso()))
        self.log("share.create", "share", u, {"title": title, "kind": kind})
        self._commit()
        return cur.lastrowid

    def update_share(self, share_id, title, scope, perms, expires_at=None):
        self.conn.execute("UPDATE u.shares SET title=?, scope=?, perms=?, expires_at=?, updated_at=? WHERE id=?",
                          (title, json.dumps(scope), json.dumps(perms), expires_at, now_iso(), share_id))
        self.log("share.update", "share", "", {"id": share_id})
        self._commit()

    def delete_share(self, share_id):
        self.conn.execute("DELETE FROM u.shares WHERE id=?", (share_id,))
        self.log("share.delete", "share", "", {"id": share_id})
        self._commit()

    # ------------------------------------------------------------------ spending log
    def add_spending(self, amount_usd, category="Cards", note="", day=None):
        u = new_uuid()
        cur = self.conn.execute("INSERT INTO u.spending(uuid,user_id,game,day,amount_usd,category,note,deleted,updated_at) VALUES(?,?,?,?,?,?,?,0,?)",
                                (u, self.user_id, self.game, day or today(), float(amount_usd), category, note, now_iso()))
        self._remember({"t": "spend", "id": cur.lastrowid, "prev": {"deleted": 1}, "card": f"spend{cur.lastrowid}", "what": "add"})
        self.log("spend.add", "spending", u, {"amount": amount_usd, "category": category})
        self._commit()
        return cur.lastrowid

    def delete_spending(self, spend_id):
        r = self.conn.execute("SELECT uuid FROM u.spending WHERE id=?", (spend_id,)).fetchone()
        if r:
            self._remember({"t": "spend", "id": spend_id, "prev": {"deleted": 0}, "card": f"spend{spend_id}", "what": "remove"})
            self.conn.execute("UPDATE u.spending SET deleted=1, updated_at=? WHERE id=?", (now_iso(), spend_id))
            self._commit()

    def spending_rows(self):
        return self.conn.execute("SELECT * FROM u.spending WHERE user_id=? AND game=? AND deleted=0 ORDER BY day DESC, id DESC",
                                 (self.user_id, self.game)).fetchall()

    def spending_by_month(self):
        """{'2026-10': total_usd} for the spending log."""
        out = {}
        for r in self.spending_rows():
            out[r["day"][:7]] = out.get(r["day"][:7], 0.0) + (r["amount_usd"] or 0)
        return out

    # ------------------------------------------------------------------ bulk edit
    def bulk_update_lots(self, card_ids, **fields):
        """Change the same detail (condition, location, edition, language, notes...) on every copy of many cards at once."""
        bad = set(fields) - set(self.LOT_FIELDS) - {"qty"}
        if bad or "qty" in fields:
            raise ValueError(f"cannot bulk edit: {bad or 'qty'}")
        n = 0
        with self.action(f"Edited {len(set(card_ids))} cards"):
            for cid in set(card_ids):
                for lot in self.lots_for(cid):
                    self.update_lot(lot["id"], **fields)
                    n += 1
        return n

    # ------------------------------------------------------------------ CSV
    CSV_COLUMNS = ["card_id", "name", "set", "number", "variant", "condition", "language", "qty",
                   "graded", "grade_company", "grade", "cert", "purchase_price", "notes", "location", "edition", "purchased", "source", "portfolio"]

    def _pf_name(self, pid):
        if not pid:
            return ""
        r = self.conn.execute("SELECT name FROM u.portfolios WHERE uuid=?", (pid,)).fetchone()
        return r[0] if r else ""

    def export_csv(self, path):
        rows = self.conn.execute(
            "SELECT l.*, c.name, c.local_id, s.name AS set_name FROM u.lots l "
            "LEFT JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
            "WHERE l.user_id=? AND l.game=? AND l.deleted=0 ORDER BY l.id", (self.user_id, self.game)).fetchall()
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(self.CSV_COLUMNS)
            for r in rows:
                w.writerow([r["card_id"], r["name"], r["set_name"], r["local_id"], r["variant"], r["condition"],
                            r["language"], r["qty"], r["graded"], r["grade_company"], r["grade"], r["cert"] or "",
                            "" if r["purchase_price"] is None else r["purchase_price"], r["notes"], r["location"] or "", r["edition"] or "",
                            r["purchased"] or "", r["source"] or "", self._pf_name(r["portfolio"])])
        return len(rows)

    def _pf_by_name(self, name):
        name = (name or "").strip()
        if not name:
            return None
        r = self.conn.execute("SELECT uuid FROM u.portfolios WHERE user_id=? AND deleted=0 AND lower(name)=lower(?)", (self.user_id, name)).fetchone()
        return r[0] if r else self.create_portfolio(name)

    def _import_vault(self, gid, opened, own=False):
        """The vault a CSV row for game `gid` goes to: this one when there is no game column or it is this game, else that game's own vault
        (opened once into `opened`).  None when that game's card list is not on this device."""
        if not gid or gid == self.game:
            return self
        if gid not in opened:
            on_device = own or os.path.exists(os.path.join(game_dir(self.data_dir, gid), "cards.db"))      # (own: a line for an item of your own in the "Other" game, which has no card list to download)
            self.commit()                                  # this game's pending rows first: the other game's vault writes the same file
            opened[gid] = Vault(self.data_dir, gid, user_id=self.user_id, user_path=self.user_path, secure=self.secure) if on_device else None
        return opened[gid]

    def _import_sealed(self, row):
        """One sealed product row from a CSV (kind = sealed).  False when it has no name."""
        name = (row.get("name") or "").strip()
        if not name:
            return False
        try:
            qty = int(float(row.get("qty") or 1))
        except ValueError:
            qty = 1
        try:
            paid = float(row["purchase_price"]) if row.get("purchase_price") not in (None, "") else None
        except ValueError:
            paid = None
        pf = self._pf_by_name(row.get("portfolio"))
        self.check_accepts(pf, "sealed")
        upc = (row.get("upc") or "").strip()
        self.conn.execute("INSERT INTO u.sealed(uuid,user_id,game,upc,name,qty,paid,purchased,source,notes,portfolio,updated_at,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                          (new_uuid(), self.user_id, self.game, upc, name, max(qty, 1), paid, row.get("purchased") or "",
                           row.get("source") or "", row.get("notes") or "", pf, now_iso()))
        if upc:
            self.conn.execute("INSERT OR REPLACE INTO u.upc_names VALUES(?,?)", (upc, name))
        return True

    def _import_labels(self, cid, text):
        """The 'tag=value; tag' text of the labels column, written as this person's card tags (a bare tag keeps no value)."""
        for part in (text or "").split(";"):
            tag, sep, val = part.strip().partition("=")
            tag = tag.strip()
            if tag:
                val = val.strip() if sep and val.strip() else None
                self.conn.execute("INSERT OR REPLACE INTO u.card_tags VALUES(?,?,?,?,?,?)", (self.user_id, self.game, cid, tag, val, now_iso()))

    def import_csv(self, path):
        """Settings > Import.  Rows go to their own game when a `game` column is there (a game not on this device is skipped); without one, to
        this game as before.  kind = sealed rows become sealed products; the labels column restores card tags."""
        added = skipped = 0
        opened, known, last = {}, {}, self
        try:
            with open(path, newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    from . import customitems
                    v = self._import_vault(row.get("game") or "", opened, own=customitems.is_custom(row.get("card_id")) and (row.get("game") or "") == customitems.OTHER_GAME)
                    if v is None:
                        skipped += 1
                        continue
                    if v is not last:                      # one writer at a time on the file: the previous game's rows are committed before the next game's
                        last.commit()
                        last = v
                    if (row.get("kind") or "").strip() == "sealed":
                        ok = v._import_sealed(row)
                        added, skipped = added + ok, skipped + (not ok)
                        continue
                    if v.game not in known:
                        known[v.game] = {r[0] for r in v.conn.execute("SELECT id FROM cards")}
                    cid = (row.get("card_id") or "").strip()
                    if cid not in known[v.game] and customitems.is_custom(cid) and customitems.restore_from_row(v, row):
                        known[v.game].add(cid)                                  # (an item of your own: made again with the same id)
                    if cid not in known[v.game]:
                        skipped += 1
                        continue
                    try:
                        qty = int(float(row.get("qty") or 1))
                    except ValueError:
                        qty = 1
                    try:
                        price = float(row["purchase_price"]) if row.get("purchase_price") not in (None, "") else None
                    except ValueError:
                        price = None
                    graded = str(row.get("graded", "")).strip().lower() in ("1", "true", "yes")
                    v.add_lot(cid, row.get("variant") or "Normal", row.get("condition") or "Near Mint", max(qty, 1),
                              graded, row.get("grade_company") or "", row.get("grade") or "", price,
                              row.get("notes") or "", row.get("language") or "English", cert=row.get("cert") or "",
                              location=row.get("location") or "", edition=row.get("edition") or "", purchased=row.get("purchased") or "",
                              source=row.get("source") or "", portfolio=v._pf_by_name(row.get("portfolio")))
                    if not customitems.is_custom(cid):
                        v._import_labels(cid, row.get("labels"))                # (an item of your own keeps its labels in the item itself)
                    added += 1
        finally:
            for v in opened.values():
                if v is not None:
                    v.commit()
                    v.close()
        self.commit()
        return added, skipped

    def backup_collection(self, dest_path):
        self._commit()
        if self.secure:
            self.backup_now("manual")
            return
        src = sqlite3.connect(self.user_path)
        dest = sqlite3.connect(dest_path)
        try:
            src.backup(dest)
        finally:
            dest.close()
            src.close()

    def restore_collection(self, backup_path):
        """Replace collection.db with a backup.  A safety copy of the current file is kept first."""
        self.backup_now("before-restore")
        self._commit()
        self.conn.execute("DETACH DATABASE u")
        for suffix in ("-wal", "-shm"):
            try:
                os.remove(self.user_path + suffix)
            except OSError:
                pass
        if self.secure and backup_path.endswith(".enc"):
            from .security import crypto
            plain = self.secure.read_backup(backup_path)
            try:
                shutil.copyfile(plain, self.user_path)
            finally:
                crypto.wipe_file(plain)
        else:
            shutil.copyfile(backup_path, self.user_path)
        self.conn.execute("ATTACH DATABASE ? AS u", (self.user_path,))
        self.conn.execute("PRAGMA u.journal_mode=WAL")
        self.conn.execute("PRAGMA u.synchronous=FULL")
        self._user_migrate()
