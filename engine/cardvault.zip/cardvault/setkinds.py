"""'Extras': groups of cards that are not part of a real set and are not the promos of a generation (Professor Program promos, deck exclusives, jumbo cards, league and
championship cards, energy-only sets, fast-food and other one-off promos ...).  Each set is sorted into at most one kind by its name / id; the person can hide a whole kind
(Find & Add then leaves those sets out) and can change any set's kind by hand in Card tools.  Nothing is deleted: cards you own always stay in your portfolios.

    kind_of(game, set_id, set_name, serie) -> a key of KINDS, or '' for a normal set / the promos of a generation (SVP, SWSH, XY ... Black Star Promos stay where they are)
"""
import re

# key -> (label, one line of help)
KINDS = {
    "professor": ("Professor Program promos", "Cards given to Play! Pokémon professors."),
    "deck": ("Decks, trainer kits & deck exclusives", "Cards that only came inside a deck, kit or starter product."),
    "jumbo": ("Jumbo (oversized) cards", "Giant cards that are not part of a set."),
    "league": ("League, championship & prize-pack cards", "Organized-play and tournament cards: league and championship promos, world championship decks, prize packs."),
    "energy": ("Energy-only sets", "Sets made only of basic / special energy cards."),
    "event": ("Event, pre-release & release cards", "Cards handed out at pre-release and release events."),
    "art": ("Art series & token cards", "Art cards, tokens and other extras that are not playable set cards."),
    "promo": ("Promo cards (other games)", "A game's general promotional cards."),
    "other": ("Fast-food, store & other one-off promos", "McDonald's, Burger King, calendars, sample cards and other odd promos."),
}

# Pokemon sets by TCGplayer-group / catalog id (the Miscellaneous groups carry numeric ids)
POKEMON_IDS = {
    "2332": "professor",
    "1840": "deck", "2686": "deck", "3051": "deck", "2208": "deck",
    "1528": "jumbo", "jumbo": "jumbo",
    "1539": "league", "2282": "league", "22880": "league",
    "mee": "energy", "sve": "energy",
    "2175": "other", "2155": "other", "2148": "other", "2205": "other", "1455": "other", "24493": "other", "1423": "other", "miscp": "other", "sp": "other", "bog": "other",
    "fut2020": "other", "3179": "other", "23266": "other", "23561": "other",
}
# name patterns, tried in order, for everything else (every game)
RULES = [
    (re.compile(r"professor program", re.I), "professor"),
    (re.compile(r"\bjumbo\b|oversize", re.I), "jumbo"),
    (re.compile(r"league|championship|world champion|prize pack|organized play|tournament pack|\bregional|qualifier|\bworlds\b|judge", re.I), "league"),
    (re.compile(r"trainer kit|deck exclusive|battle academy|theme deck|battle deck", re.I), "deck"),
    (re.compile(r"\benerg(y|ies)\b\s*$", re.I), "energy"),
    (re.compile(r"mcdonald|burger king|countdown calendar|trick or trade|pikachu world collection|sample cards?|best of promos|futsal|d23|disney100", re.I), "other"),
    (re.compile(r"pre-?release|release event|\bevent\b", re.I), "event"),
    (re.compile(r"art series|\btokens?\b|\bart cards?\b|memorabilia", re.I), "art"),
    (re.compile(r"promo(tion|tional)? cards?$|promos?$|promo pack|promotional|promotion", re.I), "promo"),
]
# Pokemon: these promo sets are the promos OF A GENERATION and stay with the main sets
GENERATION_PROMO = re.compile(r"black star promos|^promos-a$|^wizards black star|alternate art promos|blister exclusives", re.I)


def kind_of(game, set_id, set_name, serie=""):
    sid, name, serie = str(set_id), set_name or "", serie or ""
    if game.startswith("pokemon"):
        if sid in POKEMON_IDS:
            return POKEMON_IDS[sid]
        if GENERATION_PROMO.search(name):
            return ""
        if re.search(r"mcdonald", serie, re.I) or sid.startswith("tk-") or serie.lower() == "trainer kits":
            return "other" if re.search(r"mcdonald", serie, re.I) else "deck"
        for rx, k in RULES:
            if k in ("promo", "event", "art"):                                 # these three are for the other games; a Pokemon promo set is a generation's promos
                continue
            if rx.search(name):
                return k
        return ""
    for rx, k in RULES:
        if k in ("professor", "jumbo") and not rx.search(name):
            continue
        if rx.search(name):
            if k == "deck":                                                        # a starter / structure deck of another game is a real product with real cards: only the Pokemon-style exclusives count
                continue
            return k
    return ""


def effective_kind(game, row, overrides):
    """The kind after the person's own choices: overrides = {set id: kind | 'main'}."""
    o = (overrides or {}).get(str(row["id"]))
    if o == "main":
        return ""
    if o in KINDS:
        return o
    return kind_of(game, row["id"], row["name"], row["serie"] if "serie" in row.keys() else "")
