"""What kind of product a sealed product is (booster box, sleeved pack, tin, three-pack blister, collector chest, case...) and which series it belongs to.

Worked out from TCGplayer's product names with ordered rules (first match wins), the same way for every game, plus a few words per game.  The result is stored in the card
list (sealed_products.kind / .serie) when the lists are built, so every app shows the same thing."""
import re

# (kind, pattern) in order: the first one that matches wins.  Patterns are matched against the lower-cased name WITHOUT its [bracket] tags and (parentheses)
# unless noted; `ALL` rules look at the whole name.
KINDS = [
    "Code card", "Case / display", "Booster box", "Half booster box", "Enhanced booster box", "Elite trainer box", "Collector chest", "Booster bundle", "Sleeved booster pack", "Checklane blister", "Hanger box", "3-pack blister",
    "2-pack blister", "Single-pack blister", "Blister (other)", "Mini tin", "Mini tin display", "Tin", "Build & battle", "Tournament collection box", "Ultra / super-premium collection", "Premium collection",
    "Collection box", "Retailer exclusive", "Secret Lair drop", "Pin / poster / binder collection", "Figure collection", "League / battle / theme deck", "Starter / structure deck", "Booster pack", "Mini / fun pack", "Prize pack", "Trainer kit", "Prerelease / kit",
    "Seasonal / gift / calendar", "Accessory / merchandise", "Oversize / promo card", "Loose card / energy", "Other product",
]

VERSION = 5                         # bump when the rules change: card lists classified by an older version are classified again (see webapi/sealedcat.py)
RETAIL_KIND = "Retailer exclusive"     # a store's own version or pack (Costco, Sam's Club, Target...), and combo packs that bundle different products together
MINI_DISPLAY = "Mini tin display"
ALIASES = {"Ultra-premium collection": "Ultra / super-premium collection", "Gift / calendar / set": "Seasonal / gift / calendar"}          # old names kept in saved choices


def kind_name(k):
    return ALIASES.get(k, k)


_CASE = re.compile(r"\bcase\b|\(case\)|\[case\]|\bcarton\b|\bmaster case\b", re.I)


def _clean(name):
    return re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", name or "").lower()


# the order below is the order of the rules (first match wins).  Names have their [bracket tags] and (parentheses) removed before matching, except where noted.
_R = lambda p: re.compile(p, re.I)
_RULES = [
    ("Code card", _R(r"\bcode[\s-]*cards?\b|\bonline\s+code\b|\bdigital\s+code\b")),
    ("Loose card / energy", _R(r"\s-\s20\d\d\s*$|\bbox\s+topper\b|\btopper\b")),
    ("Mini tin", _R(r"\bmini\s+tins?\b")),
    ("Secret Lair drop", _R(r"\bsecret\s+lair\b")),
    ("Prize pack", _R(r"\bprize\s+pack\b")),
    ("Mini / fun pack", _R(r"\bfun\s+pack\b|\bmini\s+(booster\s+)?pack\b|\bmatch\s*&\s*battle\s+pack\b|\b\d+[\s-]*card\s+(booster\s+)?pack\b")),
    ("Booster pack", _R(r"\bseries\s+\d+\s+booster\s+pack\b")),
    ("Seasonal / gift / calendar", _R(r"\btrick\s+or\s+trade\b|\bback[\s-]*to[\s-]*school\s+bundle\b|\b(spring|summer|fall|autumn|winter|holiday)\s+(20\d\d\s+)?collector'?s?\s+bundle\b|\bhalloween\b")),
    ("Half booster box", _R(r"\bhalf\s+booster\s+box(es)?\b")),
    ("Enhanced booster box", _R(r"\benhanced\s+booster\s+(display\s+)?box\b")),
    ("Hanger box", _R(r"\bhanger\b|\b(3|three)[\s-]*pack\s+booster\s+box\b")),
    ("Trainer kit", _R(r"\btrainer\s+kit\b|\btrainer'?s?\s+toolkit\b")),
    ("Starter / structure deck", _R(r"\bbattle\s+academy\b|\bmy\s+first\s+battle\b")),
    ("3-pack blister", _R(r"\bcase\s+files?\b.*\bblister\b")),
    ("Booster pack", _R(r"\bcollection\s+booster\s+packs?\b")),
    ("League / battle / theme deck", _R(r"\btheme\s+decks?\b|\bex\s+deck\b")),
    ("Seasonal / gift / calendar", _R(r"\bgift\s+(box|set)\b")),
    ("Premium collection", _R(r"\bpremium\s+(powers|treasures)\s+collection\b")),
    ("Collection box", _R(r"\btrading\s+card\s+game\s+classic\b")),
    ("Starter / structure deck", _R(r"\bex\s+battle\s+stadium\b")),
    ("Collection box", _R(r"\bcase\s+files?\b")),
    ("League / battle / theme deck", _R(r"\bbattle\s+decks?\s+bundle\b")),
    ("Booster box", _R(r"\b(booster|draft booster|play booster|set booster|collector booster|jumpstart|theme booster|starter)\s+(boxes|box|displays?)\b|\bbooster\s+display\b|\bdisplay\s+box\b|\bhalf\s+booster\b|\b(36|24|18)\s*packs?\b|\bhobby\s+box\b|\bblaster\s+box\b|\bbooster\s+brick\b|\bbooster\s+boxes\b|\b(mini|tuck|draft|jumbo)\s+box\b|\bbox\s+of\s+\d+\s+packs?\b")),
    ("Elite trainer box", _R(r"\belite\s+trainer\b|\betb\b")),
    ("Collector chest", _R(r"\bcollector'?s?\s+chests?\b")),
    ("Booster bundle", _R(r"\bbooster\s+bundle\b|\bbundles?\b|\bfat\s+pack\b|\bart\s+bundle\b")),
    ("Sleeved booster pack", _R(r"\bsleeved\s+(booster|pack)")),
    ("Checklane blister", _R(r"\bcheck-?\s*lane\b")),
    ("3-pack blister", _R(r"\b3[\s-]*packs?\s+(booster\s+)?blisters?\b|\bthree[\s-]*packs?\s+blisters?\b|\btriple\s+pack\b")),
    ("2-pack blister", _R(r"\b2[\s-]*packs?\s+blisters?\b|\btwo[\s-]*packs?\s+blisters?\b|\b2\s+booster\s+packs?\s*(&|and|\+|with)\s")),
    ("Single-pack blister", _R(r"\bsingle\s+pack\s+blisters?\b|\b1[\s-]*pack\s+blisters?\b|\bsingle\s+blisters?\b")),
    ("Blister (other)", _R(r"\bblisters?\b")),
    ("Tin", _R(r"\btins?\b|\blunch\s*box\b")),
    ("2-pack blister", _R(r"\b(2|two)[\s-]*packs?\b")),
    ("Collection box", _R(r"\b(adventure|treasure)\s+chests?\b|\bchests?\b")),
    ("Build & battle", _R(r"\bbuild\s*(&|and)\s*battle\b")),
    ("Booster pack", _R(r"\btournament\s+pack\b(?!\s+(box|collection))")),
    ("Tournament collection box", _R(r"\btournament\b|\bchampionship\s+(box|collection)\b|\bleague\s+challenge\b|\bplay!?\s*pokemon\s+(kit|league)\b")),
    ("Ultra / super-premium collection", _R(r"\b(ultra|super)[\s-]*premium\b")),
    ("Premium collection", _R(r"\bpremium\s+(collections?|figure|box|playmat|trainer)\b")),
    ("Pin / poster / binder collection", _R(r"\b(pin|poster|binder|portfolio|album|tech\s+sticker|sticker)\s+collections?\b|\bpin\s+box\b|\bpins?\b.*\bcollection\b|\b(mini\s+)?portfolio\b")),
    ("Figure collection", _R(r"\bfigure\s+collections?\b|\bfigures?\b|\bplush\b|\bstatues?\b")),
    ("Accessory / merchandise", _R(r"\bpuzzle\s+insert\b|\binserts?\b")),
    ("Prerelease / kit", _R(r"\bscene\s+box\b|\bdraft\s+night\b|\billumineer'?s?\s+quest\b|\bbeginner\s+box\b")),
    ("Collection box", _R(r"\bbriefcase\b|\bselection\b|\banniversary\s+box\b|\bspecial\s+box\b|\b(gym|koko|golden|futuristic)\s+box\b|\b(ex|v|vmax|vstar|gx|tag\s+team|mega|radiant)\s+boxe?s?\b|\bcollections?\b|\bpokemon\s+box\b|\bmy\s+first\s+battle\b|\bgift\s+(box|set)\b|\bseason\s+pass\b|\bsecret\s+lair\b|\btrove\b|\bbox\s+set\b|\bbattle\s+academy\b|\bprofessor'?s?\b.*\bbox\b")),
    ("Accessory / merchandise", _R(r"\bdeck\s*boxes?\b|\bsleeves?\b|\bplaymat\b")),
    ("Collection box", _R(r"\bbox\b|\b(special|deluxe|collector'?s?|anniversary)\s+edition\b")),
    ("League / battle / theme deck", _R(r"\b(league\s+battle|battle|theme|commander|challenger|constructed|intro|clash|trainer|demo|trial|arena|preconstructed|world\s+champ(?:ionship)?s?)\s+decks?\b|\bdeck\s+kit\b|\bstarter\s+set\b|\bstarter\s+kit\b|\bgame\s+night\b")),
    ("Starter / structure deck", _R(r"\b(starter|structure|advanced|fusion|special|ultimate|champion|premium)\s+decks?\b|\bdeck\s+set\b|\bdecks?\b(?!\s*box)")),
    ("Prerelease / kit", _R(r"\bpre-?release\b|\bkit\b|\blaunch\s+(party|kit)\b|\bevent\s+pack\b")),
    ("Booster pack", _R(r"\bbooster\b|\bpacks?\b|\bpromo\s+pack\b|\bpop\s+series\b")),
    ("Seasonal / gift / calendar", _R(r"\bcalendar\b|\bholiday\b|\badvent\b|\bgift\b|\bsurprise\b|\bmystery\b|\bset\b")),
    ("Accessory / merchandise", _R(r"\b(sleeves?|deck\s*box|binder|portfolio|playmat|play\s*mat|dice|coin|counter|storage|album|pin|keychain|lanyard|bag|poster|stand|bookmark|toploader)\b")),
    ("Oversize / promo card", _R(r"\bjumbo\b|\boversize[d]?\b|\bpromo\s+card\b|\bpromo\b")),
    ("Loose card / energy", _R(r"\benergy\b|\bholo\b|\bfoil\b|\bcards?\b|\btoken\b|\bart\s+series\b|\bemblem\b")),
]


# A "Display" is a case-like pack of several of the product it names ("Build & Battle Box Display" = a display of Build & Battle boxes), except for boosters, where "Booster Display" /
# "Display Box" is simply what the booster box is called.
_BOOSTER_DISPLAY = re.compile(r"\b(booster|draft booster|play booster|set booster|collector booster|jumpstart|theme booster|starter)\s+(box\s+)?displays?\b|\bdisplay\s+box\b|\bbooster\s+display\b", re.I)
_DISPLAY = re.compile(r"\bdisplays?\b", re.I)
_NOT_A_CASE = re.compile(r"\bcase\s+for\b|\bcard\s+case\b|(?<!commander )(?<!challenger )(?<!battle )deck\s+case\b|\bcarrying\s+case\b|\bcase\s+files?\b|\bdisplay\s+(stand|frame|shelf)\b", re.I)
_PLURAL = re.compile(r"\bset\s+of\s+\d+\b|\b(boxes|tins|bundles|blisters|decks|collections)\b(?!\s+(of|from))", re.I)


CASE_KIND = "Case / display"          # a case, carton or display of several items: its own product type, never filed under what is inside it
_STRUCT_DISPLAY = re.compile(r"\b(structure|starter)\s+(deck\s+)?display\b|\b(structure|starter)\s+decks?\s+display\s+box\b|\bstarter\s+display\b", re.I)
_ONE_OF = re.compile(r"\(\s*\d+\s+of\s+\d+\s*\)")           # "Case File Cards (3 of 18)": one loose card of a set


def is_multi(name):
    """True for a product that holds SEVERAL of an item: a case / carton, or a display of tins, bundles, decks...  (a booster box is the item itself, not a multi-pack)."""
    full = name or ""
    if _NOT_A_CASE.search(full):
        return False
    if _CASE.search(full.lower()):
        return True
    return bool(_DISPLAY.search(full) and not _BOOSTER_DISPLAY.search(full)) or bool(_STRUCT_DISPLAY.search(full)) or bool(re.search(r"\b(set|bundle|pack)\s+of\s+\d+\b|\bcollector\s+3-?pack\b", full, re.I))


# A store's own version or pack.  The warehouse clubs always; the other stores only when the name says it is THEIR exclusive (a card called "Target" is not a product from Target).
_RET_CLUB = re.compile(r"\b(costco|sam'?s\s+club|bj'?s(\s+wholesale)?)\b", re.I)
_RET_STORE = re.compile(r"\b(walmart|target|walgreens|dollar\s+general|dollar\s+tree|family\s+dollar|gamestop|best\s+buy|amazon|barnes\s*(&|and)\s*noble|kroger|meijer|five\s+below|lowe'?s|toys\s*r\s*us|big\s+lots|cvs|rite\s+aid|menards|fred\s+meyer|hy-?vee|publix|safeway|albertsons)\b", re.I)
_RET_TAG = re.compile(r"\bretail\s+exclusive\b|\bexclusive\b|\(\s*[^)]*\)|\[\s*[^\]]*\]", re.I)
_PRODUCT_NOUN = re.compile(r"\b(tins?|bundles?|chests?|decks?|blisters?|balls?|elite\s+trainer\s+box(?:es)?|etb|collection|booster\s+packs?|packs?|calendar|box(?:es)?)\b", re.I)
_JOINERS = re.compile(r"\s\+\s|\s&\s|\sand\s|\splus\s|\swith\s", re.I)
_CASE_WORDS = re.compile(r"\bcases?\b|\bcartons?\b|\bdisplay\b|\bmaster\s+case\b", re.I)
_MINI_TIN = re.compile(r"\bmini\s+tins?\b", re.I)


def retailer_of(name, pk=True):
    """The store a product belongs to ('Costco', "Sam's Club", 'Target'...), or '' (a Pokemon Center item is the brand's own product, not a store's)."""
    full = name or ""
    if re.search(r"\bcheck-?\s*lane\b", full, re.I):
        return ""                                                       # a Checklane blister stays a Checklane blister, whichever store it was made for
    m = _RET_CLUB.search(full)
    if m:
        return re.sub(r"\s+", " ", m.group(1)).title().replace("'S", "'s")
    m = _RET_STORE.search(full)
    if m and re.search(r"\bexclusive\b|\(\s*" + re.escape(m.group(1)) + r"|\[\s*" + re.escape(m.group(1)), full, re.I):
        return re.sub(r"\s+", " ", m.group(1)).title()
    if pk and re.search(r"\bretail\s+exclusive\b", full, re.I):          # (other games' "Retail Exclusive" boxes are just their own retail version)
        return "Retail"
    return ""


def is_combo(name):
    """Two or more different products sold together ('Collector's Chest Tin + Great Ball 2-Pack', 'Battle Deck & 2 Booster Bundle').  A card name with '&' is not a combo."""
    clean = re.sub(r"\[[^\]]*\]", " ", name or "")
    clean = re.sub(r"\([^)]*\)", " ", clean)
    parts = [p for p in _JOINERS.split(clean) if p.strip()]
    nouns = [re.sub(r"s$|es$", "", _PRODUCT_NOUN.search(p).group(1).lower()) for p in parts if _PRODUCT_NOUN.search(p)]
    return len(parts) >= 2 and len(set(nouns)) >= 2


def also_kinds(kind):
    """Other product types a product should ALSO be found under (a Mini tin display is also a Mini tin)."""
    return ["Mini tin"] if kind == MINI_DISPLAY else []


_POKE_BUNDLE = re.compile(r"\bbooster\s+bundle\b", re.I)


def kind_of(name, game=""):
    """-> one of KINDS for a product name.  A display of something is filed under what is in it (a Build & Battle Box Display is a Build & battle, not a booster box); is_multi() says it is a multi-pack."""
    full = (name or "")
    low = _clean(full)
    pk = str(game).startswith("pokemon")
    if _DISPLAY.search(low) and not _BOOSTER_DISPLAY.search(full):
        low = _DISPLAY.sub(" ", low)
    if _RULES[0][1].search(full):
        return "Code card"
    if _ONE_OF.search(full):
        return "Loose card / energy"
    if _MINI_TIN.search(full) and not retailer_of(full, pk) and (is_multi(full) or re.search(r"\b\d+[\s-]*packs?\b|\bset\s+of\b", full, re.I)):
        return MINI_DISPLAY                                        # a display / 5-pack of mini tins: its own type, and also listed under Mini tin
    if is_multi(full) and _CASE_WORDS.search(full):
        return CASE_KIND                                           # a case / carton / display of something (a store's too: it is a case, not the store's single item)
    if retailer_of(full, pk) or (pk and is_combo(full)):
        return RETAIL_KIND
    if is_multi(full):
        return CASE_KIND
    if re.search(r"\boversized?\b", full, re.I):
        return "Oversize / promo card"
    for kind, rx in _RULES[1:]:
        if kind == "2-pack blister" and rx.pattern.startswith(r"\b(2|two)") and not pk:
            continue                                               # "2-Pack" alone means a blister only for Pokemon
        if kind == "Booster bundle" and pk:
            rx = _POKE_BUNDLE                                      # a Pokemon "bundle" that is not a Booster Bundle (Collector Bundle, Back to School Bundle...) is something else
        if rx.search(low):
            return kind
    # nothing about the name says "product": it is a single card that has no card number (Bulbasaur, Potion (Pikachu), 'Avacyn's Collar, the Symbol of Her Church')
    return "Loose card / energy"


# ------------------------------------------------------------------------------------------------ series
_SPECIAL_SERIES = [
    (re.compile(r"^pop series|\bpop series\b", re.I), "POP Series"),
    (re.compile(r"trainer kit", re.I), "Trainer Kits"),
    (re.compile(r"mcdonald", re.I), "McDonald's"),
    (re.compile(r"world championship|worlds? deck", re.I), "World Championship Decks"),
    (re.compile(r"^(jumbo cards|league & championship|deck exclusives|kids wb|wotc promo|alternate art promos|pikachu world|player placement|first partner|black star|promo cards?|promos?)\b|\bpromos?\b", re.I), "Promos & specials"),
]

ERAS = [("2003-06-01", "Original era (1999-2003)"), ("2007-05-01", "EX era (2003-2007)"), ("2011-04-01", "Diamond & Pearl to HeartGold (2007-2011)"),
        ("2014-01-01", "Black & White (2011-2013)"), ("2017-01-01", "XY (2014-2016)"), ("2020-02-01", "Sun & Moon (2017-2019)"),
        ("2023-03-01", "Sword & Shield (2020-2022)"), ("2025-09-01", "Scarlet & Violet (2023-2025)"), ("9999", "Mega Evolution (2025 on)")]
MISC = "Promos, kits & specials"
_PLACEHOLDER_FROM = "2026-10-01"          # groups published without a real date carry the day they were added; they are placed by name instead
_FAMILY_WORDS = [(re.compile(r"\bmega evolution\b|\bme\d{2}\b|\bascended heroes\b|\bphantasmal flames\b|\bperfect order\b|\bchaos rising\b|\bpitch black\b|\b30th celebration\b|\bdelta reign\b", re.I), "Mega Evolution (2025 on)"),
                 (re.compile(r"\bscarlet\s*&?\s*violet\b|\bsv\d{2}\b|\bpaldea\b|\bpaldean\b|\bobsidian\b|\bparadox\b|\btemporal forces\b|\btwilight masquerade\b|\bstellar crown\b|\bsurging sparks\b|\bprismatic\b|\bjourney together\b|\bdestined rivals\b|\bblack bolt\b|\bwhite flare\b|\bshrouded fable\b|\bterastal\b", re.I), "Scarlet & Violet (2023-2025)"),
                 (re.compile(r"\bsword\s*&?\s*shield\b|\bswsh\d*\b|\bcrown zenith\b|\bsilver tempest\b|\blost origin\b|\bastral radiance\b|\bbrilliant stars\b|\bfusion strike\b|\bevolving skies\b|\bchilling reign\b|\bbattle styles\b|\bshining fates\b|\bvivid voltage\b|\bdarkness ablaze\b|\brebel clash\b|\bchampion'?s path\b|\bcelebrations\b|\bpokemon go\b|\bgalar", re.I), "Sword & Shield (2020-2022)"),
                 (re.compile(r"\bsun\s*&?\s*moon\b|\bsm\d*\b|\bhidden fates\b|\bcosmic eclipse\b|\bunified minds\b|\bunbroken bonds\b|\bteam up\b|\blost thunder\b|\bdragon majesty\b|\bceleste\b|\bcrimson invasion\b|\bburning shadows\b|\bguardians rising\b|\bultra prism\b|\bforbidden light\b|\bshining legends\b|\bdetective pikachu\b|\balola\b", re.I), "Sun & Moon (2017-2019)"),
                 (re.compile(r"\bxy\b|\bevolutions\b|\bsteam siege\b|\bfates collide\b|\bbreakpoint\b|\bbreakthrough\b|\bancient origins\b|\broaring skies\b|\bprimal clash\b|\bphantom forces\b|\bfuries fists\b|\bfurious fists\b|\bflashfire\b|\bgenerations\b|\bkalos\b|\bdouble crisis\b", re.I), "XY (2014-2016)"),
                 (re.compile(r"\bblack\s*&?\s*white\b|\bplasma\b|\bboundaries crossed\b|\bdark explorers\b|\bdragons exalted\b|\bnext destinies\b|\bnoble victories\b|\bemerging powers\b|\blegendary treasures\b|\bdragon vault\b", re.I), "Black & White (2011-2013)"),
                 (re.compile(r"\bdiamond\s*&?\s*pearl\b|\bplatinum\b|\bheartgold\b|\bsoulsilver\b|\bhgss\b|\bunleashed\b|\bundaunted\b|\btriumphant\b|\bcall of legends\b|\bsupreme victors\b|\brising rivals\b|\barceus\b|\bstormfront\b|\bmajestic dawn\b|\bgreat encounters\b|\bsecret wonders\b|\bmysterious treasures\b|\blegends awakened\b", re.I), "Diamond & Pearl to HeartGold (2007-2011)"),
                 (re.compile(r"\bex\b.*\b(ruby|sapphire|sandstorm|dragon|hidden legends|firered|leafgreen|team rocket returns|deoxys|emerald|unseen forces|delta species|legend maker|holon|crystal guardians|power keepers)\b|\bex\s+(ruby|sandstorm|deoxys|emerald|unseen)", re.I), "EX era (2003-2007)"),
                 (re.compile(r"\bbase set\b|\bjungle\b|\bfossil\b|\bteam rocket\b|\bgym (heroes|challenge)\b|\bneo (genesis|discovery|revelation|destiny)\b|\blegendary collection\b|\bexpedition\b|\baquapolis\b|\bskyridge\b", re.I), "Original era (1999-2003)")]


def era_of_date(released):
    for cut, label in ERAS:
        if released < cut:
            return label
    return ERAS[-1][1]


# ---- placing a product that sits in a catch-all group ("Miscellaneous Cards & Products") into the right era.  Signals, best first:
#   the set it names  >  a year / season in the name  >  the card type it features (V, VMAX, GX, EX, ex, Mega ex...)  >  the first appearance of the card it features  >
#   its neighbours: TCGplayer numbers products in the order they were created, so a product sits in the era of the products around its number (only used when nothing else says).
_QTR = re.compile(r"\bQ([1-4])\s*(20\d\d)\b", re.I)
_SEASON = re.compile(r"\b(spring|summer|fall|autumn|winter|holiday)\s*(20\d\d)\b", re.I)
_SEASON_MONTH = {"spring": "04", "summer": "07", "fall": "10", "autumn": "10", "winter": "01", "holiday": "11"}
_YEAR = re.compile(r"(?<![\d/#-])(20[0-3]\d)(?![\d/])")
_NOT_MAIN_SET = re.compile(r"miscellaneous|jumbo|prize pack|promo|black star|trainer kit|pop series|mcdonald|world championship|\bpro\b", re.I)
_ERA_LABELS = [lab for _, lab in ERAS]
_BW_WORDS = re.compile(r"\b(black|white|kyurem|reshiram|zekrom|unova|plasma|keldeo|victini|genesect|meloetta)\b", re.I)


_ERA_TOKENS = [
    (re.compile(r"\bBW\b|\bblack\s*&\s*white\b", re.I), ERAS[3][1]),
    (re.compile(r"(?<!\w)XY\b", re.I), ERAS[4][1]),
    (re.compile(r"\bSM\d*\b|\bsun\s*&\s*moon\b", re.I), ERAS[5][1]),
    (re.compile(r"\bSWSH\d*\b|\bsword\s*&\s*shield\b", re.I), ERAS[6][1]),
    (re.compile(r"\bSV\d*\b|\bscarlet\s*&\s*violet\b", re.I), ERAS[7][1]),
    (re.compile(r"\bHGSS\b|\bDP\b|\bdiamond\s*&\s*pearl\b", re.I), ERAS[2][1]),
    (re.compile(r"\bmega\s+evolution\b", re.I), ERAS[8][1]),
]


def date_hint(name):
    """A year / season / quarter written in the name ('Fall 2020', 'Q4 2024', '(2021)', 'Holiday Calendar 2023') -> an approximate date, or ''."""
    full = name or ""
    m = _QTR.search(full)
    if m:
        return f"{m.group(2)}-{(int(m.group(1)) - 1) * 3 + 2:02d}-15"
    m = _SEASON.search(full)
    if m:
        return f"{m.group(2)}-{_SEASON_MONTH[m.group(1).lower()]}-15"
    m = _YEAR.search(full)
    if m and 2000 <= int(m.group(1)) <= 2035:
        return f"{m.group(1)}-07-01"
    return ""


def era_marker(name):
    """The era a card-type marker in the name points to ('VMAX' -> Sword & Shield, 'GX' -> Sun & Moon, 'EX' -> XY, 'Mega ... ex' -> Mega Evolution), or ('', allowed eras) when it is ambiguous."""
    full = name or ""
    lab = lambda d: era_of_date(d)
    if re.search(r"\b(VMAX|VSTAR|V-UNION)\b|\w V\b", full) and not re.search(r"\bGX\b|\bEX\b", full):
        return lab("2021-01-01"), None
    if re.search(r"\bGX\b|TAG TEAM", full):
        return lab("2018-01-01"), None
    if re.search(r"\bBREAK\b", full):
        return lab("2015-01-01"), None
    if re.search(r"\bLV\.?\s?X\b|\bPrime\b", full):
        return lab("2009-01-01"), None
    if re.search(r"\bMega\b.*\bex\b", full):
        return lab("2026-01-01"), None
    if re.search(r"\bEX\b|\bEx\b", full):
        return None, (lab("2012-01-01"), lab("2015-01-01"))
    if re.search(r"\bex\b", full):
        return None, (lab("2024-01-01"), lab("2026-01-01"), lab("2005-01-01"))
    return None, None


def _clean_card_name(n):
    n = re.sub(r"\s*\([^)]*\)", "", n or "")
    n = re.sub(r"\s-\s[\w/]*\d[\w/]*\s*$", "", n)
    return n.strip()


class SeriesContext:
    """What a card list knows about timing, used to place products that sit in a catch-all group: the first era each card name appears in, and which era the products around
    a product number belong to."""

    def __init__(self, conn):
        import bisect
        self._bisect = bisect
        self.first = {}
        pts = {}
        try:
            for name, d, sname in conn.execute("SELECT c.name, s.release_date, s.name FROM cards c JOIN sets s ON s.id=c.set_id WHERE s.release_date<>''"):
                if d >= _PLACEHOLDER_FROM or _NOT_MAIN_SET.search(sname or ""):
                    continue
                k = _clean_card_name(name)
                if k and (k not in self.first or d < self.first[k]):
                    self.first[k] = d
            for pid, d, sname in conn.execute("SELECT id, released, set_name FROM sealed_products WHERE released<>''"):
                if d < _PLACEHOLDER_FROM and not _NOT_MAIN_SET.search(sname or "") and str(pid).isdigit():
                    pts[int(pid)] = d
            for tid, d, sname in conn.execute("SELECT c.tcg_id, s.release_date, s.name FROM cards c JOIN sets s ON s.id=c.set_id WHERE c.tcg_id IS NOT NULL AND s.release_date<>''"):
                if d < _PLACEHOLDER_FROM and not _NOT_MAIN_SET.search(sname or "") and str(tid).isdigit():
                    pts.setdefault(int(tid), d)
        except Exception:  # noqa: BLE001 - a card list without these tables: fewer signals, never an error
            pass
        self.pts = sorted(pts.items())
        self.ids = [p for p, _ in self.pts]

    def era_by_number(self, pid, k=9):
        if not self.ids or not str(pid).isdigit():
            return None
        i = self._bisect.bisect_left(self.ids, int(pid))
        near = sorted(d for _, d in self.pts[max(0, i - k): i + k])
        return era_of_date(near[len(near) // 2]) if near else None

    def era_of_card(self, name):
        d = self.first.get(name)
        return era_of_date(d) if d else None


_TAIL = re.compile(r"\b(premium|ultra[\s-]*premium|super[\s-]*premium|special|collector'?s?|battle|league|deluxe|build|tin|box|collection|deck|bundle|blister|figure|illustration|case|display|set|poke\s*ball|pin)\b.*$", re.I)


def featured_names(product_name):
    """Card names a product features: the bracket contents ('[Dialga ex]'), and the words before the product type ('Charizard ex Premium Collection')."""
    full = product_name or ""
    out = []
    for br in re.findall(r"[\[(]([^\])]*)[\])]", full):
        out += re.split(r"\s*(?:,|/|&|\band\b)\s*", br)
    head = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", full)
    head = re.sub(r"^.*?:\s*", "", head)
    head = _TAIL.sub("", head).strip(" -:")
    out += re.split(r"\s*(?:&|/|\band\b|\+)\s*", head)
    return [c.strip() for c in out if len(c.strip()) >= 3]


def _named_set_era(name, set_names):
    """The era of the longest real set name (6+ letters) written in the title, or None."""
    if not set_names:
        return None
    low = (name or "").lower()
    best = max((n for n in set_names if len(n) >= 6 and re.search(r"(?<![a-z0-9])" + re.escape(n.lower()) + r"(?![a-z0-9])", low)), key=len, default=None)       # whole words only ("Dragon" is not in "Dragonite")
    return era_of_date(set_names[best]) if best else None


def infer_era(product_name, product_id="", ctx=None, set_names=None):
    """Best guess at the era of a product from everything its name and number say; '' when nothing does.  Order: an era written in the name, a year / season, a definite card-type
    mark (VMAX, GX, Mega ... ex), a set named in the title, the broad family words, the first appearance of the card it features, then the products numbered around it."""
    name = product_name or ""
    for rx, label in _ERA_TOKENS:                                       # an era written in the name ("BW Sneak-Peek Tin", "XY Trainer Kit")
        if rx.search(name):
            return label
    hint = date_hint(name)
    if hint:
        return era_of_date(hint)
    era, allowed = era_marker(name)
    if era:
        return era
    near = ctx.era_by_number(product_id) if ctx is not None else None
    named = _named_set_era(name, set_names)
    if allowed:                                                          # EX / ex: several eras use the mark - a named set or the neighbours choose between those that fit
        if named in allowed:
            return named
        return near if near in allowed else allowed[0]
    if named:
        return named
    for rx, label in _FAMILY_WORDS:                                     # the broad words (set and region names)
        if rx.search(name):
            return label
    first = None
    if ctx is not None:
        firsts = [e for e in (ctx.era_of_card(c) for c in featured_names(name)) if e]
        if firsts:
            first = max(firsts, key=_ERA_LABELS.index)                  # the product cannot be older than the newest card it features
    if first and near is not None and _ERA_LABELS.index(first) < _ERA_LABELS.index(near) and _BW_WORDS.search(name):
        return first                                                    # an old Pokemon's box listed late: its own era, not its neighbours'
    return near or first or ""


def serie_of(game, set_name, released, product_name="", set_names=None, ctx=None, product_id=""):
    """The series a sealed product belongs to.  Pokemon: an era (or POP Series / Trainer Kits / Promos...); the other games: their set's family."""
    nm = set_name or ""
    if game in ("pokemon", "pokemon_jp", "pokemon_tw"):
        for rx, label in _SPECIAL_SERIES:
            if rx.search(nm):
                return label
        if released and released < _PLACEHOLDER_FROM and not re.search(r"miscellaneous", nm, re.I):
            return era_of_date(released)
        text = f"{nm} {product_name}"
        if ctx is not None:
            return infer_era(product_name, product_id, ctx, set_names) or MISC
        for rx, label in _FAMILY_WORDS:                       # (no card list to learn from: the broad words decide, as before)
            if rx.search(text):
                return label
        if set_names:
            low = text.lower()
            best = max((n for n in set_names if len(n) >= 6 and n.lower() in low), key=len, default=None)
            if best:
                return era_of_date(set_names[best])
        return MISC
    from .tcgcsv import serie_for                       # the other games: the same family names the set boxes use (Booster Packs, Starter Decks, 2024 releases...)
    return serie_for(game, {"name": nm, "publishedOn": released or "", "abbreviation": ""}) or "Other products"



def classify_rows(conn, game):
    """Work out kind / series / multi / also for every sealed product of an open card list and store them (and the rule version).  -> number of products."""
    from . import sealedcontents
    from .db import _ensure_column
    _ensure_column(conn, "sealed_products", "contents", "TEXT")
    rows = conn.execute("SELECT id, name, set_id, set_name, released FROM sealed_products").fetchall()
    pk = str(game).startswith("pokemon")
    ctx = SeriesContext(conn) if pk else None
    set_names = {}
    if pk:
        set_names = {r[0]: (r[1] or "") for r in conn.execute("SELECT name, release_date FROM sets") if r[0] and len(r[0]) >= 6}
    ups = []
    for r in rows:
        pid, name, _sid, sname, rel = r[0], r[1], r[2], r[3], r[4]
        kind = kind_of(name, game)
        serie = serie_of(game, sname, rel or "", name, set_names if game == "pokemon" else None, ctx, pid)
        code = 1 if sealedcontents.is_code_card(name) else 0
        ups.append((kind, serie, 1 if is_multi(name) else 0, ",".join(also_kinds(kind)), code, sealedcontents.pack(sealedcontents.from_name(name)), pid))
    conn.executemany("UPDATE sealed_products SET kind=?, serie=?, multi=?, also=?, contents=CASE WHEN ?=1 THEN NULL ELSE COALESCE(NULLIF(contents,''), ?) END WHERE id=?", ups)  # a count in the name fills a blank; a description's list (tcgcsv) is kept; a code card has none
    conn.execute("INSERT OR REPLACE INTO meta VALUES('sealed_class_v', ?)", (str(VERSION),))
    conn.commit()
    return len(ups)
