"""What kind of product a sealed product is (booster box, sleeved pack, tin, three-pack blister, collector chest, case...) and which series it belongs to.

Worked out from TCGplayer's product names with ordered rules (first match wins), the same way for every game, plus a few words per game.  The result is stored in the card
list (sealed_products.kind / .serie) when the lists are built, so every app shows the same thing."""
import re

# (kind, pattern) in order: the first one that matches wins.  Patterns are matched against the lower-cased name WITHOUT its [bracket] tags and (parentheses)
# unless noted; `ALL` rules look at the whole name.
KINDS = [
    "Code card", "Case / display", "Booster box", "Half booster box", "Enhanced booster box", "Elite trainer box", "Collector chest", "Booster bundle", "Sleeved booster pack", "Checklane blister", "Hanger box", "3-pack blister",
    "2-pack blister", "Single-pack blister", "Blister (other)", "Mini tin", "Tin", "Build & battle", "Tournament collection box", "Ultra-premium collection", "Premium collection",
    "Collection box", "Secret Lair drop", "Pin / poster / binder collection", "Figure collection", "League / battle / theme deck", "Starter / structure deck", "Booster pack", "Mini / fun pack", "Prize pack", "Trainer kit", "Prerelease / kit",
    "Gift / calendar / set", "Accessory / merchandise", "Oversize / promo card", "Loose card / energy", "Other product",
]

_CASE = re.compile(r"\bcase\b|\(case\)|\[case\]|\bcarton\b|\bmaster case\b", re.I)


def _clean(name):
    return re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", name or "").lower()


# the order below is the order of the rules (first match wins).  Names have their [bracket tags] and (parentheses) removed before matching, except where noted.
_R = lambda p: re.compile(p, re.I)
_RULES = [
    ("Code card", _R(r"\bcode[\s-]*cards?\b|\bonline\s+code\b|\bdigital\s+code\b")),
    ("Loose card / energy", _R(r"\s-\s20\d\d\s*$|\bbox\s+topper\b|\btopper\b")),
    ("Mini tin", _R(r"\bmini\s+tins?\b|\bpoke\s*ball\s+tins?\b|\bpokeball\s+tins?\b")),
    ("Secret Lair drop", _R(r"\bsecret\s+lair\b")),
    ("Prize pack", _R(r"\bprize\s+pack\b")),
    ("Mini / fun pack", _R(r"\bfun\s+pack\b|\bmini\s+(booster\s+)?pack\b|\bmatch\s*&\s*battle\s+pack\b|\b\d+[\s-]*card\s+(booster\s+)?pack\b")),
    ("Booster pack", _R(r"\bseries\s+\d+\s+booster\s+pack\b")),
    ("Half booster box", _R(r"\bhalf\s+booster\s+box(es)?\b")),
    ("Enhanced booster box", _R(r"\benhanced\s+booster\s+(display\s+)?box\b")),
    ("Hanger box", _R(r"\bhanger\b")),
    ("Trainer kit", _R(r"\btrainer\s+kit\b|\btrainer'?s?\s+toolkit\b")),
    ("Starter / structure deck", _R(r"\bbattle\s+academy\b|\bmy\s+first\s+battle\b")),
    ("Collection box", _R(r"\bcase\s+files?\b")),
    ("League / battle / theme deck", _R(r"\bbattle\s+decks?\s+bundle\b")),
    ("Booster box", _R(r"\b(booster|draft booster|play booster|set booster|collector booster|jumpstart|theme booster|starter)\s+(boxes|box|displays?)\b|\bbooster\s+display\b|\bdisplay\s+box\b|\bhalf\s+booster\b|\b(36|24|18)\s*packs?\b|\bhobby\s+box\b|\bblaster\s+box\b|\bbooster\s+brick\b|\bbooster\s+boxes\b|\b(mini|tuck|draft|jumbo)\s+box\b|\bbox\s+of\s+\d+\s+packs?\b")),
    ("Elite trainer box", _R(r"\belite\s+trainer\b|\betb\b|\btrainer'?s?\s+toolkit\b")),
    ("Collector chest", _R(r"\bcollector'?s?\s+chests?\b|\bchest\b")),
    ("Booster bundle", _R(r"\bbooster\s+bundle\b|\bbundles?\b|\bfat\s+pack\b|\bart\s+bundle\b")),
    ("Sleeved booster pack", _R(r"\bsleeved\s+(booster|pack)")),
    ("Checklane blister", _R(r"\bcheck-?\s*lane\b")),
    ("3-pack blister", _R(r"\b3[\s-]*packs?\s+(booster\s+)?blisters?\b|\bthree[\s-]*packs?\s+blisters?\b|\btriple\s+pack\b")),
    ("2-pack blister", _R(r"\b2[\s-]*packs?\s+blisters?\b|\btwo[\s-]*packs?\s+blisters?\b")),
    ("Single-pack blister", _R(r"\bsingle\s+pack\s+blisters?\b|\b1[\s-]*pack\s+blisters?\b|\bsingle\s+blisters?\b")),
    ("Blister (other)", _R(r"\bblisters?\b")),
    ("Tin", _R(r"\btins?\b|\blunch\s*box\b")),
    ("Build & battle", _R(r"\bbuild\s*(&|and)\s*battle\b")),
    ("Booster pack", _R(r"\btournament\s+pack\b(?!\s+(box|collection))")),
    ("Tournament collection box", _R(r"\btournament\b|\bchampionship\s+(box|collection)\b|\bleague\s+challenge\b|\bplay!?\s*pokemon\s+(kit|league)\b")),
    ("Ultra-premium collection", _R(r"\bultra[\s-]*premium\b")),
    ("Premium collection", _R(r"\bpremium\s+(collections?|figure|box|playmat|trainer)\b|\bspecial\s+collections?\b|\bcollector'?s?\s+box\b")),
    ("Pin / poster / binder collection", _R(r"\b(pin|poster|binder|portfolio|album|tech\s+sticker|sticker)\s+collections?\b|\bpin\s+box\b|\bpins?\b.*\bcollection\b")),
    ("Figure collection", _R(r"\bfigure\s+collections?\b|\bfigures?\b|\bplush\b|\bstatues?\b")),
    ("Accessory / merchandise", _R(r"\bpuzzle\s+insert\b|\binserts?\b")),
    ("Prerelease / kit", _R(r"\bscene\s+box\b|\bdraft\s+night\b|\billumineer'?s?\s+quest\b|\bbeginner\s+box\b")),
    ("Collection box", _R(r"\bbriefcase\b|\bselection\b|\banniversary\s+box\b|\bspecial\s+box\b|\b(gym|koko|golden|futuristic)\s+box\b|\b(ex|v|vmax|vstar|gx|tag\s+team|mega|radiant)\s+boxe?s?\b|\bcollections?\b|\bpokemon\s+box\b|\bmy\s+first\s+battle\b|\bgift\s+(box|set)\b|\bseason\s+pass\b|\bsecret\s+lair\b|\btrove\b|\bbox\s+set\b|\bbattle\s+academy\b|\bprofessor'?s?\b.*\bbox\b")),
    ("Accessory / merchandise", _R(r"\bdeck\s*boxes?\b|\bsleeves?\b|\bplaymat\b")),
    ("Collection box", _R(r"\bbox\b|\b(special|deluxe|collector'?s?|anniversary)\s+edition\b")),
    ("League / battle / theme deck", _R(r"\b(league\s+battle|battle|theme|commander|challenger|constructed|intro|clash|trainer|demo|trial|arena|preconstructed|world\s+champ(?:ionship)?s?)\s+decks?\b|\bdeck\s+kit\b|\bstarter\s+set\b|\bstarter\s+kit\b|\bgame\s+night\b")),
    ("Starter / structure deck", _R(r"\b(starter|structure|advanced|fusion|special|ultimate|champion|premium)\s+decks?\b|\bdeck\s+set\b|\bdecks?\b(?!\s*box)")),
    ("Prerelease / kit", _R(r"\bpre-?release\b|\bkit\b|\blaunch\s+(party|kit)\b|\bevent\s+pack\b")),
    ("Booster pack", _R(r"\bbooster\b|\bpacks?\b|\bpromo\s+pack\b|\bpop\s+series\b")),
    ("Gift / calendar / set", _R(r"\bcalendar\b|\bholiday\b|\badvent\b|\bgift\b|\bsurprise\b|\bmystery\b|\bset\b")),
    ("Accessory / merchandise", _R(r"\b(sleeves?|deck\s*box|binder|portfolio|playmat|play\s*mat|dice|coin|counter|storage|album|pin|keychain|lanyard|bag|poster|stand|bookmark|toploader)\b")),
    ("Oversize / promo card", _R(r"\bjumbo\b|\boversize[d]?\b|\bpromo\s+card\b|\bpromo\b")),
    ("Loose card / energy", _R(r"\benergy\b|\bholo\b|\bfoil\b|\bcards?\b|\btoken\b|\bart\s+series\b|\bemblem\b")),
]


# A "Display" is a case-like pack of several of the product it names ("Build & Battle Box Display" = a display of Build & Battle boxes), except for boosters, where "Booster Display" /
# "Display Box" is simply what the booster box is called.
_BOOSTER_DISPLAY = re.compile(r"\b(booster|draft booster|play booster|set booster|collector booster|jumpstart|theme booster|starter)\s+(box\s+)?displays?\b|\bdisplay\s+box\b|\bbooster\s+display\b", re.I)
_DISPLAY = re.compile(r"\bdisplays?\b", re.I)
_NOT_A_CASE = re.compile(r"\bcase\s+for\b|\bcard\s+case\b|(?<!commander )(?<!challenger )(?<!battle )deck\s+case\b|\bcarrying\s+case\b|\bcase\s+files?\b|\bdisplay\s+(stand|frame|shelf)\b", re.I)
_PLURAL = re.compile(r"\bset\s+of\s+\d+\b|\b(boxes|tins|bundles|blisters|decks|collections)\b(?!\s+(of|from))", re.I)


CASE_KIND = "Case / display"          # a case, carton or display of several items: its own product type, never filed under what is inside it
_STRUCT_DISPLAY = re.compile(r"\b(structure|starter)\s+(deck\s+)?display\b|\b(structure|starter)\s+decks?\s+display\s+box\b|\bstarter\s+display\b", re.I)
_ONE_OF = re.compile(r"\(\s*\d+\s+of\s+\d+\s*\)")           # "Case File Cards (3 of 18)": one loose card of a set


def is_multi(name):
    """True for a product that holds SEVERAL of an item: a case / carton, or a display of tins, bundles, decks...  (a booster box is the item itself, not a multi-pack)."""
    full = name or ""
    if _NOT_A_CASE.search(full):
        return False
    if _CASE.search(full.lower()):
        return True
    return bool(_DISPLAY.search(full) and not _BOOSTER_DISPLAY.search(full)) or bool(_STRUCT_DISPLAY.search(full)) or bool(re.search(r"\b(set|bundle|pack)\s+of\s+\d+\b|\bcollector\s+3-?pack\b", full, re.I))


def kind_of(name, game=""):
    """-> one of KINDS for a product name.  A display of something is filed under what is in it (a Build & Battle Box Display is a Build & battle, not a booster box); is_multi() says it is a multi-pack."""
    full = (name or "")
    low = _clean(full)
    if _DISPLAY.search(low) and not _BOOSTER_DISPLAY.search(full):
        low = _DISPLAY.sub(" ", low)
    if _RULES[0][1].search(full):
        return "Code card"
    if _ONE_OF.search(full):
        return "Loose card / energy"
    if is_multi(full):
        return CASE_KIND
    if re.search(r"\bmini\s+tins?\b", full, re.I) and "tin" not in low:
        return "Mini tin"                                          # e.g. "Sam's Club 151 (4 Mini Tins + Promo Cards Bundle)"
    if re.search(r"\boversized?\b", full, re.I):
        return "Oversize / promo card"
    for kind, rx in _RULES[1:]:
        if rx.search(low):
            return kind
    # nothing about the name says "product": it is a single card that has no card number (Bulbasaur, Potion (Pikachu), 'Avacyn's Collar, the Symbol of Her Church')
    return "Loose card / energy"


# ------------------------------------------------------------------------------------------------ series
_SPECIAL_SERIES = [
    (re.compile(r"^pop series|\bpop series\b", re.I), "POP Series"),
    (re.compile(r"trainer kit", re.I), "Trainer Kits"),
    (re.compile(r"mcdonald", re.I), "McDonald's"),
    (re.compile(r"world championship|worlds? deck", re.I), "World Championship Decks"),
    (re.compile(r"^(jumbo cards|league & championship|deck exclusives|kids wb|wotc promo|alternate art promos|pikachu world|player placement|first partner|black star|promo cards?|promos?)\b|\bpromos?\b", re.I), "Promos & specials"),
]

ERAS = [("2003-06-01", "Original era (1999-2003)"), ("2007-05-01", "EX era (2003-2007)"), ("2011-04-01", "Diamond & Pearl to HeartGold (2007-2011)"),
        ("2014-01-01", "Black & White (2011-2013)"), ("2017-01-01", "XY (2014-2016)"), ("2020-02-01", "Sun & Moon (2017-2019)"),
        ("2023-03-01", "Sword & Shield (2020-2022)"), ("2025-09-01", "Scarlet & Violet (2023-2025)"), ("9999", "Mega Evolution (2025 on)")]
MISC = "Promos, kits & specials"
_PLACEHOLDER_FROM = "2026-10-01"          # groups published without a real date carry the day they were added; they are placed by name instead
_FAMILY_WORDS = [(re.compile(r"\bmega evolution\b|\bme\d{2}\b|\bascended heroes\b|\bphantasmal flames\b|\bperfect order\b|\bchaos rising\b|\bpitch black\b|\b30th celebration\b|\bdelta reign\b", re.I), "Mega Evolution (2025 on)"),
                 (re.compile(r"\bscarlet\s*&?\s*violet\b|\bsv\d{2}\b|\bpaldea\b|\bpaldean\b|\bobsidian\b|\bparadox\b|\btemporal forces\b|\btwilight masquerade\b|\bstellar crown\b|\bsurging sparks\b|\bprismatic\b|\bjourney together\b|\bdestined rivals\b|\bblack bolt\b|\bwhite flare\b|\bshrouded fable\b|\bterastal\b", re.I), "Scarlet & Violet (2023-2025)"),
                 (re.compile(r"\bsword\s*&?\s*shield\b|\bswsh\d*\b|\bcrown zenith\b|\bsilver tempest\b|\blost origin\b|\bastral radiance\b|\bbrilliant stars\b|\bfusion strike\b|\bevolving skies\b|\bchilling reign\b|\bbattle styles\b|\bshining fates\b|\bvivid voltage\b|\bdarkness ablaze\b|\brebel clash\b|\bchampion'?s path\b|\bcelebrations\b|\bpokemon go\b|\bgalar", re.I), "Sword & Shield (2020-2022)"),
                 (re.compile(r"\bsun\s*&?\s*moon\b|\bsm\d*\b|\bhidden fates\b|\bcosmic eclipse\b|\bunified minds\b|\bunbroken bonds\b|\bteam up\b|\blost thunder\b|\bdragon majesty\b|\bceleste\b|\bcrimson invasion\b|\bburning shadows\b|\bguardians rising\b|\bultra prism\b|\bforbidden light\b|\bshining legends\b|\bdetective pikachu\b|\balola\b", re.I), "Sun & Moon (2017-2019)"),
                 (re.compile(r"\bxy\b|\bevolutions\b|\bsteam siege\b|\bfates collide\b|\bbreakpoint\b|\bbreakthrough\b|\bancient origins\b|\broaring skies\b|\bprimal clash\b|\bphantom forces\b|\bfuries fists\b|\bfurious fists\b|\bflashfire\b|\bgenerations\b|\bkalos\b|\bdouble crisis\b", re.I), "XY (2014-2016)"),
                 (re.compile(r"\bblack\s*&?\s*white\b|\bplasma\b|\bboundaries crossed\b|\bdark explorers\b|\bdragons exalted\b|\bnext destinies\b|\bnoble victories\b|\bemerging powers\b|\blegendary treasures\b|\bdragon vault\b", re.I), "Black & White (2011-2013)"),
                 (re.compile(r"\bdiamond\s*&?\s*pearl\b|\bplatinum\b|\bheartgold\b|\bsoulsilver\b|\bhgss\b|\bunleashed\b|\bundaunted\b|\btriumphant\b|\bcall of legends\b|\bsupreme victors\b|\brising rivals\b|\barceus\b|\bstormfront\b|\bmajestic dawn\b|\bgreat encounters\b|\bsecret wonders\b|\bmysterious treasures\b|\blegends awakened\b", re.I), "Diamond & Pearl to HeartGold (2007-2011)"),
                 (re.compile(r"\bex\b.*\b(ruby|sapphire|sandstorm|dragon|hidden legends|firered|leafgreen|team rocket returns|deoxys|emerald|unseen forces|delta species|legend maker|holon|crystal guardians|power keepers)\b|\bex\s+(ruby|sandstorm|deoxys|emerald|unseen)", re.I), "EX era (2003-2007)"),
                 (re.compile(r"\bbase set\b|\bjungle\b|\bfossil\b|\bteam rocket\b|\bgym (heroes|challenge)\b|\bneo (genesis|discovery|revelation|destiny)\b|\blegendary collection\b|\bexpedition\b|\baquapolis\b|\bskyridge\b", re.I), "Original era (1999-2003)")]


def era_of_date(released):
    for cut, label in ERAS:
        if released < cut:
            return label
    return ERAS[-1][1]


def serie_of(game, set_name, released, product_name="", set_names=None):
    """The series a sealed product belongs to.  Pokemon: an era (or POP Series / Trainer Kits / Promos...); the other games: their set's family."""
    nm = set_name or ""
    if game in ("pokemon", "pokemon_jp"):
        for rx, label in _SPECIAL_SERIES:
            if rx.search(nm):
                return label
        if released and released < _PLACEHOLDER_FROM and not re.search(r"miscellaneous", nm, re.I):
            return era_of_date(released)
        text = f"{nm} {product_name}"
        for rx, label in _FAMILY_WORDS:                       # a product in a catch-all group: placed by the set it names
            if rx.search(text):
                return label
        if set_names:
            low = text.lower()
            best = max((n for n in set_names if len(n) >= 6 and n.lower() in low), key=len, default=None)
            if best:
                return era_of_date(set_names[best])
        return MISC
    from .tcgcsv import serie_for                       # the other games: the same family names the set boxes use (Booster Packs, Starter Decks, 2024 releases...)
    return serie_for(game, {"name": nm, "publishedOn": released or "", "abbreviation": ""}) or "Other products"
