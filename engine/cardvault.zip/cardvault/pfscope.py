"""One chosen set of portfolios as an SQL filter, for the reports that read every game's copies straight from u.lots / u.sealed (not the side bar's lots_s view).
ids = portfolio database ids ('' = the main portfolio), or None = everything."""


def where(ids, col="portfolio"):
    """-> (" AND COALESCE(<col>,'') IN (?,..)", ids), or ("", ()) for everything."""
    if ids is None:
        return "", ()
    ids = list(ids)
    return f" AND COALESCE({col},'') IN ({','.join('?' * len(ids)) or 'NULL'})", tuple(ids)
