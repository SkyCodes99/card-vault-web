"""Slab fields of a graded copy: cert (slab) number, grading company and status (roadmap "Slab number and status fields").

The cert number, company and grade were already on every copy (u.lots cert, grade_company, grade).  This adds the STATUS of the slab, in u.lots.slab_status:
    ""           nothing said
    submitted    sent to the grader, not back yet
    graded       back with its grade
    returned     back without a grade (or sent back)
The column is added by the idempotent migration in db.py (a copy of old data has an empty status, nothing else changes).  It is a normal copy field: edited with lot.update (one
undo), copied when a stack is split, synced in the snapshot, written by the CSV / spreadsheet exports and read back by the import.  A copy that stops being graded loses it.

For other code:
    clean(text)          -> one of STATUSES or "" (anything else)
    find(v, text)        -> [{game, card_id, cert, company, grade, status, qty}] copies of mine whose cert number matches what was typed (cert_like(text) says if it looks like one)
"""
import re

STATUSES = ("submitted", "graded", "returned")
LABELS = {"": "No status", "submitted": "Submitted", "graded": "Graded", "returned": "Returned"}
COLUMN = "slab_status"
MIN_CERT = 5                                     # characters: shorter than this is a word or a card number, not a cert


def clean(text):
    t = str(text or "").strip().lower()
    return t if t in STATUSES else ""


def cert_like(text):
    """True when what was typed could be a cert number: one word of letters / digits (dashes allowed), at least MIN_CERT characters, with a digit in it."""
    t = str(text or "").strip()
    return len(t) >= MIN_CERT and re.fullmatch(r"[A-Za-z0-9-]+", t) is not None and any(ch.isdigit() for ch in t)


def find(v, text, game=""):
    """My copies (every game, or one) whose cert number contains what was typed - exact numbers first.  [] when it does not look like a cert number."""
    if not cert_like(text):
        return []
    t = text.strip().lower()
    q = ("SELECT game, card_id, cert, grade_company, grade, slab_status, SUM(qty) FROM u.lots WHERE user_id=? AND deleted=0 AND qty>0 AND graded=1 AND lower(cert) LIKE ?"
         + (" AND game=?" if game else "") + " GROUP BY game, card_id, cert ORDER BY (lower(cert)=?) DESC, cert LIMIT 30")
    args = (v.user_id, f"%{t}%", *((game,) if game else ()), t)
    return [{"game": r[0], "card_id": r[1], "cert": r[2] or "", "company": r[3] or "", "grade": r[4] or "", "status": r[5] or "", "qty": int(r[6] or 0)} for r in v.conn.execute(q, args)]
