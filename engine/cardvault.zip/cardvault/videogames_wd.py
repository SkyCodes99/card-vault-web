"""Wikidata, for the Video games (physical) list: the SPARQL queries tools/harvest_videogames.py asks and the code that turns their answer rows into game records.  No network here (the tool sends the queries),
so the whole step from answer rows to data file is testable.

A game record (what cardvault/videogames_data.json holds, one per Wikidata item that is a video game with an English Wikipedia article):
  q name wp (article title) sl (sitelinks: how widely it is known) series [qid] dev pub genre fmt [names] (the game's own distribution list: read, not kept) plat [qid of every platform the game is on] rel [{p platform qid or '', d 'YYYY[-MM[-DD]]', r place}] img [file]
Every value is one Wikidata states; a statement it does not make is left out, never guessed."""
import re
from urllib.parse import unquote

ENTITY = "http://www.wikidata.org/entity/"
SERVICE = 'SERVICE wikibase:label { bd:serviceParam wikibase:language "en,mul". }'
KINDS = (("P123", "pub"), ("P178", "dev"), ("P179", "series"), ("P136", "genre"), ("P437", "fmt"), ("P400", "plat"), ("P18", "img"))
CHUNK = 60


def qid(uri):
    return uri.rsplit("/", 1)[-1] if uri else ""


def values(qids):
    return " ".join("wd:" + q for q in qids)


def q_top(platform, limit):
    """The best-known games of one platform: those with an English Wikipedia article, most-linked first."""
    return ("SELECT ?g ?gLabel ?sl ?art WHERE { ?g wdt:P31 wd:Q7889; wdt:P400 wd:%s; wikibase:sitelinks ?sl . ?art schema:about ?g; schema:isPartOf <https://en.wikipedia.org/> . %s } "
            "ORDER BY DESC(?sl) LIMIT %d" % (platform, SERVICE, limit))


def q_series(series, platforms, min_links):
    """Games of the given series that are on one of our platforms and have an English article."""
    return ("SELECT ?g ?gLabel ?sl ?art WHERE { VALUES ?s { %s } VALUES ?p { %s } ?g wdt:P179 ?s; wdt:P31 wd:Q7889; wdt:P400 ?p; wikibase:sitelinks ?sl . FILTER(?sl >= %d) "
            "?art schema:about ?g; schema:isPartOf <https://en.wikipedia.org/> . %s } LIMIT 1500" % (values(series), values(platforms), min_links, SERVICE))


def q_facts(games):
    parts = " UNION ".join("{ ?g wdt:%s ?v BIND(\"%s\" AS ?k) }" % (prop, key) for prop, key in KINDS)
    return "SELECT ?g ?k ?v ?vLabel WHERE { VALUES ?g { %s } %s %s }" % (values(games), parts, SERVICE)


def q_releases(games):
    return ("SELECT ?g ?plat ?d ?prec ?place ?placeLabel WHERE { VALUES ?g { %s } ?g p:P577 ?s . ?s psv:P577 ?n . ?n wikibase:timeValue ?d; wikibase:timePrecision ?prec . "
            "OPTIONAL { ?s pq:P400 ?plat } OPTIONAL { ?s pq:P291 ?place } %s }" % (values(games), SERVICE))


def chunks(items, n=CHUNK):
    items = list(items)
    return [items[i:i + n] for i in range(0, len(items), n)]


def _v(b, k):
    return (b.get(k) or {}).get("value", "")


def title_of(label, article):
    """The name shown: the English label, or - when Wikidata has none and the label service answers the bare id - the Wikipedia article's title without its '(video game)' tag."""
    if label and not re.fullmatch(r"Q\d+", label):
        return label
    t = unquote(article.rsplit("/wiki/", 1)[-1]).replace("_", " ")
    return re.sub(r"\s*\((?:[^()]*\s)?(?:video game|game)\)$", "", t)


def date_of(value, precision):
    """'1985-09-13T00:00:00Z' + precision 11 -> '1985-09-13'; precision 10 -> '1985-09'; 9 (or less) -> '1985'.  Bare years before 1970 are kept (the statement says so)."""
    m = re.match(r"(-?\d{4})-(\d\d)-(\d\d)", value or "")
    if not m or m.group(1).startswith("-"):
        return ""
    p = int(precision or 9)
    return m.group(1) if p <= 9 else "%s-%s" % (m.group(1), m.group(2)) if p == 10 else "-".join(m.groups())


def games_from_top(rows):
    """{qid: {q, name, wp, sl}} from q_top / q_series answer rows (a game twice keeps one record)."""
    out = {}
    for b in rows:
        q = qid(_v(b, "g"))
        if q and q not in out:
            out[q] = {"q": q, "name": title_of(_v(b, "gLabel"), _v(b, "art")), "wp": unquote(_v(b, "art").rsplit("/wiki/", 1)[-1]), "sl": int(_v(b, "sl") or 0)}
    return out


def add_facts(games, rows, series_names):
    """Fold q_facts rows into the game records (lists stay in the order read, without repeats); series_names gets {series qid: name}."""
    for b in rows:
        g = games.get(qid(_v(b, "g")))
        key = _v(b, "k")
        if not g or not key:
            continue
        v = _v(b, "v")
        if key == "img":
            val = unquote(v.rsplit("/", 1)[-1]).replace("_", " ")
        elif key in ("plat", "series"):
            val = qid(v)
            if key == "series" and val:
                series_names[val] = _v(b, "vLabel") if not re.fullmatch(r"Q\d+", _v(b, "vLabel")) else ""
        else:
            val = _v(b, "vLabel")
            if not val or re.fullmatch(r"Q\d+", val):
                continue
        if val and val not in g.setdefault(key, []):
            g[key].append(val)


def add_releases(games, rows):
    for b in rows:
        g = games.get(qid(_v(b, "g")))
        d = date_of(_v(b, "d"), _v(b, "prec"))
        if not g or not d:
            continue
        place = _v(b, "placeLabel")
        rec = {"p": qid(_v(b, "plat")), "d": d, "r": "" if re.fullmatch(r"Q\d+", place) else place}
        if rec not in g.setdefault("rel", []):
            g["rel"].append(rec)
