"""Portfolio options that fit the game you are looking at (roadmap "Portfolio options that fit each game", 2026-11-10).

The value views (Overview "Where your value is", Tables, the portfolio analytics, the value graph) all split the collection's value some way.  This is the ONE place that decides which splits a
game offers and works them out, so no screen lists a choice the game does not use:

  Pokémon        set, series, rarity, finish (Normal / Reverse Holo / Holo / 1st Edition), graded or raw, condition, sealed product type
  Magic          set, series, rarity, finish (Non-foil / Foil / Etched), colour, graded or raw, condition, sealed product type
  Yu-Gi-Oh!      set, series, rarity, edition (1st Edition / Unlimited / Limited), graded or raw, condition, sealed product type   (a Yu-Gi-Oh! finish IS its rarity)
  Lorcana        set, series, rarity, finish (Regular / Foil / Cold Foil), ink, graded or raw, condition, sealed product type
  other cards    set, series, rarity, finish (Regular / Foil), colour where the game has one, graded or raw, condition, sealed product type
  toys           set (Fandom / Collection / ...), product type, release (open / limited edition) - NO rarity, condition or graded
  every game     checklist, single card

A split is offered only when it has something to show: it is empty, or says "Unknown" for everything, or (for a property of the copies - finish, edition, colour, graded, condition) has only one
kind of copy, and it disappears.  It reads the same sources as the rest of the app: the price the person picked (pricepick), the sealed price book (sealedprice), the game's own filter rules
(gamefacets: rarities pruned the way the sidebar prunes them, the colour facet), sealed product kinds (sealedclass).  tests/test_portfoliooptions.py has the cases.
The phone / website build has the same rules in ui/src/phone/portfolio.js.
(A twin of this idea exists in listoptions.py - the checklist options of the same roadmap step; merge the two vocabularies when both are committed.)"""
import re

from . import gamefacets, pricepick, sealedclass
from .db import VARIANT_LABELS
from .games import game_by_id, is_misc

UNKNOWN = "Unknown"
ATTRIBUTE_KEYS = ("finish", "edition", "color", "graded", "condition", "type")   # properties of a copy (or cards vs sealed): one kind only = nothing to compare
COLOUR_LABELS = ("Color", "Ink", "Domain", "Colour")                          # what a card game calls its colour column
EDITION_GAMES = ("yugioh",)                                                   # the game prints 1st Edition / Unlimited versions and tells them by edition, not by finish
_EDITIONS = ("1st Edition", "Unlimited", "Limited")


def kind_of(game_id):
    g = game_by_id(game_id)
    return "pokemon" if g.pokemon else "toy" if is_misc(game_id) else "card"


# ------------------------------------------------------------------------------------------------ what a game could offer (no data needed)
def plan(game_id):
    """[(key, label)] - every split this game can have, in the order shown.  Which of them show is decided by what the collection holds (options())."""
    kind, g = kind_of(game_id), game_by_id(game_id)
    voc = gamefacets.vocab(game_id)
    if kind == "toy":
        edition = voc["rarityLabel"] if voc["rarityLabel"] != "Rarity" else "Edition"
        return [("set", voc["setLabelOne"]), ("product", "Product type"), ("release", edition), ("type", "Items vs sealed"), ("checklist", "Checklist"), ("card", "Single item")]
    out = [("set", voc["setLabelOne"]), ("serie", "Series"), ("rarity", voc["rarityLabel"])]
    if game_id in EDITION_GAMES:
        out.append(("edition", "Edition"))
    else:
        out.append(("finish", "Finish"))
    if kind == "card" and (game_id == "mtg" or g.type_label in COLOUR_LABELS):
        out.append(("color", g.type_label if g.type_label in COLOUR_LABELS else "Color"))
    out += [("graded", "Graded or raw"), ("condition", "Condition"), ("product", "Sealed product type"), ("type", "Cards vs sealed"), ("checklist", "Checklist"), ("card", "Single card")]
    return out


# ------------------------------------------------------------------------------------------------ one copy -> its name in each split (pure)
def finish_of(game_id, variant):
    """The finish a copy's 'variant' means in this game: Magic 'Non-foil' / 'Foil', Lorcana 'Regular' / 'Foil' / 'Cold Foil', Pokémon 'Normal' / 'Reverse Holo' / 'Holo' ..."""
    raw = str(variant or "").strip()
    low = raw.lower()
    if kind_of(game_id) == "pokemon":
        return next((lab for lab in VARIANT_LABELS.values() if lab.lower() == low), "Normal" if not low else "Other")
    plain = "Non-foil" if game_id == "mtg" else "Regular"
    if "cold" in low:
        return "Cold Foil"
    if "etch" in low:
        return "Etched foil"
    if re.search(r"foil|holo|shiny|sparkle", low):
        return "Foil"
    if "1st" in low or "first" in low:
        return "1st Edition"
    return plain if low in ("", "normal", "regular", "non-foil", "nonfoil", "non foil", "standard", "unlimited", "limited") else "Other"


def edition_of(variant, edition=""):
    """Yu-Gi-Oh!: '1st Edition', 'Unlimited' or 'Limited' - what the copy's Edition says, else its variant (1st Edition), else Unlimited."""
    ed = str(edition or "").strip().lower()
    for e in _EDITIONS:
        if ed == e.lower():
            return e
    if "1st" in ed or "first" in ed or "1st" in str(variant or "").lower():
        return "1st Edition"
    return "Unlimited"


def graded_of(graded, company=""):
    """'Raw' or the company that graded it (PSA, BGS, CGC ...), 'Graded' when no company was entered."""
    return (str(company or "").strip() or "Graded") if graded else "Raw"


def release_of(text):
    """A toy's release: the edition size is not a rarity, 'Limited edition of 250' and 'Limited edition of 400' are both 'Limited edition'."""
    t = str(text or "").strip()
    if not t:
        return UNKNOWN
    return "Limited edition" if re.match(r"(?i)^limited edition\b", t) else t[:1].upper() + t[1:]


def colour_of(types, none_label):
    """From a colour column ('Red', 'Green, Red', ''): the colour, 'Multicolor' for two or more, `none_label` for none."""
    parts = [p.strip() for p in str(types or "").split(",") if p.strip()]
    return none_label if not parts else parts[0] if len(parts) == 1 else "Multicolor"


# ------------------------------------------------------------------------------------------------ the copies in view
def _load(v, db_ids=None):
    """The copies and sealed products to split.  db_ids = portfolio database ids ('' = Main); [] = everything; None = what the Portfolio menu is showing."""
    ids = list(v.scope or []) if db_ids is None else list(db_ids)
    where = f" AND COALESCE(l.portfolio,'') IN ({','.join('?' * len(ids))})" if ids else ""
    lots = v.conn.execute(
        f"SELECT l.card_id, l.qty, l.variant, l.edition, l.graded, l.grade_company, l.condition, {pricepick.sql(v, lot='l')} AS price, c.name, c.rarity, c.category, c.types, c.set_id, "
        f"s.name AS set_name, s.serie FROM u.lots l JOIN cards c ON c.id=l.card_id LEFT JOIN sets s ON s.id=c.set_id "
        f"WHERE l.user_id=? AND l.game=? AND l.deleted=0 AND l.qty>0{where}", [v.user_id, v.game, *ids]).fetchall()
    sealed = []
    try:
        from . import sealedprice
        swhere = f" AND COALESCE(portfolio,'') IN ({','.join('?' * len(ids))})" if ids else ""
        for r in v.conn.execute(f"SELECT name, qty FROM u.sealed WHERE user_id=? AND game=? AND deleted=0 AND qty>0{swhere}", [v.user_id, v.game, *ids]).fetchall():
            p = sealedprice.price_for(v, r["name"])
            sealed.append((sealedclass.kind_of(r["name"], v.game), (p["price"] if p and p["price"] else 0) * r["qty"], r["qty"]))
    except Exception:  # noqa: BLE001 - a game with no sealed list
        sealed = []
    return {"lots": lots, "sealed": sealed, "colors": _colors(v, {r["card_id"] for r in lots}) if "color" in dict(plan(v.game)) and v.game == "mtg" else {}}


def _colors(v, ids):
    """{card id: 'Red' | 'Multicolor' | 'Colorless'} from the Magic colour facet (empty when the list has none yet)."""
    out = {}
    try:
        if not gamefacets._has_table(v.conn):
            return out
        ids = list(ids)
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            # (+facet: look the cards up by id - the facet index would walk every coloured card in the list, 124k for Magic)
            for cid, val in v.conn.execute(f"SELECT card_id, value FROM card_facets WHERE +facet='color' AND card_id IN ({','.join('?' * len(chunk))})", chunk):
                out.setdefault(cid, []).append(val)
    except Exception:  # noqa: BLE001
        return {}
    return {cid: ("Multicolor" if "Multicolor" in vals else vals[0]) for cid, vals in out.items()}


def _rarity_ok(v):
    """Rarity is offered when the game's list has real rarities (the sidebar's own rule: a column of names is not a rarity).  Kept per card list."""
    fp = v.catalog_fp()
    hit = v.__dict__.get("_pfopt_rar")
    if hit and fp is not None and hit[0] == (v.game, fp):
        return hit[1]
    ok = bool(gamefacets.basics(v.conn, v.game)["rarities"])
    v._pfopt_rar = ((v.game, fp), ok)
    return ok


def _label(key, game_id, r, colors):
    """The name of the bucket one copy falls into for this split (r = a row from _load)."""
    if key == "set":
        return r["set_name"] or r["set_id"] or UNKNOWN
    if key == "serie":
        return r["serie"] or "Other"
    if key == "rarity":
        return r["rarity"] or UNKNOWN
    if key == "release":
        return release_of(r["rarity"])
    if key == "finish":
        return finish_of(game_id, r["variant"])
    if key == "edition":
        return edition_of(r["variant"], r["edition"])
    if key == "color":
        if game_id == "mtg":
            return colors.get(r["card_id"], UNKNOWN)
        return colour_of(r["types"], "No " + (game_by_id(game_id).type_label or "color").lower())
    if key == "graded":
        return graded_of(r["graded"], r["grade_company"])
    if key == "condition":
        return "Graded" if r["graded"] else (r["condition"] or "Not stated")
    if key == "product":
        return r["category"] or "Other"
    if key == "card":
        return r["name"] or r["card_id"]
    return UNKNOWN


def _tally(v, key, data):
    """{name: [value, copies]} for one split."""
    game_id, out = v.game, {}

    def add(name, value, copies):
        o = out.setdefault(name, [0.0, 0])
        o[0] += value
        o[1] += copies
    if key == "checklist":
        for name, val in v.checklist_values().items():
            add(name, val, 0)
    elif key == "type":
        add("Items" if kind_of(game_id) == "toy" else "Cards", sum((r["price"] or 0) * r["qty"] for r in data["lots"]), sum(r["qty"] for r in data["lots"]))
        add("Sealed products", sum(val for _k, val, _n in data["sealed"]), sum(n for _k, _v, n in data["sealed"]))
    elif key == "product":
        if kind_of(game_id) == "toy":
            for r in data["lots"]:
                add(_label("product", game_id, r, None), (r["price"] or 0) * r["qty"], r["qty"])
        for kind, val, n in data["sealed"]:
            add(kind, val, n)
    else:
        for r in data["lots"]:
            add(_label(key, game_id, r, data["colors"]), (r["price"] or 0) * r["qty"], r["qty"])
    return out


def _rows(v, key, data):
    """[[name, value, copies]] for one split, biggest first; a name that is worth nothing and holds no copies is left out."""
    return sorted(([k, round(val, 2), n] for k, (val, n) in _tally(v, key, data).items() if val or n), key=lambda kv: -kv[1])


def _worth_showing(key, rows):
    rows = [r for r in rows if r[1] > 0]                                          # (a name with no price adds nothing to a value split)
    if not rows:
        return False
    if key not in ("set", "serie") and all(r[0] in (UNKNOWN, "Other", "Not stated") for r in rows):
        return False                                                            # (the list does not say: nothing to split by)
    return len(rows) > 1 if key in ATTRIBUTE_KEYS else True


def detail(v, db_ids=None):
    """{key: [[name, value, copies]]} for every split the game offers that has something to show (the order of plan())."""
    data = _load(v, db_ids)
    out = {}
    for key, _label_ in plan(v.game):
        if key == "rarity" and not _rarity_ok(v):
            continue
        rows = _rows(v, key, data)
        if _worth_showing(key, rows):
            out[key] = rows
    return out


def options(v, db_ids=None):
    """{game, kind, dims: [{key, label}]} - the splits to offer for the open game and the portfolios in view (see the module notes)."""
    shown = detail(v, db_ids)
    labels = dict(plan(v.game))
    return {"game": v.game, "kind": kind_of(v.game), "dims": [{"key": k, "label": labels[k]} for k in labels if k in shown]}


def rows_of(v, key, db_ids=None):
    """One split as [[name, value, copies]] - empty for a split this game does not offer or that has nothing to show."""
    if key not in dict(plan(v.game)) or (key == "rarity" and not _rarity_ok(v)):
        return []
    rows = _rows(v, key, _load(v, db_ids))
    return rows if _worth_showing(key, rows) else []


def breakdown(v, key, db_ids=None):
    """One split as [[name, value]] (what the 'Where your value is' bars read)."""
    return [[n, val] for n, val, _c in rows_of(v, key, db_ids) if val]


# ------------------------------------------------------------------------------------------------ the phone / website build
def phone_split(v):
    """What the phone's card list needs to apply the same rules (ui/src/phone/portfolio.js): ({kind, typeLabel, plan, colors, products}, {card id: [colour index, product index]}).
    The phone has no sealed products and no checklist values, so those splits are not in its plan; a split the game's list could never fill (rarity of a list of names) is left out too."""
    kind, g = kind_of(v.game), game_by_id(v.game)
    plan_ = [(k, lab) for k, lab in plan(v.game) if k not in ("checklist", "type") and (k != "product" or kind == "toy") and (k != "rarity" or _rarity_ok(v))]
    keys = {k for k, _l in plan_}
    colors, products, per = [], [], {}
    if "color" in keys and v.game == "mtg":
        found = _colors(v, {r[0] for r in v.conn.execute("SELECT DISTINCT card_id FROM card_facets WHERE facet='color'")}) if gamefacets._has_table(v.conn) else {}
        colors = sorted(set(found.values()))
        for cid, name in found.items():
            per.setdefault(cid, [-1, -1])[0] = colors.index(name)
    if "product" in keys:
        cats = {cid: cat for cid, cat in v.conn.execute("SELECT id, category FROM cards WHERE category IS NOT NULL AND category!=''")}
        products = sorted(set(cats.values()))
        idx = {p: i for i, p in enumerate(products)}
        for cid, cat in cats.items():
            per.setdefault(cid, [-1, -1])[1] = idx[cat]
    return {"kind": kind, "game": v.game, "typeLabel": g.type_label, "plan": [list(p) for p in plan_], "colors": colors, "products": products}, per
