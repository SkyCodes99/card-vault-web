"""Search without a Python call per card.

Typed words are matched ignoring capitals, accents and curly apostrophes ('pokemon' finds 'Pokémon', 'farfetchd' finds 'Farfetch'd').  That used to be done by a Python function SQLite called nine times for
every card of the list on every search: a Magic search (107,000 cards) took 1.4 s on a PC and 3.7 s in the browser.  Now every card and set carries the words search looks in, already folded, in a `fold`
column - made once per list (a list published from 3.50.120 on already has it) - and a search is one LIKE per card.  tests/test_searchfold.py checks that both ways answer the same."""
import unicodedata

LOCAL_NAMES = ("name_es", "name_fr", "name_de", "name_it", "name_pt")          # (the same list as names.COLUMNS: kept here so this module needs nothing from it)
SEP = "\n"                                          # between the fields of one card: a typed word never contains it, so a word can't match across two fields


def fold(s):
    """Lower case, no accents, straight apostrophes: what search compares (so 'pokemon' finds 'Pokémon' and "farfetchd" finds "Farfetch'd")."""
    s = str(s if s is not None else "")
    if s.isascii():                                  # (nearly every name: nothing to take off)
        return s.lower()
    out = []
    for ch in unicodedata.normalize("NFKD", s):
        if ord(ch) < 128:
            out.append(ch)
        elif unicodedata.combining(ch):
            if out and ord(out[-1]) >= 0x250:                      # a mark on a Japanese / other-script letter belongs to it; on a Latin letter it is just an accent
                out.append(ch)
        elif ord(ch) >= 0x250 and ch not in "’‘":                  # other scripts (Japanese, Korean...) are kept so they can be searched
            out.append(ch)
    return "".join(out).lower().replace("’", "'")


def words(*fields):
    """The folded words of one card or set: its fields folded and joined (empty ones left out)."""
    return SEP.join(f for f in (fold(x) for x in fields) if f)


def fill(conn, force=False):
    """Fold the search words of every card and set that has none yet (of all of them with force).  Safe to run any time; a list that is complete costs one quick look.  -> cards done"""
    where = "" if force else " WHERE fold IS NULL"
    done = 0
    local = [c for c in LOCAL_NAMES if any(r[1] == c for r in conn.execute("PRAGMA table_info(cards)"))]       # the official names in other languages (cardvault/names.py): searchable too
    cards = conn.execute(f"SELECT rowid, name, local_id, illustrator, rarity, name_ja, name_en{''.join(', ' + c for c in local)} FROM cards{where}").fetchall()
    for i in range(0, len(cards), 20000):
        conn.executemany("UPDATE cards SET fold=? WHERE rowid=?", [(words(r[1], r[2], r[3], r[4], r[5], r[6], *r[7:]), r[0]) for r in cards[i:i + 20000]])
        done += len(cards[i:i + 20000])
    sets = conn.execute(f"SELECT rowid, name, name_ja, name_en FROM sets{where}").fetchall()
    conn.executemany("UPDATE sets SET fold=? WHERE rowid=?", [(words(r[1], r[2], r[3]), r[0]) for r in sets])
    if cards or sets:
        conn.commit()
    return done


def complete(conn):
    """True when every card and set has its folded words."""
    return not conn.execute("SELECT 1 FROM cards WHERE fold IS NULL LIMIT 1").fetchone() and not conn.execute("SELECT 1 FROM sets WHERE fold IS NULL LIMIT 1").fetchone()
