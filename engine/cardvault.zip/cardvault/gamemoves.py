"""Items that moved from one list (game) to another.

meta 'id_redirects' (db.Vault._apply_id_redirects) only works inside ONE list: it says which id of that list stays.  An item that changes list keeps nothing of yours unless it is moved
too, so this table says where it went: {(old game, old item id): (new game, new item id)}.  At every opening of either list (db.Vault.__init__) everything of yours that still points
at the old place is moved to the new one: copies you own (signed, graded, photos and portfolio go with the copy), wishlist and tags.  Safe to run every time: once moved, nothing
points at the old place any more.  A checklist, binder or trade belongs to its own list and keeps its entry.

    owner quiz 2026-11-15 q12 ("Create the sports category if not there yet and it just goes in sports"): the two Costco FIFA World Cup sticker boxes, Accessories -> Sports
"""
from .collabmerch import KEY

MOVES = {
    ("accessories", KEY + "cwc-2026-panini-fifa-world-cup-sticker-stadium-box-costco"): ("sports", KEY + "cwc-2026-panini-fifa-world-cup-sticker-stadium-box-costco"),
    ("accessories", KEY + "cwc-2026-panini-fifa-world-cup-sticker-collection-box-costco"): ("sports", KEY + "cwc-2026-panini-fifa-world-cup-sticker-collection-box-costco"),
}
GAMES = frozenset(g for pair in MOVES.items() for g, _i in pair)


def apply(conn, game, ts):
    """Moves what is still at an old place (u.* tables of the attached collection).  -> number of copies moved.  Does nothing unless `game` is one of the lists involved."""
    if game not in GAMES:
        return 0
    n = 0
    for (og, oid), (ng, nid) in MOVES.items():
        if game not in (og, ng):
            continue
        n += conn.execute("UPDATE u.lots SET game=?, card_id=?, updated_at=? WHERE game=? AND card_id=?", (ng, nid, ts, og, oid)).rowcount
        conn.execute("UPDATE OR IGNORE u.wishlist SET game=?, card_id=? WHERE game=? AND card_id=?", (ng, nid, og, oid))
        conn.execute("DELETE FROM u.wishlist WHERE game=? AND card_id=?", (og, oid))                  # (already wished for at the new place)
        conn.execute("UPDATE OR IGNORE u.card_tags SET game=?, card_id=?, updated_at=? WHERE game=? AND card_id=?", (ng, nid, ts, og, oid))
        conn.execute("DELETE FROM u.card_tags WHERE game=? AND card_id=?", (og, oid))
    return n
