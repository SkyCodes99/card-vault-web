"""Promo and reprint cards whose picture decides which art category they belong in, although the card source labels them just "Promo" or "Classic Collection".
Checked by eye against the card pictures (at full size).  Three lists:
  ALT           V / VMAX alternate arts            -> Alternate Art (and Art)
  ILLUSTRATION  full scene illustrations            -> Illustration Rare style (and Art)
  FULL_ART      full-art cards with a patterned / foil background (NOT scene art) -> the Full Art categories, never Art
Add more with the owner's Card tools (Art category > Find cards to add > "Likely art first"), then add their ids here."""

ALT = frozenset({
    # Eevee evolutions alternate-art V / VMAX promos (SWSH Black Star Promos) and the oversize versions of the VMAX ones; the Classic Collection Mew VMAX alternate art; Greninja V-UNION
    "swshp-SWSH179", "swshp-SWSH180", "swshp-SWSH181", "swshp-SWSH182", "swshp-SWSH183", "swshp-SWSH184", "257708", "257709", "257710", "30th-c-026",
    "swshp-SWSH155", "swshp-SWSH156", "swshp-SWSH157", "swshp-SWSH158",
})

ILLUSTRATION = frozenset({
    # Scarlet & Violet promos that are full scene illustrations
    "svp-013", "svp-014", "svp-044", "svp-208", "svp-209", "svp-210", "svp-211", "svp-212", "svp-213", "svp-214", "svp-215",
    "svp-051", "svp-052", "svp-053", "svp-085", "svp-097", "svp-098", "svp-123", "svp-129", "svp-130", "svp-131", "svp-132", "svp-173", "svp-203", "svp-206", "svp-207",
    # Classic Collection reprint of the Paldea Evolved Magikarp illustration
    "716210",
    # Mega Evolution First Partner Illustration Collection, Series 1-3: the illustrated starters (Bulbasaur ... Quaxly), Mega promos 037-063
    *[f"mep-{n:03d}" for n in range(37, 64)],
})

FULL_ART = frozenset({
    # Mega ex promos (Zeraora, Darkrai, Dragonite, Charizard X / Y, Kangaskhan, Gardevoir, Lucario, Meganium, Emboar, Feraligatr, Zygarde, Clefable, Gengar, Greninja)
    "710754", "710756", "710757", *[f"mep-{n:03d}" for n in (23, 25, 29, 30, 32, 33, 34, 35, 36, 71, 72, 73, 81)],
    # Scarlet & Violet full-art ex promos (Charizard, Cinderace, Lapras, Terapagos, Ogerpon, Eevee, Espeon, Umbreon, Cynthia's Garchomp, Team Rocket's Mewtwo / Nidoking / Persian)
    "svp-074", "svp-163", "svp-164", "svp-165", "svp-166", "svp-174", "svp-175", "svp-176", "svp-204", "svp-205", "svp-216", "svp-217", "svp-218",
})

IDS = ALT | ILLUSTRATION
