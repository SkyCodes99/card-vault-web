"""Promo and reprint cards whose picture decides which art category they belong in, although the card source labels them just "Promo" or "Classic Collection".
Checked by eye against the card pictures (at full size).  Three lists:
  ALT           V / VMAX alternate arts            -> Alternate Art (and Art)
  ILLUSTRATION  full scene illustrations            -> Illustration Rare style (and Art)
  FULL_ART      full-art cards with a patterned / foil background (NOT scene art) -> the Full Art categories, never Art
Add more with the owner's Card tools (Art category > Find cards to add > "Likely art first"), then add their ids here."""

ALT = frozenset({
    # Eevee evolutions alternate-art V / VMAX promos (SWSH Black Star Promos) and the oversize versions of the VMAX ones; the Classic Collection Mew VMAX alternate art; Greninja V-UNION
    "swshp-SWSH179", "swshp-SWSH180", "swshp-SWSH181", "swshp-SWSH182", "swshp-SWSH183", "swshp-SWSH184", "257708", "257709", "257710", "30th-c-026",
    "swshp-SWSH155", "swshp-SWSH156", "swshp-SWSH157", "swshp-SWSH158",
})

ILLUSTRATION = frozenset({
    # Scarlet & Violet promos that are full scene illustrations
    "svp-013", "svp-014", "svp-027", "svp-065", "svp-066", "svp-124", "svp-075", "svp-088", "svp-141","svp-167","svp-168","svp-169","svp-170","svp-171","svp-172","svp-177","svp-189","svp-193","svp-194","svp-195",
    "mep-005","mep-006","mep-007","mep-008","mep-009","mep-010","mep-018","mep-019","mep-020","mep-022","mep-024","mep-026","mep-027","mep-028","mep-031","mep-078","mep-079","mep-080","mep-086","mep-087","mep-092","mep-094", "svp-044", "svp-208", "svp-209", "svp-210", "svp-211", "svp-212", "svp-213", "svp-214", "svp-215",
    "svp-051", "svp-052", "svp-053", "svp-085", "svp-097", "svp-098", "svp-123", "svp-129", "svp-130", "svp-131", "svp-132", "svp-173", "svp-203", "svp-206", "svp-207",
    # Classic Collection reprint of the Paldea Evolved Magikarp illustration
    "716210",
    # Mega Evolution First Partner Illustration Collection, Series 1-3: the illustrated starters (Bulbasaur ... Quaxly), Mega promos 037-063
    *[f"mep-{n:03d}" for n in range(37, 64)],
    # XY Black Star Promos, checked at full size 2026-10-22: the full-art promos whose picture is a SCENE (Mew's meadow and rainbow, Jirachi's starry sky over mountains, Manaphy's coral reef,
    # Keldeo's mountains ... the Mythical / Legendary full-art set XY110-XY120) and Regigigas in its ruins.  They are full arts too, so they are also listed in FULL_ART below.
    *[f"xyp-XY{n}" for n in range(110, 121)], "xyp-XY82",
    # Sun & Moon Black Star Promos: the Magikarp & Wailord TAG TEAM wave scene
    "smp-SM166",
})

FULL_ART = frozenset({
    "mep-011", "mep-012", "mep-013", "mep-089", "mep-090", "mep-091",
    # Mega ex promos (Zeraora, Darkrai, Dragonite, Charizard X / Y, Kangaskhan, Gardevoir, Lucario, Meganium, Emboar, Feraligatr, Zygarde, Clefable, Gengar, Greninja)
    "710754", "710756", "710757", *[f"mep-{n:03d}" for n in (23, 25, 29, 30, 32, 33, 34, 35, 36, 71, 72, 73, 81)],
    # Scarlet & Violet full-art ex promos (Charizard, Cinderace, Lapras, Terapagos, Ogerpon, Eevee, Espeon, Umbreon, Cynthia's Garchomp, Team Rocket's Mewtwo / Nidoking / Persian)
    "svp-074", "svp-163", "svp-164", "svp-165", "svp-166", "svp-174", "svp-175", "svp-176", "svp-204", "svp-205", "svp-216", "svp-217", "svp-218",
    # XY Black Star Promos (checked at full size): the full-art promos - no art window, the artwork runs under the attack text.  (The ordinary EX promos have the black bar under the art window and are NOT here.)
    "xyp-XY67a", *[f"xyp-XY{n}" for n in (*range(74, 84), *range(110, 127), 133, 148, 183, 185)],
    # Sun & Moon Black Star Promos: Decidueye / Incineroar / Primarina / Charizard / Salamence / White Kyurem GX full arts, the rainbow Kingdra / Dragonite GX, the stained-glass Moltres & Zapdos & Articuno,
    # the white Eevee GX and the golden Reshiram & Charizard / Pikachu & Zekrom TAG TEAM GX
    "smp-SM37", "smp-SM38", "smp-SM39", "smp-SM60", "smp-SM139", "smp-SM141", "smp-SM155", "smp-SM156", "smp-SM210", "smp-SM242", "smp-SM247", "smp-SM248",
})

IDS = ALT | ILLUSTRATION
