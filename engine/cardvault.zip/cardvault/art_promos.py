"""Promo and reprint cards that ARE art cards (full-card illustrations / alternate arts) although the card source labels them just "Promo" or "Classic Collection".
Checked by eye against the card pictures.  Add more with the owner's Card tools (Art category > Find cards to add > "Likely art first"), then add their ids here."""

IDS = frozenset({
    # Eevee evolutions alternate-art V / VMAX promos (SWSH Black Star Promos) and the oversize versions of the VMAX ones
    "swshp-SWSH179", "swshp-SWSH180", "swshp-SWSH181", "swshp-SWSH182", "swshp-SWSH183", "swshp-SWSH184", "257708", "257709", "257710",
    # Scarlet & Violet promos that are full illustrations: Snorlax SVP 051, Mew ex SVP 053
    "svp-051", "svp-053",
    # Classic Collection reprints of art cards: Mew VMAX alternate art, Magikarp 203/193 (Paldea Evolved illustration), Lugia 149/147
    "30th-c-026", "716210", "714386",
})
