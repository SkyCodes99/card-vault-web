"""Comics: the sidebar filters, read from each issue's stated facts (raw ext written by cardvault/comics.py).  Pure text rules, used by cardvault/gamefacets.py.

A filter value is always a word the source states: the publisher, the cover year (from the stated cover date), whether the issue is one of several covers / editions, and - for a key issue - which
kind of claim the source makes ("First appearance", "Origin", "Death" ...).  An issue whose source states none of them has no value in that filter."""
import re

_KINDS = (("First appearance", r"\b(?:first|1st)\b.*\bappearance\b"), ("Origin", r"\borigin\b"), ("Death", r"\bdeath\b"), ("Debut", r"\bdebut\b"), ("Last appearance", r"\blast appearance\b"))


def _year(e):
    m = re.search(r"\b(\d{4})\b", str(e.get("Cover date") or ""))
    return m.group(1) if m else ""


def year(e, c):
    return [_year(e)] if _year(e) else []


def decade(e, c):
    return ["%s0s" % _year(e)[:3]] if _year(e) else []


def cover(e, c):
    """'Standard' for the issue itself, 'Variant cover or edition' for one of its other covers (its source names it)."""
    return ["Variant cover or edition"] if e.get("Cover") else (["Standard"] if e.get("Issue") else [])


def key_kind(e, c):
    """Which claim a key issue's source makes ('First appearance', 'Origin', 'Death' ...), else 'Other key issue'; nothing for an ordinary issue."""
    out = []
    for note in str(e.get("Key issue") or "").split(" / "):
        if note.strip():
            out.append(next((label for label, rx in _KINDS if re.search(rx, note.lower())), "Other key issue"))
    return list(dict.fromkeys(out))


def _one(key):
    return lambda e, c: [str(e[key]).strip()] if e.get(key) else []


FACETS = [("publisher", "Publisher", _one("Publisher")), ("decade", "Decade", decade), ("year", "Cover year", year), ("cover", "Cover", cover), ("key", "Key issue (what the source states)", key_kind),
          ("artist", "Cover artist", _one("Cover artist"))]
