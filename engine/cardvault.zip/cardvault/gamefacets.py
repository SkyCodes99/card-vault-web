"""The ways a collector of each card game finds and groups cards - beyond rarity, card type and colour: Yu-Gi-Oh! frames / attributes / monster types, Magic subtypes, One Piece traits and
costs, Lorcana classifications, Union Arena affinities, Gundam / Weiss Schwarz traits and levels... and, for every game, the SPECIAL PRINTING of a card (alternate art, parallel, manga, borderless,
showcase, foil finishes, stamped / signature, event prizes...).

Everything is worked out from what the card list already holds (the shop's own fields in `raw`, the card's name) and kept in one small table of the list itself:

    card_facets(card_id, facet, value)         one row per value (a card can have several)

so searching, grouping and the master-set tools all read the same thing.  The table is rebuilt whenever the card list is fetched (and once, on the spot, for a list that was downloaded before this
existed).  `fix_columns` also tidies the ordinary columns where a shop's data was inconsistent (Yu-Gi-Oh! had its card type scattered over 111 spellings and no category at all)."""
import json
import re

from . import cardkinds, cardtext, comicsfacets, facetvalues, funkofandoms, funkovariants, hotwheelsfacets, tcgfacets, videogamefacets

VERSION = 7                  # 7: card details (regulation mark, keywords, level / rank, archetype ...) - lists built before need the facets again; 6: a whole number 0 (a land's mana value) is a value

# ---------------------------------------------------------------------------------------------------------------- special printings (all card games)
_PRINT_RULES = [
    ("Alternate art", r"\balt(?:ernate)?\.? art\b|\bspecial art\b|\bjp alternate art\b"),
    ("Parallel", r"\bparallel\b"),
    ("Manga art", r"\bmanga\b"),
    ("Full art", r"\bfull art\b"),
    ("Extended art", r"\bextended art\b"),
    ("Borderless", r"\bborderless\b"),
    ("Showcase", r"\bshowcase\b"),
    ("Retro frame", r"\bretro\b"),
    ("Special foil", r"\b(?:surge|rainbow|ripple|galaxy|halo|etched|textured|pirate|jolly roger|silver|gold|box topper|first-place|confetti|neon ink|step-and-compleat|alternate)\s+foil\b|\bfoil etched\b|\bstarfoil\b|\bshatterfoil\b|\bmosaic\b"),
    ("Stamped / signature / numbered", r"gold[- ]stamp|silver[- ]stamp|winner stamp|\bsignature\b|serial numbered|autograph"),
    ("Event / prize / promo", r"\b(?:winner|finalist|participant|participation|judge|store championship|regionals?|release event|top \d+|prize|champion(?:ship)?|celebration pack|player bundle|prerelease|launch|tournament|top players|expo|cruise promo|card game fest|worlds|store)\b"),
    ("Reprint", r"\breprint\b"),
    ("Oversized", r"\boversized?\b"),
    ("Other language", r"\b(?:spanish|italian|french|german|portuguese|japanese|korean|russian|chinese|jp exclusive)\b"),
    ("Star rarity", r"(?:^|\|\s*)[A-Z]{1,3}\*+\s*(?:\||$)"),
]
_PRINT_RX = [(label, re.compile(rx, re.I)) for label, rx in _PRINT_RULES]
_TAIL = re.compile(r"\(([^()]{1,60})\)|\[([^\[\]]{1,60})\]")


def printing_of(name, rarity="", game=""):
    """The special printings a card is, from the brackets in its name (and its rarity): ['Alternate art', 'Special foil'] - or ['Regular'] when it is the ordinary card."""
    parts = [(a or b) for a, b in _TAIL.findall(name or "")]
    text = " | ".join(parts)
    out = []
    for label, rx in _PRINT_RX:
        if rx.search(text) or (label == "Star rarity" and re.search(r"\d-Star\b", rarity or "")):
            out.append(label)
    if game == "yugioh":
        out = [x for x in out if x not in ("Special foil",)]           # a Yu-Gi-Oh! finish is its rarity (Starlight, Starfoil, Mosaic...) - already filterable
    return out or ["Regular"]


# ---------------------------------------------------------------------------------------------------------------- per-game facets
_split, _thousands, _num, _bucket = facetvalues.split, facetvalues.thousands, facetvalues.num, facetvalues.bucket                  # (the small helpers every game's filters are made of)


# Pokémon: what a collector filters by besides the era / type / rarity the sidebar already had - the kind of card, Trainer / Energy kind, stage, the mechanic in its name (V, VMAX, ex, GX...) and its HP.
_PK_MECH = [("V", re.compile(r"\bV\b(?!-)")), ("VMAX", re.compile(r"\bVMAX\b")), ("VSTAR", re.compile(r"\bVSTAR\b")), ("V-UNION", re.compile(r"\bV-UNION\b")), ("ex", re.compile(r"\bex\b")),
            ("EX", re.compile(r"\bEX\b")), ("GX", re.compile(r"\bGX\b")), ("Tag Team", re.compile(r"&.*\bGX\b|\bTAG TEAM\b", re.I)), ("BREAK", re.compile(r"\bBREAK\b")),
            ("Mega", re.compile(r"^(Mega|M)\s|\bMega\b")), ("Radiant", re.compile(r"\bRadiant\b")), ("Prism Star", re.compile(r"\bPrism Star\b|\u25c7")), ("Shining", re.compile(r"^Shining\b")),
            ("Delta Species", re.compile(r"\bDelta Species\b|\u03b4")), ("Prime / LEGEND", re.compile(r"\bPRIME\b|\bLEGEND\b")), ("Terastal", re.compile(r"\bTera\b|\bTerastal\b"))]


def _pk_kind(e, c):
    from .taxonomy import canon_category
    k = canon_category(c.get("category"), c.get("types"), c.get("name"))
    return [{"Pokemon": "Pok\u00e9mon", "Trainer": "Trainer", "Energy": "Energy"}[k]] if k in ("Pokemon", "Trainer", "Energy") else []


def _pk_sub(e, c):
    t = (str(c.get("types") or "") + " " + str(c.get("category") or "")).lower()
    for words, label in ((("special energy",), "Special Energy"), (("basic", "energy"), "Basic Energy"), (("supporter",), "Supporter"), (("stadium",), "Stadium"), (("tool",), "Pok\u00e9mon Tool"), (("item",), "Item")):
        if all(w in t for w in words):
            return [label]
    return []


_PK_STAGE = {"basic": "Basic", "stage1": "Stage 1", "stage2": "Stage 2", "level-up": "Level-Up", "restored": "Restored", "mega": "Mega", "v-union": "V-UNION", "baby": "Baby", "vmax": "VMAX", "vstar": "VSTAR", "break": "BREAK"}


def _pk_stage(e, c):
    s = str(c.get("stage") or "").strip()
    return [_PK_STAGE.get(s.lower(), s)] if s else []


def _pk_mech(e, c):
    name = str(c.get("name") or "")
    return [label for label, rx in _PK_MECH if rx.search(name)][:3]


def _pk_hp(e, c):
    m = re.search(r"\d+", str(c.get("hp") or ""))
    if not m or int(m.group()) <= 0:
        return []
    n = int(m.group())
    return ["10-50" if n <= 50 else "60-90" if n <= 90 else "100-130" if n <= 130 else "140-190" if n <= 190 else "200+"]


def _pk_doc(c):
    d = c.get("doc")
    return d if isinstance(d, dict) else {}


def _pk_regulation(e, c):
    m = str(_pk_doc(c).get("regulationMark") or "").strip().upper()
    return [m] if re.fullmatch(r"[A-Z]", m) else []


def _pk_ability(e, c):
    return [str(a.get("type") or "Ability").strip() for a in _pk_doc(c).get("abilities") or [] if isinstance(a, dict)][:3]


def _pk_weakness(e, c):
    return [str(w.get("type")).strip() for w in _pk_doc(c).get("weaknesses") or [] if isinstance(w, dict) and w.get("type")][:3]


def _pk_retreat(e, c):
    r = _pk_doc(c).get("retreat")
    return [str(r) if r < 4 else "4+"] if isinstance(r, int) and r >= 0 else []


_PK_FACETS = [("kind", "Card kind", _pk_kind), ("sub", "Trainer / Energy kind", _pk_sub), ("stage", "Stage", _pk_stage), ("mech", "Mechanic (V, VMAX, ex, GX ...)", _pk_mech), ("hp", "HP", _pk_hp),
              ("regulation", "Regulation mark", _pk_regulation), ("ability", "Ability (Ability, Poke-Power, Poke-Body ...)", _pk_ability), ("weakness", "Weakness", _pk_weakness), ("retreat", "Retreat cost", _pk_retreat)]


_MTG_COLORS = {"W": "White", "U": "Blue", "B": "Black", "R": "Red", "G": "Green"}


def _mtg_color(e, c):
    """From the colours in the card's own data (tools/enrich_mtg.py adds them): White / Blue / Black / Red / Green, Colorless, and Multicolor for two or more.  Nothing for a list that has none yet."""
    if "Colors" not in e:
        return []
    out = [_MTG_COLORS[x] for x in str(e.get("Colors") or "").split(",") if x in _MTG_COLORS]
    if not out:
        return ["Colorless"]
    return out + (["Multicolor"] if len(out) > 1 else [])


_WUBRG = "WUBRG"


def mtg_color_key(ext):
    """The sort key of a Magic card's colour: White, Blue, Black, Red, Green (in that order), then gold (two or more colours), then colourless.  None when the card has no colour facts yet."""
    if "Colors" not in ext:
        return None
    cs = [x for x in _WUBRG if x in str(ext.get("Colors") or "").split(",")]
    if not cs:
        return "7 Colorless"
    return f"{_WUBRG.index(cs[0]) + 1} {_MTG_COLORS[cs[0]]}" if len(cs) == 1 else "6 Multicolor " + "".join(cs)


def _mtg_pt(key):
    """Power / toughness as printed ('3', '0', '*', '1+*', '-1'); nothing for a card that has none."""
    def get(e, c):
        v = str(e.get(key) if e.get(key) is not None else "").strip()
        return [v] if v and re.fullmatch(r"[0-9*+-]{1,6}", v) else []
    return get


def _mtg_mv(e, c):
    return _num(e.get("ManaValue")) if e.get("ManaValue") not in (None, "") else []


def _parens(v):
    """'(Earth Federation) (White Base Team)' -> ['Earth Federation', 'White Base Team']"""
    found = re.findall(r"\(([^()]+)\)", str(v or ""))
    return [x.strip() for x in found] or _split(v, r"[;,]")


def _attr(v):
    out = [x.upper() for x in _split(v)]
    return [x for x in out if x not in ("SPELL", "TRAP", "SKILL")]


def _first(ext, *keys):
    for k in keys:
        if ext.get(k) not in (None, ""):
            return ext[k]
    return None


_YGO_FRAMES = ["Normal", "Effect", "Fusion", "Synchro", "Xyz", "Link", "Pendulum", "Ritual", "Tuner", "Flip", "Spirit", "Union", "Gemini", "Toon", "Token", "Skill", "Special Summon"]
_YGO_ST = ["Normal", "Quick-Play", "Continuous", "Field", "Equip", "Ritual", "Counter"]


def _ygo_card_type(ext):
    t = str(ext.get("Card Type") or ext.get("CardType") or "")
    if "Spell" in t:
        return "Spell"
    if "Trap" in t:
        return "Trap"
    if "Skill" in t:
        return "Skill"
    if t:
        return "Monster"
    return ""


def _ygo_frame(ext):
    t = str(ext.get("Card Type") or ext.get("CardType") or "")
    kind = _ygo_card_type(ext)
    if kind in ("Spell", "Trap"):
        return [x + " " + kind for x in _YGO_ST if x.lower() in t.lower()] or [kind]
    return [x for x in _YGO_FRAMES if re.search(r"\b" + re.escape(x) + r"\b", t)] or ([t] if t else [])


_MTG_SUPER = ["Legendary", "Basic", "Snow", "World", "Ongoing"]


def _mtg_line(ext):
    return str(ext.get("SubType") or "").replace("\xa0", " ")


_DASH = re.compile("\\s+[\u2014\u2013\ufffd-]\\s+")                   # the dash of a type line (a damaged copy of it shows as a replacement character)


def _mtg_faces(ext):
    """[(type words before the dash, subtype words after it)] for each face of the card ('A - x // B - y' is a two-faced card)."""
    out = []
    for face in _mtg_line(ext).split("//"):
        parts = _DASH.split(face.strip(), maxsplit=1)
        out.append((parts[0], parts[1] if len(parts) > 1 else ""))
    return out


def _mtg_subtypes(ext):
    return list(dict.fromkeys(w for _h, sub in _mtg_faces(ext) for w in sub.split() if w and w[0].isalpha()))[:8]


def _mtg_supertypes(ext):
    heads = " ".join(h for h, _s in _mtg_faces(ext))
    return [s for s in _MTG_SUPER if re.search(r"\b" + s + r"\b", heads)]


# ---------------------------------------------------------------------------------------------------------------- the designer-toy shops (Abominable Toys, 100% Soft)
NO_PRINTING = {"chomps", "dumpsterfires", "funko", "accessories", "plushies", "needoh", "consoles", "youtooz", "beyblade", "bakugan", "hotwheels", "comics", "videogames"}                 # 'special printing' is a card-game idea; toys have their own filters below


def _ptype(e, c):
    """What kind of product it is, from the shop's own words: Plush / Squishy & ceramic / Blind box / Bust / Resin figure / Vinyl figure / Misc."""
    text = " ".join([str(c.get("name") or ""), str(e.get("Shop name") or ""), " ".join(c.get("tags") or []), str(c.get("category") or "")]).lower()
    for words, label in ((("plush",), "Plush"), (("squishy", "ceramic"), "Squishy & ceramic"), (("blind", "mystery"), "Blind box / bag"), (("bust",), "Bust"), (("resin",), "Resin figure"),
                         (("vinyl", "figure", "chomp", "toy"), "Vinyl figure")):
        if any(w in text for w in words):
            return [label]
    return ["Misc"]


_SHOP_FACETS = [("ptype", "Product type", _ptype),
                ("avail", "In stock / sold out", lambda e, c: (["Sold out" if "sold out" in str(e.get("Availability")).lower() else "In stock"] if e.get("Availability") else [])),
                ("edition", "Edition", lambda e, c: (["Open edition" if "open" in str(e.get("Edition", "")).lower() else "Limited edition"] if e.get("Edition") else [])),
                ("exclusive", "Exclusive to", lambda e, c: [x.strip() for x in str(e.get("Exclusive to", "")).split(",") if x.strip() and x.strip().lower() != "not exclusive"]),
                ("designer", "Designer / artist", lambda e, c: ([str(e["Designer"]).strip()] if e.get("Designer") else [])),
                ("series", "Series (blind-bag set)", lambda e, c: ([str(e["Series"]).strip()] if e.get("Series") else [])),
                ("tier", "Chase / rarity in its series", lambda e, c: ([str(e["Series rarity"]).strip()] if e.get("Series rarity") else []))]


# Funko: what KIND of product it is (Pop! Vinyl, Wacky Wobbler, Pocket Pop, Dorbz, Pop! Pez ...) and, separately, its CATEGORY / fandom (Animation, Television, 8-Bit, Ad Icons, Movies ...)
_FUNKO_FACETS = [("ptype", "Product type", lambda e, c: [str(c.get("category")).strip()] if c.get("category") else []),
                 ("fandom", "Category (fandom)", lambda e, c: [str(e["Fandom"])] if e.get("Fandom") else [funkofandoms.fandom_for(str(c.get("setname") or "").strip(), c.get("name"))] if c.get("setname") else []),
                 ("franchise", "Franchise (Yu-Gi-Oh!, Pokemon, Dragon Ball ...)", lambda e, c: [funkofandoms.franchise_of(c.get("name"), e.get("Franchise"))] if funkofandoms.franchise_of(c.get("name"), e.get("Franchise")) else []),
                 ("signed", "Signed Pops (off = hide them)", lambda e, c: ["Signed" if e.get("Signed by") else "Not signed"]),
                 ("sticker", "Sticker (store / convention exclusive)", lambda e, c: funkovariants.facet_stickers(c.get("name"), c.get("tags") or [])),
                 ("finish", "Finish / chase", lambda e, c: funkovariants.facet_finishes(c.get("name"), c.get("tags") or [])),
                 ("tag", "Exclusive / special", lambda e, c: [t for t in (c.get("tags") or []) if t and t != c.get("category") and re.search(r"exclusive|chase|glow|flocked|metallic|diamond|con\b|convention|limited", t, re.I)][:4])]


_MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]


def _yt_avail(e, c):
    tags = {str(t).lower() for t in (c.get("tags") or [])}
    for key, label in (("coming_soon", "Coming soon"), ("backorder", "Backorder"), ("in_stock", "In stock"), ("past_drop", "Past drop")):
        if key in tags:
            return [label]
    return ["Sold out" if "sold out" in str(e.get("Availability")).lower() else "In stock"] if e.get("Availability") else []


def _yt_drop(e, c):
    for t in c.get("tags") or []:
        m = re.fullmatch(r"([a-z]{3})_(\d{4})_drop", str(t).lower())
        if m and m.group(1) in _MONTHS:
            return [f"{m.group(2)} {m.group(1).capitalize()}"]
    return []


_YT_FACETS = [("ptype", "Product type", lambda e, c: [("Plush" if "plush" in str(c.get("name")).lower() else "Mini / blind box" if re.search(r"mini|blind", str(c.get("name")), re.I) else "Vinyl figure")]),
              ("avail", "Availability", _yt_avail), ("drop", "Drop (month released)", _yt_drop)]


# Accessories: what it is (playmat, display / storage...), the fandom / game it is for, and the brand that makes it.  Plushies and Nee-Doh: their brand / line and kind.
_ACC_FACETS = [("ptype", "Product type", lambda e, c: [str(c.get("category")).strip()] if c.get("category") else []),
               ("fandom", "Fandom / game", lambda e, c: [str(c.get("types")).strip()] if c.get("types") else []),
               ("brand", "Brand", lambda e, c: [str(c.get("setname")).strip()] if c.get("setname") else [])]
_PLUSH_FACETS = [("brand", "Brand / collection", lambda e, c: [str(c.get("setname")).strip()] if c.get("setname") else []),
                 ("line", "Line / series", lambda e, c: [x.strip() for x in str(c.get("types") or "").split(",") if x.strip()][:3]),
                 ("ptype", "Product type", lambda e, c: [str(c.get("category")).strip()] if c.get("category") else [])]


# Beyblade X and Bakugan: the wiki lists carry their facts as tags ("kind:Starter", "attr:Pyrus" ...) written by cardvault/wikitoys.py
def _tagv(prefix):
    return lambda e, c: [str(t)[len(prefix) + 1:] for t in (c.get("tags") or []) if str(t).startswith(prefix + ":") and len(str(t)) > len(prefix) + 1]


_BEY_FACETS = [("kind", "Product type", _tagv("kind")), ("line", "Line (BX / UX / CX ...)", _tagv("line")), ("maker", "Maker (Takara Tomy / Hasbro)", _tagv("maker")),
               ("blade", "Blade", _tagv("blade")), ("year", "Year released", _tagv("year")), ("exclusive", "Sold at / event", _tagv("exclusive")),
               ("variant", "Variant (Metal Coat, clear ...)", _tagv("variant")), ("collab", "Collab / crossover", _tagv("collab"))]
_BAKU_FACETS = [("group", "Bakugan or attachment", _tagv("group")), ("kind", "Kind (trap, battle gear, Mechtogan ...)", _tagv("kind")), ("attr", "Bakugan type (attribute)", _tagv("attr")),
                ("season", "Season", _tagv("season")), ("wave", "Wave / release", _tagv("wave")), ("note", "Re-release / exclusive", _tagv("note"))]


# facet key -> (label, extractor(ext, card) -> [values])
FACETS = {
    "chomps": _SHOP_FACETS, "dumpsterfires": _SHOP_FACETS, "funko": _FUNKO_FACETS, "accessories": _ACC_FACETS, "plushies": _PLUSH_FACETS, "needoh": _PLUSH_FACETS, "consoles": _PLUSH_FACETS, "youtooz": _YT_FACETS, "beyblade": _BEY_FACETS, "bakugan": _BAKU_FACETS,
    "pokemon": _PK_FACETS, "pokemon_jp": _PK_FACETS, "pokemon_tw": _PK_FACETS,
    "yugioh": [("frame", "Card frame / kind", lambda e, c: _ygo_frame(e)), ("monstertype", "Monster type", lambda e, c: _split(e.get("MonsterType"))), ("level", "Link rating", lambda e, c: _num(e.get("LinkRating"))),
               ("atk", "ATK", lambda e, c: _bucket(e.get("Attack"), 1000, 4)), ("def", "DEF", lambda e, c: _bucket(e.get("Defense"), 1000, 4)),
               ("stars", "Level / Rank", lambda e, c: _num(_first(e, "Level", "Rank"))), ("archetype", "Archetype", lambda e, c: _split(e.get("Archetype"), r";")), ("scale", "Pendulum scale", lambda e, c: _num(e.get("Pendulum Scale")))],
    "mtg": [("color", "Color", _mtg_color), ("mv", "Mana value", _mtg_mv), ("power", "Power", _mtg_pt("Power")), ("toughness", "Toughness", _mtg_pt("Toughness")), ("supertype", "Supertype", lambda e, c: _mtg_supertypes(e)), ("subtype", "Subtype (creature type, land type...)", lambda e, c: _mtg_subtypes(e)),
            ("keyword", "Keyword (Flying, Trample, Cycling ...)", lambda e, c: _split(e.get("Keywords"), r";"))],
    "onepiece": [("attribute", "Attribute", lambda e, c: _split(e.get("Attribute"))), ("trait", "Trait / crew", lambda e, c: _split(e.get("Subtypes"))),
                 ("cost", "Cost", lambda e, c: _num(e.get("Cost"))), ("power", "Power", lambda e, c: _bucket(e.get("Power"), 2000, 5)), ("counter", "Counter (thousands)", lambda e, c: _thousands(e.get("Counterplus"))),
                 ("life", "Life", lambda e, c: _num(e.get("Life")))],
    "unionarena": [("affinity", "Affinity", lambda e, c: _split(e.get("Affinities"))), ("energy", "Energy required", lambda e, c: _num(e.get("RequiredEnergy"))),
                   ("trigger", "Trigger", lambda e, c: list(dict.fromkeys(re.findall(r"\[([^\]]{2,20})\]", str(e.get("Trigger") or "")[:60])))[:1]),
                   ("bp", "Battle points", lambda e, c: _bucket(e.get("BattlePointBP"), 2000, 4))],
    "lorcana": [("classification", "Classification", lambda e, c: _split(e.get("Classification"), r"[/,;•]")), ("cost", "Ink cost", lambda e, c: _num(e.get("Cost Ink"))),
                ("inkable", "Inkable", lambda e, c: ["Inkable" if "inkpot" in str(e.get("InkwellIcononCard") or "").lower() or str(e.get("InkwellIcononCard") or "").lower() in ("yes", "true") else "Not inkable"] if e.get("InkwellIcononCard") else []),
                ("lore", "Lore value", lambda e, c: _num(e.get("Lore Value"))), ("strength", "Strength", lambda e, c: _num(e.get("Strength"))), ("willpower", "Willpower", lambda e, c: _num(e.get("Willpower"))),
                ("keyword", "Keyword (Rush, Evasive, Shift ...)", lambda e, c: _split(e.get("Keywords"), r";"))],
    "dbs": [("era", "Era", lambda e, c: _split(e.get("Era"))), ("character", "Character", lambda e, c: _split(e.get("Character"), r"[;,]")),
            ("trait", "Special trait", lambda e, c: _split(e.get("SpecialTrait"), r"[;|/]")), ("cost", "Energy cost", lambda e, c: _num(e.get("EnergyColor Cost"))), ("power", "Power", lambda e, c: _bucket(e.get("Power"), 5000, 6))],
    "gundam": [("trait", "Trait", lambda e, c: _parens(e.get("Trait"))), ("level", "Level", lambda e, c: _num(e.get("Level"))), ("cost", "Cost", lambda e, c: _num(e.get("Cost"))),
               ("ap", "Attack points", lambda e, c: _num(e.get("Attack Points"))), ("hit", "Hit points", lambda e, c: _num(e.get("Hit Points"))), ("zone", "Zone", lambda e, c: _split(e.get("Zone"), r"[;,/]"))],
    "riftbound": [("tag", "Tag", lambda e, c: _split(e.get("Tag"), r"[;,]")), ("energy", "Energy cost", lambda e, c: _num(e.get("Energy Cost"))), ("might", "Might", lambda e, c: _num(e.get("Might")))],
    "palworld": [("subtype", "Subtype", lambda e, c: _split(e.get("CardSubtype"))), ("element", "Element", lambda e, c: _split(e.get("Element"))), ("cost", "Cost", lambda e, c: _num(e.get("Cost"))),
                 ("work", "Work suitability", lambda e, c: _split(e.get("WorkSuitability"), r"[;,/]"))],
    "weissschwarz": [("trait", "Trait", lambda e, c: [x for k in ("Trait", "Trait 2") for x in _split(e.get(k), r"[;,]")]), ("level", "Level", lambda e, c: _num(e.get("Level"))),
                     ("cost", "Cost", lambda e, c: _num(e.get("Cost"))), ("soul", "Soul", lambda e, c: _num(e.get("Soul"))), ("power", "Power", lambda e, c: _bucket(e.get("Power"), 2000, 5))],
}
FACETS["videogames"] = videogamefacets.FACETS                                      # (Video games: cardvault/videogamefacets.py)
FACETS["comics"] = comicsfacets.FACETS                                                     # (Comics: cardvault/comicsfacets.py)
FACETS["hotwheels"] = hotwheelsfacets.FACETS                                           # (Hot Wheels: cardvault/hotwheelsfacets.py)
FACETS.update(tcgfacets.FACETS)                                                       # (the card games added from TCGplayer on 2026-10-29: cardvault/tcgfacets.py)
PRINTING =("printing", "Special printing / art")

# The sidebar of a game only offers what works for THAT game.  Some lists have a 'type' or 'rarity' column that is not a usable filter: their own filters (above) already say it better, or the values are
# one-offs (Funko has 3,000+ 'series' names; a shop toy's 'rarity' is its edition size, "Limited edition of 1,000 (sold out)").
TYPES_COVERED = {"funko", "beyblade", "bakugan", "accessories", "plushies", "needoh", "consoles", "hotwheels", "comics", "videogames"}


VALUE_LIMIT = 400                                                                    # the most values one filter lists (the rest are found by searching)
MANY = 150                                                                           # a column with more different values than this is a NAME column (a franchise, a title), not something to filter or group by


def prune(game, types, rarities):
    """-> (types, rarities) as the sidebar should show them for this game."""
    vals = lambda xs: [str(x if isinstance(x, str) else x[0]) for x in xs]
    types = [t for t in types if len(vals([t])[0]) > 1]                               # (a stray one-letter value is a split-up name, not a type)
    if game in TYPES_COVERED or len(types) > MANY:
        types = []
    rar = vals(rarities)
    from .games import is_misc
    if is_misc(game) and any(re.search(r"(?i)^\s*open edition|limited edition of|\(sold out\)|^\d", r) for r in rar):          # a shop toy's 'rarity' is its edition size ("Limited edition of 250"), not a rarity
        rarities = []
    if len(rarities) > MANY:
        rarities = []
    return types, rarities


def type_names(types):
    """The names in a list of types that may be plain names or [name, label, count] triples."""
    return [t if isinstance(t, str) else t[0] for t in types]


def same_as_categories(categories, types):
    """True when the 'types' column only says the card type again (Magic: Creature, Artifact, Land... in both): a second list with the same words is no use."""
    cats = {str(c).strip().lower() for c in categories if c}
    ts = {str(t).strip().lower() for t in type_names(types) if t}
    return bool(ts) and len(ts & cats) >= 0.6 * len(ts)


def offered_categories(conn, game, scope=None):
    """The 'card type' values a game's sidebar offers as a list of its own (none for a toy list, whose category is its product line, and none for Pokémon, which has its own card kind)."""
    from .games import game_by_id
    if game in NO_PRINTING or game_by_id(game).pokemon:
        return []
    return distinct_values(conn, "category", scope)


def dimension_values(game, rarities, categories, colours):
    """Which of a game's rarity / card-type / colour values are worth GROUPING by (Browse by ...): the same rule as the sidebar, so the two always agree.  -> (rarities, categories, colours)"""
    _t, rars = prune(game, [], list(rarities))
    cats = [] if game in NO_PRINTING or len(categories) > MANY else list(categories)         # toy lists have their own product-type facet; hundreds of 'categories' are names
    cols, _r = prune(game, list(colours), [])
    if same_as_categories(cats, cols):
        cols = []
    return list(rars), cats, list(cols)


# What a game's "sets" are called, and what its things are called: a toy list says "Product lines" and "items", a card game "Sets" and "cards".
_SET_WORDS = {"beyblade": ("Product line", "Product lines"), "bakugan": ("Season", "Seasons"), "funko": ("Fandom", "Fandoms"), "youtooz": ("Franchise", "Franchises"),
              "accessories": ("Brand / game", "Brands & games"), "plushies": ("Collection", "Collections"), "needoh": ("Collection", "Collections"), "consoles": ("Family", "Families"), "hotwheels": ("Line & year", "Lines & years"), "comics": ("Series", "Series"), "videogames": ("Platform", "Platforms"),
              "chomps": ("Collection", "Collections"), "dumpsterfires": ("Collection", "Collections")}


_RARITY_WORDS = {"beyblade": "Release type", "bakugan": "Release type", "funko": "Edition", "needoh": "Range", "comics": "Issue kind", "videogames": "Format"}           # what the 'rarity' column of a toy list really says
SET_FACETS = {"funko": {"fandom"}, "accessories": {"brand"}, "plushies": {"brand"}, "needoh": {"brand"}, "consoles": {"brand"}}               # facets that are only the set's own name again (Browse by already has them as the sets)


def vocab(game_id):
    from .games import is_misc
    one, many = _SET_WORDS.get(game_id, ("Set", "Sets"))
    misc = is_misc(game_id)
    noun = ("issue", "issues") if game_id == "comics" else ("game", "games") if game_id == "videogames" else ("item", "items") if misc else ("card", "cards")
    return {"setLabelOne": one, "setLabel": many, "nounOne": noun[0], "noun": noun[1], "rarityLabel": _RARITY_WORDS.get(game_id, "Rarity")}


def _within(scope):
    """(" AND <condition on the cards table>", args) for a sidebar counted within part of the list (one set, the physical cards only ...), or ("", []) for the whole list.
    `scope` is (condition, args) or None."""
    return (f" AND ({scope[0]})", list(scope[1])) if scope else ("", [])


def card_in(scope):
    """The same, for a table keyed by card_id (card_facets, card_legality)."""
    return (f" AND card_id IN (SELECT id FROM cards WHERE {scope[0]})", list(scope[1])) if scope else ("", [])


def distinct_values(conn, column, scope=None):
    out = set()
    w, a = _within(scope)
    for (v,) in conn.execute(f"SELECT DISTINCT {column} FROM cards WHERE {column} IS NOT NULL AND {column}!=''{w}", a):
        for part in str(v).split(","):
            if part.strip():
                out.add(part.strip())
    return sorted(out)


def pokemon_types(conn, scope=None):
    """The eleven TCG types only (no Trainer / Energy names, no video-game types), each with how many cards have it: [[type, type, count]]."""
    from .db import TCG_TYPES
    tally = {}
    w, a = _within(scope)
    for raw, n in conn.execute(f"SELECT types, COUNT(*) FROM cards WHERE types IS NOT NULL AND types != ''{w} GROUP BY types", a):
        for token in {t.strip() for t in str(raw).replace("/", ",").split(",")}:
            token = "Darkness" if token == "Dark" else token
            if token in TCG_TYPES:
                tally[token] = tally.get(token, 0) + n
    return [[t, t, tally[t]] for t in TCG_TYPES if t in tally]


def basics(conn, game, scope=None):
    """What one game's sidebar needs besides its own filters: the types and rarities worth offering, and whether artists, release dates and prices exist at all.  ONE answer for the Cards page and the
    all-games search panel, so the two always offer the same.  scope: counted within part of the list only (_within)."""
    from .games import game_by_id
    w, a = _within(scope)
    one = lambda sql: bool(conn.execute(sql, a).fetchone())
    types, rarities = prune(game, pokemon_types(conn, scope) if game_by_id(game).pokemon else distinct_values(conn, "types", scope), distinct_values(conn, "rarity", scope))
    if same_as_categories(offered_categories(conn, game, scope), types):
        types = []                                                                   # (Magic's 'type' is its card type again - the same rule the Cards page applies)
    return {"types": types, "rarities": rarities,
            "hasArtist": one(f"SELECT 1 FROM cards WHERE illustrator IS NOT NULL AND illustrator NOT IN ('', 'None', 'N/A'){w} LIMIT 1"),
            "hasDates": one("SELECT 1 FROM sets WHERE release_date IS NOT NULL AND release_date != ''" + (f" AND id IN (SELECT set_id FROM cards WHERE {scope[0]})" if scope else "") + " LIMIT 1"),
            "hasPrices": one(f"SELECT 1 FROM cards WHERE price_usd IS NOT NULL AND price_usd > 0{w} LIMIT 1")}


def card_type_filter(conn, game, scope=None):
    """The 'Card type' filter (the kinds of card with how many of each), for a game that has one of its own (not a toy list, whose category is its product line, and not Pokémon, which has its own card kind)."""
    from .games import game_by_id
    if game in NO_PRINTING or game_by_id(game).pokemon:
        return None
    w, a = _within(scope)
    rows = conn.execute(f"SELECT category, COUNT(*) FROM cards WHERE category IS NOT NULL AND category != ''{w} GROUP BY category ORDER BY COUNT(*) DESC", a).fetchall()
    return {"key": "category", "label": "Card type", "values": [{"v": r[0], "n": r[1]} for r in rows]} if len(rows) > 1 else None


def filters(conn, game, scope=None):
    """Every filter a game's sidebar offers, in the order shown: its card types, then its own (special printing, attribute, trait, cost ...).  The list gets its filter table the first time it is looked at."""
    ensure(conn, game)
    kind = card_type_filter(conn, game, scope)
    from .games import game_by_id
    text = None if game in TYPES_COVERED or game_by_id(game).family == "collectibles" else cardtext.filter_def(conn)       # (a toy list has no card text to search)
    return ([kind] if kind else []) + values(conn, game, scope) + ([text] if text else [])


def facet_defs(game):
    """[(key, label)] of the facets a game offers, in the order they are shown.  Printing is first: it is what collectors of every game ask for."""
    return ([] if game in NO_PRINTING else [PRINTING]) + [(k, label) for k, label, _ in FACETS.get(game, [])] if game in FACETS else []


def facets_of(game, ext, name, rarity, card=None):
    """{facet key: [values]} of one card."""
    out = {} if game in NO_PRINTING else {"printing": printing_of(name, rarity, game)}
    for key, _label, fn in FACETS.get(game, []):
        try:
            vals = [v for v in fn(ext, card or {}) if v]
        except Exception:  # noqa: BLE001 - one odd record never stops the list
            vals = []
        if vals:
            out[key] = list(dict.fromkeys(vals))[:12]
    return out


# ---------------------------------------------------------------------------------------------------------------- tidy the ordinary columns
_ART_CARD = re.compile(r"\bart card\b", re.I)


def fix_columns(conn, game):
    """Where a shop's own data is inconsistent, make the ordinary columns consistent: category = the card's main kind, types = the game's colour / attribute dimension."""
    mtg = game == "mtg" and "color_key" in {r[1] for r in conn.execute("PRAGMA table_info(cards)")}
    rows = conn.execute("SELECT id, name, category, types, raw" + (", color_key" if mtg else ", NULL") + " FROM cards").fetchall()
    upd, ckeys = [], []
    for cid, name, cat, typ, raw, ckey in rows:
        try:
            ext = (json.loads(raw) or {}).get("ext") or {}
        except (TypeError, ValueError):
            ext = {}
        ncat, ntyp = cat, typ
        if game == "yugioh":
            ncat = _ygo_card_type(ext) or cat
            ntyp = ", ".join(_attr(ext.get("Attribute")))
            ncat = ncat or "Other"
        elif game == "unionarena":
            ntyp = re.sub(r"\s*,\s*", " ", str(typ or "")).strip() or typ                        # a series title with commas is ONE series, not several
            ncat = cat or str(ext.get("CardType") or "").strip() or "Other"
        elif game == "mtg":
            if not cat:
                ncat = "Art card" if _ART_CARD.search(name or "") else ("Token" if re.search(r"\btoken\b", (name or "") + " " + str(ext.get("SubType") or ""), re.I) else "Other")
            key = mtg_color_key(ext)                                                              # (the colour sort: a list that has the colours but not the key gets it here, once)
            if key and key != ckey:
                ckeys.append((key, cid))
        elif game in tcgfacets.JOINED_KINDS:
            ncat = cardkinds.joined(cat) or cat
        if (ncat, ntyp) != (cat, typ):
            upd.append((ncat, ntyp, cid))
    if upd:
        conn.executemany("UPDATE cards SET category=?, types=? WHERE id=?", upd)
    if mtg and ckeys:
        conn.executemany("UPDATE cards SET color_key=? WHERE id=?", ckeys)
    return len(upd) + len(ckeys) + cardkinds.tidy(conn, game)                                  # (the cards the shop gave no kind: their own data, or their other printings, say it)


# ---------------------------------------------------------------------------------------------------------------- the table
def _has_table(conn):
    return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='card_facets'").fetchone())


def current(conn):
    if not _has_table(conn):
        return False
    r = conn.execute("SELECT value FROM meta WHERE key='facets_v'").fetchone()
    return bool(r) and str(r[0]) == str(VERSION)


def ensure(conn, game, force=False):
    """Make sure the list has an up-to-date facet table (rebuilds it when missing, out of date, or forced).  -> rows written, or 0 when nothing was needed."""
    from .games import POKEMON_GAMES, game_by_id
    if game not in FACETS or not conn:
        return 0
    if not force and current(conn):
        return 0
    conn.execute("CREATE TABLE IF NOT EXISTS card_facets(card_id TEXT NOT NULL, facet TEXT NOT NULL, value TEXT NOT NULL)")
    conn.execute("CREATE INDEX IF NOT EXISTS card_facets_fv ON card_facets(facet, value)")
    conn.execute("CREATE INDEX IF NOT EXISTS card_facets_c ON card_facets(card_id)")
    fix_columns(conn, game)
    conn.execute("DELETE FROM card_facets")
    batch, n = [], 0
    texts = []
    for cid, name, rarity, raw, cat, setname, types, stage, hp, desc in conn.execute("SELECT c.id, c.name, c.rarity, c.raw, c.category, s.name, c.types, c.stage, c.hp, c.description FROM cards c LEFT JOIN sets s ON s.id=c.set_id").fetchall():
        try:
            doc = json.loads(raw) or {}
        except (TypeError, ValueError):
            doc = {}
        ext = doc.get("ext") or {}
        for facet, vals in facets_of(game, ext, name, rarity, {"name": name, "tags": doc.get("tags") or [], "category": cat, "setname": setname, "types": types, "stage": stage, "hp": hp, "doc": doc}).items():
            for v in vals:
                batch.append((cid, facet, v))
        words = cardtext.row_text(desc, doc if game in POKEMON_GAMES else None)         # (the card text search: cardvault/cardtext.py)
        if words:
            texts.append((cid, words))
        if len(batch) >= 20000:
            conn.executemany("INSERT INTO card_facets VALUES(?,?,?)", batch)
            n += len(batch)
            batch = []
    if batch:
        conn.executemany("INSERT INTO card_facets VALUES(?,?,?)", batch)
        n += len(batch)
    if game not in TYPES_COVERED and game_by_id(game).family != "collectibles":
        cardtext.write(conn, texts)
    conn.execute("INSERT OR REPLACE INTO meta VALUES('facets_v', ?)", (str(VERSION),))
    conn.commit()
    return n


def values(conn, game, scope=None):
    """[{key, label, values:[{v, n}]}] for the open list: what each facet holds and how many cards have each value (most common first)."""
    if not _has_table(conn):
        return []
    out = []
    w, a = card_in(scope)
    for key, label in facet_defs(game):
        vals = [{"v": r[0], "n": r[1]} for r in conn.execute(f"SELECT value, COUNT(*) FROM card_facets WHERE facet=?{w} GROUP BY value ORDER BY COUNT(*) DESC, value LIMIT {VALUE_LIMIT}", (key, *a))]
        if key == "printing":
            vals = [x for x in vals if x["v"] != "Regular"] + [x for x in vals if x["v"] == "Regular"]
        if vals and (len(vals) > 1 or key == "printing"):
            out.append({"key": key, "label": label, "values": vals})
    return out


def card_map(conn):
    """{card id: {facet: [values]}} - read once when the list is opened."""
    if not _has_table(conn):
        return {}
    out = {}
    for cid, f, v in conn.execute("SELECT card_id, facet, value FROM card_facets"):
        out.setdefault(cid, {}).setdefault(f, []).append(v)
    return out
