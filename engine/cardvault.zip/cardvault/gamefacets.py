"""The ways a collector of each card game finds and groups cards - beyond rarity, card type and colour: Yu-Gi-Oh! frames / attributes / monster types, Magic subtypes, One Piece traits and
costs, Lorcana classifications, Union Arena affinities, Gundam / Weiss Schwarz traits and levels... and, for every game, the SPECIAL PRINTING of a card (alternate art, parallel, manga, borderless,
showcase, foil finishes, stamped / signature, event prizes...).

Everything is worked out from what the card list already holds (the shop's own fields in `raw`, the card's name) and kept in one small table of the list itself:

    card_facets(card_id, facet, value)         one row per value (a card can have several)

so searching, grouping and the master-set tools all read the same thing.  The table is rebuilt whenever the card list is fetched (and once, on the spot, for a list that was downloaded before this
existed).  `fix_columns` also tidies the ordinary columns where a shop's data was inconsistent (Yu-Gi-Oh! had its card type scattered over 111 spellings and no category at all)."""
import json
import re

VERSION = 3

# ---------------------------------------------------------------------------------------------------------------- special printings (all card games)
_PRINT_RULES = [
    ("Alternate art", r"\balt(?:ernate)?\.? art\b|\bspecial art\b|\bjp alternate art\b"),
    ("Parallel", r"\bparallel\b"),
    ("Manga art", r"\bmanga\b"),
    ("Full art", r"\bfull art\b"),
    ("Extended art", r"\bextended art\b"),
    ("Borderless", r"\bborderless\b"),
    ("Showcase", r"\bshowcase\b"),
    ("Retro frame", r"\bretro\b"),
    ("Special foil", r"\b(?:surge|rainbow|ripple|galaxy|halo|etched|textured|pirate|jolly roger|silver|gold|box topper|first-place|confetti|neon ink|step-and-compleat|alternate)\s+foil\b|\bfoil etched\b|\bstarfoil\b|\bshatterfoil\b|\bmosaic\b"),
    ("Stamped / signature / numbered", r"gold[- ]stamp|silver[- ]stamp|winner stamp|\bsignature\b|serial numbered|autograph"),
    ("Event / prize / promo", r"\b(?:winner|finalist|participant|participation|judge|store championship|regionals?|release event|top \d+|prize|champion(?:ship)?|celebration pack|player bundle|prerelease|launch|tournament|top players|expo|cruise promo|card game fest|worlds|store)\b"),
    ("Reprint", r"\breprint\b"),
    ("Oversized", r"\boversized?\b"),
    ("Other language", r"\b(?:spanish|italian|french|german|portuguese|japanese|korean|russian|chinese|jp exclusive)\b"),
    ("Star rarity", r"(?:^|\|\s*)[A-Z]{1,3}\*+\s*(?:\||$)"),
]
_PRINT_RX = [(label, re.compile(rx, re.I)) for label, rx in _PRINT_RULES]
_TAIL = re.compile(r"\(([^()]{1,60})\)|\[([^\[\]]{1,60})\]")


def printing_of(name, rarity="", game=""):
    """The special printings a card is, from the brackets in its name (and its rarity): ['Alternate art', 'Special foil'] - or ['Regular'] when it is the ordinary card."""
    parts = [(a or b) for a, b in _TAIL.findall(name or "")]
    text = " | ".join(parts)
    out = []
    for label, rx in _PRINT_RX:
        if rx.search(text) or (label == "Star rarity" and re.search(r"\d-Star\b", rarity or "")):
            out.append(label)
    if game == "yugioh":
        out = [x for x in out if x not in ("Special foil",)]           # a Yu-Gi-Oh! finish is its rarity (Starlight, Starfoil, Mosaic...) - already filterable
    return out or ["Regular"]


# ---------------------------------------------------------------------------------------------------------------- per-game facets
def _split(v, seps=r"[/,;]"):
    return [p.strip() for p in re.split(seps, str(v or "")) if p and p.strip()]


def _thousands(v):
    m = re.search(r"\d+", str(v or ""))
    if not m:
        return []
    n = int(m.group())
    n = n // 1000 if n >= 1000 else n
    return [str(n) if n < 10 else "10+"]


def _num(v):
    m = re.search(r"\d+", str(v or ""))
    if not m:
        return []
    n = int(m.group())
    return [str(n) if n < 10 else "10+"]


def _parens(v):
    """'(Earth Federation) (White Base Team)' -> ['Earth Federation', 'White Base Team']"""
    found = re.findall(r"\(([^()]+)\)", str(v or ""))
    return [x.strip() for x in found] or _split(v, r"[;,]")


def _attr(v):
    out = [x.upper() for x in _split(v)]
    return [x for x in out if x not in ("SPELL", "TRAP", "SKILL")]


def _first(ext, *keys):
    for k in keys:
        if ext.get(k) not in (None, ""):
            return ext[k]
    return None


_YGO_FRAMES = ["Normal", "Effect", "Fusion", "Synchro", "Xyz", "Link", "Pendulum", "Ritual", "Tuner", "Flip", "Spirit", "Union", "Gemini", "Toon", "Token", "Skill", "Special Summon"]
_YGO_ST = ["Normal", "Quick-Play", "Continuous", "Field", "Equip", "Ritual", "Counter"]


def _ygo_card_type(ext):
    t = str(ext.get("Card Type") or ext.get("CardType") or "")
    if "Spell" in t:
        return "Spell"
    if "Trap" in t:
        return "Trap"
    if "Skill" in t:
        return "Skill"
    if t:
        return "Monster"
    return ""


def _ygo_frame(ext):
    t = str(ext.get("Card Type") or ext.get("CardType") or "")
    kind = _ygo_card_type(ext)
    if kind in ("Spell", "Trap"):
        return [x + " " + kind for x in _YGO_ST if x.lower() in t.lower()] or [kind]
    return [x for x in _YGO_FRAMES if re.search(r"\b" + re.escape(x) + r"\b", t)] or ([t] if t else [])


_MTG_SUPER = ["Legendary", "Basic", "Snow", "World", "Ongoing"]


def _mtg_line(ext):
    return str(ext.get("SubType") or "").replace("\xa0", " ")


_DASH = re.compile("\\s+[\u2014\u2013\ufffd-]\\s+")                   # the dash of a type line (a damaged copy of it shows as a replacement character)


def _mtg_faces(ext):
    """[(type words before the dash, subtype words after it)] for each face of the card ('A - x // B - y' is a two-faced card)."""
    out = []
    for face in _mtg_line(ext).split("//"):
        parts = _DASH.split(face.strip(), maxsplit=1)
        out.append((parts[0], parts[1] if len(parts) > 1 else ""))
    return out


def _mtg_subtypes(ext):
    return list(dict.fromkeys(w for _h, sub in _mtg_faces(ext) for w in sub.split() if w and w[0].isalpha()))[:8]


def _mtg_supertypes(ext):
    heads = " ".join(h for h, _s in _mtg_faces(ext))
    return [s for s in _MTG_SUPER if re.search(r"\b" + s + r"\b", heads)]


# ---------------------------------------------------------------------------------------------------------------- the designer-toy shops (Abominable Toys, 100% Soft)
NO_PRINTING = {"chomps", "dumpsterfires", "funko", "accessories", "plushies", "needoh", "youtooz"}                 # 'special printing' is a card-game idea; toys have their own filters below


def _ptype(e, c):
    """What kind of product it is, from the shop's own words: Plush / Squishy & ceramic / Blind box / Bust / Resin figure / Vinyl figure / Misc."""
    text = " ".join([str(c.get("name") or ""), str(e.get("Shop name") or ""), " ".join(c.get("tags") or []), str(c.get("category") or "")]).lower()
    for words, label in ((("plush",), "Plush"), (("squishy", "ceramic"), "Squishy & ceramic"), (("blind", "mystery"), "Blind box / bag"), (("bust",), "Bust"), (("resin",), "Resin figure"),
                         (("vinyl", "figure", "chomp", "toy"), "Vinyl figure")):
        if any(w in text for w in words):
            return [label]
    return ["Misc"]


_SHOP_FACETS = [("ptype", "Product type", _ptype),
                ("avail", "In stock / sold out", lambda e, c: (["Sold out" if "sold out" in str(e.get("Availability")).lower() else "In stock"] if e.get("Availability") else [])),
                ("edition", "Edition", lambda e, c: (["Open edition" if "open" in str(e.get("Edition", "")).lower() else "Limited edition"] if e.get("Edition") else [])),
                ("exclusive", "Exclusive to", lambda e, c: [x.strip() for x in str(e.get("Exclusive to", "")).split(",") if x.strip() and x.strip().lower() != "not exclusive"]),
                ("designer", "Designer / artist", lambda e, c: ([str(e["Designer"]).strip()] if e.get("Designer") else []))]


# Funko: what KIND of product it is (Pop! Vinyl, Wacky Wobbler, Pocket Pop, Dorbz, Pop! Pez ...) and, separately, its CATEGORY / fandom (Animation, Television, 8-Bit, Ad Icons, Movies ...)
_FUNKO_FACETS = [("ptype", "Product type", lambda e, c: [str(c.get("category")).strip()] if c.get("category") else []),
                 ("fandom", "Category (fandom)", lambda e, c: [str(c.get("setname")).strip()] if c.get("setname") else []),
                 ("tag", "Exclusive / special", lambda e, c: [t for t in (c.get("tags") or []) if t and t != c.get("category") and re.search(r"exclusive|chase|glow|flocked|metallic|diamond|con\b|convention|limited", t, re.I)][:4])]


_MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]


def _yt_avail(e, c):
    tags = {str(t).lower() for t in (c.get("tags") or [])}
    for key, label in (("coming_soon", "Coming soon"), ("backorder", "Backorder"), ("in_stock", "In stock"), ("past_drop", "Past drop")):
        if key in tags:
            return [label]
    return ["Sold out" if "sold out" in str(e.get("Availability")).lower() else "In stock"] if e.get("Availability") else []


def _yt_drop(e, c):
    for t in c.get("tags") or []:
        m = re.fullmatch(r"([a-z]{3})_(\d{4})_drop", str(t).lower())
        if m and m.group(1) in _MONTHS:
            return [f"{m.group(2)} {m.group(1).capitalize()}"]
    return []


_YT_FACETS = [("ptype", "Product type", lambda e, c: [("Plush" if "plush" in str(c.get("name")).lower() else "Mini / blind box" if re.search(r"mini|blind", str(c.get("name")), re.I) else "Vinyl figure")]),
              ("avail", "Availability", _yt_avail), ("drop", "Drop (month released)", _yt_drop)]


# Accessories: what it is (playmat, display / storage...), the fandom / game it is for, and the brand that makes it.  Plushies and Nee-Doh: their brand / line and kind.
_ACC_FACETS = [("ptype", "Product type", lambda e, c: [str(c.get("category")).strip()] if c.get("category") else []),
               ("fandom", "Fandom / game", lambda e, c: [str(c.get("types")).strip()] if c.get("types") else []),
               ("brand", "Brand", lambda e, c: [str(c.get("setname")).strip()] if c.get("setname") else [])]
_PLUSH_FACETS = [("brand", "Brand / collection", lambda e, c: [str(c.get("setname")).strip()] if c.get("setname") else []),
                 ("line", "Line / series", lambda e, c: [x.strip() for x in str(c.get("types") or "").split(",") if x.strip()][:3]),
                 ("ptype", "Product type", lambda e, c: [str(c.get("category")).strip()] if c.get("category") else [])]


# facet key -> (label, extractor(ext, card) -> [values])
FACETS = {
    "chomps": _SHOP_FACETS, "dumpsterfires": _SHOP_FACETS, "funko": _FUNKO_FACETS, "accessories": _ACC_FACETS, "plushies": _PLUSH_FACETS, "needoh": _PLUSH_FACETS, "youtooz": _YT_FACETS,
    "yugioh": [("frame", "Card frame / kind", lambda e, c: _ygo_frame(e)), ("monstertype", "Monster type", lambda e, c: _split(e.get("MonsterType"))), ("level", "Link rating", lambda e, c: _num(e.get("LinkRating")))],
    "mtg": [("supertype", "Supertype", lambda e, c: _mtg_supertypes(e)), ("subtype", "Subtype (creature type, land type...)", lambda e, c: _mtg_subtypes(e))],
    "onepiece": [("attribute", "Attribute", lambda e, c: _split(e.get("Attribute"))), ("trait", "Trait / crew", lambda e, c: _split(e.get("Subtypes"))),
                 ("cost", "Cost", lambda e, c: _num(e.get("Cost"))), ("counter", "Counter (thousands)", lambda e, c: _thousands(e.get("Counterplus"))), ("life", "Life", lambda e, c: _num(e.get("Life")))],
    "unionarena": [("affinity", "Affinity", lambda e, c: _split(e.get("Affinities"))), ("energy", "Energy required", lambda e, c: _num(e.get("RequiredEnergy"))),
                   ("trigger", "Trigger", lambda e, c: list(dict.fromkeys(re.findall(r"\[([^\]]{2,20})\]", str(e.get("Trigger") or "")[:60])))[:1])],
    "lorcana": [("classification", "Classification", lambda e, c: _split(e.get("Classification"), r"[/,;•]")), ("cost", "Ink cost", lambda e, c: _num(e.get("Cost Ink"))),
                ("inkable", "Inkable", lambda e, c: ["Inkable" if "inkpot" in str(e.get("InkwellIcononCard") or "").lower() or str(e.get("InkwellIcononCard") or "").lower() in ("yes", "true") else "Not inkable"] if e.get("InkwellIcononCard") else []),
                ("lore", "Lore value", lambda e, c: _num(e.get("Lore Value")))],
    "dbs": [("era", "Era", lambda e, c: _split(e.get("Era"))), ("character", "Character", lambda e, c: _split(e.get("Character"), r"[;,]")),
            ("trait", "Special trait", lambda e, c: _split(e.get("SpecialTrait"), r"[;|/]")), ("cost", "Energy cost", lambda e, c: _num(e.get("EnergyColor Cost")))],
    "gundam": [("trait", "Trait", lambda e, c: _parens(e.get("Trait"))), ("level", "Level", lambda e, c: _num(e.get("Level"))), ("cost", "Cost", lambda e, c: _num(e.get("Cost")))],
    "riftbound": [("tag", "Tag", lambda e, c: _split(e.get("Tag"), r"[;,]")), ("energy", "Energy cost", lambda e, c: _num(e.get("Energy Cost"))), ("might", "Might", lambda e, c: _num(e.get("Might")))],
    "palworld": [("subtype", "Subtype", lambda e, c: _split(e.get("CardSubtype"))), ("element", "Element", lambda e, c: _split(e.get("Element"))), ("cost", "Cost", lambda e, c: _num(e.get("Cost")))],
    "weissschwarz": [("trait", "Trait", lambda e, c: [x for k in ("Trait", "Trait 2") for x in _split(e.get(k), r"[;,]")]), ("level", "Level", lambda e, c: _num(e.get("Level"))),
                     ("cost", "Cost", lambda e, c: _num(e.get("Cost"))), ("soul", "Soul", lambda e, c: _num(e.get("Soul")))],
}
PRINTING = ("printing", "Special printing / art")


def facet_defs(game):
    """[(key, label)] of the facets a game offers, in the order they are shown.  Printing is first: it is what collectors of every game ask for."""
    return ([] if game in NO_PRINTING else [PRINTING]) + [(k, label) for k, label, _ in FACETS.get(game, [])] if game in FACETS else []


def facets_of(game, ext, name, rarity, card=None):
    """{facet key: [values]} of one card."""
    out = {} if game in NO_PRINTING else {"printing": printing_of(name, rarity, game)}
    for key, _label, fn in FACETS.get(game, []):
        try:
            vals = [v for v in fn(ext, card or {}) if v]
        except Exception:  # noqa: BLE001 - one odd record never stops the list
            vals = []
        if vals:
            out[key] = list(dict.fromkeys(vals))[:12]
    return out


# ---------------------------------------------------------------------------------------------------------------- tidy the ordinary columns
_ART_CARD = re.compile(r"\bart card\b", re.I)


def fix_columns(conn, game):
    """Where a shop's own data is inconsistent, make the ordinary columns consistent: category = the card's main kind, types = the game's colour / attribute dimension."""
    rows = conn.execute("SELECT id, name, category, types, raw FROM cards").fetchall()
    upd = []
    for cid, name, cat, typ, raw in rows:
        try:
            ext = (json.loads(raw) or {}).get("ext") or {}
        except (TypeError, ValueError):
            ext = {}
        ncat, ntyp = cat, typ
        if game == "yugioh":
            ncat = _ygo_card_type(ext) or cat
            ntyp = ", ".join(_attr(ext.get("Attribute")))
            ncat = ncat or "Other"
        elif game == "unionarena":
            ntyp = re.sub(r"\s*,\s*", " ", str(typ or "")).strip() or typ                        # a series title with commas is ONE series, not several
            ncat = cat or str(ext.get("CardType") or "").strip() or "Other"
        elif game == "mtg":
            if not cat:
                ncat = "Art card" if _ART_CARD.search(name or "") else ("Token" if re.search(r"\btoken\b", (name or "") + " " + str(ext.get("SubType") or ""), re.I) else "Other")
        if (ncat, ntyp) != (cat, typ):
            upd.append((ncat, ntyp, cid))
    if upd:
        conn.executemany("UPDATE cards SET category=?, types=? WHERE id=?", upd)
    return len(upd)


# ---------------------------------------------------------------------------------------------------------------- the table
def _has_table(conn):
    return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='card_facets'").fetchone())


def current(conn):
    if not _has_table(conn):
        return False
    r = conn.execute("SELECT value FROM meta WHERE key='facets_v'").fetchone()
    return bool(r) and str(r[0]) == str(VERSION)


def ensure(conn, game, force=False):
    """Make sure the list has an up-to-date facet table (rebuilds it when missing, out of date, or forced).  -> rows written, or 0 when nothing was needed."""
    if game not in FACETS or not conn:
        return 0
    if not force and current(conn):
        return 0
    conn.execute("CREATE TABLE IF NOT EXISTS card_facets(card_id TEXT NOT NULL, facet TEXT NOT NULL, value TEXT NOT NULL)")
    conn.execute("CREATE INDEX IF NOT EXISTS card_facets_fv ON card_facets(facet, value)")
    conn.execute("CREATE INDEX IF NOT EXISTS card_facets_c ON card_facets(card_id)")
    fix_columns(conn, game)
    conn.execute("DELETE FROM card_facets")
    batch, n = [], 0
    for cid, name, rarity, raw, cat, setname, types in conn.execute("SELECT c.id, c.name, c.rarity, c.raw, c.category, s.name, c.types FROM cards c LEFT JOIN sets s ON s.id=c.set_id").fetchall():
        try:
            doc = json.loads(raw) or {}
        except (TypeError, ValueError):
            doc = {}
        ext = doc.get("ext") or {}
        for facet, vals in facets_of(game, ext, name, rarity, {"name": name, "tags": doc.get("tags") or [], "category": cat, "setname": setname, "types": types}).items():
            for v in vals:
                batch.append((cid, facet, v))
        if len(batch) >= 20000:
            conn.executemany("INSERT INTO card_facets VALUES(?,?,?)", batch)
            n += len(batch)
            batch = []
    if batch:
        conn.executemany("INSERT INTO card_facets VALUES(?,?,?)", batch)
        n += len(batch)
    conn.execute("INSERT OR REPLACE INTO meta VALUES('facets_v', ?)", (str(VERSION),))
    conn.commit()
    return n


def values(conn, game):
    """[{key, label, values:[{v, n}]}] for the open list: what each facet holds and how many cards have each value (most common first)."""
    if not _has_table(conn):
        return []
    out = []
    for key, label in facet_defs(game):
        vals = [{"v": r[0], "n": r[1]} for r in conn.execute("SELECT value, COUNT(*) FROM card_facets WHERE facet=? GROUP BY value ORDER BY COUNT(*) DESC, value LIMIT 400", (key,))]
        if key == "printing":
            vals = [x for x in vals if x["v"] != "Regular"] + [x for x in vals if x["v"] == "Regular"]
        if vals and (len(vals) > 1 or key == "printing"):
            out.append({"key": key, "label": label, "values": vals})
    return out


def card_map(conn):
    """{card id: {facet: [values]}} - read once when the list is opened."""
    if not _has_table(conn):
        return {}
    out = {}
    for cid, f, v in conn.execute("SELECT card_id, facet, value FROM card_facets"):
        out.setdefault(cid, {}).setdefault(f, []).append(v)
    return out
