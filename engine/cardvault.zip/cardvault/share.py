"""Share pages.

build_payload() turns a saved share definition (what to share + what is permitted) into a plain JSON document that contains
ONLY the permitted information - fields that are not permitted never leave this function.  The same payload is
  * written into a standalone HTML page today (export_html), and
  * what the future online service will store and serve behind the share token (see docs/SHARE_API.md).
"""
import base64
import io
import json
import os

from . import checklists
from .db import image_file, now_iso

SCHEMA = 1
DEFAULT_PERMS = {
    "owner_name": "",            # shown as the page owner; empty = anonymous
    "show_owned": True,          # which cards I have
    "show_missing": True,        # which cards I'm missing
    "show_progress": True,       # owned / total / percent
    "show_quantities": False,    # how many copies
    "show_conditions": False,    # variant / condition / grading
    "show_prices": False,        # per-card market prices
    "show_total_value": False,   # total market value of what is shown
    "show_purchase_prices": False,
    "show_notes": False,
    "show_images": True,
}
KINDS = {
    "collection": "My whole collection (owned cards)",
    "set": "A master set (one set's progress)",
    "checklist": "One of my checklists",
    "wishlist": "My wishlist",
    "group": "A card group (e.g. all Art cards)",
}


def merged_perms(perms):
    p = dict(DEFAULT_PERMS)
    p.update(perms or {})
    return p


def _thumb_data_uri(gdir, card_id, set_id, size=(120, 168)):
    from PIL import Image
    for q in ("low", "high"):
        p = image_file(gdir, q, card_id, set_id)
        if os.path.exists(p):
            try:
                with Image.open(p) as im:
                    im = im.convert("RGB")
                    im.thumbnail(size)
                    buf = io.BytesIO()
                    im.save(buf, "JPEG", quality=70)
                return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
            except Exception:  # noqa: BLE001
                return None
    return None


def build_payload(vault, share, with_images=True):
    """share: a row/dict with title, kind, scope (dict or JSON), perms (dict or JSON)."""
    scope = share["scope"] if isinstance(share["scope"], dict) else json.loads(share["scope"] or "{}")
    perms = merged_perms(share["perms"] if isinstance(share["perms"], dict) else json.loads(share["perms"] or "{}"))
    kind = share["kind"]
    owned_map = vault.owned_map()
    lots_by_card = {}
    if perms["show_conditions"] or perms["show_purchase_prices"] or perms["show_notes"]:
        for cid in owned_map:
            lots_by_card[cid] = vault.lots_for(cid)

    tiles, progress = [], None
    if kind == "set":
        progress = checklists.progress_for_set(vault, scope["set_id"], bool(scope.get("per_variant")))
    elif kind == "checklist":
        progress = checklists.progress_for_checklist(vault, vault.checklist(scope["checklist_id"]))
    elif kind == "collection":
        ids = [c["id"] for c in vault.card_index() if owned_map.get(c["id"], 0) > 0]
        progress = checklists.progress_for_cards(vault, ids)
    elif kind == "group":
        progress = checklists.progress_for_cards(vault, vault.group_ids(scope["group_id"]))
    elif kind == "wishlist":
        ids = [c["id"] for c in vault.card_index() if c["id"] in vault.wishlist_ids()]
        progress = checklists.progress_for_cards(vault, ids)
        for t in progress.tiles:
            t.owned = owned_map.get(t.card_id, 0) > 0
    else:
        raise ValueError("unknown share kind")

    items, value = [], 0.0
    for t in progress.tiles:
        if t.owned and not perms["show_owned"]:
            continue
        if not t.owned and not perms["show_missing"]:
            continue
        c = vault.card_light(t.card_id)
        if not c:
            continue
        it = {"id": t.card_id, "name": c["name"], "set": c["set_name"], "number": c["local_id"], "official": c.get("official"),
              "rarity": c.get("rarity") or "", "label": t.label if t.candidates else "",
              "variant": t.variant or "" if perms["show_conditions"] else ""}
        if perms["show_owned"] or perms["show_missing"]:
            it["owned"] = bool(t.owned)
        if perms["show_quantities"] and t.owned:
            it["qty"] = t.qty
        if perms["show_conditions"] and t.owned:
            lots = lots_by_card.get(t.card_id, [])
            it["copies"] = [{"variant": l["variant"], "condition": l["condition"] if not l["graded"] else "",
                             "grade": f"{l['grade_company']} {l['grade']}".strip() if l["graded"] else "", "qty": l["qty"] if perms["show_quantities"] else None}
                            for l in lots]
        if perms["show_purchase_prices"] and t.owned:
            it["paid"] = [l["purchase_price"] for l in lots_by_card.get(t.card_id, []) if l["purchase_price"] is not None]
        if perms["show_notes"] and t.owned:
            it["notes"] = [l["notes"] for l in lots_by_card.get(t.card_id, []) if l["notes"]]
        if perms["show_prices"] and c.get("price_usd") is not None:
            it["price"] = c["price_usd"]
        if perms["show_total_value"] and t.owned and c.get("price_usd"):
            value += c["price_usd"] * max(t.qty, 1)
        if with_images and perms["show_images"]:
            it["img"] = _thumb_data_uri(vault.gdir, t.card_id, c["set_id"])
        items.append(it)

    payload = {
        "schema": SCHEMA, "generated": now_iso(), "game": vault.game, "kind": kind, "title": share["title"],
        "owner": perms["owner_name"] or None, "permissions": {k: v for k, v in perms.items() if k.startswith("show_")},
        "items": items,
    }
    if perms["show_progress"]:
        payload["progress"] = {"owned": progress.owned, "total": progress.total, "percent": round(progress.pct, 1)}
    if perms["show_total_value"]:
        payload["total_value_usd"] = round(value, 2)
    return payload


HTML_TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--bg:#f4f6fb;--card:#fff;--ink:#1c2333;--mute:#667085;--line:#e1e6f0;--accent:#2f6df6;--ok:#1e9e5a;--miss:#c9ced8}
@media (prefers-color-scheme:dark){:root{--bg:#10141f;--card:#1a2030;--ink:#e8ecf5;--mute:#98a2b3;--line:#2a3247;--accent:#6b9bff;--ok:#38c07a;--miss:#3a425a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,Segoe UI,sans-serif}
header{padding:28px 20px 8px;max-width:1200px;margin:auto}h1{margin:0 0 4px;font-size:26px}.sub{color:var(--mute)}
.bar{height:12px;border-radius:8px;background:var(--line);overflow:hidden;margin:14px 0 6px}.bar i{display:block;height:100%;background:var(--ok)}
.stats{display:flex;gap:18px;flex-wrap:wrap;margin-top:8px}.stats b{font-size:20px}
.tools{max-width:1200px;margin:10px auto;padding:0 20px;display:flex;gap:8px;flex-wrap:wrap}
input,button{font:inherit;padding:8px 12px;border-radius:10px;border:1px solid var(--line);background:var(--card);color:var(--ink)}
button.on{background:var(--accent);color:#fff;border-color:var(--accent)}
main{max-width:1200px;margin:auto;padding:8px 20px 60px;display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}
.t{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:8px;text-align:center;position:relative}
.t img{width:100%;aspect-ratio:5/7;object-fit:contain;border-radius:8px;background:var(--line)}
.t.miss img{opacity:.3;filter:grayscale(1)}.t .n{font-weight:600;margin-top:6px;font-size:13px}.t .m{color:var(--mute);font-size:12px}
.ph{aspect-ratio:5/7;border-radius:8px;background:var(--line);display:flex;align-items:center;justify-content:center;color:var(--mute);font-size:12px;padding:6px}
.badge{position:absolute;top:12px;left:12px;background:var(--ok);color:#fff;border-radius:999px;font-size:12px;padding:1px 8px;font-weight:700}
.t.miss .badge{background:var(--miss);color:var(--ink)}
footer{text-align:center;color:var(--mute);font-size:12px;padding:20px}
</style></head><body>
<header><h1 id="h"></h1><div class="sub" id="sub"></div><div id="prog"></div></header>
<div class="tools"><input id="q" placeholder="Search..." style="flex:1;min-width:180px">
<button data-f="all" class="on">All</button><button data-f="owned">Owned</button><button data-f="missing">Missing</button></div>
<main id="g"></main>
<footer>Made with Pokemon Card Vault - snapshot of __DATE__</footer>
<script>
const D=__DATA__;
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
$('#h').textContent=D.title;$('#sub').textContent=(D.owner?D.owner+' - ':'')+'Snapshot '+D.generated.slice(0,10);
if(D.progress){$('#prog').innerHTML='<div class="bar"><i style="width:'+D.progress.percent+'%"></i></div><div class="stats"><span><b>'+D.progress.percent+'%</b> complete</span><span><b>'+D.progress.owned+'</b> / '+D.progress.total+' owned</span>'+(D.total_value_usd!=null?'<span><b>$'+D.total_value_usd.toLocaleString()+'</b> est. value</span>':'')+'</div>'}
else if(D.total_value_usd!=null){$('#prog').innerHTML='<div class="stats"><span><b>$'+D.total_value_usd.toLocaleString()+'</b> est. value</span></div>'}
let f='all';
function draw(){const q=$('#q').value.toLowerCase();let h='';
for(const i of D.items){const o=i.owned!==false;if(f==='owned'&&!o||f==='missing'&&o)continue;
const txt=(i.name+' '+i.set+' '+i.rarity+' '+i.label).toLowerCase();if(q&&!txt.includes(q))continue;
const num='#'+i.number+(i.official?'/'+i.official:'');
h+='<div class="t '+(o?'':'miss')+'">'+(i.owned!==undefined?'<span class="badge">'+(o?(i.qty>1?'x'+i.qty:'\\u2713'):'\\u2717')+'</span>':'')+
(i.img?'<img loading="lazy" src="'+i.img+'">':'<div class="ph">'+esc(i.name)+'</div>')+
'<div class="n">'+esc(i.label||i.name)+'</div><div class="m">'+esc(i.set)+' '+num+'</div>'+(i.rarity?'<div class="m">'+esc(i.rarity)+'</div>':'')+
(i.variant?'<div class="m">'+esc(i.variant)+'</div>':'')+(i.price!=null?'<div class="m">$'+i.price.toFixed(2)+'</div>':'')+
(i.copies?'<div class="m">'+i.copies.map(c=>esc([c.variant,c.condition,c.grade].filter(Boolean).join(' '))).join('; ')+'</div>':'')+'</div>'}
$('#g').innerHTML=h||'<p class="sub">Nothing to show.</p>'}
document.querySelectorAll('button[data-f]').forEach(b=>b.onclick=()=>{f=b.dataset.f;document.querySelectorAll('button[data-f]').forEach(x=>x.classList.toggle('on',x===b));draw()});
$('#q').oninput=draw;draw();
</script></body></html>"""


def export_html(path, payload):
    data = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    title = payload["title"].replace("<", "&lt;")
    html = HTML_TEMPLATE.replace("__TITLE__", title).replace("__DATA__", data).replace("__DATE__", payload["generated"][:10])
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return os.path.getsize(path)
