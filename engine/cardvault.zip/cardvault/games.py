"""Game catalogue + download providers.

Each card game is a Game entry.  A game that is `available` has a provider that downloads its sets, cards, pictures and prices into
games/<id>/ in the data folder, filling the generic `sets` / `cards` tables (see db.CARDS_SCHEMA).  The rest of the app (browse,
collection, checklists, value, sharing, downloads) works for any game that fills those tables.

Providers
  * PokemonProvider   - TCGdex (api.tcgdex.net): English cards, pictures, prices, Pokédex numbers, illustrators
  * TcgCsvProvider    - tcgcsv.com (a daily dump of TCGplayer's catalogue): One Piece Card Game, Union Arena - and any other TCGplayer
                        category later (Magic, Yu-Gi-Oh!, Lorcana...) with one more registry line.
"""
from dataclasses import dataclass, field

from . import sync


@dataclass
class Game:
    id: str
    name: str
    source: str
    available: bool = False
    note: str = ""
    pokemon: bool = False           # Pokédex numbers, Art cards, mechanics, illustrators... only make sense for Pokémon
    type_label: str = "Type"        # what the 'types' column is called for this game (Type / Color / Series)
    rarity_order: tuple = ()        # rarity codes from the easiest to the hardest pull (for the rarity sections of a set)
    image_note: str = "small pictures about 20 KB each"
    family: str = ""               # games that belong together in the app (the Pokémon spots: English / TCG Pocket / Japanese)


GAMES = [
    Game("pokemon", "Pokémon TCG (English)", "TCGdex (api.tcgdex.net) - free community database", True,
         "English cards, pictures and market prices. Includes the TCG Pocket sets, which have their own spot under Cards.", pokemon=True, family="pokemon"),
    Game("pokemon_jp", "Pokémon TCG (Japanese)", "TCGdex (api.tcgdex.net, Japanese catalogue)", True,
         "Japanese cards and pictures (no prices).", pokemon=True, family="pokemon"),
    Game("onepiece", "One Piece Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (boosters, extra boosters, starter decks, promos) with pictures and market prices.",
         type_label="Color", rarity_order=("C", "UC", "R", "SR", "SEC", "L", "SP CARD", "SP", "TR", "P", "DON!!", "Promo")),
    Game("unionarena", "Union Arena", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, starter deck, advanced deck and promo with pictures and market prices.",
         type_label="Series", rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Special", "Ultra Rare", "Promo", "Action Point")),
    Game("mtg", "Magic: The Gathering", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, Commander deck, promo and token with pictures and market prices (a big download).", type_label="Type",
         rarity_order=("C", "U", "R", "M", "S", "T", "P", "L")),
    Game("yugioh", "Yu-Gi-Oh!", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (booster packs, structure decks, tins, promos) with pictures, 1st Edition / Unlimited printings and market prices.",
         type_label="Card type", rarity_order=("Common", "Short Print", "Rare", "Super Rare", "Ultra Rare", "Ultimate Rare", "Secret Rare", "Ghost Rare", "Starlight Rare", "Collector's Rare", "Prismatic Secret Rare", "Quarter Century Secret Rare", "Promo")),
    Game("dbs", "Dragon Ball Super Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every Fusion World / Masters booster, starter deck and promo with pictures and market prices.",
         type_label="Color", rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Special Rare", "Secret Rare", "Ultra Rare", "Starter Rare", "Leader Rare", "Promo")),
    Game("lorcana", "Disney Lorcana", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (booster sets, starter decks, promos) with pictures and market prices.", type_label="Ink",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Legendary", "Enchanted", "Epic", "Iconic", "Promo")),
    Game("gundam", "Gundam Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, starter deck and promo with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Legend Rare", "Promo")),
    Game("riftbound", "Riftbound (League of Legends TCG)", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, bundle and promo with pictures and market prices.", type_label="Domain",
         rarity_order=("Common", "Uncommon", "Rare", "Epic", "Overnumbered", "Showcase", "Promo")),
    Game("palworld", "Palworld Official Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster and starter deck with pictures and market prices.", type_label="Type"),
    Game("swu", "Star Wars: Unlimited", "planned: TCGplayer", False, "Coming later."),
]


def game_by_id(game_id):
    return next((g for g in GAMES if g.id == game_id), GAMES[0])


class GameProvider:
    """Interface every game provider implements.  All methods take the game's folder (games/<id>) and a cancel Event."""
    game_id = ""
    avg_bytes = {"low": 22_000, "high": 85_000}

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        raise NotImplementedError

    def fetch_details(self, gdir, cancel, progress, refresh_all=False, only_ids=None):
        raise NotImplementedError

    def fetch_images(self, gdir, quality, cancel, progress):
        raise NotImplementedError

    def estimate(self, gdir, quality):
        raise NotImplementedError

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        raise NotImplementedError


class PokemonProvider(GameProvider):
    def __init__(self, game_id="pokemon", lang="en"):
        self.game_id = game_id
        self.api = f"https://api.tcgdex.net/v2/{lang}"

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        return sync.fetch_catalog(gdir, cancel, progress, only_sets, api=self.api)

    def fetch_details(self, gdir, cancel, progress, refresh_all=False, only_ids=None):
        return sync.fetch_details(gdir, cancel, progress, refresh_all, only_ids, api=self.api)

    def fetch_images(self, gdir, quality, cancel, progress):
        return sync.fetch_images(gdir, quality, cancel, progress)

    def estimate(self, gdir, quality):
        return sync.estimate(gdir, quality)

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return sync.refresh_prices(gdir, cancel, progress, priority_ids, api=self.api)


def _build_providers():
    from .tcgcsv import TcgCsvProvider
    return {
        "pokemon": PokemonProvider("pokemon", "en"),
        "pokemon_jp": PokemonProvider("pokemon_jp", "ja"),
        "onepiece": TcgCsvProvider("onepiece", 68, type_field="Color"),
        "unionarena": TcgCsvProvider("unionarena", 81, type_field="SeriesName"),
        "yugioh": TcgCsvProvider("yugioh", 2, type_field="Card Type"),
        "dbs": TcgCsvProvider("dbs", 27, type_field="Color"),
        "mtg": TcgCsvProvider("mtg", 1, type_field="SubType"),
        "lorcana": TcgCsvProvider("lorcana", 71, type_field="InkType"),
        "gundam": TcgCsvProvider("gundam", 86, type_field="Color"),
        "riftbound": TcgCsvProvider("riftbound", 89, type_field="Domain"),
        "palworld": TcgCsvProvider("palworld", 91, type_field="Type"),
    }


PROVIDERS = _build_providers()


def provider_for(game_id):
    return PROVIDERS.get(game_id)
