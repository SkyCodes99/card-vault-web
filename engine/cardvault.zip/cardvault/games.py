"""Game catalogue + download providers.

Each card game is a Game entry.  A game that is `available` has a provider that downloads its sets, cards, pictures and prices into
games/<id>/ in the data folder, filling the generic `sets` / `cards` tables (see db.CARDS_SCHEMA).  The rest of the app (browse,
collection, checklists, value, sharing, downloads) works for any game that fills those tables.

Providers
  * PokemonProvider   - TCGdex (api.tcgdex.net): English cards, pictures, prices, Pokédex numbers, illustrators
  * TcgCsvProvider    - tcgcsv.com (a daily dump of TCGplayer's catalogue): One Piece Card Game, Union Arena - and any other TCGplayer
                        category later (Magic, Yu-Gi-Oh!, Lorcana...) with one more registry line.
"""
from dataclasses import dataclass, field

from . import sync


@dataclass
class Game:
    id: str
    name: str
    source: str
    available: bool = False
    note: str = ""
    pokemon: bool = False           # Pokédex numbers, Art cards, mechanics, illustrators... only make sense for Pokémon
    type_label: str = "Type"        # what the 'types' column is called for this game (Type / Color / Series)
    rarity_order: tuple = ()        # rarity codes from the easiest to the hardest pull (for the rarity sections of a set)
    image_note: str = "small pictures about 20 KB each"
    family: str = ""               # games that belong together in the app (the Pokémon spots: English / TCG Pocket / Japanese)


GAMES = [
    Game("pokemon", "Pokémon TCG (English)", "TCGdex (api.tcgdex.net) - free community database", True,
         "English cards, pictures and market prices. Includes the TCG Pocket sets, which have their own spot under Cards.", pokemon=True, family="pokemon"),
    Game("pokemon_jp", "Pokémon TCG (Japanese)", "TCGdex (api.tcgdex.net, Japanese catalogue)", True,
         "Japanese cards and pictures (no prices).", pokemon=True, family="pokemon"),
    Game("onepiece", "One Piece Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (boosters, extra boosters, starter decks, promos) with pictures and market prices.",
         type_label="Color", rarity_order=("C", "UC", "R", "SR", "SEC", "L", "SP CARD", "SP", "TR", "P", "DON!!", "Promo")),
    Game("unionarena", "Union Arena", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, starter deck, advanced deck and promo with pictures and market prices.",
         type_label="Series", rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Special", "Ultra Rare", "Promo", "Action Point")),
    Game("mtg", "Magic: The Gathering", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, Commander deck, promo and token with pictures and market prices (a big download).", type_label="Type",
         rarity_order=("C", "U", "R", "M", "S", "T", "P", "L")),
    Game("yugioh", "Yu-Gi-Oh!", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (booster packs, structure decks, tins, promos) with pictures, 1st Edition / Unlimited printings and market prices.",
         type_label="Attribute", rarity_order=("Common", "Short Print", "Rare", "Super Rare", "Ultra Rare", "Ultimate Rare", "Secret Rare", "Ghost Rare", "Starlight Rare", "Collector's Rare", "Prismatic Secret Rare", "Quarter Century Secret Rare", "Promo")),
    Game("dbs", "Dragon Ball Super Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every Masters-era booster, starter deck, promo and tournament card with pictures and market prices (Fusion World is its own game below).",
         type_label="Color", rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Special Rare", "Secret Rare", "Ultra Rare", "Starter Rare", "Leader Rare", "Promo")),
    Game("lorcana", "Disney Lorcana", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (booster sets, starter decks, promos) with pictures and market prices.", type_label="Ink",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Legendary", "Enchanted", "Epic", "Iconic", "Promo")),
    Game("gundam", "Gundam Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, starter deck and promo with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Legend Rare", "Promo")),
    Game("riftbound", "Riftbound (League of Legends TCG)", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, bundle and promo with pictures and market prices.", type_label="Domain",
         rarity_order=("Common", "Uncommon", "Rare", "Epic", "Overnumbered", "Showcase", "Promo")),
    Game("palworld", "Palworld Official Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster and starter deck with pictures and market prices.", type_label="Type"),
    Game("funko", "Funko Pop! (collectibles)", "TCGplayer (tcgcsv.com) + the open hobbyDB-based Funko list (MIT)", True,
         "Every Funko figure we could find - about 20,000 names and pictures, with market prices where TCGplayer has them. Browse by fandom (Television, Movies, Animation, Disney, Games ...).",
         type_label="Series", rarity_order=("Standard", "Exclusive", "Limited Edition", "Chase", "Limited Edition Chase", "Specialty Series"), family="collectibles"),
    Game("accessories", "Accessories (playmats & displays)", "TCGplayer (tcgcsv.com)", True,
         "Playmats for Pokémon and every other card game (about 6,600), plus deck boxes and displays that name a game. Browse by brand.",
         type_label="Game", family="collectibles"),
    Game("chomps", "Abominable Toys", "abominabletoys.com (public shop feed)", True,
         "Every Abominable Toys figure - Chomps, Chompers, Frozen Culture, plush, collaborations, Hope Turtle ... - with picture, price, edition size and what makes it exclusive. Filter by product line. Refreshed daily - new releases are added, sold-out ones stay.",
         type_label="Product line", rarity_order=("Open edition", "Limited edition"), family="collectibles"),
    Game("dumpsterfires", "100% Soft", "100soft.shop (public shop feed)", True,
         "Every 100% Soft toy - Dumpster Fires (including the sold-out vault), Trash Fire Friends, collaborations, plush ... - with picture, price and edition. Filter by product line. Refreshed daily - new releases are added, sold-out ones stay.",
         type_label="Product line", rarity_order=("Open edition", "Limited edition"), family="collectibles"),
    Game("youtooz", "Youtooz", "youtooz.com (public shop feed)", True,
         "Every Youtooz vinyl figure and plush - games, anime, cartoons, memes, streamers, originals ... past drops included - with picture, price and whether it is still available. Filter by franchise, product type, drop and availability. Refreshed daily - new drops are added.",
         type_label="Franchise", rarity_order=("Open edition", "Limited edition"), family="collectibles"),
    Game("beyblade", "Beyblade X", "beyblade.fandom.com product lists (CC BY-SA) + a collector's spreadsheet", True,
         "Every Beyblade X release - Takara Tomy Basic (BX), Unique (UX) and Custom (CX) lines, limited and prize releases, every Hasbro release, plus the event gear stickers. Filter by product type (starter, booster, random booster, set, stadium, launcher, parts ...), line, maker, blade, year and where it was sold.",
         type_label="Blade", rarity_order=("Regular release", "Limited / exclusive"), family="collectibles"),
    Game("bakugan", "Bakugan", "bakugan.fandom.com wave lists (CC BY-SA)", True,
         "Every Bakugan and every attachment (Battle Gear, Super Assault, Mobile Assault, BakuNano, Mechtogan, Baku-Gear ...), one entry per type (Pyrus, Aquos, Haos, Darkus, Subterra, Ventus, Aurelus), by season and wave. Filter by Bakugan or attachment, kind, type, season and wave.",
         type_label="Type (attribute)", rarity_order=("Regular release", "Re-release", "Exclusive"), family="collectibles"),
    Game("plushies", "Plushies", "Bulbapedia (CC BY-NC-SA) + the Squishmallows wiki (CC BY-SA)", True,
         "Pokemon plush (Sitting Cuties in the US and the Japanese Pokemon fit - mark which one you have) and every Squishmallow, with pictures. Filter by brand and line; more brands are added over time.",
         type_label="Brand / line", family="collectibles"),
    Game("needoh", "Nee-Doh (Schylling)", "needoh.org (unofficial catalogue)", True,
         "Every Nee-Doh stress toy - Nice Cube, Gumdrop, Cool Cats, glow and seasonal editions ... - with its picture. Refreshed daily; new ones are added.", type_label="Maker", family="collectibles"),
    Game("weissschwarz", "Weiss Schwarz", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, trial deck, premium booster and promo of the English Weiss Schwarz with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Double Rare", "Triple Rare", "Super Rare", "Climax Rare", "Special Rare", "Super Special Rare", "Signed", "Promo")),
    # ---- the other card games TCGplayer lists (the list of ids, categories and filter fields is cardvault/tcggames.py)
    Game("dbsfw", "Dragon Ball Super Card Game Fusion World", "TCGplayer catalogue via tcgcsv.com", True,
         "Every Fusion World booster, starter deck, promo and tournament card with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Secret Rare", "Leader", "Code Card", "Promo")),
    Game("dbz", "Dragon Ball Z TCG (Panini & Score)", "TCGplayer catalogue via tcgcsv.com", True,
         "The older Dragon Ball Z trading card game: every Panini and Score set with pictures and market prices.", type_label="Type",
         rarity_order=("Common", "Starter", "Uncommon", "Rare", "Ultra Rare", "Dragon Rare", "Insert", "P")),
    Game("swu", "Star Wars: Unlimited", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (boosters, spotlight decks, weekly play and promo cards) with pictures and market prices.", type_label="Aspect",
         rarity_order=("Common", "Uncommon", "Rare", "Legendary", "Special")),
    Game("digimon", "Digimon Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, starter deck, promo and tournament card with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Secret Rare", "Ultimate Rare", "Promo")),
    Game("fab", "Flesh and Blood", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, armory deck, blitz deck and promo with pictures and market prices.", type_label="Class",
         rarity_order=("Common", "Rare", "Super Rare", "Majestic", "Legendary", "Fabled", "Marvel", "Basic", "Token", "Promo")),
    Game("vanguard", "Cardfight!! Vanguard", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, trial deck, start-up deck and promo of the English, Japanese and overDress lines with pictures and market prices.", type_label="Nation",
         rarity_order=("C", "R", "RR", "RRR", "VR", "SVR", "SP", "FR", "FFR", "GR", "SEC", "T")),
    Game("fow", "Force of Will", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter deck and promo with pictures and market prices.", type_label="Attribute",
         rarity_order=("Common", "Normal", "Uncommon", "Rare", "Super Rare", "Marvel Rare", "Ruler Rare", "Sub Ruler Rare", "Uber Rare", "XR", "Basic", "Token")),
    Game("shadowverse", "Shadowverse: Evolve", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, starter deck and promo with pictures and market prices.", type_label="Class",
         rarity_order=("Bronze", "Silver", "Gold", "Legendary", "Super Legendary", "Ultimate", "Premium")),
    Game("grandarchive", "Grand Archive", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter deck and promo with pictures and market prices.", type_label="Element",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Ultra Rare", "Collector Super Rare")),
    Game("wixoss", "WIXOSS", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, deck and promo of the English WIXOSS with pictures and market prices.", type_label="Color",
         rarity_order=("C", "R", "LC", "SR", "LR", "UR", "ST", "T", "SRP", "LRP", "PI", "Re")),
    Game("hololive", "hololive OFFICIAL CARD GAME", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, start deck and promo with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Double Rare", "Super Rare", "Ultra Rare", "Secret Rare", "Special", "Oshi Super Rare", "Oshi Ultra Rare", "Holomem Rare", "Special Yell")),
    Game("finalfantasy", "Final Fantasy TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every opus, starter deck and promo with pictures and market prices.", type_label="Element",
         rarity_order=("Common", "Rare", "Hero", "Legend", "Starter", "Promo")),
    Game("battlespirits", "Battle Spirits Saga", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter deck and promo with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Special Rare", "X Rare", "Collaboration Rare", "Collaboration X Rare", "Saga Rare", "Promo")),
    Game("metazoo", "MetaZoo", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, first edition and unlimited, with pictures and market prices.", type_label="Aura",
         rarity_order=("Bronze", "Silver", "Gold")),
    Game("universus", "UniVersus", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set (Marvel, Attack on Titan, My Hero Academia, Street Fighter and the rest) with pictures and market prices.", type_label="Resource",
         rarity_order=("Common", "Uncommon", "Rare", "Ultra Rare", "Promo")),
    Game("sorcery", "Sorcery: Contested Realm", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, precon and promo with pictures and market prices.", type_label="Element",
         rarity_order=("Ordinary", "Exceptional", "Elite", "Unique", "Promo")),
    Game("cookierun", "CookieRun: Braverse", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices.", type_label="Color",
         rarity_order=("C", "U", "R", "SR", "SSR", "UR", "SUR", "SEC", "EXR", "GXR", "P")),
    Game("godzilla", "Godzilla Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter deck and promo with pictures and market prices.", type_label="Color",
         rarity_order=("C", "UC", "R", "SR", "SD", "SP", "P")),
    Game("alphaclash", "Alpha Clash", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices.", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Epic", "Legendary", "Iconic Rare", "Starter Rare", "Alpha Rare", "Promo")),
    Game("elestrals", "Elestrals", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter deck and promo with pictures and market prices.", type_label="Element",
         rarity_order=("C", "UC", "R", "SR")),
    Game("akora", "Akora", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, first edition and unlimited, with pictures and market prices.", type_label="Attribute",
         rarity_order=("Common", "Uncommon", "Rare", "Holo", "Full Art", "Extended Art", "Secret Rare")),
    Game("kryptik", "Kryptik TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every wave with pictures and market prices.", type_label="Faction",
         rarity_order=("Common", "Rare", "Noble Rare")),
    Game("transformers", "Transformers TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices.", type_label="Affiliation",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare")),
    Game("swdestiny", "Star Wars: Destiny", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set with pictures and market prices (the game is no longer printed).", type_label="Color",
         rarity_order=("Common", "Uncommon", "Rare", "Legendary", "Fixed")),
    Game("gateruler", "Gate Ruler", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and starter deck with pictures and market prices.", type_label="Faction",
         rarity_order=("No Star", "1-Star", "2-Star", "3-Star", "4-Star", "Uber Rare", "Superior Rare", "Legend Rare")),
    Game("wowtcg", "World of Warcraft TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices (the game is no longer printed).", type_label="Class",
         rarity_order=("C", "U", "R", "E", "L")),
    Game("dicemasters", "Dice Masters", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter and team pack with pictures and market prices.", type_label="Energy",
         rarity_order=("Common", "Uncommon", "Rare", "Super-Rare", "Starter", "Promo")),
    Game("buddyfight", "Future Card Buddyfight", "TCGplayer catalogue via tcgcsv.com", True,
         "Every booster, trial deck and promo with pictures and market prices.", type_label="World",
         rarity_order=("C", "U", "R", "RR", "RRR")),
    Game("dragoborne", "Dragoborne", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and trial deck with pictures and market prices.", type_label="Color",
         rarity_order=("C", "U", "R", "RR", "TD", "PR")),
    Game("metax", "MetaX TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and starter deck with pictures and market prices.", type_label="Stat",
         rarity_order=("Common", "Uncommon", "Rare", "Starter", "Promo")),
    Game("zwo", "Zombie World Order TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices.", type_label="Color",
         rarity_order=("C", "UC", "R", "PR")),
    Game("casterchronicles", "The Caster Chronicles", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and starter deck with pictures and market prices.", type_label="Element",
         rarity_order=("Common", "Uncommon", "Rare", "Super Rare", "Ultra Rare", "Repack")),
    Game("exodus", "Exodus TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every edition and promo with pictures and market prices.", type_label="Edition",
         rarity_order=("Common", "Uncommon", "Rare", "Secret Rare", "Harmony Rare")),
    Game("lightseekers", "Lightseekers TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices.", type_label="Order",
         rarity_order=("Common", "Uncommon", "Rare", "Mythic", "RareStarter", "RareToy")),
    Game("munchkin", "Munchkin Collectible Card Game", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and promo with pictures and market prices.", type_label="Faction",
         rarity_order=("C - Common", "Common", "U - Uncommon", "Uncommon", "R - Rare", "Rare", "X - Special")),
    Game("aoschampions", "Warhammer Age of Sigmar: Champions", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and starter with pictures and market prices.", type_label="Alliance",
         rarity_order=("Common", "Uncommon", "Rare", "Exclusive Starter", "Exclusive")),
    Game("bakugantcg", "Bakugan TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, starter and promo of the trading card game (the toys are the Bakugan list under Misc).", type_label="Faction",
         rarity_order=("Common", "Rare", "Super Rare", "Awesome Rare")),
    Game("chronoclash", "Chrono Clash System", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set with pictures and market prices.", type_label="Color",
         rarity_order=()),
    Game("argentsaga", "Argent Saga TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set, intro deck and promo with pictures and market prices.", type_label="Element",
         rarity_order=("Common", "Rare", "Super Rare", "Promo", "Demo Deck", "Intro Deck")),
    Game("cyberpunk", "Cyberpunk TCG", "TCGplayer catalogue via tcgcsv.com", True,
         "Every set and starter with pictures and market prices.", type_label="Color",
         rarity_order=("C", "UC", "R", "NR", "E", "IL")),
]


def is_misc(game_id):
    """True for the lists that are not card games (Funko, Chomps, plush, accessories, Beyblade, Bakugan ...): everything you own there is a 'Misc' item - the third kind next to cards and sealed products."""
    return game_by_id(game_id).family == "collectibles"


def game_by_id(game_id):
    return next((g for g in GAMES if g.id == game_id), GAMES[0])


class GameProvider:
    """Interface every game provider implements.  All methods take the game's folder (games/<id>) and a cancel Event."""
    game_id = ""
    avg_bytes = {"low": 22_000, "high": 85_000}

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        raise NotImplementedError

    def fetch_details(self, gdir, cancel, progress, refresh_all=False, only_ids=None):
        raise NotImplementedError

    def fetch_images(self, gdir, quality, cancel, progress):
        raise NotImplementedError

    def estimate(self, gdir, quality):
        raise NotImplementedError

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        raise NotImplementedError


class PokemonProvider(GameProvider):
    def __init__(self, game_id="pokemon", lang="en"):
        self.game_id = game_id
        self.api = f"https://api.tcgdex.net/v2/{lang}"

    def fetch_catalog(self, gdir, cancel, progress, only_sets=None):
        return sync.fetch_catalog(gdir, cancel, progress, only_sets, api=self.api)

    def fetch_details(self, gdir, cancel, progress, refresh_all=False, only_ids=None):
        return sync.fetch_details(gdir, cancel, progress, refresh_all, only_ids, api=self.api)

    def fetch_images(self, gdir, quality, cancel, progress):
        return sync.fetch_images(gdir, quality, cancel, progress)

    def estimate(self, gdir, quality):
        return sync.estimate(gdir, quality)

    def refresh_prices(self, gdir, cancel, progress, priority_ids=()):
        return sync.refresh_prices(gdir, cancel, progress, priority_ids, api=self.api)


def _build_providers():
    from . import tcggames
    from .tcgcsv import TcgCsvProvider
    from .collectibles import AccessoriesProvider, NeeDohProvider, PlushProvider, FunkoProvider, chomps_provider, dumpsterfire_provider, youtooz_provider
    from .wikitoys import BakuganProvider, BeybladeProvider
    tcg = {game: TcgCsvProvider(game, tcggames.CATEGORIES[game], type_field=field, kind_field=tcggames.KIND_FIELDS.get(game)) for game, field in tcggames.TYPE_FIELDS.items()}          # every TCGplayer card game
    return {
        "pokemon": PokemonProvider("pokemon", "en"),
        "pokemon_jp": PokemonProvider("pokemon_jp", "ja"),
        **tcg,
        "funko": FunkoProvider(),
        "plushies": PlushProvider(),
        "needoh": NeeDohProvider(),
        "chomps": chomps_provider(),
        "dumpsterfires": dumpsterfire_provider(),
        "youtooz": youtooz_provider(),
        "beyblade": BeybladeProvider(),
        "bakugan": BakuganProvider(),
        "accessories": AccessoriesProvider(),
    }


PROVIDERS = _build_providers()


def provider_for(game_id):
    return PROVIDERS.get(game_id)
