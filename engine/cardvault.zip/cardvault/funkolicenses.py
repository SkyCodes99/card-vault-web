"""Every Pokémon and Yu-Gi-Oh! Funko Pop! (owner 2026-11-14: "ensure all pokemon and yu-gi-oh funkos pops are included").

funkowiki adds only Pops from 2021 on and skips a row whose year cell lists several years, so older Pops and most store / finish versions of these two licenses were missing or unnumbered.
This pass reads the same wiki pages (funkowiki's weekly API cache, never the web pages) and, for the rows whose franchise cell says Pokémon or Yu-Gi-Oh!, takes EVERY Pop and every version the wiki
lists for it ('# Flocked (GameStop Exclusive)', '# Pearlescent (Pokémon Center Exclusive)' ...), of any year, plus the multi-pack and Deluxe Moment tables.

For each version (number, size, finish, store):
  in the list already   a row of the same line at that number (or an unnumbered hobbyDB row of that one name) with the same finish and a fitting store -> nothing added; an unnumbered hobbyDB row
                        that fits exactly one wiki version gets the wiki's number
  maybe in the list     a row fits several versions -> review (never a second copy)
  missing               added only with the wiki's own picture of THAT version and a second source (the Pop itself in the TCGplayer / hobbyDB lists, or a saved checker finding); else review
Multi-packs and Deluxe Moments count on their own numbering and have only the wiki as a source: review, never added on their own.
The rows waiting go into funkowiki.LAST['review'], so the daily update queues them with the other wiki Pops.  Never raises: with the wiki down the list stays as it is."""
import json
import os
import re

from . import funkovariants as fv
from . import funkowiki as fw

LICENSES = (("Pokémon", re.compile(r"pok\S?mon", re.I)), ("Yu-Gi-Oh!", re.compile(r"yu-?gi-?oh", re.I)))
PAGES = ("Pop! Games", "Pop! Animation", "Pop! Deluxe Moments")
SETS = {"Pop! Games": ("fd:games", "fd:pokemon"), "Pop! Animation": ("fd:animation",)}           # where the list keeps that page's Pops
_SIZE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:\"|''|-?\s*inch\b|in\b)", re.I)
_NOISE = {"spring", "summer", "fall", "winter", "convention", "debut", "virtual", "wondrous", "wonderous", "shared", "sticker", "anniversary", "silver"}    # 'Pikachu (Silver) (Metallic)' is the Metallic Pikachu
_FINISH_KEYS = {k for k, _ in fv._FIN}
_FILE_WORDS = {"Metallic": r"metallic|silver|gold", "Flocked": r"flock", "Diamond": r"diamond", "Pearlescent": r"pearl", "Soft Color": r"soft", "Glow in the Dark": r"glow|gitd",
               "Chase": r"chase", "Glitter": r"glitter", "Translucent": r"translucent", "Blacklight": r"black-?light", "Chrome": r"chrome", "Scented": r"scent"}
HDB_LAST = 2021                                    # the open hobbyDB list has nothing newer
LAST = {}


def _fix(s):
    return s.replace("Pok\ufffdmon", "Pokémon")


def size_of(text):
    m = _SIZE.search(fv._unescape(text))
    return m.group(1) if m else ""


def name_key(name):
    return " ".join(w for w in fv.base_key(name).split() if w not in _NOISE)


def license_of(texts):
    for label, rx in LICENSES:
        if any(rx.search(t) for t in texts):
            return label
    return ""


def _marks(text):
    t = fv.tokens("", (), text, "")
    fin = frozenset(k for k in t if k in _FINISH_KEYS)
    stores = frozenset(k for k in t if k in fv._STORE_KEYS)
    return fin, stores


# ------------------------------------------------------------------------------------------------ the wiki rows
def rows_of(page, text):
    """[{page, table, number, name, license, years, files, items, multi}] for every Pokémon / Yu-Gi-Oh! row of a page; items = the versions [(label, is_original)] ('Original' when none listed)."""
    out = []
    for head, cap, table in fw._tables(text):
        multi = fw._is_other_line(page, head + " " + cap)
        for cells in fw._table_rows(table):
            texts = [_fix(fw._clean(c[1])) for c in cells]
            num = re.fullmatch(r"#?\s*(\d{1,4})", texts[0]) if texts else None
            if not num or len(cells) < 3:
                continue
            lic = license_of(texts[2:])
            name = texts[1]
            if not lic or not name or len(name) > 90 or fw._NO_NAME.match(name) or re.search(r"[|{}<>=�]", name):
                continue
            raw = [c[1] for c in cells]
            listed = [_fix(fw._clean(m)) for c in raw[1:] for m in re.findall(r"^\s*#\s*(.+)$", c, re.M)]
            listed = [x for x in listed if x and len(x) <= 80 and not re.fullmatch(r"\d+", x)]
            notes = [t for t in texts[2:] if t and not re.fullmatch(r"[\d\s]+", t) and not license_of([t]) and len(t) <= 120]
            items = [(x, bool(fv._ORIGINAL.match(x))) for x in listed] or [(" / ".join(notes) if multi else "Original", True)]
            if not any(o for _, o in items):
                items.insert(0, ("Original", True))
            out.append({"page": page, "table": head, "number": int(num.group(1)), "name": name, "license": lic, "multi": multi,
                        "years": next((t.split() for t in texts[2:] if re.fullmatch(r"(?:(?:19|20)\d\d\s*)+", t)), []),       # the year cell only (one year per version, in order)
                        "files": [x.strip() for c in raw for x in re.findall(r"\[\[(?:File|Image):([^|\]]+)", c, re.I)], "items": items})
    return out


def versions(rows):
    """One entry per version: the row's fields + label, original, size, fin, stores, year."""
    out = []
    for r in rows:
        base_size = size_of(r["name"])
        for i, (label, original) in enumerate(r["items"]):
            fin, stores = _marks(label)
            year = r["years"][i] if len(r["years"]) == len(r["items"]) else (r["years"][0] if original and r["years"] else "")
            out.append({**r, "label": label, "original": original, "size": size_of(label) or base_size, "fin": fin, "stores": stores, "year": year, "key": name_key(r["name"])})
    return out


# ------------------------------------------------------------------------------------------------ is it in the list?
def marks_fit(fin_r, st_r, fin_i, st_i):
    """A list row is this version: the same finish and a store that does not contradict, or the version's finish beyond the row's but the same store ('Pikachu (Pokémon Center Exclusive)' is the
    Pearlescent Pokémon Center Pop)."""
    if fin_r == fin_i:
        return bool(st_r & st_i) or not st_r or not st_i
    return fin_i - fin_r == {"Pearlescent"} and "Pokémon Center" in st_r & st_i


def list_rows(conn, set_ids):
    out = []
    q = "SELECT id, set_id, local_id, name, rarity, raw, image_base FROM cards WHERE set_id IN (%s)" % ",".join("?" * len(set_ids))
    for cid, sid, lid, name, rarity, raw, img in conn.execute(q, set_ids).fetchall():
        d = fv._doc(raw)
        if fv.is_signed(name):
            continue
        t = fv.tokens(name, d.get("tags") or [], d.get("note") or "", rarity)
        digits = re.sub(r"\D", "", lid or "")
        prefix = fv._franchise_prefix(name)
        out.append({"id": cid, "set": sid, "hdb": str(cid).startswith("hdb:"), "prefix": prefix if prefix and not license_of([prefix]) else "", "num": int(digits) if digits else None, "name": name, "key": name_key(name), "size": size_of(name), "img": img,
                    "fin": frozenset(k for k in t if k in _FINISH_KEYS), "stores": frozenset(k for k in t if k in fv._STORE_KEYS)})
    return out


def _related(a, b):
    """Two plain names for the same figure at one number: one's words inside the other's, or the same first word ('Pikachu' / 'Pikachu (Waving)')."""
    wa, wb = set(a.split()), set(b.split())
    return bool(wa and wb) and (wa <= wb or wb <= wa or a.split()[0] == b.split()[0])


def _same_words(a, b):
    """Word by word the same, a one-letter word standing for a word it starts ('Red-Eyes B. Dragon' / 'Red-Eyes Black Dragon')."""
    wa, wb = a.split(), b.split()
    return len(wa) == len(wb) and all(x == y or (min(len(x), len(y)) == 1 and (x.startswith(y) or y.startswith(x))) for x, y in zip(wa, wb))


def _name_fits(row_key, v, keys):
    if _same_words(row_key, v["key"]):
        return True
    w = row_key.split()
    vw = v["key"].split()
    short, long_ = (w, vw) if len(w) <= len(vw) else (vw, w)
    if not short or long_[:len(short)] != short:
        return False
    return sum(1 for k in keys if k.split()[:len(short)] == short) == 1          # a word-prefix only when it names one wiki figure ('Obelisk' -> 'Obelisk The Tormentor')


def match(rows, vs):
    """-> (found, maybe, numbered): found[i] = list rows that are version i; maybe[i] = rows that could be it or another one; numbered = [(row id, number)] for unnumbered hobbyDB rows that fit one."""
    found, maybe, numbered = {}, {}, []
    by_set = {}
    for i, v in enumerate(vs):
        by_set.setdefault(v["page"], []).append(i)
    for page, idx in by_set.items():
        keys = {vs[i]["key"] for i in idx}
        sets = SETS.get(page, ())
        for r in (x for x in rows if x["set"] in sets):
            def fits(i, same_number):
                v = vs[i]
                if same_number:
                    if v["number"] != r["num"] or not _related(r["key"], v["key"]):
                        return False
                elif not _name_fits(r["key"], v, keys):
                    return False
                if same_number:
                    size_ok = r["size"] == v["size"] or (not v["size"] and not any(vs[j]["number"] == v["number"] and vs[j]["size"] == r["size"] for j in idx))
                else:
                    size_ok = r["size"] == v["size"] or (not r["size"] and not any(vs[j]["key"] == v["key"] and not vs[j]["size"] for j in idx))
                    if r["hdb"] and v["year"] and int(v["year"]) > HDB_LAST:
                        return False                                  # the hobbyDB list stops in 2021: its row is not a later Pop of the same name
                    if r["prefix"]:
                        return False                                  # 'An Afternoon with Eevee: Jolteon' is another line's figure, matched only by its number
                return size_ok and marks_fit(r["fin"], r["stores"], v["fin"], v["stores"])
            hit = [i for i in idx if not vs[i]["multi"] and fits(i, True)] if r["num"] is not None else []
            if not hit:
                hit = [i for i in idx if not vs[i]["multi"] and fits(i, False)]
            if len(hit) > 1:
                exact = [i for i in hit if vs[i]["fin"] == r["fin"] and (r["stores"] & vs[i]["stores"] or not r["stores"] and not vs[i]["stores"])]
                hit = exact if len(exact) == 1 else hit
            if len(hit) == 1:
                found.setdefault(hit[0], []).append(r)
                if r["num"] is None and str(r["id"]).startswith("hdb:"):
                    numbered.append((r["id"], vs[hit[0]]["number"]))
            elif len({vs[i]["number"] for i in hit}) == 1 and len(hit) > 1 and r["num"] == vs[hit[0]]["number"]:
                for i in hit:                                             # one Pop number, several versions fit: the plainest one is it
                    if not vs[i]["fin"] and vs[i]["original"]:
                        found.setdefault(i, []).append(r)
                        break
                else:
                    for i in hit:
                        maybe.setdefault(i, []).append(r)
            else:
                for i in hit:
                    maybe.setdefault(i, []).append(r)
    return found, maybe, numbered


# ------------------------------------------------------------------------------------------------ pictures
def own_file(v, all_versions_of_row):
    """The wiki file that shows THIS version: the first file for the original when it carries no finish / size word, else the one file whose name has every finish word of the version (and its
    size), none of another version's, and the Pop's number or name.  '' when none or several fit."""
    files = [f for f in v["files"] if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")) and not fw._NO_PICTURE.search(f)]
    if not files:
        return ""
    others = set()
    for o in all_versions_of_row:
        others |= set(o["fin"]) | ({"size:" + o["size"]} if o["size"] else set())
    want = set(v["fin"]) | ({"size:" + v["size"]} if v["size"] and v["size"] != size_of(v["name"]) else set())

    def words(f):
        low = re.sub(r"[ _]+", "-", f.lower())
        have = {k for k in others if not k.startswith("size:") and re.search(_FILE_WORDS.get(k, re.escape(k.lower())), low)}
        have |= {k for k in others if k.startswith("size:") and re.search(r"(?<!\d)" + re.escape(k[5:]) + r"(?:in|inch|-inch|\")?(?!\d)", re.sub(r"(?<!\d)" + str(v["number"]) + r"(?!\d)", "", low))}
        return have, low
    name_words = [w for w in fv.base_key(v["name"]).split() if len(w) > 2][:2]
    fit = []
    for f in files:
        have, low = words(f)
        if have != want:
            continue
        nums = [int(n) for n in re.findall(r"(?<!\d)\d{3,4}(?!\d)", low)]
        if any(n != v["number"] and not 1990 <= n <= 2030 for n in nums):
            continue
        if str(v["number"]) in low or any(w in low for w in name_words) or (v["original"] and f == files[0]):
            fit.append(f)
    if v["original"] and not v["fin"] and files[0] in fit:
        return files[0]
    return fit[0] if len(fit) == 1 else ""


# ------------------------------------------------------------------------------------------------ putting it together
def _set_name(v):
    return re.sub(r"^Pop!\s*", "", v["page"]).strip()


def _pop(v, name):
    return {"page": v["page"], "number": v["number"], "name": name, "year": v["year"], "series": v["license"], "note": "" if v["original"] else v["label"]}


def _label(v):
    if v["original"]:
        stores = {k: lab for k, lab in fv.tokens("", (), v["label"], "").items() if k in fv._STORE_KEYS}
        return ", ".join(stores.values())
    return fv.flat_label(v["label"])


def plan(conn, rows, evidence=None):
    """-> (add, review, numbered, found): add = [(version, display name, file)], review = [(version, display name, why)]."""
    vs = versions(rows)
    sets = tuple(s for p in PAGES for s in SETS.get(p, ()))
    lrows = list_rows(conn, sets)
    found, maybe, numbered = match(lrows, vs)
    index = fv.Index(conn)
    evidence = evidence or {}
    by_row = {}
    for i, v in enumerate(vs):
        by_row.setdefault((v["page"], v["table"], v["number"], v["name"]), []).append(i)
    add, review = [], []
    for i, v in enumerate(vs):
        if i in found:
            continue
        lab = v["label"] if v["multi"] else _label(v)
        name = f"{v['name']} ({lab})" if lab else v["name"]
        if i in maybe:
            review.append((v, name, "a check: it may already be listed as " + "; ".join(sorted({r['name'] for r in maybe[i]}))[:200]))
            continue
        if v["multi"]:
            review.append((v, name, "a second source (multi-packs and Deluxe Moments are only on the wiki)"))
            continue
        sib = by_row[(v["page"], v["table"], v["number"], v["name"])]
        pop_known = any(j in found for j in sib)
        second = pop_known or fw.second_source({"name": v["name"], "number": v["number"]}, fw._set_id(_set_name(v)), index, evidence) \
            or evidence.get(f"{v['number']} {name}", "")
        f = own_file(v, [vs[j] for j in sib])
        missing = ([] if f else ["a picture of its own"]) + ([] if second else ["a second source"])
        if missing:
            review.append((v, name, " and ".join(missing)))
        else:
            add.append((v, name, f))
    return add, review, numbered, found


def apply(conn, gdir, put_set, cancel):
    """Number the hobbyDB rows the wiki pins down, add the missing versions that pass both gates, fill the picture of a wiki-added row that has none, queue the rest.  -> counts (never raises)."""
    LAST.clear()
    try:
        folder = os.path.join(gdir, "funkowiki")
        rows = []
        for page in PAGES:
            if cancel.is_set():
                return {}
            rows += rows_of(page, fw.page_text(folder, page, cancel))
        if not rows:
            return {}
        evidence = fw._cache_read(os.path.join(folder, "second_sources.json")) or {}
        add, review, numbered, found = plan(conn, rows, evidence)
        n_num = 0
        for cid, number in numbered:
            n_num += conn.execute("UPDATE cards SET local_id=?, sort_key=? WHERE id=? AND (local_id IS NULL OR local_id='')", (str(number), number, cid)).rowcount
        vs = versions(rows)
        refill = []                                                     # wiki rows added on the owner's yes without a picture: their own file, when there is exactly one
        for i, rs in found.items():
            for r in rs:
                if not r["img"] and str(r["id"]).startswith("fw:"):
                    sib = [x for x in vs if (x["page"], x["number"], x["name"]) == (vs[i]["page"], vs[i]["number"], vs[i]["name"])]
                    f = own_file(vs[i], sib)
                    if f:
                        refill.append((r["id"], f))
        pics = fw.pictures(folder, list(dict.fromkeys([f for _, _, f in add] + [f for _, f in refill])), cancel)
        added = 0
        for v, name, f in add:
            pic = pics.get(f) or None
            if not pic:
                review.append((v, name, "a picture of its own"))
                continue
            added += fw._insert(conn, put_set, _pop(v, v["name"]), _set_name(v), name, pic, slug_extra="" if v["original"] and not _label(v) else _label(v))
        filled = 0
        for cid, f in refill:
            if pics.get(f):
                filled += conn.execute("UPDATE cards SET image_base=? WHERE id=? AND (image_base IS NULL OR image_base='')", (pics[f], cid)).rowcount
        conn.commit()
        queued = fw.LAST.setdefault("review", [])
        for v, name, why in review:
            p = {**_pop(v, name), "base": v["name"], "variant": "" if v["original"] else _label(v)}
            queued.append((p, _set_name(v), why))
        LAST.update({"versions": len(vs), "in_list": len(found), "numbered": n_num, "added": added, "pictures": filled, "review": len(review)})
        return dict(LAST)
    except Exception as e:  # noqa: BLE001 - an extra source: the rest of the list is fine without it today
        print("funko: Pokémon / Yu-Gi-Oh! check not done:", str(e)[:80], flush=True)
        return {}
