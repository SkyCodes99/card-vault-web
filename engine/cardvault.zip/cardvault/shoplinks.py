"""Where to get an item: the "Shop" list in the item panel.  Plain links only - no affiliate links, no tracking parameters (owner's decision, 2026-11-10).

`for_item(...)` returns [{site, url, kind: "market"|"maker"|"retailer", stock: "in"|"out"|"unknown", checked: "YYYY-MM-DD"|None}]:
  * TCGplayer  - the product page from the product id (or the stored TCGplayer url), market, stock unknown.
  * eBay       - a plain search URL built from the item's name + set + number, market, stock unknown.
  * maker / retailer - the product url the data readers stored (raw["url"]); stock read from the stored Availability text ("In stock ..." / "Sold out ...") when there is one.
Stock is re-checked in the weekly full check: cardvault/weeklylinks.py reads it (robots.txt-checked, small budget) and stores it in linkstore; `refresh_stock` below hands it the items."""
import re
from . import linkstore
from urllib.parse import parse_qsl, quote_plus, urlencode, urlsplit, urlunsplit

TRACKING = {"ref", "ref_", "referrer", "source", "src", "aff", "affid", "affiliate", "partner", "partnerid", "campid", "customid", "toolid", "mkcid", "mkrid", "mkevt", "mksid",
            "siteid", "icep_id", "gclid", "gclsrc", "fbclid", "msclkid", "dclid", "irclickid", "irgwc", "clickid", "cjevent", "sid", "subid", "tag", "linkcode", "pid", "scid",
            "mc_cid", "mc_eid", "_ga", "_gl", "oly_enc_id", "oly_anon_id", "wickedid", "yclid", "twclid", "ttclid", "share", "shpxid", "srsltid", "variant_tracking"}
MAKER_HOSTS = ("pokemoncenter.com", "funko.com", "bearwalker.com", "frozenculture.com")        # the maker's own shop (anything else with a stored url is a retailer)


def clean_url(url):
    """The link with its tracking/affiliate parameters and #fragment removed; "" if it is not a plain http(s) link."""
    try:
        p = urlsplit((url or "").strip())
    except ValueError:
        return ""
    if p.scheme not in ("http", "https") or not p.netloc:
        return ""
    keep = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k.lower() not in TRACKING and not k.lower().startswith(("utm_", "pk_", "mtm_", "_hs", "hsa_"))]
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(keep), ""))


def tcgplayer_url(tcg_id):
    s = str(tcg_id or "").strip()
    return f"https://www.tcgplayer.com/product/{s}" if s.isdigit() else ""


def ebay_url(name, set_name="", number=""):
    """A plain eBay search (Buy It Now) for the item: name + set + collector number, URL-encoded."""
    local = str(number or "").split("/")[0].strip()
    words = [w for w in (name, set_name if set_name and set_name.lower() not in (name or "").lower() else "", local if local and local not in (name or "") else "") if w]
    q = " ".join(words).strip()
    return f"https://www.ebay.com/sch/i.html?_nkw={quote_plus(q)}&LH_BIN=1" if q else "https://www.ebay.com/"


def _stock(text):
    """('in'|'out'|'unknown', checked-date|None) from a stored Availability line like 'Sold out at Pokémon Center (2026-11-02)'."""
    t = (text or "").lower()
    day = re.search(r"(\d{4}-\d{2}-\d{2})", text or "")
    st = "out" if ("sold out" in t or "out of stock" in t) else "in" if "in stock" in t else "unknown"
    return st, (day.group(1) if day and st != "unknown" else None)


def _site(host):
    host = host.lower().removeprefix("www.")
    return {"pokemoncenter.com": "Pokémon Center", "funko.com": "Funko"}.get(host, host)


def for_item(name, set_name="", number="", tcg_id="", raw=None):
    raw = raw if isinstance(raw, dict) else {}
    out, stored = [], clean_url(raw.get("url") or "")
    host = urlsplit(stored).netloc.lower().removeprefix("www.") if stored else ""
    tcg = stored if host.endswith("tcgplayer.com") else tcgplayer_url(tcg_id)
    if tcg:
        out.append({"site": "TCGplayer", "url": tcg, "kind": "market", "stock": "unknown", "checked": None})
    out.append({"site": "eBay", "url": ebay_url(name, set_name, number), "kind": "market", "stock": "unknown", "checked": None})
    if stored and not host.endswith("tcgplayer.com"):
        st, day = _stock((raw.get("ext") or {}).get("Availability"))
        wst, wday = linkstore.stock_for(stored)                      # the weekly check's newer reading wins
        if wst and (not day or wday >= day):
            st, day = wst, wday
        out.append({"site": _site(host), "url": stored, "kind": "maker" if host.endswith(MAKER_HOSTS) else "retailer", "stock": st, "checked": day, "checkedText": linkstore.pretty(day) if day else ""})
    return out


def refresh_stock(items, **kw):
    """The weekly check's stock step (cardvault/weeklylinks.py): re-read In stock / Out of stock for the maker/retailer links of `items` ([(card_id, shop_list)]) and store it with its date.
    Returns {card_id: [updated shop_list]}; nothing is read (and {} comes back) unless the 7-day gate is open - use weeklylinks.run_weekly for the whole job."""
    from . import weeklylinks
    return weeklylinks.refresh_stock(items, **kw)
