"""Art proofs and prototypes of the designer-toy lists: kept out of every list unless the person turns them on (Game menu > "Show art proofs & prototypes").
The card list carries them in a side table (cards_extra); this moves them into the visible list or takes them out again.  A proof you OWN (or wishlisted) always stays visible."""
import sqlite3

GAMES = ("chomps", "dumpsterfires")


def apply(vault, on):
    c = vault.conn
    try:
        extra = [r[1] for r in c.execute("PRAGMA table_info(cards_extra)")]
    except sqlite3.Error:
        return 0
    if not extra:
        return 0
    cols = [r[1] for r in c.execute("PRAGMA table_info(cards)") if r[1] in extra]
    lst = ",".join(cols)
    ids = [r[0] for r in c.execute("SELECT id FROM cards_extra")]
    if not ids:
        return 0
    keep = set()
    try:
        keep |= {r[0] for r in c.execute("SELECT DISTINCT card_id FROM u.lots WHERE user_id=? AND game=? AND deleted=0", (vault.user_id, vault.game))}
        keep |= {r[0] for r in c.execute("SELECT card_id FROM u.wishlist WHERE user_id=? AND game=?", (vault.user_id, vault.game))}
    except sqlite3.Error:
        pass
    sid = f"{vault.game}:proofs"
    if on:
        c.execute(f"INSERT OR REPLACE INTO cards({lst}) SELECT {lst} FROM cards_extra")
        c.execute("INSERT OR REPLACE INTO sets(id,name,serie,release_date,total,official,logo) VALUES(?,?,?,?,?,?,NULL)", (sid, "Art proofs & prototypes", "Toys", "", len(ids), len(ids)))
    else:
        for i in range(0, len(ids), 400):
            chunk = [x for x in ids[i:i + 400] if x not in keep]
            if chunk:
                c.execute(f"DELETE FROM cards WHERE id IN ({','.join('?' * len(chunk))})", chunk)
        left = c.execute("SELECT COUNT(*) FROM cards WHERE set_id=?", (sid,)).fetchone()[0]
        if left:
            c.execute("UPDATE sets SET total=?, official=? WHERE id=?", (left, left, sid))
        else:
            c.execute("DELETE FROM sets WHERE id=?", (sid,))
    c.commit()
    return len(ids)
