"""Retired: the React screens are shown by webhost_wv.py (Edge WebView2) instead of an embedded Qt browser, which keeps the app small."""
