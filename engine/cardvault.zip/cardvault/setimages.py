"""Find set logos / symbols that are still missing.

Order of sources (each only for sets that still have nothing):
  1. pokemontcg.io's public set list (logos and symbols for promos, McDonald's sets, trainer kits, galleries...)
  2. a clean generated picture (set name, year, series colour) made on this PC, so no set box is ever empty.
Only downloads; nothing about you or your collection is sent."""
import json
import os
import re
import sqlite3
import time

import requests

from . import bulbapedia
from .db import logo_file

UA = "PokemonCardVault/3 (set pictures)"
PTCG_SETS = "https://api.pokemontcg.io/v2/sets"


KNOWN = [("basep", "Wizards Black Star Promos"), ("np", "Nintendo Black Star Promos"), ("dpp", "DP Black Star Promos"), ("hsp", "HGSS Black Star Promos"),
         ("bwp", "BW Black Star Promos"), ("xyp", "XY Black Star Promos"), ("smp", "SM Black Star Promos"), ("swshp", "SWSH Black Star Promos"),
         ("svp", "Scarlet & Violet Black Star Promos"), ("tk1a", "EX Trainer Kit Latias"), ("tk1b", "EX Trainer Kit Latios"), ("tk2a", "EX Trainer Kit 2 Plusle"),
         ("tk2b", "EX Trainer Kit 2 Minun"), ("swsh9tg", "Brilliant Stars Trainer Gallery"), ("swsh10tg", "Astral Radiance Trainer Gallery"),
         ("swsh11tg", "Lost Origin Trainer Gallery"), ("swsh12tg", "Silver Tempest Trainer Gallery")] +         [(f"mcd{y % 100}", f"McDonald's Collection {y}") for y in (2011, 2012, 2014, 2015, 2016, 2017, 2018, 2019, 2021, 2022)]


def _norm(s):
    s = (s or "").lower().replace("é", "e").replace("&", " and ").replace("'", "").replace("’", "")
    s = re.sub(r"\b(pokemon|tcg|the|set|collection|series)\b", " ", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def has_art(gdir, sid):
    p = [logo_file(gdir, sid), bulbapedia.art_path(gdir, sid, "logo")]
    return any(os.path.exists(x) and os.path.getsize(x) > 0 for x in p)


def generated_path(gdir, sid):
    return os.path.join(bulbapedia.setart_dir(gdir), f"{sid.replace('/', '_')}_generated.png")


def missing_sets(gdir):
    conn = sqlite3.connect(os.path.join(gdir, "cards.db"))
    try:
        rows = conn.execute("SELECT id, name, serie, release_date FROM sets").fetchall()
    finally:
        conn.close()
    return [r for r in rows if not has_art(gdir, r[0])]


def _download(url, dest):
    r = requests.get(url, timeout=30, headers={"User-Agent": UA})
    if r.status_code != 200 or len(r.content) < 200:
        return False
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "wb") as f:
        f.write(r.content)
    return True


def fetch_missing(gdir, cancel, progress):
    """Download logos / symbols for sets that have none.  Returns {'missing': n, 'found': n, 'urls': {set_id: logo url}}."""
    from .sync import Cancelled
    todo = missing_sets(gdir)
    out = {"missing": len(todo), "found": 0, "urls": {}}
    if not todo:
        return out
    progress("Looking for the missing set pictures…", 0, len(todo))
    data = None
    for attempt in range(4):                       # the free service is sometimes briefly unavailable; try different query shapes
        params = [{"pageSize": 250, "select": "id,name,series,ptcgoCode,releaseDate,images"}, {"pageSize": 250}][attempt % 2]
        try:
            r = requests.get(PTCG_SETS, params=params, timeout=60, headers={"User-Agent": UA})
            if r.status_code == 200:
                data = r.json().get("data", [])
                break
        except (requests.RequestException, ValueError):
            pass
        time.sleep(2 + 2 * attempt)
    if data is None:                               # service down: use the addresses we know follow a fixed pattern
        data = [{"id": i, "name": n, "releaseDate": "", "images": {"logo": f"https://images.pokemontcg.io/{i}/logo.png", "symbol": f"https://images.pokemontcg.io/{i}/symbol.png"}}
                for i, n in KNOWN]
    theirs = {}
    for s in data:
        theirs.setdefault(_norm(s["name"]), []).append(s)
    for i, (sid, name, serie, date) in enumerate(todo):
        if cancel.is_set():
            raise Cancelled()
        cands = theirs.get(_norm(name), [])
        if len(cands) > 1 and date:
            cands = sorted(cands, key=lambda s: abs(int((s.get("releaseDate") or "1900")[:4]) - int(date[:4] or 1900)))
        if cands:
            img = cands[0].get("images") or {}
            ok = False
            if img.get("logo"):
                ok = _download(img["logo"], bulbapedia.art_path(gdir, sid, "logo"))
                if ok:
                    out["urls"][sid] = img["logo"]
            if img.get("symbol"):
                _download(img["symbol"], bulbapedia.art_path(gdir, sid, "symbol"))
            out["found"] += 1 if ok else 0
            time.sleep(0.15)
        progress("Looking for the missing set pictures…", i + 1, len(todo))
    # remember the web addresses so the phone app can show the same pictures
    if out["urls"]:
        conn = sqlite3.connect(os.path.join(gdir, "cards.db"))
        try:
            old = conn.execute("SELECT value FROM meta WHERE key='setimg_urls'").fetchone()
            data = json.loads(old[0]) if old else {}
            data.update(out["urls"])
            conn.execute("INSERT OR REPLACE INTO meta VALUES('setimg_urls', ?)", (json.dumps(data),))
            conn.commit()
        finally:
            conn.close()
    return out


# ------------------------------------------------------------------------------------------------ generated pictures
PALETTE = [("#2a6df0", "#7aa7ff"), ("#d63a2f", "#ff9a8f"), ("#17995a", "#7fe0b0"), ("#8a4fd1", "#c9a2f5"), ("#d17b00", "#ffc46b"), ("#0f8fa3", "#7fdbe8"), ("#b03a75", "#f0a0c8")]


def _font(size):
    from PIL import ImageFont
    for f in ("segoeuib.ttf", "segoeui.ttf", "arialbd.ttf", "arial.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(f, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def make_generated(gdir, sid, name, serie, date):
    """A tidy label picture for a set that has no official logo anywhere (trainer kits, promos...)."""
    from PIL import Image, ImageDraw
    a, b = PALETTE[sum(map(ord, serie or "x")) % len(PALETTE)]
    W, H = 480, 240
    im = Image.new("RGB", (W, H), a)
    px = im.load()
    c1, c2 = tuple(int(a[i:i + 2], 16) for i in (1, 3, 5)), tuple(int(b[i:i + 2], 16) for i in (1, 3, 5))
    for y in range(H):
        t = y / (H - 1)
        col = tuple(int(c1[k] * (1 - t) + c2[k] * t) for k in range(3))
        for x in range(W):
            px[x, y] = col
    d = ImageDraw.Draw(im)
    font, small = _font(40), _font(24)
    words, lines, cur = name.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=font) > W - 50 and cur:
            lines.append(cur)
            cur = w
        else:
            cur = t
    lines.append(cur)
    lines = lines[:3]
    y = (H - len(lines) * 46 - 34) // 2
    for ln in lines:
        w = d.textlength(ln, font=font)
        d.text(((W - w) / 2 + 2, y + 2), ln, font=font, fill=(0, 0, 0, 90))
        d.text(((W - w) / 2, y), ln, font=font, fill="white")
        y += 46
    sub = " · ".join(x for x in (serie, (date or "")[:4]) if x)
    w = d.textlength(sub, font=small)
    d.text(((W - w) / 2, y + 6), sub, font=small, fill=(255, 255, 255))
    os.makedirs(os.path.dirname(generated_path(gdir, sid)), exist_ok=True)
    im.save(generated_path(gdir, sid), "PNG")


def make_all_generated(gdir):
    n = 0
    for sid, name, serie, date in missing_sets(gdir):
        if not os.path.exists(generated_path(gdir, sid)):
            make_generated(gdir, sid, name, serie, date)
            n += 1
    return n
