"""Search that forgives typos (roadmap "Search that forgives typos", 2026-11-10): 'charzard' finds Charizard, 'pika 25' finds Pikachu #25, 'blue eyes' finds Blue-Eyes White Dragon.

ONE small layer, shared by the card lists (db.Vault.query_cards - desktop AND website, the website runs this same Python), "Search everything" (webapi/searchindex.py) and, ported line for line,
the phone (ui/src/phone/fuzzy.js - the two are checked against the same cases in tests/test_fuzzy.py and tests/fuzzy.mjs).

  1. the exact search (LIKE per typed word) runs first, as always.  Exact names come first, then names that start with the words, then 'number + name' ('pika 25' = a Pikachu numbered 25), then the rest.
  2. only when that finds FEW cards, every typed word the card names do not know is replaced by the closest names' words ('charzard' -> 'charizard'; edits allowed: 0 for 1-3 letters, 1 for 4-7, 2 for 8+)
     and the search runs again; those cards come AFTER the exact ones.
  Words come from a vocabulary of the name words of the list (Vocab): no word is compared letter by letter unless a cheap letter-set check says it could be close (a few ms on Magic's 107,000 cards).
Pure functions and one small class: no database in here."""
import bisect
import re

PREFIX_KNOWN = 20                                           # names that must begin with a typed word for it to count as a word being typed, not as a typo
FEW = 5                                                     # fewer exact hits than this: typo tolerance is added behind them
_DROP = str.maketrans("", "", "'.’‘`")                      # letters kept together:   Farfetch'd -> farfetchd,  Mr. Mime -> mr mime
_SPACE = str.maketrans({c: " " for c in '-,:()'})           # words kept apart:        Blue-Eyes -> blue eyes
SQL_DROP, SQL_SPACE = ("'", "."), ("-", ",", ":", "(", ")")   # the same two lists for SQL's replace() - norm_sql() below (the ’ was already made ' by searchfold.fold)
_NUM = re.compile(r"^#?(\d{1,4})(?:/(\d{1,4}))?$")


def norm(s):
    """Words of a name or of what was typed, the way they are compared: lower case, no accents, 'blue-eyes' = 'blue eyes', "farfetch'd" = 'farfetchd', single spaces."""
    from .searchfold import fold
    return " ".join(fold(s).translate(_DROP).translate(_SPACE).split())


def norm_sql(col):
    """SQL that makes `col` (already folded) look like norm() does - apart from runs of spaces (replace() cannot squeeze them)."""
    for c in SQL_DROP:
        col = f"replace({col},'{c.replace(chr(39), chr(39) * 2)}','')"
    for c in SQL_SPACE:
        col = f"replace({col},'{c}',' ')"
    return col


def number(tok):
    """'25', '025', '#25', '25/102' -> 25 (the card number asked for), else None."""
    m = _NUM.match(tok or "")
    return int(m.group(1)) if m else None


def split_query(text):
    """-> (the typed words that are not numbers, joined and normalised;  [the numbers])"""
    names, nums = [], []
    for tok in (text or "").split():
        n = number(tok)
        (nums if n is not None else names).append(n if n is not None else tok)
    return norm(" ".join(names)), nums


def max_edits(n):
    """How many typos a word of n letters may have: none in a short word ('mew' is not 'mow'), one in a middle-sized one, two in a long one."""
    return 0 if n < 4 else 1 if n < 8 else 2


def mask(w):
    """The set of letters of a word as bits.  One edit changes at most two bits, so words further than 2*k bits from the typed one can't be within k edits (a cheap filter before the real count)."""
    m = 0
    for c in w:
        m |= 1 << (ord(c) & 31)
    return m


def osa(a, b, k):
    """Edit distance with swapped neighbours counting as one edit ('lugai' -> 'lugia' = 1), or k+1 as soon as it is clearly more than k."""
    la, lb = len(a), len(b)
    if abs(la - lb) > k:
        return k + 1
    prev2, prev = None, list(range(lb + 1))
    for i in range(1, la + 1):
        cur, ai = [i] + [0] * lb, a[i - 1]
        for j in range(1, lb + 1):
            v = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ai != b[j - 1]))
            if i > 1 and j > 1 and ai == b[j - 2] and a[i - 2] == b[j - 1]:
                v = min(v, prev2[j - 2] + 1)
            cur[j] = v
        if min(cur) > k:
            return k + 1
        prev2, prev = prev, cur
    return prev[lb]


class Vocab:
    """The name words of a card list (or of the whole search index) with how many names use each: counts = {word: n}.  correct(word) -> the closest words."""

    def __init__(self, counts):
        ws = sorted(w for w, n in counts.items() if w.isalpha() and 2 <= len(w) <= 30)
        self.sorted, self.counts, self.by_len = ws, counts, {}
        for w in ws:
            b = self.by_len.setdefault(len(w), ([], []))
            b[0].append(w)
            b[1].append(mask(w))

    def known(self, w):
        """True when `w` is a word, or the beginning of words used by enough names (a word being typed is not a typo; 'dragn' - the start of two rare words - is)."""
        if w in self.counts:
            return True
        i, total, n = bisect.bisect_left(self.sorted, w), 0, len(self.sorted)
        while i < n and self.sorted[i].startswith(w) and total < PREFIX_KNOWN:
            total += self.counts.get(self.sorted[i], 1)
            i += 1
        return total >= PREFIX_KNOWN

    def correct(self, w, limit=3):
        """The words within the allowed edits of `w`: the closest first, then the most used.  [] when `w` is a known word, too short, or nothing is close."""
        k = max_edits(len(w))
        if not k or not w.isalpha() or self.known(w):
            return []
        m, found = mask(w), []
        for ln in range(len(w) - k, len(w) + k + 1):
            b = self.by_len.get(ln)
            if not b:
                continue
            words, masks = b
            for i in [i for i, wm in enumerate(masks) if (wm ^ m).bit_count() <= 2 * k]:
                d = osa(w, words[i], k)
                if d <= k:
                    found.append((d, -self.counts.get(words[i], 1), words[i]))
        found.sort()
        if not found:
            return []
        best = [x for x in found if x[0] == found[0][0]]
        return [x[2] for x in best if -x[1] * 20 >= -best[0][1]][:limit]                 # (the closest words; a far rarer one beside a common one is noise)


def count_words(names, into=None):
    """{word: number of names using it} for an iterable of names (added to `into` when given)."""
    into = {} if into is None else into
    for nm in names:
        for w in set(norm(nm).split()):
            into[w] = into.get(w, 0) + 1
    return into


def correct_text(vocab, text):
    """The typed text with every unknown word replaced by its closest words ('charzard ex' -> 'charizard ex'; two close words: 'a|b').  None when nothing needed (or could be) corrected."""
    out, changed = [], False
    for tok in (text or "").split():
        c = vocab.correct(norm(tok)) if number(tok) is None and " " not in norm(tok) else []
        out.append("|".join(c) if c else tok)
        changed = changed or bool(c)
    return " ".join(out) if changed else None


def alternatives(tok):
    """A typed word of corrected text -> its alternatives ('charizard|charmander' -> both; a plain word -> itself)."""
    return [a for a in tok.split("|") if a] or [tok]


def first_choice(text):
    """Corrected text as one plain text: every word's first alternative (what exact names are ranked against)."""
    return " ".join(alternatives(t)[0] for t in (text or "").split())
