"""The extra price lines of an item's detail (roadmap rows "Price per grade", "Price by condition and language", "Recent sales list"), put together from what is ALREADY stored - nothing is fetched here.

    printings   TCGplayer's price of each printing of the card (Normal, Holofoil, Reverse Holofoil, 1st Edition ...), from cards.variant_prices (cardvault/variantprice.py); only when the card has 2 or more
    english     for a card of a non-English list (Japanese Pokémon): the English printings of the same card and their prices (cardvault/langlink.py), TCGplayer prices of the English list
    asks        eBay ASKING prices by grade / condition / language and the newest asks (cardvault/asksplit.py, the lines the daily eBay run read in the last 24 hours)
TCGplayer's free price feed (tcgcsv) gives one price per printing, not per condition, and no other connected free source gives conditions: condition lines exist only as eBay asks.
Nothing here is a sold price; the screens say "asking" next to every eBay number."""
from . import asksplit, variantprice

MAX_ENGLISH = 4


def printings(row):
    """[{name, usd}] the card's printings with a price, best price first; [] unless there are at least two."""
    vp = variantprice.prices_of(row)
    out = sorted(({"name": n, "usd": float(v)} for n, v in vp.items() if isinstance(v, (int, float)) and v > 0), key=lambda r: -r["usd"])
    return out if len(out) >= 2 else []


def english(link):
    """The English printings of a non-English card, from scanweb.english()'s answer: {status, enGame, english: [{id, name, set, number, rarity, price}]} or None when there is nothing to show."""
    if not link or link.get("status") != "linked":
        return None
    rows = [{k: r.get(k) for k in ("id", "name", "set", "number", "rarity", "price")} for r in link.get("english") or [] if r.get("price")]
    return {"game": link.get("enGame") or "", "rows": rows[:MAX_ENGLISH]} if rows else None


def detail(conn, card_id, row, link=None):
    """{printings, english, asks} for one card (row = {variant_prices, variants, price_usd}); see the module note."""
    return {"printings": printings(row), "english": english(link), "asks": asksplit.for_card(conn, card_id)}
