"""New release calendar (roadmap "New release calendar"): upcoming and recent releases - sets, sealed products and toy lines - by month, for the games the owner collects.

Where the dates come from (nothing is guessed, nothing is fetched here):
  * the release dates the catalogs already hold: sets.release_date and sealed_products.released in each game's card list (tcgcsv, TCGdex and the toy sources fill them in the daily update);
  * an optional per-game file games/<game>/announced_releases.json written by the daily checker from official / retailer pages that allow it:
    [{"name", "kind" (set|sealed|toy), "date" ("YYYY-MM-DD", "YYYY-MM" or empty = date TBA), "source", "url"}].  An entry with no source is ignored; an entry with no usable date shows as "date TBA".
A day that is not a real date is dropped, never repaired. Read-only on the catalogs.  "Add to wishlist" puts the set's cards on the game's wishlist when the cards are in the catalog;
otherwise (sealed products, a set not listed yet) it is saved in the account setting "release_wants" so the calendar keeps it marked."""
import datetime
import json
import os
import re
import sqlite3

from . import games
from .db import game_dir

KEY = "release_wants"
RECENT_DAYS = 60                   # how far back "recent" goes
LIMIT = 600                        # items kept per answer
KINDS = ("set", "sealed", "toy")
_DATE = re.compile(r"^(\d{4})-(\d{2})(?:-(\d{2}))?")


def parse_date(raw):
    """'2026-12-04...' -> ('2026-12-04', 'day'); '2026-12' -> ('2026-12', 'month'); anything else (also an impossible day) -> (None, None)."""
    m = _DATE.match(str(raw or "").strip())
    if not m:
        return None, None
    y, mo, d = int(m.group(1)), int(m.group(2)), m.group(3)
    try:
        if d:
            datetime.date(y, mo, int(d))
            return f"{y:04d}-{mo:02d}-{int(d):02d}", "day"
        datetime.date(y, mo, 1)
    except ValueError:
        return None, None
    return f"{y:04d}-{mo:02d}", "month"


def _start(date, prec):
    return date if prec == "day" else date + "-01"


def place(date, prec, today):
    """'upcoming' (today or later), 'recent' (inside RECENT_DAYS), 'tba' (no date) or None (too old). A month-only date counts by its last day, so a month still running is not called past."""
    if not date:
        return "tba"
    y, mo = int(date[:4]), int(date[5:7])
    d = int(date[8:10]) if prec == "day" else (datetime.date(y + (mo == 12), mo % 12 + 1, 1) - datetime.timedelta(days=1)).day
    day = datetime.date(y, mo, d)
    if day >= today:
        return "upcoming"
    return "recent" if (today - day).days <= RECENT_DAYS else None


def month_label(date):
    return datetime.date(int(date[:4]), int(date[5:7]), 1).strftime("%B %Y")


def collected_games(v):
    """Game ids the owner has copies or a wishlist in (in catalog order), so the calendar follows what is collected."""
    have = {r[0] for r in v.conn.execute("SELECT DISTINCT game FROM lots_s WHERE user_id=? AND deleted=0 AND qty>0", (v.user_id,))}
    have |= {r[0] for r in v.conn.execute("SELECT DISTINCT game FROM u.wishlist WHERE user_id=?", (v.user_id,))}
    have.add(v.game)
    return [g.id for g in games.GAMES if g.id in have]


def _announced(gdir):
    try:
        with open(os.path.join(gdir, "announced_releases.json"), encoding="utf-8") as f:
            rows = json.load(f)
    except (OSError, ValueError):
        return []
    return [r for r in rows if isinstance(r, dict) and r.get("name") and r.get("source")] if isinstance(rows, list) else []


def game_items(data_dir, gid):
    """Every item of one game as dicts (not filtered by window yet), announced ones included; [] when the card list is not on this device."""
    gdir = game_dir(data_dir, gid)
    path = os.path.join(gdir, "cards.db")
    misc = games.is_misc(gid)
    out = []
    if os.path.exists(path):
        try:
            c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                have = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if "sets" in have:
                    for sid, name, rel, total in c.execute("SELECT id, name, release_date, total FROM sets WHERE release_date IS NOT NULL AND release_date<>''"):
                        out.append({"id": f"set:{gid}:{sid}", "kind": "toy" if misc else "set", "ref": sid, "name": name, "raw": rel, "cards": total or 0, "source": "catalog"})
                if "sealed_products" in have:
                    for pid, name, setname, rel in c.execute("SELECT id, name, set_name, released FROM sealed_products WHERE released IS NOT NULL AND released<>''"):
                        out.append({"id": f"sealed:{gid}:{pid}", "kind": "sealed", "ref": str(pid), "name": name, "set": setname or "", "raw": rel, "source": "catalog"})
            finally:
                c.close()
        except sqlite3.Error:
            pass
    for i, a in enumerate(_announced(gdir)):
        kind = a.get("kind") if a.get("kind") in KINDS else "set"
        out.append({"id": f"ann:{gid}:{i}", "kind": kind, "ref": "", "name": str(a["name"]), "raw": a.get("date"), "source": str(a["source"])[:80], "url": str(a.get("url") or "")[:300]})
    items = []
    for it in out:
        date, prec = parse_date(it.pop("raw"))
        items.append({**it, "game": gid, "game_name": games.game_by_id(gid).name, "date": date, "precision": prec})
    return items


def build(items, today, game=None, kind=None, wants=()):
    """Pure: items (from game_items) -> {"months": [{key, label, when, items}], "tba": [...], "counts"}; upcoming first (soonest month first), then recent (newest month first)."""
    keep, tba = [], []
    for it in items:
        if game and it["game"] != game:
            continue
        if kind and it["kind"] != kind:
            continue
        it = {**it, "wanted": it["id"] in wants}
        p = place(it["date"], it["precision"], today)
        if p == "tba":
            tba.append(it)
        elif p:
            keep.append({**it, "when": p})
    keep.sort(key=lambda i: (_start(i["date"], i["precision"]), i["name"].lower()))
    up = [i for i in keep if i["when"] == "upcoming"]
    rec = [i for i in keep if i["when"] == "recent"][::-1]
    months = []
    for grp in (up, rec):
        for it in grp:
            k = it["date"][:7]
            if not months or months[-1]["key"] != k or months[-1]["when"] != it["when"]:
                months.append({"key": k, "label": month_label(it["date"]), "when": it["when"], "items": []})
            months[-1]["items"].append(it)
    tba.sort(key=lambda i: i["name"].lower())
    return {"months": months, "tba": tba[:200], "counts": {"upcoming": len(up), "recent": len(rec), "tba": len(tba)}}


def wants(svc):
    try:
        d = json.loads(svc.pget(KEY) or "{}")
    except ValueError:
        d = {}
    return d if isinstance(d, dict) else {}


def _cap(months, limit=LIMIT):
    out, n = [], 0
    for m in months:
        room = limit - n
        if room <= 0:
            break
        out.append({**m, "items": m["items"][:room]})
        n += len(out[-1]["items"])
    return out


def calendar(svc, game=None, kind=None, today=None):
    today = today or datetime.date.today()
    v = svc.vault
    gids = collected_games(v)
    items = []
    for gid in gids:
        items += game_items(v.data_dir, gid)
    game = game if game in gids else None
    kind = kind if kind in KINDS else None
    res = build(items, today, game, kind, set(wants(svc)))
    res["games"] = [{"id": g, "name": games.game_by_id(g).name} for g in gids]
    res["game"] = game or ""
    res["kind"] = kind or ""
    res["months"] = _cap(res["months"])
    return res


def find(data_dir, item_id):
    """The calendar item with this id (or None)."""
    parts = str(item_id).split(":", 2)
    if len(parts) < 3 or parts[1] not in {g.id for g in games.GAMES}:
        return None
    return next((i for i in game_items(data_dir, parts[1]) if i["id"] == item_id), None)


def set_card_ids(data_dir, gid, set_id):
    path = os.path.join(game_dir(data_dir, gid), "cards.db")
    if not os.path.exists(path):
        return []
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            return [r[0] for r in c.execute("SELECT id FROM cards WHERE set_id=?", (set_id,))]
        finally:
            c.close()
    except sqlite3.Error:
        return []
