"""A second opinion for the Pokemon list differences (roadmap: "Pokemon English and Japanese filled in").

A single source never changes our list.  When PokeCottage (or The Hobby Bin) disagrees with a card's name or rarity, the card's own TCGplayer product record is asked:
  * it agrees with the page and not with us  -> two sources against ours: the fix is applied (provenance 'fix', so the nightly re-sync keeps it);
  * it agrees with us                        -> ours is confirmed by two sources (the page has a typo or its own spelling): nothing changes, nothing is asked;
  * anything else (no product link, TCGplayer says a third thing) -> the review list, as before.

records(conn, set_id, fetcher)   -> {tcg product id: {"name", "rarity"}}  read from the TCGplayer group of that set (tcgcsv mirror, through the shared polite Fetcher)
settle(rep, ours, products)      -> {"apply": [...], "confirmed": [...], "review": [...]}  (pure: no network, writes nothing)
apply_fixes(conn, fixes)         -> number written   (name / rarity only; fills an empty rarity, never touches anything else)"""
import html
import re

from . import pokemonlists, provenance


def clean_name(name):
    """TCGplayer's product name as a card name: 'Adventure Lantern - 126/103 126/103' -> 'Adventure Lantern'; a trailing '(Pokemon Center Exclusive)' goes."""
    n = html.unescape(name or "")
    n = re.sub(r"\s+-\s+\d+[A-Za-z]?(?:/\d+)?.*$", "", n)
    return re.sub(r"\s*\([^)]*\)\s*$", "", n).strip()


def _tokens(x):
    return [t for t in re.sub(r"[^a-z0-9]+", " ", (x or "").lower().replace("é", "e")).split() if t]


def agrees(a, b):
    """Two names say the same card: the same once typography and tails are ignored, or TCGplayer's own shortened name (it cuts long names: 'Growing G Energy')."""
    if pokemonlists.same_name(a, b):
        return True
    ta, tb = _tokens(a), _tokens(b)
    short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    return bool(short) and len(short) == len(long_) and all(l.startswith(s) for s, l in zip(short, long_))


def same_rarity(a, b):
    return (a or "").strip().lower() == (b or "").strip().lower()


def records(conn, set_id, fetcher):
    """TCGplayer's product records for the cards of one set: the group whose name matches the set's name (tcgcsv, category 3)."""
    from . import sources, tcgsync
    set_name = (conn.execute("SELECT name FROM sets WHERE id=?", (set_id,)).fetchone() or [""])[0]
    t = sources.TcgCsv(fetcher)
    out = {}
    for g in t.results(t.groups(3)):
        if not tcgsync._same_set_name(g["name"], set_name):
            continue
        for p in t.results(t.products(3, g["groupId"])):
            ext = {e["name"]: e["value"] for e in p.get("extendedData", [])}
            out[str(p["productId"])] = {"name": clean_name(p.get("name")), "rarity": ext.get("Rarity", "")}
    return out


def settle(rep, ours, products):
    """rep = pokemonlists.compare(...) result; ours = {card id: tcg product id or ''}; products = records(...).  -> {"apply", "confirmed", "review"} lists of the differences."""
    res = {"apply": [], "confirmed": [], "review": []}
    for field, key in (("names", "name"), ("rarity", "rarity")):
        for d in rep[field]:
            rec = products.get(str(ours.get(d["id"]) or ""))
            item = dict(d, field=key)
            if not rec or not rec.get(key):
                res["review"].append(item)
                continue
            same = agrees if key == "name" else same_rarity
            if same(rec[key], d["after"]) and not same(rec[key], d["before"]):
                res["apply"].append(dict(item, tcgplayer=rec[key]))
            elif same(rec[key], d["before"]):
                res["confirmed"].append(dict(item, tcgplayer=rec[key]))
            else:
                res["review"].append(dict(item, tcgplayer=rec[key]))
    return res


def apply_fixes(conn, fixes):
    n = 0
    for f in fixes:
        col = "name" if f["field"] == "name" else "rarity"
        conn.execute(f"UPDATE cards SET {col}=? WHERE id=?", (f["after"], f["id"]))
        provenance.record(conn, f["id"], col, "fix")
        n += 1
    return n
