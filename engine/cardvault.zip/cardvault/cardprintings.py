"""Other printings of a card - the same card in other sets, rarities and finishes - for the scanner to offer once it has recognised one.  A picture alone often cannot tell them apart: a Yu-Gi-Oh! card is
one artwork in a dozen sets and rarities, a One Piece card comes as a regular, a parallel and a manga version, so the person picks the right one from a short list.

What 'the same card' means depends on the game: in Yu-Gi-Oh!, Magic and Lorcana a card IS its name; in most other games a name is used again for different cards (a hundred Agumons), so the printed number
must match too (OP01-003 in the booster and in the premium reprint); a Pokémon card is told by its name, HP and artist.  A printing is not a different card, so the brackets that only describe one -
'(Parallel)', '(Foil)', '(OP01-003)' - are left out of the name.  tests/test_cardprintings.py has the cases."""
import re

from . import raritytiers
from .db import taxonomy_rank
from .games import game_by_id

NAME_ONLY = frozenset({"yugioh", "mtg", "lorcana", "sorcery"})
BY_ARTIST = frozenset({"pokemon", "pokemon_jp", "pokemon_tw"})
_TAIL = re.compile(r"\s*[\(\[][^()\[\]]{1,60}[\)\]]")
_KEEP_TAIL = {"fab": re.compile(r"red|yellow|blue", re.I)}                     # Flesh and Blood: 'Snatch (Red)' and 'Snatch (Blue)' are two different cards
_VARIANT_MARK = re.compile(r"(?:_[A-Za-z]+\d*|[A-Za-z]+)$")
_LAST = chr(0xFFFF)                                                            # sorts after every name that starts with the same words
_COLUMNS = "c.id, c.name, c.local_id, c.hp, c.illustrator, c.rarity, c.set_id, c.price_usd, c.image_base, s.name AS set_name, s.release_date AS released"


def base_name(game, name):
    """A card's name without the brackets that only describe a printing: 'Luffy (Parallel)' and 'Luffy (OP01-003) [Foil]' -> 'Luffy'."""
    keep = _KEEP_TAIL.get(game)

    def tail(m):
        return m.group(0) if keep and keep.fullmatch(m.group(0).strip()[1:-1].strip()) else ""
    return re.sub(r"\s+", " ", _TAIL.sub(tail, name or "")).strip()


def variant_of(game, name, rarity="", number=""):
    """What the brackets of a name say about the printing, apart from what the list already shows as its rarity and number: 'Dark Magician Girl (3rd Art) (Platinum Secret Rare)' -> '3rd Art'."""
    keep, said = _KEEP_TAIL.get(game), {str(rarity or "").strip().lower(), str(number or "").strip().lower()}
    tails = [m.group(0).strip()[1:-1].strip() for m in _TAIL.finditer(name or "")]
    return " · ".join(t for t in tails if t and t.lower() not in said and not (keep and keep.fullmatch(t)))


def number_root(number):
    """The printed number without the letters that mark a variant: 'OP01-003_p1' and 'OP01-003' are one card, so are 'SAO/S20-001SP' and 'SAO/S20-001'."""
    return _VARIANT_MARK.sub("", str(number or "").strip()).upper()


def identity(game, name, number="", hp="", artist=""):
    """What two printings of one card have in common (for `game`)."""
    base = base_name(game, name).lower()
    if game in NAME_ONLY:
        return (base,)
    if game in BY_ARTIST:
        return (base, str(hp or "").strip(), str(artist or "").strip().lower())
    return (base, number_root(number))


def same_card(conn, game, card_id):
    """Every card of the list that is the same card as `card_id` (itself included), newest set first - as rows with id, name, local_id, rarity, set_id, price_usd, image_base, set_name, released.
    Nothing for an id the list does not have.  `conn` returns sqlite3.Row rows."""
    row = conn.execute("SELECT name, local_id, hp, illustrator FROM cards WHERE id=?", (str(card_id),)).fetchone()
    if row is None:
        return []
    want, base = identity(game, row["name"], row["local_id"], row["hp"], row["illustrator"]), base_name(game, row["name"])
    rows = conn.execute(f"SELECT {_COLUMNS} FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.name >= ? AND c.name < ?", (base, base + _LAST)).fetchall() if base else []
    same = [r for r in rows if identity(game, r["name"], r["local_id"], r["hp"], r["illustrator"]) == want]
    same.sort(key=lambda r: (r["released"] or "", str(r["local_id"] or "")), reverse=True)
    return same or conn.execute(f"SELECT {_COLUMNS} FROM cards c LEFT JOIN sets s ON s.id=c.set_id WHERE c.id=?", (str(card_id),)).fetchall()


def rarities_of(game, rows):
    """The different rarities among `rows`, the easiest pull first: in the game's own order where it names the rarity, else by the tier it belongs to (common ... secret, promo), else last."""
    order, tiers = game_by_id(game).rarity_order, [t[0] for t in raritytiers.TIERS]

    def key(rarity):
        rank = taxonomy_rank(rarity, order)
        if rank < len(order):
            return (0, rank, rarity)
        tier = raritytiers.tier_of(rarity)
        return (1, tiers.index(tier) if tier else len(tiers), rarity)
    return sorted({r["rarity"] for r in rows if r["rarity"]}, key=key)
